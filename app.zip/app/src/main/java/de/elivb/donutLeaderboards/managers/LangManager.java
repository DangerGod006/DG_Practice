package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.ColorUtil;
import de.elivb.donutLeaderboards.Leaderboards;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/LangManager.class */
public class LangManager {
    private final Leaderboards plugin;
    private FileConfiguration langConfig;
    private final Map<String, String> messages = new HashMap();

    public LangManager(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public void loadMessages() {
        File langFile = new File(this.plugin.getDataFolder(), "lang.yml");
        if (!langFile.exists()) {
            this.plugin.saveResource("lang.yml", false);
        }
        this.langConfig = YamlConfiguration.loadConfiguration(langFile);
        this.messages.clear();
        if (this.langConfig.contains("messages")) {
            for (String key : this.langConfig.getConfigurationSection("messages").getKeys(false)) {
                String message = this.langConfig.getString("messages." + key, "");
                this.messages.put(key, ColorUtil.colorize(message));
            }
        }
    }

    public String getMessage(String key) {
        return this.messages.getOrDefault(key, ColorUtil.colorize("&cMessage not found: " + key));
    }

    public void reloadMessages() {
        loadMessages();
    }
}
