package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/HeadDatabaseManager.class */
public class HeadDatabaseManager {
    private final Leaderboards plugin;
    private Connection connection;
    private final ConcurrentHashMap<UUID, ItemStack> headCache = new ConcurrentHashMap<>();
    private final long CACHE_TIME = 3600000;
    private ScheduledExecutorService scheduler;

    public HeadDatabaseManager(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public void initializeDatabase() {
        try {
            File dbFile = new File(this.plugin.getDataFolder(), "heads.db");
            if (!dbFile.exists()) {
                dbFile.createNewFile();
            }
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            createTable();
        } catch (Exception e) {
        }
    }

    private void createTable() throws SQLException {
        Statement stmt = this.connection.createStatement();
        try {
            stmt.execute("CREATE TABLE IF NOT EXISTS player_heads (uuid VARCHAR(36) PRIMARY KEY,name VARCHAR(16),texture_url TEXT,last_updated BIGINT)");
            if (stmt != null) {
                stmt.close();
            }
        } catch (Throwable th) {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public ItemStack getPlayerHead(UUID uuid, String playerName) {
        if (this.headCache.containsKey(uuid)) {
            return this.headCache.get(uuid).clone();
        }
        ItemStack head = new ItemStack(Material.PLAYER_HEAD, 1);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        String textureURL = getTextureFromDatabase(uuid);
        if (textureURL != null && !textureURL.isEmpty()) {
            setSkullTexture(meta, textureURL);
        } else {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                meta.setOwningPlayer(player);
                saveTextureToDatabase(uuid, playerName, getTextureFromPlayer(player));
            } else {
                meta.setOwningPlayer(Bukkit.getOfflinePlayer(uuid));
            }
        }
        head.setItemMeta(meta);
        this.headCache.put(uuid, head.clone());
        if (this.scheduler == null) {
            this.scheduler = Executors.newSingleThreadScheduledExecutor();
        }
        this.scheduler.schedule(() -> {
            this.headCache.remove(uuid);
        }, 3600000L, TimeUnit.MILLISECONDS);
        return head;
    }

    private String getTextureFromPlayer(Player player) {
        try {
            PlayerTextures textures = player.getPlayerProfile().getTextures();
            if (textures.getSkin() != null) {
                return textures.getSkin().toString();
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private void setSkullTexture(SkullMeta meta, String textureURL) {
        try {
            UUID hashUUID = UUID.nameUUIDFromBytes(textureURL.getBytes());
            PlayerProfile profile = Bukkit.createPlayerProfile(hashUUID);
            PlayerTextures textures = profile.getTextures();
            textures.setSkin(new URL(textureURL));
            profile.setTextures(textures);
            meta.setOwnerProfile(profile);
        } catch (Exception e) {
        }
    }

    private String getTextureFromDatabase(UUID uuid) {
        try {
            PreparedStatement pstmt = this.connection.prepareStatement("SELECT texture_url FROM player_heads WHERE uuid = ?");
            try {
                pstmt.setString(1, uuid.toString());
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    String string = rs.getString("texture_url");
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    return string;
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                return null;
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        e.printStackTrace();
        return null;
    }

    private void saveTextureToDatabase(UUID uuid, String name, String textureURL) {
        if (textureURL == null) {
            return;
        }
        try {
            PreparedStatement pstmt = this.connection.prepareStatement("INSERT OR REPLACE INTO player_heads (uuid, name, texture_url, last_updated) VALUES (?, ?, ?, ?)");
            try {
                pstmt.setString(1, uuid.toString());
                pstmt.setString(2, name);
                pstmt.setString(3, textureURL);
                pstmt.setLong(4, System.currentTimeMillis());
                pstmt.executeUpdate();
                if (pstmt != null) {
                    pstmt.close();
                }
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeDatabase() {
        if (this.scheduler != null && !this.scheduler.isShutdown()) {
            this.scheduler.shutdown();
        }
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
