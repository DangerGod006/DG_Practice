package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/SearchManager.class */
public class SearchManager {
    private final Leaderboards plugin;
    private final ConcurrentHashMap<UUID, String> searchQueries = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<UUID, Boolean> waitingForSearch = new ConcurrentHashMap<>();

    public SearchManager(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public void setSearchQuery(UUID playerId, String query) {
        if (query == null || query.isEmpty()) {
            this.searchQueries.remove(playerId);
        } else {
            this.searchQueries.put(playerId, query);
        }
    }

    public String getSearchQuery(UUID playerId) {
        return this.searchQueries.getOrDefault(playerId, "");
    }

    public void clearSearchQuery(UUID playerId) {
        this.searchQueries.remove(playerId);
    }

    public void setWaitingForSearch(UUID playerId, boolean waiting) {
        if (waiting) {
            this.waitingForSearch.put(playerId, true);
        } else {
            this.waitingForSearch.remove(playerId);
        }
    }

    public boolean isWaitingForSearch(UUID playerId) {
        return this.waitingForSearch.containsKey(playerId);
    }

    public void clearAll() {
        this.searchQueries.clear();
        this.waitingForSearch.clear();
    }
}
