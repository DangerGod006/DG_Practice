package de.elivb.donutLeaderboards.listeners;

import de.elivb.donutLeaderboards.ColorUtil;
import de.elivb.donutLeaderboards.Leaderboards;
import de.elivb.donutLeaderboards.managers.DataManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/listeners/GUIListener.class */
public class GUIListener implements Listener {
    private final Leaderboards plugin;
    private final Map<UUID, String> waitingForSearch = new ConcurrentHashMap();
    private final Map<UUID, Long> lastClickTime = new ConcurrentHashMap();
    private final long CLICK_COOLDOWN = 200;
    private final String MAIN_MENU_TITLE = ColorUtil.colorize("&8ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅꜱ");

    public GUIListener(Leaderboards plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player) {
            Player player = (Player) event.getWhoClicked();
            String title = event.getView().getTitle();
            boolean isMainMenu = title.equals(this.MAIN_MENU_TITLE);
            boolean isLeaderboard = title.contains("Leaderboard") || title.contains("ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ") || title.contains("ᴍᴏѕᴛ");
            if (isMainMenu || isLeaderboard) {
                event.setCancelled(true);
                int slot = event.getSlot();
                if (slot < 0) {
                    return;
                }
                UUID uuid = player.getUniqueId();
                long now = System.currentTimeMillis();
                if (this.lastClickTime.containsKey(uuid) && now - this.lastClickTime.get(uuid).longValue() < 200) {
                    return;
                }
                this.lastClickTime.put(uuid, Long.valueOf(now));
                if (isMainMenu) {
                    handleMainMenuClick(player, slot);
                } else {
                    handleLeaderboardClick(player, title, slot);
                }
            }
        }
    }

    private void handleMainMenuClick(Player player, int slot) {
        Map<Integer, String> slotToLeaderboard = getMainMenuSlots();
        if (slotToLeaderboard.containsKey(Integer.valueOf(slot))) {
            String leaderboardType = slotToLeaderboard.get(Integer.valueOf(slot));
            this.plugin.getSoundManager().playSound(player, "click-sound");
            this.plugin.getLeaderboardGUI().openLeaderboard(player, leaderboardType, 1);
        }
    }

    private Map<Integer, String> getMainMenuSlots() {
        Map<Integer, String> slots = new HashMap<>();
        slots.put(10, "money");
        slots.put(11, "deaths");
        slots.put(12, "playtime");
        slots.put(13, "blocks-placed");
        slots.put(14, "blocks-broken");
        slots.put(15, "mobs-killed");
        slots.put(16, "player-kills");
        return slots;
    }

    private void handleLeaderboardClick(Player player, String title, int slot) {
        UUID clickedUUID;
        String leaderboardType = extractLeaderboardType(title);
        if (leaderboardType == null) {
            return;
        }
        Map<Integer, UUID> slotMap = this.plugin.getLeaderboardGUI().getOpenInventory(player.getUniqueId());
        if (slotMap != null && slotMap.containsKey(Integer.valueOf(slot)) && (clickedUUID = slotMap.get(Integer.valueOf(slot))) != null) {
            this.plugin.getSoundManager().playSound(player, "click-sound");
            OfflinePlayer target = Bukkit.getOfflinePlayer(clickedUUID);
            String playerName = target.getName();
            if (playerName == null) {
                playerName = clickedUUID.toString().substring(0, 8);
            }
            String command = getPlayerCommand(leaderboardType).replace("%player%", playerName);
            if (command.startsWith("/")) {
                command = command.substring(1);
            }
            String finalCommand = command;
            this.plugin.runTask(player, () -> {
                player.performCommand(finalCommand);
            });
            return;
        }
        int currentPage = extractPageFromTitle(title);
        FileConfiguration guiConfig = this.plugin.getConfigManager().getLeaderboardGUI(leaderboardType);
        if (guiConfig == null) {
            return;
        }
        int backSlot = guiConfig.getInt("items.back.slot", -1);
        if (slot == backSlot) {
            this.plugin.getSoundManager().playSound(player, "click-sound");
            if (currentPage > 1) {
                this.plugin.getLeaderboardGUI().openLeaderboard(player, leaderboardType, currentPage - 1);
                return;
            } else {
                this.plugin.getLeaderboardGUI().openMainMenu(player);
                return;
            }
        }
        int nextSlot = guiConfig.getInt("items.next.slot", -1);
        if (slot == nextSlot) {
            this.plugin.getSoundManager().playSound(player, "click-sound");
            int totalPlayers = this.plugin.getDataManager().getTotalPlayersWithStat(DataManager.StatType.fromGuiName(leaderboardType));
            String playerRange = guiConfig.getString("players", "0-44");
            int playersPerPage = getPlayersPerPage(playerRange);
            int totalPages = (int) Math.ceil(((double) totalPlayers) / ((double) playersPerPage));
            if (currentPage < totalPages) {
                this.plugin.getLeaderboardGUI().openLeaderboard(player, leaderboardType, currentPage + 1);
                return;
            }
            return;
        }
        int refreshSlot = guiConfig.getInt("items.refresh.slot", -1);
        if (slot == refreshSlot) {
            this.plugin.getSoundManager().playSound(player, "click-sound");
            this.plugin.getDataManager().clearCache();
            this.plugin.getLeaderboardGUI().openLeaderboard(player, leaderboardType, currentPage);
        } else {
            int searchSlot = guiConfig.getInt("items.search.slot", -1);
            if (slot == searchSlot) {
                this.plugin.getSoundManager().playSound(player, "click-sound");
                startSearch(player, leaderboardType, currentPage);
            }
        }
    }

    private void startSearch(Player player, String leaderboardType, int currentPage) {
        if (!player.hasPermission("leaderboards.use")) {
            player.sendMessage(this.plugin.getLangManager().getMessage("no-permissions"));
            return;
        }
        UUID uuid = player.getUniqueId();
        this.waitingForSearch.put(uuid, leaderboardType);
        boolean useSignAPI = this.plugin.getConfigManager().useSignAPI();
        if (useSignAPI) {
            List<String> signLines = this.plugin.getConfigManager().getSignGUILines();
            String[] lines = new String[4];
            for (int i = 0; i < 4 && i < signLines.size(); i++) {
                lines[i] = signLines.get(i);
            }
            this.plugin.getSignManager().openSignEditor(player, lines, (p, input) -> {
                String searchTerm = input.trim();
                this.waitingForSearch.remove(p.getUniqueId());
                if (searchTerm.isEmpty() || searchTerm.equalsIgnoreCase("cancel")) {
                    p.sendMessage(this.plugin.getLangManager().getMessage("search-cancelled"));
                    this.plugin.getLeaderboardGUI().openLeaderboard(p, leaderboardType, currentPage);
                } else {
                    this.plugin.getLeaderboardGUI().openSearchResults(p, leaderboardType, searchTerm, 1);
                }
            });
            return;
        }
        player.closeInventory();
        player.sendMessage(this.plugin.getLangManager().getMessage("chat-input"));
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (this.waitingForSearch.containsKey(uuid)) {
            event.setCancelled(true);
            String leaderboardType = this.waitingForSearch.remove(uuid);
            String message = event.getMessage();
            if (message.equalsIgnoreCase("cancel")) {
                player.sendMessage(this.plugin.getLangManager().getMessage("search-cancelled"));
                this.plugin.runTask(player, () -> {
                    this.plugin.getLeaderboardGUI().openLeaderboard(player, leaderboardType, 1);
                });
            } else {
                this.plugin.runTask(player, () -> {
                    this.plugin.getLeaderboardGUI().openSearchResults(player, leaderboardType, message, 1);
                });
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        this.waitingForSearch.remove(uuid);
        this.lastClickTime.remove(uuid);
        this.plugin.getLeaderboardGUI().removeOpenInventory(uuid);
    }

    private String extractLeaderboardType(String title) {
        return title.contains("ᴍᴏɴᴇʏ") ? "money" : title.contains("ᴅᴇᴀᴛʜꜱ") ? "deaths" : title.contains("ᴘʟᴀʏᴛɪᴍᴇ") ? "playtime" : title.contains("ʙʟᴏᴄᴋꜱ ᴘʟᴀᴄᴇᴅ") ? "blocks-placed" : title.contains("ʙʟᴏᴄᴋꜱ ʙʀᴏᴋᴇɴ") ? "blocks-broken" : title.contains("ᴍᴏʙꜱ ᴋɪʟʟᴇᴅ") ? "mobs-killed" : title.contains("ᴘʟᴀʏᴇʀ ᴋɪʟʟꜱ") ? "player-kills" : "money";
    }

    private int extractPageFromTitle(String title) {
        try {
            int pageIndex = title.indexOf("Page ");
            if (pageIndex == -1) {
                return 1;
            }
            int start = pageIndex + 5;
            int end = start;
            while (end < title.length() && Character.isDigit(title.charAt(end))) {
                end++;
            }
            if (end > start) {
                return Integer.parseInt(title.substring(start, end));
            }
            return 1;
        } catch (Exception e) {
            return 1;
        }
    }

    private int getPlayersPerPage(String range) {
        if (range.contains("-")) {
            String[] parts = range.split("-");
            try {
                int start = Integer.parseInt(parts[0]);
                int end = Integer.parseInt(parts[1]);
                return (end - start) + 1;
            } catch (NumberFormatException e) {
                return 45;
            }
        }
        return 45;
    }

    private String getPlayerCommand(String leaderboardType) {
        FileConfiguration guiConfig = this.plugin.getConfigManager().getLeaderboardGUI(leaderboardType);
        if (guiConfig != null) {
            return guiConfig.getString("items.player.command", "stats %player%");
        }
        return "stats %player%";
    }
}
