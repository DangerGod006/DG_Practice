package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.ColorUtil;
import de.elivb.donutLeaderboards.Leaderboards;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/SignManager.class */
public class SignManager implements Listener {
    private final Leaderboards plugin;
    private final Map<UUID, SignSession> activeSessions = new HashMap();
    private final Map<UUID, Location> signLocations = new HashMap();

    public SignManager(Leaderboards plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public void openSignEditor(Player player, String[] defaultLines, BiConsumer<Player, String> callback) {
        UUID uuid = player.getUniqueId();
        closeSession(player);
        SignSession session = new SignSession(callback, defaultLines);
        this.activeSessions.put(uuid, session);
        Location signLoc = player.getLocation().getBlock().getLocation();
        Block block = signLoc.getBlock();
        session.oldBlockType = block.getType();
        session.oldBlockData = block.getBlockData();
        block.setType(Material.OAK_SIGN);
        this.signLocations.put(uuid, signLoc);
        Sign state = block.getState();
        if (state instanceof Sign) {
            Sign sign = state;
            for (int i = 0; i < 4; i++) {
                String line = "";
                if (defaultLines != null && i < defaultLines.length && defaultLines[i] != null) {
                    line = defaultLines[i];
                }
                sign.setLine(i, line);
            }
            sign.update();
        }
        player.getScheduler().run(this.plugin, scheduledTask -> {
            Location currentLoc;
            if (player.isOnline() && (currentLoc = this.signLocations.get(uuid)) != null && currentLoc.isWorldLoaded()) {
                Block currentBlock = currentLoc.getBlock();
                Sign state2 = currentBlock.getState();
                if (state2 instanceof Sign) {
                    Sign sign2 = state2;
                    String[] lines = new String[4];
                    int i2 = 0;
                    while (i2 < 4) {
                        lines[i2] = (defaultLines == null || i2 >= defaultLines.length || defaultLines[i2] == null) ? "" : defaultLines[i2];
                        i2++;
                    }
                    player.sendSignChange(currentLoc, lines);
                    player.getScheduler().runDelayed(this.plugin, task -> {
                        if (player.isOnline()) {
                            player.openSign(sign2);
                        }
                    }, (Runnable) null, 2L);
                }
            }
        }, (Runnable) null);
    }

    public void openSignEditor(Player player, String defaultText, BiConsumer<Player, String> callback) {
        String[] lines = new String[4];
        if (defaultText != null && !defaultText.isEmpty()) {
            lines[0] = defaultText;
        }
        openSignEditor(player, lines, callback);
    }

    public void openSignEditor(Player player, BiConsumer<Player, String> callback) {
        openSignEditor(player, (String[]) null, callback);
    }

    public void closeSession(Player player) {
        Location loc;
        Block block;
        UUID uuid = player.getUniqueId();
        SignSession session = this.activeSessions.remove(uuid);
        if (session != null && (loc = this.signLocations.remove(uuid)) != null && loc.isWorldLoaded() && (block = loc.getBlock()) != null && block.getType() == Material.OAK_SIGN) {
            if (session.oldBlockType != null && session.oldBlockType != Material.AIR) {
                block.setType(session.oldBlockType);
                if (session.oldBlockData != null) {
                    block.setBlockData(session.oldBlockData);
                    return;
                }
                return;
            }
            block.setType(Material.AIR);
        }
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        Block block;
        String defaultLine;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (!this.activeSessions.containsKey(uuid)) {
            return;
        }
        SignSession session = this.activeSessions.get(uuid);
        event.setCancelled(true);
        StringBuilder textBuilder = new StringBuilder();
        for (int i = 0; i < event.getLines().length; i++) {
            String currentLine = event.getLine(i);
            if (currentLine != null && !currentLine.isEmpty()) {
                boolean isDefaultLine = false;
                if (session.defaultLines != null && i < session.defaultLines.length && (defaultLine = session.defaultLines[i]) != null && defaultLine.equals(currentLine)) {
                    isDefaultLine = true;
                }
                if (!isDefaultLine) {
                    if (textBuilder.length() > 0) {
                        textBuilder.append(" ");
                    }
                    textBuilder.append(currentLine);
                }
            }
        }
        String input = textBuilder.toString().trim();
        this.activeSessions.remove(uuid);
        Location loc = this.signLocations.remove(uuid);
        if (loc != null && loc.isWorldLoaded() && (block = loc.getBlock()) != null) {
            if (session.oldBlockType != null && session.oldBlockType != Material.AIR) {
                block.setType(session.oldBlockType);
                if (session.oldBlockData != null) {
                    block.setBlockData(session.oldBlockData);
                }
            } else {
                block.setType(Material.AIR);
            }
        }
        if (input.isEmpty()) {
            if (session.callback != null) {
                session.callback.accept(player, "cancel");
            }
        } else {
            if (input.contains("&")) {
                input = ColorUtil.colorize(input);
            }
            if (session.callback != null) {
                session.callback.accept(player, input);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (this.activeSessions.containsKey(uuid)) {
            if ((event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_BLOCK) && event.getClickedBlock() != null && event.getClickedBlock().getType() == Material.OAK_SIGN) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Location signLoc;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (this.activeSessions.containsKey(uuid) && (signLoc = this.signLocations.get(uuid)) != null && signLoc.isWorldLoaded() && event.getBlock().getLocation().equals(signLoc)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        closeSession(event.getPlayer());
    }

    /* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/SignManager$SignSession.class */
    private static class SignSession {
        final BiConsumer<Player, String> callback;
        final String[] defaultLines;
        Material oldBlockType = Material.AIR;
        BlockData oldBlockData;

        SignSession(BiConsumer<Player, String> callback, String[] defaultLines) {
            this.callback = callback;
            this.defaultLines = defaultLines;
        }
    }
}
