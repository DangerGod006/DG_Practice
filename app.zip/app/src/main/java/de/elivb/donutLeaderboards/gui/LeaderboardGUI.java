package de.elivb.donutLeaderboards.gui;

import de.elivb.donutLeaderboards.ColorUtil;
import de.elivb.donutLeaderboards.Leaderboards;
import de.elivb.donutLeaderboards.managers.DataManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/gui/LeaderboardGUI.class */
public class LeaderboardGUI {
    private final Leaderboards plugin;
    private final Map<UUID, Map<Integer, UUID>> openInventories = new ConcurrentHashMap();

    public LeaderboardGUI(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public void openMainMenu(Player player) {
        int slot;
        FileConfiguration guiConfig = this.plugin.getConfigManager().getMainGUI();
        if (guiConfig == null) {
            return;
        }
        String title = guiConfig.getString("main.title", "&8ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅꜱ");
        String title2 = ColorUtil.colorize(title);
        int rows = guiConfig.getInt("main.rows", 3);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title2);
        if (guiConfig.contains("main.items")) {
            for (String key : guiConfig.getConfigurationSection("main.items").getKeys(false)) {
                String path = "main.items." + key;
                boolean enabled = guiConfig.getBoolean(path + ".enabled", true);
                if (enabled && (slot = guiConfig.getInt(path + ".slot", -1)) >= 0) {
                    String materialName = guiConfig.getString(path + ".material", "STONE");
                    String displayName = guiConfig.getString(path + ".display-name", key);
                    List<String> lore = guiConfig.getStringList(path + ".lore");
                    Material material = Material.getMaterial(materialName);
                    if (material == null) {
                        material = Material.STONE;
                    }
                    ItemStack item = new ItemStack(material);
                    ItemMeta meta = item.getItemMeta();
                    meta.setDisplayName(ColorUtil.colorize(displayName));
                    List<String> coloredLore = new ArrayList<>();
                    for (String line : lore) {
                        coloredLore.add(ColorUtil.colorize(line));
                    }
                    meta.setLore(coloredLore);
                    item.setItemMeta(meta);
                    inv.setItem(slot, item);
                }
            }
        }
        player.openInventory(inv);
    }

    public void openLeaderboard(Player player, String leaderboardType, int page) {
        int totalPlayers;
        List<?> entries;
        UUID uuid;
        String name;
        long value;
        int rank;
        DataManager.StatType statType = DataManager.StatType.fromGuiName(leaderboardType);
        FileConfiguration guiConfig = this.plugin.getConfigManager().getLeaderboardGUI(leaderboardType);
        if (guiConfig == null) {
            return;
        }
        String playerRange = guiConfig.getString("players", "0-44");
        int playersPerPage = getPlayersPerPage(playerRange);
        if (statType == DataManager.StatType.MONEY) {
            totalPlayers = this.plugin.getDataManager().getTotalPlayersWithMoney();
            List<DataManager.MoneyEntry> moneyEntries = this.plugin.getDataManager().getTopPlayers(playersPerPage, page);
            entries = moneyEntries;
        } else {
            totalPlayers = this.plugin.getDataManager().getTotalPlayersWithStat(statType);
            entries = this.plugin.getDataManager().getLeaderboard(statType, page, playersPerPage);
        }
        int totalPages = Math.max(1, (int) Math.ceil(((double) totalPlayers) / ((double) playersPerPage)));
        if (page < 1) {
            page = 1;
        }
        if (page > totalPages) {
            page = totalPages;
        }
        String title = guiConfig.getString("title", "&8ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅꜱ (Page %page%/%total%)");
        String title2 = ColorUtil.colorize(title.replace("%page%", String.valueOf(page)).replace("%total%", String.valueOf(totalPages)).replace("Leaderboard", "ᴍᴏѕᴛ"));
        int rows = guiConfig.getInt("row", 6);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title2);
        Map<Integer, UUID> slotToUUID = new HashMap<>();
        List<Integer> playerSlots = getPlayerSlots(playerRange);
        String valueFormat = getValueFormat(statType);
        for (int i = 0; i < playerSlots.size() && i < entries.size(); i++) {
            int slot = playerSlots.get(i).intValue();
            if (statType == DataManager.StatType.MONEY) {
                DataManager.MoneyEntry entry = (DataManager.MoneyEntry) entries.get(i);
                uuid = entry.uuid;
                name = entry.name;
                value = (long) entry.balance;
                rank = entry.rank;
            } else {
                DataManager.StatEntry entry2 = (DataManager.StatEntry) entries.get(i);
                uuid = entry2.uuid;
                name = entry2.name;
                value = entry2.value;
                rank = entry2.rank;
            }
            ItemStack head = this.plugin.getHeadDatabaseManager().getPlayerHead(uuid, name);
            SkullMeta meta = head.getItemMeta();
            String displayNameFormat = guiConfig.getString("items.player.display-name", "&#04fc84%name%");
            String displayName = displayNameFormat.replace("%name%", name).replace("%rank%", "#" + rank);
            meta.setDisplayName(ColorUtil.colorize(displayName));
            List<String> loreFormat = guiConfig.getStringList("items.player.lore");
            List<String> lore = new ArrayList<>();
            for (String line : loreFormat) {
                lore.add(ColorUtil.colorize(line.replace("%name%", name).replace("%value%", formatValue(value, valueFormat)).replace("%rank%", "#" + rank)));
            }
            meta.setLore(lore);
            head.setItemMeta(meta);
            inv.setItem(slot, head);
            slotToUUID.put(Integer.valueOf(slot), uuid);
        }
        addSelfItem(player, inv, guiConfig, statType, slotToUUID, valueFormat);
        addButton(inv, guiConfig, "back");
        addButton(inv, guiConfig, "refresh");
        addButton(inv, guiConfig, "search");
        addButton(inv, guiConfig, "next");
        this.openInventories.put(player.getUniqueId(), slotToUUID);
        player.openInventory(inv);
    }

    private void addButton(Inventory inv, FileConfiguration guiConfig, String buttonKey) {
        int slot;
        String path = "items." + buttonKey;
        if (guiConfig.contains(path) && (slot = guiConfig.getInt(path + ".slot", -1)) >= 0) {
            String materialName = guiConfig.getString(path + ".material", "STONE");
            String displayName = guiConfig.getString(path + ".display-name", buttonKey);
            List<String> lore = guiConfig.getStringList(path + ".lore");
            Material material = Material.getMaterial(materialName);
            if (material == null) {
                material = Material.STONE;
            }
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ColorUtil.colorize(displayName));
            List<String> coloredLore = new ArrayList<>();
            for (String line : lore) {
                coloredLore.add(ColorUtil.colorize(line));
            }
            meta.setLore(coloredLore);
            item.setItemMeta(meta);
            inv.setItem(slot, item);
        }
    }

    private void addSelfItem(Player player, Inventory inv, FileConfiguration guiConfig, DataManager.StatType statType, Map<Integer, UUID> slotToUUID, String valueFormat) {
        long playerValue;
        int playerRank;
        int selfSlot = guiConfig.getInt("items.self.slot", 48);
        if (statType == DataManager.StatType.MONEY) {
            playerValue = (long) this.plugin.getDataManager().getBalance(player);
            playerRank = this.plugin.getDataManager().getPlayerRank(player);
        } else {
            playerValue = this.plugin.getDataManager().getStat(player, statType);
            playerRank = this.plugin.getDataManager().getPlayerRank(player, statType);
        }
        ItemStack selfHead = this.plugin.getHeadDatabaseManager().getPlayerHead(player.getUniqueId(), player.getName());
        SkullMeta selfMeta = selfHead.getItemMeta();
        String displayNameFormat = guiConfig.getString("items.self.display-name", "&#04fc84%name%");
        String displayName = displayNameFormat.replace("%name%", player.getName());
        selfMeta.setDisplayName(ColorUtil.colorize(displayName));
        List<String> loreFormat = guiConfig.getStringList("items.self.lore");
        List<String> lore = new ArrayList<>();
        for (String line : loreFormat) {
            lore.add(ColorUtil.colorize(line.replace("%name%", player.getName()).replace("%value%", formatValue(playerValue, valueFormat)).replace("%rank%", "#" + String.valueOf(playerRank > 0 ? Integer.valueOf(playerRank) : "?"))));
        }
        selfMeta.setLore(lore);
        selfHead.setItemMeta(selfMeta);
        inv.setItem(selfSlot, selfHead);
        slotToUUID.put(Integer.valueOf(selfSlot), player.getUniqueId());
    }

    private List<Integer> getPlayerSlots(String range) {
        List<Integer> slots = new ArrayList<>();
        if (range.contains("-")) {
            String[] parts = range.split("-");
            try {
                int start = Integer.parseInt(parts[0]);
                int end = Integer.parseInt(parts[1]);
                for (int i = start; i <= end; i++) {
                    slots.add(Integer.valueOf(i));
                }
            } catch (NumberFormatException e) {
                for (int i2 = 0; i2 < 45; i2++) {
                    slots.add(Integer.valueOf(i2));
                }
            }
        } else {
            for (int i3 = 0; i3 < 45; i3++) {
                slots.add(Integer.valueOf(i3));
            }
        }
        return slots;
    }

    private int getPlayersPerPage(String range) {
        return getPlayerSlots(range).size();
    }

    private String getValueFormat(DataManager.StatType type) {
        switch (type) {
            case PLAYTIME:
                return "time";
            case MONEY:
                return "money";
            default:
                return "number";
        }
    }

    private String formatValue(long value, String format) {
        if (format.equals("time")) {
            long seconds = value / 1000;
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            long secs = seconds % 60;
            if (hours > 0) {
                return String.format("%dh %dm", Long.valueOf(hours), Long.valueOf(minutes));
            }
            if (minutes > 0) {
                return String.format("%dm %ds", Long.valueOf(minutes), Long.valueOf(secs));
            }
            return String.format("%ds", Long.valueOf(secs));
        }
        if (format.equals("money")) {
            return this.plugin.getConfigManager().formatMoney(value);
        }
        return String.format("%,d", Long.valueOf(value));
    }

    public void openSearchResults(Player player, String leaderboardType, String searchTerm, int page) {
        List<?> results;
        UUID uuid;
        String name;
        long value;
        int rank;
        DataManager.StatType statType = DataManager.StatType.fromGuiName(leaderboardType);
        FileConfiguration guiConfig = this.plugin.getConfigManager().getLeaderboardGUI(leaderboardType);
        if (guiConfig == null) {
            return;
        }
        if (statType == DataManager.StatType.MONEY) {
            List<DataManager.MoneyEntry> moneyResults = this.plugin.getDataManager().searchPlayers(searchTerm);
            results = moneyResults;
        } else {
            results = this.plugin.getDataManager().searchPlayers(statType, searchTerm);
        }
        if (results.isEmpty()) {
            openLeaderboard(player, leaderboardType, 1);
            return;
        }
        String title = guiConfig.getString("title", "&8ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅꜱ (Page %page%/%total%)");
        String title2 = ColorUtil.colorize(title.replace("%page%", "1").replace("%total%", "1").replace("Leaderboard", "ᴍᴏѕᴛ"));
        int rows = guiConfig.getInt("row", 6);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title2);
        Map<Integer, UUID> slotToUUID = new HashMap<>();
        List<Integer> playerSlots = getPlayerSlots(guiConfig.getString("players", "0-44"));
        String valueFormat = getValueFormat(statType);
        int maxResults = Math.min(results.size(), playerSlots.size());
        for (int i = 0; i < maxResults; i++) {
            int slot = playerSlots.get(i).intValue();
            if (statType == DataManager.StatType.MONEY) {
                DataManager.MoneyEntry entry = (DataManager.MoneyEntry) results.get(i);
                uuid = entry.uuid;
                name = entry.name;
                value = (long) entry.balance;
                rank = entry.rank;
            } else {
                DataManager.StatEntry entry2 = (DataManager.StatEntry) results.get(i);
                uuid = entry2.uuid;
                name = entry2.name;
                value = entry2.value;
                rank = entry2.rank;
            }
            ItemStack head = this.plugin.getHeadDatabaseManager().getPlayerHead(uuid, name);
            SkullMeta meta = head.getItemMeta();
            String displayNameFormat = guiConfig.getString("items.player.display-name", "&#04fc84%name%");
            String displayName = displayNameFormat.replace("%name%", name).replace("%rank%", "#" + rank);
            meta.setDisplayName(ColorUtil.colorize(displayName));
            List<String> loreFormat = guiConfig.getStringList("items.player.lore");
            List<String> lore = new ArrayList<>();
            for (String line : loreFormat) {
                lore.add(ColorUtil.colorize(line.replace("%name%", name).replace("%value%", formatValue(value, valueFormat)).replace("%rank%", "#" + rank)));
            }
            meta.setLore(lore);
            head.setItemMeta(meta);
            inv.setItem(slot, head);
            slotToUUID.put(Integer.valueOf(slot), uuid);
        }
        addSelfItem(player, inv, guiConfig, statType, slotToUUID, valueFormat);
        addButton(inv, guiConfig, "back");
        addButton(inv, guiConfig, "refresh");
        addButton(inv, guiConfig, "search");
        this.openInventories.put(player.getUniqueId(), slotToUUID);
        player.openInventory(inv);
    }

    public Map<Integer, UUID> getOpenInventory(UUID playerId) {
        return this.openInventories.get(playerId);
    }

    public void removeOpenInventory(UUID playerId) {
        this.openInventories.remove(playerId);
    }

    public String getPlayerCommand(FileConfiguration guiConfig) {
        return guiConfig.getString("items.player.command", "stats %player%");
    }
}
