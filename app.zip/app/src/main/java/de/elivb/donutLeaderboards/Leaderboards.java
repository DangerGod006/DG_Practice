package de.elivb.donutLeaderboards;

import de.elivb.donutLeaderboards.commands.LeaderboardCommand;
import de.elivb.donutLeaderboards.gui.LeaderboardGUI;
import de.elivb.donutLeaderboards.listeners.GUIListener;
import de.elivb.donutLeaderboards.listeners.StatListener;
import de.elivb.donutLeaderboards.managers.ConfigManager;
import de.elivb.donutLeaderboards.managers.DataManager;
import de.elivb.donutLeaderboards.managers.GUIProvider;
import de.elivb.donutLeaderboards.managers.HeadDatabaseManager;
import de.elivb.donutLeaderboards.managers.LangManager;
import de.elivb.donutLeaderboards.managers.SearchManager;
import de.elivb.donutLeaderboards.managers.SignManager;
import de.elivb.donutLeaderboards.managers.SoundManager;
import java.io.File;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/Leaderboards.class */
public final class Leaderboards extends JavaPlugin {
    private static Leaderboards instance;
    private ConfigManager configManager;
    private LangManager langManager;
    private DataManager dataManager;
    private HeadDatabaseManager headDatabaseManager;
    private SearchManager searchManager;
    private SoundManager soundManager;
    private LeaderboardGUI leaderboardGUI;
    private GUIListener guiListener;
    private SignManager signManager;
    private GUIProvider guiProvider;
    private StatListener statListener;
    private LicenseManager licenseManager;

    public void onEnable() {
        instance = this;
        this.licenseManager = new LicenseManager(this);
        if (!this.licenseManager.validateLicenseOnStartup()) {
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        saveDefaultConfig();
        saveResourceIfNotExists("lang.yml");
        saveResourceIfNotExists("gui/main-gui.yml");
        saveResourceIfNotExists("gui/blocks-broken.yml");
        saveResourceIfNotExists("gui/blocks-placed.yml");
        saveResourceIfNotExists("gui/deaths.yml");
        saveResourceIfNotExists("gui/mobs-killed.yml");
        saveResourceIfNotExists("gui/money.yml");
        saveResourceIfNotExists("gui/player-kills.yml");
        saveResourceIfNotExists("gui/playtime.yml");
        this.configManager = new ConfigManager(this);
        this.langManager = new LangManager(this);
        this.soundManager = new SoundManager(this);
        this.dataManager = new DataManager(this);
        this.headDatabaseManager = new HeadDatabaseManager(this);
        this.searchManager = new SearchManager(this);
        this.signManager = new SignManager(this);
        this.guiProvider = new GUIProvider(this);
        this.langManager.loadMessages();
        this.dataManager.initializeDatabase();
        this.headDatabaseManager.initializeDatabase();
        this.leaderboardGUI = new LeaderboardGUI(this);
        LeaderboardCommand leaderboardCommand = new LeaderboardCommand(this);
        if (getCommand("leaderboards") != null) {
            getCommand("leaderboards").setExecutor(leaderboardCommand);
            getCommand("leaderboards").setTabCompleter(leaderboardCommand);
        }
        this.guiListener = new GUIListener(this);
        getServer().getPluginManager().registerEvents(this.guiListener, this);
        this.statListener = new StatListener(this);
        getServer().getPluginManager().registerEvents(this.statListener, this);
    }

    private void saveResourceIfNotExists(String path) {
        File file = new File(getDataFolder(), path);
        if (!file.exists()) {
            saveResource(path, false);
        }
    }

    public LicenseManager getLicenseManager() {
        return this.licenseManager;
    }

    public void onDisable() {
        if (this.statListener != null) {
            this.statListener.stopAutoUpdater();
        }
        if (this.dataManager != null) {
            this.dataManager.shutdown();
            this.dataManager.closeDatabase();
        }
        if (this.headDatabaseManager != null) {
            this.headDatabaseManager.closeDatabase();
        }
        if (this.searchManager != null) {
            this.searchManager.clearAll();
        }
    }

    public void reload() {
        this.configManager.reloadConfigs();
        this.langManager.reloadMessages();
        this.dataManager.clearCache();
        this.guiProvider.clearCache();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission("leaderboards.reload")) {
                this.soundManager.playSound(player, "reload-sound");
            }
        }
    }

    public void runTask(Player player, Runnable runnable) {
        if (isFolia()) {
            player.getScheduler().run(this, scheduledTask -> {
                runnable.run();
            }, (Runnable) null);
        } else {
            Bukkit.getScheduler().runTask(this, runnable);
        }
    }

    public void runTaskLater(Player player, Runnable runnable, long delay) {
        if (isFolia()) {
            player.getScheduler().runDelayed(this, scheduledTask -> {
                runnable.run();
            }, (Runnable) null, delay);
        } else {
            Bukkit.getScheduler().runTaskLater(this, runnable, delay);
        }
    }

    public boolean isFolia() {
        try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static Leaderboards getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public LangManager getLangManager() {
        return this.langManager;
    }

    public DataManager getDataManager() {
        return this.dataManager;
    }

    public HeadDatabaseManager getHeadDatabaseManager() {
        return this.headDatabaseManager;
    }

    public SearchManager getSearchManager() {
        return this.searchManager;
    }

    public SoundManager getSoundManager() {
        return this.soundManager;
    }

    public LeaderboardGUI getLeaderboardGUI() {
        return this.leaderboardGUI;
    }

    public GUIListener getGUIListener() {
        return this.guiListener;
    }

    public SignManager getSignManager() {
        return this.signManager;
    }

    public GUIProvider getGUIProvider() {
        return this.guiProvider;
    }

    public StatListener getStatListener() {
        return this.statListener;
    }
}
