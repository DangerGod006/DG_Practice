package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/GUIProvider.class */
public class GUIProvider {
    private final Leaderboards plugin;
    private final ConcurrentHashMap<String, FileConfiguration> guiCache = new ConcurrentHashMap<>();
    private final long CACHE_DURATION = 60000;
    private final ConcurrentHashMap<String, Long> cacheTime = new ConcurrentHashMap<>();

    public GUIProvider(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public FileConfiguration getGUI(String name) {
        Long time;
        if (this.guiCache.containsKey(name) && (time = this.cacheTime.get(name)) != null && System.currentTimeMillis() - time.longValue() < 60000) {
            return this.guiCache.get(name);
        }
        File file = new File(this.plugin.getDataFolder(), "gui/" + name + ".yml");
        if (!file.exists()) {
            this.plugin.saveResource("gui/" + name + ".yml", false);
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        this.guiCache.put(name, config);
        this.cacheTime.put(name, Long.valueOf(System.currentTimeMillis()));
        return config;
    }

    public void clearCache() {
        this.guiCache.clear();
        this.cacheTime.clear();
    }
}
