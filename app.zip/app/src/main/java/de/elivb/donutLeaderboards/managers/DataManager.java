package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/DataManager.class */
public class DataManager {
    private final Leaderboards plugin;
    private Connection connection;
    private Economy economy;
    private List<MoneyEntry> cachedFullTopList = null;
    private long lastFullUpdate = 0;
    private final long FULL_UPDATE_INTERVAL = 30000;
    private final Map<UUID, Double> balanceCache = new ConcurrentHashMap();
    private final Map<UUID, Long> balanceCacheTime = new ConcurrentHashMap();
    private final long BALANCE_CACHE_TIME = 5000;
    private final Map<UUID, Integer> rankCache = new ConcurrentHashMap();
    private int cachedTotalPlayers = -1;
    private long lastTotalUpdate = 0;
    private ScheduledExecutorService scheduler;
    private ScheduledExecutorService dbScheduler;

    /* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/DataManager$StatType.class */
    public enum StatType {
        BLOCKS_BROKEN("blocks_broken", "blocks-broken"),
        BLOCKS_PLACED("blocks_placed", "blocks-placed"),
        DEATHS("deaths", "deaths"),
        MOBS_KILLED("mobs_killed", "mobs-killed"),
        MONEY("money", "money"),
        PLAYER_KILLS("player_kills", "player-kills"),
        PLAYTIME("playtime", "playtime");

        private final String dbColumn;
        private final String guiName;

        StatType(String dbColumn, String guiName) {
            this.dbColumn = dbColumn;
            this.guiName = guiName;
        }

        public String getDbColumn() {
            return this.dbColumn;
        }

        public String getGuiName() {
            return this.guiName;
        }

        public static StatType fromGuiName(String guiName) {
            for (StatType type : values()) {
                if (type.guiName.equals(guiName)) {
                    return type;
                }
            }
            return MONEY;
        }
    }

    public DataManager(Leaderboards plugin) {
        this.plugin = plugin;
        setupEconomy();
        startAsyncUpdater();
    }

    private void setupEconomy() {
        RegisteredServiceProvider<Economy> rsp;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null && (rsp = Bukkit.getServicesManager().getRegistration(Economy.class)) != null) {
            this.economy = (Economy) rsp.getProvider();
        }
    }

    private void startAsyncUpdater() {
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.scheduler.scheduleAtFixedRate(() -> {
            try {
                updateFullTopListAsync();
            } catch (Exception e) {
            }
        }, 1L, 30L, TimeUnit.SECONDS);
    }

    private void updateFullTopListAsync() {
        if (this.economy == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastFullUpdate < 30000) {
            return;
        }
        try {
            List<MoneyEntry> allWithMoney = new ArrayList<>();
            OfflinePlayer[] players = Bukkit.getOfflinePlayers();
            for (OfflinePlayer player : players) {
                String name = player.getName();
                if (name != null && !name.isEmpty()) {
                    double balance = getBalanceDirect(player);
                    if (balance > 0.0d) {
                        allWithMoney.add(new MoneyEntry(player.getUniqueId(), name, balance));
                    }
                }
            }
            allWithMoney.sort((a, b) -> {
                return Double.compare(b.balance, a.balance);
            });
            for (int i = 0; i < allWithMoney.size(); i++) {
                MoneyEntry entry = allWithMoney.get(i);
                entry.rank = i + 1;
                this.rankCache.put(entry.uuid, Integer.valueOf(entry.rank));
            }
            this.cachedFullTopList = allWithMoney;
            this.cachedTotalPlayers = allWithMoney.size();
            this.lastFullUpdate = now;
            this.lastTotalUpdate = now;
        } catch (Exception e) {
        }
    }

    private double getBalanceDirect(OfflinePlayer player) {
        if (this.economy != null && this.economy.isEnabled()) {
            try {
                return this.economy.getBalance(player);
            } catch (Exception e) {
                return 0.0d;
            }
        }
        return 0.0d;
    }

    private double getBalanceWithCache(OfflinePlayer player) {
        Long cacheTime;
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        if (this.balanceCache.containsKey(uuid) && (cacheTime = this.balanceCacheTime.get(uuid)) != null && now - cacheTime.longValue() < 5000) {
            return this.balanceCache.get(uuid).doubleValue();
        }
        double balance = getBalanceDirect(player);
        this.balanceCache.put(uuid, Double.valueOf(balance));
        this.balanceCacheTime.put(uuid, Long.valueOf(now));
        return balance;
    }

    public List<MoneyEntry> getTopPlayers(int limit, int page) {
        if (this.cachedFullTopList == null) {
            updateFullTopListAsync();
            for (int i = 0; i < 10 && this.cachedFullTopList == null; i++) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                }
            }
            if (this.cachedFullTopList == null) {
                return new ArrayList();
            }
        }
        int start = (page - 1) * limit;
        int end = Math.min(start + limit, this.cachedFullTopList.size());
        if (start >= this.cachedFullTopList.size()) {
            return new ArrayList();
        }
        return new ArrayList(this.cachedFullTopList.subList(start, end));
    }

    public List<MoneyEntry> getAllPlayers() {
        if (this.cachedFullTopList == null) {
            updateFullTopListAsync();
            for (int i = 0; i < 10 && this.cachedFullTopList == null; i++) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                }
            }
            if (this.cachedFullTopList == null) {
                return new ArrayList();
            }
        }
        return new ArrayList(this.cachedFullTopList);
    }

    public List<MoneyEntry> searchPlayers(String searchTerm) {
        if (this.cachedFullTopList == null) {
            updateFullTopListAsync();
            for (int i = 0; i < 10 && this.cachedFullTopList == null; i++) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                }
            }
        }
        if (this.cachedFullTopList == null) {
            return new ArrayList();
        }
        List<MoneyEntry> results = new ArrayList<>();
        String lowerSearch = searchTerm.toLowerCase();
        for (MoneyEntry entry : this.cachedFullTopList) {
            if (entry.name.toLowerCase().contains(lowerSearch)) {
                results.add(entry);
            }
        }
        return results;
    }

    public int getTotalPlayersWithMoney() {
        if (this.cachedTotalPlayers == -1 && this.cachedFullTopList != null) {
            this.cachedTotalPlayers = this.cachedFullTopList.size();
        }
        if (this.cachedTotalPlayers > 0) {
            return this.cachedTotalPlayers;
        }
        return 0;
    }

    public int getPlayerRank(OfflinePlayer player) {
        UUID uuid = player.getUniqueId();
        if (this.rankCache.containsKey(uuid)) {
            return this.rankCache.get(uuid).intValue();
        }
        if (this.cachedFullTopList != null) {
            for (MoneyEntry entry : this.cachedFullTopList) {
                if (entry.uuid.equals(uuid)) {
                    this.rankCache.put(uuid, Integer.valueOf(entry.rank));
                    return entry.rank;
                }
            }
            return -1;
        }
        return -1;
    }

    public double getBalance(OfflinePlayer player) {
        return getBalanceWithCache(player);
    }

    public void clearCache() {
        this.cachedFullTopList = null;
        this.rankCache.clear();
        this.balanceCache.clear();
        this.balanceCacheTime.clear();
        this.cachedTotalPlayers = -1;
        this.lastFullUpdate = 0L;
        this.lastTotalUpdate = 0L;
        updateFullTopListAsync();
    }

    public void initializeDatabase() {
        try {
            File dbFile = new File(this.plugin.getDataFolder(), "stats.db");
            if (!dbFile.exists()) {
                dbFile.createNewFile();
            }
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            createTables();
        } catch (Exception e) {
        }
    }

    private void createTables() throws SQLException {
        Statement stmt = this.connection.createStatement();
        try {
            stmt.execute("CREATE TABLE IF NOT EXISTS player_stats (uuid VARCHAR(36) PRIMARY KEY,name VARCHAR(16),blocks_broken BIGINT DEFAULT 0,blocks_placed BIGINT DEFAULT 0,deaths BIGINT DEFAULT 0,mobs_killed BIGINT DEFAULT 0,player_kills BIGINT DEFAULT 0,playtime BIGINT DEFAULT 0,last_updated BIGINT)");
            if (stmt != null) {
                stmt.close();
            }
        } catch (Throwable th) {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public void updateStat(Player player, StatType type, long amount) {
        UUID uuid = player.getUniqueId();
        String name = player.getName();
        if (this.dbScheduler == null) {
            this.dbScheduler = Executors.newSingleThreadScheduledExecutor();
        }
        this.dbScheduler.execute(() -> {
            String sql = "INSERT INTO player_stats (uuid, name, " + type.getDbColumn() + ", last_updated) VALUES (?, ?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET " + type.getDbColumn() + " = " + type.getDbColumn() + " + ?, name = excluded.name, last_updated = excluded.last_updated";
            try {
                PreparedStatement pstmt = this.connection.prepareStatement(sql);
                try {
                    pstmt.setString(1, uuid.toString());
                    pstmt.setString(2, name);
                    pstmt.setLong(3, amount);
                    pstmt.setLong(4, System.currentTimeMillis());
                    pstmt.setLong(5, amount);
                    pstmt.executeUpdate();
                    if (pstmt != null) {
                        pstmt.close();
                    }
                } finally {
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public long getStat(OfflinePlayer player, StatType type) {
        UUID uuid = player.getUniqueId();
        String sql = "SELECT " + type.getDbColumn() + " FROM player_stats WHERE uuid = ?";
        try {
            PreparedStatement pstmt = this.connection.prepareStatement(sql);
            try {
                pstmt.setString(1, uuid.toString());
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    long j = rs.getLong(1);
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    return j;
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                return 0L;
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0L;
        }
        e.printStackTrace();
        return 0L;
    }

    public List<StatEntry> getLeaderboard(StatType type, int page, int playersPerPage) {
        if (type == StatType.MONEY) {
            List<MoneyEntry> moneyEntries = getTopPlayers(playersPerPage, page);
            List<StatEntry> entries = new ArrayList<>();
            for (MoneyEntry me : moneyEntries) {
                entries.add(new StatEntry(me.uuid, me.name, (long) me.balance, me.rank));
            }
            return entries;
        }
        int offset = (page - 1) * playersPerPage;
        String sql = "SELECT uuid, name, " + type.getDbColumn() + " FROM player_stats WHERE " + type.getDbColumn() + " > 0 ORDER BY " + type.getDbColumn() + " DESC LIMIT ? OFFSET ?";
        List<StatEntry> entries2 = new ArrayList<>();
        try {
            PreparedStatement pstmt = this.connection.prepareStatement(sql);
            try {
                pstmt.setInt(1, playersPerPage);
                pstmt.setInt(2, offset);
                ResultSet rs = pstmt.executeQuery();
                int rank = offset + 1;
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString("uuid"));
                    String name = rs.getString("name");
                    long value = rs.getLong(type.getDbColumn());
                    int i = rank;
                    rank++;
                    entries2.add(new StatEntry(uuid, name, value, i));
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entries2;
    }

    public int getTotalPlayersWithStat(StatType type) {
        if (type == StatType.MONEY) {
            return getTotalPlayersWithMoney();
        }
        String sql = "SELECT COUNT(*) FROM player_stats WHERE " + type.getDbColumn() + " > 0";
        try {
            Statement stmt = this.connection.createStatement();
            try {
                ResultSet rs = stmt.executeQuery(sql);
                try {
                    if (!rs.next()) {
                        if (rs != null) {
                            rs.close();
                        }
                        if (stmt != null) {
                            stmt.close();
                        }
                        return 0;
                    }
                    int i = rs.getInt(1);
                    if (rs != null) {
                        rs.close();
                    }
                    if (stmt != null) {
                        stmt.close();
                    }
                    return i;
                } catch (Throwable th) {
                    if (rs != null) {
                        try {
                            rs.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getPlayerRank(OfflinePlayer player, StatType type) {
        if (type == StatType.MONEY) {
            return getPlayerRank(player);
        }
        long playerValue = getStat(player, type);
        if (playerValue <= 0) {
            return -1;
        }
        String sql = "SELECT COUNT(*) + 1 FROM player_stats WHERE " + type.getDbColumn() + " > ?";
        try {
            PreparedStatement pstmt = this.connection.prepareStatement(sql);
            try {
                pstmt.setLong(1, playerValue);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    int i = rs.getInt(1);
                    if (pstmt != null) {
                        pstmt.close();
                    }
                    return i;
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                return -1;
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        e.printStackTrace();
        return -1;
    }

    public List<StatEntry> searchPlayers(StatType type, String searchTerm) {
        if (type == StatType.MONEY) {
            List<MoneyEntry> moneyResults = searchPlayers(searchTerm);
            List<StatEntry> results = new ArrayList<>();
            for (MoneyEntry me : moneyResults) {
                results.add(new StatEntry(me.uuid, me.name, (long) me.balance, me.rank));
            }
            return results;
        }
        String sql = "SELECT uuid, name, " + type.getDbColumn() + " FROM player_stats WHERE name LIKE ? AND " + type.getDbColumn() + " > 0 ORDER BY " + type.getDbColumn() + " DESC LIMIT 100";
        List<StatEntry> results2 = new ArrayList<>();
        try {
            PreparedStatement pstmt = this.connection.prepareStatement(sql);
            try {
                pstmt.setString(1, "%" + searchTerm + "%");
                ResultSet rs = pstmt.executeQuery();
                int rank = 1;
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString("uuid"));
                    String name = rs.getString("name");
                    long value = rs.getLong(type.getDbColumn());
                    int i = rank;
                    rank++;
                    results2.add(new StatEntry(uuid, name, value, i));
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } finally {
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return results2;
    }

    public void shutdown() {
        if (this.scheduler != null && !this.scheduler.isShutdown()) {
            this.scheduler.shutdown();
        }
        if (this.dbScheduler != null && !this.dbScheduler.isShutdown()) {
            this.dbScheduler.shutdown();
        }
        closeDatabase();
    }

    public void closeDatabase() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/DataManager$StatEntry.class */
    public static class StatEntry {
        public final UUID uuid;
        public final String name;
        public long value;
        public int rank;

        public StatEntry(UUID uuid, String name, long value, int rank) {
            this.uuid = uuid;
            this.name = name;
            this.value = value;
            this.rank = rank;
        }
    }

    /* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/DataManager$MoneyEntry.class */
    public static class MoneyEntry {
        public final UUID uuid;
        public final String name;
        public final double balance;
        public int rank;

        public MoneyEntry(UUID uuid, String name, double balance) {
            this.uuid = uuid;
            this.name = name;
            this.balance = balance;
        }
    }
}
