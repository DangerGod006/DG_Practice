package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/SoundManager.class */
public class SoundManager {
    private final Leaderboards plugin;

    public SoundManager(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public void playSound(Player player, String soundType) {
        String soundName;
        switch (soundType) {
            case "click-sound":
                soundName = this.plugin.getConfigManager().getClickSound();
                break;
            case "reload-sound":
                soundName = this.plugin.getConfigManager().getReloadSound();
                break;
            default:
                soundName = soundType;
                break;
        }
        Sound sound = getSound(soundName);
        if (sound != null) {
            player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
        }
    }

    private Sound getSound(String soundName) {
        try {
            NamespacedKey key = NamespacedKey.minecraft(soundName.toLowerCase());
            Sound sound = Registry.SOUNDS.get(key);
            if (sound != null) {
                return sound;
            }
        } catch (Exception e) {
        }
        try {
            switch (soundName.toUpperCase()) {
                case "UI_BUTTON_CLICK":
                    return getUISound();
                case "ENTITY_PLAYER_LEVELUP":
                    return getLevelUpSound();
                case "BLOCK_NOTE_BLOCK_PLING":
                    return getPlingSound();
                default:
                    NamespacedKey key2 = NamespacedKey.minecraft(soundName.toLowerCase().replace("_", ""));
                    Sound sound2 = Registry.SOUNDS.get(key2);
                    if (sound2 != null) {
                        return sound2;
                    }
                    return null;
            }
        } catch (Exception e2) {
            return null;
        }
    }

    private Sound getUISound() {
        Sound[] possibleSounds = {getSoundByName("ui.button.click"), getSoundByName("block.note_block.pling"), getSoundByName("block.wooden_button.click_on")};
        for (Sound sound : possibleSounds) {
            if (sound != null) {
                return sound;
            }
        }
        return null;
    }

    private Sound getLevelUpSound() {
        Sound[] possibleSounds = {getSoundByName("entity.player.levelup"), getSoundByName("entity.experience_orb.pickup")};
        for (Sound sound : possibleSounds) {
            if (sound != null) {
                return sound;
            }
        }
        return null;
    }

    private Sound getPlingSound() {
        return getSoundByName("block.note_block.pling");
    }

    private Sound getSoundByName(String name) {
        try {
            NamespacedKey key = NamespacedKey.minecraft(name);
            return Registry.SOUNDS.get(key);
        } catch (Exception e) {
            return null;
        }
    }
}
