package de.elivb.donutLeaderboards.listeners;

import de.elivb.donutLeaderboards.Leaderboards;
import de.elivb.donutLeaderboards.managers.DataManager;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.RegisteredServiceProvider;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/listeners/StatListener.class */
public class StatListener implements Listener {
    private final Leaderboards plugin;
    private final Map<UUID, Long> playtimeStart = new ConcurrentHashMap();
    private final Map<UUID, Long> lastPlaytimeSave = new ConcurrentHashMap();
    private Economy economy;
    private ScheduledExecutorService scheduler;

    public StatListener(Leaderboards plugin) {
        this.plugin = plugin;
        setupEconomy();
        startAutoUpdater();
    }

    private void setupEconomy() {
        RegisteredServiceProvider<Economy> rsp;
        if (Bukkit.getPluginManager().getPlugin("Vault") != null && (rsp = Bukkit.getServicesManager().getRegistration(Economy.class)) != null) {
            this.economy = (Economy) rsp.getProvider();
        }
    }

    private void startAutoUpdater() {
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.scheduler.scheduleAtFixedRate(() -> {
            try {
                updateAllPlaytime();
            } catch (Exception e) {
            }
        }, 30L, 30L, TimeUnit.SECONDS);
    }

    private void updateAllPlaytime() {
        long diff;
        Player player;
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : this.playtimeStart.entrySet()) {
            UUID uuid = entry.getKey();
            long startTime = entry.getValue().longValue();
            long totalPlaytime = now - startTime;
            Long lastSave = this.lastPlaytimeSave.get(uuid);
            if (lastSave == null) {
                diff = totalPlaytime;
            } else {
                diff = totalPlaytime - lastSave.longValue();
            }
            if (diff > 0 && (player = Bukkit.getPlayer(uuid)) != null && player.isOnline()) {
                this.plugin.getDataManager().updateStat(player, DataManager.StatType.PLAYTIME, diff);
                this.lastPlaytimeSave.put(uuid, Long.valueOf(totalPlaytime));
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled()) {
            return;
        }
        Player player = event.getPlayer();
        this.plugin.getDataManager().updateStat(player, DataManager.StatType.BLOCKS_BROKEN, 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (event.isCancelled()) {
            return;
        }
        Player player = event.getPlayer();
        this.plugin.getDataManager().updateStat(player, DataManager.StatType.BLOCKS_PLACED, 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        this.plugin.getDataManager().updateStat(player, DataManager.StatType.DEATHS, 1L);
        if (player.getKiller() != null) {
            Player killer = player.getKiller();
            this.plugin.getDataManager().updateStat(killer, DataManager.StatType.PLAYER_KILLS, 1L);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null && !(event.getEntity() instanceof Player)) {
            this.plugin.getDataManager().updateStat(killer, DataManager.StatType.MOBS_KILLED, 1L);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        this.playtimeStart.put(uuid, Long.valueOf(now));
        this.lastPlaytimeSave.put(uuid, 0L);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Long startTime = this.playtimeStart.remove(uuid);
        if (startTime != null) {
            long totalPlaytime = System.currentTimeMillis() - startTime.longValue();
            Long lastSave = this.lastPlaytimeSave.get(uuid);
            long finalDiff = lastSave == null ? totalPlaytime : totalPlaytime - lastSave.longValue();
            if (finalDiff > 0) {
                this.plugin.getDataManager().updateStat(player, DataManager.StatType.PLAYTIME, finalDiff);
            }
        }
        this.lastPlaytimeSave.remove(uuid);
    }

    public void stopAutoUpdater() {
        if (this.scheduler != null && !this.scheduler.isShutdown()) {
            this.scheduler.shutdown();
        }
    }
}
