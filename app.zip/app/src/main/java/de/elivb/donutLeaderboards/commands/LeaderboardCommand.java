package de.elivb.donutLeaderboards.commands;

import de.elivb.donutLeaderboards.Leaderboards;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/commands/LeaderboardCommand.class */
public class LeaderboardCommand implements CommandExecutor, TabCompleter {
    private final Leaderboards plugin;

    public LeaderboardCommand(Leaderboards plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("leaderboards.reload")) {
                sender.sendMessage(this.plugin.getLangManager().getMessage("no-permissions"));
                return true;
            }
            this.plugin.reload();
            this.plugin.getLogger().info("\u001b[96mReloading configuration...\u001b[0m");
            this.plugin.getLogger().info("\u001b[91m╠ Reloaded lang.yml!\u001b[0m");
            this.plugin.getLogger().info("\u001b[91m╠ Reloaded config.yml!\u001b[0m");
            this.plugin.getLogger().info("\u001b[91m╠ Reloaded GUIS!\u001b[0m");
            this.plugin.getLogger().info("\u001b[96m╚ Successful reload!\u001b[0m");
            sender.sendMessage(this.plugin.getLangManager().getMessage("reloaded"));
            return true;
        }
        if (args.length > 0 && !args[0].equalsIgnoreCase("reload")) {
            if (!(sender instanceof Player)) {
                return true;
            }
            Player player = (Player) sender;
            if (!player.hasPermission("leaderboards.use")) {
                player.sendMessage(this.plugin.getLangManager().getMessage("no-permissions"));
                return true;
            }
            String type = args[0].toLowerCase();
            int page = 1;
            if (args.length > 1) {
                try {
                    page = Integer.parseInt(args[1]);
                    if (page < 1) {
                        page = 1;
                    }
                } catch (NumberFormatException e) {
                }
            }
            openLeaderboard(player, type, page);
            return true;
        }
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player2 = (Player) sender;
        if (!player2.hasPermission("leaderboards.use")) {
            player2.sendMessage(this.plugin.getLangManager().getMessage("no-permissions"));
            return true;
        }
        this.plugin.getLeaderboardGUI().openMainMenu(player2);
        return true;
    }

    private void openLeaderboard(Player player, String type, int page) {
        switch (type) {
            case "money":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "money", page);
                break;
            case "deaths":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "deaths", page);
                break;
            case "playtime":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "playtime", page);
                break;
            case "blocks-placed":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "blocks-placed", page);
                break;
            case "blocks-broken":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "blocks-broken", page);
                break;
            case "mobs-killed":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "mobs-killed", page);
                break;
            case "player-kills":
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "player-kills", page);
                break;
            default:
                this.plugin.getLeaderboardGUI().openLeaderboard(player, "money", page);
                break;
        }
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            if (sender.hasPermission("leaderboards.reload")) {
                completions.add("reload");
            }
            if (sender.hasPermission("leaderboards.use")) {
                completions.add("money");
                completions.add("deaths");
                completions.add("playtime");
                completions.add("blocks-placed");
                completions.add("blocks-broken");
                completions.add("mobs-killed");
                completions.add("player-kills");
            }
        }
        return completions;
    }
}
