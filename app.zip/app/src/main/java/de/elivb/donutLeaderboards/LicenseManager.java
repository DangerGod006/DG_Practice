package de.elivb.donutLeaderboards;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.UUID;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/LicenseManager.class */
public class LicenseManager {
    private final JavaPlugin plugin;
    private File licenseFile;
    private FileConfiguration licenseConfig;
    private String serverId;
    private String licenseKey;
    private final String API_URL = "http://154.43.52.66:25010/api/validate";
    private final String PLUGIN_NAME = "DonutLeaderboards";
    private final String PLUGIN_ID = "DonutLeaderboards";
    private boolean licenseValid = false;

    public LicenseManager(JavaPlugin plugin) {
        this.plugin = plugin;
        setupLicenseFile();
        loadServerId();
    }

    private void setupLicenseFile() {
        this.licenseFile = new File(this.plugin.getDataFolder(), "license.yml");
        if (!this.licenseFile.exists()) {
            this.plugin.saveResource("license.yml", false);
        }
        this.licenseConfig = YamlConfiguration.loadConfiguration(this.licenseFile);
    }

    private void loadServerId() {
        if (this.licenseConfig.contains("server-id") && !this.licenseConfig.getString("server-id").isEmpty()) {
            this.serverId = this.licenseConfig.getString("server-id");
            return;
        }
        String serverIp = this.plugin.getServer().getIp();
        String serverPort = String.valueOf(this.plugin.getServer().getPort());
        String serverMotd = this.plugin.getServer().getMotd();
        if (serverIp.isEmpty() || serverIp.equals("0.0.0.0")) {
            serverIp = "localhost";
        }
        String combined = serverIp + ":" + serverPort + ":" + serverMotd.hashCode() + ":" + System.getProperty("user.name", "unknown") + ":" + System.getProperty("user.home", "unknown");
        this.serverId = generateHash(combined);
        this.licenseConfig.set("server-id", this.serverId);
        saveLicenseFile();
    }

    public boolean validateLicenseOnStartup() {
        this.licenseKey = this.licenseConfig.getString("license-key", "");
        if (this.licenseKey.isEmpty() || this.licenseKey.equals("YOUR_KEY_HERE")) {
            this.plugin.getLogger().info("\u001b[31m" + "██╗   ██╗ ██╗    ████████╗ ██╗ ███╗   ███╗  █████╗  ████████╗ ███████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║    ╚══██╔══╝ ██║ ████╗ ████║ ██╔══██╗ ╚══██╔══╝ ██╔═" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║       ██║    ██║ ██╔████╔██║ ███████║    ██║    █████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║       ██║    ██║ ██║╚██╔╝██║ ██╔══██║    ██║    ██╔══╝" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "╚██████╔╝ ███████╗  ██║    ██║ ██║ ╚═╝ ██║ ██║  ██║    ██║    ███████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + " ╚═════╝   ╚══════╝ ╚═╝    ╚═╝ ╚═╝     ╚═╝ ╚═╝  ╚═╝    ╚═╝    ╚══════╝" + "\u001b[0m");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████╗ ████████╗ ██╗   ██╗ ██████╗  ██╗  ██████╗            " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ██╔════╝ ╚══██╔══╝ ██║   ██║ ██╔══██╗ ██║ ██╔═══██╗           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████╗    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ╚════██║    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████║    ██║    ╚██████╔╝ ██████╔╝ ██║ ╚██████╔╝          " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ╚══════╝    ╚═╝     ╚═════╝  ╚═════╝  ╚═╝  ╚═════╝           " + "\u001b[0m");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("\u001b[31m" + "╔══════════════════════════════════════════════════════════════╗");
            this.plugin.getLogger().info("\u001b[31m" + "║                    NO LICENSE KEY FOUND                      ║");
            this.plugin.getLogger().info("\u001b[31m" + "╠══════════════════════════════════════════════════════════════╣");
            String displayedKey = this.licenseKey == null ? "" : this.licenseKey.length() >= 64 ? this.licenseKey.substring(0, 64) + "..." : this.licenseKey;
            this.plugin.getLogger().info("\u001b[31m" + "║ Key: " + displayedKey + "                                           ║");
            this.plugin.getLogger().info("\u001b[31m" + "║ Contact EliVB97 on Discord for a free key                    ║");
            this.plugin.getLogger().info("\u001b[31m" + "╚══════════════════════════════════════════════════════════════╝");
            try {
                this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                    this.plugin.getServer().getPluginManager().disablePlugin(this.plugin);
                }, 600L);
                return false;
            } catch (Exception e) {
                return false;
            }
        }
        try {
            this.licenseValid = validateWithAPI(this.licenseKey, this.serverId);
        } catch (Exception e2) {
            e2.printStackTrace();
            this.licenseValid = false;
        }
        if (!this.licenseValid) {
            this.plugin.getLogger().info("\u001b[31m" + "██╗   ██╗ ██╗    ████████╗ ██╗ ███╗   ███╗  █████╗  ████████╗ ███████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║    ╚══██╔══╝ ██║ ████╗ ████║ ██╔══██╗ ╚══██╔══╝ ██╔═" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║       ██║    ██║ ██╔████╔██║ ███████║    ██║    █████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "██║   ██║ ██║       ██║    ██║ ██║╚██╔╝██║ ██╔══██║    ██║    ██╔══╝" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "╚██████╔╝ ███████╗  ██║    ██║ ██║ ╚═╝ ██║ ██║  ██║    ██║    ███████╗" + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + " ╚═════╝   ╚══════╝ ╚═╝    ╚═╝ ╚═╝     ╚═╝ ╚═╝  ╚═╝    ╚═╝    ╚══════╝" + "\u001b[0m");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████╗ ████████╗ ██╗   ██╗ ██████╗  ██╗  ██████╗            " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ██╔════╝ ╚══██╔══╝ ██║   ██║ ██╔══██╗ ██║ ██╔═══██╗           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████╗    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ╚════██║    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ███████║    ██║    ╚██████╔╝ ██████╔╝ ██║ ╚██████╔╝          " + "\u001b[0m");
            this.plugin.getLogger().info("\u001b[31m" + "          ╚══════╝    ╚═╝     ╚═════╝  ╚═════╝  ╚═╝  ╚═════╝           " + "\u001b[0m");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("");
            this.plugin.getLogger().info("\u001b[31m" + "╔══════════════════════════════════════════════════════════════╗");
            this.plugin.getLogger().info("\u001b[31m" + "║                    LICENSE KEY INVALID                       ║");
            this.plugin.getLogger().info("\u001b[31m" + "╠══════════════════════════════════════════════════════════════╣");
            String displayedKey2 = this.licenseKey == null ? "" : this.licenseKey.length() >= 64 ? this.licenseKey.substring(0, 64) + "..." : this.licenseKey;
            this.plugin.getLogger().info("\u001b[31m" + "║ Key: " + displayedKey2 + "                     ║");
            this.plugin.getLogger().info("\u001b[31m" + "║ Contact EliVB97 on Discord for a free key                    ║");
            this.plugin.getLogger().info("\u001b[31m" + "╚══════════════════════════════════════════════════════════════╝");
            try {
                this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                    this.plugin.getServer().getPluginManager().disablePlugin(this.plugin);
                }, 600L);
                return false;
            } catch (Exception e3) {
                return false;
            }
        }
        this.plugin.getLogger().info("\u001b[32m" + "██╗   ██╗ ██╗    ████████╗ ██╗ ███╗   ███╗  █████╗  ████████╗ ███████╗" + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "██║   ██║ ██║    ╚══██╔══╝ ██║ ████╗ ████║ ██╔══██╗ ╚══██╔══╝ ██╔═" + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "██║   ██║ ██║       ██║    ██║ ██╔████╔██║ ███████║    ██║    █████╗" + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "██║   ██║ ██║       ██║    ██║ ██║╚██╔╝██║ ██╔══██║    ██║    ██╔══╝" + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "╚██████╔╝ ███████╗  ██║    ██║ ██║ ╚═╝ ██║ ██║  ██║    ██║    ███████╗" + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + " ╚═════╝   ╚══════╝ ╚═╝    ╚═╝ ╚═╝     ╚═╝ ╚═╝  ╚═╝    ╚═╝    ╚══════╝" + "\u001b[0m");
        this.plugin.getLogger().info("");
        this.plugin.getLogger().info("\u001b[32m" + "          ███████╗ ████████╗ ██╗   ██╗ ██████╗  ██╗  ██████╗            " + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "          ██╔════╝ ╚══██╔══╝ ██║   ██║ ██╔══██╗ ██║ ██╔═══██╗           " + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "          ███████╗    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "          ╚════██║    ██║    ██║   ██║ ██║  ██║ ██║ ██║   ██║           " + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "          ███████║    ██║    ╚██████╔╝ ██████╔╝ ██║ ╚██████╔╝          " + "\u001b[0m");
        this.plugin.getLogger().info("\u001b[32m" + "          ╚══════╝    ╚═╝     ╚═════╝  ╚═════╝  ╚═╝  ╚═════╝           " + "\u001b[0m");
        this.plugin.getLogger().info("");
        this.plugin.getLogger().info("");
        this.plugin.getLogger().info("\u001b[32m" + "╔══════════════════════════════════════════════════════════════╗");
        this.plugin.getLogger().info("\u001b[32m" + "║                    LICENSE KEY VAILD                         ║");
        this.plugin.getLogger().info("\u001b[32m" + "╠══════════════════════════════════════════════════════════════╣");
        String displayedKey3 = this.licenseKey == null ? "" : this.licenseKey.length() >= 64 ? this.licenseKey.substring(0, 64) + "..." : this.licenseKey;
        this.plugin.getLogger().info("\u001b[32m" + "║ Key: " + displayedKey3 + "                     ║");
        this.plugin.getLogger().info("\u001b[32m" + "║ Thanks for your support to use my Plugin                     ║");
        this.plugin.getLogger().info("\u001b[32m" + "╚══════════════════════════════════════════════════════════════╝");
        return true;
    }

    private boolean validateWithAPI(String licenseKey, String serverId) {
        HttpURLConnection conn = null;
        try {
            disableSSLVerification();
            URL url = new URL("http://154.43.52.66:25010/api/validate");
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", this.plugin.getName() + "/" + this.plugin.getDescription().getVersion());
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            String jsonData = String.format("{\"license_key\":\"%s\",\"server_id\":\"%s\",\"plugin_id\":\"%s\"}", licenseKey, serverId, "DonutLeaderboards");
            OutputStream os = conn.getOutputStream();
            os.write(jsonData.getBytes("UTF-8"));
            os.flush();
            os.close();
            int responseCode = conn.getResponseCode();
            if (responseCode == 301 || responseCode == 302 || responseCode == 303) {
                String newUrl = conn.getHeaderField("Location");
                conn.disconnect();
                URL url2 = new URL(newUrl);
                conn = (HttpURLConnection) url2.openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("User-Agent", this.plugin.getName() + "/" + this.plugin.getDescription().getVersion());
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);
                OutputStream os2 = conn.getOutputStream();
                os2.write(jsonData.getBytes("UTF-8"));
                os2.flush();
                os2.close();
                responseCode = conn.getResponseCode();
            }
            InputStream inputStream = (responseCode < 200 || responseCode >= 300) ? conn.getErrorStream() : conn.getInputStream();
            if (inputStream == null) {
                if (conn != null) {
                    conn.disconnect();
                }
                return false;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuilder response = new StringBuilder();
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                response.append(line);
            }
            br.close();
            String responseStr = response.toString();
            if (responseStr.contains("\"valid\":true") || responseStr.contains("\"message\":\"LICENSE_VALID\"") || responseStr.contains("\"valid\": true")) {
                if (conn != null) {
                    conn.disconnect();
                }
                return true;
            }
            if (!responseStr.contains("LICENSE_NOT_FOUND") && !responseStr.contains("LICENSE_EXPIRED") && !responseStr.contains("WRONG_PLUGIN") && !responseStr.contains("TOO_MANY_SERVERS")) {
                if (responseStr.contains("LICENSE_INACTIVE")) {
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
            return false;
        } catch (Exception e) {
            if (conn != null) {
            }
            if (conn != null) {
                conn.disconnect();
            }
            return false;
        } catch (Throwable th) {
            if (conn != null) {
                conn.disconnect();
            }
            throw th;
        }
    }

    private void disableSSLVerification() {
        try {
            TrustManager[] trustAllCerts = {new X509TrustManager(this) { // from class: de.elivb.donutLeaderboards.LicenseManager.1
                @Override // javax.net.ssl.X509TrustManager
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override // javax.net.ssl.X509TrustManager
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                @Override // javax.net.ssl.X509TrustManager
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HostnameVerifier allHostsValid = new HostnameVerifier(this) { // from class: de.elivb.donutLeaderboards.LicenseManager.2
                @Override // javax.net.ssl.HostnameVerifier
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
        }
    }

    private String generateHash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(255 & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            String fullHash = hexString.toString().toUpperCase();
            String formatted = "";
            for (int i = 0; i < 32; i += 8) {
                if (i >= fullHash.length()) {
                    break;
                }
                if (i > 0) {
                    formatted = formatted + "-";
                }
                int end = Math.min(i + 8, fullHash.length());
                formatted = formatted + fullHash.substring(i, end);
            }
            return formatted;
        } catch (Exception e) {
            return UUID.randomUUID().toString().toUpperCase().replace("-", "").substring(0, 32);
        }
    }

    private void saveLicenseFile() {
        try {
            this.licenseConfig.save(this.licenseFile);
        } catch (IOException e) {
        }
    }

    public String getServerId() {
        return this.serverId;
    }

    public String getLicenseKey() {
        return this.licenseKey;
    }

    public boolean isLicenseValid() {
        return this.licenseValid;
    }

    public void setLicenseKey(String key) {
        this.licenseConfig.set("license-key", key);
        saveLicenseFile();
        this.licenseKey = key;
        this.licenseValid = validateWithAPI(key, this.serverId);
    }
}
