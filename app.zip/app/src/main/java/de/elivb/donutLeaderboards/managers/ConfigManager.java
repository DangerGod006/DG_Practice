package de.elivb.donutLeaderboards.managers;

import de.elivb.donutLeaderboards.Leaderboards;
import java.io.File;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: DonutLeaderboards-1.1.jar:de/elivb/donutLeaderboards/managers/ConfigManager.class */
public class ConfigManager {
    private final Leaderboards plugin;
    private FileConfiguration mainConfig;
    private final Map<String, FileConfiguration> guiConfigs = new HashMap();
    private final DecimalFormat decimalFormat;

    public ConfigManager(Leaderboards plugin) {
        this.plugin = plugin;
        this.mainConfig = plugin.getConfig();
        this.decimalFormat = new DecimalFormat(this.mainConfig.getString("economy.currency-format", "#,##0.##"));
        loadGUIConfigs();
    }

    private void loadGUIConfigs() {
        File guiFolder = new File(this.plugin.getDataFolder(), "gui");
        if (!guiFolder.exists()) {
            guiFolder.mkdirs();
        }
        File mainGuiFile = new File(guiFolder, "main-gui.yml");
        if (mainGuiFile.exists()) {
            this.guiConfigs.put("main-gui", YamlConfiguration.loadConfiguration(mainGuiFile));
        }
        String[] leaderboardFiles = {"money", "deaths", "playtime", "blocks-placed", "blocks-broken", "mobs-killed", "player-kills"};
        for (String fileName : leaderboardFiles) {
            File file = new File(guiFolder, fileName + ".yml");
            if (file.exists()) {
                this.guiConfigs.put(fileName, YamlConfiguration.loadConfiguration(file));
            }
        }
    }

    public FileConfiguration getMainGUI() {
        FileConfiguration config = this.guiConfigs.get("main-gui");
        if (config == null) {
            config = createDefaultMainGUI();
            this.guiConfigs.put("main-gui", config);
        }
        return config;
    }

    private FileConfiguration createDefaultMainGUI() {
        YamlConfiguration yamlConfigurationLoadConfiguration = YamlConfiguration.loadConfiguration(new File(this.plugin.getDataFolder(), "gui/main-gui.yml"));
        yamlConfigurationLoadConfiguration.set("main.title", "&8ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅꜱ");
        yamlConfigurationLoadConfiguration.set("main.rows", 3);
        yamlConfigurationLoadConfiguration.set("main.items.money.enabled", true);
        yamlConfigurationLoadConfiguration.set("main.items.money.slot", 10);
        yamlConfigurationLoadConfiguration.set("main.items.money.material", "EMERALD");
        yamlConfigurationLoadConfiguration.set("main.items.money.display-name", "&#04fc84ᴍᴏɴᴇʏ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ");
        yamlConfigurationLoadConfiguration.set("main.items.money.lore", List.of("&fClick to view the ᴍᴏɴᴇʏ leaderboard"));
        return yamlConfigurationLoadConfiguration;
    }

    public FileConfiguration getLeaderboardGUI(String name) {
        FileConfiguration config = this.guiConfigs.get(name);
        if (config == null) {
            return createDefaultLeaderboardGUI(name);
        }
        return config;
    }

    private FileConfiguration createDefaultLeaderboardGUI(String name) {
        YamlConfiguration yamlConfigurationLoadConfiguration = YamlConfiguration.loadConfiguration(new File(this.plugin.getDataFolder(), "gui/" + name + ".yml"));
        yamlConfigurationLoadConfiguration.set("title", "&8" + name.toUpperCase() + " (Page %page%/%total%)");
        yamlConfigurationLoadConfiguration.set("row", 6);
        yamlConfigurationLoadConfiguration.set("players", "0-44");
        yamlConfigurationLoadConfiguration.set("items.player.display-name", "&#04fc84%name%");
        yamlConfigurationLoadConfiguration.set("items.player.material", "PLAYER_HEAD");
        yamlConfigurationLoadConfiguration.set("items.player.command", "stats %player%");
        yamlConfigurationLoadConfiguration.set("items.player.lore", List.of("&fValue: &7%value% &#04fc84(%rank%)"));
        yamlConfigurationLoadConfiguration.set("items.self.slot", 48);
        yamlConfigurationLoadConfiguration.set("items.self.material", "PLAYER_HEAD");
        yamlConfigurationLoadConfiguration.set("items.self.display-name", "&#04fc84%name%");
        yamlConfigurationLoadConfiguration.set("items.self.lore", List.of("&fValue: &7%value% &#04fc84(%rank%)"));
        yamlConfigurationLoadConfiguration.set("items.back.slot", 45);
        yamlConfigurationLoadConfiguration.set("items.back.material", "ARROW");
        yamlConfigurationLoadConfiguration.set("items.back.display-name", "&#04fc84ʙᴀᴄᴋ");
        yamlConfigurationLoadConfiguration.set("items.refresh.slot", 49);
        yamlConfigurationLoadConfiguration.set("items.refresh.material", "STONE");
        yamlConfigurationLoadConfiguration.set("items.refresh.display-name", "&#04fc84ʀᴇꜰʀᴇꜱʜ");
        yamlConfigurationLoadConfiguration.set("items.search.slot", 50);
        yamlConfigurationLoadConfiguration.set("items.search.material", "OAK_SIGN");
        yamlConfigurationLoadConfiguration.set("items.search.display-name", "&#04fc84ѕᴇᴀʀᴄʜ");
        yamlConfigurationLoadConfiguration.set("items.next.slot", 53);
        yamlConfigurationLoadConfiguration.set("items.next.material", "ARROW");
        yamlConfigurationLoadConfiguration.set("items.next.display-name", "&#04fc84ɴᴇxᴛ");
        return yamlConfigurationLoadConfiguration;
    }

    public void reloadConfigs() {
        this.plugin.reloadConfig();
        this.mainConfig = this.plugin.getConfig();
        this.guiConfigs.clear();
        loadGUIConfigs();
    }

    public String getCurrencyFormat() {
        return this.mainConfig.getString("economy.currency-format", "#,##0.##");
    }

    public boolean isAbbreviationsEnabled() {
        return this.mainConfig.getBoolean("economy.abbreviations.enabled", true);
    }

    public List<String> getAbbreviationFormats() {
        return this.mainConfig.getStringList("economy.abbreviations.formats");
    }

    public boolean useSignAPI() {
        return this.mainConfig.getBoolean("chat-input.SignAPI", true);
    }

    public boolean useChatAPI() {
        return this.mainConfig.getBoolean("chat-input.ChatAPI", false);
    }

    public List<String> getSignGUILines() {
        return this.mainConfig.getStringList("sign-gui");
    }

    public String getClickSound() {
        return this.mainConfig.getString("sounds.click-sound", "UI_BUTTON_CLICK");
    }

    public String getReloadSound() {
        return this.mainConfig.getString("sounds.plugin-reloaded", "ENTITY_PLAYER_LEVELUP");
    }

    public String formatMoney(double amount) {
        String str;
        if (!isAbbreviationsEnabled() || amount < 1000.0d) {
            return this.decimalFormat.format(amount);
        }
        String[] units = {"", "K", "M", "B", "T"};
        List<String> customUnits = getAbbreviationFormats();
        int unitIndex = 0;
        double formattedAmount = amount;
        while (formattedAmount >= 1000.0d && unitIndex < units.length - 1) {
            formattedAmount /= 1000.0d;
            unitIndex++;
        }
        if (unitIndex > 0 && unitIndex <= customUnits.size()) {
            str = customUnits.get(unitIndex - 1);
        } else {
            str = units[unitIndex];
        }
        String unit = str;
        return this.decimalFormat.format(formattedAmount) + unit;
    }
}
