package dev.rean.pvpcore.util;

import dev.rean.pvpcore.managers.MessageManager;
import java.time.Duration;
import java.util.Map;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/TitleFormat.class */
public final class TitleFormat {
    private TitleFormat() {
    }

    public static void send(Player p, String raw, MessageManager messages) {
        if (raw == null) {
            return;
        }
        String formatted = messages.format(raw, Map.of());
        String[] parts = formatted.split("\\|", -1);
        String title = parts.length > 0 ? parts[0] : "";
        String subtitle = parts.length > 1 ? parts[1] : "";
        int fadeIn = parts.length > 2 ? parseInt(parts[2], 0) : 0;
        int stay = parts.length > 3 ? parseInt(parts[3], 20) : 20;
        int fadeOut = parts.length > 4 ? parseInt(parts[4], 0) : 0;
        Title.Times times = Title.Times.times(Duration.ofMillis(((long) fadeIn) * 50), Duration.ofMillis(((long) stay) * 50), Duration.ofMillis(((long) fadeOut) * 50));
        LegacyComponentSerializer legacy = LegacyComponentSerializer.legacySection();
        p.showTitle(Title.title(legacy.deserialize(title), legacy.deserialize(subtitle), times));
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }
}
