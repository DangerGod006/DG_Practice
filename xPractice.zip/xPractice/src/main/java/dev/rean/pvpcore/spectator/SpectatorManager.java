package dev.rean.pvpcore.spectator;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/spectator/SpectatorManager.class */
public final class SpectatorManager {
    private static final long SPECTATE_COOLDOWN_MILLIS = 10000;
    private final PvPCorePlugin plugin;
    private final Map<UUID, SpectatorSession> sessions = new ConcurrentHashMap();
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap();

    public SpectatorManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean spectate(Player spectator, Player target) {
        if (spectator == null || target == null) {
            return false;
        }
        UUID spectatorId = spectator.getUniqueId();
        if (this.plugin.duelManager().isInMatch(spectatorId)) {
            this.plugin.messages().send(spectator, "spectators.already-in-duel");
            return false;
        }
        DuelMatch match = this.plugin.duelManager().getMatch(target.getUniqueId());
        if (match == null) {
            this.plugin.messages().send(spectator, "spectators.target-not-in-duel");
            return false;
        }
        String matchId = this.plugin.duelManager().matchId(match);
        SpectatorSession current = this.sessions.get(spectatorId);
        if (current != null && current.matchId().equals(matchId)) {
            this.plugin.messages().send(spectator, "spectators.already-spectating");
            teleportToMatch(spectator, match);
            return true;
        }
        long now = System.currentTimeMillis();
        long nextAllowed = this.cooldowns.computeIfAbsent(spectatorId, ignored -> {
            return new ConcurrentHashMap();
        }).getOrDefault(matchId, 0L).longValue();
        if (nextAllowed > now) {
            long seconds = Math.max(1L, ((nextAllowed - now) + 999) / 1000);
            this.plugin.messages().send(spectator, "spectators.cooldown", Map.of("seconds", String.valueOf(seconds)));
            return false;
        }
        if (current != null) {
            leave(spectator, false);
        }
        this.plugin.queueManager().leaveAllQuiet(spectatorId);
        this.cooldowns.get(spectatorId).put(matchId, Long.valueOf(now + SPECTATE_COOLDOWN_MILLIS));
        this.sessions.put(spectatorId, new SpectatorSession(spectatorId, matchId, match.red(), match.blue(), spectator.getLocation().clone()));
        spectator.setGameMode(GameMode.SPECTATOR);
        spectator.setFlying(true);
        teleportToMatch(spectator, match);
        this.plugin.messages().send(spectator, "spectators.started", Map.of("target", target.getName()));
        return true;
    }

    public boolean leave(Player player, boolean notify) {
        SpectatorSession session;
        if (player == null || (session = this.sessions.remove(player.getUniqueId())) == null) {
            return false;
        }
        player.setGameMode(GameMode.SURVIVAL);
        player.setFlying(false);
        Location exit = this.plugin.settings().mainSpawn();
        if (exit == null) {
            exit = session.previousLocation();
        }
        if (exit != null) {
            player.teleport(exit);
        }
        this.plugin.lobbyItems().giveLobbyItems(player);
        if (notify) {
            this.plugin.messages().send(player, "spectators.left");
            return true;
        }
        return true;
    }

    public void remove(UUID playerId) {
        if (playerId == null) {
            return;
        }
        Player player = Bukkit.getPlayer(playerId);
        if (player == null) {
            this.sessions.remove(playerId);
        } else {
            leave(player, false);
        }
    }

    public boolean isSpectating(UUID playerId) {
        return playerId != null && this.sessions.containsKey(playerId);
    }

    public String spectatedMatchId(UUID playerId) {
        SpectatorSession session = playerId == null ? null : this.sessions.get(playerId);
        return session == null ? "" : session.matchId();
    }

    public DuelMatch spectatedMatch(UUID playerId) {
        SpectatorSession session = playerId == null ? null : this.sessions.get(playerId);
        if (session == null) {
            return null;
        }
        DuelMatch redMatch = this.plugin.duelManager().getMatch(session.red());
        if (redMatch != null && this.plugin.duelManager().matchId(redMatch).equals(session.matchId())) {
            return redMatch;
        }
        DuelMatch blueMatch = this.plugin.duelManager().getMatch(session.blue());
        if (blueMatch != null && this.plugin.duelManager().matchId(blueMatch).equals(session.matchId())) {
            return blueMatch;
        }
        this.sessions.remove(playerId);
        return null;
    }

    public Collection<Player> spectators(DuelMatch match) {
        Player player;
        if (match == null) {
            return Collections.emptyList();
        }
        String matchId = this.plugin.duelManager().matchId(match);
        Collection<Player> viewers = new ArrayList<>();
        for (SpectatorSession session : this.sessions.values()) {
            if (session.matchId().equals(matchId) && (player = Bukkit.getPlayer(session.playerId())) != null && player.isOnline()) {
                viewers.add(player);
            }
        }
        return viewers;
    }

    public void stopSpectatingMatch(DuelMatch match) {
        if (match == null) {
            return;
        }
        String matchId = this.plugin.duelManager().matchId(match);
        Set<UUID> toRemove = ConcurrentHashMap.newKeySet();
        for (SpectatorSession session : this.sessions.values()) {
            if (session.matchId().equals(matchId)) {
                toRemove.add(session.playerId());
            }
        }
        for (UUID spectatorId : toRemove) {
            Player player = Bukkit.getPlayer(spectatorId);
            if (player == null || !player.isOnline()) {
                this.sessions.remove(spectatorId);
            } else {
                leave(player, true);
            }
        }
    }

    public void teleportToMatch(Player player) {
        DuelMatch match;
        if (player != null && (match = spectatedMatch(player.getUniqueId())) != null) {
            teleportToMatch(player, match);
        }
    }

    public void teleportToMatch(Player player, DuelMatch match) {
        Location location;
        if (player == null || match == null || (location = match.spectatorLocation()) == null) {
            return;
        }
        player.teleport(location);
    }

    public void shutdown() {
        for (UUID spectatorId : new ArrayList(this.sessions.keySet())) {
            Player player = Bukkit.getPlayer(spectatorId);
            if (player == null || !player.isOnline()) {
                this.sessions.remove(spectatorId);
            } else {
                leave(player, false);
            }
        }
        this.cooldowns.clear();
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession.class */
    private static final class SpectatorSession extends Record {
        private final UUID playerId;
        private final String matchId;
        private final UUID red;
        private final UUID blue;
        private final Location previousLocation;

        private SpectatorSession(UUID playerId, String matchId, UUID red, UUID blue, Location previousLocation) {
            this.playerId = playerId;
            this.matchId = matchId;
            this.red = red;
            this.blue = blue;
            this.previousLocation = previousLocation;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, SpectatorSession.class), SpectatorSession.class, "playerId;matchId;red;blue;previousLocation", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->matchId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->red:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->blue:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->previousLocation:Lorg/bukkit/Location;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, SpectatorSession.class), SpectatorSession.class, "playerId;matchId;red;blue;previousLocation", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->matchId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->red:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->blue:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->previousLocation:Lorg/bukkit/Location;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, SpectatorSession.class, Object.class), SpectatorSession.class, "playerId;matchId;red;blue;previousLocation", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->matchId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->red:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->blue:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/spectator/SpectatorManager$SpectatorSession;->previousLocation:Lorg/bukkit/Location;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public UUID playerId() {
            return this.playerId;
        }

        public String matchId() {
            return this.matchId;
        }

        public UUID red() {
            return this.red;
        }

        public UUID blue() {
            return this.blue;
        }

        public Location previousLocation() {
            return this.previousLocation;
        }
    }
}
