package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.duel.DuelMatch;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.util.HashSet;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/DuelChatListener.class */
public final class DuelChatListener implements Listener {
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final Pattern UNSAFE_MINIMESSAGE_TAGS = Pattern.compile("(?i)</?(click|click_event|insertion)(?::[^>]*)?>");
    private final PvPCorePlugin plugin;
    private final DuelManager duelManager;

    public DuelChatListener(PvPCorePlugin plugin, DuelManager duelManager) {
        this.plugin = plugin;
        this.duelManager = duelManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        String string;
        if (this.plugin.getConfig().getBoolean("chat.enabled", true)) {
            Player sender = event.getPlayer();
            DuelMatch match = this.duelManager.getMatch(sender.getUniqueId());
            String plainMessage = PlainTextComponentSerializer.plainText().serialize(event.message());
            if (match != null && this.plugin.getConfig().getBoolean("chat.duel-only-match", true)) {
                Player red = Bukkit.getPlayer(match.red());
                Player blue = Bukkit.getPlayer(match.blue());
                HashSet hashSet = new HashSet();
                if (red != null) {
                    hashSet.add(red);
                }
                if (blue != null) {
                    hashSet.add(blue);
                }
                hashSet.addAll(this.plugin.spectatorManager().spectators(match));
                event.viewers().clear();
                event.viewers().addAll(hashSet);
            }
            if (match != null) {
                string = this.plugin.getConfig().getString("chat.duel-format", "&b[Duel] %team_color%%player% &8» &f%message%");
            } else {
                string = this.plugin.getConfig().getString("chat.format", "&7%player% &8» &f%message%");
            }
            String rawFormat = string;
            Component formatted = render(rawFormat, sender, plainMessage, match);
            event.renderer((source, sourceDisplayName, message, viewer) -> {
                return formatted;
            });
        }
    }

    private Component render(String rawFormat, Player sender, String plainMessage, DuelMatch match) {
        String rendered = sanitizeUnsafeMiniMessage(legacyFormatToMini(rawFormat));
        try {
            return MINI_MESSAGE.deserialize(rendered.replace("%player%", escapeMiniMessageText(sender.getName())).replace("%displayname%", escapeMiniMessageText(sender.getDisplayName())).replace("%message%", escapeMiniMessageText(plainMessage)).replace("%team_color%", match != null ? legacyFormatToMini(match.teamColor(sender.getUniqueId())) : "").replace("%arena%", match != null ? escapeMiniMessageText(match.arena().id()) : "").replace("%arena_name%", match != null ? escapeMiniMessageText(match.arena().displayName()) : "").replace("%kit%", match != null ? escapeMiniMessageText(match.kit().id()) : "").replace("%kit_name%", match != null ? escapeMiniMessageText(match.kit().displayName()) : ""));
        } catch (RuntimeException e) {
            return Component.text(sender.getName() + " » " + plainMessage);
        }
    }

    private String sanitizeUnsafeMiniMessage(String value) {
        return (value == null || value.isBlank()) ? "" : UNSAFE_MINIMESSAGE_TAGS.matcher(value).replaceAll("");
    }

    private String escapeMiniMessageText(String value) {
        return (value == null || value.isEmpty()) ? "" : value.replace("\\", "\\\\").replace("<", "\\<");
    }

    private String legacyFormatToMini(String value) {
        if (value == null) {
            return "";
        }
        return Pattern.compile("&?#([A-Fa-f0-9]{6})").matcher(value.replace((char) 167, '&')).replaceAll("<#$1>").replace("&0", "<black>").replace("&1", "<dark_blue>").replace("&2", "<dark_green>").replace("&3", "<dark_aqua>").replace("&4", "<dark_red>").replace("&5", "<dark_purple>").replace("&6", "<gold>").replace("&7", "<gray>").replace("&8", "<dark_gray>").replace("&9", "<blue>").replace("&a", "<green>").replace("&b", "<aqua>").replace("&c", "<red>").replace("&d", "<light_purple>").replace("&e", "<yellow>").replace("&f", "<white>").replace("&l", "<bold>").replace("&o", "<italic>").replace("&n", "<underlined>").replace("&m", "<strikethrough>").replace("&r", "<reset>");
    }
}
