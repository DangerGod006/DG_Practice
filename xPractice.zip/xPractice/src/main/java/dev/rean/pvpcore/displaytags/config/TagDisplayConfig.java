package dev.rean.pvpcore.displaytags.config;

import dev.rean.pvpcore.displaytags.entities.DisplayBillboard;
import dev.rean.pvpcore.displaytags.entities.TextAlignment;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/config/TagDisplayConfig.class */
public class TagDisplayConfig {
    private final String id;
    private final boolean enabled;
    private final List<String> lines;
    private final boolean textShadow;
    private final boolean seeThrough;
    private final TextAlignment textAlignment;
    private final String background;
    private final DisplayBillboard billboard;
    private final Vector scale;
    private final Vector position;
    private final Set<String> worlds;
    private final List<Integer> visibleLines;

    public TagDisplayConfig(String id, ConfigurationSection section) {
        this.id = id;
        this.enabled = section.getBoolean("enabled", true);
        this.lines = section.getStringList("lines");
        this.textShadow = section.getBoolean("text-shadow", false);
        this.seeThrough = section.getBoolean("see-through", false);
        this.textAlignment = TextAlignment.valueOf(section.getString("text-alignment", "center").toUpperCase());
        this.background = section.getString("background", "default");
        this.billboard = DisplayBillboard.valueOf(section.getString("billboard", "center").toUpperCase());
        this.scale = parseVector(section, "scale", new Vector(1, 1, 1));
        this.position = parseVector(section, "position", new Vector(0.0d, 0.25d, 0.0d));
        this.worlds = new LinkedHashSet(section.getStringList("worlds"));
        this.visibleLines = parseVisibleLines(section);
    }

    public String getId() {
        return this.id;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public List<String> getLines() {
        return this.lines;
    }

    public boolean hasTextShadow() {
        return this.textShadow;
    }

    public boolean isSeeThrough() {
        return this.seeThrough;
    }

    public TextAlignment getTextAlignment() {
        return this.textAlignment;
    }

    public String getBackground() {
        return this.background;
    }

    public DisplayBillboard getBillboard() {
        return this.billboard;
    }

    public Vector getScale() {
        return this.scale;
    }

    public Vector getPosition() {
        return this.position;
    }

    public Set<String> getWorlds() {
        return Collections.unmodifiableSet(this.worlds);
    }

    public boolean isWorldAllowed(String worldName) {
        return this.worlds.isEmpty() || this.worlds.contains(worldName);
    }

    public List<Integer> getVisibleLines() {
        return Collections.unmodifiableList(this.visibleLines);
    }

    private Vector parseVector(ConfigurationSection section, String path, Vector defaults) {
        ConfigurationSection vectorSection = section.getConfigurationSection(path);
        if (vectorSection == null) {
            return defaults.clone();
        }
        return new Vector(vectorSection.getDouble("x", defaults.getX()), vectorSection.getDouble("y", defaults.getY()), vectorSection.getDouble("z", defaults.getZ()));
    }

    private List<Integer> parseVisibleLines(ConfigurationSection section) {
        List<Integer> lineIndexes = section.getIntegerList("visible-lines");
        if (!lineIndexes.isEmpty()) {
            return lineIndexes.stream().filter(index -> {
                return index.intValue() > 0;
            }).distinct().toList();
        }
        int singleLine = section.getInt("show-line", -1);
        if (singleLine > 0) {
            return List.of(Integer.valueOf(singleLine));
        }
        return List.of();
    }
}
