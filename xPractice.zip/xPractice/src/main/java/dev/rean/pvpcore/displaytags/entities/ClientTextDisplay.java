package dev.rean.pvpcore.displaytags.entities;

import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes;
import dev.rean.pvpcore.kits.KitEditorManager;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/entities/ClientTextDisplay.class */
public class ClientTextDisplay extends ClientDisplay {
    private Component text;
    private int background;
    private int flags;

    public ClientTextDisplay(Location location) {
        super(EntityType.TEXT_DISPLAY, location);
        this.background = -1;
        this.flags = 0;
    }

    public Component getText() {
        return this.text;
    }

    public void setText(Component text) {
        this.text = text;
    }

    public int getBackground() {
        return this.background;
    }

    public void setBackground(int background) {
        this.background = background;
    }

    public void setTextShadow(boolean enabled) {
        setFlag(1, enabled);
    }

    public void setSeeThrough(boolean enabled) {
        setFlag(2, enabled);
    }

    /* JADX INFO: renamed from: dev.rean.pvpcore.displaytags.entities.ClientTextDisplay$1, reason: invalid class name */
    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/entities/ClientTextDisplay$1.class */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$dev$rean$pvpcore$displaytags$entities$TextAlignment = new int[TextAlignment.values().length];

        static {
            try {
                $SwitchMap$dev$rean$pvpcore$displaytags$entities$TextAlignment[TextAlignment.CENTER.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$displaytags$entities$TextAlignment[TextAlignment.LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$displaytags$entities$TextAlignment[TextAlignment.RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public void setTextAlignment(TextAlignment alignment) {
        this.flags &= -25;
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$displaytags$entities$TextAlignment[alignment.ordinal()]) {
            case KitEditorManager.HELMET_SLOT /* 2 */:
                this.flags |= 8;
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                this.flags |= 16;
                break;
        }
    }

    @Override // dev.rean.pvpcore.displaytags.entities.ClientDisplay, dev.rean.pvpcore.displaytags.entities.ClientEntity
    public List<EntityData<?>> getEntityData() {
        List<EntityData<?>> data = super.getEntityData();
        if (this.text != null) {
            data.add(new EntityData<>(23, EntityDataTypes.ADV_COMPONENT, this.text));
        }
        if (this.background != -1) {
            data.add(new EntityData<>(25, EntityDataTypes.INT, Integer.valueOf(this.background)));
        }
        if (this.flags != 0) {
            data.add(new EntityData<>(27, EntityDataTypes.BYTE, Byte.valueOf((byte) this.flags)));
        }
        return data;
    }

    private void setFlag(int mask, boolean enabled) {
        if (enabled) {
            this.flags |= mask;
        } else {
            this.flags &= mask ^ (-1);
        }
    }
}
