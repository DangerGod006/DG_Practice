package dev.rean.pvpcore.gui;

import java.util.Locale;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiAction.class */
public enum GuiAction {
    SELECT_KIT,
    EDITKIT,
    OPEN_KIT_SELECT,
    OPEN_ROUNDS_SELECT,
    CONFIRM_DUEL,
    SELECT_ROUNDS,
    BACK_TO_DUEL_REQUEST,
    NONE;

    public static GuiAction from(String raw) {
        if (raw == null || raw.isBlank()) {
            return NONE;
        }
        try {
            return valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }
}
