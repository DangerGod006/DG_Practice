package dev.rean.pvpcore.kits;

import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/kits/KitEditorHolder.class */
public final class KitEditorHolder implements InventoryHolder {
    private final UUID playerId;
    private final String kitId;

    public KitEditorHolder(UUID playerId, String kitId) {
        this.playerId = playerId;
        this.kitId = kitId;
    }

    public UUID playerId() {
        return this.playerId;
    }

    public String kitId() {
        return this.kitId;
    }

    @NotNull
    public Inventory getInventory() {
        throw new UnsupportedOperationException("Virtual holder");
    }
}
