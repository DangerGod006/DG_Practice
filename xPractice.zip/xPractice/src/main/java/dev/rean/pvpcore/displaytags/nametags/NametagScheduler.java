package dev.rean.pvpcore.displaytags.nametags;

import dev.rean.pvpcore.displaytags.DisplayTags;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/nametags/NametagScheduler.class */
public class NametagScheduler {
    private final DisplayTags plugin;
    private BukkitTask task;

    public NametagScheduler(DisplayTags plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            this.plugin.getLogger().info("Starting Nametag scheduler...");
            int interval = Math.max(1, this.plugin.config().getNametagConfig().getUpdateInterval());
            this.task = Bukkit.getScheduler().runTaskTimer(this.plugin.getHost(), () -> {
                for (Nametag nametag : this.plugin.getNametagManager().getAll()) {
                    nametag.updateVisibilityForAll();
                }
            }, interval, interval);
        } else {
            this.plugin.getLogger().warning("Nametags are disabled for this server, therefore the nametag scheduler has not been started.");
            this.plugin.getLogger().warning("If you want to enable the nametags again, enable them in displaytags.yml and run /pvpcore reload.");
        }
    }

    public void stop() {
        if (this.task != null) {
            this.plugin.getLogger().info("Stopping Nametag scheduler...");
            this.task.cancel();
        }
    }
}
