package dev.rean.pvpcore.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/HexColor.class */
public final class HexColor {
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private HexColor() {
    }

    public static String color(String s) {
        if (s == null) {
            return "";
        }
        Matcher matcher = HEX.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String hex = matcher.group(1);
            matcher.appendReplacement(sb, ChatColor.of("#" + hex).toString());
        }
        matcher.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }
}
