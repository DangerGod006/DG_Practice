package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.managers.ToggleManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/DuelToggleCommand.class */
public final class DuelToggleCommand implements CommandExecutor {
    private final MessageManager messages;
    private final ToggleManager toggles;

    public DuelToggleCommand(MessageManager messages, ToggleManager toggles) {
        this.messages = messages;
        this.toggles = toggles;
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.messages.send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        boolean nowDisabled = this.toggles.toggle(commandSender.getUniqueId());
        if (!nowDisabled) {
            this.messages.send(commandSender, "duels.toggled-on");
            return true;
        }
        this.messages.send(commandSender, "duels.toggled-off");
        return true;
    }
}
