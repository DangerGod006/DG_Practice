package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.managers.Settings;
import java.util.Locale;
import java.util.Map;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/PlayerCommandPreprocessListener.class */
public final class PlayerCommandPreprocessListener implements Listener {
    private final Settings settings;
    private final DuelManager duels;
    private final MessageManager messages;

    public PlayerCommandPreprocessListener(Settings settings, DuelManager duels, MessageManager messages) {
        this.settings = settings;
        this.duels = duels;
        this.messages = messages;
    }

    @EventHandler
    public void onCmd(PlayerCommandPreprocessEvent e) {
        if (this.duels.isInMatch(e.getPlayer().getUniqueId()) && !this.settings.plugin().getConfig().getBoolean("duels.commands-in-duel.enabled", this.settings.allowCommandsInMatch())) {
            String bypass = this.settings.plugin().getConfig().getString("duels.commands-in-duel.bypass-permission", "pvpcore.duel.commands.bypass");
            if (bypass == null || bypass.isBlank() || !e.getPlayer().hasPermission(bypass)) {
                String raw = e.getMessage().startsWith("/") ? e.getMessage().substring(1) : e.getMessage();
                String label = raw.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
                for (String allowed : this.settings.plugin().getConfig().getStringList("duels.commands-in-duel.allowed")) {
                    if (allowed != null && !allowed.isBlank()) {
                        String normalized = allowed.toLowerCase(Locale.ROOT).replaceFirst("^/", "");
                        if (label.equals(normalized)) {
                            return;
                        }
                    }
                }
                e.setCancelled(true);
                String fallback = this.settings.plugin().getConfig().getString("duels.commands-in-duel.message", "&cYou can't use commands during a duel.");
                String msg = this.messages.rawString("duels.command-blocked", fallback);
                e.getPlayer().sendMessage(this.messages.format(msg, Map.of()));
            }
        }
    }
}
