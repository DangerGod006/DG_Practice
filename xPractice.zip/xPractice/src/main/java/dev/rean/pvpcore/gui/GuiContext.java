package dev.rean.pvpcore.gui;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiContext.class */
public enum GuiContext {
    DUEL,
    QUEUE,
    KIT_EDITOR,
    SETTINGS
}
