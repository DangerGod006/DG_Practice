package dev.rean.pvpcore.displaytags.config;

import dev.rean.pvpcore.displaytags.DisplayTags;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/config/NametagConfig.class */
public class NametagConfig {
    private final DisplayTags plugin;
    private boolean enabled;
    private boolean showSelf;
    private int updateInterval;
    private int visibilityDistance;
    private int deathVisibleTicks;
    private double stackedYOffset;
    private double temporarySpectatorTagHeightOffset;
    private List<TagDisplayConfig> displays = new ArrayList();

    public NametagConfig(DisplayTags plugin) {
        this.plugin = plugin;
    }

    public void load() {
        load(this.plugin.getConfig());
    }

    public void load(FileConfiguration config) {
        this.enabled = config.getBoolean("nametags.enabled", false);
        this.showSelf = config.getBoolean("nametags.show-self", true);
        this.updateInterval = config.getInt("nametags.update-interval", 1);
        this.visibilityDistance = config.getInt("nametags.visibility-distance", 64);
        this.deathVisibleTicks = Math.max(0, config.getInt("nametags.death-visible-ticks", 22));
        this.stackedYOffset = config.getDouble("nametags.stacked-y-offset", 0.3d);
        this.temporarySpectatorTagHeightOffset = config.getDouble("nametags.temporary-spectator-tag-height-offset", 0.55d);
        this.displays = loadDisplays(config);
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public int getUpdateInterval() {
        return this.updateInterval;
    }

    public boolean shouldHideSelf() {
        return !this.showSelf;
    }

    public int getVisibilityDistance() {
        return this.visibilityDistance;
    }

    public int getDeathVisibleTicks() {
        return this.deathVisibleTicks;
    }

    public double getStackedYOffset() {
        return this.stackedYOffset;
    }

    public double getTemporarySpectatorTagHeightOffset() {
        return this.temporarySpectatorTagHeightOffset;
    }

    public List<TagDisplayConfig> getDisplays() {
        return Collections.unmodifiableList(this.displays);
    }

    private List<TagDisplayConfig> loadDisplays(FileConfiguration config) {
        List<TagDisplayConfig> loadedDisplays = new ArrayList<>();
        ConfigurationSection tagsSection = config.getConfigurationSection("nametags.tags");
        if (tagsSection != null) {
            for (String key : tagsSection.getKeys(false)) {
                ConfigurationSection section = tagsSection.getConfigurationSection(key);
                if (section != null) {
                    TagDisplayConfig display = new TagDisplayConfig(key, section);
                    if (display.isEnabled()) {
                        loadedDisplays.add(display);
                    }
                }
            }
        }
        if (!loadedDisplays.isEmpty()) {
            return loadedDisplays;
        }
        ConfigurationSection legacyDisplay = config.getConfigurationSection("nametags.display");
        if (legacyDisplay != null) {
            loadedDisplays.add(new TagDisplayConfig("tag-1", legacyDisplay));
        }
        return loadedDisplays;
    }
}
