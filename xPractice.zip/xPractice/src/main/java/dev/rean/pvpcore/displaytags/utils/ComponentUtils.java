package dev.rean.pvpcore.displaytags.utils;

import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/utils/ComponentUtils.class */
public class ComponentUtils {
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_SERIALIZER = LegacyComponentSerializer.builder().character('&').useUnusualXRepeatedCharacterHexFormat().build();
    private static final JoinConfiguration joinConfig = JoinConfiguration.separator(Component.newline());

    public static Component format(String input) {
        String strReplace;
        if (input.indexOf(167) != -1) {
            strReplace = input.replace((char) 167, '&');
        } else {
            strReplace = input;
        }
        String sanitized = strReplace;
        String modern = ((String) MINI_MESSAGE.serialize(LEGACY_SERIALIZER.deserialize(sanitized))).replace("\\", "");
        return MINI_MESSAGE.deserialize(modern);
    }

    public static Component join(List<Component> components) {
        return Component.join(joinConfig, components);
    }
}
