package dev.rean.pvpcore.playerdata;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/playerdata/PlayerStatus.class */
public enum PlayerStatus {
    ONLINE("&a", "Online"),
    INVISIBLE("&7", "Invisible"),
    DND("&c", "Do Not Disturb");

    private final String colorCode;
    private final String displayName;

    PlayerStatus(String colorCode, String displayName) {
        this.colorCode = colorCode;
        this.displayName = displayName;
    }

    public String colorCode() {
        return this.colorCode;
    }

    public String displayName() {
        return this.displayName;
    }

    public PlayerStatus next() {
        PlayerStatus[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    public static PlayerStatus fromString(String input) {
        if (input == null || input.isBlank()) {
            return ONLINE;
        }
        for (PlayerStatus status : values()) {
            if (status.name().equalsIgnoreCase(input)) {
                return status;
            }
        }
        return ONLINE;
    }
}
