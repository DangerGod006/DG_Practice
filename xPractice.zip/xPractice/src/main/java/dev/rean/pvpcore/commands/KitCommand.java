package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.managers.KitManager;
import dev.rean.pvpcore.model.Kit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/KitCommand.class */
public final class KitCommand implements CommandExecutor, TabCompleter {
    private final PvPCorePlugin plugin;
    private final KitManager kits;

    public KitCommand(PvPCorePlugin plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String usage;
        if (!sender.hasPermission("pvpcore.kit")) {
            this.plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (args.length == 0) {
            sendUsage(commandSender);
            return true;
        }
        if (args[0].equalsIgnoreCase("blacklist")) {
            if (args.length < 3) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-blacklist");
                return true;
            }
            String kitId = args[1];
            if (this.kits.get(kitId) == null) {
                commandSender.sendMessage(this.plugin.messages().format("&cKit not found: &f" + kitId, Map.of()));
                return true;
            }
            String action = args[2];
            if (action.equalsIgnoreCase("list")) {
                Set<String> list = this.plugin.arenaManager().listKitBlacklist(kitId);
                commandSender.sendMessage(this.plugin.messages().format("&eBlacklist for &f" + kitId + "&e: &f" + (list.isEmpty() ? "(empty)" : String.join(", ", list)), Map.of()));
                return true;
            }
            if (args.length < 4) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-blacklist-edit");
                return true;
            }
            String entry = args[3];
            if (action.equalsIgnoreCase("add")) {
                this.plugin.arenaManager().addKitBlacklist(kitId, entry);
                commandSender.sendMessage(this.plugin.messages().format("&aAdded to blacklist: &f" + entry + " &afor kit &f" + kitId, Map.of()));
                return true;
            }
            if (action.equalsIgnoreCase("remove")) {
                if (!this.plugin.arenaManager().removeKitBlacklist(kitId, entry)) {
                    commandSender.sendMessage(this.plugin.messages().format("&cThat entry was not blacklisted.", Map.of()));
                    return true;
                }
                commandSender.sendMessage(this.plugin.messages().format("&aRemoved from blacklist: &f" + entry + " &afor kit &f" + kitId, Map.of()));
                return true;
            }
            this.plugin.messages().send(commandSender, "commands.kit.usage-blacklist");
            return true;
        }
        if (args[0].equalsIgnoreCase("attribute")) {
            if (args.length < 4) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-attribute");
                return true;
            }
            Kit kit = this.kits.get(args[1]);
            if (kit == null) {
                commandSender.sendMessage(this.plugin.messages().format("&cKit not found: &f" + args[1], Map.of()));
                return true;
            }
            String attribute = args[2];
            if (attribute.equalsIgnoreCase("consoleCommand") || attribute.equalsIgnoreCase("hideTag") || attribute.equalsIgnoreCase("info") || attribute.equalsIgnoreCase("gamemode") || attribute.equalsIgnoreCase("gameMode") || attribute.equalsIgnoreCase("break-blocks") || attribute.equalsIgnoreCase("breakBlocks") || attribute.equalsIgnoreCase("explode-blocks") || attribute.equalsIgnoreCase("explodeBlocks")) {
                String value = String.join(" ", (CharSequence[]) Arrays.copyOfRange(args, 3, args.length)).trim();
                if (value.isEmpty()) {
                    if (attribute.equalsIgnoreCase("hideTag")) {
                        usage = "&cYou must enter one or more tag ids separated by commas, or use clear.";
                    } else if (attribute.equalsIgnoreCase("info")) {
                        usage = "&cYou must enter one or more info ids separated by commas (totems,pots,hp,armoravg,xp), or use clear.";
                    } else if (attribute.equalsIgnoreCase("gamemode") || attribute.equalsIgnoreCase("gameMode")) {
                        usage = "&cYou must enter survival or adventure.";
                    } else if (attribute.equalsIgnoreCase("break-blocks") || attribute.equalsIgnoreCase("breakBlocks") || attribute.equalsIgnoreCase("explode-blocks") || attribute.equalsIgnoreCase("explodeBlocks")) {
                        usage = "&cYou must enter one or more block materials separated by commas, or use clear.";
                    } else {
                        usage = "&cYou must enter a command or use clear to remove it.";
                    }
                    commandSender.sendMessage(this.plugin.messages().format(usage, Map.of()));
                    return true;
                }
                if (attribute.equalsIgnoreCase("gamemode") || attribute.equalsIgnoreCase("gameMode")) {
                    String normalizedGameMode = value.toLowerCase(Locale.ROOT);
                    if (!normalizedGameMode.equals("survival") && !normalizedGameMode.equals("adventure")) {
                        commandSender.sendMessage(this.plugin.messages().format("&cInvalid gamemode. Use survival or adventure.", Map.of()));
                        return true;
                    }
                }
                if (!this.kits.setStringAttribute(kit.id(), attribute, value)) {
                    commandSender.sendMessage(this.plugin.messages().format("&cThe attribute could not be saved.", Map.of()));
                    return true;
                }
                commandSender.sendMessage(this.plugin.messages().format("&aAttribute &f" + attribute + " &aupdated for kit &f" + kit.id(), Map.of()));
                return true;
            }
            if (!attribute.equalsIgnoreCase("naturalRegen") && !attribute.equalsIgnoreCase("naturalSaturationDecrease")) {
                commandSender.sendMessage(this.plugin.messages().format("&cInvalid attribute. Use: naturalRegen, naturalSaturationDecrease, consoleCommand, hideTag, info, gamemode, break-blocks or explode-blocks", Map.of()));
                return true;
            }
            String raw = args[3].toLowerCase(Locale.ROOT);
            if (!raw.equals("true") && !raw.equals("false")) {
                commandSender.sendMessage(this.plugin.messages().format("&cInvalid value. Use true or false.", Map.of()));
                return true;
            }
            boolean value2 = Boolean.parseBoolean(raw);
            if (!this.kits.setBooleanAttribute(kit.id(), attribute, value2)) {
                commandSender.sendMessage(this.plugin.messages().format("&cThe attribute could not be saved.", Map.of()));
                return true;
            }
            commandSender.sendMessage(this.plugin.messages().format("&aAttribute &f" + attribute + " &aupdated to &f" + value2 + " &afor kit &f" + kit.id(), Map.of()));
            return true;
        }
        if (args[0].equalsIgnoreCase("editgui")) {
            this.plugin.kitEditorManager().openEditSelector(commandSender);
            return true;
        }
        if (args[0].equalsIgnoreCase("edit")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-edit");
                return true;
            }
            Kit kit2 = this.kits.get(args[1]);
            if (kit2 == null) {
                commandSender.sendMessage(this.plugin.messages().format("&cKit not found: &f" + args[1], Map.of()));
                return true;
            }
            this.plugin.kitEditorManager().open(commandSender, kit2);
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            List<Kit> list2 = this.kits.list();
            this.plugin.messages().send(commandSender, "kits.list-header", Map.of("count", String.valueOf(list2.size())));
            for (Kit k : list2) {
                this.plugin.messages().send(commandSender, "kits.list-line", Map.of("id", k.id(), "name", k.displayName()));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("create")) {
            if (args.length < 3) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-create");
                return true;
            }
            String id = args[1];
            String name = String.join(" ", (CharSequence[]) Arrays.copyOfRange(args, 2, args.length));
            if (this.kits.get(id) != null) {
                commandSender.sendMessage(this.plugin.messages().format("&cA kit with id '&f%kit_id%&c' already exists. Use &f/kit update %kit_id%&c instead.", Map.of("kit_id", id)));
                return true;
            }
            this.kits.createFromPlayer(commandSender, id, name);
            return true;
        }
        if (args[0].equalsIgnoreCase("update")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-update");
                return true;
            }
            this.kits.updateFromPlayer(commandSender, args[1]);
            return true;
        }
        if (args[0].equalsIgnoreCase("seticon")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-seticon");
                return true;
            }
            this.kits.setIconFromHand(commandSender, args[1]);
            return true;
        }
        if (args[0].equalsIgnoreCase("remove")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "commands.kit.usage-remove");
                return true;
            }
            this.kits.remove(commandSender, args[1]);
            return true;
        }
        sendUsage(commandSender);
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!sender.hasPermission("pvpcore.kit")) {
            return List.of();
        }
        if (args.length == 1) {
            return partial(args[0], List.of("create", "update", "remove", "seticon", "list", "blacklist", "attribute", "edit", "editgui"));
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("update") || args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("seticon") || args[0].equalsIgnoreCase("blacklist") || args[0].equalsIgnoreCase("attribute") || args[0].equalsIgnoreCase("edit"))) {
            return partial(args[1], kitIds());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("attribute")) {
            return partial(args[2], List.of("naturalRegen", "naturalSaturationDecrease", "consoleCommand", "hideTag", "info", "gamemode", "break-blocks", "explode-blocks"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("attribute") && args[2].equalsIgnoreCase("info")) {
            return partial(args[3], List.of("totems", "pots", "hp", "armoravg", "xp", "clear"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("attribute") && (args[2].equalsIgnoreCase("gamemode") || args[2].equalsIgnoreCase("gameMode"))) {
            return partial(args[3], List.of("survival", "adventure"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("attribute") && (args[2].equalsIgnoreCase("break-blocks") || args[2].equalsIgnoreCase("breakBlocks") || args[2].equalsIgnoreCase("explode-blocks") || args[2].equalsIgnoreCase("explodeBlocks"))) {
            return partial(args[3], List.of("SHULKER_BOX", "STONE", "ANDESITE", "OBSIDIAN", "RESPAWN_ANCHOR", "clear"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("attribute") && !args[2].equalsIgnoreCase("consoleCommand") && !args[2].equalsIgnoreCase("hideTag") && !args[2].equalsIgnoreCase("info") && !args[2].equalsIgnoreCase("gamemode") && !args[2].equalsIgnoreCase("gameMode") && !args[2].equalsIgnoreCase("break-blocks") && !args[2].equalsIgnoreCase("breakBlocks") && !args[2].equalsIgnoreCase("explode-blocks") && !args[2].equalsIgnoreCase("explodeBlocks")) {
            return partial(args[3], List.of("true", "false"));
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("blacklist")) {
            return partial(args[2], List.of("add", "list", "remove"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("blacklist") && !args[2].equalsIgnoreCase("list")) {
            List<String> options = new ArrayList<>(this.plugin.arenaManager().categoryIds());
            options.addAll(this.plugin.arenaManager().all().stream().map((v0) -> {
                return v0.id();
            }).toList());
            return partial(args[3], options);
        }
        return List.of();
    }

    private void sendUsage(Player player) {
        this.plugin.messages().send(player, "commands.kit.usage");
    }

    private List<String> kitIds() {
        return (List) this.kits.list().stream().map((v0) -> {
            return v0.id();
        }).sorted().collect(Collectors.toList());
    }

    private List<String> partial(String token, List<String> options) {
        String t = token.toLowerCase(Locale.ROOT);
        return options.stream().filter(s -> {
            return s.toLowerCase(Locale.ROOT).startsWith(t);
        }).toList();
    }
}
