package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.integrations.ProtectionHook;
import dev.rean.pvpcore.model.Arena;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerMoveEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/DuelSafetyListener.class */
public final class DuelSafetyListener implements Listener {
    private final PvPCorePlugin plugin;
    private final ProtectionHook protectionHook;

    public DuelSafetyListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
        this.protectionHook = ProtectionHook.create(plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickSafetyCheck, 10L, 10L);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Location to = event.getTo();
        if (to == null || sameBlock(event.getFrom(), to)) {
            return;
        }
        Player player = event.getPlayer();
        DuelMatch match = this.plugin.duelManager().getMatch(player.getUniqueId());
        if (match != null) {
            if (isUnsafe(to)) {
                Location from = event.getFrom();
                if (!isUnsafe(from)) {
                    event.setTo(from);
                    return;
                } else {
                    match.teleportToOpponent(player);
                    return;
                }
            }
            return;
        }
        if (this.plugin.spectatorManager().isSpectating(player.getUniqueId()) && isUnsafe(to)) {
            this.plugin.spectatorManager().teleportToMatch(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        DuelMatch match = this.plugin.duelManager().getMatch(player.getUniqueId());
        if (match == null) {
            return;
        }
        if (!match.isFighting()) {
            event.setCancelled(true);
            return;
        }
        Material material = event.getBlock().getType();
        if (match.kit() == null || !match.kit().canBreakBlock(material)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        filterExplosionBlocks(event.getLocation(), event.blockList(), event.getEntity());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        filterExplosionBlocks(event.getBlock().getLocation(), event.blockList(), null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSuffocation(EntityDamageEvent event) {
        Player entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = entity;
            if (event.getCause() == EntityDamageEvent.DamageCause.SUFFOCATION && isUnsafe(player.getLocation())) {
                DuelMatch match = this.plugin.duelManager().getMatch(player.getUniqueId());
                if (match != null) {
                    event.setCancelled(true);
                    match.teleportToOpponent(player);
                } else if (this.plugin.spectatorManager().isSpectating(player.getUniqueId())) {
                    event.setCancelled(true);
                    this.plugin.spectatorManager().teleportToMatch(player);
                }
            }
        }
    }

    private void filterExplosionBlocks(Location explosionLocation, List<Block> blocks, Entity source) {
        DuelMatch match = matchAt(explosionLocation);
        if (match == null) {
            return;
        }
        if (!match.isFighting() || match.kit() == null) {
            blocks.clear();
        } else {
            blocks.removeIf(block -> {
                return (insideArena(match.arena(), block.getLocation()) && match.kit().canExplodeBlock(block.getType()) && this.protectionHook.canExplosionBreak(block, source)) ? false : true;
            });
        }
    }

    private DuelMatch matchAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        for (DuelMatch match : this.plugin.duelManager().activeMatches()) {
            if (match != null && insideArena(match.arena(), location)) {
                return match;
            }
        }
        return null;
    }

    private boolean insideArena(Arena arena, Location location) {
        if (arena == null || location == null || location.getWorld() == null) {
            return false;
        }
        if (arena.world() != null && !arena.world().equals(location.getWorld())) {
            return false;
        }
        Location min = arena.min();
        Location max = arena.max();
        if (min == null || max == null || min.getWorld() == null || max.getWorld() == null) {
            return arena.world() == null || arena.world().equals(location.getWorld());
        }
        if (!min.getWorld().equals(location.getWorld()) || !max.getWorld().equals(location.getWorld())) {
            return false;
        }
        int x = location.getBlockX();
        int y = location.getBlockY();
        int z = location.getBlockZ();
        return x >= Math.min(min.getBlockX(), max.getBlockX()) && x <= Math.max(min.getBlockX(), max.getBlockX()) && y >= Math.min(min.getBlockY(), max.getBlockY()) && y <= Math.max(min.getBlockY(), max.getBlockY()) && z >= Math.min(min.getBlockZ(), max.getBlockZ()) && z <= Math.max(min.getBlockZ(), max.getBlockZ());
    }

    private void tickSafetyCheck() {
        for (DuelMatch match : this.plugin.duelManager().activeMatches()) {
            Player red = Bukkit.getPlayer(match.red());
            Player blue = Bukkit.getPlayer(match.blue());
            if (red != null && red.isOnline() && isUnsafe(red.getLocation())) {
                match.teleportToOpponent(red);
            }
            if (blue != null && blue.isOnline() && isUnsafe(blue.getLocation())) {
                match.teleportToOpponent(blue);
            }
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (this.plugin.spectatorManager().isSpectating(player.getUniqueId()) && isUnsafe(player.getLocation())) {
                this.plugin.spectatorManager().teleportToMatch(player);
            }
        }
    }

    private boolean isUnsafe(Location location) {
        if (location == null || location.getWorld() == null) {
            return false;
        }
        Block feet = location.getBlock();
        Block head = feet.getRelative(BlockFace.UP);
        return isBlocking(feet) || isBlocking(head);
    }

    private boolean sameBlock(Location from, Location to) {
        return from != null && to != null && from.getWorld() != null && to.getWorld() != null && from.getWorld().equals(to.getWorld()) && from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ();
    }

    private boolean isBlocking(Block block) {
        if (block == null) {
            return false;
        }
        Material type = block.getType();
        return type == Material.BARRIER || type == Material.BEDROCK;
    }
}
