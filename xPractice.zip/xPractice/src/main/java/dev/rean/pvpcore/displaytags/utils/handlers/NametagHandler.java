package dev.rean.pvpcore.displaytags.utils.handlers;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerTeams;
import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.utils.helpers.DependencyHelper;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.event.EventBus;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.nametag.NameTagManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/utils/handlers/NametagHandler.class */
public class NametagHandler {
    public static void load() {
        EventBus eventBus;
        if (!DependencyHelper.isTABEnabled() || (eventBus = TabAPI.getInstance().getEventBus()) == null) {
            return;
        }
        eventBus.register(PlayerLoadEvent.class, event -> {
            TabPlayer player = event.getPlayer();
            NameTagManager manager = TabAPI.getInstance().getNameTagManager();
            if (manager != null && DisplayTags.getInstance().config().getNametagConfig().isEnabled()) {
                manager.hideNameTag(player);
            }
        });
    }

    public static void hide(Player target, Player viewer) {
        if (!DependencyHelper.isTABEnabled() || TabAPI.getInstance().getNameTagManager() == null) {
            String name = getTeamName(target);
            WrapperPlayServerTeams.ScoreBoardTeamInfo teamInfo = new WrapperPlayServerTeams.ScoreBoardTeamInfo(Component.empty(), Component.empty(), Component.empty(), WrapperPlayServerTeams.NameTagVisibility.NEVER, WrapperPlayServerTeams.CollisionRule.ALWAYS, (NamedTextColor) null, WrapperPlayServerTeams.OptionData.NONE);
            WrapperPlayServerTeams packet = new WrapperPlayServerTeams(name, WrapperPlayServerTeams.TeamMode.CREATE, teamInfo, new String[]{target.getName()});
            sendPacket(packet, viewer);
        }
    }

    public static void show(Player target, Player viewer) {
        if (!DependencyHelper.isTABEnabled() || TabAPI.getInstance().getNameTagManager() == null) {
            String name = getTeamName(target);
            WrapperPlayServerTeams packet = new WrapperPlayServerTeams(name, WrapperPlayServerTeams.TeamMode.REMOVE, (WrapperPlayServerTeams.ScoreBoardTeamInfo) null, new String[]{target.getName()});
            sendPacket(packet, viewer);
        }
    }

    private static String getTeamName(Player target) {
        return "displaytags_" + target.getEntityId();
    }

    private static void sendPacket(PacketWrapper<?> packet, Player viewer) {
        PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, packet);
    }
}
