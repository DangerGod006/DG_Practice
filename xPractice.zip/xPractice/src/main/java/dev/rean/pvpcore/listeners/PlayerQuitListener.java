package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.duel.DuelManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/PlayerQuitListener.class */
public final class PlayerQuitListener implements Listener {
    private final DuelManager duels;

    public PlayerQuitListener(DuelManager duels) {
        this.duels = duels;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        this.duels.removePlayer(e.getPlayer().getUniqueId());
    }
}
