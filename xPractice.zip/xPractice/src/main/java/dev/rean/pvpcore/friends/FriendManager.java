package dev.rean.pvpcore.friends;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.playerdata.PlayerDataManager;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/friends/FriendManager.class */
public final class FriendManager {
    private final PvPCorePlugin plugin;
    private final PlayerDataManager playerData;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    public FriendManager(PvPCorePlugin plugin, PlayerDataManager playerData) {
        this.plugin = plugin;
        this.playerData = playerData;
    }

    public boolean sendRequest(Player sender, Player target) {
        if (sender == null || target == null) {
            return false;
        }
        if (sender.getUniqueId().equals(target.getUniqueId())) {
            send(sender, "friends.self", "<red>✘ You cannot add yourself.</red>", resolver(sender, target));
            return false;
        }
        if (!this.playerData.canReceiveFriendRequests(target.getUniqueId())) {
            send(sender, "friends.target-disabled", "<red>✘ That player is not accepting friend requests right now.</red>", resolver(sender, target));
            return false;
        }
        if (this.playerData.areFriends(sender.getUniqueId(), target.getUniqueId())) {
            send(sender, "friends.already", "<yellow>✉ You are already friends with <target>.</yellow>", resolver(sender, target));
            return false;
        }
        if (this.playerData.hasOutgoingFriendRequest(sender.getUniqueId(), target.getUniqueId())) {
            send(sender, "friends.request-already-sent", "<yellow>✉ You already sent a friend request to <target>.</yellow>", resolver(sender, target));
            return false;
        }
        if (this.playerData.hasIncomingFriendRequest(sender.getUniqueId(), target.getUniqueId())) {
            return acceptRequest(sender, target.getName());
        }
        this.playerData.addFriendRequest(sender.getUniqueId(), sender.getName(), target.getUniqueId(), target.getName());
        TagResolver resolver = resolver(sender, target);
        send(sender, "friends.request-sent", "<green>✔ Friend request sent to <target><green>.</green>", resolver);
        send(target, "friends.request-received", "<yellow>✉ <sender> <yellow>sent you a friend request. Use <white>/friend accept " + sender.getName() + "</white>.</yellow>", resolver);
        return true;
    }

    public boolean acceptRequest(Player receiver, String senderName) {
        Component componentText;
        if (receiver == null || senderName == null || senderName.isBlank()) {
            return false;
        }
        UUID senderId = findIncomingRequestUuid(receiver.getUniqueId(), senderName);
        if (senderId == null) {
            send(receiver, "friends.request-not-found", "<red>✘ No pending friend request from that player was found.</red>", selfResolver(receiver));
            return false;
        }
        Player sender = Bukkit.getPlayer(senderId);
        String resolvedSenderName = sender != null ? sender.getName() : this.playerData.getIncomingFriendRequestName(receiver.getUniqueId(), senderId);
        this.playerData.addFriendRelation(receiver.getUniqueId(), receiver.getName(), senderId, resolvedSenderName);
        if (sender != null) {
            componentText = this.playerData.getDisplayNameComponent(sender);
        } else {
            componentText = Component.text(resolvedSenderName == null ? senderName : resolvedSenderName);
        }
        Component senderComponent = componentText;
        TagResolver[] tagResolverArr = new TagResolver[4];
        tagResolverArr[0] = Placeholder.component("sender", senderComponent);
        tagResolverArr[1] = Placeholder.component("target", senderComponent);
        tagResolverArr[2] = Placeholder.unparsed("sender_name", resolvedSenderName == null ? senderName : resolvedSenderName);
        tagResolverArr[3] = Placeholder.unparsed("target_name", resolvedSenderName == null ? senderName : resolvedSenderName);
        TagResolver receiverResolver = TagResolver.resolver(tagResolverArr);
        send(receiver, "friends.request-accepted", "<green>✔ You accepted <sender><green>'s friend request.</green>", receiverResolver);
        if (sender != null) {
            send(sender, "friends.request-accepted-target", "<green>✔ <target> <green>accepted your friend request.</green>", resolver(sender, receiver));
            return true;
        }
        return true;
    }

    public boolean denyRequest(Player receiver, String senderName) {
        if (receiver == null || senderName == null || senderName.isBlank()) {
            return false;
        }
        UUID senderId = findIncomingRequestUuid(receiver.getUniqueId(), senderName);
        if (senderId == null) {
            send(receiver, "friends.request-not-found", "<red>✘ No pending friend request from that player was found.</red>", selfResolver(receiver));
            return false;
        }
        String resolvedName = this.playerData.getIncomingFriendRequestName(receiver.getUniqueId(), senderId);
        this.playerData.removeFriendRequest(senderId, receiver.getUniqueId());
        send(receiver, "friends.request-denied", "<yellow>✉ Friend request from <target> <yellow>denied.</yellow>", Placeholder.component("target", Component.text(resolvedName)));
        Player sender = Bukkit.getPlayer(senderId);
        if (sender != null) {
            send(sender, "friends.request-denied-target", "<yellow>✉ <target> <yellow>denied your friend request.</yellow>", resolver(sender, receiver));
            return true;
        }
        return true;
    }

    public boolean cancelRequest(Player sender, String targetName) {
        if (sender == null || targetName == null || targetName.isBlank()) {
            return false;
        }
        UUID targetId = findOutgoingRequestUuid(sender.getUniqueId(), targetName);
        if (targetId == null) {
            send(sender, "friends.outgoing-not-found", "<red>✘ You do not have a pending request to that player.</red>", selfResolver(sender));
            return false;
        }
        String resolvedName = this.playerData.getOutgoingFriendRequestName(sender.getUniqueId(), targetId);
        this.playerData.removeFriendRequest(sender.getUniqueId(), targetId);
        send(sender, "friends.request-cancelled", "<yellow>✉ Cancelled friend request to <target><yellow>.</yellow>", Placeholder.component("target", Component.text(resolvedName)));
        return true;
    }

    public boolean removeRelationOrRequest(Player sender, String targetName) {
        if (sender == null || targetName == null || targetName.isBlank()) {
            return false;
        }
        UUID friend = findFriendUuid(sender.getUniqueId(), targetName);
        if (friend != null) {
            return removeFriend(sender, targetName);
        }
        UUID outgoing = findOutgoingRequestUuid(sender.getUniqueId(), targetName);
        if (outgoing != null) {
            String resolvedName = this.playerData.getOutgoingFriendRequestName(sender.getUniqueId(), outgoing);
            this.playerData.removeFriendRequest(sender.getUniqueId(), outgoing);
            send(sender, "friends.request-cancelled", "<yellow>✉ Cancelled friend request to <target><yellow>.</yellow>", Placeholder.component("target", Component.text(resolvedName == null ? targetName : resolvedName)));
            return true;
        }
        UUID incoming = findIncomingRequestUuid(sender.getUniqueId(), targetName);
        if (incoming != null) {
            String resolvedName2 = this.playerData.getIncomingFriendRequestName(sender.getUniqueId(), incoming);
            this.playerData.removeFriendRequest(incoming, sender.getUniqueId());
            send(sender, "friends.request-denied", "<yellow>✉ Removed friend request from <target><yellow>.</yellow>", Placeholder.component("target", Component.text(resolvedName2 == null ? targetName : resolvedName2)));
            Player requester = Bukkit.getPlayer(incoming);
            if (requester != null) {
                send(requester, "friends.request-denied-target", "<yellow>✉ <target> <yellow>removed your friend request.</yellow>", resolver(requester, sender));
                return true;
            }
            return true;
        }
        send(sender, "friends.not-found", "<red>✘ No friend or pending request was found with that name.</red>", selfResolver(sender));
        return false;
    }

    public boolean addFriend(Player sender, Player target) {
        return sendRequest(sender, target);
    }

    public boolean removeFriend(Player sender, String targetName) {
        Component componentText;
        if (sender == null || targetName == null || targetName.isBlank()) {
            return false;
        }
        UUID match = findFriendUuid(sender.getUniqueId(), targetName);
        if (match == null) {
            send(sender, "friends.not-friends", "<red>✘ That player is not in your friends list.</red>", selfResolver(sender));
            return false;
        }
        String resolvedName = this.playerData.getFriendDisplayName(sender.getUniqueId(), match);
        this.playerData.removeFriendRelation(sender.getUniqueId(), match);
        Player online = Bukkit.getPlayer(match);
        if (online != null) {
            componentText = this.playerData.getDisplayNameComponent(online);
        } else {
            componentText = Component.text(resolvedName == null ? targetName : resolvedName);
        }
        Component targetComponent = componentText;
        send(sender, "friends.removed", "<yellow>✉ Removed <target> <yellow>from your friends.</yellow>", Placeholder.component("target", targetComponent));
        if (online != null) {
            send(online, "friends.removed-target", "<yellow>✉ <sender> <yellow>removed you from their friends.</yellow>", Placeholder.component("sender", this.playerData.getDisplayNameComponent(sender)));
            return true;
        }
        return true;
    }

    public void listFriends(Player sender) {
        if (sender == null) {
            return;
        }
        List<FriendEntry> friends = friends(sender.getUniqueId());
        sender.sendMessage(this.miniMessage.deserialize(message("friends.list-header", "<gold>Friends <gray>(<white><count><gray>)</gray>"), Placeholder.unparsed("count", String.valueOf(friends.size()))));
        if (friends.isEmpty()) {
            send(sender, "friends.list-empty", "<gray>You do not have any friends added yet.</gray>", selfResolver(sender));
            return;
        }
        for (FriendEntry friend : friends) {
            Component display = friend.onlinePlayer() != null ? this.playerData.getDisplayNameComponent(friend.onlinePlayer()) : Component.text(friend.name());
            MiniMessage miniMessage = this.miniMessage;
            String strMessage = message("friends.list-line", "<status><name> <gray>-</gray> <state>");
            TagResolver[] tagResolverArr = new TagResolver[4];
            tagResolverArr[0] = Placeholder.parsed("status", friend.online() ? "<green>●</green> " : "<gray>●</gray> ");
            tagResolverArr[1] = Placeholder.component("name", display);
            tagResolverArr[2] = Placeholder.parsed("state", friend.online() ? "<green>Online</green>" : "<gray>Offline</gray>");
            tagResolverArr[3] = Placeholder.unparsed("name_plain", friend.name());
            sender.sendMessage(miniMessage.deserialize(strMessage, TagResolver.resolver(tagResolverArr)));
        }
    }

    public void listRequests(Player sender) {
        if (sender == null) {
            return;
        }
        List<RequestEntry> incoming = incomingRequests(sender.getUniqueId());
        List<RequestEntry> outgoing = outgoingRequests(sender.getUniqueId());
        sender.sendMessage(this.miniMessage.deserialize(message("friends.requests-header", "<gold>Friend Requests <gray>(<white><incoming> incoming<gray>, <white><outgoing> outgoing<gray>)</gray>"), TagResolver.resolver(new TagResolver[]{Placeholder.unparsed("incoming", String.valueOf(incoming.size())), Placeholder.unparsed("outgoing", String.valueOf(outgoing.size()))})));
        if (incoming.isEmpty() && outgoing.isEmpty()) {
            send(sender, "friends.requests-empty", "<gray>You do not have pending friend requests.</gray>", selfResolver(sender));
            return;
        }
        for (RequestEntry request : incoming) {
            sender.sendMessage(this.miniMessage.deserialize(message("friends.requests-incoming-line", "<green>Incoming</green> <gray>-</gray> <white><name></white> <gray>(/friend accept <name>)</gray>"), requestResolver(request)));
        }
        for (RequestEntry request2 : outgoing) {
            sender.sendMessage(this.miniMessage.deserialize(message("friends.requests-outgoing-line", "<yellow>Outgoing</yellow> <gray>-</gray> <white><name></white> <gray>(/friend remove <name>)</gray>"), requestResolver(request2)));
        }
    }

    public void notifyFriendJoin(Player joined) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.getUniqueId().equals(joined.getUniqueId()) && this.playerData.hasFriendJoinNotifierEnabled(viewer.getUniqueId()) && this.playerData.areFriends(viewer.getUniqueId(), joined.getUniqueId())) {
                viewer.sendMessage(this.miniMessage.deserialize(message("friends.join-notify", "<yellow>✉ Your friend <friend> <yellow>joined the server.</yellow>"), Placeholder.component("friend", this.playerData.getDisplayNameComponent(joined))));
            }
        }
    }

    public List<FriendEntry> friends(UUID owner) {
        List<FriendEntry> friends = new ArrayList<>();
        if (owner == null) {
            return friends;
        }
        for (UUID uuid : this.playerData.profile(owner).friends()) {
            Player online = Bukkit.getPlayer(uuid);
            boolean visibleOnline = online != null && online.isOnline();
            String name = this.playerData.getFriendDisplayName(owner, uuid);
            if (name == null || name.isBlank()) {
                name = resolveOfflineName(uuid);
            }
            friends.add(new FriendEntry(uuid, name, visibleOnline, visibleOnline ? online : null));
        }
        friends.sort(Comparator.comparing((v0) -> {
            return v0.online();
        }).reversed().thenComparing(e -> {
            return e.name().toLowerCase(Locale.ROOT);
        }));
        return friends;
    }

    public List<RequestEntry> incomingRequests(UUID owner) {
        List<RequestEntry> entries = new ArrayList<>();
        if (owner == null) {
            return entries;
        }
        for (UUID uuid : this.playerData.profile(owner).incomingFriendRequests()) {
            String name = this.playerData.getIncomingFriendRequestName(owner, uuid);
            if (name == null || name.isBlank()) {
                name = resolveOfflineName(uuid);
            }
            entries.add(new RequestEntry(uuid, name));
        }
        entries.sort(Comparator.comparing(e -> {
            return e.name().toLowerCase(Locale.ROOT);
        }));
        return entries;
    }

    public List<RequestEntry> outgoingRequests(UUID owner) {
        List<RequestEntry> entries = new ArrayList<>();
        if (owner == null) {
            return entries;
        }
        for (UUID uuid : this.playerData.profile(owner).outgoingFriendRequests()) {
            String name = this.playerData.getOutgoingFriendRequestName(owner, uuid);
            if (name == null || name.isBlank()) {
                name = resolveOfflineName(uuid);
            }
            entries.add(new RequestEntry(uuid, name));
        }
        entries.sort(Comparator.comparing(e -> {
            return e.name().toLowerCase(Locale.ROOT);
        }));
        return entries;
    }

    public UUID findFriendUuid(UUID owner, String input) {
        if (owner == null || input == null || input.isBlank()) {
            return null;
        }
        for (UUID friend : this.playerData.profile(owner).friends()) {
            if (matchesName(owner, friend, input, this.playerData.getFriendDisplayName(owner, friend))) {
                return friend;
            }
        }
        return null;
    }

    public UUID findIncomingRequestUuid(UUID owner, String input) {
        if (owner == null || input == null || input.isBlank()) {
            return null;
        }
        for (UUID sender : this.playerData.profile(owner).incomingFriendRequests()) {
            if (matchesName(owner, sender, input, this.playerData.getIncomingFriendRequestName(owner, sender))) {
                return sender;
            }
        }
        return null;
    }

    public UUID findOutgoingRequestUuid(UUID owner, String input) {
        if (owner == null || input == null || input.isBlank()) {
            return null;
        }
        for (UUID target : this.playerData.profile(owner).outgoingFriendRequests()) {
            if (matchesName(owner, target, input, this.playerData.getOutgoingFriendRequestName(owner, target))) {
                return target;
            }
        }
        return null;
    }

    private boolean matchesName(UUID owner, UUID candidate, String input, String storedName) {
        if (candidate == null || input == null || input.isBlank()) {
            return false;
        }
        if (candidate.toString().equalsIgnoreCase(input)) {
            return true;
        }
        if (storedName != null && storedName.equalsIgnoreCase(input)) {
            return true;
        }
        Player online = Bukkit.getPlayer(candidate);
        if (online != null && online.getName().equalsIgnoreCase(input)) {
            return true;
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayer(candidate);
        return offline.getName() != null && offline.getName().equalsIgnoreCase(input);
    }

    private String resolveOfflineName(UUID uniqueId) {
        OfflinePlayer offline = Bukkit.getOfflinePlayer(uniqueId);
        return offline.getName() != null ? offline.getName() : uniqueId.toString();
    }

    private String message(String path, String fallback) {
        return this.plugin.messages().rawString(path, fallback);
    }

    private TagResolver requestResolver(RequestEntry request) {
        String name = request == null ? "" : escape(request.name());
        return TagResolver.resolver(new TagResolver[]{Placeholder.unparsed("name", name), Placeholder.unparsed("player", name), Placeholder.unparsed("target_name", name), Placeholder.unparsed("sender_name", name)});
    }

    private void send(Player player, String path, String fallback, TagResolver resolver) {
        String raw = this.plugin.messages().rawString(path, fallback);
        player.sendMessage(this.miniMessage.deserialize(raw, resolver));
    }

    private TagResolver resolver(Player sender, Player target) {
        TagResolver[] tagResolverArr = new TagResolver[4];
        tagResolverArr[0] = Placeholder.component("sender", sender == null ? Component.empty() : this.playerData.getDisplayNameComponent(sender));
        tagResolverArr[1] = Placeholder.component("target", target == null ? Component.empty() : this.playerData.getDisplayNameComponent(target));
        tagResolverArr[2] = Placeholder.unparsed("sender_name", sender == null ? "" : sender.getName());
        tagResolverArr[3] = Placeholder.unparsed("target_name", target == null ? "" : target.getName());
        return TagResolver.resolver(tagResolverArr);
    }

    private TagResolver selfResolver(Player player) {
        TagResolver[] tagResolverArr = new TagResolver[4];
        tagResolverArr[0] = Placeholder.component("sender", player == null ? Component.empty() : this.playerData.getDisplayNameComponent(player));
        tagResolverArr[1] = Placeholder.component("target", player == null ? Component.empty() : this.playerData.getDisplayNameComponent(player));
        tagResolverArr[2] = Placeholder.unparsed("sender_name", player == null ? "" : player.getName());
        tagResolverArr[3] = Placeholder.unparsed("target_name", player == null ? "" : player.getName());
        return TagResolver.resolver(tagResolverArr);
    }

    private String escape(String value) {
        return value == null ? "" : value.replace("<", "&lt;").replace(">", "&gt;");
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/friends/FriendManager$FriendEntry.class */
    public static final class FriendEntry extends Record {
        private final UUID uniqueId;
        private final String name;
        private final boolean online;
        private final Player onlinePlayer;

        public FriendEntry(UUID uniqueId, String name, boolean online, Player onlinePlayer) {
            this.uniqueId = uniqueId;
            this.name = name;
            this.online = online;
            this.onlinePlayer = onlinePlayer;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, FriendEntry.class), FriendEntry.class, "uniqueId;name;online;onlinePlayer", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->name:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->online:Z", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->onlinePlayer:Lorg/bukkit/entity/Player;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, FriendEntry.class), FriendEntry.class, "uniqueId;name;online;onlinePlayer", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->name:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->online:Z", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->onlinePlayer:Lorg/bukkit/entity/Player;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, FriendEntry.class, Object.class), FriendEntry.class, "uniqueId;name;online;onlinePlayer", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->name:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->online:Z", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$FriendEntry;->onlinePlayer:Lorg/bukkit/entity/Player;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public UUID uniqueId() {
            return this.uniqueId;
        }

        public String name() {
            return this.name;
        }

        public boolean online() {
            return this.online;
        }

        public Player onlinePlayer() {
            return this.onlinePlayer;
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/friends/FriendManager$RequestEntry.class */
    public static final class RequestEntry extends Record {
        private final UUID uniqueId;
        private final String name;

        public RequestEntry(UUID uniqueId, String name) {
            this.uniqueId = uniqueId;
            this.name = name;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, RequestEntry.class), RequestEntry.class, "uniqueId;name", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->name:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, RequestEntry.class), RequestEntry.class, "uniqueId;name", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->name:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, RequestEntry.class, Object.class), RequestEntry.class, "uniqueId;name", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->uniqueId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/friends/FriendManager$RequestEntry;->name:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public UUID uniqueId() {
            return this.uniqueId;
        }

        public String name() {
            return this.name;
        }
    }
}
