package dev.rean.pvpcore.kits;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.gui.GenericGui;
import dev.rean.pvpcore.gui.GuiContext;
import dev.rean.pvpcore.gui.GuiKey;
import dev.rean.pvpcore.gui.GuiSession;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.HexColor;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/kits/KitEditorManager.class */
public final class KitEditorManager {
    public static final int SLOT_TOP_FILLER_LEFT = 0;
    public static final int SLOT_TOP_FILLER_MIDDLE = 1;
    public static final int HELMET_SLOT = 2;
    public static final int CHESTPLATE_SLOT = 3;
    public static final int LEGGINGS_SLOT = 4;
    public static final int BOOTS_SLOT = 5;
    public static final int OFFHAND_SLOT = 6;
    public static final int SLOT_TOP_FILLER_RIGHT = 7;
    public static final int BACK_SLOT = 8;
    public static final int INVENTORY_START = 9;
    public static final int INVENTORY_END = 35;
    public static final int[] DIVIDER_SLOTS = {36, 37, 38, 39, 40, 41, 42, 43, 44};
    public static final int HOTBAR_START = 45;
    public static final int HOTBAR_END = 53;
    private final PvPCorePlugin plugin;

    public KitEditorManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public void openEditSelector(Player player) {
        if (player == null) {
            return;
        }
        Kit defaultKit = this.plugin.kitManager().getFirstOrNull();
        if (defaultKit == null) {
            this.plugin.messages().send(player, "kit-editor.no-kits");
            return;
        }
        GuiSession session = new GuiSession(GuiKey.CONFIGURABLE, player, player, defaultKit);
        session.setContext(GuiContext.KIT_EDITOR);
        if (!GenericGui.open(this.plugin, player, player, session, "kit-editor-gui")) {
            this.plugin.messages().send(player, "kit-editor.open-failed");
        }
    }

    public void open(Player player, Kit baseKit) {
        if (player == null || baseKit == null) {
            return;
        }
        Kit effectiveKit = this.plugin.kitManager().getEditableKit(player.getUniqueId(), baseKit.id());
        Inventory inv = Bukkit.createInventory(new KitEditorHolder(player.getUniqueId(), baseKit.id()), 54, HexColor.color(this.plugin.messages().get("kit-editor.title", Map.of("kit", effectiveKit.displayName(), "kit_id", effectiveKit.id()))));
        inv.setItem(0, createHiddenBlackFiller());
        inv.setItem(1, createHiddenBlackFiller());
        inv.setItem(7, createHiddenBlackFiller());
        inv.setItem(8, createBackItem());
        ItemStack[] armor = effectiveKit.armor();
        inv.setItem(2, getArmorPieceOrPlaceholder(armor, 3, Material.LEATHER_HELMET, "&7Helmet"));
        inv.setItem(3, getArmorPieceOrPlaceholder(armor, 2, Material.LEATHER_CHESTPLATE, "&7Chestplate"));
        inv.setItem(4, getArmorPieceOrPlaceholder(armor, 1, Material.LEATHER_LEGGINGS, "&7Leggings"));
        inv.setItem(5, getArmorPieceOrPlaceholder(armor, 0, Material.LEATHER_BOOTS, "&7Boots"));
        ItemStack[] contents = effectiveKit.contents();
        for (int slot = 9; slot <= 35; slot++) {
            int storageIndex = slot;
            inv.setItem(slot, getContent(contents, storageIndex));
        }
        for (int slot2 : DIVIDER_SLOTS) {
            inv.setItem(slot2, createInventoryDivider());
        }
        for (int slot3 = 45; slot3 <= 53; slot3++) {
            int storageIndex2 = slot3 - 45;
            inv.setItem(slot3, getContent(contents, storageIndex2));
        }
        inv.setItem(6, createDisplayedOffhand(effectiveKit.offhand()));
        player.openInventory(inv);
    }

    private ItemStack getContent(ItemStack[] contents, int index) {
        if (contents == null || index < 0 || index >= contents.length || contents[index] == null) {
            return null;
        }
        return contents[index].clone();
    }

    private ItemStack getArmorPieceOrPlaceholder(ItemStack[] armor, int index, Material material, String name) {
        if (armor != null && index >= 0 && index < armor.length && armor[index] != null && !armor[index].getType().isAir()) {
            return armor[index].clone();
        }
        return null;
    }

    public ItemStack createDisplayedOffhand(ItemStack offhand) {
        if (offhand != null && !offhand.getType().isAir()) {
            return offhand.clone();
        }
        return createOffhandPlaceholder();
    }

    public boolean isOffhandPlaceholder(ItemStack item) {
        ItemMeta meta;
        String stripped;
        return item != null && item.getType() == Material.ITEM_FRAME && (meta = item.getItemMeta()) != null && meta.hasDisplayName() && (stripped = ChatColor.stripColor(meta.getDisplayName())) != null && stripped.contains("Offhand");
    }

    private ItemStack createOffhandPlaceholder() {
        ItemStack item = new ItemStack(Material.ITEM_FRAME);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(HexColor.color("&6⛨ Offhand"));
            meta.setLore(List.of(HexColor.color("&7ℹ Items can be move into this slot.")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createHiddenBlackFiller() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP});
            tryHideTooltip(meta);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createInventoryDivider() {
        ItemStack item = new ItemStack(Material.CYAN_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(HexColor.color("&7▲ Inventory"));
            meta.setLore(List.of(HexColor.color("&7▼ Hotbar")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createBackItem() {
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(HexColor.color("&c◀ &7Back"));
            meta.setLore(List.of(HexColor.color("&#777777(Saves your kit)")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private void tryHideTooltip(ItemMeta meta) {
        try {
            meta.setHideTooltip(true);
        } catch (Throwable th) {
        }
    }
}
