package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.managers.ArenaManager;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.playerdata.PlayerStatus;
import dev.rean.pvpcore.util.ClickCooldown;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiListener.class */
public final class GuiListener implements Listener {
    private static final long MENU_CLICK_COOLDOWN_MS = 100;
    private final PvPCorePlugin plugin;
    private final DuelManager duels;
    private final ClickCooldown menuClickCooldown = new ClickCooldown(MENU_CLICK_COOLDOWN_MS);

    public GuiListener(PvPCorePlugin plugin, DuelManager duels) {
        this.plugin = plugin;
        this.duels = duels;
    }

    private GuiSession sessionOrNull(Inventory topInv) {
        if (topInv == null) {
            return null;
        }
        InventoryHolder holder = topInv.getHolder();
        if (!(holder instanceof ReanMenuHolder)) {
            return null;
        }
        ReanMenuHolder holder2 = (ReanMenuHolder) holder;
        return holder2.session();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        ConfigurationSection root;
        ConfigurationSection items;
        CommandSender whoClicked = e.getWhoClicked();
        if (whoClicked instanceof Player) {
            CommandSender commandSender = (Player) whoClicked;
            GuiSession session = sessionOrNull(e.getView().getTopInventory());
            if (session == null) {
                return;
            }
            e.setCancelled(true);
            if (this.menuClickCooldown.test(commandSender.getUniqueId())) {
                YamlConfiguration cfg = GenericGui.loadInventories(this.plugin);
                if (session.key() == GuiKey.CONFIGURABLE) {
                    handleConfigurableClick(commandSender, e.getRawSlot(), e.getClick(), session, cfg);
                    return;
                }
                if (session.key() == GuiKey.KIT_SELECT) {
                    ConfigurationSection root2 = cfg.getConfigurationSection("kit-select-gui");
                    if (root2 == null) {
                        return;
                    }
                    List<Integer> slots = root2.getIntegerList("kit-slots");
                    if (slots == null || slots.isEmpty()) {
                        slots = List.of(10, 11, 12, 13, 14, 15, 16);
                    }
                    int index = slots.indexOf(Integer.valueOf(e.getRawSlot()));
                    if (index < 0) {
                        return;
                    }
                    List<Kit> kits = this.plugin.kitManager().list();
                    if (index >= kits.size()) {
                        return;
                    }
                    session.setSelectedKit(kits.get(index));
                    playValidClick(commandSender, e.getCurrentItem());
                    Player target = Bukkit.getPlayer(session.target());
                    if (target == null) {
                        this.plugin.messages().send(commandSender, "duels.offline");
                        commandSender.closeInventory();
                        return;
                    } else {
                        DuelRequestGui.open(this.plugin, commandSender, target, session);
                        return;
                    }
                }
                if (session.key() == GuiKey.DUEL_REQUEST) {
                    ConfigurationSection root3 = cfg.getConfigurationSection("duel-request-gui");
                    if (root3 == null || (items = root3.getConfigurationSection("items")) == null) {
                        return;
                    }
                    int kitSlot = items.getInt("kit.slot", 13);
                    int roundsSlot = items.getInt("rounds.slot", 14);
                    int confirmSlot = items.getInt("confirm.slot", 26);
                    int slot = e.getRawSlot();
                    Player target2 = Bukkit.getPlayer(session.target());
                    if (target2 == null) {
                        this.plugin.messages().send(commandSender, "duels.offline");
                        commandSender.closeInventory();
                        return;
                    }
                    if (slot == kitSlot) {
                        playValidClick(commandSender, commandSender.getOpenInventory().getTopInventory().getItem(slot));
                        KitSelectGui.open(this.plugin, commandSender, target2, session);
                        return;
                    } else if (slot == roundsSlot) {
                        playValidClick(commandSender, commandSender.getOpenInventory().getTopInventory().getItem(slot));
                        RoundSelectGui.open(this.plugin, commandSender, session, target2.getName());
                        return;
                    } else {
                        if (slot == confirmSlot) {
                            playValidClick(commandSender, commandSender.getOpenInventory().getTopInventory().getItem(slot));
                            this.duels.createAndSendRequest(commandSender, target2, session.selectedKit(), session.firstTo(), session.selectedArena());
                            commandSender.closeInventory();
                            return;
                        }
                        return;
                    }
                }
                if (session.key() != GuiKey.ROUND_SELECT || (root = cfg.getConfigurationSection("rounds-select-gui")) == null) {
                    return;
                }
                List<Integer> slots2 = root.getIntegerList("option-slots");
                if (slots2 == null || slots2.isEmpty()) {
                    slots2 = List.of(10, 11, 12, 13, 14);
                }
                List<Integer> values = root.getIntegerList("values");
                if (values == null || values.isEmpty()) {
                    values = List.of(1, 3, 5, 7, 9);
                }
                int clicked = e.getRawSlot();
                int idx = slots2.indexOf(Integer.valueOf(clicked));
                if (idx >= 0 && idx < values.size()) {
                    session.setFirstTo(values.get(idx).intValue());
                    playValidClick(commandSender, commandSender.getOpenInventory().getTopInventory().getItem(clicked));
                    CommandSender player = session.context() == GuiContext.QUEUE ? commandSender : Bukkit.getPlayer(session.target());
                    if (player == null) {
                        this.plugin.messages().send(commandSender, "duels.offline");
                        commandSender.closeInventory();
                        return;
                    } else {
                        DuelRequestGui.open(this.plugin, commandSender, player, session);
                        return;
                    }
                }
                int backSlot = root.getInt("back.slot", 18);
                if (clicked == backSlot) {
                    playValidClick(commandSender, commandSender.getOpenInventory().getTopInventory().getItem(clicked));
                    CommandSender player2 = session.context() == GuiContext.QUEUE ? commandSender : Bukkit.getPlayer(session.target());
                    if (player2 == null) {
                        this.plugin.messages().send(commandSender, "duels.offline");
                        commandSender.closeInventory();
                    } else {
                        DuelRequestGui.open(this.plugin, commandSender, player2, session);
                    }
                }
            }
        }
    }

    private void handleConfigurableClick(Player p, int slot, ClickType clickType, GuiSession session, YamlConfiguration cfg) {
        ConfigurationSection root;
        String single;
        int dynamicIndex;
        List<ArenaManager.ArenaOption> arenaOptionsIgnoringBlacklist;
        String single2;
        String currentGui = session.currentGuiId();
        if (currentGui == null || currentGui.isBlank() || (root = GenericGui.resolveGuiRoot(cfg, currentGui)) == null) {
            return;
        }
        ConfigurationSection arenaItem = root.getConfigurationSection("arena-item");
        List<Integer> dynamicArenaSlots = GenericGui.resolveArenaSlots(root, p.getOpenInventory().getTopInventory().getSize());
        if (arenaItem != null && "arena-icon".equalsIgnoreCase(arenaItem.getString("dynamic", "")) && (dynamicIndex = dynamicArenaSlots.indexOf(Integer.valueOf(slot))) >= 0) {
            if (session.context() == GuiContext.QUEUE) {
                arenaOptionsIgnoringBlacklist = this.plugin.arenaManager().getArenaOptions(session.selectedKit(), session.selectedArena());
            } else {
                arenaOptionsIgnoringBlacklist = this.plugin.arenaManager().getArenaOptionsIgnoringBlacklist(session.selectedArena());
            }
            List<ArenaManager.ArenaOption> options = arenaOptionsIgnoringBlacklist;
            if (dynamicIndex >= options.size()) {
                return;
            }
            ArenaManager.ArenaOption option = options.get(dynamicIndex);
            List<String> actions = new ArrayList<>();
            boolean rightClick = clickType != null && clickType.isRightClick();
            boolean leftClick = clickType != null && clickType.isLeftClick();
            if (rightClick && arenaItem.isList("actions-right")) {
                actions.addAll(arenaItem.getStringList("actions-right"));
            }
            if (leftClick && arenaItem.isList("actions-left")) {
                actions.addAll(arenaItem.getStringList("actions-left"));
            }
            if (actions.isEmpty() && arenaItem.isList("actions")) {
                actions.addAll(arenaItem.getStringList("actions"));
            }
            if (actions.isEmpty() && (single2 = arenaItem.getString("action")) != null && !single2.isBlank()) {
                actions.add(single2);
            }
            Player target = session.context() == GuiContext.QUEUE ? p : Bukkit.getPlayer(session.target());
            if (target == null) {
                this.plugin.messages().send(p, "duels.offline");
                p.closeInventory();
                return;
            }
            playValidClick(p, p.getOpenInventory().getTopInventory().getItem(slot));
            for (String raw : actions) {
                String parsed = raw.replace("%arena%", option.id()).replace("%arena_id%", option.id()).replace("%arena_name%", option.displayName());
                if (!executeAction(p, target, session, parsed)) {
                    break;
                }
            }
            ConfigurationSection refreshedRoot = GenericGui.resolveGuiRoot(cfg, session.currentGuiId());
            if ((p.getOpenInventory().getTopInventory().getHolder() instanceof ReanMenuHolder) && refreshedRoot != null && session.key() == GuiKey.CONFIGURABLE) {
                GenericGui.render(this.plugin, p.getOpenInventory().getTopInventory(), session, refreshedRoot);
                return;
            }
            return;
        }
        ConfigurationSection items = root.getConfigurationSection("items");
        if (items == null) {
            return;
        }
        ConfigurationSection clickedSec = null;
        int inventorySize = p.getOpenInventory().getTopInventory().getSize();
        Iterator it = items.getKeys(false).iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            String key = (String) it.next();
            ConfigurationSection sec = items.getConfigurationSection(key);
            if (sec != null && GenericGui.shouldRenderItem(this.plugin, sec, session) && GenericGui.resolveSlots(sec, inventorySize).contains(Integer.valueOf(slot))) {
                clickedSec = sec;
                break;
            }
        }
        if (clickedSec == null) {
            return;
        }
        List<String> actions2 = new ArrayList<>();
        boolean rightClick2 = clickType != null && clickType.isRightClick();
        boolean leftClick2 = clickType != null && clickType.isLeftClick();
        if (rightClick2 && clickedSec.isList("actions-right")) {
            actions2.addAll(clickedSec.getStringList("actions-right"));
        }
        if (leftClick2 && clickedSec.isList("actions-left")) {
            actions2.addAll(clickedSec.getStringList("actions-left"));
        }
        if (actions2.isEmpty() && clickedSec.isList("actions")) {
            actions2.addAll(clickedSec.getStringList("actions"));
        }
        if (actions2.isEmpty() && (single = clickedSec.getString("action")) != null && !single.isBlank()) {
            actions2.add(single);
        }
        Player target2 = session.context() == GuiContext.QUEUE ? p : Bukkit.getPlayer(session.target());
        if (target2 == null) {
            this.plugin.messages().send(p, "duels.offline");
            p.closeInventory();
            return;
        }
        playValidClick(p, p.getOpenInventory().getTopInventory().getItem(slot));
        for (String raw2 : actions2) {
            if (!executeAction(p, target2, session, raw2)) {
                break;
            }
        }
        ConfigurationSection refreshedRoot2 = GenericGui.resolveGuiRoot(cfg, session.currentGuiId());
        if ((p.getOpenInventory().getTopInventory().getHolder() instanceof ReanMenuHolder) && refreshedRoot2 != null && session.key() == GuiKey.CONFIGURABLE) {
            GenericGui.render(this.plugin, p.getOpenInventory().getTopInventory(), session, refreshedRoot2);
        }
    }

    private boolean executeAction(Player p, Player target, GuiSession session, String raw) {
        if (raw == null) {
            return true;
        }
        String action = raw.trim();
        if (action.isBlank()) {
            return true;
        }
        String upper = action.toUpperCase(Locale.ROOT);
        if (session.context() == GuiContext.QUEUE && !upper.startsWith("[SELECT_KIT]") && !upper.startsWith("[EDITKIT]") && !upper.startsWith("[SET_ROUNDS]")) {
            return true;
        }
        if (upper.startsWith("[SELECT_KIT]")) {
            String id = action.substring(action.indexOf(93) + 1).trim();
            Kit kit = this.plugin.kitManager().get(id);
            if (kit == null) {
                this.plugin.messages().send(p, "gui.kit-not-found", Map.of("kit_id", id));
                return false;
            }
            session.setSelectedKit(kit);
            if (session.context() == GuiContext.QUEUE) {
                this.plugin.queueManager().toggleQueue(p, kit, session.firstTo());
                GenericGui.render(this.plugin, p.getOpenInventory().getTopInventory(), session, GenericGui.resolveGuiRoot(GenericGui.loadInventories(this.plugin), session.currentGuiId()));
                return false;
            }
            if (session.context() == GuiContext.KIT_EDITOR) {
                this.plugin.kitEditorManager().open(p, kit);
                return false;
            }
            return true;
        }
        if (upper.startsWith("[EDITKIT]")) {
            String id2 = action.substring(action.indexOf(93) + 1).trim();
            Kit kit2 = id2.isBlank() ? session.selectedKit() : this.plugin.kitManager().get(id2);
            if (kit2 == null) {
                this.plugin.messages().send(p, "gui.kit-not-found", Map.of("kit_id", id2.isBlank() ? "selected" : id2));
                return false;
            }
            session.setSelectedKit(kit2);
            this.plugin.kitEditorManager().open(p, kit2);
            return false;
        }
        if (upper.startsWith("[SET_ROUNDS]")) {
            String value = action.substring(action.indexOf(93) + 1).trim();
            try {
                session.setFirstTo(Integer.parseInt(value));
                return true;
            } catch (NumberFormatException e) {
                this.plugin.messages().send(p, "gui.invalid-rounds", Map.of("rounds", value));
                return false;
            }
        }
        if (upper.startsWith("[ADD_ROUNDS]")) {
            if (session.context() == GuiContext.QUEUE) {
                return true;
            }
            String value2 = action.substring(action.indexOf(93) + 1).trim();
            int amount = 1;
            if (!value2.isBlank()) {
                try {
                    amount = Integer.parseInt(value2);
                } catch (NumberFormatException e2) {
                }
            }
            session.setFirstTo(session.firstTo() + Math.max(1, amount));
            return true;
        }
        if (upper.startsWith("[REMOVE_ROUNDS]")) {
            if (session.context() == GuiContext.QUEUE) {
                return true;
            }
            String value3 = action.substring(action.indexOf(93) + 1).trim();
            int amount2 = 1;
            if (!value3.isBlank()) {
                try {
                    amount2 = Integer.parseInt(value3);
                } catch (NumberFormatException e3) {
                }
            }
            session.setFirstTo(session.firstTo() - Math.max(1, amount2));
            return true;
        }
        if (upper.startsWith("[SET_STATUS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            String value4 = action.substring(action.indexOf(93) + 1).trim();
            PlayerStatus status = PlayerStatus.fromString(value4);
            if (!status.name().equalsIgnoreCase(value4)) {
                this.plugin.messages().send(p, "gui.invalid-status", Map.of("status", value4));
                return false;
            }
            this.plugin.playerData().setStatus(p, status);
            return true;
        }
        if (upper.equals("[NEXT_STATUS]") || upper.equals("[CYCLE_STATUS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().cycleStatus(p);
            return true;
        }
        if (upper.equals("[TOGGLE_DUELS]") || upper.equals("[TOGGLE_DUEL_REQUESTS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            boolean disabledNow = this.plugin.playerData().toggleDuelRequests(p.getUniqueId());
            if (!disabledNow) {
                this.plugin.messages().send(p, "duels.toggled-on");
                return true;
            }
            this.plugin.messages().send(p, "duels.toggled-off");
            return true;
        }
        if (upper.equals("[TOGGLE_FAST_CRYSTALS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleFastCrystals(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_BLAST_PARTICLES]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleBlastParticles(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_TOTEM_PARTICLES]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleTotemParticles(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_DIRECT_MESSAGES]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleDirectMessages(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_SHOW_OWN_TIER]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleShowOwnTier(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_PROFILE_KITS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleProfileKits(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_FRIEND_REQUESTS]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleFriendRequests(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_FRIEND_JOIN_NOTIFIER]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleFriendJoinNotifier(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_DUEL_POPS]") || upper.equals("[TOGGLE_TOTEM_POPS_PLACEHOLDER]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleDuelPops(p.getUniqueId());
            return true;
        }
        if (upper.equals("[TOGGLE_SCOREBOARD]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().toggleScoreboard(p);
            return true;
        }
        if (upper.equals("[RESET_NICK]") || upper.equals("[CLEAR_NICK]")) {
            if (session.context() != GuiContext.SETTINGS) {
                return true;
            }
            this.plugin.playerData().clearNick(p);
            return true;
        }
        if (upper.startsWith("[SELECT_ARENA]")) {
            if (session.context() == GuiContext.QUEUE) {
                return true;
            }
            session.setSelectedArena(action.substring(action.indexOf(93) + 1).trim());
            return true;
        }
        if (upper.startsWith("[OPENGUI]") || upper.startsWith("[OPEN_GUI]")) {
            String guiId = action.substring(action.indexOf(93) + 1).trim();
            GenericGui.open(this.plugin, p, target, session, guiId);
            return false;
        }
        if (upper.equals("[BACK]")) {
            String previous = session.popHistory();
            if (previous != null) {
                session.setCurrentGuiId(null);
                GenericGui.open(this.plugin, p, target, session, previous);
                return false;
            }
            return false;
        }
        if (upper.equals("[CONFIRM_DUEL]") || upper.equals("[SEND_DUEL]")) {
            if (session.context() == GuiContext.QUEUE) {
                return true;
            }
            this.duels.createAndSendRequest(p, target, session.selectedKit(), session.firstTo(), session.selectedArena());
            p.closeInventory();
            return false;
        }
        if (upper.startsWith("[RUN_COMMAND]") || upper.startsWith("[RUNCMD]") || upper.startsWith("[CONSOLE_COMMAND]") || upper.startsWith("[CONSOLECOMMAND]") || upper.startsWith("[CONSOLE]")) {
            String command = extractActionPayload(action);
            dispatchConsoleCommand(applyCommandPlaceholders(command, p, target, session));
            return true;
        }
        if (upper.startsWith("[PLAYER_COMMAND]") || upper.startsWith("[PLAYERCOMMAND]") || upper.startsWith("[COMMAND]")) {
            String command2 = extractActionPayload(action);
            dispatchPlayerCommand(p, applyCommandPlaceholders(command2, p, target, session));
            return true;
        }
        if (upper.equals("[CLOSE]")) {
            p.closeInventory();
            return false;
        }
        return true;
    }

    private String extractActionPayload(String action) {
        int endIndex = action.indexOf(93);
        if (endIndex < 0 || endIndex + 1 >= action.length()) {
            return "";
        }
        return action.substring(endIndex + 1).trim();
    }

    private String applyCommandPlaceholders(String command, Player actor, Player target, GuiSession session) {
        if (command == null || command.isBlank()) {
            return "";
        }
        Kit kit = session.selectedKit();
        String arenaId = session.selectedArena() == null ? "" : session.selectedArena();
        Arena arena = this.plugin.arenaManager().get(arenaId);
        String resolved = command.replace("%player%", actor != null ? actor.getName() : "").replace("%viewer%", actor != null ? actor.getName() : "").replace("%target%", target != null ? target.getName() : "").replace("%opponent%", target != null ? target.getName() : "").replace("%kit%", kit != null ? kit.id() : "").replace("%kit_name%", kit != null ? kit.displayName() : "").replace("%arena%", arenaId).replace("%arena_name%", arena != null ? arena.displayName() : arenaId).replace("%rounds%", String.valueOf(session.firstTo())).replace("%first_to%", String.valueOf(session.firstTo()));
        if (actor != null && Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                resolved = PlaceholderAPI.setPlaceholders(actor, resolved);
            } catch (Throwable th) {
            }
        }
        return resolved;
    }

    private void dispatchConsoleCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        String normalized = command.startsWith("/") ? command.substring(1) : command;
        if (normalized.isBlank()) {
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), normalized);
    }

    private void dispatchPlayerCommand(Player player, String command) {
        if (player == null || command == null || command.isBlank()) {
            return;
        }
        String normalized = command.startsWith("/") ? command.substring(1) : command;
        if (normalized.isBlank()) {
            return;
        }
        player.performCommand(normalized);
    }

    private void playValidClick(Player player, ItemStack clickedItem) {
        if (shouldPlayValidClickSound(clickedItem)) {
            player.playSound(player.getLocation(), Sound.BLOCK_WOODEN_BUTTON_CLICK_ON, 0.8f, 1.0f);
        }
    }

    private boolean shouldPlayValidClickSound(ItemStack item) {
        return (item == null || item.getType().isAir() || item.getType().name().endsWith("_STAINED_GLASS_PANE")) ? false : true;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (sessionOrNull(e.getView().getTopInventory()) == null) {
            return;
        }
        e.setCancelled(true);
    }
}
