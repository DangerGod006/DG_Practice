package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.model.Kit;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiSession.class */
public final class GuiSession {
    private GuiKey key;
    private final UUID owner;
    private final UUID target;
    private Kit selectedKit;
    private String currentGuiId;
    private GuiContext context = GuiContext.DUEL;
    private final Deque<String> history = new ArrayDeque();
    private int firstTo = 3;
    private String selectedArena = "random";

    public GuiSession(GuiKey key, Player owner, Player target, Kit kit) {
        this.key = key;
        this.owner = owner.getUniqueId();
        this.target = target.getUniqueId();
        this.selectedKit = kit;
    }

    public GuiKey key() {
        return this.key;
    }

    public void setKey(GuiKey key) {
        this.key = key;
    }

    public UUID owner() {
        return this.owner;
    }

    public UUID target() {
        return this.target;
    }

    public Kit selectedKit() {
        return this.selectedKit;
    }

    public void setSelectedKit(Kit kit) {
        this.selectedKit = kit;
    }

    public int firstTo() {
        return Math.max(1, Math.min(50, this.firstTo));
    }

    public void setFirstTo(int firstTo) {
        this.firstTo = Math.max(1, Math.min(50, firstTo));
    }

    public String selectedArena() {
        return (this.selectedArena == null || this.selectedArena.isBlank()) ? "random" : this.selectedArena;
    }

    public void setSelectedArena(String selectedArena) {
        this.selectedArena = (selectedArena == null || selectedArena.isBlank()) ? "random" : selectedArena.toLowerCase();
    }

    public String currentGuiId() {
        return this.currentGuiId;
    }

    public GuiContext context() {
        return this.context;
    }

    public void setCurrentGuiId(String currentGuiId) {
        this.currentGuiId = currentGuiId;
    }

    public void setContext(GuiContext context) {
        this.context = context == null ? GuiContext.DUEL : context;
    }

    public void pushHistory(String guiId) {
        if (guiId == null || guiId.isBlank()) {
            return;
        }
        this.history.push(guiId);
    }

    public String popHistory() {
        if (this.history.isEmpty()) {
            return null;
        }
        return this.history.pop();
    }

    public void clearHistory() {
        this.history.clear();
    }
}
