package dev.rean.pvpcore.effects;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import dev.rean.pvpcore.kits.KitEditorManager;
import dev.rean.pvpcore.util.HexColor;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/effects/DuelVisualEffects.class */
public final class DuelVisualEffects {
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final AtomicInteger ENTITY_ID_SEQUENCE = new AtomicInteger(2000000000);
    private static final int DEATH_STATUS = 2;
    private static final long CLEANUP_TICKS = 22;
    private final Plugin plugin;
    private volatile boolean packetEventsWarningPrinted;

    public DuelVisualEffects(Plugin plugin) {
        this.plugin = plugin;
    }

    public void playFakeDeath(Player dead, Location exactDeathLocation, Collection<Player> viewers) {
        if (dead == null || !dead.isOnline()) {
            return;
        }
        List<Player> targets = new ArrayList<>();
        for (Player viewer : viewers) {
            if (viewer != null && viewer.isOnline() && !viewer.getUniqueId().equals(dead.getUniqueId())) {
                targets.add(viewer);
            }
        }
        if (targets.isEmpty()) {
            playFallbackVisualsForViewer(dead, dead.getLocation(), dead);
            return;
        }
        Location deathLocation = exactDeathLocation.clone();
        int fakeEntityId = nextEntityId();
        UUID fakeUuid = UUID.randomUUID();
        Iterator<Player> it = targets.iterator();
        while (it.hasNext()) {
            it.next().hidePlayer(this.plugin, dead);
        }
        boolean spawned = false;
        try {
            Object playerInfoPacket = createAddPlayerInfoPacket(dead, fakeUuid);
            Object spawnPacket = createSpawnPlayerPacket(fakeEntityId, fakeUuid, dead, deathLocation);
            Object metadataPacket = createMetadataPacket(dead, fakeEntityId);
            Object lookPacket = createEntityLookPacket(fakeEntityId, dead, deathLocation);
            Object headLookPacket = createEntityHeadLookPacket(fakeEntityId, resolveHeadYaw(dead, deathLocation));
            Object deathStatusPacket = createEntityStatusPacket(fakeEntityId, 2);
            for (Player viewer2 : targets) {
                sendPacket(viewer2, playerInfoPacket);
                sendPacket(viewer2, spawnPacket);
                if (metadataPacket != null) {
                    sendPacket(viewer2, metadataPacket);
                }
                if (lookPacket != null) {
                    sendPacket(viewer2, lookPacket);
                }
                if (headLookPacket != null) {
                    sendPacket(viewer2, headLookPacket);
                }
                sendPacket(viewer2, deathStatusPacket);
                playFallbackVisualsForViewer(dead, deathLocation, viewer2);
            }
            playFallbackVisualsForViewer(dead, deathLocation, dead);
            spawned = true;
        } catch (Throwable throwable) {
            if (!this.packetEventsWarningPrinted) {
                this.packetEventsWarningPrinted = true;
                this.plugin.getLogger().log(Level.WARNING, "Failed to create the fake death with PacketEvents. Falling back to particle-only effects.", throwable);
            }
        }
        if (!spawned) {
            Iterator<Player> it2 = targets.iterator();
            while (it2.hasNext()) {
                playFallbackVisualsForViewer(dead, deathLocation, it2.next());
            }
            playFallbackVisualsForViewer(dead, deathLocation, dead);
        }
        boolean finalSpawned = spawned;
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            cleanup(dead.getUniqueId(), fakeEntityId, fakeUuid, targets, finalSpawned);
        }, CLEANUP_TICKS);
    }

    private void cleanup(UUID deadId, int fakeEntityId, UUID fakeUuid, List<Player> viewers, boolean fakeSpawned) {
        if (fakeSpawned) {
            try {
                Object destroyPacket = createDestroyPacket(fakeEntityId);
                Object removeInfoPacket = createRemovePlayerInfoPacket(fakeUuid);
                for (Player viewer : viewers) {
                    if (viewer != null && viewer.isOnline()) {
                        sendPacket(viewer, destroyPacket);
                        if (removeInfoPacket != null) {
                            sendPacket(viewer, removeInfoPacket);
                        }
                    }
                }
            } catch (Throwable throwable) {
                if (!this.packetEventsWarningPrinted) {
                    this.packetEventsWarningPrinted = true;
                    this.plugin.getLogger().log(Level.WARNING, "Failed to clean up the PacketEvents fake death correctly.", throwable);
                }
            }
        }
        Player realPlayer = Bukkit.getPlayer(deadId);
        if (realPlayer == null) {
            return;
        }
        for (Player viewer2 : viewers) {
            if (viewer2 != null && viewer2.isOnline()) {
                viewer2.showPlayer(this.plugin, realPlayer);
            }
        }
    }

    private void playFallbackVisualsForViewer(Player subject, Location loc, Player viewer) {
        if (subject == null || loc == null || loc.getWorld() == null || viewer == null || !viewer.isOnline()) {
            return;
        }
        Location center = loc.clone().add(0.0d, 1.0d, 0.0d);
        for (int i = 0; i < 6; i++) {
            double offsetX = (Math.random() * 0.7d) - 0.35d;
            double offsetY = (Math.random() * 0.45d) - 0.1d;
            double offsetZ = (Math.random() * 0.7d) - 0.35d;
            viewer.spawnParticle(Particle.SCULK_SOUL, center.clone().add(offsetX, offsetY, offsetZ), 1, 0.0d, 0.0d, 0.0d, 0.0d);
        }
        viewer.spawnParticle(Particle.FLASH, center, 1, 0.0d, 0.0d, 0.0d, 0.0d, Color.WHITE);
    }

    public void playDeathCombatEffects(Player dead, Player killer) {
        if (dead == null) {
            return;
        }
        playFallbackVisualsForViewer(dead, dead.getLocation().clone(), dead);
        if (killer != null && killer.isOnline()) {
            playFallbackVisualsForViewer(dead, dead.getLocation().clone(), killer);
            killer.playSound(killer, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.0f, 0.9f);
            killer.playSound(killer, Sound.BLOCK_TRIAL_SPAWNER_OPEN_SHUTTER, 1.0f, 1.1f);
        }
        if (dead.isOnline()) {
            dead.playSound(dead, Sound.BLOCK_CONDUIT_DEACTIVATE, 1.0f, 0.9f);
        }
    }

    public void playAnimatedTitle(Player player, List<String> frames, String subtitle, int changeIntervalTicks) {
        if (player == null || !player.isOnline() || frames == null || frames.isEmpty()) {
            return;
        }
        int interval = Math.max(1, changeIntervalTicks);
        int i = 0;
        while (i < frames.size()) {
            String frame = frames.get(i);
            boolean isLast = i == frames.size() - 1;
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                if (player.isOnline()) {
                    long stayMillis = isLast ? 200L : (((long) interval) * 50) + 100;
                    Title.Times times = Title.Times.times(Duration.ZERO, Duration.ofMillis(stayMillis), Duration.ofMillis(200L));
                    player.showTitle(Title.title(deserializeTitlePart(frame), deserializeTitlePart(subtitle == null ? "" : subtitle), times));
                }
            }, ((long) i) * ((long) interval));
            i++;
        }
    }

    private Component deserializeTitlePart(String text) {
        String input = text == null ? "" : text;
        try {
            return MINI_MESSAGE.deserialize(input);
        } catch (Throwable th) {
            return LegacyComponentSerializer.legacySection().deserialize(HexColor.color(input));
        }
    }

    private Object createAddPlayerInfoPacket(Player dead, UUID fakeUuid) throws Exception {
        Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoUpdate");
        Class<?> actionClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoUpdate$Action");
        Class<?> infoClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoUpdate$PlayerInfo");
        Class<?> userProfileClass = Class.forName("com.github.retrooper.packetevents.protocol.player.UserProfile");
        Class<?> peGameModeClass = Class.forName("com.github.retrooper.packetevents.protocol.player.GameMode");
        Object userProfile = createFakeUserProfile(dead, fakeUuid, userProfileClass);
        Object peGameMode = Enum.valueOf(peGameModeClass, mapGameMode(GameMode.SURVIVAL));
        Object playerInfo = createPlayerInfo(infoClass, userProfileClass, peGameModeClass, userProfile, peGameMode);
        Object actionAddPlayer = Enum.valueOf(actionClass, "ADD_PLAYER");
        for (Constructor<?> constructor : packetClass.getConstructors()) {
            Class<?>[] types = constructor.getParameterTypes();
            if (types.length == 2) {
                try {
                    if (EnumSet.class.isAssignableFrom(types[0]) || Iterable.class.isAssignableFrom(types[0])) {
                        EnumSet actions = EnumSet.noneOf(actionClass);
                        actions.add((Enum) actionAddPlayer);
                        return constructor.newInstance(actions, Collections.singletonList(playerInfo));
                    }
                    if (types[0].isEnum()) {
                        return constructor.newInstance(actionAddPlayer, Collections.singletonList(playerInfo));
                    }
                } catch (Throwable th) {
                }
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for WrapperPlayServerPlayerInfoUpdate");
    }

    private Object createFakeUserProfile(Player dead, UUID fakeUuid, Class<?> userProfileClass) throws Exception {
        List<?> textureProperties = resolveTexturePropertiesSafe(dead);
        for (Constructor<?> constructor : userProfileClass.getConstructors()) {
            Class<?>[] types = constructor.getParameterTypes();
            if (types.length == 3 && types[0] == UUID.class && types[1] == String.class && List.class.isAssignableFrom(types[2])) {
                return constructor.newInstance(fakeUuid, dead.getName(), textureProperties);
            }
            if (types.length == 2 && types[0] == UUID.class && types[1] == String.class) {
                Object profile = constructor.newInstance(fakeUuid, dead.getName());
                applyTextureProperties(profile, textureProperties);
                return profile;
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for UserProfile");
    }

    private List<?> resolveTexturePropertiesSafe(Player dead) {
        Object gameProfile;
        Object propertyMap;
        try {
            Object originalProfile = resolveOriginalUserProfile(dead);
            List<?> props = extractTextureProperties(originalProfile);
            if (!props.isEmpty()) {
                return props;
            }
        } catch (Throwable th) {
        }
        try {
            Method getHandle = dead.getClass().getMethod("getHandle", new Class[0]);
            Object nmsPlayer = getHandle.invoke(dead, new Object[0]);
            gameProfile = findGameProfile(nmsPlayer);
        } catch (Throwable th2) {
        }
        if (gameProfile != null && (propertyMap = invokeGetProperties(gameProfile)) != null) {
            List<?> mojangProps = extractFromPropertyMap(propertyMap);
            if (!mojangProps.isEmpty()) {
                return convertMojangProperties(mojangProps);
            }
            return Collections.emptyList();
        }
        return Collections.emptyList();
    }

    private Object findGameProfile(Object nmsPlayer) {
        for (Method method : nmsPlayer.getClass().getMethods()) {
            if (method.getParameterCount() == 0 && method.getReturnType().getSimpleName().equals("GameProfile")) {
                try {
                    return method.invoke(nmsPlayer, new Object[0]);
                } catch (Throwable th) {
                }
            }
        }
        for (Field field : nmsPlayer.getClass().getDeclaredFields()) {
            if (field.getType().getSimpleName().equals("GameProfile")) {
                try {
                    field.setAccessible(true);
                    return field.get(nmsPlayer);
                } catch (Throwable th2) {
                }
            }
        }
        return null;
    }

    private Object invokeGetProperties(Object gameProfile) {
        for (String name : List.of("getProperties", "properties")) {
            try {
                Method m = gameProfile.getClass().getMethod(name, new Class[0]);
                return m.invoke(gameProfile, new Object[0]);
            } catch (Throwable th) {
            }
        }
        return null;
    }

    private List<?> extractFromPropertyMap(Object propertyMap) {
        for (Method m : propertyMap.getClass().getMethods()) {
            if (m.getName().equals("get") && m.getParameterCount() == 1) {
                try {
                    Object result = m.invoke(propertyMap, "textures");
                    if (result instanceof Collection) {
                        Collection<?> col = (Collection) result;
                        if (!col.isEmpty()) {
                            return new ArrayList(col);
                        }
                        continue;
                    } else {
                        continue;
                    }
                } catch (Throwable th) {
                }
            }
        }
        return Collections.emptyList();
    }

    private List<?> convertMojangProperties(List<?> mojangProps) {
        try {
            Class<?> pePropertyClass = Class.forName("com.github.retrooper.packetevents.protocol.player.TextureProperty");
            List<Object> converted = new ArrayList<>();
            for (Object mojangProp : mojangProps) {
                String name = invokeStringGetter(mojangProp, "getName", "name");
                String value = invokeStringGetter(mojangProp, "getValue", "value");
                String sign = invokeStringGetterSilent(mojangProp, "getSignature", "signature");
                boolean added = false;
                Constructor<?>[] constructors = pePropertyClass.getConstructors();
                int length = constructors.length;
                int i = 0;
                while (true) {
                    if (i >= length) {
                        break;
                    }
                    Constructor<?> c = constructors[i];
                    Class<?>[] t = c.getParameterTypes();
                    if (t.length == 3 && t[0] == String.class && t[1] == String.class && t[2] == String.class) {
                        converted.add(c.newInstance(name, value, sign));
                        added = true;
                        break;
                    }
                    if (t.length != 2 || t[0] != String.class || t[1] != String.class) {
                        i++;
                    } else {
                        converted.add(c.newInstance(name, value));
                        added = true;
                        break;
                    }
                }
                if (!added) {
                    converted.add(mojangProp);
                }
            }
            if (!converted.isEmpty()) {
                return converted;
            }
        } catch (Throwable th) {
        }
        return mojangProps;
    }

    private String invokeStringGetter(Object target, String... methodNames) throws Exception {
        for (String name : methodNames) {
            try {
                Method m = target.getClass().getMethod(name, new Class[0]);
                Object result = m.invoke(target, new Object[0]);
                if (result instanceof String) {
                    String s = (String) result;
                    return s;
                }
                continue;
            } catch (NoSuchMethodException e) {
            }
        }
        throw new NoSuchMethodException("Ninguno de los getters encontrado en " + String.valueOf(target.getClass()));
    }

    private String invokeStringGetterSilent(Object target, String... methodNames) {
        for (String name : methodNames) {
            try {
                Method m = target.getClass().getMethod(name, new Class[0]);
                Object result = m.invoke(target, new Object[0]);
                if (result instanceof String) {
                    String s = (String) result;
                    return s;
                }
                continue;
            } catch (Throwable th) {
            }
        }
        return null;
    }

    private Object resolveOriginalUserProfile(Player dead) throws Exception {
        Class<?> reflectionUtilClass = Class.forName("io.github.retrooper.packetevents.util.SpigotReflectionUtil");
        Method method = reflectionUtilClass.getMethod("getUserProfile", Player.class);
        return method.invoke(null, dead);
    }

    private List<?> extractTextureProperties(Object userProfile) {
        Object result;
        if (userProfile == null) {
            return Collections.emptyList();
        }
        for (String methodName : List.of("getTextureProperties", "getProperties", "getProfileProperties")) {
            try {
                Method method = userProfile.getClass().getMethod(methodName, new Class[0]);
                result = method.invoke(userProfile, new Object[0]);
            } catch (Throwable th) {
            }
            if (result instanceof List) {
                List<?> list = (List) result;
                return new ArrayList(list);
            }
            if (result instanceof Collection) {
                Collection<?> collection = (Collection) result;
                return new ArrayList(collection);
            }
        }
        return Collections.emptyList();
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:?, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void applyTextureProperties(java.lang.Object r9, java.util.List<?> r10) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: dev.rean.pvpcore.effects.DuelVisualEffects.applyTextureProperties(java.lang.Object, java.util.List):void");
    }

    private Object createPlayerInfo(Class<?> infoClass, Class<?> userProfileClass, Class<?> peGameModeClass, Object userProfile, Object peGameMode) throws Exception {
        for (Constructor<?> constructor : infoClass.getConstructors()) {
            Class<?>[] types = constructor.getParameterTypes();
            if (types.length == 6 && userProfileClass.isAssignableFrom(types[0])) {
                return constructor.newInstance(userProfile, true, 0, peGameMode, null, null);
            }
            if (types.length == 5 && userProfileClass.isAssignableFrom(types[0])) {
                return constructor.newInstance(userProfile, true, 0, peGameMode, null);
            }
            if (types.length == 4 && userProfileClass.isAssignableFrom(types[0])) {
                return constructor.newInstance(userProfile, true, 0, peGameMode);
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for PlayerInfo");
    }

    private Object createSpawnPlayerPacket(int fakeEntityId, UUID fakeUuid, Player dead, Location loc) throws Exception {
        try {
            Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnPlayer");
            for (Constructor<?> constructor : packetClass.getConstructors()) {
                Class<?>[] types = constructor.getParameterTypes();
                if (types.length == 5 && types[0] == Integer.TYPE && types[1] == UUID.class && types[2] == Double.TYPE && types[3] == Double.TYPE && types[4] == Double.TYPE) {
                    return constructor.newInstance(Integer.valueOf(fakeEntityId), fakeUuid, Double.valueOf(loc.getX()), Double.valueOf(loc.getY()), Double.valueOf(loc.getZ()));
                }
                if (types.length == 6 && types[0] == Integer.TYPE && types[1] == UUID.class && types[2] == Double.TYPE && types[3] == Double.TYPE && types[4] == Double.TYPE && types[5] == Float.TYPE) {
                    return constructor.newInstance(Integer.valueOf(fakeEntityId), fakeUuid, Double.valueOf(loc.getX()), Double.valueOf(loc.getY()), Double.valueOf(loc.getZ()), Float.valueOf(resolveBodyYaw(dead, loc)));
                }
            }
        } catch (ClassNotFoundException e) {
        }
        Class<?> packetClass2 = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity");
        Class<?> entityTypesClass = Class.forName("com.github.retrooper.packetevents.protocol.entity.type.EntityTypes");
        Class<?> vectorClass = Class.forName("com.github.retrooper.packetevents.util.Vector3d");
        Object playerEntityType = entityTypesClass.getField("PLAYER").get(null);
        Object position = vectorClass.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(Double.valueOf(loc.getX()), Double.valueOf(loc.getY()), Double.valueOf(loc.getZ()));
        Object velocity = vectorClass.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE).newInstance(Double.valueOf(0.0d), Double.valueOf(0.0d), Double.valueOf(0.0d));
        for (Constructor<?> constructor2 : packetClass2.getConstructors()) {
            if (constructor2.getParameterTypes().length == 9) {
                return constructor2.newInstance(Integer.valueOf(fakeEntityId), Optional.of(fakeUuid), playerEntityType, position, Float.valueOf(loc.getPitch()), Float.valueOf(resolveBodyYaw(dead, loc)), Float.valueOf(resolveHeadYaw(dead, loc)), 0, Optional.of(velocity));
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for the spawn packet");
    }

    private Object createEntityLookPacket(int fakeEntityId, Player dead, Location loc) {
        try {
            Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityRotation");
            float bodyYaw = resolveBodyYaw(dead, loc);
            float pitch = loc == null ? 0.0f : loc.getPitch();
            for (Constructor<?> constructor : packetClass.getConstructors()) {
                Class<?>[] types = constructor.getParameterTypes();
                if (types.length == 4 && types[0] == Integer.TYPE && types[1] == Float.TYPE && types[2] == Float.TYPE && types[3] == Boolean.TYPE) {
                    return constructor.newInstance(Integer.valueOf(fakeEntityId), Float.valueOf(bodyYaw), Float.valueOf(pitch), true);
                }
            }
            return null;
        } catch (Throwable th) {
            return null;
        }
    }

    private Object createEntityHeadLookPacket(int fakeEntityId, float headYaw) {
        try {
            Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityHeadLook");
            for (Constructor<?> constructor : packetClass.getConstructors()) {
                Class<?>[] types = constructor.getParameterTypes();
                if (types.length == 2 && types[0] == Integer.TYPE && types[1] == Float.TYPE) {
                    return constructor.newInstance(Integer.valueOf(fakeEntityId), Float.valueOf(headYaw));
                }
            }
            return null;
        } catch (Throwable th) {
            return null;
        }
    }

    private float resolveHeadYaw(Player player, Location loc) {
        if (player != null) {
            try {
                return player.getEyeLocation().getYaw();
            } catch (Throwable th) {
            }
        }
        if (loc == null) {
            return 0.0f;
        }
        return loc.getYaw();
    }

    private float resolveBodyYaw(Player player, Location fallback) {
        if (player != null) {
            try {
                Method method = player.getClass().getMethod("getBodyYaw", new Class[0]);
                Object value = method.invoke(player, new Object[0]);
                if (value instanceof Number) {
                    Number number = (Number) value;
                    return number.floatValue();
                }
            } catch (Throwable th) {
            }
            try {
                return player.getLocation().getYaw();
            } catch (Throwable th2) {
            }
        }
        if (fallback == null) {
            return 0.0f;
        }
        return fallback.getYaw();
    }

    private Object createMetadataPacket(Player dead, int fakeEntityId) {
        try {
            Class<?> reflectionUtilClass = Class.forName("io.github.retrooper.packetevents.util.SpigotReflectionUtil");
            Method metadataMethod = reflectionUtilClass.getMethod("getEntityMetadata", Entity.class);
            List<?> metadata = (List) metadataMethod.invoke(null, dead);
            if (metadata == null || metadata.isEmpty()) {
                return null;
            }
            Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata");
            for (Constructor<?> constructor : packetClass.getConstructors()) {
                Class<?>[] types = constructor.getParameterTypes();
                if (types.length == 2 && types[0] == Integer.TYPE && List.class.isAssignableFrom(types[1])) {
                    return constructor.newInstance(Integer.valueOf(fakeEntityId), metadata);
                }
            }
            return null;
        } catch (Throwable th) {
            return null;
        }
    }

    private Object createEntityStatusPacket(int fakeEntityId, int status) throws Exception {
        Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityStatus");
        for (Constructor<?> constructor : packetClass.getConstructors()) {
            Class<?>[] types = constructor.getParameterTypes();
            if (types.length == 2 && types[0] == Integer.TYPE && types[1] == Integer.TYPE) {
                return constructor.newInstance(Integer.valueOf(fakeEntityId), Integer.valueOf(status));
            }
            if (types.length == 2 && types[0] == Integer.TYPE && types[1].isEnum()) {
                Object enumValue = findEnumConstant(types[1], "PLAYER_DIE", "DEATH", "PLAY_DEATH_SOUND_OR_ADD_PROJECTILE_HIT_PARTICLES");
                return constructor.newInstance(Integer.valueOf(fakeEntityId), enumValue);
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for the entity status packet");
    }

    private Object createDestroyPacket(int fakeEntityId) throws Exception {
        Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities");
        for (Constructor<?> constructor : packetClass.getConstructors()) {
            Class<?>[] types = constructor.getParameterTypes();
            if (types.length == 1 && types[0] == int[].class) {
                return constructor.newInstance(new int[]{fakeEntityId});
            }
        }
        throw new NoSuchMethodException("No compatible constructor was found for the destroy packet");
    }

    private Object createRemovePlayerInfoPacket(UUID fakeUuid) {
        try {
            Class<?> packetClass = Class.forName("com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerInfoRemove");
            for (Constructor<?> constructor : packetClass.getConstructors()) {
                Class<?>[] parameterTypes = constructor.getParameterTypes();
                if (parameterTypes.length == 1) {
                    if (List.class.isAssignableFrom(parameterTypes[0])) {
                        return constructor.newInstance(Collections.singletonList(fakeUuid));
                    }
                    if (parameterTypes[0].isArray() && parameterTypes[0].getComponentType() == UUID.class) {
                        Object array = Array.newInstance((Class<?>) UUID.class, 1);
                        Array.set(array, 0, fakeUuid);
                        return constructor.newInstance(array);
                    }
                }
            }
            return null;
        } catch (Throwable th) {
            return null;
        }
    }

    private Object findEnumConstant(Class<?> enumClass, String... names) throws Exception {
        if (!enumClass.isEnum()) {
            throw new IllegalArgumentException(enumClass.getName() + " no es enum");
        }
        for (String name : names) {
            try {
                return Enum.valueOf(enumClass, name);
            } catch (IllegalArgumentException e) {
            }
        }
        Object[] constants = enumClass.getEnumConstants();
        if (constants == null || constants.length <= 0) {
            throw new NoSuchFieldException("No enum constant was found in " + enumClass.getName());
        }
        return constants[0];
    }

    private void sendPacket(Player viewer, Object packet) {
        if (viewer == null || !viewer.isOnline() || packet == null) {
            return;
        }
        PacketEvents.getAPI().getPlayerManager().sendPacket(viewer, (PacketWrapper) packet);
    }

    private int nextEntityId() {
        int next = ENTITY_ID_SEQUENCE.incrementAndGet();
        if (next == Integer.MAX_VALUE) {
            ENTITY_ID_SEQUENCE.set(ThreadLocalRandom.current().nextInt(1500000000, 2000000000));
            next = ENTITY_ID_SEQUENCE.incrementAndGet();
        }
        return next;
    }

    /* JADX INFO: renamed from: dev.rean.pvpcore.effects.DuelVisualEffects$1, reason: invalid class name */
    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/effects/DuelVisualEffects$1.class */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$org$bukkit$GameMode = new int[GameMode.values().length];

        static {
            try {
                $SwitchMap$org$bukkit$GameMode[GameMode.CREATIVE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$org$bukkit$GameMode[GameMode.ADVENTURE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$org$bukkit$GameMode[GameMode.SPECTATOR.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    private String mapGameMode(GameMode gameMode) {
        switch (AnonymousClass1.$SwitchMap$org$bukkit$GameMode[gameMode.ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                return "CREATIVE";
            case 2:
                return "ADVENTURE";
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                return "SPECTATOR";
            default:
                return "SURVIVAL";
        }
    }
}
