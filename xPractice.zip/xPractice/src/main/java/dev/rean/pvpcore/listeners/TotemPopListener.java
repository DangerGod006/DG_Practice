package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/TotemPopListener.class */
public final class TotemPopListener implements Listener {
    private final PvPCorePlugin plugin;

    public TotemPopListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onResurrect(EntityResurrectEvent event) {
        Player entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = entity;
            this.plugin.duelManager().recordTotemPop(player.getUniqueId());
        }
    }
}
