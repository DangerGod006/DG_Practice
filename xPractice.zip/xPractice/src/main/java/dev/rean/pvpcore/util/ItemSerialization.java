package dev.rean.pvpcore.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.Base64;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/ItemSerialization.class */
public final class ItemSerialization {

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/ItemSerialization$InventoryData.class */
    public static final class InventoryData extends Record {
        private final ItemStack[] contents;
        private final ItemStack[] armor;
        private final ItemStack offhand;

        public InventoryData(ItemStack[] contents, ItemStack[] armor, ItemStack offhand) {
            this.contents = contents;
            this.armor = armor;
            this.offhand = offhand;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, InventoryData.class), InventoryData.class, "contents;armor;offhand", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->armor:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, InventoryData.class), InventoryData.class, "contents;armor;offhand", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->armor:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, InventoryData.class, Object.class), InventoryData.class, "contents;armor;offhand", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->armor:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/util/ItemSerialization$InventoryData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public ItemStack[] contents() {
            return this.contents;
        }

        public ItemStack[] armor() {
            return this.armor;
        }

        public ItemStack offhand() {
            return this.offhand;
        }
    }

    private ItemSerialization() {
    }

    public static String serialize(ItemStack[] contents, ItemStack[] armor, ItemStack offhand) {
        int length;
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            BukkitObjectOutputStream oos = new BukkitObjectOutputStream(out);
            if (contents == null) {
                length = 0;
            } else {
                try {
                    length = contents.length;
                } finally {
                }
            }
            oos.writeInt(length);
            if (contents != null) {
                for (ItemStack it : contents) {
                    oos.writeObject(it);
                }
            }
            oos.writeInt(armor == null ? 0 : armor.length);
            if (armor != null) {
                for (ItemStack it2 : armor) {
                    oos.writeObject(it2);
                }
            }
            oos.writeObject(offhand);
            oos.close();
            return Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static InventoryData deserialize(String base64) {
        try {
            byte[] data = Base64.getDecoder().decode(base64);
            BukkitObjectInputStream ois = new BukkitObjectInputStream(new ByteArrayInputStream(data));
            try {
                int cLen = ois.readInt();
                ItemStack[] contents = new ItemStack[cLen];
                for (int i = 0; i < cLen; i++) {
                    contents[i] = (ItemStack) ois.readObject();
                }
                int aLen = ois.readInt();
                ItemStack[] armor = new ItemStack[aLen];
                for (int i2 = 0; i2 < aLen; i2++) {
                    armor[i2] = (ItemStack) ois.readObject();
                }
                ItemStack offhand = (ItemStack) ois.readObject();
                InventoryData inventoryData = new InventoryData(contents, armor, offhand);
                ois.close();
                return inventoryData;
            } finally {
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
