package dev.rean.pvpcore.queue;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.UUID;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/queue/QueueEntry.class */
public final class QueueEntry extends Record {
    private final UUID playerId;
    private final String kitId;
    private final int rounds;
    private final long joinedAt;

    public QueueEntry(UUID playerId, String kitId, int rounds, long joinedAt) {
        this.playerId = playerId;
        this.kitId = kitId;
        this.rounds = rounds;
        this.joinedAt = joinedAt;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, QueueEntry.class), QueueEntry.class, "playerId;kitId;rounds;joinedAt", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->kitId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->rounds:I", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->joinedAt:J").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, QueueEntry.class), QueueEntry.class, "playerId;kitId;rounds;joinedAt", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->kitId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->rounds:I", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->joinedAt:J").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, QueueEntry.class, Object.class), QueueEntry.class, "playerId;kitId;rounds;joinedAt", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->playerId:Ljava/util/UUID;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->kitId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->rounds:I", "FIELD:Ldev/rean/pvpcore/queue/QueueEntry;->joinedAt:J").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public UUID playerId() {
        return this.playerId;
    }

    public String kitId() {
        return this.kitId;
    }

    public int rounds() {
        return this.rounds;
    }

    public long joinedAt() {
        return this.joinedAt;
    }
}
