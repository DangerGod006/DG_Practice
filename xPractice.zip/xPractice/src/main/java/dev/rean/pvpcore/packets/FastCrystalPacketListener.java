package dev.rean.pvpcore.packets;

import com.github.retrooper.packetevents.event.PacketListener;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import dev.rean.pvpcore.PvPCorePlugin;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/packets/FastCrystalPacketListener.class */
public final class FastCrystalPacketListener implements PacketListener {
    private static final double FALLBACK_ENTITY_RANGE = 4.5d;
    private final PvPCorePlugin plugin;

    public FastCrystalPacketListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public void onPacketReceive(PacketReceiveEvent event) {
        UUID playerId;
        if (event.getPacketType() == PacketType.Play.Client.ANIMATION && (playerId = event.getUser().getUUID()) != null && this.plugin.playerData().hasFastCrystalsEnabled(playerId)) {
            Bukkit.getScheduler().runTask(this.plugin, () -> {
                tryBreakCrystal(playerId);
            });
        }
    }

    private void tryBreakCrystal(UUID playerId) {
        Location eye;
        Vector direction;
        RayTraceResult entityResult;
        Entity crystal;
        try {
            Player player = Bukkit.getPlayer(playerId);
            if (player == null || !player.isOnline() || player.getGameMode() == GameMode.SPECTATOR || isAttackDamageReduced(player) || (entityResult = player.getWorld().rayTraceEntities(eye, (direction = (eye = player.getEyeLocation()).getDirection()), entityInteractionRange(player), 0.0d, entity -> {
                return entity.getType() == EntityType.END_CRYSTAL && entity.getTicksLived() > 0;
            })) == null || (crystal = entityResult.getHitEntity()) == null || crystal.getType() != EntityType.END_CRYSTAL || isBlockedBySolidBlock(player, eye, direction, entityResult)) {
                return;
            }
            player.attack(crystal);
        } catch (Throwable th) {
        }
    }

    private double entityInteractionRange(Player player) {
        AttributeInstance attribute = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
        return attribute == null ? FALLBACK_ENTITY_RANGE : Math.max(FALLBACK_ENTITY_RANGE, attribute.getValue());
    }

    private boolean isBlockedBySolidBlock(Player player, Location eye, Vector direction, RayTraceResult entityResult) {
        Entity hitEntity = entityResult.getHitEntity();
        if (hitEntity != null && hitEntity.getBoundingBox().contains(eye.toVector())) {
            return false;
        }
        double blockRange = player.getGameMode() == GameMode.CREATIVE ? 5.0d : FALLBACK_ENTITY_RANGE;
        RayTraceResult blockResult = player.getWorld().rayTraceBlocks(eye, direction, blockRange);
        if (blockResult == null) {
            return false;
        }
        Block block = blockResult.getHitBlock();
        if (block == null) {
            return false;
        }
        Vector eyeVector = eye.toVector();
        return eyeVector.distanceSquared(blockResult.getHitPosition()) <= eyeVector.distanceSquared(entityResult.getHitPosition());
    }

    private boolean isAttackDamageReduced(Player player) {
        PotionEffect weakness = player.getPotionEffect(PotionEffectType.WEAKNESS);
        int weaknessLevel = weakness == null ? 0 : weakness.getAmplifier() + 1;
        PotionEffect strength = player.getPotionEffect(PotionEffectType.STRENGTH);
        int strengthLevel = strength == null ? 0 : strength.getAmplifier() + 1;
        return (strengthLevel * 3) - (weaknessLevel * 4) < 0;
    }
}
