package dev.rean.pvpcore.integrations;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/integrations/TabScoreboardHook.class */
public final class TabScoreboardHook {
    private final PvPCorePlugin plugin;
    private final Set<UUID> duelTabNames = new HashSet();
    private BukkitTask duelTabTask;
    private boolean warnedScoreboard;
    private boolean warnedTabName;

    public TabScoreboardHook(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isAvailable() {
        return Bukkit.getPluginManager().getPlugin("TAB") != null;
    }

    private boolean duelTabNameOverrideEnabled() {
        Object value = this.plugin.getConfig().get("tab.duel-name-override");
        if (value instanceof String) {
            String stringValue = (String) value;
            return !stringValue.isBlank();
        }
        if (this.plugin.getConfig().isConfigurationSection("tab.duel-name-override")) {
            return this.plugin.getConfig().getBoolean("tab.duel-name-override.enabled", false);
        }
        return false;
    }

    private String duelNameOverrideFormat() {
        Object value = this.plugin.getConfig().get("tab.duel-name-override");
        if (value instanceof String) {
            String stringValue = (String) value;
            if (!stringValue.isBlank()) {
                return stringValue;
            }
        }
        String legacyFormat = this.plugin.getConfig().getString("tab.duel-name-override.format");
        if (legacyFormat != null && !legacyFormat.isBlank()) {
            return legacyFormat;
        }
        return "%team_color%🗡 %player% &7%ping%ms";
    }

    public void apply(Player player, boolean enabled) {
        if (player != null && player.isOnline() && isAvailable()) {
            try {
                Class<?> tabApiClass = Class.forName("me.neznamy.tab.api.TabAPI");
                Object tabApi = tabApiClass.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
                if (tabApi == null) {
                    return;
                }
                Method getPlayer = tabApiClass.getMethod("getPlayer", UUID.class);
                Object tabPlayer = getPlayer.invoke(tabApi, player.getUniqueId());
                if (tabPlayer == null) {
                    Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                        apply(player, enabled);
                    }, 10L);
                    return;
                }
                Method getScoreboardManager = tabApiClass.getMethod("getScoreboardManager", new Class[0]);
                Object scoreboardManager = getScoreboardManager.invoke(tabApi, new Object[0]);
                if (scoreboardManager == null) {
                    return;
                }
                Class<?> tabPlayerClass = Class.forName("me.neznamy.tab.api.TabPlayer");
                Method setVisible = scoreboardManager.getClass().getMethod("setScoreboardVisible", tabPlayerClass, Boolean.TYPE, Boolean.TYPE);
                setVisible.invoke(scoreboardManager, tabPlayer, Boolean.valueOf(enabled), false);
            } catch (Throwable t) {
                if (!this.warnedScoreboard) {
                    this.warnedScoreboard = true;
                    this.plugin.getLogger().warning("Could not apply TAB scoreboard visibility through the TAB API: " + t.getMessage());
                }
            }
        }
    }

    public void applyDuelTabNames(DuelMatch match) {
        if (match == null || !duelTabNameOverrideEnabled()) {
            return;
        }
        this.duelTabNames.add(match.red());
        this.duelTabNames.add(match.blue());
        refreshDuelTabNames();
        ensureDuelTabRefreshTask();
    }

    public void resetDuelTabNames(DuelMatch match) {
        if (match == null) {
            return;
        }
        resetDuelTabName(match.red());
        resetDuelTabName(match.blue());
    }

    public void resetDuelTabName(UUID playerId) {
        if (playerId == null) {
            return;
        }
        this.duelTabNames.remove(playerId);
        Player player = Bukkit.getPlayer(playerId);
        if (player == null || !player.isOnline()) {
            return;
        }
        hardResetDuelTabName(player);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            hardResetDuelTabName(player);
        }, 1L);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            hardResetDuelTabName(player);
        }, 5L);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            hardResetDuelTabName(player);
        }, 20L);
    }

    private void hardResetDuelTabName(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        setTabName(player, null);
        refreshTabPlayer(player);
    }

    public void refreshPlayer(Player player) {
        refreshTabPlayer(player);
    }

    public void shutdown() {
        if (this.duelTabTask != null) {
            this.duelTabTask.cancel();
            this.duelTabTask = null;
        }
        for (UUID playerId : new HashSet(this.duelTabNames)) {
            resetDuelTabName(playerId);
        }
        this.duelTabNames.clear();
    }

    private void ensureDuelTabRefreshTask() {
        if (this.duelTabTask == null || this.duelTabTask.isCancelled()) {
            this.duelTabTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::refreshDuelTabNames, 20L, 40L);
        }
    }

    private void refreshDuelTabNames() {
        if (isAvailable() && duelTabNameOverrideEnabled()) {
            Iterator<UUID> iterator = this.duelTabNames.iterator();
            while (iterator.hasNext()) {
                UUID playerId = iterator.next();
                Player player = Bukkit.getPlayer(playerId);
                DuelMatch match = this.plugin.duelManager() == null ? null : this.plugin.duelManager().getMatch(playerId);
                if (player == null || !player.isOnline() || match == null) {
                    if (player != null && player.isOnline()) {
                        hardResetDuelTabName(player);
                    }
                    iterator.remove();
                } else {
                    setTabName(player, formatDuelTabName(match, player));
                }
            }
            if (this.duelTabNames.isEmpty() && this.duelTabTask != null) {
                this.duelTabTask.cancel();
                this.duelTabTask = null;
            }
        }
    }

    public String formatDuelTabName(DuelMatch match, Player player) {
        if (match == null || player == null) {
            return "";
        }
        String format = duelNameOverrideFormat();
        if (format == null || format.isBlank()) {
            format = "%team_color%🗡 %player% &7%ping%ms";
        }
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                format = PlaceholderAPI.setPlaceholders(player, format);
            } catch (Throwable th) {
            }
        }
        UUID playerId = player.getUniqueId();
        boolean red = match.red().equals(playerId);
        UUID opponentId = red ? match.blue() : match.red();
        Player opponent = Bukkit.getPlayer(opponentId);
        String selfColor = match.teamColor(playerId);
        String opponentColor = match.teamColor(opponentId);
        return format.replace("%team_color%", selfColor).replace("%color%", selfColor).replace("%player%", player.getName()).replace("%player_name%", player.getName()).replace("%displayname%", player.getDisplayName()).replace("%ping%", String.valueOf(player.getPing())).replace("%team%", red ? "red" : "blue").replace("%opponent%", opponent != null ? opponent.getName() : "").replace("%opponent_color%", opponentColor).replace("%arena%", match.arena() != null ? match.arena().displayName() : "").replace("%arena_id%", match.arena() != null ? match.arena().id() : "").replace("%kit%", match.kit() != null ? match.kit().id() : "").replace("%kit_name%", match.kit() != null ? match.kit().displayName() : "").replace("%score%", match.getColoredScoreLineFor(playerId)).replace("%red_score%", String.valueOf(match.redWins())).replace("%blue_score%", String.valueOf(match.blueWins())).replace("%red_color%", match.redColor()).replace("%blue_color%", match.blueColor());
    }

    private void refreshTabPlayer(Player player) {
        if (player != null && player.isOnline() && isAvailable()) {
            try {
                Class<?> tabApiClass = Class.forName("me.neznamy.tab.api.TabAPI");
                Object tabApi = tabApiClass.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
                if (tabApi == null) {
                    return;
                }
                Method getPlayer = tabApiClass.getMethod("getPlayer", UUID.class);
                Object tabPlayer = getPlayer.invoke(tabApi, player.getUniqueId());
                if (tabPlayer == null) {
                    return;
                }
                invokeIfPresent(tabApi, "refreshPlayer", tabPlayer);
                invokeIfPresent(tabApi, "updatePlayer", tabPlayer);
                Object tabListFormatManager = invokeNoArgs(tabApi, "getTabListFormatManager");
                invokeIfPresent(tabListFormatManager, "refresh", tabPlayer);
                invokeIfPresent(tabListFormatManager, "update", tabPlayer);
                Object nameTagManager = invokeNoArgs(tabApi, "getNameTagManager");
                invokeIfPresent(nameTagManager, "refresh", tabPlayer);
                invokeIfPresent(nameTagManager, "update", tabPlayer);
                Object placeholderManager = invokeNoArgs(tabApi, "getPlaceholderManager");
                invokeIfPresent(placeholderManager, "refresh", tabPlayer);
                invokeIfPresent(placeholderManager, "refreshPlayer", tabPlayer);
            } catch (Throwable th) {
            }
        }
    }

    private Object invokeNoArgs(Object target, String methodName) {
        if (target == null) {
            return null;
        }
        try {
            Method method = target.getClass().getMethod(methodName, new Class[0]);
            return method.invoke(target, new Object[0]);
        } catch (Throwable th) {
            return null;
        }
    }

    private void invokeIfPresent(Object target, String methodName, Object arg) {
        if (target == null || arg == null) {
            return;
        }
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == 1) {
                Class<?> parameterType = method.getParameterTypes()[0];
                if (parameterType.isAssignableFrom(arg.getClass())) {
                    try {
                        method.invoke(target, arg);
                        return;
                    } catch (Throwable th) {
                        return;
                    }
                }
            }
        }
    }

    private void setTabName(Player player, String name) {
        if (player != null && player.isOnline() && isAvailable()) {
            try {
                Class<?> tabApiClass = Class.forName("me.neznamy.tab.api.TabAPI");
                Object tabApi = tabApiClass.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
                if (tabApi == null) {
                    return;
                }
                Method getPlayer = tabApiClass.getMethod("getPlayer", UUID.class);
                Object tabPlayer = getPlayer.invoke(tabApi, player.getUniqueId());
                if (tabPlayer == null) {
                    Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                        setTabName(player, name);
                    }, 10L);
                    return;
                }
                Method getTabListFormatManager = tabApiClass.getMethod("getTabListFormatManager", new Class[0]);
                Object tabListFormatManager = getTabListFormatManager.invoke(tabApi, new Object[0]);
                if (tabListFormatManager == null) {
                    return;
                }
                Class<?> tabPlayerClass = Class.forName("me.neznamy.tab.api.TabPlayer");
                Method setName = tabListFormatManager.getClass().getMethod("setName", tabPlayerClass, String.class);
                setName.invoke(tabListFormatManager, tabPlayer, name);
            } catch (Throwable t) {
                if (!this.warnedTabName) {
                    this.warnedTabName = true;
                    this.plugin.getLogger().warning("Could not apply duel tab name through the TAB API: " + t.getMessage());
                }
            }
        }
    }
}
