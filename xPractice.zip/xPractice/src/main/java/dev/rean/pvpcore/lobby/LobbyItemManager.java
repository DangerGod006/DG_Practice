package dev.rean.pvpcore.lobby;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.gui.GenericGui;
import dev.rean.pvpcore.gui.GuiContext;
import dev.rean.pvpcore.gui.GuiKey;
import dev.rean.pvpcore.gui.GuiSession;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.ClickCooldown;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/lobby/LobbyItemManager.class */
public final class LobbyItemManager {
    private static final long MENU_CLICK_COOLDOWN_MS = 100;
    private final PvPCorePlugin plugin;
    private final ClickCooldown useCooldown = new ClickCooldown(MENU_CLICK_COOLDOWN_MS);
    private final NamespacedKey lobbyItemTypeKey;

    public LobbyItemManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
        this.lobbyItemTypeKey = new NamespacedKey(plugin, "lobby_item_type");
    }

    public void giveLobbyItems(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        removeLobbyItems(player);
        for (LobbyItemDefinition definition : configuredItems()) {
            ItemStack item = createConfiguredItem(definition.section(), definition.type(), definition.fallback());
            if (item != null) {
                int slot = Math.max(0, Math.min(player.getInventory().getSize() - 1, definition.slot()));
                player.getInventory().setItem(slot, item);
            }
        }
        player.updateInventory();
    }

    public void removeLobbyItems(Player player) {
        if (player == null) {
            return;
        }
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack current = player.getInventory().getItem(i);
            if (isLobbyItem(current)) {
                player.getInventory().setItem(i, (ItemStack) null);
            }
        }
        if (isLobbyItem(player.getInventory().getItemInOffHand())) {
            player.getInventory().setItemInOffHand((ItemStack) null);
        }
        player.updateInventory();
    }

    public boolean isLobbyItem(ItemStack item) {
        return lobbyItemType(item) != null;
    }

    public boolean isQueueItem(ItemStack item) {
        return typeMatches(lobbyItemType(item), "queue");
    }

    public boolean isSettingsItem(ItemStack item) {
        return typeMatches(lobbyItemType(item), "settings");
    }

    public boolean useItem(Player player, ItemStack item) {
        if (player == null || item == null || item.getType().isAir()) {
            return false;
        }
        if (!this.useCooldown.test(player.getUniqueId())) {
            return true;
        }
        String type = lobbyItemType(item);
        if (type == null || type.isBlank()) {
            return false;
        }
        LobbyItemDefinition definition = findByType(type);
        playUseSound(player);
        if (definition == null) {
            return runFallback(player, type);
        }
        List<String> actions = configuredActions(definition.section());
        if (actions.isEmpty()) {
            return runFallback(player, type);
        }
        for (String action : actions) {
            if (!executeAction(player, action)) {
                return true;
            }
        }
        return true;
    }

    private boolean runFallback(Player player, String type) {
        if (typeMatches(type, "queue")) {
            this.plugin.queueManager().openQueueMenu(player);
            return true;
        }
        if (typeMatches(type, "settings")) {
            this.plugin.playerData().openSettingsMenu(player);
            return true;
        }
        return false;
    }

    private ItemStack createConfiguredItem(ConfigurationSection section, String type, Material fallback) {
        if (section == null) {
            return markType(new ItemStack(fallback), type);
        }
        ItemStack item = GenericGui.buildConfiguredItem(this.plugin, section, Map.of());
        if (item == null) {
            item = new ItemStack(fallback);
        }
        return markType(item, type);
    }

    private ItemStack markType(ItemStack item, String type) {
        if (item == null) {
            return null;
        }
        ItemStack clone = item.clone();
        ItemMeta meta = clone.getItemMeta();
        if (meta == null) {
            return clone;
        }
        meta.getPersistentDataContainer().set(this.lobbyItemTypeKey, PersistentDataType.STRING, type);
        clone.setItemMeta(meta);
        return clone;
    }

    private String lobbyItemType(ItemStack item) {
        ItemMeta meta;
        if (item == null || item.getType().isAir() || (meta = item.getItemMeta()) == null) {
            return null;
        }
        return (String) meta.getPersistentDataContainer().get(this.lobbyItemTypeKey, PersistentDataType.STRING);
    }

    private LobbyItemDefinition findByType(String requestedType) {
        if (requestedType == null || requestedType.isBlank()) {
            return null;
        }
        for (LobbyItemDefinition definition : configuredItems()) {
            if (typeMatches(definition.type(), requestedType)) {
                return definition;
            }
        }
        return null;
    }

    private Collection<LobbyItemDefinition> configuredItems() {
        ConfigurationSection root = this.plugin.getConfig().getConfigurationSection("lobby-items");
        if (root == null) {
            return defaultItems().values();
        }
        Map<String, LobbyItemDefinition> definitions = new LinkedHashMap<>();
        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section != null) {
                String type = normalizeType(section.getString("type", key));
                definitions.put(type, new LobbyItemDefinition(type, section, section.getInt("slot", defaultSlot(type)), fallbackMaterial(type)));
            }
        }
        if (definitions.isEmpty()) {
            return defaultItems().values();
        }
        return definitions.values();
    }

    private Map<String, LobbyItemDefinition> defaultItems() {
        Map<String, LobbyItemDefinition> defaults = new LinkedHashMap<>();
        ConfigurationSection root = this.plugin.getConfig().getConfigurationSection("lobby-items");
        if (root != null) {
            ConfigurationSection queue = root.getConfigurationSection("queue-item");
            if (queue != null) {
                defaults.put("queue", new LobbyItemDefinition("queue", queue, queue.getInt("slot", 0), Material.IRON_SWORD));
            }
            ConfigurationSection settings = root.getConfigurationSection("settings-item");
            if (settings != null) {
                defaults.put("settings", new LobbyItemDefinition("settings", settings, settings.getInt("slot", 8), Material.COMPARATOR));
            }
        }
        defaults.putIfAbsent("queue", new LobbyItemDefinition("queue", null, 0, Material.IRON_SWORD));
        defaults.putIfAbsent("settings", new LobbyItemDefinition("settings", null, 8, Material.COMPARATOR));
        return defaults;
    }

    private List<String> configuredActions(ConfigurationSection section) {
        if (section == null) {
            return List.of();
        }
        List<String> actions = new ArrayList<>();
        if (section.isList("actions")) {
            actions.addAll(section.getStringList("actions"));
        }
        String single = section.getString("action");
        if (actions.isEmpty() && single != null && !single.isBlank()) {
            actions.add(single);
        }
        return actions;
    }

    private boolean executeAction(Player player, String raw) {
        if (raw == null || raw.isBlank()) {
            return true;
        }
        String action = raw.trim();
        String upper = action.toUpperCase(Locale.ROOT);
        if (upper.startsWith("[OPENGUI]") || upper.startsWith("[OPEN_GUI]")) {
            String guiId = action.substring(action.indexOf(93) + 1).trim();
            if ("settings-gui".equalsIgnoreCase(guiId)) {
                this.plugin.playerData().openSettingsMenu(player);
                return false;
            }
            Kit defaultKit = this.plugin.kitManager().getFirstOrNull();
            if (defaultKit == null) {
                this.plugin.messages().send(player, "queue.no-kits");
                return false;
            }
            GuiSession session = new GuiSession(GuiKey.CONFIGURABLE, player, player, defaultKit);
            session.setContext(GuiContext.QUEUE);
            GenericGui.open(this.plugin, player, player, session, guiId);
            return false;
        }
        if (upper.equals("[QUEUE]") || upper.equals("[QUEUE_MENU]")) {
            this.plugin.queueManager().openQueueMenu(player);
            return false;
        }
        if (upper.startsWith("[MESSAGE]")) {
            String msg = action.substring(action.indexOf(93) + 1).trim();
            if (!msg.isBlank()) {
                player.sendMessage(this.plugin.messages().format(msg, Map.of("player", player.getName())));
                return true;
            }
            return true;
        }
        if (upper.startsWith("[SOUND]")) {
            String soundName = action.substring(action.indexOf(93) + 1).trim();
            try {
                player.playSound(player.getLocation(), Sound.valueOf(soundName.toUpperCase(Locale.ROOT)), 1.0f, 1.0f);
                return true;
            } catch (IllegalArgumentException e) {
                return true;
            }
        }
        if (upper.startsWith("[CONSOLE_COMMAND]") || upper.startsWith("[CONSOLECOMMAND]") || upper.startsWith("[CONSOLE]")) {
            dispatchConsoleCommand(applyActionPlaceholders(player, extractActionPayload(action)));
            return true;
        }
        if (upper.startsWith("[PLAYER_COMMAND]") || upper.startsWith("[PLAYERCOMMAND]") || upper.startsWith("[COMMAND]")) {
            dispatchPlayerCommand(player, applyActionPlaceholders(player, extractActionPayload(action)));
            return true;
        }
        if (upper.equals("[CLOSE]")) {
            player.closeInventory();
            return false;
        }
        return true;
    }

    private String extractActionPayload(String action) {
        int endIndex = action.indexOf(93);
        return (endIndex < 0 || endIndex + 1 >= action.length()) ? "" : action.substring(endIndex + 1).trim();
    }

    private String applyActionPlaceholders(Player player, String command) {
        if (command == null || command.isBlank()) {
            return "";
        }
        Kit defaultKit = this.plugin.kitManager().getFirstOrNull();
        return command.replace("%player%", player != null ? player.getName() : "").replace("%viewer%", player != null ? player.getName() : "").replace("%target%", player != null ? player.getName() : "").replace("%kit%", defaultKit != null ? defaultKit.id() : "").replace("%kit_name%", defaultKit != null ? defaultKit.displayName() : "");
    }

    private void dispatchConsoleCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        String normalized = command.startsWith("/") ? command.substring(1) : command;
        if (normalized.isBlank()) {
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), normalized);
    }

    private void dispatchPlayerCommand(Player player, String command) {
        if (player == null || command == null || command.isBlank()) {
            return;
        }
        String normalized = command.startsWith("/") ? command.substring(1) : command;
        if (normalized.isBlank()) {
            return;
        }
        player.performCommand(normalized);
    }

    private void playUseSound(Player player) {
        player.playSound(player.getLocation(), Sound.BLOCK_WOODEN_BUTTON_CLICK_ON, 0.8f, 1.0f);
    }

    private static boolean typeMatches(String left, String right) {
        return normalizeType(left).equals(normalizeType(right));
    }

    private static String normalizeType(String type) {
        String normalized;
        if (type == null) {
            return "";
        }
        normalized = type.toLowerCase(Locale.ROOT).replace(" ", "").replace("-", "").replace("_", "");
        switch (normalized) {
            case "queueitem":
            case "queues":
            case "duelqueue":
            case "queue":
                return "queue";
            case "settingsitem":
            case "setting":
            case "settings":
            case "preferences":
                return "settings";
            default:
                return normalized;
        }
    }

    private static int defaultSlot(String type) {
        return typeMatches(type, "settings") ? 8 : 0;
    }

    private static Material fallbackMaterial(String type) {
        return typeMatches(type, "settings") ? Material.COMPARATOR : Material.IRON_SWORD;
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition.class */
    private static final class LobbyItemDefinition extends Record {
        private final String type;
        private final ConfigurationSection section;
        private final int slot;
        private final Material fallback;

        private LobbyItemDefinition(String type, ConfigurationSection section, int slot, Material fallback) {
            this.type = type;
            this.section = section;
            this.slot = slot;
            this.fallback = fallback;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, LobbyItemDefinition.class), LobbyItemDefinition.class, "type;section;slot;fallback", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->type:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->section:Lorg/bukkit/configuration/ConfigurationSection;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->slot:I", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->fallback:Lorg/bukkit/Material;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, LobbyItemDefinition.class), LobbyItemDefinition.class, "type;section;slot;fallback", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->type:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->section:Lorg/bukkit/configuration/ConfigurationSection;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->slot:I", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->fallback:Lorg/bukkit/Material;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, LobbyItemDefinition.class, Object.class), LobbyItemDefinition.class, "type;section;slot;fallback", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->type:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->section:Lorg/bukkit/configuration/ConfigurationSection;", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->slot:I", "FIELD:Ldev/rean/pvpcore/lobby/LobbyItemManager$LobbyItemDefinition;->fallback:Lorg/bukkit/Material;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String type() {
            return this.type;
        }

        public ConfigurationSection section() {
            return this.section;
        }

        public int slot() {
            return this.slot;
        }

        public Material fallback() {
            return this.fallback;
        }
    }
}
