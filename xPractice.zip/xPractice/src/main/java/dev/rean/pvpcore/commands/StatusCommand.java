package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.playerdata.PlayerStatus;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/StatusCommand.class */
public final class StatusCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public StatusCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (!commandSender.hasPermission("pvpcore.status")) {
            this.plugin.messages().send(commandSender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-status-usage", Map.of());
            return true;
        }
        PlayerStatus status = PlayerStatus.fromString(args[0]);
        if (!status.name().equalsIgnoreCase(args[0])) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-status-usage", Map.of());
            return true;
        }
        this.plugin.playerData().setStatus(commandSender, status);
        return true;
    }
}
