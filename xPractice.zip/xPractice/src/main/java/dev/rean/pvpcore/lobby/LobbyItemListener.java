package dev.rean.pvpcore.lobby;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.Iterator;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/lobby/LobbyItemListener.class */
public final class LobbyItemListener implements Listener {
    private final PvPCorePlugin plugin;

    public LobbyItemListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.plugin.lobbyItems().giveLobbyItems(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (itemInHand != null && !itemInHand.getType().isAir() && this.plugin.lobbyItems().isLobbyItem(itemInHand)) {
            event.setCancelled(true);
            if (this.plugin.duelManager().isInMatch(player.getUniqueId())) {
                return;
            }
            this.plugin.lobbyItems().useItem(player, itemInHand);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity whoClicked = event.getWhoClicked();
        if (whoClicked instanceof Player) {
            Player player = (Player) whoClicked;
            boolean hasLobbyItem = hasLobbyItemInClick(event);
            boolean matchLocked = this.plugin.duelManager().isInMatch(player.getUniqueId());
            boolean craftingSlot = isCraftingSlot(event);
            if (matchLocked) {
                if (hasLobbyItem || craftingSlot || craftingViewContainsLobbyItem(event.getView().getTopInventory())) {
                    event.setCancelled(true);
                    purgeLobbyItemsFromCraftingView(player);
                    player.updateInventory();
                    return;
                }
                return;
            }
            if (hasLobbyItem) {
                if (craftingSlot || wouldMoveIntoNonStorage(event)) {
                    event.setCancelled(true);
                    purgeLobbyItemsFromCraftingView(player);
                    player.updateInventory();
                } else {
                    if (isPlayerInventoryView(event) && clickStaysInPlayerStorage(event)) {
                        return;
                    }
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity whoClicked = event.getWhoClicked();
        if (whoClicked instanceof Player) {
            Player player = (Player) whoClicked;
            boolean hasLobbyItem = hasLobbyItemInDrag(event);
            boolean touchesCrafting = touchesCraftingSlot(event);
            boolean matchLocked = this.plugin.duelManager().isInMatch(player.getUniqueId());
            if (matchLocked) {
                if (hasLobbyItem || touchesCrafting || craftingViewContainsLobbyItem(event.getView().getTopInventory())) {
                    event.setCancelled(true);
                    purgeLobbyItemsFromCraftingView(player);
                    player.updateInventory();
                    return;
                }
                return;
            }
            if (hasLobbyItem) {
                if (touchesCrafting || !isPlayerInventoryView(event) || !dragStaysInPlayerStorage(event)) {
                    event.setCancelled(true);
                    purgeLobbyItemsFromCraftingView(player);
                    player.updateInventory();
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrop(PlayerDropItemEvent event) {
        if (this.plugin.lobbyItems().isLobbyItem(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    private boolean hasLobbyItemInClick(InventoryClickEvent event) {
        int hotbarSlot;
        if (this.plugin.lobbyItems().isLobbyItem(event.getCurrentItem()) || this.plugin.lobbyItems().isLobbyItem(event.getCursor())) {
            return true;
        }
        if (event.getClick() == ClickType.NUMBER_KEY && (hotbarSlot = event.getHotbarButton()) >= 0) {
            ItemStack hotbarItem = event.getWhoClicked().getInventory().getItem(hotbarSlot);
            return this.plugin.lobbyItems().isLobbyItem(hotbarItem);
        }
        return false;
    }

    private boolean hasLobbyItemInDrag(InventoryDragEvent event) {
        if (this.plugin.lobbyItems().isLobbyItem(event.getOldCursor()) || this.plugin.lobbyItems().isLobbyItem(event.getCursor())) {
            return true;
        }
        for (ItemStack item : event.getNewItems().values()) {
            if (this.plugin.lobbyItems().isLobbyItem(item)) {
                return true;
            }
        }
        return false;
    }

    private boolean wouldMoveIntoNonStorage(InventoryClickEvent event) {
        ClickType click = event.getClick();
        if (click == ClickType.DROP || click == ClickType.CONTROL_DROP || click.isShiftClick()) {
            return true;
        }
        return click == ClickType.NUMBER_KEY && event.getRawSlot() < event.getView().getTopInventory().getSize();
    }

    private boolean clickStaysInPlayerStorage(InventoryClickEvent event) {
        int rawSlot = event.getRawSlot();
        return rawSlot >= 0 && !isCraftingSlot(event) && rawSlot >= event.getView().getTopInventory().getSize();
    }

    private boolean isPlayerInventoryView(InventoryClickEvent event) {
        return isPlayerInventoryView(event.getView().getTopInventory().getType());
    }

    private boolean isPlayerInventoryView(InventoryDragEvent event) {
        return isPlayerInventoryView(event.getView().getTopInventory().getType());
    }

    private boolean isPlayerInventoryView(InventoryType topType) {
        return topType == InventoryType.CRAFTING || topType == InventoryType.CREATIVE || topType == InventoryType.PLAYER;
    }

    private boolean dragStaysInPlayerStorage(InventoryDragEvent event) {
        int topSize = event.getView().getTopInventory().getSize();
        Iterator it = event.getRawSlots().iterator();
        while (it.hasNext()) {
            int rawSlot = ((Integer) it.next()).intValue();
            if (rawSlot < topSize) {
                return false;
            }
        }
        return true;
    }

    private boolean isCraftingSlot(InventoryClickEvent event) {
        int rawSlot;
        return event.getView().getTopInventory().getType() == InventoryType.CRAFTING && (rawSlot = event.getRawSlot()) >= 0 && rawSlot <= 4;
    }

    private boolean touchesCraftingSlot(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getType() != InventoryType.CRAFTING) {
            return false;
        }
        Iterator it = event.getRawSlots().iterator();
        while (it.hasNext()) {
            int rawSlot = ((Integer) it.next()).intValue();
            if (rawSlot >= 0 && rawSlot <= 4) {
                return true;
            }
        }
        return false;
    }

    private boolean craftingViewContainsLobbyItem(Inventory top) {
        if (top == null || top.getType() != InventoryType.CRAFTING) {
            return false;
        }
        int max = Math.min(4, top.getSize() - 1);
        for (int slot = 0; slot <= max; slot++) {
            if (this.plugin.lobbyItems().isLobbyItem(top.getItem(slot))) {
                return true;
            }
        }
        return false;
    }

    private void purgeLobbyItemsFromCraftingView(Player player) {
        Inventory top;
        if (player == null || player.getOpenInventory() == null || (top = player.getOpenInventory().getTopInventory()) == null || top.getType() != InventoryType.CRAFTING) {
            return;
        }
        int max = Math.min(4, top.getSize() - 1);
        for (int slot = 0; slot <= max; slot++) {
            if (this.plugin.lobbyItems().isLobbyItem(top.getItem(slot))) {
                top.setItem(slot, (ItemStack) null);
            }
        }
    }
}
