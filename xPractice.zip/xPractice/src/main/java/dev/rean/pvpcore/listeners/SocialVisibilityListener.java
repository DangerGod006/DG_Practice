package dev.rean.pvpcore.listeners;

import com.destroystokyo.paper.event.server.AsyncTabCompleteEvent;
import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/SocialVisibilityListener.class */
public final class SocialVisibilityListener implements Listener {
    private final PvPCorePlugin plugin;

    public SocialVisibilityListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onAsyncTabComplete(AsyncTabCompleteEvent event) {
        Player sender = event.getSender();
        if (sender instanceof Player) {
            Player viewer = sender;
            event.completions().removeIf(completion -> {
                Player matched = this.plugin.getServer().getPlayerExact(completion.suggestion());
                return (matched == null || !this.plugin.playerData().isInvisible(matched.getUniqueId()) || this.plugin.playerData().areFriends(viewer.getUniqueId(), matched.getUniqueId())) ? false : true;
            });
        }
    }
}
