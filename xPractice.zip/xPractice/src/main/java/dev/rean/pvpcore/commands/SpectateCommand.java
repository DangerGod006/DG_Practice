package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/SpectateCommand.class */
public final class SpectateCommand implements CommandExecutor, TabCompleter {
    private final PvPCorePlugin plugin;

    public SpectateCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (args.length < 1) {
            this.plugin.messages().send(commandSender, "spectators.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            this.plugin.messages().send(commandSender, "duels.offline");
            return true;
        }
        if (target.getUniqueId().equals(commandSender.getUniqueId())) {
            this.plugin.messages().send(commandSender, "spectators.self");
            return true;
        }
        this.plugin.spectatorManager().spectate(commandSender, target);
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        String input = args[0].toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (sender instanceof Player) {
                Player player = (Player) sender;
                if (online.getUniqueId().equals(player.getUniqueId())) {
                }
            }
            if (this.plugin.duelManager().isInMatch(online.getUniqueId()) && online.getName().toLowerCase(Locale.ROOT).startsWith(input)) {
                out.add(online.getName());
            }
        }
        return out;
    }
}
