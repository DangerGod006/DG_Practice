package dev.rean.pvpcore.model;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/model/Kit.class */
public final class Kit {
    private final String id;
    private String displayName;
    private ItemStack[] contents;
    private ItemStack[] armor;
    private ItemStack offhand;
    private ItemStack icon;
    private String consoleCommand;
    private boolean naturalRegen = true;
    private boolean naturalSaturationDecrease = true;
    private GameMode gameMode = GameMode.SURVIVAL;
    private Set<Material> breakBlocks = new LinkedHashSet();
    private Set<Material> explodeBlocks = new LinkedHashSet();
    private Set<String> hiddenTags = new LinkedHashSet();
    private Set<String> summaryInfo = new LinkedHashSet();

    public Kit(String id, String displayName) {
        this.id = id.toLowerCase();
        this.displayName = displayName;
    }

    public String id() {
        return this.id;
    }

    public String displayName() {
        return this.displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public ItemStack[] contents() {
        return cloneArray(this.contents);
    }

    public ItemStack[] armor() {
        return cloneArray(this.armor);
    }

    public ItemStack offhand() {
        return cloneItem(this.offhand);
    }

    public ItemStack icon() {
        return cloneItem(this.icon);
    }

    public void setInventory(ItemStack[] contents, ItemStack[] armor, ItemStack offhand) {
        this.contents = cloneArray(contents);
        this.armor = cloneArray(armor);
        this.offhand = cloneItem(offhand);
    }

    public void setIcon(ItemStack icon) {
        this.icon = cloneItem(icon);
    }

    public boolean naturalRegen() {
        return this.naturalRegen;
    }

    public void setNaturalRegen(boolean naturalRegen) {
        this.naturalRegen = naturalRegen;
    }

    public boolean naturalSaturationDecrease() {
        return this.naturalSaturationDecrease;
    }

    public void setNaturalSaturationDecrease(boolean naturalSaturationDecrease) {
        this.naturalSaturationDecrease = naturalSaturationDecrease;
    }

    public String consoleCommand() {
        return this.consoleCommand;
    }

    public void setConsoleCommand(String consoleCommand) {
        this.consoleCommand = (consoleCommand == null || consoleCommand.isBlank()) ? null : consoleCommand;
    }

    public GameMode gameMode() {
        return this.gameMode == null ? GameMode.SURVIVAL : this.gameMode;
    }

    public void setGameMode(GameMode gameMode) {
        if (gameMode == GameMode.ADVENTURE || gameMode == GameMode.SURVIVAL) {
            this.gameMode = gameMode;
        } else {
            this.gameMode = GameMode.SURVIVAL;
        }
    }

    public Set<Material> breakBlocks() {
        return Collections.unmodifiableSet(new LinkedHashSet(this.breakBlocks));
    }

    public boolean canBreakBlock(Material material) {
        return material != null && this.breakBlocks.contains(material);
    }

    public void setBreakBlocks(Collection<String> blockTypes) {
        this.breakBlocks.clear();
        if (blockTypes == null) {
            return;
        }
        for (String blockType : blockTypes) {
            Material material = parseMaterial(blockType);
            if (material != null && material.isBlock()) {
                this.breakBlocks.add(material);
            }
        }
    }

    public void setBreakBlocksFromMaterials(Collection<Material> blockTypes) {
        this.breakBlocks.clear();
        if (blockTypes == null) {
            return;
        }
        for (Material material : blockTypes) {
            if (material != null && material.isBlock()) {
                this.breakBlocks.add(material);
            }
        }
    }

    public Set<Material> explodeBlocks() {
        return Collections.unmodifiableSet(new LinkedHashSet(this.explodeBlocks));
    }

    public boolean canExplodeBlock(Material material) {
        return material != null && this.explodeBlocks.contains(material);
    }

    public void setExplodeBlocks(Collection<String> blockTypes) {
        this.explodeBlocks.clear();
        if (blockTypes == null) {
            return;
        }
        for (String blockType : blockTypes) {
            Material material = parseMaterial(blockType);
            if (material != null && material.isBlock()) {
                this.explodeBlocks.add(material);
            }
        }
    }

    public void setExplodeBlocksFromMaterials(Collection<Material> blockTypes) {
        this.explodeBlocks.clear();
        if (blockTypes == null) {
            return;
        }
        for (Material material : blockTypes) {
            if (material != null && material.isBlock()) {
                this.explodeBlocks.add(material);
            }
        }
    }

    private static Material parseMaterial(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String normalized = raw.trim().toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        return Material.matchMaterial(normalized);
    }

    public Set<String> hiddenTags() {
        return Collections.unmodifiableSet(new LinkedHashSet(this.hiddenTags));
    }

    public Set<String> summaryInfo() {
        return Collections.unmodifiableSet(new LinkedHashSet(this.summaryInfo));
    }

    public void setSummaryInfo(Collection<String> summaryInfo) {
        this.summaryInfo.clear();
        if (summaryInfo == null) {
            return;
        }
        for (String value : summaryInfo) {
            if (value != null && !value.isBlank()) {
                String normalized = value.trim().toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
                switch (normalized) {
                    case "tot":
                    case "tots":
                    case "totem":
                    case "totems":
                        this.summaryInfo.add("totems");
                        break;
                    case "pot":
                    case "pots":
                    case "potion":
                    case "potions":
                        this.summaryInfo.add("pots");
                        break;
                    case "hp":
                    case "health":
                        this.summaryInfo.add("hp");
                        break;
                    case "armor":
                    case "armoravg":
                    case "armour":
                    case "armouravg":
                        this.summaryInfo.add("armoravg");
                        break;
                    case "xp":
                    case "exp":
                    case "experience":
                    case "experiencebottle":
                    case "experiencebottles":
                    case "bottlexp":
                    case "bottlesxp":
                        this.summaryInfo.add("xp");
                        break;
                }
            }
        }
    }

    public void setHiddenTags(Collection<String> hiddenTags) {
        this.hiddenTags.clear();
        if (hiddenTags == null) {
            return;
        }
        for (String hiddenTag : hiddenTags) {
            if (hiddenTag != null && !hiddenTag.isBlank()) {
                this.hiddenTags.add(hiddenTag.trim().toLowerCase(Locale.ROOT));
            }
        }
    }

    private static ItemStack[] cloneArray(ItemStack[] source) {
        if (source == null) {
            return null;
        }
        ItemStack[] copy = new ItemStack[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = cloneItem(source[i]);
        }
        return copy;
    }

    private static ItemStack cloneItem(ItemStack item) {
        if (item == null) {
            return null;
        }
        return item.clone();
    }
}
