package dev.rean.pvpcore.playerdata;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/playerdata/PlayerProfile.class */
public final class PlayerProfile {
    private String nickRaw;
    private int totemPops;
    private PlayerStatus status = PlayerStatus.ONLINE;
    private boolean duelRequestsEnabled = true;
    private boolean blastParticlesEnabled = true;
    private boolean totemParticlesEnabled = true;
    private boolean fastCrystalsEnabled = true;
    private boolean directMessagesEnabled = true;
    private boolean showOwnTier = true;
    private boolean profileKitsPublic = true;
    private boolean friendRequestsEnabled = true;
    private boolean friendJoinNotifierEnabled = true;
    private boolean scoreboardEnabled = true;
    private boolean duelPopsEnabled = true;
    private final Set<UUID> friends = new LinkedHashSet();
    private final Map<UUID, String> friendNames = new LinkedHashMap();
    private final Set<UUID> incomingFriendRequests = new LinkedHashSet();
    private final Set<UUID> outgoingFriendRequests = new LinkedHashSet();
    private final Map<UUID, String> incomingFriendRequestNames = new LinkedHashMap();
    private final Map<UUID, String> outgoingFriendRequestNames = new LinkedHashMap();

    public String nickRaw() {
        return this.nickRaw;
    }

    public void setNickRaw(String nickRaw) {
        this.nickRaw = (nickRaw == null || nickRaw.isBlank()) ? null : nickRaw;
    }

    public PlayerStatus status() {
        return this.status == null ? PlayerStatus.ONLINE : this.status;
    }

    public void setStatus(PlayerStatus status) {
        this.status = status == null ? PlayerStatus.ONLINE : status;
    }

    public boolean duelRequestsEnabled() {
        return this.duelRequestsEnabled;
    }

    public void setDuelRequestsEnabled(boolean duelRequestsEnabled) {
        this.duelRequestsEnabled = duelRequestsEnabled;
    }

    public boolean blastParticlesEnabled() {
        return this.blastParticlesEnabled;
    }

    public void setBlastParticlesEnabled(boolean blastParticlesEnabled) {
        this.blastParticlesEnabled = blastParticlesEnabled;
    }

    public boolean totemParticlesEnabled() {
        return this.totemParticlesEnabled;
    }

    public void setTotemParticlesEnabled(boolean totemParticlesEnabled) {
        this.totemParticlesEnabled = totemParticlesEnabled;
    }

    public boolean fastCrystalsEnabled() {
        return this.fastCrystalsEnabled;
    }

    public void setFastCrystalsEnabled(boolean fastCrystalsEnabled) {
        this.fastCrystalsEnabled = fastCrystalsEnabled;
    }

    public boolean directMessagesEnabled() {
        return this.directMessagesEnabled;
    }

    public void setDirectMessagesEnabled(boolean directMessagesEnabled) {
        this.directMessagesEnabled = directMessagesEnabled;
    }

    public boolean showOwnTier() {
        return this.showOwnTier;
    }

    public void setShowOwnTier(boolean showOwnTier) {
        this.showOwnTier = showOwnTier;
    }

    public boolean profileKitsPublic() {
        return this.profileKitsPublic;
    }

    public void setProfileKitsPublic(boolean profileKitsPublic) {
        this.profileKitsPublic = profileKitsPublic;
    }

    public boolean friendRequestsEnabled() {
        return this.friendRequestsEnabled;
    }

    public void setFriendRequestsEnabled(boolean friendRequestsEnabled) {
        this.friendRequestsEnabled = friendRequestsEnabled;
    }

    public boolean friendJoinNotifierEnabled() {
        return this.friendJoinNotifierEnabled;
    }

    public void setFriendJoinNotifierEnabled(boolean friendJoinNotifierEnabled) {
        this.friendJoinNotifierEnabled = friendJoinNotifierEnabled;
    }

    public boolean scoreboardEnabled() {
        return this.scoreboardEnabled;
    }

    public void setScoreboardEnabled(boolean scoreboardEnabled) {
        this.scoreboardEnabled = scoreboardEnabled;
    }

    public boolean duelPopsEnabled() {
        return this.duelPopsEnabled;
    }

    public void setDuelPopsEnabled(boolean duelPopsEnabled) {
        this.duelPopsEnabled = duelPopsEnabled;
    }

    public int totemPops() {
        return this.totemPops;
    }

    public void setTotemPops(int totemPops) {
        this.totemPops = Math.max(0, totemPops);
    }

    public int incrementTotemPops() {
        if (this.totemPops < Integer.MAX_VALUE) {
            this.totemPops++;
        }
        return this.totemPops;
    }

    public Set<UUID> friends() {
        return Collections.unmodifiableSet(this.friends);
    }

    public void setFriends(Collection<UUID> friends) {
        this.friends.clear();
        if (friends == null) {
            return;
        }
        for (UUID friend : friends) {
            if (friend != null) {
                this.friends.add(friend);
            }
        }
    }

    public boolean addFriend(UUID uniqueId, String lastKnownName) {
        if (uniqueId == null) {
            return false;
        }
        setFriendName(this.friendNames, uniqueId, lastKnownName);
        return this.friends.add(uniqueId);
    }

    public boolean removeFriend(UUID uniqueId) {
        if (uniqueId == null) {
            return false;
        }
        this.friendNames.remove(uniqueId);
        return this.friends.remove(uniqueId);
    }

    public Map<UUID, String> friendNames() {
        return Collections.unmodifiableMap(this.friendNames);
    }

    public void setFriendNames(Map<UUID, String> friendNames) {
        this.friendNames.clear();
        if (friendNames == null) {
            return;
        }
        friendNames.forEach((uuid, name) -> {
            setFriendName(this.friendNames, uuid, name);
        });
    }

    public String friendName(UUID uniqueId) {
        return this.friendNames.get(uniqueId);
    }

    public void setFriendName(UUID uniqueId, String name) {
        setFriendName(this.friendNames, uniqueId, name);
    }

    public Set<UUID> incomingFriendRequests() {
        return Collections.unmodifiableSet(this.incomingFriendRequests);
    }

    public void setIncomingFriendRequests(Collection<UUID> requests) {
        this.incomingFriendRequests.clear();
        if (requests == null) {
            return;
        }
        for (UUID request : requests) {
            if (request != null && !this.friends.contains(request)) {
                this.incomingFriendRequests.add(request);
            }
        }
    }

    public boolean addIncomingFriendRequest(UUID uniqueId, String lastKnownName) {
        if (uniqueId == null || this.friends.contains(uniqueId)) {
            return false;
        }
        setFriendName(this.incomingFriendRequestNames, uniqueId, lastKnownName);
        return this.incomingFriendRequests.add(uniqueId);
    }

    public boolean removeIncomingFriendRequest(UUID uniqueId) {
        if (uniqueId == null) {
            return false;
        }
        this.incomingFriendRequestNames.remove(uniqueId);
        return this.incomingFriendRequests.remove(uniqueId);
    }

    public Map<UUID, String> incomingFriendRequestNames() {
        return Collections.unmodifiableMap(this.incomingFriendRequestNames);
    }

    public void setIncomingFriendRequestNames(Map<UUID, String> names) {
        this.incomingFriendRequestNames.clear();
        if (names == null) {
            return;
        }
        names.forEach((uuid, name) -> {
            setFriendName(this.incomingFriendRequestNames, uuid, name);
        });
    }

    public String incomingFriendRequestName(UUID uniqueId) {
        return this.incomingFriendRequestNames.get(uniqueId);
    }

    public Set<UUID> outgoingFriendRequests() {
        return Collections.unmodifiableSet(this.outgoingFriendRequests);
    }

    public void setOutgoingFriendRequests(Collection<UUID> requests) {
        this.outgoingFriendRequests.clear();
        if (requests == null) {
            return;
        }
        for (UUID request : requests) {
            if (request != null && !this.friends.contains(request)) {
                this.outgoingFriendRequests.add(request);
            }
        }
    }

    public boolean addOutgoingFriendRequest(UUID uniqueId, String lastKnownName) {
        if (uniqueId == null || this.friends.contains(uniqueId)) {
            return false;
        }
        setFriendName(this.outgoingFriendRequestNames, uniqueId, lastKnownName);
        return this.outgoingFriendRequests.add(uniqueId);
    }

    public boolean removeOutgoingFriendRequest(UUID uniqueId) {
        if (uniqueId == null) {
            return false;
        }
        this.outgoingFriendRequestNames.remove(uniqueId);
        return this.outgoingFriendRequests.remove(uniqueId);
    }

    public Map<UUID, String> outgoingFriendRequestNames() {
        return Collections.unmodifiableMap(this.outgoingFriendRequestNames);
    }

    public void setOutgoingFriendRequestNames(Map<UUID, String> names) {
        this.outgoingFriendRequestNames.clear();
        if (names == null) {
            return;
        }
        names.forEach((uuid, name) -> {
            setFriendName(this.outgoingFriendRequestNames, uuid, name);
        });
    }

    public String outgoingFriendRequestName(UUID uniqueId) {
        return this.outgoingFriendRequestNames.get(uniqueId);
    }

    private void setFriendName(Map<UUID, String> target, UUID uniqueId, String name) {
        if (uniqueId == null) {
            return;
        }
        if (name != null && !name.isBlank()) {
            target.put(uniqueId, name);
        } else {
            target.remove(uniqueId);
        }
    }
}
