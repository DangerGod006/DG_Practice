package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.Arrays;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/MsgCommand.class */
public final class MsgCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public MsgCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (!commandSender.hasPermission("pvpcore.msg")) {
            this.plugin.messages().send(commandSender, "no-permission");
            return true;
        }
        if (args.length < 2) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-msg-usage", Map.of());
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-player-not-found", Map.of());
            return true;
        }
        if (target.getUniqueId().equals(commandSender.getUniqueId())) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-msg-self", Map.of());
            return true;
        }
        String message = String.join(" ", (CharSequence[]) Arrays.copyOfRange(args, 1, args.length));
        this.plugin.playerData().sendPrivateMessage(commandSender, target, message);
        return true;
    }
}
