package dev.rean.pvpcore.tiers;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.model.Kit;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/tiers/TierResolver.class */
public final class TierResolver {
    private final PvPCorePlugin plugin;
    private final Map<String, ModeStyle> styles = new LinkedHashMap();
    private final Map<String, String> tierColors = new LinkedHashMap();
    private final McTiersService mcTiersService;

    public TierResolver(PvPCorePlugin plugin) {
        this.plugin = plugin;
        this.mcTiersService = new McTiersService(plugin);
        reload();
    }

    public void reload() {
        this.styles.clear();
        this.tierColors.clear();
        registerStyle("axe", "🪓", "#55FF55");
        registerStyle("mace", "🔨", "#AAAAAA");
        registerStyle("nethop", "☠", "#7D4A40");
        registerStyle("pot", "⚗", "#FF0000");
        registerStyle("smp", "🛡", "#ECCB45");
        registerStyle("sword", "🗡", "#A4FDF0");
        registerStyle("uhc", "❤", "#FF5555");
        registerStyle("vanilla", "✦", "#FF55FF");
        this.tierColors.put("HT1", "#E8BA3A");
        this.tierColors.put("LT1", "#D5B355");
        this.tierColors.put("HT2", "#C4D3E7");
        this.tierColors.put("LT2", "#A0A7B2");
        this.tierColors.put("HT3", "#F89F5A");
        this.tierColors.put("LT3", "#C67B42");
        this.tierColors.put("HT4", "#81749A");
        this.tierColors.put("LT4", "#655B79");
        this.tierColors.put("HT5", "#8F82A8");
        this.tierColors.put("LT5", "#655B79");
    }

    public String getDisplayedTier(UUID uniqueId) {
        return !this.plugin.playerData().showsOwnTier(uniqueId) ? "" : getFormattedTierFor(uniqueId);
    }

    public String getTierFor(UUID uniqueId) {
        return getRawTierFor(uniqueId);
    }

    public String getRawTierFor(UUID uniqueId) {
        if (uniqueId == null) {
            return "";
        }
        Player player = Bukkit.getPlayer(uniqueId);
        if (player == null) {
            return "";
        }
        String mode = getCurrentMode(uniqueId);
        if (mode.isBlank()) {
            return "";
        }
        String resolved = this.mcTiersService.getTierNow(uniqueId, mode).trim().toUpperCase(Locale.ROOT);
        return this.tierColors.containsKey(resolved) ? resolved : "";
    }

    public void prefetch(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        String mode = getCurrentMode(uniqueId);
        if (mode.isBlank()) {
            return;
        }
        this.mcTiersService.requestRefresh(uniqueId);
    }

    public String getFormattedTierFor(UUID uniqueId) {
        ModeStyle style;
        String tierHex;
        if (uniqueId == null) {
            return "";
        }
        String mode = getCurrentMode(uniqueId);
        if (mode.isBlank() || (style = this.styles.get(mode)) == null) {
            return "";
        }
        String tier = getRawTierFor(uniqueId);
        return (tier.isBlank() || (tierHex = this.tierColors.get(tier)) == null || tierHex.isBlank()) ? "" : hex(style.iconHex()) + style.icon() + " " + hex(tierHex) + tier + " &7| &r";
    }

    public String getCurrentMode(UUID uniqueId) {
        DuelMatch match;
        Kit kit;
        if (uniqueId == null || (match = this.plugin.duelManager().getMatch(uniqueId)) == null || (kit = match.kit()) == null) {
            return "";
        }
        String fromId = normalizeMode(kit.id());
        if (this.styles.containsKey(fromId)) {
            return fromId;
        }
        String fromDisplay = normalizeMode(kit.displayName());
        return this.styles.containsKey(fromDisplay) ? fromDisplay : "";
    }

    private void registerStyle(String key, String icon, String iconHex) {
        this.styles.put(normalizeMode(key), new ModeStyle(icon, iconHex));
    }

    private static String normalizeMode(String input) {
        String normalized;
        if (input == null) {
            return "";
        }
        normalized = input.toLowerCase(Locale.ROOT).replace(" ", "").replace("-", "").replace("_", "");
        switch (normalized) {
            case "nethpot":
            case "netheritepot":
            case "netherpot":
            case "netheriteop":
            case "neth_pot":
                return "nethop";
            case "potpvp":
            case "nodebuff":
            case "potp":
            case "pot":
                return "pot";
            default:
                return normalized;
        }
    }

    private static String hex(String hex) {
        return "&" + hex;
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/tiers/TierResolver$ModeStyle.class */
    private static final class ModeStyle extends Record {
        private final String icon;
        private final String iconHex;

        private ModeStyle(String icon, String iconHex) {
            this.icon = icon;
            this.iconHex = iconHex;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, ModeStyle.class), ModeStyle.class, "icon;iconHex", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->icon:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->iconHex:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, ModeStyle.class), ModeStyle.class, "icon;iconHex", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->icon:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->iconHex:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, ModeStyle.class, Object.class), ModeStyle.class, "icon;iconHex", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->icon:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/tiers/TierResolver$ModeStyle;->iconHex:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String icon() {
            return this.icon;
        }

        public String iconHex() {
            return this.iconHex;
        }
    }
}
