package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.ItemBuilder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/RoundSelectGui.class */
public final class RoundSelectGui {
    public static void open(PvPCorePlugin plugin, Player sender, GuiSession session, String targetName) {
        YamlConfiguration cfg = GenericGui.loadInventories(plugin);
        if (GenericGui.resolveGuiRoot(cfg, "rounds-select-gui") != null && cfg.getConfigurationSection("guis") != null) {
            Player target = Bukkit.getPlayer(session.target());
            if (target == null) {
                target = sender;
            }
            GenericGui.open(plugin, sender, target, session, "rounds-select-gui");
            return;
        }
        ConfigurationSection root = cfg.getConfigurationSection("rounds-select-gui");
        if (root == null) {
            plugin.messages().send(sender, "gui.missing-rounds-select");
            return;
        }
        String titleRaw = root.getString("title", "Select Rounds");
        String title = GenericGui.formatGuiText(plugin, sender, titleRaw, Map.of("target", targetName, "target_name", targetName, "player", sender.getName(), "player_name", sender.getName(), "owner_uuid", sender.getUniqueId().toString()));
        int size = GenericGui.normalizeInventorySize(root.getInt("size", 27));
        session.setKey(GuiKey.ROUND_SELECT);
        Inventory inv = Bukkit.createInventory(new ReanMenuHolder(session), size, HexColor.color(title));
        render(plugin, inv, session, root);
        sender.openInventory(inv);
    }

    public static void render(PvPCorePlugin plugin, Inventory inv, GuiSession session, ConfigurationSection root) {
        inv.clear();
        ConfigurationSection filler = root.getConfigurationSection("filler");
        if (filler != null) {
            Material mat = Material.matchMaterial(filler.getString("material", "BLACK_STAINED_GLASS_PANE"));
            if (mat == null) {
                mat = Material.BLACK_STAINED_GLASS_PANE;
            }
            ItemStack fill = new ItemBuilder(mat).name(filler.getString("name", " ")).build();
            for (int i = 0; i < inv.getSize(); i++) {
                inv.setItem(i, fill);
            }
        }
        List<Integer> slots = root.getIntegerList("option-slots");
        if (slots == null || slots.isEmpty()) {
            slots = List.of(10, 11, 12, 13, 14);
        }
        List<Integer> values = root.getIntegerList("values");
        if (values == null || values.isEmpty()) {
            values = List.of(1, 3, 5, 7, 9);
        }
        String nameRaw = root.getString("option-name", "&eFirst to &f%value%&r");
        List<String> loreRaw = root.getStringList("option-lore");
        int idx = 0;
        Iterator<Integer> it = slots.iterator();
        while (it.hasNext()) {
            int slot = it.next().intValue();
            if (idx >= values.size()) {
                break;
            }
            int i2 = idx;
            idx++;
            int v = values.get(i2).intValue();
            ItemStack it2 = new ItemStack(Material.PAPER);
            it2.setAmount(Math.min(64, Math.max(1, v)));
            ItemMeta meta = it2.getItemMeta();
            Player owner = Bukkit.getPlayer(session.owner());
            Map<String, String> ph = Map.of("value", String.valueOf(v), "player", owner != null ? owner.getName() : "", "player_name", owner != null ? owner.getName() : "", "owner_uuid", session.owner().toString());
            meta.setDisplayName(HexColor.color(GenericGui.formatGuiText(plugin, owner, nameRaw, ph)));
            meta.setLore(loreRaw.stream().map(line -> {
                return HexColor.color(GenericGui.formatGuiText(plugin, owner, line, ph));
            }).toList());
            it2.setItemMeta(meta);
            inv.setItem(slot, it2);
        }
        ConfigurationSection back = root.getConfigurationSection("back");
        if (back != null) {
            int slot2 = back.getInt("slot", 18);
            Material mat2 = Material.matchMaterial(back.getString("material", "ARROW"));
            if (mat2 == null) {
                mat2 = Material.ARROW;
            }
            inv.setItem(slot2, new ItemBuilder(mat2).name(back.getString("name", "&fBack&r")).build());
        }
    }
}
