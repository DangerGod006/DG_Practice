package dev.rean.pvpcore.util;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/ItemBuilder.class */
public final class ItemBuilder {
    private final ItemStack item;

    public ItemBuilder(Material mat) {
        this.item = new ItemStack(mat);
    }

    public ItemBuilder name(String name) {
        ItemMeta meta = this.item.getItemMeta();
        meta.setDisplayName(HexColor.color(name));
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemBuilder lore(List<String> lore) {
        ItemMeta meta = this.item.getItemMeta();
        meta.setLore(lore.stream().map(HexColor::color).toList());
        this.item.setItemMeta(meta);
        return this;
    }

    public ItemStack build() {
        return this.item;
    }
}
