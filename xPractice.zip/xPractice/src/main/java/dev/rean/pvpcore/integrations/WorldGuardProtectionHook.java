package dev.rean.pvpcore.integrations;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.association.RegionAssociable;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import java.lang.reflect.Method;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/integrations/WorldGuardProtectionHook.class */
public final class WorldGuardProtectionHook implements ProtectionHook {
    private final RegionQuery query = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();

    public WorldGuardProtectionHook(JavaPlugin plugin) {
    }

    @Override // dev.rean.pvpcore.integrations.ProtectionHook
    public boolean canExplosionBreak(Block block, Entity source) {
        if (block == null || block.getWorld() == null) {
            return false;
        }
        RegionAssociable associable = associable(source);
        return this.query.testState(BukkitAdapter.adapt(block.getLocation()), associable, new StateFlag[]{Flags.BLOCK_BREAK});
    }

    private RegionAssociable associable(Entity source) {
        Player player = playerFrom(source);
        if (player == null) {
            return null;
        }
        LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
        return localPlayer;
    }

    private Player playerFrom(Entity source) {
        if (source == null) {
            return null;
        }
        if (source instanceof Player) {
            Player player = (Player) source;
            return player;
        }
        if (source instanceof Projectile) {
            Projectile projectile = (Projectile) source;
            Player shooter = projectile.getShooter();
            if (shooter instanceof Player) {
                Player player2 = shooter;
                return player2;
            }
            if (shooter instanceof Entity) {
                Entity entity = (Entity) shooter;
                Player nested = playerFrom(entity);
                if (nested != null) {
                    return nested;
                }
            }
        }
        Object reflectedSource = invokeNoArg(source, "getSource");
        if (reflectedSource instanceof Player) {
            Player player3 = (Player) reflectedSource;
            return player3;
        }
        if (reflectedSource instanceof Entity) {
            Entity entity2 = (Entity) reflectedSource;
            Player nested2 = playerFrom(entity2);
            if (nested2 != null) {
                return nested2;
            }
        }
        Object reflectedShooter = invokeNoArg(source, "getShooter");
        if (reflectedShooter instanceof Player) {
            Player player4 = (Player) reflectedShooter;
            return player4;
        }
        if (!(reflectedShooter instanceof Entity)) {
            return null;
        }
        Entity entity3 = (Entity) reflectedShooter;
        return playerFrom(entity3);
    }

    private Object invokeNoArg(Object target, String methodName) {
        if (target == null) {
            return null;
        }
        try {
            Method method = target.getClass().getMethod(methodName, new Class[0]);
            return method.invoke(target, new Object[0]);
        } catch (ReflectiveOperationException | RuntimeException e) {
            return null;
        }
    }
}
