package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.playerdata.PlayerDataManager;
import java.util.UUID;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/ToggleManager.class */
public final class ToggleManager {
    private final PlayerDataManager playerData;

    public ToggleManager(PlayerDataManager playerData) {
        this.playerData = playerData;
    }

    public boolean isDisabled(UUID uuid) {
        return this.playerData.areDuelRequestsDisabled(uuid);
    }

    public boolean toggle(UUID uuid) {
        return this.playerData.toggleDuelRequests(uuid);
    }
}
