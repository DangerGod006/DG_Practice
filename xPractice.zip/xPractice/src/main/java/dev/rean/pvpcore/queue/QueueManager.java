package dev.rean.pvpcore.queue;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.gui.GenericGui;
import dev.rean.pvpcore.gui.GuiContext;
import dev.rean.pvpcore.gui.GuiKey;
import dev.rean.pvpcore.gui.GuiSession;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.ClickCooldown;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/queue/QueueManager.class */
public final class QueueManager {
    private final PvPCorePlugin plugin;
    private static final long QUEUE_CLICK_COOLDOWN_MS = 100;
    private final Map<String, LinkedHashMap<UUID, QueueEntry>> queues = new HashMap();
    private final Map<UUID, String> queuedKeyByPlayer = new HashMap();
    private final ClickCooldown queueToggleCooldown = new ClickCooldown(QUEUE_CLICK_COOLDOWN_MS);
    private BukkitTask actionbarTask;

    public QueueManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
        startActionbarTask();
    }

    public void openQueueMenu(Player player) {
        if (player == null) {
            return;
        }
        Kit defaultKit = this.plugin.kitManager().getFirstOrNull();
        if (defaultKit == null) {
            this.plugin.messages().send(player, "queue.no-kits");
            return;
        }
        GuiSession session = new GuiSession(GuiKey.CONFIGURABLE, player, player, defaultKit);
        session.setContext(GuiContext.QUEUE);
        session.setFirstTo(this.plugin.settings().defaultRounds());
        if (!GenericGui.open(this.plugin, player, player, session, "queue-gui")) {
            GenericGui.open(this.plugin, player, player, session, "kit-select-gui");
        }
    }

    private void startActionbarTask() {
        stopActionbarTask();
        this.actionbarTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.queues.isEmpty()) {
                return;
            }
            purgeInvalidEntries();
            if (this.queues.isEmpty()) {
                return;
            }
            tryMatchQueues();
            if (this.queues.isEmpty()) {
                return;
            }
            long now = System.currentTimeMillis();
            Map<UUID, MutableQueueStats> statsByPlayer = new HashMap<>();
            for (LinkedHashMap<UUID, QueueEntry> queue : this.queues.values()) {
                for (QueueEntry entry : queue.values()) {
                    if (entry != null) {
                        statsByPlayer.computeIfAbsent(entry.playerId(), ignored -> {
                            return new MutableQueueStats();
                        }).accept(entry);
                    }
                }
            }
            for (Map.Entry<UUID, MutableQueueStats> entry2 : statsByPlayer.entrySet()) {
                Player player = Bukkit.getPlayer(entry2.getKey());
                if (player != null && player.isOnline()) {
                    MutableQueueStats stats = entry2.getValue();
                    if (stats.modeCount > 0) {
                        long waitSeconds = stats.waitSeconds(now);
                        String modeWord = stats.modeCount == 1 ? "mode" : "modes";
                        String message = this.plugin.messages().get("queue.searching-actionbar", Map.of("modes", String.valueOf(stats.modeCount), "mode_word", modeWord, "time", String.valueOf(waitSeconds), "time_formatted", formatWaitTime(waitSeconds)));
                        player.sendActionBar(message);
                    }
                }
            }
        }, 20L, 20L);
    }

    public void shutdown() {
        stopActionbarTask();
        this.queues.clear();
        this.queuedKeyByPlayer.clear();
    }

    private void stopActionbarTask() {
        if (this.actionbarTask != null) {
            this.actionbarTask.cancel();
            this.actionbarTask = null;
        }
    }

    private static String key(String kitId, int rounds) {
        return normalizeKit(kitId) + ":" + Math.max(1, Math.min(50, rounds));
    }

    private static String normalizeKit(String kitId) {
        return kitId == null ? "" : kitId.toLowerCase(Locale.ROOT);
    }

    public boolean toggleQueue(Player player, Kit kit, int rounds) {
        Player opponent;
        if (player == null || kit == null) {
            return false;
        }
        UUID playerId = player.getUniqueId();
        if (!this.queueToggleCooldown.test(playerId)) {
            return isQueued(playerId, kit.id());
        }
        int rounds2 = Math.max(1, Math.min(50, rounds));
        if (this.plugin.duelManager().isInMatch(playerId)) {
            leaveAllQuiet(playerId);
            this.plugin.messages().send(player, "queue.already-in-match");
            return false;
        }
        purgeInvalidEntries();
        String targetKey = key(kit.id(), rounds2);
        String existingKey = findQueueKey(playerId);
        if (existingKey != null) {
            removeFromQueue(existingKey, playerId);
            if (existingKey.equals(targetKey)) {
                return false;
            }
        }
        LinkedHashMap<UUID, QueueEntry> queue = this.queues.computeIfAbsent(targetKey, ignored -> {
            return new LinkedHashMap();
        });
        QueueEntry selfEntry = new QueueEntry(playerId, kit.id(), rounds2, System.currentTimeMillis());
        QueueEntry opponentEntry = takeFirstValidOpponent(targetKey, queue, playerId);
        if (opponentEntry != null && (opponent = Bukkit.getPlayer(opponentEntry.playerId())) != null && opponent.isOnline() && !this.plugin.duelManager().isInMatch(opponent.getUniqueId())) {
            cleanup(targetKey, queue);
            if (this.plugin.duelManager().startQueuedMatch(player, opponent, kit, rounds2)) {
                return true;
            }
            if (!this.plugin.duelManager().isInMatch(playerId) && !this.plugin.duelManager().isInMatch(opponent.getUniqueId())) {
                restoreEntry(targetKey, opponentEntry);
                restoreEntry(targetKey, selfEntry);
                return true;
            }
            return false;
        }
        restoreEntry(targetKey, selfEntry);
        return true;
    }

    private void tryMatchQueues() {
        QueueEntry firstEntry;
        for (String queueKey : new ArrayList(this.queues.keySet())) {
            LinkedHashMap<UUID, QueueEntry> queue = this.queues.get(queueKey);
            if (queue != null && queue.size() >= 2) {
                while (true) {
                    if (queue.size() < 2 || (firstEntry = takeFirstValidEntry(queueKey, queue)) == null) {
                        break;
                    }
                    QueueEntry secondEntry = takeFirstValidEntry(queueKey, queue);
                    if (secondEntry == null) {
                        restoreEntry(queueKey, firstEntry);
                        break;
                    }
                    Player first = Bukkit.getPlayer(firstEntry.playerId());
                    Player second = Bukkit.getPlayer(secondEntry.playerId());
                    Kit kit = this.plugin.kitManager().get(firstEntry.kitId());
                    int rounds = firstEntry.rounds();
                    if (first != null && second != null && first.isOnline() && second.isOnline() && kit != null && !this.plugin.duelManager().isInMatch(first.getUniqueId()) && !this.plugin.duelManager().isInMatch(second.getUniqueId())) {
                        if (this.plugin.arenaManager().findAvailable("random", kit).isEmpty()) {
                            restoreEntry(queueKey, firstEntry);
                            restoreEntry(queueKey, secondEntry);
                            break;
                        } else if (!this.plugin.duelManager().startQueuedMatch(first, second, kit, rounds)) {
                            if (!this.plugin.duelManager().isInMatch(first.getUniqueId())) {
                                restoreEntry(queueKey, firstEntry);
                            }
                            if (!this.plugin.duelManager().isInMatch(second.getUniqueId())) {
                                restoreEntry(queueKey, secondEntry);
                            }
                        } else {
                            cleanup(queueKey, queue);
                        }
                    }
                }
            }
        }
    }

    private QueueEntry takeFirstValidEntry(String queueKey, LinkedHashMap<UUID, QueueEntry> queue) {
        Iterator<Map.Entry<UUID, QueueEntry>> iterator = queue.entrySet().iterator();
        while (iterator.hasNext()) {
            QueueEntry entry = iterator.next().getValue();
            iterator.remove();
            if (!isValidQueuedEntry(entry)) {
                unregisterEntry(entry);
            } else {
                unregisterEntry(entry);
                cleanup(queueKey, queue);
                return entry;
            }
        }
        return null;
    }

    public String formatWaitTime(long seconds) {
        long safeSeconds = Math.max(0L, seconds);
        long minutes = safeSeconds / 60;
        long remainingSeconds = safeSeconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainingSeconds));
    }

    private QueueEntry takeFirstValidOpponent(String queueKey, LinkedHashMap<UUID, QueueEntry> queue, UUID self) {
        Iterator<Map.Entry<UUID, QueueEntry>> iterator = queue.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, QueueEntry> mapEntry = iterator.next();
            QueueEntry entry = mapEntry.getValue();
            if (entry == null || entry.playerId().equals(self) || !isValidQueuedEntry(entry)) {
                iterator.remove();
                unregisterEntry(entry);
            } else {
                iterator.remove();
                unregisterEntry(entry);
                cleanup(queueKey, queue);
                return entry;
            }
        }
        return null;
    }

    private boolean isValidQueuedEntry(QueueEntry entry) {
        Player candidate;
        return (entry == null || entry.playerId() == null || (candidate = Bukkit.getPlayer(entry.playerId())) == null || !candidate.isOnline() || this.plugin.duelManager().isInMatch(candidate.getUniqueId())) ? false : true;
    }

    private String findQueueKey(UUID playerId) {
        if (playerId == null) {
            return null;
        }
        String indexedKey = this.queuedKeyByPlayer.get(playerId);
        if (indexedKey != null) {
            LinkedHashMap<UUID, QueueEntry> indexedQueue = this.queues.get(indexedKey);
            if (indexedQueue != null && indexedQueue.containsKey(playerId)) {
                return indexedKey;
            }
            this.queuedKeyByPlayer.remove(playerId);
        }
        for (Map.Entry<String, LinkedHashMap<UUID, QueueEntry>> entry : this.queues.entrySet()) {
            if (entry.getValue().containsKey(playerId)) {
                this.queuedKeyByPlayer.put(playerId, entry.getKey());
                return entry.getKey();
            }
        }
        return null;
    }

    private QueueEntry removeFromQueue(String queueKey, UUID playerId) {
        if (queueKey == null || playerId == null) {
            return null;
        }
        LinkedHashMap<UUID, QueueEntry> queue = this.queues.get(queueKey);
        if (queue == null) {
            this.queuedKeyByPlayer.remove(playerId);
            return null;
        }
        QueueEntry removed = queue.remove(playerId);
        unregisterEntry(removed);
        cleanup(queueKey, queue);
        return removed;
    }

    private void restoreEntry(String queueKey, QueueEntry entry) {
        if (queueKey == null || entry == null || entry.playerId() == null) {
            return;
        }
        String existing = findQueueKey(entry.playerId());
        if (existing != null && !existing.equals(queueKey)) {
            removeFromQueue(existing, entry.playerId());
        }
        LinkedHashMap<UUID, QueueEntry> queue = this.queues.computeIfAbsent(queueKey, ignored -> {
            return new LinkedHashMap();
        });
        QueueEntry previous = queue.put(entry.playerId(), entry);
        unregisterEntry(previous);
        registerEntry(queueKey, entry);
    }

    private void registerEntry(String queueKey, QueueEntry entry) {
        if (queueKey == null || entry == null || entry.playerId() == null) {
            return;
        }
        this.queuedKeyByPlayer.put(entry.playerId(), queueKey);
    }

    private void unregisterEntry(QueueEntry entry) {
        if (entry == null || entry.playerId() == null) {
            return;
        }
        this.queuedKeyByPlayer.remove(entry.playerId());
    }

    private void cleanup(String key, LinkedHashMap<UUID, QueueEntry> queue) {
        if (queue == null || queue.isEmpty()) {
            this.queues.remove(key);
        }
    }

    private void purgeInvalidEntries() {
        Iterator<Map.Entry<String, LinkedHashMap<UUID, QueueEntry>>> queueIterator = this.queues.entrySet().iterator();
        while (queueIterator.hasNext()) {
            Map.Entry<String, LinkedHashMap<UUID, QueueEntry>> queueEntry = queueIterator.next();
            Iterator<Map.Entry<UUID, QueueEntry>> entryIterator = queueEntry.getValue().entrySet().iterator();
            while (entryIterator.hasNext()) {
                QueueEntry entry = entryIterator.next().getValue();
                if (!isValidQueuedEntry(entry)) {
                    entryIterator.remove();
                    unregisterEntry(entry);
                }
            }
            if (queueEntry.getValue().isEmpty()) {
                queueIterator.remove();
            }
        }
        this.queuedKeyByPlayer.entrySet().removeIf(entry2 -> {
            LinkedHashMap<UUID, QueueEntry> queue = this.queues.get(entry2.getValue());
            return queue == null || !queue.containsKey(entry2.getKey());
        });
    }

    public int leaveAllQuiet(UUID playerId) {
        if (playerId == null) {
            return 0;
        }
        int removed = 0;
        String queueKey = findQueueKey(playerId);
        if (queueKey != null && removeFromQueue(queueKey, playerId) != null) {
            removed = 0 + 1;
        }
        Iterator<Map.Entry<String, LinkedHashMap<UUID, QueueEntry>>> it = this.queues.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, LinkedHashMap<UUID, QueueEntry>> entry = it.next();
            QueueEntry removedEntry = entry.getValue().remove(playerId);
            if (removedEntry != null) {
                removed++;
                unregisterEntry(removedEntry);
            }
            if (entry.getValue().isEmpty()) {
                it.remove();
            }
        }
        this.queuedKeyByPlayer.remove(playerId);
        return removed;
    }

    public void leaveAll(UUID playerId) {
        leaveAllQuiet(playerId);
    }

    public boolean leave(UUID playerId, String kitId) {
        if (playerId == null) {
            return false;
        }
        boolean removed = false;
        String prefix = normalizeKit(kitId) + ":";
        Iterator<Map.Entry<String, LinkedHashMap<UUID, QueueEntry>>> it = this.queues.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, LinkedHashMap<UUID, QueueEntry>> entry = it.next();
            if (entry.getKey().startsWith(prefix)) {
                QueueEntry removedEntry = entry.getValue().remove(playerId);
                if (removedEntry != null) {
                    removed = true;
                    unregisterEntry(removedEntry);
                }
                if (entry.getValue().isEmpty()) {
                    it.remove();
                }
            }
        }
        if (removed) {
            this.queuedKeyByPlayer.remove(playerId);
        }
        return removed;
    }

    public int countInQueue(String kitId) {
        String normalized = normalizeKit(kitId);
        if (normalized.isBlank()) {
            return 0;
        }
        int count = 0;
        String prefix = normalized + ":";
        for (Map.Entry<String, LinkedHashMap<UUID, QueueEntry>> entry : this.queues.entrySet()) {
            if (entry.getKey().startsWith(prefix)) {
                count += entry.getValue().size();
            }
        }
        return count;
    }

    public int countPlayerQueues(UUID playerId) {
        return getStats(playerId).modeCount();
    }

    public long getQueueWaitSeconds(UUID playerId) {
        return getStats(playerId).waitSeconds();
    }

    public QueueStats getStats(UUID playerId) {
        String queueKey;
        if (playerId != null && (queueKey = findQueueKey(playerId)) != null) {
            LinkedHashMap<UUID, QueueEntry> queue = this.queues.get(queueKey);
            QueueEntry entry = queue == null ? null : queue.get(playerId);
            if (entry == null) {
                this.queuedKeyByPlayer.remove(playerId);
                return new QueueStats(0, 0L);
            }
            long waitSeconds = Math.max(0L, (System.currentTimeMillis() - entry.joinedAt()) / 1000);
            return new QueueStats(1, waitSeconds);
        }
        return new QueueStats(0, 0L);
    }

    public boolean isQueued(UUID playerId, String kitId) {
        if (playerId == null || kitId == null || kitId.isBlank()) {
            return false;
        }
        String prefix = normalizeKit(kitId) + ":";
        String indexedKey = findQueueKey(playerId);
        if (indexedKey != null) {
            return indexedKey.startsWith(prefix);
        }
        return false;
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/queue/QueueManager$MutableQueueStats.class */
    private static final class MutableQueueStats {
        private int modeCount;
        private long earliestJoinedAt = Long.MAX_VALUE;

        private MutableQueueStats() {
        }

        private void accept(QueueEntry entry) {
            if (entry == null) {
                return;
            }
            this.modeCount++;
            this.earliestJoinedAt = Math.min(this.earliestJoinedAt, entry.joinedAt());
        }

        private long waitSeconds(long now) {
            if (this.earliestJoinedAt == Long.MAX_VALUE) {
                return 0L;
            }
            return Math.max(0L, (now - this.earliestJoinedAt) / 1000);
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/queue/QueueManager$QueueStats.class */
    public static final class QueueStats extends Record {
        private final int modeCount;
        private final long waitSeconds;

        public QueueStats(int modeCount, long waitSeconds) {
            this.modeCount = modeCount;
            this.waitSeconds = waitSeconds;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, QueueStats.class), QueueStats.class, "modeCount;waitSeconds", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->modeCount:I", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->waitSeconds:J").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, QueueStats.class), QueueStats.class, "modeCount;waitSeconds", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->modeCount:I", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->waitSeconds:J").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, QueueStats.class, Object.class), QueueStats.class, "modeCount;waitSeconds", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->modeCount:I", "FIELD:Ldev/rean/pvpcore/queue/QueueManager$QueueStats;->waitSeconds:J").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public int modeCount() {
            return this.modeCount;
        }

        public long waitSeconds() {
            return this.waitSeconds;
        }
    }
}
