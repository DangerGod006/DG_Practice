package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.friends.FriendManager;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/FriendCommand.class */
public final class FriendCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = List.of("add", "accept", "remove");
    private final PvPCorePlugin plugin;

    public FriendCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (args.length == 0) {
            usage(commandSender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "add":
                if (args.length < 2) {
                    this.plugin.messages().sendMiniMessage(commandSender, "friends.usage-add", Map.of());
                    break;
                } else {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null || !target.isOnline()) {
                        this.plugin.messages().sendMiniMessage(commandSender, "social.error-player-not-found", Map.of());
                    } else {
                        this.plugin.friendManager().sendRequest(commandSender, target);
                    }
                    break;
                }
                break;
            case "accept":
                if (args.length < 2) {
                    this.plugin.messages().sendMiniMessage(commandSender, "friends.usage-accept", Map.of());
                    break;
                } else {
                    this.plugin.friendManager().acceptRequest(commandSender, args[1]);
                    break;
                }
                break;
            case "remove":
                if (args.length < 2) {
                    this.plugin.messages().sendMiniMessage(commandSender, "friends.usage-remove", Map.of());
                    break;
                } else {
                    this.plugin.friendManager().removeRelationOrRequest(commandSender, args[1]);
                    break;
                }
                break;
            default:
                usage(commandSender);
                break;
        }
        return true;
    }

    private void usage(Player player) {
        this.plugin.messages().sendMiniMessage(player, "friends.usage", Map.of());
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String input = args[0].toLowerCase(Locale.ROOT);
            for (String subcommand : SUBCOMMANDS) {
                if (subcommand.startsWith(input)) {
                    out.add(subcommand);
                }
            }
            return out;
        }
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (args.length == 2) {
                String sub = args[0].toLowerCase(Locale.ROOT);
                String input2 = args[1].toLowerCase(Locale.ROOT);
                if (sub.equals("add")) {
                    for (Player online : Bukkit.getOnlinePlayers()) {
                        if (!online.equals(player) && (!this.plugin.playerData().isInvisible(online.getUniqueId()) || this.plugin.playerData().areFriends(player.getUniqueId(), online.getUniqueId()))) {
                            if (!this.plugin.playerData().areFriends(player.getUniqueId(), online.getUniqueId()) && !this.plugin.playerData().hasOutgoingFriendRequest(player.getUniqueId(), online.getUniqueId()) && online.getName().toLowerCase(Locale.ROOT).startsWith(input2)) {
                                out.add(online.getName());
                            }
                        }
                    }
                    return out;
                }
                if (sub.equals("accept")) {
                    for (FriendManager.RequestEntry request : this.plugin.friendManager().incomingRequests(player.getUniqueId())) {
                        if (request.name().toLowerCase(Locale.ROOT).startsWith(input2)) {
                            out.add(request.name());
                        }
                    }
                    return out;
                }
                if (sub.equals("remove")) {
                    Set<String> names = new LinkedHashSet<>();
                    for (FriendManager.FriendEntry friend : this.plugin.friendManager().friends(player.getUniqueId())) {
                        names.add(friend.name());
                    }
                    for (FriendManager.RequestEntry request2 : this.plugin.friendManager().incomingRequests(player.getUniqueId())) {
                        names.add(request2.name());
                    }
                    for (FriendManager.RequestEntry request3 : this.plugin.friendManager().outgoingRequests(player.getUniqueId())) {
                        names.add(request3.name());
                    }
                    for (String name : names) {
                        if (name != null && name.toLowerCase(Locale.ROOT).startsWith(input2)) {
                            out.add(name);
                        }
                    }
                }
                return out;
            }
        }
        return out;
    }
}
