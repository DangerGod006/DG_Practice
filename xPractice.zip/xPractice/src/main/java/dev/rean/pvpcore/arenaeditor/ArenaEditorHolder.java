package dev.rean.pvpcore.arenaeditor;

import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorHolder.class */
public final class ArenaEditorHolder implements InventoryHolder {
    private final UUID playerId;
    private final String arenaId;

    public ArenaEditorHolder(UUID playerId, String arenaId) {
        this.playerId = playerId;
        this.arenaId = arenaId;
    }

    public UUID playerId() {
        return this.playerId;
    }

    public String arenaId() {
        return this.arenaId;
    }

    @NotNull
    public Inventory getInventory() {
        throw new UnsupportedOperationException("Virtual holder");
    }
}
