package dev.rean.pvpcore.util;

import dev.rean.pvpcore.model.Kit;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/U.class */
public final class U {
    private U() {
    }

    public static void applyKit(Player p, Kit kit) {
        if (kit == null) {
            return;
        }
        clearTransientInventoryState(p);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand((ItemStack) null);
        ItemStack[] contents = cloneArray(kit.contents());
        if (contents != null && contents.length != inv.getStorageContents().length) {
            ItemStack[] truncated = new ItemStack[inv.getStorageContents().length];
            System.arraycopy(contents, 0, truncated, 0, Math.min(contents.length, truncated.length));
            contents = truncated;
        }
        inv.setStorageContents(contents);
        inv.setArmorContents(cloneArray(kit.armor()));
        inv.setItemInOffHand(cloneItem(kit.offhand()));
        p.updateInventory();
    }

    public static void clearInventory(Player p) {
        clearTransientInventoryState(p);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand((ItemStack) null);
        p.updateInventory();
    }

    private static void clearTransientInventoryState(Player p) {
        p.setItemOnCursor((ItemStack) null);
        if (p.getOpenInventory() != null && p.getOpenInventory().getTopInventory().getType() == InventoryType.CRAFTING) {
            p.getOpenInventory().getTopInventory().clear();
        }
    }

    public static void writeLocation(FileConfiguration cfg, String path, Location loc) {
        writeLocation(cfg, path, loc, null);
    }

    public static void writeLocation(FileConfiguration cfg, String path, Location loc, String fallbackWorldName) {
        if (loc == null) {
            return;
        }
        String worldName = loc.getWorld() != null ? loc.getWorld().getName() : fallbackWorldName;
        cfg.set(path + ".world", worldName);
        cfg.set(path + ".x", Double.valueOf(loc.getX()));
        cfg.set(path + ".y", Double.valueOf(loc.getY()));
        cfg.set(path + ".z", Double.valueOf(loc.getZ()));
        cfg.set(path + ".yaw", Float.valueOf(loc.getYaw()));
        cfg.set(path + ".pitch", Float.valueOf(loc.getPitch()));
    }

    public static Location readLocation(FileConfiguration cfg, String path) {
        return readLocation(cfg, path, null);
    }

    public static Location readLocation(FileConfiguration cfg, String path, String fallbackWorldName) {
        if (cfg == null || path == null || path.isBlank()) {
            return null;
        }
        String world = cfg.getString(path + ".world", fallbackWorldName);
        World w = (world == null || world.isBlank()) ? null : Bukkit.getWorld(world);
        if (w == null) {
            return null;
        }
        double x = cfg.getDouble(path + ".x");
        double y = cfg.getDouble(path + ".y");
        double z = cfg.getDouble(path + ".z");
        float yaw = (float) cfg.getDouble(path + ".yaw");
        float pitch = (float) cfg.getDouble(path + ".pitch");
        return new Location(w, x, y, z, yaw, pitch);
    }

    public static ItemStack[] cloneArray(ItemStack[] source) {
        if (source == null) {
            return null;
        }
        ItemStack[] copy = new ItemStack[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = cloneItem(source[i]);
        }
        return copy;
    }

    public static ItemStack cloneItem(ItemStack item) {
        if (item == null) {
            return null;
        }
        return item.clone();
    }
}
