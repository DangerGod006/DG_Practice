package dev.rean.pvpcore.integrations;

import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/integrations/ProtectionHook.class */
public interface ProtectionHook {
    public static final ProtectionHook ALLOW_ALL = (block, source) -> {
        return true;
    };

    boolean canExplosionBreak(Block block, Entity entity);

    static ProtectionHook create(JavaPlugin plugin) {
        if (Bukkit.getPluginManager().getPlugin("WorldGuard") == null) {
            return ALLOW_ALL;
        }
        try {
            return new WorldGuardProtectionHook(plugin);
        } catch (Throwable th) {
            return ALLOW_ALL;
        }
    }
}
