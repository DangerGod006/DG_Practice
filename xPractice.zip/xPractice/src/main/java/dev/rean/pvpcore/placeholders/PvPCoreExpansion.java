package dev.rean.pvpcore.placeholders;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.queue.QueueManager;
import java.util.Locale;
import java.util.UUID;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/placeholders/PvPCoreExpansion.class */
public final class PvPCoreExpansion extends PlaceholderExpansion implements Relational {
    private final PvPCorePlugin plugin;

    public PvPCoreExpansion(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @NotNull
    public String getIdentifier() {
        return "pvpcore";
    }

    @NotNull
    public String getAuthor() {
        return "Rean";
    }

    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    @Nullable
    public String onPlaceholderRequest(Player viewer, Player target, @NotNull String params) {
        UUID viewerId;
        UUID targetId;
        boolean sameVisibleMatch;
        DuelMatch targetMatch;
        if (viewer == null || target == null) {
            return "";
        }
        String key = params.toLowerCase(Locale.ROOT);
        viewerId = viewer.getUniqueId();
        targetId = target.getUniqueId();
        sameVisibleMatch = this.plugin.duelManager().sharesVisibleMatch(viewerId, targetId);
        targetMatch = this.plugin.duelManager().getMatch(targetId);
        switch (key) {
            case "not_self":
                return String.valueOf(!viewerId.equals(targetId));
            case "same_match":
            case "match_visible":
            case "duel_visible":
                return String.valueOf(sameVisibleMatch);
            case "duel_tab_name":
            case "match_tab_name":
                return (!sameVisibleMatch || targetMatch == null) ? "" : duelTabName(targetMatch, target);
            default:
                return "";
        }
    }

    @Nullable
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        boolean isRed;
        Player opponent;
        String opponentName;
        String redColor;
        String blueColor;
        String selfColor;
        String opponentColor;
        DuelMatch spectated;
        if (player == null) {
            return "";
        }
        String key = params.toLowerCase(Locale.ROOT);
        UUID playerId = player.getUniqueId();
        QueueManager.QueueStats queueStats = this.plugin.queueManager().getStats(playerId);
        if (key.startsWith("inqueue_")) {
            return String.valueOf(this.plugin.queueManager().countInQueue(params.substring("inqueue_".length())));
        }
        if (key.startsWith("playing_")) {
            return String.valueOf(this.plugin.duelManager().countQueuedAndPlaying(params.substring("playing_".length())));
        }
        if (key.startsWith("queued_")) {
            return this.plugin.queueManager().isQueued(playerId, params.substring("queued_".length())) ? "&9(Queued)" : "";
        }
        if (key.startsWith("queueboolean_")) {
            return this.plugin.queueManager().isQueued(playerId, params.substring("queueboolean_".length())) ? "&c◀ Click to leave!" : "&e▶ Click to play!";
        }
        if (key.equals("queue_modes")) {
            return String.valueOf(queueStats.modeCount());
        }
        if (key.equals("queue_wait")) {
            return String.valueOf(queueStats.waitSeconds());
        }
        if (key.equals("queue_wait_formatted")) {
            return this.plugin.queueManager().formatWaitTime(queueStats.waitSeconds());
        }
        if (key.equals("displayname")) {
            return this.plugin.playerData().getPlainDisplayName(player);
        }
        if (key.equals("displayname_raw")) {
            return this.plugin.playerData().getDisplayNameRaw(player);
        }
        if (key.equals("status")) {
            return this.plugin.playerData().getStatus(playerId).colorCode();
        }
        if (key.equals("status_name")) {
            return this.plugin.playerData().getStatus(playerId).displayName();
        }
        if (key.equals("duels_enabled")) {
            return String.valueOf(!this.plugin.playerData().areDuelRequestsDisabled(playerId));
        }
        if (key.equals("duels_state")) {
            return this.plugin.playerData().areDuelRequestsDisabled(playerId) ? "&cDisabled" : "&aEnabled";
        }
        if (key.equals("sneak_status")) {
            return this.plugin.sneakStatus().status(playerId);
        }
        if (key.equals("sneak_status_name")) {
            return this.plugin.sneakStatus().statusName(playerId);
        }
        if (key.equals("sneak_status_friends")) {
            return String.valueOf(this.plugin.sneakStatus().isFriends(playerId));
        }
        if (key.equals("friends_count")) {
            return String.valueOf(this.plugin.playerData().friendCount(playerId));
        }
        if (key.equals("friends_online")) {
            return String.valueOf(this.plugin.playerData().onlineFriendCount(playerId));
        }
        if (key.equals("spectating")) {
            return String.valueOf(this.plugin.spectatorManager().isSpectating(playerId));
        }
        if (key.equals("spectating_match_id")) {
            return this.plugin.spectatorManager().spectatedMatchId(playerId);
        }
        if (key.equals("state_icon") || key.equals("tab_status_icon") || key.equals("player_state_icon") || key.equals("duel_status_icon")) {
            return stateIcon(playerId, true);
        }
        if (key.equals("state_icon_empty") || key.equals("tab_status_icon_empty") || key.equals("player_state_icon_empty") || key.equals("duel_status_icon_empty")) {
            return stateIcon(playerId, false);
        }
        if (key.equals("pops") || key.equals("totem_pops") || key.equals("duel_pops") || key.equals("duel_totem_pops")) {
            DuelMatch match = this.plugin.duelManager().getMatch(playerId);
            return match == null ? "" : match.formattedTotemPops(playerId);
        }
        if (key.equals("pops_raw") || key.equals("totem_pops_raw") || key.equals("duel_pops_raw") || key.equals("duel_totem_pops_raw")) {
            DuelMatch match2 = this.plugin.duelManager().getMatch(playerId);
            return match2 == null ? "0" : String.valueOf(match2.totemPops(playerId));
        }
        if (key.equals("global_pops") || key.equals("lifetime_pops")) {
            return this.plugin.playerData().formattedTotemPops(playerId);
        }
        if (key.equals("global_pops_raw") || key.equals("lifetime_pops_raw")) {
            return String.valueOf(this.plugin.playerData().totemPops(playerId));
        }
        if (key.equals("fast_crystals_state")) {
            return this.plugin.playerData().hasFastCrystalsEnabled(playerId) ? "&aON" : "&cOFF";
        }
        if (key.equals("duel_pops_state")) {
            return this.plugin.playerData().hasDuelPopsEnabled(playerId) ? "&aON" : "&cOFF";
        }
        if (key.equals("opponent_pops") || key.equals("opponent_totem_pops")) {
            DuelMatch match3 = this.plugin.duelManager().getMatch(playerId);
            return match3 == null ? "" : match3.formattedOpponentTotemPops(playerId);
        }
        if (key.equals("opponent_pops_raw") || key.equals("opponent_totem_pops_raw")) {
            DuelMatch match4 = this.plugin.duelManager().getMatch(playerId);
            return match4 == null ? "0" : String.valueOf(match4.opponentTotemPops(playerId));
        }
        if (key.equals("tier")) {
            return this.plugin.tierResolver().getDisplayedTier(playerId);
        }
        DuelMatch match5 = this.plugin.duelManager().getMatch(playerId);
        if (match5 == null) {
            spectated = this.plugin.spectatorManager().spectatedMatch(playerId);
            switch (key) {
                case "in_match":
                    return "false";
                case "in_match_or_spectating":
                    return String.valueOf(spectated != null);
                case "match_id":
                    return spectated == null ? "" : this.plugin.duelManager().matchId(spectated);
                case "duel_tab_name":
                case "match_tab_name":
                    return "";
                case "opponent":
                case "opponent_colored":
                case "opponent_tab_name":
                case "arena":
                case "arena_id":
                case "arena_name":
                case "team":
                case "team_color":
                case "score":
                case "red_pops":
                case "red_totem_pops":
                case "red_pops_raw":
                case "red_totem_pops_raw":
                case "blue_pops":
                case "blue_totem_pops":
                case "blue_pops_raw":
                case "blue_totem_pops_raw":
                    return "";
                default:
                    return "";
            }
        }
        isRed = match5.red().equals(playerId);
        UUID opponentId = isRed ? match5.blue() : match5.red();
        opponent = Bukkit.getPlayer(opponentId);
        opponentName = opponent != null ? opponent.getName() : "";
        redColor = match5.redColor();
        blueColor = match5.blueColor();
        selfColor = isRed ? redColor : blueColor;
        opponentColor = isRed ? blueColor : redColor;
        switch (key) {
            case "in_match":
            case "in_match_or_spectating":
                return "true";
            case "match_id":
                return this.plugin.duelManager().matchId(match5);
            case "opponent":
                return opponentName;
            case "opponent_colored":
                return opponentColor + opponentName;
            case "team":
                return isRed ? "red" : "blue";
            case "team_color":
                return selfColor;
            case "duel_tab_name":
            case "match_tab_name":
                return duelTabName(match5, player);
            case "opponent_tab_name":
                return opponent == null ? "" : duelTabName(match5, opponent);
            case "arena":
                return match5.arena().displayName();
            case "arena_id":
                return match5.arena().id();
            case "arena_name":
                return match5.arena().displayName();
            case "score":
                int left = isRed ? match5.redWins() : match5.blueWins();
                int right = isRed ? match5.blueWins() : match5.redWins();
                String leftColor = isRed ? redColor : blueColor;
                String rightColor = isRed ? blueColor : redColor;
                return leftColor + left + " &7- " + rightColor + right;
            case "red_pops":
            case "red_totem_pops":
                return match5.formattedTotemPopsFor(playerId, match5.red());
            case "red_pops_raw":
            case "red_totem_pops_raw":
                return String.valueOf(match5.totemPops(match5.red()));
            case "blue_pops":
            case "blue_totem_pops":
                return match5.formattedTotemPopsFor(playerId, match5.blue());
            case "blue_pops_raw":
            case "blue_totem_pops_raw":
                return String.valueOf(match5.totemPops(match5.blue()));
            default:
                return "";
        }
    }

    private String stateIcon(UUID playerId, boolean showLobbyIcon) {
        return this.plugin.spectatorManager().isSpectating(playerId) ? "&7👁" : this.plugin.duelManager().isInMatch(playerId) ? "&7⚔" : showLobbyIcon ? "&7🌲" : "";
    }

    private String duelTabName(DuelMatch match, Player target) {
        return this.plugin.tabScoreboardHook().formatDuelTabName(match, target);
    }
}
