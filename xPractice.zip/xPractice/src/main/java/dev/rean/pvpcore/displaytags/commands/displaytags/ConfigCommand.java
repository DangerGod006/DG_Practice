package dev.rean.pvpcore.displaytags.commands.displaytags;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.commands.framework.CommandGroup;
import dev.rean.pvpcore.displaytags.commands.framework.Subcommand;
import dev.rean.pvpcore.displaytags.config.NametagConfig;
import dev.rean.pvpcore.displaytags.config.TagDisplayConfig;
import dev.rean.pvpcore.displaytags.utils.helpers.MessageHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.bukkit.command.CommandSender;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/displaytags/ConfigCommand.class */
public class ConfigCommand extends Subcommand {
    public ConfigCommand(DisplayTags plugin, CommandGroup parentCommand) {
        super(plugin, parentCommand);
        super.setName("config");
        super.setDescription("View the plugin configuration.");
        super.setPermission("displaytags.admin");
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.Subcommand
    public void execute(CommandSender sender, String[] args) {
        NametagConfig config = this.plugin.config().getNametagConfig();
        List<String> messages = new ArrayList<>();
        messages.add("<dark_gray>• <white>Nametags");
        messages.add("  <white>Enabled <dark_gray>→ " + booleanToString(config.isEnabled()));
        messages.add("  <white>Show Self <dark_gray>→ " + booleanToString(!config.shouldHideSelf()));
        messages.add("  <white>Update Interval <dark_gray>→ <gray>" + config.getUpdateInterval() + " seconds");
        messages.add("  <white>Visibility Distance <dark_gray>→ <gray>" + config.getVisibilityDistance() + " blocks");
        int index = 1;
        for (TagDisplayConfig display : config.getDisplays()) {
            List<String> scaleText = toVectorText(display.getScale());
            List<String> positionText = toVectorText(display.getPosition());
            messages.add("<dark_gray>• <white>Tag " + index + " <gray>(" + display.getId() + ")");
            messages.add("  <white>Lines <dark_gray>→ <hover:show_text:'{lines}'><gray><u>Hover".replace("{lines}", String.join("\n", display.getLines())));
            messages.add("  <white>Text Shadow <dark_gray>→ " + booleanToString(display.hasTextShadow()));
            messages.add("  <white>See Through <dark_gray>→ " + booleanToString(display.isSeeThrough()));
            messages.add("  <white>Text Alignment <dark_gray>→ <gray>" + display.getTextAlignment().name());
            messages.add("  <white>Background <dark_gray>→ " + color(display.getBackground()) + background(display.getBackground()));
            messages.add("  <white>Billboard <dark_gray>→ <gray>" + display.getBillboard().name());
            messages.add("  <white>Scale <dark_gray>→ <hover:show_text:'{scale}'><gray><u>Hover".replace("{scale}", String.join("\n", scaleText)));
            messages.add("  <white>Position <dark_gray>→ <hover:show_text:'{position}'><gray><u>Hover".replace("{position}", String.join("\n", positionText)));
            index++;
        }
        sender.sendMessage("");
        MessageHelper.send(sender, "<dark_gray>[<#00BFFF>&lᴘʟᴜɢɪɴ ᴄᴏɴꜰɪɢᴜʀᴀᴛɪᴏɴ<dark_gray>]");
        MessageHelper.send(sender, messages);
        sender.sendMessage("");
    }

    private List<String> toVectorText(Vector vector) {
        List<String> vectorText = new ArrayList<>();
        vectorText.add("<white>X <dark_gray>→ <gray>" + vector.getX());
        vectorText.add("<white>Y <dark_gray>→ <gray>" + vector.getY());
        vectorText.add("<white>Z <dark_gray>→ <gray>" + vector.getZ());
        return vectorText;
    }

    private String booleanToString(boolean b) {
        return b ? "<green>Yes" : "<red>No";
    }

    private String background(String background) {
        return Objects.equals(background, "default") ? "Default" : Objects.equals(background, "transparent") ? "Transparent" : background;
    }

    private String color(String hex) {
        return Objects.equals(hex, "default") ? "<gray>" : Objects.equals(hex, "transparent") ? "<white>" : "<" + hex + ">";
    }
}
