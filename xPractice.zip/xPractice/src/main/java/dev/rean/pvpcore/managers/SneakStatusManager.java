package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/SneakStatusManager.class */
public final class SneakStatusManager {
    private static final long TOGGLE_COOLDOWN_MS = 2000;
    private static final String FRIENDS_STATE = "friends";
    private final PvPCorePlugin plugin;
    private final Map<UUID, String> states = new ConcurrentHashMap();
    private final Map<UUID, Long> lastToggle = new ConcurrentHashMap();

    public SneakStatusManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public String status(UUID uniqueId) {
        return uniqueId == null ? "" : (this.plugin.spectatorManager() == null || !this.plugin.spectatorManager().isSpectating(uniqueId)) ? (this.plugin.duelManager() == null || !this.plugin.duelManager().isInMatch(uniqueId)) ? this.states.getOrDefault(uniqueId, "") : "duel" : "spectating";
    }

    public boolean isFriends(UUID uniqueId) {
        return FRIENDS_STATE.equals(status(uniqueId));
    }

    public String statusName(UUID uniqueId) {
        return FRIENDS_STATE.equals(status(uniqueId)) ? "&e☻ &bFriends" : "&a🌎 &bRegion";
    }

    public boolean toggle(Player player) {
        if (player == null) {
            return false;
        }
        UUID uniqueId = player.getUniqueId();
        if (this.plugin.spectatorManager() != null && this.plugin.spectatorManager().isSpectating(uniqueId)) {
            return false;
        }
        if (this.plugin.duelManager() != null && this.plugin.duelManager().isInMatch(uniqueId)) {
            return false;
        }
        long now = System.currentTimeMillis();
        long last = this.lastToggle.getOrDefault(uniqueId, 0L).longValue();
        if (now - last < TOGGLE_COOLDOWN_MS) {
            return false;
        }
        this.lastToggle.put(uniqueId, Long.valueOf(now));
        if (FRIENDS_STATE.equals(this.states.get(uniqueId))) {
            this.states.remove(uniqueId);
            return true;
        }
        this.states.put(uniqueId, FRIENDS_STATE);
        return true;
    }

    public void clear(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        this.states.remove(uniqueId);
        this.lastToggle.remove(uniqueId);
    }
}
