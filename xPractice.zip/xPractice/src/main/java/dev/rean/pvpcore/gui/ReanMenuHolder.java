package dev.rean.pvpcore.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/ReanMenuHolder.class */
public final class ReanMenuHolder implements InventoryHolder {
    private final GuiSession session;

    public ReanMenuHolder(GuiSession session) {
        this.session = session;
    }

    public GuiSession session() {
        return this.session;
    }

    @NotNull
    public Inventory getInventory() {
        throw new UnsupportedOperationException("ReanMenuHolder#getInventory is not used");
    }
}
