package dev.rean.pvpcore.duel;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.gui.KitSelectGui;
import dev.rean.pvpcore.managers.ArenaManager;
import dev.rean.pvpcore.managers.KitManager;
import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.managers.Settings;
import dev.rean.pvpcore.managers.ToggleManager;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.TitleFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/duel/DuelManager.class */
public final class DuelManager {
    private final PvPCorePlugin plugin;
    private final Settings settings;
    private final MessageManager messages;
    private final ArenaManager arenas;
    private final ToggleManager toggles;
    private final Map<UUID, List<DuelRequest>> requests = new HashMap();
    private final Map<UUID, DuelMatch> matches = new HashMap();
    private final Map<String, Integer> playingByKit = new HashMap();

    public DuelManager(PvPCorePlugin plugin, Settings settings, MessageManager messages, ArenaManager arenas, KitManager kits, ToggleManager toggles) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.arenas = arenas;
        this.toggles = toggles;
    }

    public boolean isInMatch(UUID uniqueId) {
        return uniqueId != null && this.matches.containsKey(uniqueId);
    }

    public DuelMatch getMatch(UUID uniqueId) {
        if (uniqueId == null) {
            return null;
        }
        return this.matches.get(uniqueId);
    }

    public Collection<DuelMatch> activeMatches() {
        return new LinkedHashSet(this.matches.values());
    }

    public String matchId(DuelMatch match) {
        if (match == null) {
            return "";
        }
        String a = match.red().toString();
        String b = match.blue().toString();
        if (a.compareTo(b) > 0) {
            a = b;
            b = a;
        }
        return a + ":" + b + ":" + match.arena().id();
    }

    public boolean sharesVisibleMatch(UUID viewerId, UUID targetId) {
        DuelMatch targetMatch;
        if (viewerId == null || targetId == null || (targetMatch = getMatch(targetId)) == null) {
            return false;
        }
        DuelMatch viewerMatch = getMatch(viewerId);
        if (viewerMatch == targetMatch) {
            return true;
        }
        return matchId(targetMatch).equals(this.plugin.spectatorManager().spectatedMatchId(viewerId));
    }

    public void openDuelSetup(Player sender, Player target) {
        KitSelectGui.open(this.plugin, sender, target);
    }

    private String resolveArenaDisplayName(String arenaSelection) {
        if (arenaSelection == null || arenaSelection.isBlank() || arenaSelection.equalsIgnoreCase("random")) {
            return "Random";
        }
        Arena arena = this.arenas.get(arenaSelection);
        if (arena != null && arena.displayName() != null && !arena.displayName().isBlank()) {
            return arena.displayName();
        }
        return arenaSelection;
    }

    public void createAndSendRequest(Player sender, Player target, Kit kit, int firstTo, String arenaSelection) {
        if (this.plugin.playerData().isDoNotDisturb(sender.getUniqueId())) {
            this.messages.send(sender, "duels.target-disabled");
            return;
        }
        if (this.toggles.isDisabled(target.getUniqueId())) {
            this.messages.send(sender, "duels.target-disabled");
            return;
        }
        if (isInMatch(sender.getUniqueId()) || isInMatch(target.getUniqueId())) {
            this.messages.send(sender, "duels.already-in-match");
            return;
        }
        long expiresAt = System.currentTimeMillis() + (((long) this.settings.requestTimeoutSeconds()) * 1000);
        DuelRequest req = new DuelRequest(sender.getUniqueId(), target.getUniqueId(), kit, firstTo, expiresAt, arenaSelection);
        List<DuelRequest> list = this.requests.computeIfAbsent(target.getUniqueId(), k -> {
            return new ArrayList();
        });
        list.removeIf(r -> {
            return r.sender().equals(sender.getUniqueId());
        });
        list.add(req);
        String arenaId = (arenaSelection == null || arenaSelection.isBlank()) ? "random" : arenaSelection;
        String arenaName = resolveArenaDisplayName(arenaId);
        this.messages.send(sender, "duels.request-sent", Map.of("target", target.getName(), "kit", kit.displayName(), "rounds", String.valueOf(firstTo), "arena", arenaId, "arena_name", arenaName));
        this.messages.sendMiniMessage(target, "duels.request-received", Map.of("sender", sender.getName(), "expires", String.valueOf(this.settings.requestTimeoutSeconds()), "target", target.getName(), "kit", kit.displayName(), "rounds", String.valueOf(firstTo), "arena", arenaId, "arena_name", arenaName));
    }

    public DuelRequest findRequest(UUID target, UUID sender) {
        List<DuelRequest> list = this.requests.get(target);
        if (list == null) {
            return null;
        }
        list.removeIf((v0) -> {
            return v0.expired();
        });
        for (DuelRequest request : list) {
            if (request.sender().equals(sender)) {
                return request;
            }
        }
        return null;
    }

    public void accept(Player receiver, Player senderPlayer) {
        DuelRequest req = findRequest(receiver.getUniqueId(), senderPlayer.getUniqueId());
        if (req == null) {
            this.messages.send(receiver, "duels.request-not-found");
            return;
        }
        if (req.expired()) {
            this.messages.send(receiver, "duels.request-expired");
            return;
        }
        if (isInMatch(receiver.getUniqueId()) || isInMatch(senderPlayer.getUniqueId())) {
            this.messages.send(receiver, "duels.already-in-match");
            return;
        }
        Optional<Arena> optArena = this.arenas.findAvailableIgnoringBlacklist(req.arenaSelection());
        if (optArena.isEmpty()) {
            this.messages.send(receiver, "duels.no-arena");
            return;
        }
        this.plugin.queueManager().leaveAllQuiet(receiver.getUniqueId());
        this.plugin.queueManager().leaveAllQuiet(senderPlayer.getUniqueId());
        this.plugin.spectatorManager().leave(receiver, false);
        this.plugin.spectatorManager().leave(senderPlayer, false);
        Arena arena = optArena.get();
        arena.setInUse(true);
        List<Player> players = new ArrayList<>(List.of(senderPlayer, receiver));
        Collections.shuffle(players);
        Player red = players.get(0);
        Player blue = players.get(1);
        DuelMatch match = new DuelMatch(this.plugin, this.settings, this.messages, arena, req.kit(), red.getUniqueId(), blue.getUniqueId(), req.rounds());
        registerMatch(match);
        List<DuelRequest> receiverRequests = this.requests.get(receiver.getUniqueId());
        if (receiverRequests != null) {
            receiverRequests.remove(req);
            if (receiverRequests.isEmpty()) {
                this.requests.remove(receiver.getUniqueId());
            }
        }
        playQueuedMatchFoundEffects(receiver);
        playQueuedMatchFoundEffects(senderPlayer);
        match.scheduleStart(50L);
    }

    private void playQueuedMatchFoundEffects(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        player.closeInventory();
        player.playSound(player, Sound.ENTITY_ZOMBIE_ATTACK_IRON_DOOR, 1.0f, 1.0f);
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0, false, false, false));
        List<String> frames = this.messages.getStringList("titles.queue-found-animation.texts").stream().map(line -> {
            return this.messages.format(line, Map.of());
        }).toList();
        if (!frames.isEmpty()) {
            String subtitle = this.messages.get("titles.queue-found-animation.subtitle", Map.of());
            int interval = this.messages.getInt("titles.queue-found-animation.change-interval", 2);
            this.plugin.duelVisualEffects().playAnimatedTitle(player, frames, subtitle, interval);
        } else {
            player.sendTitle("", "", 0, 0, 0);
            TitleFormat.send(player, this.messages.get("titles.queue-found", Map.of()), this.messages);
        }
    }

    public boolean startQueuedMatch(Player first, Player second, Kit kit, int rounds) {
        if (first == null || second == null || kit == null || isInMatch(first.getUniqueId()) || isInMatch(second.getUniqueId())) {
            return false;
        }
        Optional<Arena> optArena = this.arenas.findAvailable("random", kit);
        if (optArena.isEmpty()) {
            this.messages.send(first, "duels.no-arena");
            this.messages.send(second, "duels.no-arena");
            return false;
        }
        Arena arena = optArena.get();
        arena.setInUse(true);
        List<Player> players = new ArrayList<>(List.of(first, second));
        Collections.shuffle(players);
        Player red = players.get(0);
        Player blue = players.get(1);
        this.plugin.spectatorManager().leave(first, false);
        this.plugin.spectatorManager().leave(second, false);
        DuelMatch match = new DuelMatch(this.plugin, this.settings, this.messages, arena, kit, red.getUniqueId(), blue.getUniqueId(), rounds);
        registerMatch(match);
        playQueuedMatchFoundEffects(first);
        playQueuedMatchFoundEffects(second);
        match.scheduleStart(50L);
        return true;
    }

    public int countPlaying(String kitId) {
        return this.playingByKit.getOrDefault(normalizeKit(kitId), 0).intValue();
    }

    public int countQueuedAndPlaying(String kitId) {
        return countPlaying(kitId) + this.plugin.queueManager().countInQueue(kitId);
    }

    public boolean recordTotemPop(UUID playerId) {
        DuelMatch match;
        if (playerId == null || (match = this.matches.get(playerId)) == null || !match.isFighting()) {
            return false;
        }
        match.recordTotemPop(playerId);
        this.plugin.playerData().incrementTotemPops(playerId);
        return true;
    }

    public boolean recordTotemPop(UUID ignoredBreakerId, UUID victimId) {
        return recordTotemPop(victimId);
    }

    public void handleDeath(Player dead) {
        DuelMatch match = this.matches.get(dead.getUniqueId());
        if (match == null) {
            return;
        }
        match.onDeath(dead);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            if (this.matches.containsValue(match) && !match.arena().inUse()) {
                unregisterMatch(match);
            }
        }, 120L);
    }

    public void removePlayer(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        this.plugin.spectatorManager().remove(uniqueId);
        this.plugin.queueManager().leaveAllQuiet(uniqueId);
        DuelMatch match = this.matches.get(uniqueId);
        if (match == null) {
            return;
        }
        match.handleResign(uniqueId);
        unregisterMatch(match);
    }

    public void clearPendingRequests() {
        this.requests.clear();
    }

    public void forceEndAllMatches() {
        new HashSet(this.matches.values()).forEach((v0) -> {
            v0.endForce();
        });
        this.plugin.tabScoreboardHook().shutdown();
        this.matches.clear();
        this.playingByKit.clear();
        clearPendingRequests();
    }

    public void finishMatch(DuelMatch match) {
        unregisterMatch(match);
    }

    private void registerMatch(DuelMatch match) {
        if (match == null) {
            return;
        }
        this.matches.put(match.red(), match);
        this.matches.put(match.blue(), match);
        adjustPlayingCount(match, 1);
        this.plugin.tabScoreboardHook().applyDuelTabNames(match);
    }

    private void unregisterMatch(DuelMatch match) {
        if (match == null) {
            return;
        }
        boolean removed = this.matches.remove(match.red(), match);
        this.matches.remove(match.blue(), match);
        if (removed) {
            adjustPlayingCount(match, -1);
        }
        this.plugin.tabScoreboardHook().resetDuelTabNames(match);
    }

    private void adjustPlayingCount(DuelMatch match, int delta) {
        if (match == null || match.kit() == null) {
            return;
        }
        String key = normalizeKit(match.kit().id());
        if (key.isBlank()) {
            return;
        }
        int next = this.playingByKit.getOrDefault(key, 0).intValue() + (delta * 2);
        if (next > 0) {
            this.playingByKit.put(key, Integer.valueOf(next));
        } else {
            this.playingByKit.remove(key);
        }
    }

    private String normalizeKit(String kitId) {
        return kitId == null ? "" : kitId.toLowerCase(Locale.ROOT);
    }
}
