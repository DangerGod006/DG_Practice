package dev.rean.pvpcore.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/ClickCooldown.class */
public final class ClickCooldown {
    private final long cooldownMs;
    private final Map<UUID, Long> lastUse = new HashMap();

    public ClickCooldown(long cooldownMs) {
        this.cooldownMs = Math.max(0L, cooldownMs);
    }

    public boolean test(UUID uuid) {
        if (uuid == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        Long previous = this.lastUse.get(uuid);
        if (previous != null && now - previous.longValue() < this.cooldownMs) {
            return false;
        }
        this.lastUse.put(uuid, Long.valueOf(now));
        cleanup(now);
        return true;
    }

    public void clear(UUID uuid) {
        if (uuid != null) {
            this.lastUse.remove(uuid);
        }
    }

    private void cleanup(long now) {
        if (this.lastUse.size() < 128) {
            return;
        }
        long maxAge = Math.max(this.cooldownMs * 5, 5000L);
        Iterator<Map.Entry<UUID, Long>> it = this.lastUse.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> entry = it.next();
            if (now - entry.getValue().longValue() > maxAge) {
                it.remove();
            }
        }
    }
}
