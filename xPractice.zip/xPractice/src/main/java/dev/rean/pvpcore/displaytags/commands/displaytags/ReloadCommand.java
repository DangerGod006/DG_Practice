package dev.rean.pvpcore.displaytags.commands.displaytags;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.commands.framework.CommandGroup;
import dev.rean.pvpcore.displaytags.commands.framework.Subcommand;
import dev.rean.pvpcore.displaytags.utils.helpers.MessageHelper;
import org.bukkit.command.CommandSender;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/displaytags/ReloadCommand.class */
public class ReloadCommand extends Subcommand {
    public ReloadCommand(DisplayTags plugin, CommandGroup parentCommand) {
        super(plugin, parentCommand);
        super.setName("reload");
        super.setDescription("Reload the plugin.");
        super.setPermission("displaytags.admin");
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.Subcommand
    public void execute(CommandSender sender, String[] args) {
        boolean success = this.plugin.reloadPlugin();
        if (success) {
            MessageHelper.success(sender, "Successfully reloaded!");
        } else {
            MessageHelper.error(sender, "Failed to reload the plugin, please check server logs!");
        }
    }
}
