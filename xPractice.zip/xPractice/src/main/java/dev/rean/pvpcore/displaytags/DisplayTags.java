package dev.rean.pvpcore.displaytags;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.displaytags.config.DisplayTagsConfig;
import dev.rean.pvpcore.displaytags.listeners.PlayerListener;
import dev.rean.pvpcore.displaytags.nametags.NametagManager;
import dev.rean.pvpcore.displaytags.nametags.NametagScheduler;
import dev.rean.pvpcore.displaytags.utils.handlers.NametagHandler;
import dev.rean.pvpcore.displaytags.utils.helpers.DependencyHelper;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.PluginManager;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/DisplayTags.class */
public final class DisplayTags {
    private static DisplayTags instance;
    private final PvPCorePlugin host;
    private FileConfiguration config;
    private File configFile;
    private DisplayTagsConfig displayTagsConfig;
    private NametagManager nametagManager;
    private NametagScheduler nametagScheduler;

    public DisplayTags(PvPCorePlugin host) {
        this.host = host;
    }

    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        this.displayTagsConfig = new DisplayTagsConfig(this);
        this.displayTagsConfig.load();
        this.nametagManager = new NametagManager();
        this.nametagScheduler = new NametagScheduler(this);
        PluginManager pluginManager = this.host.getServer().getPluginManager();
        pluginManager.registerEvents(new PlayerListener(), this.host);
        DependencyHelper.load();
        NametagHandler.load();
        if (config().getNametagConfig().isEnabled()) {
            this.nametagManager.createAll();
            this.nametagScheduler.start();
        }
        getLogger().info("Integrated DisplayTags module enabled.");
    }

    public void onDisable() {
        if (this.nametagScheduler != null) {
            this.nametagScheduler.stop();
        }
        if (this.nametagManager != null) {
            this.nametagManager.removeAll();
        }
    }

    public boolean reloadPlugin() {
        try {
            reloadConfig();
            this.displayTagsConfig.reload();
            if (this.nametagScheduler != null) {
                this.nametagScheduler.stop();
            }
            if (this.nametagManager != null) {
                this.nametagManager.removeAll();
            }
            if (config().getNametagConfig().isEnabled()) {
                this.nametagManager.createAll();
                this.nametagScheduler.start();
                return true;
            }
            return true;
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Failed to reload DisplayTags module: " + e.getMessage(), (Throwable) e);
            return false;
        }
    }

    public void saveDefaultConfig() {
        if (this.configFile == null) {
            this.configFile = new File(this.host.getDataFolder(), "displaytags.yml");
        }
        if (!this.configFile.exists()) {
            this.host.saveResource("displaytags.yml", false);
        }
        reloadConfig();
    }

    public void reloadConfig() {
        if (this.configFile == null) {
            this.configFile = new File(this.host.getDataFolder(), "displaytags.yml");
        }
        this.config = YamlConfiguration.loadConfiguration(this.configFile);
    }

    public void saveConfig() {
        if (this.config == null || this.configFile == null) {
            return;
        }
        try {
            this.config.save(this.configFile);
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not save displaytags.yml", (Throwable) e);
        }
    }

    public FileConfiguration getConfig() {
        if (this.config == null) {
            reloadConfig();
        }
        return this.config;
    }

    public PvPCorePlugin getHost() {
        return this.host;
    }

    public Logger getLogger() {
        return this.host.getLogger();
    }

    public File getDataFolder() {
        return this.host.getDataFolder();
    }

    public String getVersion() {
        return this.host.getPluginMeta().getVersion();
    }

    public static DisplayTags getInstance() {
        return instance;
    }

    public DisplayTagsConfig config() {
        return this.displayTagsConfig;
    }

    public NametagManager getNametagManager() {
        return this.nametagManager;
    }
}
