package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.util.U;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/PvPCoreCommand.class */
public final class PvPCoreCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public PvPCoreCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            this.plugin.messages().send(sender, "commands.pvpcore.usage");
            return true;
        }
        if (args[0].equalsIgnoreCase("settings")) {
            if (!(sender instanceof Player)) {
                this.plugin.messages().send(sender, "player-only");
                return true;
            }
            Player player = (Player) sender;
            this.plugin.playerData().openSettingsMenu(player);
            return true;
        }
        if (!sender.hasPermission("pvpcore.admin")) {
            this.plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            this.plugin.reloadAll();
            this.plugin.messages().send(sender, "reloaded");
            return true;
        }
        if (args[0].equalsIgnoreCase("setspawn")) {
            if (!(sender instanceof Player)) {
                this.plugin.messages().send(sender, "player-only");
                return true;
            }
            CommandSender commandSender = (Player) sender;
            U.writeLocation(this.plugin.getConfig(), "spawn", commandSender.getLocation());
            this.plugin.saveConfig();
            this.plugin.settings().reload();
            this.plugin.messages().send(commandSender, "spawn-set");
            return true;
        }
        this.plugin.messages().send(sender, "commands.pvpcore.usage");
        return true;
    }
}
