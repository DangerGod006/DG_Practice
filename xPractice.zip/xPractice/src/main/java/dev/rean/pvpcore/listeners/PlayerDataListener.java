package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/PlayerDataListener.class */
public final class PlayerDataListener implements Listener {
    private final PvPCorePlugin plugin;

    public PlayerDataListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.plugin.playerData().load(event.getPlayer());
        applyConfiguredJoinSpawnAndEffects(event.getPlayer());
        this.plugin.friendManager().notifyFriendJoin(event.getPlayer());
    }

    private void applyConfiguredJoinSpawnAndEffects(Player player) {
        Location spawn;
        if (player == null || !player.isOnline()) {
            return;
        }
        if (this.plugin.settings().teleportToSpawnOnJoin() && (spawn = this.plugin.settings().mainSpawn()) != null) {
            player.teleport(spawn);
        }
        applyConfiguredLobbySpeed(player);
    }

    private void applyConfiguredLobbySpeed(Player player) {
        if (player != null && player.isOnline() && this.plugin.settings().joinSpeedEnabled()) {
            int amplifier = Math.max(0, this.plugin.settings().joinSpeedLevel() - 1);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, -1, amplifier, false, false, false), true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.plugin.sneakStatus().clear(event.getPlayer().getUniqueId());
        this.plugin.playerData().unload(event.getPlayer());
    }
}
