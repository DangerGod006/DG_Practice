package dev.rean.pvpcore.displaytags.nametags;

import dev.rean.pvpcore.displaytags.utils.handlers.NametagHandler;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/nametags/NametagManager.class */
public class NametagManager {
    private final Map<UUID, Nametag> nametags = new ConcurrentHashMap();
    private final Map<UUID, Set<String>> forcedVisibleTags = new ConcurrentHashMap();
    private final Map<UUID, Set<String>> forcedHiddenTags = new ConcurrentHashMap();

    public Nametag get(Player player) {
        return this.nametags.get(player.getUniqueId());
    }

    public Collection<Nametag> getAll() {
        return this.nametags.values();
    }

    public void create(Player player) {
        Nametag nametag = new Nametag(player, this.forcedVisibleTags.get(player.getUniqueId()), this.forcedHiddenTags.get(player.getUniqueId()));
        nametag.updateVisibilityForAll();
        this.nametags.put(player.getUniqueId(), nametag);
    }

    public void remove(Player player) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            NametagHandler.show(player, viewer);
        }
        Nametag nametag = this.nametags.get(player.getUniqueId());
        if (nametag != null) {
            nametag.hideForAll();
            this.nametags.remove(player.getUniqueId());
        }
    }

    public Set<String> getForcedVisibleTags(Player player) {
        return this.forcedVisibleTags.get(player.getUniqueId());
    }

    public void setForcedVisibleTags(Player player, Set<String> tagIds) {
        if (tagIds == null || tagIds.isEmpty()) {
            clearForcedVisibleTags(player);
            return;
        }
        Set<String> normalized = (Set) tagIds.stream().map(id -> {
            return id.toLowerCase(Locale.ROOT);
        }).collect(Collectors.toCollection(LinkedHashSet::new));
        this.forcedVisibleTags.put(player.getUniqueId(), normalized);
        refresh(player);
    }

    public void clearForcedVisibleTags(Player player) {
        this.forcedVisibleTags.remove(player.getUniqueId());
        refresh(player);
    }

    public Set<String> getForcedHiddenTags(Player player) {
        return this.forcedHiddenTags.get(player.getUniqueId());
    }

    public void setForcedHiddenTags(Player player, Set<String> tagIds) {
        if (tagIds == null || tagIds.isEmpty()) {
            clearForcedHiddenTags(player);
            return;
        }
        Set<String> normalized = (Set) tagIds.stream().map(id -> {
            return id.toLowerCase(Locale.ROOT);
        }).collect(Collectors.toCollection(LinkedHashSet::new));
        this.forcedHiddenTags.put(player.getUniqueId(), normalized);
        refresh(player);
    }

    public void clearForcedHiddenTags(Player player) {
        this.forcedHiddenTags.remove(player.getUniqueId());
        refresh(player);
    }

    public void refresh(Player player) {
        remove(player);
        create(player);
    }

    public void createAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            create(player);
        }
    }

    public void removeAll() {
        for (Nametag nametag : this.nametags.values()) {
            remove(nametag.getPlayer());
        }
    }
}
