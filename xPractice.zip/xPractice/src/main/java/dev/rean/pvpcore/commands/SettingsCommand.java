package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/SettingsCommand.class */
public final class SettingsCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public SettingsCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        Player player = (Player) sender;
        this.plugin.playerData().openSettingsMenu(player);
        return true;
    }
}
