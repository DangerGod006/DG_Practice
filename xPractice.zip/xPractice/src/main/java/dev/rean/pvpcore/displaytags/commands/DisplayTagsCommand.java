package dev.rean.pvpcore.displaytags.commands;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.commands.displaytags.ConfigCommand;
import dev.rean.pvpcore.displaytags.commands.displaytags.HelpCommand;
import dev.rean.pvpcore.displaytags.commands.displaytags.ReloadCommand;
import dev.rean.pvpcore.displaytags.commands.displaytags.VisibilityCommand;
import dev.rean.pvpcore.displaytags.commands.framework.CommandGroup;
import dev.rean.pvpcore.displaytags.utils.helpers.MessageHelper;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/DisplayTagsCommand.class */
public class DisplayTagsCommand extends CommandGroup {
    private final DisplayTags plugin;

    public DisplayTagsCommand(DisplayTags plugin) {
        super("displaytags");
        this.plugin = plugin;
        createCommand(new HelpCommand(plugin, this));
        createCommand(new ReloadCommand(plugin, this));
        createCommand(new ConfigCommand(plugin, this));
        createCommand(new VisibilityCommand(plugin, this));
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.CommandGroup
    public boolean execute(@NotNull CommandSender sender, @NotNull String commandLabel, @NotNull String[] args) {
        if (args.length == 0) {
            MessageHelper.send(sender, "This server is running <#00BFFF>DisplayTags <gray>v" + this.plugin.getVersion() + "<white>!");
            MessageHelper.send(sender, "Run <gray>'/displaytags help' <white>for a full list of commands.");
            return true;
        }
        return super.execute(sender, commandLabel, args);
    }
}
