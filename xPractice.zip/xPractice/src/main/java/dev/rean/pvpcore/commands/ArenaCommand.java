package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.managers.ArenaManager;
import dev.rean.pvpcore.model.Arena;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/ArenaCommand.class */
public final class ArenaCommand implements CommandExecutor, TabCompleter {
    private final PvPCorePlugin plugin;
    private final ArenaManager arenas;

    public ArenaCommand(PvPCorePlugin plugin, ArenaManager arenas) {
        this.plugin = plugin;
        this.arenas = arenas;
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub;
        if (!sender.hasPermission("pvpcore.arena")) {
            this.plugin.messages().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }
        sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list":
                handleList(sender);
                break;
            case "status":
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.messages().format("&cUsage: /arena status <id>", Map.of()));
                    break;
                } else {
                    handleStatus(sender, args[1]);
                    break;
                }
                break;
            case "state":
                if (args.length < 3) {
                    sender.sendMessage(this.plugin.messages().format("&cUsage: /arena state <id> <free|used>", Map.of()));
                    break;
                } else {
                    String stateArg = args[2].toLowerCase(Locale.ROOT);
                    if (!stateArg.equals("free") && !stateArg.equals("used")) {
                        sender.sendMessage(this.plugin.messages().format("&cUsage: /arena state <id> <free|used>", Map.of()));
                    } else if (!this.arenas.setArenaState(args[1], stateArg.equals("used"))) {
                        this.plugin.messages().send(sender, "arenas.not-found");
                    } else {
                        sender.sendMessage(this.plugin.messages().format("&aArena &f" + args[1] + " &ais now in state &f" + stateArg, Map.of()));
                    }
                    break;
                }
                break;
            case "releaseall":
                this.arenas.releaseAll();
                sender.sendMessage(this.plugin.messages().format("&aAll arenas were released at runtime.", Map.of()));
                break;
            case "create":
                if (args.length < 3) {
                    sender.sendMessage(this.plugin.messages().format("&cUsage: /arena create <id> <display name...>", Map.of()));
                    break;
                } else {
                    String id = args[1];
                    String name = String.join(" ", (CharSequence[]) Arrays.copyOfRange(args, 2, args.length));
                    if (!this.arenas.create(id, name)) {
                        sender.sendMessage(this.plugin.messages().format("&cAn arena with that id already exists, or the id is invalid.", Map.of()));
                    } else {
                        this.arenas.save();
                        this.plugin.messages().send(sender, "arenas.created", Map.of("id", id.toLowerCase(Locale.ROOT), "name", name));
                        sender.sendMessage(this.plugin.messages().format("&7Next step: &f/arena tp " + id + " &8or &f/arena red " + id, Map.of()));
                    }
                    break;
                }
                break;
            case "delete":
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.messages().format("&cUsage: /arena delete <id>", Map.of()));
                    break;
                } else {
                    if (!this.arenas.delete(args[1])) {
                        this.plugin.messages().send(sender, "arenas.not-found");
                    } else {
                        this.plugin.messages().send(sender, "arenas.deleted", Map.of("id", args[1]));
                    }
                    break;
                }
                break;
            case "setspawn":
                Player p = requirePlayer(sender);
                if (p != null) {
                    if (args.length < 3) {
                        p.sendMessage(this.plugin.messages().format("&cUsage: /arena setspawn <id> <red|blue>", Map.of()));
                    } else if (!isSide(args[2])) {
                        p.sendMessage(this.plugin.messages().format("&cYou must use red or blue.", Map.of()));
                    } else {
                        this.arenas.setSpawn(p, args[1], args[2]);
                    }
                    break;
                }
                break;
            case "red":
            case "blue":
                Player p2 = requirePlayer(sender);
                if (p2 != null) {
                    if (args.length < 2) {
                        p2.sendMessage(this.plugin.messages().format("&cUsage: /arena " + sub + " <id>", Map.of()));
                    } else {
                        this.arenas.setSpawn(p2, args[1], sub);
                    }
                    break;
                }
                break;
            case "tp":
                Player p3 = requirePlayer(sender);
                if (p3 != null) {
                    if (args.length < 2) {
                        p3.sendMessage(this.plugin.messages().format("&cUsage: /arena tp <id> [red|blue|regen]", Map.of()));
                    } else {
                        handleTeleport(p3, args[1], args.length >= 3 ? args[2] : "");
                    }
                    break;
                }
                break;
            case "setwall":
            case "setfinalwall":
            case "wall":
            case "finalwall":
                Player p4 = requirePlayer(sender);
                if (p4 != null) {
                    String actionName = sub.equals("wall") ? "setwall" : sub.equals("finalwall") ? "setfinalwall" : sub;
                    if (args.length < 3) {
                        p4.sendMessage(this.plugin.messages().format("&cUsage: /arena " + actionName + " <red|blue> <id>", Map.of()));
                    } else {
                        ParsedArenaSide parsed = parseArenaAndSide(args[1], args[2]);
                        if (parsed == null) {
                            p4.sendMessage(this.plugin.messages().format("&cUsage: /arena " + actionName + " <red|blue> <id>", Map.of()));
                        } else if (actionName.equals("setfinalwall")) {
                            this.arenas.setFinalWallRegionFromSelection(p4, parsed.arenaId(), parsed.side());
                        } else {
                            this.arenas.setWallRegionFromSelection(p4, parsed.arenaId(), parsed.side());
                        }
                    }
                    break;
                }
                break;
            case "regen":
                Player p5 = requirePlayer(sender);
                if (p5 != null) {
                    if (args.length == 2) {
                        this.arenas.setRegenRegionFromSelection(p5, args[1]);
                    } else if (args.length == 3 && args[1].equalsIgnoreCase("set")) {
                        this.arenas.setRegenRegionFromSelection(p5, args[2]);
                    } else {
                        p5.sendMessage(this.plugin.messages().format("&cUsage: /arena regen <id> &7(o /arena regen set <id>)", Map.of()));
                        p5.sendMessage(this.plugin.messages().format("&7Use your current WorldEdit selection; the wand was removed.", Map.of()));
                    }
                    break;
                }
                break;
            case "subarena":
                handleSubarena(sender, args);
                break;
            case "seticon":
                Player p6 = requirePlayer(sender);
                if (p6 != null) {
                    if (args.length < 2) {
                        p6.sendMessage(this.plugin.messages().format("&cUsage: /arena seticon <category>", Map.of()));
                    } else {
                        ItemStack hand = p6.getInventory().getItemInMainHand();
                        if (hand == null || hand.getType().isAir()) {
                            p6.sendMessage(this.plugin.messages().format("&cYou must hold an item in your hand.", Map.of()));
                        } else if (!this.arenas.setCategoryIcon(args[1], hand)) {
                            p6.sendMessage(this.plugin.messages().format("&cThe icon could not be saved.", Map.of()));
                        } else {
                            p6.sendMessage(this.plugin.messages().format("&aIcon saved for category &f" + args[1], Map.of()));
                        }
                    }
                    break;
                }
                break;
            case "editor":
                CommandSender commandSenderRequirePlayer = requirePlayer(sender);
                if (commandSenderRequirePlayer != null) {
                    if (args.length < 2) {
                        commandSenderRequirePlayer.sendMessage(this.plugin.messages().format("&cUsage: /arena editor <id|stop>", Map.of()));
                    } else {
                        String target = args[1].toLowerCase(Locale.ROOT);
                        if (target.equals("stop") || target.equals("exit") || target.equals("off") || target.equals("leave")) {
                            this.plugin.arenaEditorManager().stop(commandSenderRequirePlayer, true);
                        } else if (this.arenas.get(target) == null) {
                            this.plugin.messages().send(commandSenderRequirePlayer, "arenas.not-found");
                        } else {
                            this.plugin.arenaEditorManager().start(commandSenderRequirePlayer, target);
                        }
                    }
                    break;
                }
                break;
            case "setup":
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.messages().format("&cUsage: /arena setup <id>", Map.of()));
                    break;
                } else {
                    handleSetup(sender, args[1]);
                    break;
                }
                break;
            default:
                sendUsage(sender);
                break;
        }
        return true;
    }

    private void handleList(CommandSender sender) {
        List<Arena> list = new ArrayList<>(this.arenas.all());
        this.plugin.messages().send(sender, "arenas.list-header", Map.of("count", String.valueOf(list.size())));
        for (Arena a : list) {
            this.plugin.messages().send(sender, "arenas.list-line", Map.of("id", a.id(), "name", a.displayName(), "ready", String.valueOf(a.ready()), "inuse", String.valueOf(a.inUse())));
        }
    }

    private void handleStatus(CommandSender sender, String arenaId) {
        Arena a = this.arenas.get(arenaId);
        if (a == null) {
            this.plugin.messages().send(sender, "arenas.not-found");
            return;
        }
        List<String> reasons = a.readyReasons();
        sender.sendMessage(this.plugin.messages().format("&8&m------------------------------", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eArena: &f" + a.id() + " &7(" + a.displayName() + ")", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eReady: &f" + a.ready(), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eIn use: &f" + a.inUse(), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eWorld: &f" + (a.worldName() == null ? "null" : a.worldName()), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eRed spawn: &f" + (a.redSpawn() == null ? "missing" : shortLoc(a.redSpawn())), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eBlue spawn: &f" + (a.blueSpawn() == null ? "missing" : shortLoc(a.blueSpawn())), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eRegen region: &f" + ((a.min() == null || a.max() == null) ? "missing" : shortLoc(a.min()) + " -> " + shortLoc(a.max())), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&eSchematic: &f" + (a.schematicFile() == null ? "null" : a.schematicFile().getName()) + " &7(" + (a.schematicFile() != null && a.schematicFile().exists()) + ")", Map.of()));
        if (reasons.isEmpty()) {
            sender.sendMessage(this.plugin.messages().format("&aReady reasons: OK", Map.of()));
        } else {
            sender.sendMessage(this.plugin.messages().format("&cMissing:", Map.of()));
            for (String reason : reasons) {
                sender.sendMessage(this.plugin.messages().format(" &8- &f" + reason, Map.of()));
            }
        }
        sender.sendMessage(this.plugin.messages().format("&8&m------------------------------", Map.of()));
    }

    private void handleSetup(CommandSender sender, String arenaId) {
        Arena arena = this.arenas.get(arenaId);
        if (arena == null) {
            this.plugin.messages().send(sender, "arenas.not-found");
            return;
        }
        sender.sendMessage(this.plugin.messages().format("&8&m------------------------------", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6Arena setup for &f" + arena.id() + " &7(" + arena.displayName() + ")", Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(1, arena.redSpawn() != null, "/arena red " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(2, arena.blueSpawn() != null, "/arena blue " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(3, (arena.min() == null || arena.max() == null) ? false : true, "/arena regen " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(4, (arena.wallMin("red") == null || arena.wallMax("red") == null) ? false : true, "/arena wall red " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(5, (arena.wallMin("blue") == null || arena.wallMax("blue") == null) ? false : true, "/arena wall blue " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(6, (arena.finalWallMin("red") == null || arena.finalWallMax("red") == null) ? false : true, "/arena finalwall red " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format(stepLine(7, (arena.finalWallMin("blue") == null || arena.finalWallMax("blue") == null) ? false : true, "/arena finalwall blue " + arena.id()), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&7Quick teleport: &f/arena tp " + arena.id() + " [red|blue|regen|min|max]", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&7Setup mode: &f/arena editor " + arena.id() + " &7(exit with &f/arena editor stop&7)", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&7Final state: " + (arena.ready() ? "&aREADY" : "&cINCOMPLETE"), Map.of()));
        sender.sendMessage(this.plugin.messages().format("&8&m------------------------------", Map.of()));
    }

    private String stepLine(int index, boolean done, String command) {
        return (done ? "&a✔ " : "&e✘ ") + "&7Step " + index + ": &f" + command;
    }

    private void handleTeleport(Player player, String arenaId, String target) {
        Location locationFirstAvailableTeleport;
        Arena arena = this.arenas.get(arenaId);
        if (arena == null) {
            this.plugin.messages().send(player, "arenas.not-found");
            return;
        }
        switch (target.toLowerCase(Locale.ROOT)) {
            case "red":
                locationFirstAvailableTeleport = arena.redSpawn();
                break;
            case "blue":
                locationFirstAvailableTeleport = arena.blueSpawn();
                break;
            case "regen":
            case "region":
            case "min":
                locationFirstAvailableTeleport = arena.min();
                break;
            case "max":
                locationFirstAvailableTeleport = arena.max();
                break;
            case "":
                locationFirstAvailableTeleport = firstAvailableTeleport(arena);
                break;
            default:
                locationFirstAvailableTeleport = null;
                break;
        }
        Location destination = locationFirstAvailableTeleport;
        if (destination == null || destination.getWorld() == null) {
            player.sendMessage(this.plugin.messages().format("&cThere is no valid location for that target in arena &f" + arena.id(), Map.of()));
        } else {
            player.teleport(destination.clone().add(0.5d, 0.0d, 0.5d));
            player.sendMessage(this.plugin.messages().format("&aTeleported to &f" + arena.id() + " &7(" + readableTarget(target, destination, arena) + "&7)", Map.of()));
        }
    }

    private String readableTarget(String target, Location destination, Arena arena) {
        String normalized = target == null ? "" : target.toLowerCase(Locale.ROOT);
        if (normalized.isBlank()) {
            return sameBlock(destination, arena.redSpawn()) ? "red" : sameBlock(destination, arena.blueSpawn()) ? "blue" : sameBlock(destination, arena.min()) ? "regen" : sameBlock(destination, arena.max()) ? "max" : "custom";
        }
        return normalized;
    }

    private boolean sameBlock(Location first, Location second) {
        return first != null && second != null && first.getWorld() != null && second.getWorld() != null && first.getWorld().getUID().equals(second.getWorld().getUID()) && first.getBlockX() == second.getBlockX() && first.getBlockY() == second.getBlockY() && first.getBlockZ() == second.getBlockZ();
    }

    private Location firstAvailableTeleport(Arena arena) {
        return arena.redSpawn() != null ? arena.redSpawn() : arena.blueSpawn() != null ? arena.blueSpawn() : arena.min() != null ? arena.min() : arena.max();
    }

    private String shortLoc(Location loc) {
        return loc.getWorld().getName() + ", " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }

    private void handleSubarena(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(this.plugin.messages().format("&cUsage: /arena subarena <category> <add|remove|list> [arenaId]", Map.of()));
            return;
        }
        String category = args[1];
        String action = args[2].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            Set<String> list = this.arenas.listSubarenas(category);
            sender.sendMessage(this.plugin.messages().format("&eSubarenas for &f" + category + "&e: &f" + (list.isEmpty() ? "(empty)" : String.join(", ", list)), Map.of()));
            return;
        }
        if (args.length < 4) {
            sender.sendMessage(this.plugin.messages().format("&cUsage: /arena subarena <category> <add|remove> <arenaId>", Map.of()));
            return;
        }
        String arenaId = args[3];
        if (action.equals("add")) {
            if (!this.arenas.addSubarena(category, arenaId)) {
                sender.sendMessage(this.plugin.messages().format("&cCould not add the subarena. Make sure the arena exists.", Map.of()));
                return;
            } else {
                sender.sendMessage(this.plugin.messages().format("&aSubarena added: &f" + arenaId + " &ato &f" + category, Map.of()));
                return;
            }
        }
        if (action.equals("remove")) {
            if (!this.arenas.removeSubarena(category, arenaId)) {
                sender.sendMessage(this.plugin.messages().format("&cCould not remove that subarena.", Map.of()));
                return;
            } else {
                sender.sendMessage(this.plugin.messages().format("&aSubarena removed: &f" + arenaId + " &afrom &f" + category, Map.of()));
                return;
            }
        }
        sender.sendMessage(this.plugin.messages().format("&cUsage: /arena subarena <category> <add|remove|list> [arenaId]", Map.of()));
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(this.plugin.messages().format("&6/arena create <id> <display>", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena red <id> &7- save the red spawn at your current position", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena blue <id> &7- save the blue spawn at your current position", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena regen <id> &7- save the regen region from WorldEdit", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena wall <red|blue> <id> &7- save the wall region from WorldEdit", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena finalwall <red|blue> <id> &7- save the final wall region from WorldEdit", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena tp <id> [red|blue|regen|min|max]", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena editor <id> &7- enter step-by-step setup mode", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena setup <id> &7- quick setup guide", Map.of()));
        sender.sendMessage(this.plugin.messages().format("&6/arena status|state|releaseall|delete|subarena|seticon|list", Map.of()));
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player) {
            Player p = (Player) sender;
            return p;
        }
        this.plugin.messages().send(sender, "player-only");
        return null;
    }

    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!sender.hasPermission("pvpcore.arena")) {
            return List.of();
        }
        String sub = args.length >= 1 ? args[0].toLowerCase(Locale.ROOT) : "";
        if (args.length == 1) {
            return partial(args[0], List.of((Object[]) new String[]{"create", "setspawn", "red", "blue", "tp", "editor", "setwall", "wall", "setfinalwall", "finalwall", "delete", "regen", "list", "status", "setup", "state", "releaseall", "subarena", "seticon"}));
        }
        if (args.length == 2) {
            switch (sub) {
                case "delete":
                case "setspawn":
                case "status":
                case "state":
                case "setup":
                case "tp":
                case "red":
                case "blue":
                    return partial(args[1], arenaIds());
                case "regen":
                    return partial(args[1], merge(arenaIds(), List.of("set")));
                case "editor":
                    return partial(args[1], merge(arenaIds(), List.of("stop", "exit", "off", "leave")));
                case "setwall":
                case "setfinalwall":
                case "wall":
                case "finalwall":
                    return partial(args[1], merge(arenaIds(), List.of("red", "blue")));
                case "seticon":
                case "subarena":
                    return partial(args[1], merge(new ArrayList(this.arenas.categoryIds()), List.of("plains")));
                default:
                    return List.of();
            }
        }
        if (args.length == 3) {
            switch (sub) {
                case "state":
                    return partial(args[2], List.of("free", "used"));
                case "setspawn":
                    return partial(args[2], List.of("red", "blue"));
                case "tp":
                    return partial(args[2], List.of("red", "blue", "regen", "min", "max"));
                case "setwall":
                case "setfinalwall":
                case "wall":
                case "finalwall":
                    return isSide(args[1]) ? partial(args[2], arenaIds()) : partial(args[2], List.of("red", "blue"));
                case "regen":
                    return args[1].equalsIgnoreCase("set") ? partial(args[2], arenaIds()) : List.of();
                case "subarena":
                    return partial(args[2], List.of("add", "remove", "list"));
                default:
                    return List.of();
            }
        }
        if (args.length == 4 && sub.equals("subarena") && !args[2].equalsIgnoreCase("list")) {
            return partial(args[3], arenaIds());
        }
        return List.of();
    }

    private List<String> merge(List<String> base, List<String> extra) {
        List<String> merged = new ArrayList<>(base);
        merged.addAll(extra);
        return merged;
    }

    private ParsedArenaSide parseArenaAndSide(String first, String second) {
        boolean firstIsSide = isSide(first);
        boolean secondIsSide = isSide(second);
        if (firstIsSide && !secondIsSide) {
            return new ParsedArenaSide(second, first.toLowerCase(Locale.ROOT));
        }
        if (!firstIsSide && secondIsSide) {
            return new ParsedArenaSide(first, second.toLowerCase(Locale.ROOT));
        }
        return null;
    }

    private boolean isSide(String value) {
        return value.equalsIgnoreCase("red") || value.equalsIgnoreCase("blue");
    }

    private List<String> arenaIds() {
        return (List) this.arenas.all().stream().map((v0) -> {
            return v0.id();
        }).sorted().collect(Collectors.toList());
    }

    private List<String> partial(String token, Collection<String> candidates) {
        String lower = token.toLowerCase(Locale.ROOT);
        return candidates.stream().filter((v0) -> {
            return Objects.nonNull(v0);
        }).filter(s -> {
            return s.toLowerCase(Locale.ROOT).startsWith(lower);
        }).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide.class */
    private static final class ParsedArenaSide extends Record {
        private final String arenaId;
        private final String side;

        private ParsedArenaSide(String arenaId, String side) {
            this.arenaId = arenaId;
            this.side = side;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, ParsedArenaSide.class), ParsedArenaSide.class, "arenaId;side", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->arenaId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->side:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, ParsedArenaSide.class), ParsedArenaSide.class, "arenaId;side", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->arenaId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->side:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, ParsedArenaSide.class, Object.class), ParsedArenaSide.class, "arenaId;side", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->arenaId:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/commands/ArenaCommand$ParsedArenaSide;->side:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String arenaId() {
            return this.arenaId;
        }

        public String side() {
            return this.side;
        }
    }
}
