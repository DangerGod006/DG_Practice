package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleSneakEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/SneakStatusListener.class */
public final class SneakStatusListener implements Listener {
    private final PvPCorePlugin plugin;

    public SneakStatusListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onToggleSneak(PlayerToggleSneakEvent event) {
        if (event.isSneaking()) {
            this.plugin.sneakStatus().toggle(event.getPlayer());
        }
    }
}
