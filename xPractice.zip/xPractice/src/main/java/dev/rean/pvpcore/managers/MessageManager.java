package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.Placeholders;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/MessageManager.class */
public final class MessageManager {
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_AMPERSAND = LegacyComponentSerializer.legacyAmpersand();
    private final PvPCorePlugin plugin;
    private final Settings settings;
    private File file;
    private FileConfiguration cfg;
    private FileConfiguration defaultsCfg;

    public MessageManager(PvPCorePlugin plugin, Settings settings) {
        this.plugin = plugin;
        this.settings = settings;
        reload();
    }

    public void reload() {
        this.file = new File(this.plugin.getDataFolder(), "messages.yml");
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.defaultsCfg = new YamlConfiguration();
        try {
            InputStream input = this.plugin.getResource("messages.yml");
            if (input != null) {
                try {
                    this.defaultsCfg.load(new InputStreamReader(input, StandardCharsets.UTF_8));
                } finally {
                }
            }
            if (input != null) {
                input.close();
            }
        } catch (Exception e) {
        }
    }

    public void send(CommandSender sender, String path) {
        send(sender, path, Map.of());
    }

    public void send(CommandSender sender, String path, Map<String, String> local) {
        if (isList(path)) {
            for (String line : getStringList(path)) {
                sender.sendMessage(format(line, local));
            }
            return;
        }
        sender.sendMessage(format(rawString(path, "&cMissing message: " + path), local));
    }

    public void sendMiniMessage(CommandSender sender, String path, Map<String, String> local) {
        if (isList(path)) {
            for (String line : getStringList(path)) {
                sender.sendMessage(deserializeMiniMessage(line, local));
            }
            return;
        }
        sender.sendMessage(deserializeMiniMessage(rawString(path, "<red>Missing message: " + path), local));
    }

    public String get(String path, Map<String, String> local) {
        return format(rawString(path, ""), local);
    }

    public boolean isList(String path) {
        return this.cfg.isList(path) || this.defaultsCfg.isList(path);
    }

    public List<String> getStringList(String path) {
        return this.cfg.isList(path) ? this.cfg.getStringList(path) : this.defaultsCfg.getStringList(path);
    }

    public Component deserializeMiniMessage(String input, Map<String, String> local) {
        String s = input == null ? "" : input;
        String s2 = s.replace("%prefix%", legacyToMini(this.settings.prefixRaw())).replace("%reset%", legacyToMini(this.settings.resetRaw()));
        for (Map.Entry<String, String> entry : local.entrySet()) {
            String value = entry.getValue() == null ? "" : legacyToMini(entry.getValue());
            s2 = s2.replace("%" + entry.getKey() + "%", value);
        }
        return MINI_MESSAGE.deserialize(s2);
    }

    private String legacyToMini(String value) {
        String legacy = value == null ? "" : value.replace((char) 167, '&');
        return (String) MINI_MESSAGE.serialize(LEGACY_AMPERSAND.deserialize(legacy));
    }

    public String rawString(String path, String def) {
        return this.cfg.isString(path) ? this.cfg.getString(path, def) : this.defaultsCfg.getString(path, def);
    }

    public List<String> rawStringList(String path) {
        return this.cfg.isList(path) ? this.cfg.getStringList(path) : this.defaultsCfg.getStringList(path);
    }

    public int getInt(String path, int def) {
        return this.cfg.isInt(path) ? this.cfg.getInt(path, def) : this.defaultsCfg.getInt(path, def);
    }

    public String format(String input, Map<String, String> local) {
        String s = input == null ? "" : input;
        return HexColor.color(Placeholders.apply(s.replace("%prefix%", this.settings.prefixRaw()).replace("%reset%", this.settings.resetRaw()), local));
    }

    public void sendToBoth(DuelMatch match, String path, Map<String, String> local) {
        Player r = Bukkit.getPlayer(match.red());
        Player b = Bukkit.getPlayer(match.blue());
        if (r != null) {
            send(r, path, local);
        }
        if (b != null) {
            send(b, path, local);
        }
    }
}
