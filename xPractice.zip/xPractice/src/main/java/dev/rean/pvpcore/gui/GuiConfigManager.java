package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.ItemBuilder;
import java.io.File;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiConfigManager.class */
public final class GuiConfigManager {
    private final PvPCorePlugin plugin;
    private final File file;
    private YamlConfiguration cfg;

    public GuiConfigManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "inventories.yml");
        reload();
    }

    public void reload() {
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
    }

    public YamlConfiguration config() {
        return this.cfg;
    }

    public ConfigurationSection gui(String path) {
        return this.cfg.getConfigurationSection(path);
    }

    public Inventory createInventory(String path, GuiSession session, Map<String, String> placeholders) {
        ConfigurationSection root = gui(path);
        if (root == null) {
            return null;
        }
        String title = GenericGui.formatGuiText(this.plugin, null, root.getString("title", path), placeholders);
        int size = GenericGui.normalizeInventorySize(root.getInt("size", 27));
        return Bukkit.createInventory(new ReanMenuHolder(session), size, HexColor.color(title));
    }

    public void fillFiller(Inventory inv, ConfigurationSection root) {
        ConfigurationSection filler;
        if (root == null || (filler = root.getConfigurationSection("filler")) == null) {
            return;
        }
        Material material = material(filler.getString("material"), Material.BLACK_STAINED_GLASS_PANE);
        ItemStack item = new ItemBuilder(material).name(filler.getString("name", " ")).build();
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, item.clone());
        }
    }

    public void applyConfiguredItem(Inventory inv, ConfigurationSection itemSection, Map<String, String> placeholders, OfflinePlayer skullOwner, ItemStack providedItem) {
        int slot;
        if (itemSection != null && (slot = itemSection.getInt("slot", -1)) >= 0 && slot < inv.getSize()) {
            ItemStack item = providedItem != null ? providedItem.clone() : new ItemStack(material(itemSection.getString("material"), Material.STONE));
            if (skullOwner != null) {
                item = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta meta = Bukkit.getItemFactory().getItemMeta(Material.PLAYER_HEAD);
                if (meta != null) {
                    meta.setOwningPlayer(skullOwner);
                    applyMeta(meta, itemSection, placeholders);
                    item.setItemMeta(meta);
                }
            } else {
                ItemMeta meta2 = item.getItemMeta();
                if (meta2 != null) {
                    applyMeta(meta2, itemSection, placeholders);
                    item.setItemMeta(meta2);
                }
            }
            int amount = Math.max(1, Math.min(64, itemSection.getInt("amount", item.getAmount())));
            item.setAmount(amount);
            inv.setItem(slot, item);
        }
    }

    private void applyMeta(ItemMeta meta, ConfigurationSection sec, Map<String, String> placeholders) {
        String displayName = sec.getString("name");
        if (displayName != null) {
            meta.setDisplayName(HexColor.color(GenericGui.formatGuiText(this.plugin, null, displayName, placeholders)));
        }
        List<String> lore = sec.getStringList("lore");
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(lore.stream().map(line -> {
                return HexColor.color(GenericGui.formatGuiText(this.plugin, null, line, placeholders));
            }).toList());
        }
    }

    public Material material(String name, Material fallback) {
        if (name == null || name.isBlank()) {
            return fallback;
        }
        Material material = Material.matchMaterial(name);
        return material == null ? fallback : material;
    }
}
