package dev.rean.pvpcore.displaytags.commands.framework;

import dev.rean.pvpcore.displaytags.DisplayTags;
import java.util.List;
import org.bukkit.command.CommandSender;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/framework/Subcommand.class */
public abstract class Subcommand {
    public DisplayTags plugin;
    private final CommandGroup parentCommand;
    private String name;
    private String description;
    private String permission;

    public abstract void execute(CommandSender commandSender, String[] strArr);

    public Subcommand(DisplayTags plugin, CommandGroup parentCommand) {
        this.plugin = plugin;
        this.parentCommand = parentCommand;
    }

    public CommandGroup getParentCommand() {
        return this.parentCommand;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPermission() {
        return this.permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public List<String> tabComplete(CommandSender sender, String[] args) {
        return List.of();
    }
}
