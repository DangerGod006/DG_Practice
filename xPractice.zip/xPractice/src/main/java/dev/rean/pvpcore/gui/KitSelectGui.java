package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.ItemBuilder;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/KitSelectGui.class */
public final class KitSelectGui {
    public static void open(PvPCorePlugin plugin, Player sender, Player target) {
        Kit defaultKit = plugin.kitManager().getFirstOrNull();
        if (defaultKit == null) {
            plugin.messages().send(sender, "gui.no-kits");
        } else {
            GuiSession session = new GuiSession(GuiKey.KIT_SELECT, sender, target, defaultKit);
            open(plugin, sender, target, session);
        }
    }

    public static void open(PvPCorePlugin plugin, Player sender, Player target, GuiSession session) {
        YamlConfiguration cfg = GenericGui.loadInventories(plugin);
        if (GenericGui.resolveGuiRoot(cfg, "kit-select-gui") != null && cfg.getConfigurationSection("guis") != null) {
            session.clearHistory();
            session.setCurrentGuiId(null);
            GenericGui.open(plugin, sender, target, session, "kit-select-gui");
            return;
        }
        ConfigurationSection root = cfg.getConfigurationSection("kit-select-gui");
        if (root == null) {
            plugin.messages().send(sender, "gui.missing-kit-select");
            return;
        }
        String titleRaw = root.getString("title", "Select Kit");
        String title = GenericGui.formatGuiText(plugin, sender, titleRaw, Map.of("target", target.getName(), "target_name", target.getName(), "player", sender.getName(), "player_name", sender.getName(), "owner_uuid", sender.getUniqueId().toString()));
        int size = GenericGui.normalizeInventorySize(root.getInt("size", 27));
        session.setKey(GuiKey.KIT_SELECT);
        Inventory inv = Bukkit.createInventory(new ReanMenuHolder(session), size, HexColor.color(title));
        render(plugin, inv, session, root);
        sender.openInventory(inv);
    }

    public static void render(PvPCorePlugin plugin, Inventory inv, GuiSession session, ConfigurationSection root) {
        inv.clear();
        ConfigurationSection filler = root.getConfigurationSection("filler");
        if (filler != null) {
            Material mat = Material.matchMaterial(filler.getString("material", "BLACK_STAINED_GLASS_PANE"));
            if (mat == null) {
                mat = Material.BLACK_STAINED_GLASS_PANE;
            }
            ItemStack fill = new ItemBuilder(mat).name(filler.getString("name", " ")).build();
            for (int i = 0; i < inv.getSize(); i++) {
                inv.setItem(i, fill);
            }
        }
        List<Integer> slots = root.getIntegerList("kit-slots");
        if (slots == null || slots.isEmpty()) {
            slots = List.of(10, 11, 12, 13, 14, 15, 16);
        }
        ConfigurationSection template = root.getConfigurationSection("kit-item");
        List<Kit> kits = plugin.kitManager().list();
        for (int i2 = 0; i2 < kits.size() && i2 < slots.size(); i2++) {
            Kit k = kits.get(i2);
            int slot = slots.get(i2).intValue();
            inv.setItem(slot, buildKitItem(plugin, root, template, k, session));
        }
    }

    private static ItemStack buildKitItem(PvPCorePlugin plugin, ConfigurationSection root, ConfigurationSection template, Kit kit, GuiSession session) {
        Material materialMatchMaterial;
        String string;
        String kitName = kit.displayName();
        Player owner = Bukkit.getPlayer(session.owner());
        Map<String, String> ph = Map.of("kit", kitName, "kit_name", kitName, "kit_id", kit.id(), "player", owner != null ? owner.getName() : "", "player_name", owner != null ? owner.getName() : "", "owner_uuid", session.owner().toString());
        ItemStack baseIcon = kit.icon();
        if (baseIcon == null || baseIcon.getType().isAir()) {
            if (template != null) {
                materialMatchMaterial = Material.matchMaterial(template.getString("material", "END_CRYSTAL"));
            } else {
                materialMatchMaterial = null;
            }
            Material fallback = materialMatchMaterial;
            if (fallback == null) {
                fallback = Material.END_CRYSTAL;
            }
            baseIcon = new ItemStack(fallback);
        }
        ItemStack icon = baseIcon.clone();
        ItemMeta meta = icon.getItemMeta();
        if (meta == null) {
            return icon;
        }
        if (template != null) {
            string = template.getString("name", root.getString("kit-name", "&f%kit%&r"));
        } else {
            string = root.getString("kit-name", "&f%kit%&r");
        }
        String name = string;
        meta.setDisplayName(HexColor.color(GenericGui.formatGuiText(plugin, owner, name, ph)));
        List<String> lore = template != null ? template.getStringList("lore") : List.of();
        if (lore == null || lore.isEmpty()) {
            lore = root.getStringList("kit-lore");
        }
        if (lore != null && !lore.isEmpty()) {
            meta.setLore(lore.stream().map(line -> {
                return HexColor.color(GenericGui.formatGuiText(plugin, owner, line, ph));
            }).toList());
        }
        icon.setItemMeta(meta);
        return icon;
    }
}
