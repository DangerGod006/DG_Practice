package dev.rean.pvpcore.duel;

import dev.rean.pvpcore.model.Kit;
import java.util.UUID;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/duel/DuelRequest.class */
public final class DuelRequest {
    private final UUID sender;
    private final UUID target;
    private final Kit kit;
    private final int rounds;
    private final long expiresAt;
    private final String arenaSelection;

    public DuelRequest(UUID sender, UUID target, Kit kit, int rounds, long expiresAt, String arenaSelection) {
        this.sender = sender;
        this.target = target;
        this.kit = kit;
        this.rounds = rounds;
        this.expiresAt = expiresAt;
        this.arenaSelection = (arenaSelection == null || arenaSelection.isBlank()) ? "random" : arenaSelection.toLowerCase();
    }

    public UUID sender() {
        return this.sender;
    }

    public UUID target() {
        return this.target;
    }

    public Kit kit() {
        return this.kit;
    }

    public int rounds() {
        return this.rounds;
    }

    public long expiresAt() {
        return this.expiresAt;
    }

    public String arenaSelection() {
        return this.arenaSelection;
    }

    public boolean expired() {
        return System.currentTimeMillis() > this.expiresAt;
    }

    public int winNeeded() {
        return (this.rounds / 2) + 1;
    }
}
