package dev.rean.pvpcore.kits;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.model.Kit;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/kits/KitEditorListener.class */
public final class KitEditorListener implements Listener {
    private final PvPCorePlugin plugin;
    private final Map<UUID, Integer> pendingSlot = new HashMap();
    private final Map<UUID, ItemStack> pendingItem = new HashMap();

    public KitEditorListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof KitEditorHolder) {
            KitEditorHolder holder2 = (KitEditorHolder) holder;
            HumanEntity whoClicked = event.getWhoClicked();
            if (whoClicked instanceof Player) {
                Player player = (Player) whoClicked;
                Inventory top = event.getView().getTopInventory();
                int raw = event.getRawSlot();
                int topSize = top.getSize();
                InventoryAction action = event.getAction();
                if (event.isShiftClick() || action == InventoryAction.DROP_ONE_SLOT || action == InventoryAction.DROP_ALL_SLOT) {
                    event.setCancelled(true);
                    return;
                }
                if (raw < 0 || raw >= topSize) {
                    event.setCancelled(true);
                    return;
                }
                if (raw == 8) {
                    event.setCancelled(true);
                    ItemStack cursor = player.getItemOnCursor();
                    if (cursor != null && !cursor.getType().isAir()) {
                        UUID uid = player.getUniqueId();
                        Integer pending = this.pendingSlot.get(uid);
                        if (pending != null) {
                            top.setItem(pending.intValue(), cursor.clone());
                            player.setItemOnCursor((ItemStack) null);
                            this.pendingSlot.remove(uid);
                            this.pendingItem.remove(uid);
                        } else {
                            player.setItemOnCursor((ItemStack) null);
                            player.getInventory().addItem(new ItemStack[]{cursor}).values().forEach(leftover -> {
                                player.getWorld().dropItem(player.getLocation(), leftover);
                            });
                        }
                    }
                    restorePending(player, top);
                    saveKit(holder2, top, player);
                    this.plugin.kitEditorManager().openEditSelector(player);
                    playClick(player, top.getItem(raw), null);
                    return;
                }
                if (isBlockedSlot(raw)) {
                    event.setCancelled(true);
                    return;
                }
                if (raw == 6) {
                    handleOffhand(event, top, player);
                } else if (!isEditableSlot(raw) || !isAllowedAction(action)) {
                    event.setCancelled(true);
                } else {
                    trackPickup(event, player, top, raw, action);
                    playClick(player, event.getCurrentItem(), event.getCursor());
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof KitEditorHolder) {
            int topSize = event.getView().getTopInventory().getSize();
            Iterator it = event.getRawSlots().iterator();
            while (it.hasNext()) {
                int raw = ((Integer) it.next()).intValue();
                if (raw >= topSize || isBlockedSlot(raw)) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof KitEditorHolder) {
            KitEditorHolder holder2 = (KitEditorHolder) holder;
            HumanEntity player = event.getPlayer();
            if (player instanceof Player) {
                Player player2 = (Player) player;
                restorePending(player2, event.getInventory());
                saveKit(holder2, event.getInventory(), player2);
            }
        }
    }

    private void trackPickup(InventoryClickEvent event, Player player, Inventory top, int raw, InventoryAction action) {
        boolean z;
        boolean z2;
        UUID uid = player.getUniqueId();
        switch (AnonymousClass1.$SwitchMap$org$bukkit$event$inventory$InventoryAction[action.ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
            case KitEditorManager.HELMET_SLOT /* 2 */:
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
            case KitEditorManager.LEGGINGS_SLOT /* 4 */:
                z = true;
                break;
            default:
                z = false;
                break;
        }
        boolean isPickup = z;
        switch (AnonymousClass1.$SwitchMap$org$bukkit$event$inventory$InventoryAction[action.ordinal()]) {
            case KitEditorManager.BOOTS_SLOT /* 5 */:
            case KitEditorManager.OFFHAND_SLOT /* 6 */:
            case KitEditorManager.SLOT_TOP_FILLER_RIGHT /* 7 */:
            case KitEditorManager.BACK_SLOT /* 8 */:
            case KitEditorManager.INVENTORY_START /* 9 */:
            case 10:
                z2 = true;
                break;
            default:
                z2 = false;
                break;
        }
        boolean clears = z2;
        if (!isPickup) {
            if (clears) {
                this.pendingSlot.remove(uid);
                this.pendingItem.remove(uid);
                return;
            }
            return;
        }
        ItemStack picked = top.getItem(raw);
        if (picked != null && !picked.getType().isAir()) {
            this.pendingSlot.put(uid, Integer.valueOf(raw));
            this.pendingItem.put(uid, picked.clone());
        }
    }

    /* JADX INFO: renamed from: dev.rean.pvpcore.kits.KitEditorListener$1, reason: invalid class name */
    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/kits/KitEditorListener$1.class */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$org$bukkit$event$inventory$InventoryAction = new int[InventoryAction.values().length];

        static {
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PICKUP_ALL.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PICKUP_HALF.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PICKUP_ONE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PICKUP_SOME.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PLACE_ALL.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PLACE_ONE.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.PLACE_SOME.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.SWAP_WITH_CURSOR.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.DROP_ONE_SLOT.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.DROP_ALL_SLOT.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$org$bukkit$event$inventory$InventoryAction[InventoryAction.COLLECT_TO_CURSOR.ordinal()] = 11;
            } catch (NoSuchFieldError e11) {
            }
        }
    }

    private void restorePending(Player player, Inventory top) {
        ItemStack cursor;
        UUID uid = player.getUniqueId();
        Integer slot = this.pendingSlot.remove(uid);
        ItemStack item = this.pendingItem.remove(uid);
        if (slot != null && item != null && (cursor = player.getItemOnCursor()) != null && !cursor.getType().isAir() && cursor.isSimilar(item)) {
            top.setItem(slot.intValue(), cursor.clone());
            player.setItemOnCursor((ItemStack) null);
        }
    }

    private void handleOffhand(InventoryClickEvent event, Inventory top, Player player) {
        event.setCancelled(true);
        ItemStack cursor = event.getCursor();
        ItemStack current = top.getItem(6);
        boolean slotHasRealItem = (current == null || current.getType().isAir() || this.plugin.kitEditorManager().isOffhandPlaceholder(current)) ? false : true;
        if (cursor != null && !cursor.getType().isAir()) {
            top.setItem(6, cursor.clone());
            event.setCursor(slotHasRealItem ? current.clone() : null);
            playClick(player, cursor, current);
        } else if (slotHasRealItem) {
            this.pendingSlot.put(player.getUniqueId(), 6);
            this.pendingItem.put(player.getUniqueId(), current.clone());
            event.setCursor(current.clone());
            top.setItem(6, this.plugin.kitEditorManager().createDisplayedOffhand(null));
            playClick(player, current, null);
        }
    }

    private void saveKit(KitEditorHolder holder, Inventory inv, Player player) {
        ItemStack[] contents = new ItemStack[36];
        for (int s = 9; s <= 35; s++) {
            ItemStack it = inv.getItem(s);
            contents[s] = it != null ? it.clone() : null;
        }
        for (int s2 = 45; s2 <= 53; s2++) {
            ItemStack it2 = inv.getItem(s2);
            contents[s2 - 45] = it2 != null ? it2.clone() : null;
        }
        ItemStack offhand = inv.getItem(6);
        if (this.plugin.kitEditorManager().isOffhandPlaceholder(offhand)) {
            offhand = null;
        } else if (offhand != null) {
            offhand = offhand.clone();
        }
        this.plugin.kitManager().saveEditedInventory(holder.playerId(), holder.kitId(), contents, offhand);
        Kit kit = this.plugin.kitManager().get(holder.kitId());
        String name = kit != null ? kit.displayName() : holder.kitId();
        player.sendActionBar(this.plugin.messages().get("kit-editor.saved-actionbar", Map.of("kit", name, "kit_id", holder.kitId())));
    }

    private boolean isBlockedSlot(int raw) {
        return raw == 0 || raw == 1 || raw == 7 || raw == 2 || raw == 3 || raw == 4 || raw == 5 || (raw > 35 && raw < 45);
    }

    private boolean isEditableSlot(int raw) {
        return (raw >= 9 && raw <= 35) || (raw >= 45 && raw <= 53);
    }

    private boolean isAllowedAction(InventoryAction action) {
        switch (AnonymousClass1.$SwitchMap$org$bukkit$event$inventory$InventoryAction[action.ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
            case KitEditorManager.HELMET_SLOT /* 2 */:
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
            case KitEditorManager.LEGGINGS_SLOT /* 4 */:
            case KitEditorManager.BOOTS_SLOT /* 5 */:
            case KitEditorManager.OFFHAND_SLOT /* 6 */:
            case KitEditorManager.SLOT_TOP_FILLER_RIGHT /* 7 */:
            case KitEditorManager.BACK_SLOT /* 8 */:
            case 11:
                return true;
            case KitEditorManager.INVENTORY_START /* 9 */:
            case 10:
            default:
                return false;
        }
    }

    private void playClick(Player player, ItemStack primary, ItemStack secondary) {
        if (shouldPlayValidClickSound(primary) || shouldPlayValidClickSound(secondary)) {
            player.playSound(player.getLocation(), Sound.BLOCK_WOODEN_BUTTON_CLICK_ON, 0.8f, 1.0f);
        }
    }

    private boolean shouldPlayValidClickSound(ItemStack item) {
        return (item == null || item.getType().isAir() || item.getType().name().endsWith("_STAINED_GLASS_PANE")) ? false : true;
    }
}
