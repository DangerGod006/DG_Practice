package dev.rean.pvpcore.gui;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiSelectMode.class */
public enum GuiSelectMode {
    DUEL,
    QUEUE,
    KIT_EDITOR
}
