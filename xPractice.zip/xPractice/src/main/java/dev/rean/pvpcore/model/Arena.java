package dev.rean.pvpcore.model;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/model/Arena.class */
public final class Arena {
    private final String id;
    private String displayName;
    private String worldName;
    private Location redSpawn;
    private Location blueSpawn;
    private Location min;
    private Location max;
    private Location redWallMin;
    private Location redWallMax;
    private Location blueWallMin;
    private Location blueWallMax;
    private Location redFinalWallMin;
    private Location redFinalWallMax;
    private Location blueFinalWallMin;
    private Location blueFinalWallMax;
    private File schematicFile;
    private ItemStack icon;
    private Material prefightWallMaterial;
    private Set<BlockFace> prefightWallFacing = new LinkedHashSet();
    private boolean inUse;
    private long lastUsedMillis;

    public Arena(String id, String displayName) {
        this.id = id.toLowerCase();
        this.displayName = displayName;
    }

    public String id() {
        return this.id;
    }

    public String displayName() {
        return this.displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public World world() {
        if (this.worldName == null) {
            return null;
        }
        return Bukkit.getWorld(this.worldName);
    }

    public String worldName() {
        return this.worldName;
    }

    public void setWorldName(String worldName) {
        this.worldName = worldName;
    }

    public Location redSpawn() {
        return this.redSpawn;
    }

    public Location blueSpawn() {
        return this.blueSpawn;
    }

    public void setRedSpawn(Location redSpawn) {
        this.redSpawn = redSpawn;
    }

    public void setBlueSpawn(Location blueSpawn) {
        this.blueSpawn = blueSpawn;
    }

    public Location min() {
        return this.min;
    }

    public Location max() {
        return this.max;
    }

    public void setRegion(Location min, Location max) {
        this.min = min;
        this.max = max;
    }

    public Location wallMin(String side) {
        return isRed(side) ? this.redWallMin : this.blueWallMin;
    }

    public Location wallMax(String side) {
        return isRed(side) ? this.redWallMax : this.blueWallMax;
    }

    public Location finalWallMin(String side) {
        return isRed(side) ? this.redFinalWallMin : this.blueFinalWallMin;
    }

    public Location finalWallMax(String side) {
        return isRed(side) ? this.redFinalWallMax : this.blueFinalWallMax;
    }

    public void setWallRegion(String side, Location min, Location max) {
        if (isRed(side)) {
            this.redWallMin = min;
            this.redWallMax = max;
        } else {
            this.blueWallMin = min;
            this.blueWallMax = max;
        }
    }

    public void setFinalWallRegion(String side, Location min, Location max) {
        if (isRed(side)) {
            this.redFinalWallMin = min;
            this.redFinalWallMax = max;
        } else {
            this.blueFinalWallMin = min;
            this.blueFinalWallMax = max;
        }
    }

    public boolean hasWall(String side) {
        return (wallMin(side) == null || wallMax(side) == null) ? false : true;
    }

    public boolean hasFinalWall(String side) {
        return (finalWallMin(side) == null || finalWallMax(side) == null) ? false : true;
    }

    private boolean isRed(String side) {
        return side != null && side.equalsIgnoreCase("red");
    }

    public File schematicFile() {
        return this.schematicFile;
    }

    public void setSchematicFile(File schematicFile) {
        this.schematicFile = schematicFile;
    }

    public ItemStack icon() {
        if (this.icon == null) {
            return null;
        }
        return this.icon.clone();
    }

    public void setIcon(ItemStack icon) {
        this.icon = icon == null ? null : icon.clone();
    }

    public Material prefightWallMaterial() {
        return this.prefightWallMaterial;
    }

    public void setPrefightWallMaterial(Material prefightWallMaterial) {
        this.prefightWallMaterial = prefightWallMaterial;
    }

    public Set<BlockFace> prefightWallFacing() {
        return new LinkedHashSet(this.prefightWallFacing);
    }

    public void setPrefightWallFacing(Set<BlockFace> prefightWallFacing) {
        this.prefightWallFacing = prefightWallFacing == null ? new LinkedHashSet() : new LinkedHashSet(prefightWallFacing);
    }

    public List<String> readyReasons() {
        List<String> reasons = new ArrayList<>();
        if (world() == null) {
            reasons.add("world not loaded");
        }
        if (this.redSpawn == null) {
            reasons.add("red spawn missing");
        } else if (this.redSpawn.getWorld() == null) {
            reasons.add("red spawn world missing");
        }
        if (this.blueSpawn == null) {
            reasons.add("blue spawn missing");
        } else if (this.blueSpawn.getWorld() == null) {
            reasons.add("blue spawn world missing");
        }
        if (this.min == null || this.max == null) {
            reasons.add("regen region missing");
        } else if (this.min.getWorld() == null || this.max.getWorld() == null) {
            reasons.add("regen region world missing");
        }
        if (this.schematicFile == null) {
            reasons.add("schematic file not assigned");
        } else if (!this.schematicFile.exists()) {
            reasons.add("schematic file missing");
        }
        return reasons;
    }

    public boolean ready() {
        return readyReasons().isEmpty();
    }

    public boolean inUse() {
        return this.inUse;
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }

    public long lastUsedMillis() {
        return this.lastUsedMillis;
    }

    public void setLastUsedMillis(long lastUsedMillis) {
        this.lastUsedMillis = lastUsedMillis;
    }
}
