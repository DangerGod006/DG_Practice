package dev.rean.pvpcore.tiers;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.rean.pvpcore.PvPCorePlugin;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/tiers/McTiersService.class */
public final class McTiersService {
    private static final String API_URL = "https://mctiers.com/api/profile/%s";
    private static final String[] API_MODES = {"vanilla", "sword", "pot", "uhc", "smp", "nethop", "axe", "mace"};
    private static final long CACHE_TTL_MS = Duration.ofMinutes(5).toMillis();
    private static final long STALE_AFTER_MS = Duration.ofSeconds(45).toMillis();
    private final PvPCorePlugin plugin;
    private final Map<UUID, CacheEntry> cache = new ConcurrentHashMap();
    private final Set<UUID> inFlight = ConcurrentHashMap.newKeySet();

    public McTiersService(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public String getTierNow(UUID uniqueId, String mode) {
        if (uniqueId == null || mode == null || mode.isBlank()) {
            return "";
        }
        String apiKey = resolveApiKey(mode);
        long now = System.currentTimeMillis();
        CacheEntry entry = this.cache.get(uniqueId);
        if (entry != null) {
            long age = now - entry.loadedAt;
            if (age > STALE_AFTER_MS) {
                scheduleRefresh(uniqueId);
            }
            if (age <= CACHE_TTL_MS) {
                return entry.getTier(apiKey);
            }
            scheduleRefresh(uniqueId);
            return entry.getTier(apiKey);
        }
        scheduleRefresh(uniqueId);
        return "";
    }

    public void invalidate(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        this.cache.remove(uniqueId);
        this.inFlight.remove(uniqueId);
    }

    public void requestRefresh(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        scheduleRefresh(uniqueId);
    }

    private void scheduleRefresh(UUID uniqueId) {
        if (this.inFlight.add(uniqueId)) {
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
                try {
                    CacheEntry fresh = fetch(uniqueId);
                    if (fresh != null) {
                        this.cache.put(uniqueId, fresh);
                    }
                } finally {
                    this.inFlight.remove(uniqueId);
                }
            });
        }
    }

    private CacheEntry fetch(UUID uniqueId) {
        JsonElement rankingsEl;
        String uuid = uniqueId.toString().replace("-", "");
        String url = String.format(API_URL, uuid);
        JsonObject payload = openJson(url);
        if (payload == null || (rankingsEl = payload.get("rankings")) == null || !rankingsEl.isJsonObject()) {
            return null;
        }
        JsonObject rankings = rankingsEl.getAsJsonObject();
        Map<String, String> tiers = new LinkedHashMap<>();
        for (String apiKey : API_MODES) {
            JsonElement modeEl = rankings.get(apiKey);
            if (modeEl != null && modeEl.isJsonObject()) {
                JsonObject modeObj = modeEl.getAsJsonObject();
                String tierCode = parseTierCode(modeObj);
                if (!tierCode.isEmpty()) {
                    tiers.put(apiKey, tierCode);
                }
            }
        }
        return new CacheEntry(System.currentTimeMillis(), tiers);
    }

    private static String parseTierCode(JsonObject modeObj) {
        JsonElement tierEl = modeObj.get("tier");
        JsonElement posEl = modeObj.get("pos");
        if (tierEl == null || !tierEl.isJsonPrimitive() || posEl == null || !posEl.isJsonPrimitive()) {
            return "";
        }
        try {
            int tier = tierEl.getAsInt();
            int pos = posEl.getAsInt();
            if (tier < 1 || tier > 5) {
                return "";
            }
            String prefix = pos == 0 ? "HT" : "LT";
            return prefix + tier;
        } catch (Exception e) {
            return "";
        }
    }

    private static JsonObject openJson(String url) {
        HttpURLConnection conn = null;
        try {
            HttpURLConnection conn2 = (HttpURLConnection) URI.create(url).toURL().openConnection();
            conn2.setRequestMethod("GET");
            conn2.setConnectTimeout(3000);
            conn2.setReadTimeout(3000);
            conn2.setRequestProperty("Accept", "application/json");
            conn2.setRequestProperty("User-Agent", "PvPCore/1.0");
            int code = conn2.getResponseCode();
            if (code == 404) {
                if (conn2 != null) {
                    conn2.disconnect();
                }
                return null;
            }
            if (code < 200 || code >= 300) {
                if (conn2 != null) {
                    conn2.disconnect();
                }
                return null;
            }
            InputStream in = conn2.getInputStream();
            try {
                String body = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                JsonElement el = JsonParser.parseString(body);
                JsonObject asJsonObject = el.isJsonObject() ? el.getAsJsonObject() : null;
                if (in != null) {
                    in.close();
                }
                if (conn2 != null) {
                    conn2.disconnect();
                }
                return asJsonObject;
            } catch (Throwable th) {
                if (in != null) {
                    try {
                        in.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        } catch (Exception e) {
            if (0 != 0) {
                conn.disconnect();
            }
            return null;
        } catch (Throwable th3) {
            if (0 != 0) {
                conn.disconnect();
            }
            throw th3;
        }
    }

    private static String resolveApiKey(String mode) {
        String m;
        m = mode.trim().toLowerCase().replace("_", "").replace("-", "").replace(" ", "");
        switch (m) {
            case "potpvp":
            case "nodebuff":
            case "potp":
                return "pot";
            case "nethop":
            case "nethpot":
            case "netheritepot":
            case "netheriteop":
            case "nethpvp":
            case "nethpot2":
                return "nethop";
            default:
                return m;
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/tiers/McTiersService$CacheEntry.class */
    private static final class CacheEntry {
        final long loadedAt;
        final Map<String, String> tiers;

        CacheEntry(long loadedAt, Map<String, String> tiers) {
            this.loadedAt = loadedAt;
            this.tiers = tiers;
        }

        String getTier(String apiKey) {
            return this.tiers.getOrDefault(apiKey, "");
        }
    }
}
