package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.duel.DuelMatch;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/PlayerDeathListener.class */
public final class PlayerDeathListener implements Listener {
    private final DuelManager duels;

    public PlayerDeathListener(DuelManager duels) {
        this.duels = duels;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        DuelMatch match = this.duels.getMatch(p.getUniqueId());
        if (match == null) {
            return;
        }
        e.setKeepInventory(true);
        e.setKeepLevel(true);
        e.getDrops().clear();
        e.deathMessage((Component) null);
        if (!match.isFighting()) {
            e.setCancelled(true);
        } else {
            this.duels.handleDeath(p);
            e.setCancelled(true);
        }
    }
}
