package dev.rean.pvpcore.util;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/HeadTextureUtil.class */
public final class HeadTextureUtil {
    private HeadTextureUtil() {
    }

    public static boolean applyValue(ItemStack item, String rawValue) {
        if (item == null || item.getType() != Material.PLAYER_HEAD) {
            return false;
        }
        SkullMeta itemMeta = item.getItemMeta();
        if (!(itemMeta instanceof SkullMeta)) {
            return false;
        }
        SkullMeta meta = itemMeta;
        String value = cleanTextureValue(rawValue);
        if (value == null || value.isBlank()) {
            return false;
        }
        try {
            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID(), (String) null);
            profile.setProperty(new ProfileProperty("textures", value));
            meta.setPlayerProfile(profile);
            item.setItemMeta(meta);
            return true;
        } catch (Throwable th) {
            return applyReflection(meta, item, value);
        }
    }

    private static boolean applyReflection(SkullMeta meta, ItemStack item, String value) {
        try {
            Class<?> gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
            Class<?> propertyClass = Class.forName("com.mojang.authlib.properties.Property");
            Object profile = gameProfileClass.getConstructor(UUID.class, String.class).newInstance(UUID.randomUUID(), "pvpcore");
            Object properties = gameProfileClass.getMethod("getProperties", new Class[0]).invoke(profile, new Object[0]);
            Object property = propertyClass.getConstructor(String.class, String.class).newInstance("textures", value);
            properties.getClass().getMethod("put", Object.class, Object.class).invoke(properties, "textures", property);
            Field profileField = meta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(meta, profile);
            item.setItemMeta(meta);
            return true;
        } catch (Throwable th) {
            item.setItemMeta(meta);
            return false;
        }
    }

    public static String cleanTextureValue(String rawValue) {
        int start;
        int end;
        int start2;
        int end2;
        if (rawValue == null) {
            return "";
        }
        String value = rawValue.trim();
        if (value.isBlank()) {
            return "";
        }
        int valueKey = value.indexOf("Value:\"");
        if (valueKey >= 0 && (end2 = value.indexOf(34, (start2 = valueKey + "Value:\"".length()))) > start2) {
            value = value.substring(start2, end2);
        }
        int jsonKey = value.indexOf("\"value\":\"");
        if (jsonKey >= 0 && (end = value.indexOf(34, (start = jsonKey + "\"value\":\"".length()))) > start) {
            value = value.substring(start, end);
        }
        String value2 = value.trim();
        if ((value2.startsWith("\"") && value2.endsWith("\"")) || (value2.startsWith("'") && value2.endsWith("'"))) {
            value2 = value2.substring(1, value2.length() - 1).trim();
        }
        if (value2.startsWith("http://") || value2.startsWith("https://")) {
            String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + value2 + "\"}}}";
            return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
        }
        return value2;
    }
}
