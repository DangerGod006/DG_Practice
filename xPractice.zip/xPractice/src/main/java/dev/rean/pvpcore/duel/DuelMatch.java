package dev.rean.pvpcore.duel;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.displaytags.nametags.NametagManager;
import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.managers.Settings;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.prefight.PreFightSkipSequence;
import dev.rean.pvpcore.util.TitleFormat;
import dev.rean.pvpcore.util.U;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/duel/DuelMatch.class */
public final class DuelMatch {
    private final PvPCorePlugin plugin;
    private final Settings settings;
    private final MessageManager messages;
    private final Arena arena;
    private final Kit kit;
    private final UUID red;
    private final UUID blue;
    private final int firstTo;
    private BukkitTask countdownTask;
    private PreFightSkipSequence preFightSkipSequence;
    private final Map<UUID, Integer> totemPops = new LinkedHashMap();
    private int redWins = 0;
    private int blueWins = 0;
    private MatchState state = MatchState.COUNTDOWN;
    private final Set<BukkitTask> pendingMatchTasks = new LinkedHashSet();

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/duel/DuelMatch$MatchState.class */
    private enum MatchState {
        COUNTDOWN,
        FIGHTING,
        ENDING
    }

    public DuelMatch(PvPCorePlugin plugin, Settings settings, MessageManager messages, Arena arena, Kit kit, UUID red, UUID blue, int firstTo) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.arena = arena;
        this.kit = kit;
        this.red = red;
        this.blue = blue;
        this.firstTo = Math.max(1, firstTo);
        this.totemPops.put(red, 0);
        this.totemPops.put(blue, 0);
    }

    public UUID red() {
        return this.red;
    }

    public UUID blue() {
        return this.blue;
    }

    public int redWins() {
        return this.redWins;
    }

    public int blueWins() {
        return this.blueWins;
    }

    public Arena arena() {
        return this.arena;
    }

    public Kit kit() {
        return this.kit;
    }

    public boolean isFighting() {
        return this.state == MatchState.FIGHTING;
    }

    public boolean contains(UUID playerId) {
        return playerId != null && (this.red.equals(playerId) || this.blue.equals(playerId));
    }

    public int totemPops(UUID playerId) {
        if (contains(playerId)) {
            return this.totemPops.getOrDefault(playerId, 0).intValue();
        }
        return 0;
    }

    public int opponentTotemPops(UUID viewerId) {
        if (contains(viewerId)) {
            return this.red.equals(viewerId) ? totemPops(this.blue) : totemPops(this.red);
        }
        return 0;
    }

    public int recordTotemPop(UUID breakerId) {
        if (!contains(breakerId) || this.state == MatchState.ENDING) {
            return 0;
        }
        int next = Math.min(Integer.MAX_VALUE, totemPops(breakerId) + 1);
        this.totemPops.put(breakerId, Integer.valueOf(next));
        return next;
    }

    public String formattedTotemPops(UUID playerId) {
        return formatTotemPops(playerId, totemPops(playerId));
    }

    public String formattedTotemPopsFor(UUID viewerId, UUID targetId) {
        return formatTotemPops(viewerId, totemPops(targetId));
    }

    public String formattedOpponentTotemPops(UUID viewerId) {
        return formatTotemPops(viewerId, opponentTotemPops(viewerId));
    }

    public void scheduleStart(long delayTicks) {
        runMatchTaskLater(this::start, Math.max(0L, delayTicks));
    }

    public void start() {
        CommandSender player = Bukkit.getPlayer(this.red);
        CommandSender player2 = Bukkit.getPlayer(this.blue);
        if (player == null || player2 == null) {
            endForce();
            return;
        }
        if (!this.plugin.arenaManager().isUsableForMatch(this.arena)) {
            String reason = String.join(", ", this.plugin.arenaManager().matchReadinessReasons(this.arena));
            this.plugin.getLogger().warning("Cannot start duel in arena " + (this.arena == null ? "<null>" : this.arena.id()) + ": " + reason);
            this.messages.send(player, "duels.no-arena");
            this.messages.send(player2, "duels.no-arena");
            endForce();
            return;
        }
        this.state = MatchState.COUNTDOWN;
        resetTotemPops();
        prepPlayer(player);
        prepPlayer(player2);
        this.plugin.tierResolver().prefetch(this.red);
        this.plugin.tierResolver().prefetch(this.blue);
        if (!teleportToSpawns()) {
            endForce();
        } else {
            executeKitConsoleCommandsForRound();
            beginCountdown();
        }
    }

    public void handleResign(UUID quitterId) {
        if (this.state == MatchState.ENDING) {
            return;
        }
        this.state = MatchState.ENDING;
        cancelPendingMatchTasks();
        this.plugin.spectatorManager().stopSpectatingMatch(this);
        this.plugin.tabScoreboardHook().resetDuelTabNames(this);
        this.arena.setInUse(false);
        this.plugin.arenaManager().markUsed(this.arena);
        UUID winnerId = quitterId.equals(this.red) ? this.blue : this.red;
        Player quitter = Bukkit.getPlayer(quitterId);
        Player winner = Bukkit.getPlayer(winnerId);
        restorePlayerToLobby(quitter);
        Bukkit.getScheduler().runTaskLater(this.plugin, this::applyEndBlindness, 40L);
        if (winner != null) {
            winner.playSound(winner, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0f, 0.8f);
            TitleFormat.send(winner, "&cResigned Match...|&f" + safePlayerName(quitterId) + " &7left.|0|40|20", this.messages);
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                restorePlayerToLobby(winner);
            }, 40L);
        }
        this.plugin.arenaManager().regenArenaAsync(this.arena, null);
    }

    public void onDeath(Player dead) {
        if (this.state == MatchState.ENDING) {
            return;
        }
        UUID deadId = dead.getUniqueId();
        UUID winnerId = deadId.equals(this.red) ? this.blue : this.red;
        if (winnerId.equals(this.red)) {
            this.redWins++;
        } else {
            this.blueWins++;
        }
        Location exactDeathLocation = dead.getLocation().clone();
        this.plugin.duelVisualEffects().playFakeDeath(dead, exactDeathLocation, currentViewers());
        this.plugin.duelVisualEffects().playDeathCombatEffects(dead, Bukkit.getPlayer(winnerId));
        this.messages.sendToBoth(this, "duels.round-death", Map.of("victim", coloredName(deadId), "killer", coloredName(winnerId), "score", getColoredScoreLine()));
        boolean matchFinished = this.redWins >= this.firstTo || this.blueWins >= this.firstTo;
        if (!matchFinished) {
            sendRoundSummary(winnerId, deadId);
        }
        runMatchTaskLater(() -> {
            makeSpectator(dead);
        }, 1L);
        if (matchFinished) {
            endMatch(winnerId);
            return;
        }
        dead.playSound(dead, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 1.0f);
        TitleFormat.send(dead, this.messages.get("titles.round-lose", Map.of("winner", coloredName(winnerId), "loser", coloredName(deadId), "score", getColoredScoreLineFor(deadId))), this.messages);
        Player winner = Bukkit.getPlayer(winnerId);
        if (winner != null) {
            winner.playSound(winner, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.0f, 1.0f);
            Map<String, String> titlePh = Map.of("winner", coloredName(winnerId), "loser", coloredName(deadId), "score", getColoredScoreLineFor(winnerId));
            List<String> frames = this.messages.getStringList("titles.round-animation.texts").stream().map(line -> {
                return this.messages.format(line, titlePh);
            }).toList();
            if (!frames.isEmpty()) {
                String subtitle = this.messages.get("titles.round-animation.subtitle", titlePh);
                int interval = this.messages.getInt("titles.round-animation.change-interval", 2);
                this.plugin.duelVisualEffects().playAnimatedTitle(winner, frames, subtitle, interval);
            }
        }
        this.state = MatchState.COUNTDOWN;
        runMatchTaskLater(() -> {
            Player r = Bukkit.getPlayer(this.red);
            Player b = Bukkit.getPlayer(this.blue);
            if (r == null || b == null) {
                endForce();
            } else {
                this.plugin.arenaManager().regenArenaAsync(this.arena, () -> {
                    if (this.state == MatchState.ENDING) {
                        return;
                    }
                    Player r2 = Bukkit.getPlayer(this.red);
                    Player b2 = Bukkit.getPlayer(this.blue);
                    if (r2 == null || b2 == null) {
                        endForce();
                        return;
                    }
                    resetForNewRound(r2);
                    resetForNewRound(b2);
                    resetTotemPops();
                    if (!teleportToSpawns()) {
                        endForce();
                    } else {
                        executeKitConsoleCommandsForRound();
                        beginCountdown();
                    }
                });
            }
        }, 60L);
    }

    public void endForce() {
        this.state = MatchState.ENDING;
        cancelPendingMatchTasks();
        this.plugin.spectatorManager().stopSpectatingMatch(this);
        this.plugin.tabScoreboardHook().resetDuelTabNames(this);
        this.arena.setInUse(false);
        this.plugin.arenaManager().markUsed(this.arena);
        teleportEndAndCleanup();
        this.plugin.duelManager().finishMatch(this);
    }

    private void endMatch(UUID winner) {
        this.state = MatchState.ENDING;
        cancelPendingMatchTasks();
        this.plugin.spectatorManager().stopSpectatingMatch(this);
        this.plugin.tabScoreboardHook().resetDuelTabNames(this);
        this.arena.setInUse(false);
        this.plugin.arenaManager().markUsed(this.arena);
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        Player w = Bukkit.getPlayer(winner);
        UUID loserId = winner.equals(this.red) ? this.blue : this.red;
        Player l = Bukkit.getPlayer(loserId);
        sendMatchSummary(winner, loserId);
        if (w != null) {
            w.playSound(w, Sound.BLOCK_BEACON_POWER_SELECT, 1.0f, 1.0f);
            Map<String, String> titlePh = Map.of("winner", coloredName(winner), "loser", coloredName(loserId), "score", getColoredScoreLineFor(winner));
            List<String> frames = this.messages.getStringList("titles.match-animation.texts").stream().map(line -> {
                return this.messages.format(line, titlePh);
            }).toList();
            if (!frames.isEmpty()) {
                String subtitle = this.messages.get("titles.match-animation.subtitle", titlePh);
                int interval = this.messages.getInt("titles.match-animation.change-interval", 2);
                this.plugin.duelVisualEffects().playAnimatedTitle(w, frames, subtitle, interval);
            } else {
                TitleFormat.send(w, this.messages.get("titles.match-win", titlePh), this.messages);
            }
        }
        if (l != null) {
            l.playSound(l, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.8f);
            TitleFormat.send(l, this.messages.get("titles.match-lose", Map.of("winner", coloredName(winner), "loser", coloredName(loserId), "score", getColoredScoreLineFor(loserId))), this.messages);
        }
        if (r != null && !r.getUniqueId().equals(winner)) {
            makeSpectator(r);
        }
        if (b != null && !b.getUniqueId().equals(winner)) {
            makeSpectator(b);
        }
        Bukkit.getScheduler().runTaskLater(this.plugin, this::applyEndBlindness, 50L);
        Bukkit.getScheduler().runTaskLater(this.plugin, this::teleportEndAndCleanup, 100L);
    }

    private void beginCountdown() {
        if (this.state == MatchState.ENDING) {
            return;
        }
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
        }
        this.countdownTask = null;
        destroyPreFightSkipSequence();
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        if (r == null || b == null) {
            endForce();
            return;
        }
        this.preFightSkipSequence = this.plugin.preFightSkipManager().begin(this, r, b);
        if (this.preFightSkipSequence == null) {
            beginFallbackCountdown();
        }
    }

    private void beginFallbackCountdown() {
        if (this.state == MatchState.ENDING) {
            return;
        }
        int seconds = Math.max(1, this.plugin.settings().countdownSeconds());
        int[] left = {seconds};
        this.countdownTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.state == MatchState.ENDING) {
                if (this.countdownTask != null) {
                    this.countdownTask.cancel();
                }
                this.countdownTask = null;
                return;
            }
            Player r = Bukkit.getPlayer(this.red);
            Player b = Bukkit.getPlayer(this.blue);
            if (r == null || b == null) {
                endForce();
                return;
            }
            int t = left[0];
            if (t <= 0) {
                if (this.countdownTask != null) {
                    this.countdownTask.cancel();
                }
                this.countdownTask = null;
                onCountdownFinished(false);
                return;
            }
            TitleFormat.send(r, this.messages.get("titles.countdown", Map.of("seconds", String.valueOf(t), "time", String.valueOf(t))), this.messages);
            TitleFormat.send(b, this.messages.get("titles.countdown", Map.of("seconds", String.valueOf(t), "time", String.valueOf(t))), this.messages);
            r.playSound(r.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 1.0f);
            b.playSound(b.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 1.0f);
            left[0] = t - 1;
        }, 0L, 20L);
    }

    public void onCountdownFinished(boolean skippedByBoth) {
        if (this.state == MatchState.ENDING) {
            return;
        }
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        if (r == null || b == null) {
            endForce();
            return;
        }
        this.state = MatchState.FIGHTING;
        applyStartConsumables(r);
        applyStartConsumables(b);
        playConfiguredAnimation(r, "titles.fight-animation", "titles.fight", Map.of());
        playConfiguredAnimation(b, "titles.fight-animation", "titles.fight", Map.of());
        r.playSound(r, Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.0f);
        b.playSound(b, Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.0f);
    }

    private void applyEndBlindness() {
        if (isStillRegistered()) {
            applyBlindness(Bukkit.getPlayer(this.red));
            applyBlindness(Bukkit.getPlayer(this.blue));
        }
    }

    private boolean isStillRegistered() {
        return this.plugin.duelManager() != null && (this.plugin.duelManager().getMatch(this.red) == this || this.plugin.duelManager().getMatch(this.blue) == this);
    }

    private void applyBlindness(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 70, 0, false, false, false));
    }

    private void executeKitConsoleCommandsForRound() {
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        if (r == null || b == null) {
            return;
        }
        applyKitTagVisibility(r);
        applyKitTagVisibility(b);
        String rawCommand = this.kit.consoleCommand();
        if (rawCommand != null && !rawCommand.isBlank()) {
            dispatchConsoleCommand(rawCommand, r, b);
            dispatchConsoleCommand(rawCommand, b, r);
        }
    }

    private void applyKitTagVisibility(Player player) {
        if (player == null || this.plugin.displayTags() == null || this.plugin.displayTags().getNametagManager() == null) {
            return;
        }
        NametagManager manager = this.plugin.displayTags().getNametagManager();
        manager.clearForcedVisibleTags(player);
        if (this.kit.hiddenTags().isEmpty()) {
            manager.clearForcedHiddenTags(player);
        } else {
            manager.setForcedHiddenTags(player, new LinkedHashSet(this.kit.hiddenTags()));
        }
    }

    private void clearKitTagVisibility(Player player) {
        if (player == null || this.plugin.displayTags() == null || this.plugin.displayTags().getNametagManager() == null) {
            return;
        }
        NametagManager manager = this.plugin.displayTags().getNametagManager();
        manager.clearForcedVisibleTags(player);
        manager.clearForcedHiddenTags(player);
        this.plugin.tabScoreboardHook().refreshPlayer(player);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            this.plugin.tabScoreboardHook().refreshPlayer(player);
        }, 5L);
    }

    private void sendRoundSummary(UUID winnerId, UUID loserId) {
        Map<String, String> ph = new LinkedHashMap<>();
        ph.put("winner", coloredName(winnerId));
        ph.put("loser", coloredName(loserId));
        ph.put("score", getColoredScoreLine());
        ph.put("red_score", String.valueOf(this.redWins));
        ph.put("blue_score", String.valueOf(this.blueWins));
        ph.put("round", String.valueOf(this.redWins + this.blueWins));
        ph.put("red_pops", String.valueOf(totemPops(this.red)));
        ph.put("blue_pops", String.valueOf(totemPops(this.blue)));
        ph.put("winner_pops", String.valueOf(totemPops(winnerId)));
        ph.put("loser_pops", String.valueOf(totemPops(loserId)));
        ph.put("winner_color", teamColor(winnerId));
        ph.put("loser_color", teamColor(loserId));
        ph.put("kit_summary", buildKitSummary(winnerId));
        if (this.messages.getStringList("duels.round-summary").isEmpty()) {
            return;
        }
        this.messages.sendToBoth(this, "duels.round-summary", ph);
    }

    private void sendMatchSummary(UUID winnerId, UUID loserId) {
        Map<String, String> ph = new LinkedHashMap<>();
        ph.put("winner", coloredName(winnerId));
        ph.put("loser", coloredName(loserId));
        ph.put("score", getColoredScoreLine());
        ph.put("red_score", String.valueOf(this.redWins));
        ph.put("blue_score", String.valueOf(this.blueWins));
        ph.put("rounds_total", String.valueOf(this.redWins + this.blueWins));
        ph.put("arena", this.arena.id());
        ph.put("arena_name", this.arena.displayName());
        ph.put("kit", this.kit.id());
        ph.put("kit_name", this.kit.displayName());
        ph.put("red_pops", String.valueOf(totemPops(this.red)));
        ph.put("blue_pops", String.valueOf(totemPops(this.blue)));
        ph.put("winner_pops", String.valueOf(totemPops(winnerId)));
        ph.put("loser_pops", String.valueOf(totemPops(loserId)));
        ph.put("winner_color", teamColor(winnerId));
        ph.put("loser_color", teamColor(loserId));
        ph.put("kit_summary", buildKitSummary(winnerId));
        if (this.messages.getStringList("duels.match-summary").isEmpty()) {
            return;
        }
        this.messages.sendToBoth(this, "duels.match-summary", ph);
    }

    private void resetTotemPops() {
        this.totemPops.put(this.red, 0);
        this.totemPops.put(this.blue, 0);
    }

    private String buildKitSummary(UUID winnerId) {
        Player winner;
        if (this.kit == null || this.kit.summaryInfo().isEmpty() || (winner = Bukkit.getPlayer(winnerId)) == null) {
            return "";
        }
        List<String> parts = new ArrayList<>();
        for (String info : this.kit.summaryInfo()) {
            switch (info) {
                case "totems":
                    parts.add("&6❤ " + countPlayerItems(winner, Material.TOTEM_OF_UNDYING) + "/" + countKitItems(Material.TOTEM_OF_UNDYING) + " ᴛᴏᴛᴇᴍs");
                    break;
                case "pots":
                    parts.add("&#F70000⚗ " + countPlayerInstantHealthPots(winner) + "/" + countKitInstantHealthPots() + " ᴘᴏᴛs");
                    break;
                case "hp":
                    parts.add("&#F70000❤ " + formatHealth(winner.getHealth()) + "/20 ʜᴘ");
                    break;
                case "armoravg":
                    parts.add("&6🛡 " + formatStrongestArmorPiece(winner));
                    break;
                case "xp":
                    parts.add("&a⚗︎ " + countPlayerItems(winner, Material.EXPERIENCE_BOTTLE) + " xᴘ");
                    break;
            }
        }
        return String.join(" &8| ", parts);
    }

    private int countKitItems(Material material) {
        int count = 0 + countItems(this.kit.contents(), material) + countItems(this.kit.armor(), material);
        ItemStack offhand = this.kit.offhand();
        if (offhand != null && offhand.getType() == material) {
            count += Math.max(1, offhand.getAmount());
        }
        return count;
    }

    private int countPlayerItems(Player player, Material material) {
        int count = countItems(player.getInventory().getStorageContents(), material) + countItems(player.getInventory().getArmorContents(), material);
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getType() == material) {
            count += Math.max(1, offhand.getAmount());
        }
        return count;
    }

    private int countItems(ItemStack[] items, Material material) {
        int count = 0;
        if (items == null) {
            return 0;
        }
        for (ItemStack item : items) {
            if (item != null && item.getType() == material) {
                count += Math.max(1, item.getAmount());
            }
        }
        return count;
    }

    private int countKitInstantHealthPots() {
        int count = countInstantHealthPots(this.kit.contents()) + countInstantHealthPots(this.kit.armor());
        ItemStack offhand = this.kit.offhand();
        if (isInstantHealthPotion(offhand)) {
            count += Math.max(1, offhand.getAmount());
        }
        return count;
    }

    private int countPlayerInstantHealthPots(Player player) {
        int count = countInstantHealthPots(player.getInventory().getStorageContents()) + countInstantHealthPots(player.getInventory().getArmorContents());
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (isInstantHealthPotion(offhand)) {
            count += Math.max(1, offhand.getAmount());
        }
        return count;
    }

    private int countInstantHealthPots(ItemStack[] items) {
        int count = 0;
        if (items == null) {
            return 0;
        }
        for (ItemStack item : items) {
            if (isInstantHealthPotion(item)) {
                count += Math.max(1, item.getAmount());
            }
        }
        return count;
    }

    private boolean isInstantHealthPotion(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return false;
        }
        if (item.getType() != Material.POTION && item.getType() != Material.SPLASH_POTION && item.getType() != Material.LINGERING_POTION) {
            return false;
        }
        PotionMeta itemMeta = item.getItemMeta();
        if (!(itemMeta instanceof PotionMeta)) {
            return false;
        }
        PotionMeta potionMeta = itemMeta;
        for (PotionEffect effect : potionMeta.getCustomEffects()) {
            if (isInstantHealthEffect(effect)) {
                return true;
            }
        }
        return potionMeta.getBasePotionType() != null && potionMeta.getBasePotionType().getPotionEffects().stream().anyMatch(this::isInstantHealthEffect);
    }

    private boolean isInstantHealthEffect(PotionEffect effect) {
        if (effect == null || effect.getType() == null || effect.getType().getKey() == null) {
            return false;
        }
        String key = effect.getType().getKey().getKey();
        return key.equalsIgnoreCase("instant_health") || key.equalsIgnoreCase("heal");
    }

    private String formatHealth(double health) {
        double safe = Math.max(0.0d, Math.min(20.0d, health));
        return Math.abs(safe - Math.rint(safe)) < 0.05d ? String.valueOf((int) Math.rint(safe)) : String.format(Locale.ROOT, "%.1f", Double.valueOf(safe));
    }

    private String formatStrongestArmorPiece(Player player) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        ItemStack bestItem = null;
        int bestRemaining = -1;
        for (ItemStack item : armor) {
            if (item != null && !item.getType().isAir() && item.getType().getMaxDurability() > 0) {
                int max = item.getType().getMaxDurability();
                int damage = 0;
                Damageable itemMeta = item.getItemMeta();
                if (itemMeta instanceof Damageable) {
                    Damageable damageable = itemMeta;
                    damage = damageable.getDamage();
                }
                int remaining = Math.max(0, max - damage);
                if (remaining > bestRemaining) {
                    bestRemaining = remaining;
                    bestItem = item;
                }
            }
        }
        return bestItem == null ? "0 ᴀʀᴍᴏʀ ᴀᴠɢ" : bestRemaining + " ᴀʀᴍᴏʀ ᴀᴠɢ";
    }

    private void playConfiguredAnimation(Player player, String animationPath, String fallbackPath, Map<String, String> ph) {
        if (player == null || !player.isOnline()) {
            return;
        }
        List<String> frames = this.messages.getStringList(animationPath + ".texts").stream().map(line -> {
            return this.messages.format(line, ph);
        }).toList();
        if (!frames.isEmpty()) {
            String subtitle = this.messages.get(animationPath + ".subtitle", ph);
            int interval = this.messages.getInt(animationPath + ".change-interval", 2);
            this.plugin.duelVisualEffects().playAnimatedTitle(player, frames, subtitle, interval);
            return;
        }
        TitleFormat.send(player, this.messages.get(fallbackPath, ph), this.messages);
    }

    private void applyStartConsumables(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        Map<PotionEffectType, PotionEffect> bestEffects = new LinkedHashMap<>();
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && !item.getType().isAir() && (item.getType() == Material.POTION || item.getType() == Material.SPLASH_POTION || item.getType() == Material.LINGERING_POTION)) {
                PotionMeta itemMeta = item.getItemMeta();
                if (itemMeta instanceof PotionMeta) {
                    PotionMeta potionMeta = itemMeta;
                    List<PotionEffect> effects = new ArrayList<>();
                    effects.addAll(potionMeta.getCustomEffects());
                    if (effects.isEmpty() && potionMeta.getBasePotionType() != null) {
                        effects.addAll(potionMeta.getBasePotionType().getPotionEffects());
                    }
                    for (PotionEffect effect : effects) {
                        PotionEffect current = bestEffects.get(effect.getType());
                        if (current == null || effect.getAmplifier() > current.getAmplifier() || (effect.getAmplifier() == current.getAmplifier() && effect.getDuration() > current.getDuration())) {
                            bestEffects.put(effect.getType(), effect);
                        }
                    }
                }
            }
        }
        if (bestEffects.isEmpty()) {
            return;
        }
        Iterator<PotionEffect> it = bestEffects.values().iterator();
        while (it.hasNext()) {
            player.addPotionEffect(it.next(), true);
        }
        playPotionUseVisual(player);
    }

    private void playPotionUseVisual(Player player) {
        Location loc = player.getLocation().clone().add(0.0d, 1.15d, 0.0d);
        player.getWorld().playSound(loc, Sound.ENTITY_SPLASH_POTION_THROW, 1.0f, 1.15f);
        player.getWorld().spawnParticle(Particle.SPLASH, loc, 10, 0.2d, 0.18d, 0.2d, 0.01d);
        runMatchTaskLater(() -> {
            if (player.isOnline()) {
                Location impact = player.getLocation().clone().add(0.0d, 1.0d, 0.0d);
                player.getWorld().playSound(impact, Sound.ENTITY_SPLASH_POTION_BREAK, 1.0f, 1.0f);
                player.getWorld().spawnParticle(Particle.WITCH, impact, 22, 0.3d, 0.35d, 0.3d, 0.01d);
            }
        }, 4L);
    }

    private BukkitTask runMatchTaskLater(Runnable action, long delayTicks) {
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            this.pendingMatchTasks.remove(holder[0]);
            if (this.state == MatchState.ENDING) {
                return;
            }
            action.run();
        }, Math.max(0L, delayTicks));
        this.pendingMatchTasks.add(holder[0]);
        return holder[0];
    }

    private void cancelPendingMatchTasks() {
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
            this.countdownTask = null;
        }
        Iterator<BukkitTask> iterator = this.pendingMatchTasks.iterator();
        while (iterator.hasNext()) {
            BukkitTask task = iterator.next();
            if (task != null && !task.isCancelled()) {
                task.cancel();
            }
            iterator.remove();
        }
        destroyPreFightSkipSequence();
    }

    private void dispatchConsoleCommand(String rawCommand, Player player, Player opponent) {
        if (player == null || rawCommand == null || rawCommand.isBlank()) {
            return;
        }
        String command = rawCommand.replace("%player%", player.getName()).replace("%target%", player.getName()).replace("%opponent%", opponent != null ? opponent.getName() : "").replace("%kit%", this.kit.id()).replace("%kit_name%", this.kit.displayName()).replace("%arena%", this.arena.id()).replace("%arena_name%", this.arena.displayName());
        if (command.startsWith("/")) {
            command = command.substring(1);
        }
        if (command.isBlank()) {
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
    }

    private void destroyPreFightSkipSequence() {
        if (this.preFightSkipSequence != null) {
            this.preFightSkipSequence.destroy();
            this.preFightSkipSequence = null;
        }
    }

    private void prepPlayer(Player p) {
        p.setFallDistance(0.0f);
        p.setFireTicks(0);
        p.setFoodLevel(20);
        p.clearActivePotionEffects();
        p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        p.setGameMode(this.kit.gameMode());
        U.applyKit(p, this.plugin.kitManager().getEffectiveKit(p.getUniqueId(), this.kit));
    }

    private void resetForNewRound(Player p) {
        p.setFallDistance(0.0f);
        p.setFireTicks(0);
        p.setFoodLevel(20);
        p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        p.setGameMode(this.kit.gameMode());
        p.clearActivePotionEffects();
        U.applyKit(p, this.plugin.kitManager().getEffectiveKit(p.getUniqueId(), this.kit));
    }

    private void makeSpectator(Player p) {
        p.setGameMode(GameMode.SPECTATOR);
    }

    private boolean teleportToSpawns() {
        CommandSender player = Bukkit.getPlayer(this.red);
        CommandSender player2 = Bukkit.getPlayer(this.blue);
        if (player == null || player2 == null) {
            return false;
        }
        if (!isValidTeleportLocation(this.arena.redSpawn()) || !isValidTeleportLocation(this.arena.blueSpawn())) {
            String reason = String.join(", ", this.plugin.arenaManager().matchReadinessReasons(this.arena));
            this.plugin.getLogger().warning("Cannot teleport duel players in arena " + (this.arena == null ? "<null>" : this.arena.id()) + ": " + reason);
            this.messages.send(player, "duels.no-arena");
            this.messages.send(player2, "duels.no-arena");
            return false;
        }
        player.teleport(this.arena.redSpawn());
        player2.teleport(this.arena.blueSpawn());
        return true;
    }

    private boolean isValidTeleportLocation(Location location) {
        return (location == null || location.getWorld() == null) ? false : true;
    }

    private void teleportEndAndCleanup() {
        destroyPreFightSkipSequence();
        this.plugin.tabScoreboardHook().resetDuelTabNames(this);
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        restorePlayerToLobby(r);
        restorePlayerToLobby(b);
        this.plugin.arenaManager().regenArenaAsync(this.arena, null);
    }

    private void restorePlayerToLobby(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        clearKitTagVisibility(player);
        resetPlayerIdentity(player);
        player.setGameMode(GameMode.SURVIVAL);
        U.clearInventory(player);
        player.clearActivePotionEffects();
        if (this.settings.mainSpawn() != null) {
            player.teleport(this.settings.mainSpawn());
        }
        applyConfiguredLobbySpeed(player);
        giveLobbyItemsReliably(player.getUniqueId());
    }

    private void giveLobbyItemsReliably(UUID playerId) {
        giveLobbyItemsIfStillRestoring(playerId);
        long[] delays = {1, 5, 20, 40};
        for (long delay : delays) {
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                giveLobbyItemsIfStillRestoring(playerId);
            }, delay);
        }
    }

    private void giveLobbyItemsIfStillRestoring(UUID playerId) {
        Player current;
        if (playerId == null || (current = Bukkit.getPlayer(playerId)) == null || !current.isOnline()) {
            return;
        }
        DuelMatch active = this.plugin.duelManager().getMatch(playerId);
        if ((active == null || active == this) && !this.plugin.spectatorManager().isSpectating(playerId)) {
            this.plugin.lobbyItems().giveLobbyItems(current);
        }
    }

    private void resetPlayerIdentity(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        try {
            player.customName((Component) null);
            player.setCustomName((String) null);
            player.setCustomNameVisible(false);
        } catch (Throwable th) {
        }
        this.plugin.tabScoreboardHook().resetDuelTabName(player.getUniqueId());
        this.plugin.playerData().refreshIdentity(player);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            this.plugin.playerData().refreshIdentity(player);
        }, 1L);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            this.plugin.playerData().refreshIdentity(player);
        }, 5L);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            this.plugin.playerData().refreshIdentity(player);
        }, 20L);
    }

    private void applyConfiguredLobbySpeed(Player player) {
        if (player != null && player.isOnline() && this.settings.joinSpeedEnabled()) {
            int amplifier = Math.max(0, this.settings.joinSpeedLevel() - 1);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, -1, amplifier, false, false, false), true);
        }
    }

    public UUID opponentOf(UUID playerId) {
        if (playerId == null || !contains(playerId)) {
            return null;
        }
        return this.red.equals(playerId) ? this.blue : this.red;
    }

    public String teamColor(UUID playerId) {
        return (playerId == null || !contains(playerId)) ? "" : this.red.equals(playerId) ? redColor() : blueColor();
    }

    public Location spectatorLocation() {
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        if (r == null || b == null || !r.getWorld().equals(b.getWorld())) {
            return r != null ? r.getLocation().clone().add(0.0d, 3.0d, 0.0d) : b != null ? b.getLocation().clone().add(0.0d, 3.0d, 0.0d) : this.arena.redSpawn() != null ? this.arena.redSpawn().clone().add(0.0d, 3.0d, 0.0d) : this.arena.blueSpawn() != null ? this.arena.blueSpawn().clone().add(0.0d, 3.0d, 0.0d) : this.settings.mainSpawn();
        }
        Location redLocation = r.getLocation();
        Location blueLocation = b.getLocation();
        Location center = new Location(redLocation.getWorld(), (redLocation.getX() + blueLocation.getX()) * 0.5d, Math.max(redLocation.getY(), blueLocation.getY()) + 3.0d, (redLocation.getZ() + blueLocation.getZ()) * 0.5d, redLocation.getYaw(), 25.0f);
        center.setPitch(25.0f);
        return center;
    }

    public void teleportToOpponent(Player player) {
        if (player == null || !contains(player.getUniqueId())) {
            return;
        }
        UUID opponentId = opponentOf(player.getUniqueId());
        Player opponent = Bukkit.getPlayer(opponentId);
        if (opponent == null || !opponent.isOnline()) {
            return;
        }
        Location target = opponent.getLocation().clone();
        if (target.getWorld() == null) {
            return;
        }
        target.setY(Math.ceil(target.getY()));
        player.teleport(target);
        player.setFallDistance(0.0f);
        player.setFireTicks(0);
    }

    private String formatTotemPops(UUID viewerId, int pops) {
        if (!this.plugin.getConfig().getBoolean("duels.totem-pops.enabled", true)) {
            return "";
        }
        if (viewerId != null && !this.plugin.playerData().hasDuelPopsEnabled(viewerId)) {
            return "";
        }
        if (pops <= 0) {
            return this.plugin.getConfig().getString("duels.totem-pops.empty", "");
        }
        String format = this.plugin.getConfig().getString("duels.totem-pops.format", "&7| &a-%pops%");
        return format == null ? "" : format.replace("%pops%", String.valueOf(pops));
    }

    private Collection<Player> currentViewers() {
        List<Player> viewers = new ArrayList<>(4);
        Player r = Bukkit.getPlayer(this.red);
        Player b = Bukkit.getPlayer(this.blue);
        if (r != null) {
            viewers.add(r);
        }
        if (b != null) {
            viewers.add(b);
        }
        viewers.addAll(this.plugin.spectatorManager().spectators(this));
        return viewers;
    }

    private String safePlayerName(UUID playerId) {
        Player player = Bukkit.getPlayer(playerId);
        return player != null ? player.getName() : "Player";
    }

    private String getColoredScoreLine() {
        return redColor() + this.redWins + "&7 - &r" + blueColor() + this.blueWins;
    }

    public String getColoredScoreLineFor(UUID viewer) {
        if (viewer != null && viewer.equals(this.blue)) {
            return blueColor() + this.blueWins + "&7 - &r" + redColor() + this.redWins;
        }
        return getColoredScoreLine();
    }

    private String coloredName(UUID playerId) {
        Player p = Bukkit.getPlayer(playerId);
        String name = p != null ? p.getName() : "Unknown";
        return (playerId.equals(this.red) ? redColor() : blueColor()) + name;
    }

    public String redColor() {
        return this.plugin.getConfig().getString("team-colors.red", "&c");
    }

    public String blueColor() {
        return this.plugin.getConfig().getString("team-colors.blue", "&#1FA3FC");
    }
}
