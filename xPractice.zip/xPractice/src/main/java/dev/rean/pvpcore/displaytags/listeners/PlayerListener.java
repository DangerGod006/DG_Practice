package dev.rean.pvpcore.displaytags.listeners;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.nametags.Nametag;
import dev.rean.pvpcore.displaytags.nametags.NametagManager;
import io.papermc.paper.event.player.PlayerClientLoadedWorldEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/listeners/PlayerListener.class */
public class PlayerListener implements Listener {
    private final DisplayTags plugin = DisplayTags.getInstance();
    private final NametagManager nametagManager = DisplayTags.getInstance().getNametagManager();

    @EventHandler
    public void onPlayerLoad(PlayerClientLoadedWorldEvent event) {
        Player player = event.getPlayer();
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            if (this.nametagManager.get(player) != null) {
                this.nametagManager.remove(player);
            }
            this.nametagManager.create(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            this.nametagManager.remove(event.getPlayer());
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Nametag nametag;
        if (this.plugin.config().getNametagConfig().isEnabled() && (nametag = this.nametagManager.get(event.getPlayer())) != null) {
            nametag.markDeathVisible();
            nametag.updateVisibilityForAll();
            int delay = this.plugin.config().getNametagConfig().getDeathVisibleTicks();
            if (delay <= 0) {
                nametag.hideForAll();
            } else {
                Bukkit.getScheduler().runTaskLater(this.plugin.getHost(), () -> {
                    Player player = event.getPlayer();
                    Nametag current = this.nametagManager.get(player);
                    if (current == null || !player.isDead()) {
                        return;
                    }
                    current.hideForAll();
                }, delay);
            }
        }
    }

    @EventHandler
    public void onPlayerWorldChange(PlayerChangedWorldEvent event) {
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            Player player = event.getPlayer();
            this.nametagManager.remove(player);
            this.nametagManager.create(player);
        }
    }

    @EventHandler
    public void onPlayerGameModeChange(PlayerGameModeChangeEvent event) {
        Nametag nametag;
        if (this.plugin.config().getNametagConfig().isEnabled() && (nametag = this.nametagManager.get(event.getPlayer())) != null) {
            nametag.hideForAll();
            nametag.removeTemporarySpectatorTag();
            if (event.getNewGameMode() == GameMode.SPECTATOR) {
                nametag.showTemporaryTagOneAtCurrentPosition(22L);
            } else {
                nametag.updateVisibilityForAll();
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            Player player = event.getPlayer();
            Bukkit.getScheduler().runTaskLater(this.plugin.getHost(), () -> {
                this.nametagManager.remove(player);
                this.nametagManager.create(player);
            }, 1L);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        if (this.plugin.config().getNametagConfig().isEnabled()) {
            Bukkit.getScheduler().runTaskLater(this.plugin.getHost(), () -> {
                Player player = event.getPlayer();
                this.nametagManager.remove(player);
                this.nametagManager.create(player);
            }, 1L);
        }
    }
}
