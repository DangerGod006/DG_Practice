package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.queue.QueueManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/QueuePlayerListener.class */
public final class QueuePlayerListener implements Listener {
    private final QueueManager queueManager;

    public QueuePlayerListener(QueueManager queueManager) {
        this.queueManager = queueManager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.queueManager.leaveAllQuiet(event.getPlayer().getUniqueId());
    }
}
