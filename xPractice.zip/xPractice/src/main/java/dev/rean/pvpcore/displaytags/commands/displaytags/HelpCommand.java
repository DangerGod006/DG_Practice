package dev.rean.pvpcore.displaytags.commands.displaytags;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.commands.framework.CommandGroup;
import dev.rean.pvpcore.displaytags.commands.framework.Subcommand;
import org.bukkit.command.CommandSender;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/displaytags/HelpCommand.class */
public class HelpCommand extends Subcommand {
    public HelpCommand(DisplayTags plugin, CommandGroup parentCommand) {
        super(plugin, parentCommand);
        super.setName("help");
        super.setDescription("List available commands for the plugin.");
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.Subcommand
    public void execute(CommandSender sender, String[] args) {
        getParentCommand().sendSubcommands(sender);
    }
}
