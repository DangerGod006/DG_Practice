package dev.rean.pvpcore.displaytags.entities;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/entities/TextAlignment.class */
public enum TextAlignment {
    CENTER(0),
    LEFT(1),
    RIGHT(2);

    public final int value;

    TextAlignment(int value) {
        this.value = value;
    }
}
