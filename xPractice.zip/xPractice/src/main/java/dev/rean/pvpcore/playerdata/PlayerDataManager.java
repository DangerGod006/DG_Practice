package dev.rean.pvpcore.playerdata;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.gui.GenericGui;
import dev.rean.pvpcore.gui.GuiContext;
import dev.rean.pvpcore.gui.GuiKey;
import dev.rean.pvpcore.gui.GuiSession;
import dev.rean.pvpcore.kits.KitEditorManager;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/playerdata/PlayerDataManager.class */
public final class PlayerDataManager {
    private final PvPCorePlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap();
    private final Map<UUID, UUID> replies = new ConcurrentHashMap();
    private final File playerDataFolder;
    private final boolean hasPlaceholderApi;

    public PlayerDataManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
        this.playerDataFolder = new File(plugin.getDataFolder(), "playerdata");
        this.playerDataFolder.mkdirs();
        this.hasPlaceholderApi = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
    }

    public void load(Player player) {
        if (player == null) {
            return;
        }
        PlayerProfile profile = new PlayerProfile();
        File file = playerFile(player.getUniqueId());
        if (file.exists()) {
            YamlConfiguration data = YamlConfiguration.loadConfiguration(file);
            profile.setNickRaw(data.getString("profile.nick"));
            profile.setStatus(PlayerStatus.fromString(data.getString("profile.status")));
            profile.setDuelRequestsEnabled(data.getBoolean("settings.duel-requests-enabled", true));
            profile.setBlastParticlesEnabled(data.getBoolean("settings.blast-particles-enabled", true));
            profile.setTotemParticlesEnabled(data.getBoolean("settings.totem-particles-enabled", true));
            profile.setFastCrystalsEnabled(data.getBoolean("settings.fast-crystals-enabled", true));
            profile.setDirectMessagesEnabled(data.getBoolean("settings.direct-messages-enabled", true));
            profile.setShowOwnTier(data.getBoolean("settings.show-own-tier", true));
            profile.setProfileKitsPublic(data.getBoolean("settings.profile-kits-public", true));
            profile.setFriendRequestsEnabled(data.getBoolean("settings.friend-requests-enabled", true));
            profile.setFriendJoinNotifierEnabled(data.getBoolean("settings.friend-join-notifier-enabled", true));
            profile.setScoreboardEnabled(data.getBoolean("settings.scoreboard-enabled", true));
            profile.setDuelPopsEnabled(data.getBoolean("settings.duel-pops-enabled", true));
            profile.setTotemPops(data.getInt("stats.totem-pops", 0));
            profile.setFriends(readUuidList(data.getStringList("friends.list")));
            profile.setFriendNames(readUuidStringMap(data.getConfigurationSection("friends.names")));
            profile.setIncomingFriendRequests(readUuidList(data.getStringList("friends.requests.incoming")));
            profile.setOutgoingFriendRequests(readUuidList(data.getStringList("friends.requests.outgoing")));
            profile.setIncomingFriendRequestNames(readUuidStringMap(data.getConfigurationSection("friends.requests.incoming-names")));
            profile.setOutgoingFriendRequestNames(readUuidStringMap(data.getConfigurationSection("friends.requests.outgoing-names")));
        }
        this.profiles.put(player.getUniqueId(), profile);
        cleanupFriendRequestConflicts(player.getUniqueId(), profile);
        applyProfile(player, profile);
    }

    public void loadOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            load(player);
        }
    }

    public void save(Player player) {
        if (player == null) {
            return;
        }
        save(player.getUniqueId());
    }

    public void save(UUID uniqueId) {
        if (uniqueId == null) {
            return;
        }
        PlayerProfile profile = this.profiles.computeIfAbsent(uniqueId, ignored -> {
            return new PlayerProfile();
        });
        File file = playerFile(uniqueId);
        YamlConfiguration data = new YamlConfiguration();
        data.set("profile.nick", profile.nickRaw());
        data.set("profile.status", profile.status().name());
        data.set("settings.duel-requests-enabled", Boolean.valueOf(profile.duelRequestsEnabled()));
        data.set("settings.blast-particles-enabled", Boolean.valueOf(profile.blastParticlesEnabled()));
        data.set("settings.totem-particles-enabled", Boolean.valueOf(profile.totemParticlesEnabled()));
        data.set("settings.fast-crystals-enabled", Boolean.valueOf(profile.fastCrystalsEnabled()));
        data.set("settings.direct-messages-enabled", Boolean.valueOf(profile.directMessagesEnabled()));
        data.set("settings.show-own-tier", Boolean.valueOf(profile.showOwnTier()));
        data.set("settings.profile-kits-public", Boolean.valueOf(profile.profileKitsPublic()));
        data.set("settings.friend-requests-enabled", Boolean.valueOf(profile.friendRequestsEnabled()));
        data.set("settings.friend-join-notifier-enabled", Boolean.valueOf(profile.friendJoinNotifierEnabled()));
        data.set("settings.scoreboard-enabled", Boolean.valueOf(profile.scoreboardEnabled()));
        data.set("settings.duel-pops-enabled", Boolean.valueOf(profile.duelPopsEnabled()));
        data.set("stats.totem-pops", Integer.valueOf(profile.totemPops()));
        data.set("friends.list", writeUuidList(profile.friends()));
        writeUuidStringMap(data, "friends.names", profile.friendNames());
        data.set("friends.requests.incoming", writeUuidList(profile.incomingFriendRequests()));
        data.set("friends.requests.outgoing", writeUuidList(profile.outgoingFriendRequests()));
        writeUuidStringMap(data, "friends.requests.incoming-names", profile.incomingFriendRequestNames());
        writeUuidStringMap(data, "friends.requests.outgoing-names", profile.outgoingFriendRequestNames());
        try {
            data.save(file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Could not save playerdata for " + String.valueOf(uniqueId) + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        for (UUID uniqueId : this.profiles.keySet()) {
            save(uniqueId);
        }
    }

    public void unload(Player player) {
        if (player == null) {
            return;
        }
        save(player);
        this.replies.remove(player.getUniqueId());
    }

    public PlayerProfile profile(UUID uniqueId) {
        return this.profiles.computeIfAbsent(uniqueId, ignored -> {
            return new PlayerProfile();
        });
    }

    public boolean areDuelRequestsDisabled(UUID uniqueId) {
        return !canReceiveDuelRequests(uniqueId);
    }

    public boolean canReceiveDuelRequests(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        return profile.duelRequestsEnabled() && profile.status() != PlayerStatus.DND;
    }

    public boolean canReceiveDirectMessages(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        return profile.directMessagesEnabled() && profile.status() != PlayerStatus.DND;
    }

    public boolean isInvisible(UUID uniqueId) {
        return getStatus(uniqueId) == PlayerStatus.INVISIBLE;
    }

    public boolean isDoNotDisturb(UUID uniqueId) {
        return getStatus(uniqueId) == PlayerStatus.DND;
    }

    public boolean toggleDuelRequests(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setDuelRequestsEnabled(!profile.duelRequestsEnabled());
        save(uniqueId);
        return !canReceiveDuelRequests(uniqueId);
    }

    public void setDuelRequestsEnabled(UUID uniqueId, boolean enabled) {
        PlayerProfile profile = profile(uniqueId);
        profile.setDuelRequestsEnabled(enabled);
        save(uniqueId);
    }

    public boolean toggleBlastParticles(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setBlastParticlesEnabled(!profile.blastParticlesEnabled());
        save(uniqueId);
        return profile.blastParticlesEnabled();
    }

    public boolean toggleTotemParticles(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setTotemParticlesEnabled(!profile.totemParticlesEnabled());
        save(uniqueId);
        return profile.totemParticlesEnabled();
    }

    public boolean toggleFastCrystals(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setFastCrystalsEnabled(!profile.fastCrystalsEnabled());
        save(uniqueId);
        return profile.fastCrystalsEnabled();
    }

    public boolean toggleDirectMessages(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setDirectMessagesEnabled(!profile.directMessagesEnabled());
        save(uniqueId);
        return canReceiveDirectMessages(uniqueId);
    }

    public boolean toggleShowOwnTier(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setShowOwnTier(!profile.showOwnTier());
        save(uniqueId);
        return profile.showOwnTier();
    }

    public boolean toggleProfileKits(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setProfileKitsPublic(!profile.profileKitsPublic());
        save(uniqueId);
        return profile.profileKitsPublic();
    }

    public boolean toggleFriendRequests(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setFriendRequestsEnabled(!profile.friendRequestsEnabled());
        save(uniqueId);
        return profile.friendRequestsEnabled();
    }

    public boolean toggleFriendJoinNotifier(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setFriendJoinNotifierEnabled(!profile.friendJoinNotifierEnabled());
        save(uniqueId);
        return profile.friendJoinNotifierEnabled();
    }

    public boolean toggleDuelPops(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        profile.setDuelPopsEnabled(!profile.duelPopsEnabled());
        save(uniqueId);
        return profile.duelPopsEnabled();
    }

    public boolean hasDuelPopsEnabled(UUID uniqueId) {
        return profile(uniqueId).duelPopsEnabled();
    }

    public boolean toggleScoreboard(Player player) {
        PlayerProfile profile = profile(player.getUniqueId());
        profile.setScoreboardEnabled(!profile.scoreboardEnabled());
        applyScoreboard(player, profile.scoreboardEnabled());
        save(player);
        return profile.scoreboardEnabled();
    }

    public int totemPops(UUID uniqueId) {
        return profile(uniqueId).totemPops();
    }

    public String formattedTotemPops(UUID uniqueId) {
        return formatTotemPops(totemPops(uniqueId));
    }

    public String formatTotemPops(int pops) {
        if (pops <= 0) {
            return this.plugin.getConfig().getString("duels.totem-pops.empty", "");
        }
        String format = this.plugin.getConfig().getString("duels.totem-pops.format", "&7| &a-%pops%");
        return format == null ? "" : format.replace("%pops%", String.valueOf(pops));
    }

    public int incrementTotemPops(UUID uniqueId) {
        if (uniqueId == null) {
            return 0;
        }
        PlayerProfile profile = profile(uniqueId);
        int total = profile.incrementTotemPops();
        save(uniqueId);
        return total;
    }

    public boolean hasBlastParticlesEnabled(UUID uniqueId) {
        return profile(uniqueId).blastParticlesEnabled();
    }

    public boolean hasTotemParticlesEnabled(UUID uniqueId) {
        return profile(uniqueId).totemParticlesEnabled();
    }

    public boolean hasFastCrystalsEnabled(UUID uniqueId) {
        return profile(uniqueId).fastCrystalsEnabled();
    }

    public boolean hasScoreboardEnabled(UUID uniqueId) {
        return profile(uniqueId).scoreboardEnabled();
    }

    public boolean hasFriendJoinNotifierEnabled(UUID uniqueId) {
        return profile(uniqueId).friendJoinNotifierEnabled();
    }

    public boolean canReceiveFriendRequests(UUID uniqueId) {
        PlayerProfile profile = profile(uniqueId);
        return profile.friendRequestsEnabled() && profile.status() != PlayerStatus.DND;
    }

    public boolean showsOwnTier(UUID uniqueId) {
        return profile(uniqueId).showOwnTier();
    }

    public boolean areFriends(UUID first, UUID second) {
        if (first == null || second == null) {
            return false;
        }
        return profile(first).friends().contains(second);
    }

    public boolean hasIncomingFriendRequest(UUID receiver, UUID sender) {
        if (receiver == null || sender == null) {
            return false;
        }
        return profile(receiver).incomingFriendRequests().contains(sender);
    }

    public boolean hasOutgoingFriendRequest(UUID sender, UUID target) {
        if (sender == null || target == null) {
            return false;
        }
        return profile(sender).outgoingFriendRequests().contains(target);
    }

    public void addFriendRequest(UUID sender, String senderName, UUID target, String targetName) {
        if (sender == null || target == null || sender.equals(target) || areFriends(sender, target)) {
            return;
        }
        PlayerProfile senderProfile = profile(sender);
        PlayerProfile targetProfile = profile(target);
        senderProfile.addOutgoingFriendRequest(target, targetName);
        targetProfile.addIncomingFriendRequest(sender, senderName);
        save(sender);
        save(target);
    }

    public void removeFriendRequest(UUID sender, UUID target) {
        if (sender == null || target == null) {
            return;
        }
        profile(sender).removeOutgoingFriendRequest(target);
        profile(target).removeIncomingFriendRequest(sender);
        save(sender);
        save(target);
    }

    public void addFriendRelation(UUID owner, String ownerName, UUID friend, String friendName) {
        if (owner == null || friend == null || owner.equals(friend)) {
            return;
        }
        PlayerProfile ownerProfile = profile(owner);
        PlayerProfile friendProfile = profile(friend);
        ownerProfile.removeIncomingFriendRequest(friend);
        ownerProfile.removeOutgoingFriendRequest(friend);
        friendProfile.removeIncomingFriendRequest(owner);
        friendProfile.removeOutgoingFriendRequest(owner);
        ownerProfile.addFriend(friend, friendName);
        ownerProfile.setFriendName(friend, friendName);
        friendProfile.addFriend(owner, ownerName);
        friendProfile.setFriendName(owner, ownerName);
        save(owner);
        save(friend);
    }

    public void removeFriendRelation(UUID owner, UUID friend) {
        if (owner == null || friend == null) {
            return;
        }
        PlayerProfile ownerProfile = profile(owner);
        PlayerProfile friendProfile = profile(friend);
        ownerProfile.removeFriend(friend);
        friendProfile.removeFriend(owner);
        save(owner);
        save(friend);
    }

    public String getFriendDisplayName(UUID owner, UUID friend) {
        Player friendPlayer = Bukkit.getPlayer(friend);
        if (friendPlayer != null) {
            return getPlainDisplayName(friendPlayer);
        }
        String stored = profile(owner).friendName(friend);
        if (stored != null && !stored.isBlank()) {
            return stored;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(friend);
        return offlinePlayer.getName();
    }

    public String getIncomingFriendRequestName(UUID owner, UUID sender) {
        return resolveStoredName(profile(owner).incomingFriendRequestName(sender), sender);
    }

    public String getOutgoingFriendRequestName(UUID owner, UUID target) {
        return resolveStoredName(profile(owner).outgoingFriendRequestName(target), target);
    }

    public int friendCount(UUID owner) {
        return profile(owner).friends().size();
    }

    public int onlineFriendCount(UUID owner) {
        int count = 0;
        for (UUID friend : profile(owner).friends()) {
            Player online = Bukkit.getPlayer(friend);
            if (online != null && online.isOnline()) {
                count++;
            }
        }
        return count;
    }

    public int incomingFriendRequestCount(UUID owner) {
        return profile(owner).incomingFriendRequests().size();
    }

    public int outgoingFriendRequestCount(UUID owner) {
        return profile(owner).outgoingFriendRequests().size();
    }

    public PlayerStatus getStatus(UUID uniqueId) {
        return profile(uniqueId).status();
    }

    public void setStatus(Player player, PlayerStatus status) {
        PlayerProfile profile = profile(player.getUniqueId());
        profile.setStatus(status);
        applyProfile(player, profile);
        save(player);
        sendMiniMessage(player, "social.status-set", socialResolvers(player, profile, Map.of()));
    }

    public void cycleStatus(Player player) {
        setStatus(player, getStatus(player.getUniqueId()).next());
    }

    public String getNickRaw(UUID uniqueId) {
        return profile(uniqueId).nickRaw();
    }

    public Component getDisplayNameComponent(Player player) {
        String raw = getNickRaw(player.getUniqueId());
        return raw == null ? Component.text(player.getName()) : this.miniMessage.deserialize(raw);
    }

    public String getDisplayNameRaw(Player player) {
        String raw = getNickRaw(player.getUniqueId());
        return raw == null ? player.getName() : raw;
    }

    public String getPlainDisplayName(Player player) {
        return PlainTextComponentSerializer.plainText().serialize(getDisplayNameComponent(player));
    }

    public boolean setNick(Player player, String rawNick) {
        if (player == null || rawNick == null || rawNick.isBlank()) {
            if (player != null) {
                sendMiniMessage(player, "social.error-usage", socialResolvers(player, profile(player.getUniqueId()), Map.of()));
                return false;
            }
            return false;
        }
        String plain = PlainTextComponentSerializer.plainText().serialize(this.miniMessage.deserialize(rawNick));
        if (!plain.equalsIgnoreCase(player.getName())) {
            sendMiniMessage(player, "social.error-name", socialResolvers(player, profile(player.getUniqueId()), Map.of()));
            return false;
        }
        PlayerProfile profile = profile(player.getUniqueId());
        profile.setNickRaw(rawNick);
        applyProfile(player, profile);
        save(player);
        sendMiniMessage(player, "social.nick-set", socialResolvers(player, profile, Map.of()));
        return true;
    }

    public void clearNick(Player player) {
        if (player == null) {
            return;
        }
        PlayerProfile profile = profile(player.getUniqueId());
        profile.setNickRaw(null);
        applyProfile(player, profile);
        save(player);
        sendMiniMessage(player, "social.nick-removed", socialResolvers(player, profile, Map.of()));
    }

    public void sendPrivateMessage(Player sender, Player target, String message) {
        if (sender == null || target == null || message == null) {
            return;
        }
        if (!canReceiveDirectMessages(sender.getUniqueId())) {
            sendMiniMessage(sender, "social.dnd-self", socialResolvers(sender, profile(sender.getUniqueId()), Map.of()));
            return;
        }
        if (!canReceiveDirectMessages(target.getUniqueId())) {
            sendMiniMessage(sender, "social.dnd-target", socialResolvers(sender, profile(sender.getUniqueId()), Map.of("target_name", target.getName(), "target_display_name", getDisplayNameRaw(target))));
            return;
        }
        String message2 = message.replace("<", "&lt;").replace(">", "&gt;");
        String sentFormat = rawMessage("social.msg-sent", "<color:#84fce2>You</color> <color:#84fce2>→</color> <color:#27af91><target></color>: <white><message></white>");
        String recvFormat = rawMessage("social.msg-recv", "<color:#27af91><sender></color>: <color:#84fce2>→</color> <color:#84fce2>You</color> <white><message></white>");
        TagResolver sentResolver = TagResolver.resolver(new TagResolver[]{Placeholder.component("sender", getDisplayNameComponent(sender)), Placeholder.component("target", getDisplayNameComponent(target)), Placeholder.unparsed("message", message2)});
        TagResolver recvResolver = TagResolver.resolver(new TagResolver[]{Placeholder.component("sender", getDisplayNameComponent(sender)), Placeholder.component("target", getDisplayNameComponent(target)), Placeholder.unparsed("message", message2)});
        sender.sendMessage(this.miniMessage.deserialize(applyExternalPlaceholders(sender, sentFormat), sentResolver));
        target.sendMessage(this.miniMessage.deserialize(applyExternalPlaceholders(target, recvFormat), recvResolver));
        this.replies.put(sender.getUniqueId(), target.getUniqueId());
        this.replies.put(target.getUniqueId(), sender.getUniqueId());
    }

    public UUID lastReplyTarget(UUID uniqueId) {
        return this.replies.get(uniqueId);
    }

    public void openSettingsMenu(Player player) {
        if (player == null) {
            return;
        }
        GuiSession session = new GuiSession(GuiKey.CONFIGURABLE, player, player, null);
        session.setContext(GuiContext.SETTINGS);
        GenericGui.open(this.plugin, player, player, session, "settings-gui");
    }

    public Map<String, String> guiPlaceholders(Player player) {
        String str;
        String str2;
        String str3;
        String str4;
        if (player == null) {
            return Map.of();
        }
        PlayerProfile profile = profile(player.getUniqueId());
        Map<String, String> ph = new HashMap<>();
        ph.put("pvpcore_displayname", getPlainDisplayName(player));
        ph.put("pvpcore_displayname_raw", getDisplayNameRaw(player));
        ph.put("pvpcore_status", profile.status().colorCode());
        ph.put("pvpcore_status_name", profile.status().displayName());
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[profile.status().ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                str = "§a●";
                break;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                str = "§7⏺";
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                str = "§c⏺";
                break;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
        ph.put("pvpcore_status_icon", str);
        ph.put("pvpcore_friends_count", String.valueOf(friendCount(player.getUniqueId())));
        ph.put("pvpcore_friends_online", String.valueOf(onlineFriendCount(player.getUniqueId())));
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[profile.status().ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                str2 = "§a⏺ §fOnline";
                break;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                str2 = "§7⏺ §fInvisible";
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                str2 = "§c⏺ §fDo Not Disturb";
                break;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
        ph.put("pvpcore_status_item_name", str2);
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[profile.status().ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                str3 = "§7ℹ Displays your status and activity to friends";
                break;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                str3 = "§7ℹ Hides your name from tab-completion";
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                str3 = "§7ℹ Disables all messages, duel requests, and party invites";
                break;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
        ph.put("pvpcore_status_lore", str3);
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[profile.status().ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                str4 = "LIME_DYE";
                break;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                str4 = "GRAY_DYE";
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                str4 = "REDSTONE";
                break;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
        ph.put("pvpcore_status_material", str4);
        ph.put("pvpcore_duels_enabled", String.valueOf(profile.duelRequestsEnabled()));
        ph.put("pvpcore_duels_state", canReceiveDuelRequests(player.getUniqueId()) ? "§aAnyone" : "§cOFF");
        ph.put("pvpcore_blast_state", profile.blastParticlesEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_totem_state", profile.totemParticlesEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_fast_crystals_state", profile.fastCrystalsEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_dm_state", canReceiveDirectMessages(player.getUniqueId()) ? "§aAnyone" : "§cOFF");
        ph.put("pvpcore_show_own_tier_state", profile.showOwnTier() ? "§aON" : "§cOFF");
        ph.put("pvpcore_profile_kits_state", profile.profileKitsPublic() ? "§aPublic" : "§cPrivate");
        ph.put("pvpcore_friend_requests_state", profile.friendRequestsEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_friend_join_notifier_state", profile.friendJoinNotifierEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_scoreboard_state", profile.scoreboardEnabled() ? "§aON" : "§cOFF");
        ph.put("pvpcore_duel_pops_state", profile.duelPopsEnabled() ? "§aON" : "§cOFF");
        DuelMatch match = this.plugin.duelManager().getMatch(player.getUniqueId());
        String duelPops = match == null ? "" : match.formattedTotemPops(player.getUniqueId());
        String duelPopsRaw = match == null ? "0" : String.valueOf(match.totemPops(player.getUniqueId()));
        ph.put("pvpcore_pops", duelPops);
        ph.put("pvpcore_pops_raw", duelPopsRaw);
        ph.put("pvpcore_global_pops", formattedTotemPops(player.getUniqueId()));
        ph.put("pvpcore_global_pops_raw", String.valueOf(totemPops(player.getUniqueId())));
        ph.put("pvpcore_lifetime_pops", formattedTotemPops(player.getUniqueId()));
        ph.put("pvpcore_lifetime_pops_raw", String.valueOf(totemPops(player.getUniqueId())));
        ph.put("pvpcore_totem_pops", duelPops);
        ph.put("pvpcore_totem_pops_raw", duelPopsRaw);
        ph.put("pvpcore_duel_pops", duelPops);
        ph.put("pvpcore_duel_pops_raw", duelPopsRaw);
        ph.put("pvpcore_sneak_status", this.plugin.sneakStatus().status(player.getUniqueId()));
        ph.put("pvpcore_sneak_status_name", this.plugin.sneakStatus().statusName(player.getUniqueId()));
        ph.put("pvpcore_sneak_status_friends", String.valueOf(this.plugin.sneakStatus().isFriends(player.getUniqueId())));
        ph.put("pvpcore_spectating", String.valueOf(this.plugin.spectatorManager().isSpectating(player.getUniqueId())));
        ph.put("pvpcore_spectating_match_id", this.plugin.spectatorManager().spectatedMatchId(player.getUniqueId()));
        String stateIcon = this.plugin.spectatorManager().isSpectating(player.getUniqueId()) ? "§7👁" : this.plugin.duelManager().isInMatch(player.getUniqueId()) ? "§7⚔" : "§7🌲";
        String stateIconEmpty = this.plugin.spectatorManager().isSpectating(player.getUniqueId()) ? "§7👁" : this.plugin.duelManager().isInMatch(player.getUniqueId()) ? "§7⚔" : "";
        ph.put("pvpcore_state_icon", stateIcon);
        ph.put("pvpcore_player_state_icon", stateIcon);
        ph.put("pvpcore_duel_status_icon", stateIcon);
        ph.put("pvpcore_tab_status_icon", stateIcon);
        ph.put("pvpcore_state_icon_empty", stateIconEmpty);
        ph.put("pvpcore_player_state_icon_empty", stateIconEmpty);
        ph.put("pvpcore_duel_status_icon_empty", stateIconEmpty);
        ph.put("pvpcore_tab_status_icon_empty", stateIconEmpty);
        return ph;
    }

    /* JADX INFO: renamed from: dev.rean.pvpcore.playerdata.PlayerDataManager$1, reason: invalid class name */
    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/playerdata/PlayerDataManager$1.class */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus = new int[PlayerStatus.values().length];

        static {
            try {
                $SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[PlayerStatus.ONLINE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[PlayerStatus.INVISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$playerdata$PlayerStatus[PlayerStatus.DND.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public void refreshIdentity(Player player) {
        if (player == null) {
            return;
        }
        try {
            player.customName((Component) null);
            player.setCustomName((String) null);
            player.setCustomNameVisible(false);
        } catch (Throwable th) {
        }
        applyProfile(player, profile(player.getUniqueId()));
    }

    private void applyProfile(Player player, PlayerProfile profile) {
        TextComponent textComponentDeserialize;
        if (profile.nickRaw() == null) {
            textComponentDeserialize = Component.text(player.getName());
        } else {
            textComponentDeserialize = this.miniMessage.deserialize(profile.nickRaw());
        }
        TextComponent textComponent = textComponentDeserialize;
        player.displayName(textComponent);
        player.playerListName(textComponent);
        applyScoreboard(player, profile.scoreboardEnabled());
    }

    private void applyScoreboard(Player player, boolean enabled) {
        this.plugin.tabScoreboardHook().apply(player, enabled);
    }

    private File playerFile(UUID uniqueId) {
        return new File(this.playerDataFolder, String.valueOf(uniqueId) + ".yml");
    }

    private void sendMiniMessage(Player player, String path, TagResolver resolver) {
        if (player == null) {
            return;
        }
        String raw = rawMessage(path, "<red>Missing message: " + path + "</red>");
        player.sendMessage(this.miniMessage.deserialize(applyExternalPlaceholders(player, raw), resolver));
    }

    private TagResolver socialResolvers(Player player, PlayerProfile profile, Map<String, String> extra) {
        PlayerProfile resolved = profile == null ? new PlayerProfile() : profile;
        Map<String, String> values = new HashMap<>(extra);
        values.putIfAbsent("status_name", resolved.status().displayName());
        values.putIfAbsent("status_color", resolved.status().colorCode());
        String str = (player != null && canReceiveDuelRequests(player.getUniqueId())) ? "Enabled" : "Disabled";
        values.putIfAbsent("duels_state", str);
        TagResolver[] tagResolverArr = new TagResolver[7];
        tagResolverArr[0] = Placeholder.component("displayname", player == null ? Component.empty() : getDisplayNameComponent(player));
        tagResolverArr[1] = Placeholder.unparsed("displayname_raw", player == null ? "" : getDisplayNameRaw(player));
        tagResolverArr[2] = Placeholder.unparsed("status_name", values.getOrDefault("status_name", resolved.status().displayName()));
        tagResolverArr[3] = Placeholder.unparsed("status_color", values.getOrDefault("status_color", resolved.status().colorCode()));
        String str2 = (player != null && canReceiveDuelRequests(player.getUniqueId())) ? "Enabled" : "Disabled";
        tagResolverArr[4] = Placeholder.unparsed("duels_state", values.getOrDefault("duels_state", str2));
        tagResolverArr[5] = Placeholder.unparsed("target_name", values.getOrDefault("target_name", ""));
        tagResolverArr[6] = Placeholder.unparsed("target_display_name", values.getOrDefault("target_display_name", ""));
        return TagResolver.resolver(tagResolverArr);
    }

    private String rawMessage(String path, String def) {
        return this.plugin.messages().rawString(path, def);
    }

    private String applyExternalPlaceholders(Player player, String input) {
        if (!this.hasPlaceholderApi || player == null || input == null || input.isBlank()) {
            return input == null ? "" : input;
        }
        try {
            return PlaceholderAPI.setPlaceholders(player, input);
        } catch (Throwable th) {
            return input;
        }
    }

    private Set<UUID> readUuidList(List<String> input) {
        Set<UUID> out = new LinkedHashSet<>();
        if (input == null) {
            return out;
        }
        for (String raw : input) {
            if (raw != null && !raw.isBlank()) {
                try {
                    out.add(UUID.fromString(raw));
                } catch (IllegalArgumentException e) {
                }
            }
        }
        return out;
    }

    private List<String> writeUuidList(Collection<UUID> input) {
        List<String> out = new ArrayList<>();
        if (input == null) {
            return out;
        }
        for (UUID uuid : input) {
            if (uuid != null) {
                out.add(uuid.toString());
            }
        }
        return out;
    }

    private Map<UUID, String> readUuidStringMap(ConfigurationSection section) {
        Map<UUID, String> out = new LinkedHashMap<>();
        if (section == null) {
            return out;
        }
        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String value = section.getString(key, "");
                if (value != null && !value.isBlank()) {
                    out.put(uuid, value);
                }
            } catch (IllegalArgumentException e) {
            }
        }
        return out;
    }

    private void writeUuidStringMap(YamlConfiguration data, String path, Map<UUID, String> input) {
        if (input == null || input.isEmpty()) {
            return;
        }
        for (Map.Entry<UUID, String> entry : input.entrySet()) {
            if (entry.getKey() != null && entry.getValue() != null && !entry.getValue().isBlank()) {
                data.set(path + "." + String.valueOf(entry.getKey()), entry.getValue());
            }
        }
    }

    private void cleanupFriendRequestConflicts(UUID owner, PlayerProfile profile) {
        for (UUID friend : profile.friends()) {
            profile.removeIncomingFriendRequest(friend);
            profile.removeOutgoingFriendRequest(friend);
        }
        profile.removeIncomingFriendRequest(owner);
        profile.removeOutgoingFriendRequest(owner);
    }

    private String resolveStoredName(String stored, UUID uniqueId) {
        if (stored != null && !stored.isBlank()) {
            return stored;
        }
        Player online = Bukkit.getPlayer(uniqueId);
        if (online != null) {
            return getPlainDisplayName(online);
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(uniqueId);
        return offlinePlayer.getName() == null ? "Unknown" : offlinePlayer.getName();
    }
}
