package dev.rean.pvpcore.duel;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/duel/TeamColor.class */
public enum TeamColor {
    RED,
    BLUE
}
