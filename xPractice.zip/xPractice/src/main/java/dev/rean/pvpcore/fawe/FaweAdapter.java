package dev.rean.pvpcore.fawe;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.LocalSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.BukkitPlayer;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.world.World;
import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.util.ItemBuilder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/fawe/FaweAdapter.class */
public final class FaweAdapter {
    private final PvPCorePlugin plugin;

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/fawe/FaweAdapter$CaptureCallback.class */
    public interface CaptureCallback {
        void done(Location location, Location location2, String str, String str2);
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/fawe/FaweAdapter$RegionCallback.class */
    public interface RegionCallback {
        void done(Location location, Location location2, String str, String str2);
    }

    public FaweAdapter(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public ItemStack createRegenWand() {
        return new ItemBuilder(Material.BLAZE_ROD).name("&#22C55ERegen Wand&r").lore(List.of("&7Use WorldEdit selection, then:", "&f/arena regen set <id>")).build();
    }

    public void readSelectionAsync(Player p, RegionCallback cb) {
        Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
            try {
                Region region = getPlayerSelection(p);
                if (region == null) {
                    Bukkit.getScheduler().runTask(this.plugin, () -> {
                        cb.done(null, null, null, "No WorldEdit selection found.");
                    });
                    return;
                }
                World weWorld = region.getWorld();
                if (weWorld == null) {
                    Bukkit.getScheduler().runTask(this.plugin, () -> {
                        cb.done(null, null, null, "Selection has no world.");
                    });
                    return;
                }
                BlockVector3 min = region.getMinimumPoint();
                BlockVector3 max = region.getMaximumPoint();
                org.bukkit.World bw = Bukkit.getWorld(weWorld.getName());
                Location bMin = new Location(bw, min.getX(), min.getY(), min.getZ());
                Location bMax = new Location(bw, max.getX(), max.getY(), max.getZ());
                Bukkit.getScheduler().runTask(this.plugin, () -> {
                    cb.done(bMin, bMax, weWorld.getName(), null);
                });
            } catch (Throwable t) {
                Bukkit.getScheduler().runTask(this.plugin, () -> {
                    cb.done(null, null, null, t.getClass().getSimpleName() + ": " + t.getMessage());
                });
            }
        });
    }

    public void captureSelectionToSchematicAsync(Player p, File schematicFile, CaptureCallback cb) {
        Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
            try {
                Region region = getPlayerSelection(p);
                if (region == null) {
                    Bukkit.getScheduler().runTask(this.plugin, () -> {
                        cb.done(null, null, null, "No WorldEdit selection found.");
                    });
                    return;
                }
                World weWorld = region.getWorld();
                if (weWorld == null) {
                    Bukkit.getScheduler().runTask(this.plugin, () -> {
                        cb.done(null, null, null, "Selection has no world.");
                    });
                    return;
                }
                BlockVector3 min = region.getMinimumPoint();
                BlockVector3 max = region.getMaximumPoint();
                BlockArrayClipboard clipboard = new BlockArrayClipboard(region);
                EditSession editSession = WorldEdit.getInstance().newEditSession(weWorld);
                try {
                    ForwardExtentCopy forwardExtentCopy = new ForwardExtentCopy(editSession, region, clipboard, min);
                    Operations.complete(forwardExtentCopy);
                    if (editSession != null) {
                        editSession.close();
                    }
                    BuiltInClipboardFormat builtInClipboardFormatFindByFile = ClipboardFormats.findByFile(schematicFile);
                    if (builtInClipboardFormatFindByFile == null) {
                        builtInClipboardFormatFindByFile = BuiltInClipboardFormat.SPONGE_SCHEMATIC;
                    }
                    schematicFile.getParentFile().mkdirs();
                    ClipboardWriter writer = builtInClipboardFormatFindByFile.getWriter(new FileOutputStream(schematicFile));
                    try {
                        writer.write(clipboard);
                        if (writer != null) {
                            writer.close();
                        }
                        org.bukkit.World bw = Bukkit.getWorld(weWorld.getName());
                        Location bMin = new Location(bw, min.getX(), min.getY(), min.getZ());
                        Location bMax = new Location(bw, max.getX(), max.getY(), max.getZ());
                        Bukkit.getScheduler().runTask(this.plugin, () -> {
                            cb.done(bMin, bMax, weWorld.getName(), null);
                        });
                    } finally {
                    }
                } finally {
                }
            } catch (Throwable t) {
                Bukkit.getScheduler().runTask(this.plugin, () -> {
                    cb.done(null, null, null, t.getClass().getSimpleName() + ": " + t.getMessage());
                });
            }
        });
    }

    public void pasteSchematicAsync(File schematicFile, String worldName, Location pasteAt, Consumer<String> done) {
        Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
            try {
                org.bukkit.World bw = Bukkit.getWorld(worldName);
                if (bw == null) {
                    Bukkit.getScheduler().runTask(this.plugin, () -> {
                        done.accept("World not loaded: " + worldName);
                    });
                    return;
                }
                World weWorld = BukkitAdapter.adapt(bw);
                BuiltInClipboardFormat builtInClipboardFormatFindByFile = ClipboardFormats.findByFile(schematicFile);
                if (builtInClipboardFormatFindByFile == null) {
                    builtInClipboardFormatFindByFile = BuiltInClipboardFormat.SPONGE_SCHEMATIC;
                }
                ClipboardReader reader = builtInClipboardFormatFindByFile.getReader(new FileInputStream(schematicFile));
                try {
                    Clipboard clipboard = reader.read();
                    if (reader != null) {
                        reader.close();
                    }
                    BlockVector3 to = BlockVector3.at(pasteAt.getBlockX(), pasteAt.getBlockY(), pasteAt.getBlockZ());
                    EditSession editSession = WorldEdit.getInstance().newEditSession(weWorld);
                    try {
                        ForwardExtentCopy operation = new ForwardExtentCopy(clipboard, clipboard.getRegion(), clipboard.getOrigin(), editSession, to);
                        Operations.complete(operation);
                        if (editSession != null) {
                            editSession.close();
                        }
                        Bukkit.getScheduler().runTask(this.plugin, () -> {
                            done.accept(null);
                        });
                    } finally {
                    }
                } finally {
                }
            } catch (Throwable t) {
                Bukkit.getScheduler().runTask(this.plugin, () -> {
                    done.accept(t.getClass().getSimpleName() + ": " + t.getMessage());
                });
            }
        });
    }

    private Region getPlayerSelection(Player p) {
        Plugin we = Bukkit.getPluginManager().getPlugin("WorldEdit");
        if (!(we instanceof WorldEditPlugin)) {
            return null;
        }
        BukkitPlayer actor = BukkitAdapter.adapt(p);
        LocalSession session = WorldEdit.getInstance().getSessionManager().get(actor);
        try {
            return session.getSelection(session.getSelectionWorld());
        } catch (Exception e) {
            return null;
        }
    }
}
