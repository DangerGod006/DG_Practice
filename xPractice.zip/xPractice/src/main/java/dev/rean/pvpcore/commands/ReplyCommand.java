package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/ReplyCommand.class */
public final class ReplyCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public ReplyCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (!commandSender.hasPermission("pvpcore.msg")) {
            this.plugin.messages().send(commandSender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-msg-usage", Map.of());
            return true;
        }
        UUID replyTarget = this.plugin.playerData().lastReplyTarget(commandSender.getUniqueId());
        if (replyTarget == null) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-no-reply", Map.of());
            return true;
        }
        Player target = Bukkit.getPlayer(replyTarget);
        if (target == null || !target.isOnline()) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-player-not-found", Map.of());
            return true;
        }
        this.plugin.playerData().sendPrivateMessage(commandSender, target, String.join(" ", args));
        return true;
    }
}
