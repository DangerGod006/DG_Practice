package dev.rean.pvpcore.arenaeditor;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.kits.KitEditorManager;
import dev.rean.pvpcore.model.Arena;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorManager.class */
public final class ArenaEditorManager {
    private final PvPCorePlugin plugin;
    private final Map<UUID, Session> sessions = new HashMap();
    private int actionbarTaskId = -1;

    public ArenaEditorManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
        startActionbarTask();
    }

    public boolean isEditing(UUID playerId) {
        return this.sessions.containsKey(playerId);
    }

    public String currentArenaId(UUID playerId) {
        Session session = this.sessions.get(playerId);
        if (session == null) {
            return null;
        }
        return session.arenaId;
    }

    public ArenaEditorStep currentStep(UUID playerId) {
        Session session = this.sessions.get(playerId);
        if (session == null) {
            return null;
        }
        return session.step;
    }

    public boolean isRegionStep(UUID playerId) {
        ArenaEditorStep step = currentStep(playerId);
        return step != null && step.isRegionStep();
    }

    public void start(Player player, String arenaId) {
        if (player == null || arenaId == null || arenaId.isBlank()) {
            return;
        }
        Arena arena = this.plugin.arenaManager().get(arenaId);
        if (arena == null) {
            this.plugin.messages().send(player, "arenas.not-found");
            return;
        }
        Session session = this.sessions.computeIfAbsent(player.getUniqueId(), ignored -> {
            return new Session();
        });
        session.arenaId = arena.id();
        session.step = resolveSuggestedStep(arena);
        player.sendMessage(this.plugin.messages().format("&aYou entered arena setup mode for &f" + arena.id(), Map.of()));
        player.sendMessage(this.plugin.messages().format("&7Spawn-step controls: &fLeft click &7= previous, &fright click &7= next", Map.of()));
        player.sendMessage(this.plugin.messages().format("&7&fShift + left click &7= teleport, &fShift + right click &7= confirm", Map.of()));
        player.sendMessage(this.plugin.messages().format("&7Region-step controls: &fQ/F &7= previous/next, &fShift+Q &7= teleport, &fShift+F &7= confirm selection", Map.of()));
        player.sendMessage(this.plugin.messages().format("&7To exit: &f/arena editor stop", Map.of()));
        play(player, true, 1.1f);
        sendStatus(player, true);
    }

    public void stop(Player player, boolean notify) {
        if (player == null) {
            return;
        }
        Session removed = this.sessions.remove(player.getUniqueId());
        if (removed != null && notify) {
            player.sendMessage(this.plugin.messages().format("&cYou left arena setup mode.", Map.of()));
            play(player, false, 0.85f);
        }
    }

    public void stop(UUID playerId) {
        this.sessions.remove(playerId);
    }

    public void nextStep(Player player) {
        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }
        ArenaEditorStep[] values = ArenaEditorStep.values();
        int nextIndex = (session.step.ordinal() + 1) % values.length;
        session.step = values[nextIndex];
        sendStatus(player, true);
        play(player, true, 1.25f);
    }

    public void previousStep(Player player) {
        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }
        ArenaEditorStep[] values = ArenaEditorStep.values();
        int previousIndex = session.step.ordinal() - 1;
        if (previousIndex < 0) {
            previousIndex = values.length - 1;
        }
        session.step = values[previousIndex];
        sendStatus(player, true);
        play(player, true, 0.9f);
    }

    public void teleportCurrent(Player player) {
        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }
        Arena arena = this.plugin.arenaManager().get(session.arenaId);
        if (arena == null) {
            stop(player, false);
            this.plugin.messages().send(player, "arenas.not-found");
            return;
        }
        Location destination = session.step.teleportTarget(arena);
        if (destination == null || destination.getWorld() == null) {
            player.sendMessage(this.plugin.messages().format("&eThe step &f" + session.step.displayName() + " &edoes not have a saved location yet.", Map.of()));
            play(player, false, 0.7f);
            sendStatus(player, false);
        } else {
            player.teleport(destination.clone().add(0.5d, 0.0d, 0.5d));
            player.sendMessage(this.plugin.messages().format("&aTeleported to &f" + session.step.displayName() + " &afor arena &f" + arena.id(), Map.of()));
            play(player, true, 1.0f);
            sendStatus(player, false);
        }
    }

    public void confirmCurrent(Player player) {
        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
        }
        Arena arena = this.plugin.arenaManager().get(session.arenaId);
        if (arena == null) {
            stop(player, false);
            this.plugin.messages().send(player, "arenas.not-found");
            return;
        }
        switch (AnonymousClass1.$SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[session.step.ordinal()]) {
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                if (!this.plugin.arenaManager().setSpawnDirect(arena.id(), "red", player.getLocation())) {
                    this.plugin.messages().send(player, "arenas.not-found");
                    play(player, false, 0.7f);
                } else {
                    onConfirmSuccess(player, arena, "&aRed spawn saved.");
                }
                break;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                if (!this.plugin.arenaManager().setSpawnDirect(arena.id(), "blue", player.getLocation())) {
                    this.plugin.messages().send(player, "arenas.not-found");
                    play(player, false, 0.7f);
                } else {
                    onConfirmSuccess(player, arena, "&aBlue spawn saved.");
                }
                break;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                this.plugin.arenaManager().setRegenRegionFromSelection(player, arena.id(), error -> {
                    if (error != null) {
                        player.sendMessage(this.plugin.messages().format("&cCould not save the regen region: " + error, Map.of()));
                        play(player, false, 0.7f);
                        sendStatus(player, false);
                        return;
                    }
                    onConfirmSuccess(player, arena, "&aRegen region saved.");
                });
                break;
            case KitEditorManager.LEGGINGS_SLOT /* 4 */:
                this.plugin.arenaManager().setWallRegionFromSelection(player, arena.id(), "red", error2 -> {
                    if (error2 != null) {
                        player.sendMessage(this.plugin.messages().format("&cCould not save the red wall: " + error2, Map.of()));
                        play(player, false, 0.7f);
                        sendStatus(player, false);
                        return;
                    }
                    onConfirmSuccess(player, arena, "&aRed wall saved.");
                });
                break;
            case KitEditorManager.BOOTS_SLOT /* 5 */:
                this.plugin.arenaManager().setWallRegionFromSelection(player, arena.id(), "blue", error3 -> {
                    if (error3 != null) {
                        player.sendMessage(this.plugin.messages().format("&cCould not save the blue wall: " + error3, Map.of()));
                        play(player, false, 0.7f);
                        sendStatus(player, false);
                        return;
                    }
                    onConfirmSuccess(player, arena, "&aBlue wall saved.");
                });
                break;
            case KitEditorManager.OFFHAND_SLOT /* 6 */:
                this.plugin.arenaManager().setFinalWallRegionFromSelection(player, arena.id(), "red", error4 -> {
                    if (error4 != null) {
                        player.sendMessage(this.plugin.messages().format("&cCould not save the red final wall: " + error4, Map.of()));
                        play(player, false, 0.7f);
                        sendStatus(player, false);
                        return;
                    }
                    onConfirmSuccess(player, arena, "&aRed final wall saved.");
                });
                break;
            case KitEditorManager.SLOT_TOP_FILLER_RIGHT /* 7 */:
                this.plugin.arenaManager().setFinalWallRegionFromSelection(player, arena.id(), "blue", error5 -> {
                    if (error5 != null) {
                        player.sendMessage(this.plugin.messages().format("&cCould not save the blue final wall: " + error5, Map.of()));
                        play(player, false, 0.7f);
                        sendStatus(player, false);
                        return;
                    }
                    onConfirmSuccess(player, arena, "&aBlue final wall saved.");
                });
                break;
        }
    }

    /* JADX INFO: renamed from: dev.rean.pvpcore.arenaeditor.ArenaEditorManager$1, reason: invalid class name */
    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorManager$1.class */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep = new int[ArenaEditorStep.values().length];

        static {
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.RED_SPAWN.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.BLUE_SPAWN.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.REGEN.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.RED_WALL.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.BLUE_WALL.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.RED_FINAL_WALL.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$dev$rean$pvpcore$arenaeditor$ArenaEditorStep[ArenaEditorStep.BLUE_FINAL_WALL.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    public void sendStatus(Player player, boolean chatFeedback) {
        Session session;
        String str;
        if (player == null || (session = this.sessions.get(player.getUniqueId())) == null) {
            return;
        }
        Arena arena = this.plugin.arenaManager().get(session.arenaId);
        if (arena == null) {
            stop(player, false);
            return;
        }
        int missing = 0;
        for (ArenaEditorStep step : ArenaEditorStep.values()) {
            if (!step.isCompleted(arena)) {
                missing++;
            }
        }
        if (session.step.isSpawnStep()) {
            str = "&7LMB/RMB move &8• &7Shift+LMB teleport &8• &7Shift+RMB confirm";
        } else {
            str = "&7Q/F move &8• &7Shift+Q teleport &8• &7Shift+F confirm";
        }
        String controls = str;
        String actionbar = "&6Setup &8| &f" + arena.id() + " &8| &e" + session.step.displayName() + " &8| &7Missing: &f" + missing + " &8| " + controls;
        player.sendActionBar(this.plugin.messages().format(actionbar, Map.of()));
        if (chatFeedback) {
            player.sendMessage(this.plugin.messages().format("&eCurrent step: &f" + session.step.displayName() + " &8(&7" + (session.step.isCompleted(arena) ? "already configured" : "pending") + "&8)", Map.of()));
        }
    }

    private ArenaEditorStep resolveSuggestedStep(Arena arena) {
        if (arena == null) {
            return ArenaEditorStep.RED_SPAWN;
        }
        for (ArenaEditorStep step : ArenaEditorStep.values()) {
            if (!step.isCompleted(arena)) {
                return step;
            }
        }
        return ArenaEditorStep.RED_SPAWN;
    }

    private void onConfirmSuccess(Player player, Arena arena, String message) {
        player.sendMessage(this.plugin.messages().format(message, Map.of()));
        play(player, true, 1.35f);
        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }
        ArenaEditorStep suggested = resolveSuggestedStep(arena);
        boolean completedAll = suggested == ArenaEditorStep.RED_SPAWN && allStepsCompleted(arena);
        if (completedAll) {
            player.sendMessage(this.plugin.messages().format("&aArena &f" + arena.id() + " &ais ready. Leaving setup mode.", Map.of()));
            stop(player, false);
            player.sendActionBar(this.plugin.messages().format("&aArena ready: &f" + arena.id(), Map.of()));
        } else {
            session.step = suggested;
            sendStatus(player, true);
        }
    }

    private boolean allStepsCompleted(Arena arena) {
        for (ArenaEditorStep step : ArenaEditorStep.values()) {
            if (!step.isCompleted(arena)) {
                return false;
            }
        }
        return true;
    }

    private void startActionbarTask() {
        this.actionbarTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, () -> {
            if (this.sessions.isEmpty()) {
                return;
            }
            for (UUID playerId : this.sessions.keySet().stream().toList()) {
                Player player = Bukkit.getPlayer(playerId);
                if (player == null || !player.isOnline()) {
                    this.sessions.remove(playerId);
                } else {
                    sendStatus(player, false);
                }
            }
        }, 20L, 20L);
    }

    private void play(Player player, boolean success, float pitch) {
        Sound sound = success ? Sound.BLOCK_WOODEN_BUTTON_CLICK_ON : Sound.BLOCK_NOTE_BLOCK_BASS;
        player.playSound(player.getLocation(), sound, 0.85f, pitch);
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorManager$Session.class */
    private static final class Session {
        private String arenaId;
        private ArenaEditorStep step = ArenaEditorStep.RED_SPAWN;

        private Session() {
        }
    }
}
