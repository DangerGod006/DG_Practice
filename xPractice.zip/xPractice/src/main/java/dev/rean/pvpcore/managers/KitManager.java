package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.ItemSerialization;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/KitManager.class */
public final class KitManager {
    private final PvPCorePlugin plugin;
    private final Settings settings;
    private final MessageManager messages;
    private final Map<String, Kit> kits = new LinkedHashMap();
    private final Map<UUID, Map<String, PersonalKitData>> personalKits = new HashMap();
    private final File file;
    private final File personalFile;
    private YamlConfiguration cfg;
    private YamlConfiguration personalCfg;

    public KitManager(PvPCorePlugin plugin, Settings settings, MessageManager messages) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
        this.personalFile = new File(plugin.getDataFolder(), "player-kits.yml");
    }

    public void load() {
        String singleInfo;
        String singleHiddenTag;
        String singleExplodeBlocks;
        String singleBreakBlocks;
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.kits.clear();
        ConfigurationSection sec = this.cfg.getConfigurationSection("kits");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                String path = "kits." + id + ".";
                String name = this.cfg.getString(path + "displayName", id);
                Kit k = new Kit(id, name);
                String inv = this.cfg.getString(path + "inventory", (String) null);
                if (inv != null) {
                    ItemSerialization.InventoryData data = ItemSerialization.deserialize(inv);
                    k.setInventory(data.contents(), data.armor(), data.offhand());
                }
                String icon = this.cfg.getString(path + "icon", (String) null);
                if (icon != null) {
                    ItemSerialization.InventoryData iconData = ItemSerialization.deserialize(icon);
                    if (iconData.contents().length > 0) {
                        k.setIcon(iconData.contents()[0]);
                    }
                }
                k.setNaturalRegen(this.cfg.getBoolean(path + "attributes.naturalRegen", true));
                k.setNaturalSaturationDecrease(this.cfg.getBoolean(path + "attributes.naturalSaturationDecrease", true));
                k.setConsoleCommand(this.cfg.getString(path + "attributes.consoleCommand", (String) null));
                k.setGameMode(parseKitGameMode(this.cfg.getString(path + "attributes.gamemode", this.cfg.getString(path + "attributes.gameMode", "survival"))));
                List<String> breakBlocks = this.cfg.getStringList(path + "attributes.break-blocks");
                if (breakBlocks.isEmpty() && (singleBreakBlocks = this.cfg.getString(path + "attributes.break-blocks", this.cfg.getString(path + "attributes.breakBlocks", (String) null))) != null && !singleBreakBlocks.isBlank()) {
                    breakBlocks = Arrays.stream(singleBreakBlocks.split(",")).map((v0) -> {
                        return v0.trim();
                    }).filter(part -> {
                        return !part.isEmpty();
                    }).toList();
                }
                k.setBreakBlocks(breakBlocks);
                List<String> explodeBlocks = this.cfg.getStringList(path + "attributes.explode-blocks");
                if (explodeBlocks.isEmpty() && (singleExplodeBlocks = this.cfg.getString(path + "attributes.explode-blocks", this.cfg.getString(path + "attributes.explodeBlocks", (String) null))) != null && !singleExplodeBlocks.isBlank()) {
                    explodeBlocks = Arrays.stream(singleExplodeBlocks.split(",")).map((v0) -> {
                        return v0.trim();
                    }).filter(part2 -> {
                        return !part2.isEmpty();
                    }).toList();
                }
                k.setExplodeBlocks(explodeBlocks);
                List<String> hiddenTags = this.cfg.getStringList(path + "attributes.hideTag");
                if (hiddenTags.isEmpty() && (singleHiddenTag = this.cfg.getString(path + "attributes.hideTag", (String) null)) != null && !singleHiddenTag.isBlank()) {
                    hiddenTags = Arrays.stream(singleHiddenTag.split(",")).map((v0) -> {
                        return v0.trim();
                    }).filter(part3 -> {
                        return !part3.isEmpty();
                    }).toList();
                }
                k.setHiddenTags(hiddenTags);
                List<String> summaryInfo = this.cfg.getStringList(path + "attributes.info");
                if (summaryInfo.isEmpty() && (singleInfo = this.cfg.getString(path + "attributes.info", (String) null)) != null && !singleInfo.isBlank()) {
                    summaryInfo = Arrays.stream(singleInfo.split(",")).map((v0) -> {
                        return v0.trim();
                    }).filter(part4 -> {
                        return !part4.isEmpty();
                    }).toList();
                }
                k.setSummaryInfo(summaryInfo);
                this.kits.put(k.id(), k);
            }
        }
        loadPersonalKits();
    }

    private void loadPersonalKits() {
        this.personalCfg = YamlConfiguration.loadConfiguration(this.personalFile);
        this.personalKits.clear();
        ConfigurationSection players = this.personalCfg.getConfigurationSection("players");
        if (players == null) {
            return;
        }
        for (String rawUuid : players.getKeys(false)) {
            try {
                UUID playerId = UUID.fromString(rawUuid);
                ConfigurationSection kitsSection = players.getConfigurationSection(rawUuid + ".kits");
                if (kitsSection != null) {
                    Map<String, PersonalKitData> perPlayer = new HashMap<>();
                    for (String kitId : kitsSection.getKeys(false)) {
                        String basePath = "players." + rawUuid + ".kits." + kitId + ".";
                        String serialized = this.personalCfg.getString(basePath + "inventory", (String) null);
                        if (serialized != null && !serialized.isBlank()) {
                            try {
                                ItemSerialization.InventoryData data = ItemSerialization.deserialize(serialized);
                                perPlayer.put(kitId.toLowerCase(Locale.ROOT), new PersonalKitData(data.contents(), data.offhand()));
                            } catch (RuntimeException e) {
                            }
                        }
                    }
                    if (!perPlayer.isEmpty()) {
                        this.personalKits.put(playerId, perPlayer);
                    }
                }
            } catch (IllegalArgumentException e2) {
            }
        }
    }

    public void save() {
        this.cfg = new YamlConfiguration();
        this.cfg.createSection("kits");
        for (Kit k : this.kits.values()) {
            String path = "kits." + k.id() + ".";
            this.cfg.set(path + "displayName", k.displayName());
            if (k.contents() != null) {
                String serialized = ItemSerialization.serialize(k.contents(), k.armor(), k.offhand());
                this.cfg.set(path + "inventory", serialized);
            }
            if (k.icon() != null) {
                String iconSer = ItemSerialization.serialize(new ItemStack[]{k.icon()}, new ItemStack[0], null);
                this.cfg.set(path + "icon", iconSer);
            }
            this.cfg.set(path + "attributes.naturalRegen", Boolean.valueOf(k.naturalRegen()));
            this.cfg.set(path + "attributes.naturalSaturationDecrease", Boolean.valueOf(k.naturalSaturationDecrease()));
            this.cfg.set(path + "attributes.consoleCommand", k.consoleCommand());
            this.cfg.set(path + "attributes.gamemode", k.gameMode().name().toLowerCase(Locale.ROOT));
            this.cfg.set(path + "attributes.break-blocks", k.breakBlocks().stream().map((v0) -> {
                return v0.name();
            }).toList());
            this.cfg.set(path + "attributes.explode-blocks", k.explodeBlocks().stream().map((v0) -> {
                return v0.name();
            }).toList());
            this.cfg.set(path + "attributes.hideTag", new ArrayList(k.hiddenTags()));
            this.cfg.set(path + "attributes.info", new ArrayList(k.summaryInfo()));
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().severe("Failed to save kits.yml: " + e.getMessage());
        }
    }

    private void savePersonalKits() {
        this.personalCfg = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, PersonalKitData>> playerEntry : this.personalKits.entrySet()) {
            String playerPath = "players." + String.valueOf(playerEntry.getKey()) + ".kits.";
            for (Map.Entry<String, PersonalKitData> kitEntry : playerEntry.getValue().entrySet()) {
                PersonalKitData data = kitEntry.getValue();
                String serialized = ItemSerialization.serialize(data.contents(), new ItemStack[0], data.offhand());
                this.personalCfg.set(playerPath + kitEntry.getKey() + ".inventory", serialized);
            }
        }
        try {
            this.personalCfg.save(this.personalFile);
        } catch (IOException e) {
            this.plugin.getLogger().severe("Failed to save player-kits.yml: " + e.getMessage());
        }
    }

    public Kit get(String id) {
        if (id == null) {
            return null;
        }
        return this.kits.get(id.toLowerCase(Locale.ROOT));
    }

    public Kit getEffectiveKit(UUID playerId, String kitId) {
        return getEffectiveKit(playerId, get(kitId));
    }

    public Kit getEditableKit(UUID playerId, String kitId) {
        return getEffectiveKit(playerId, get(kitId));
    }

    public Kit getEffectiveKit(UUID playerId, Kit baseKit) {
        PersonalKitData personal;
        if (baseKit == null) {
            return null;
        }
        Kit copy = copyOf(baseKit);
        if (playerId != null && (personal = personalData(playerId, baseKit.id())) != null) {
            copy.setInventory(personal.contents(), baseKit.armor(), personal.offhand());
            return copy;
        }
        return copy;
    }

    private PersonalKitData personalData(UUID playerId, String kitId) {
        Map<String, PersonalKitData> playerMap = this.personalKits.get(playerId);
        if (playerMap == null || kitId == null) {
            return null;
        }
        return playerMap.get(kitId.toLowerCase(Locale.ROOT));
    }

    private Kit copyOf(Kit original) {
        Kit copy = new Kit(original.id(), original.displayName());
        copy.setInventory(original.contents(), original.armor(), original.offhand());
        copy.setIcon(original.icon());
        copy.setNaturalRegen(original.naturalRegen());
        copy.setNaturalSaturationDecrease(original.naturalSaturationDecrease());
        copy.setConsoleCommand(original.consoleCommand());
        copy.setGameMode(original.gameMode());
        copy.setBreakBlocksFromMaterials(original.breakBlocks());
        copy.setHiddenTags(original.hiddenTags());
        copy.setSummaryInfo(original.summaryInfo());
        return copy;
    }

    public void setIconFromHand(Player p, String id) {
        Kit kit = this.kits.get(id.toLowerCase(Locale.ROOT));
        if (kit == null) {
            this.plugin.messages().send(p, "kits.not-found");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            this.plugin.messages().send(p, "kits.seticon-empty-hand");
            return;
        }
        kit.setIcon(hand);
        save();
        this.plugin.messages().send(p, "kits.seticon", Map.of("id", kit.id(), "name", kit.displayName()));
    }

    public List<Kit> list() {
        return new ArrayList(this.kits.values());
    }

    public Kit getFirstOrNull() {
        return this.kits.values().stream().findFirst().orElse(null);
    }

    public void saveEditedInventory(UUID playerId, String id, ItemStack[] contents, ItemStack offhand) {
        Kit baseKit = get(id);
        if (playerId == null || baseKit == null) {
            return;
        }
        int contentSize = contents == null ? 36 : Math.max(36, contents.length);
        ItemStack[] clonedContents = cloneContents(contents, contentSize);
        ItemStack clonedOffhand = offhand == null ? null : offhand.clone();
        this.personalKits.computeIfAbsent(playerId, ignored -> {
            return new HashMap();
        }).put(baseKit.id(), new PersonalKitData(clonedContents, clonedOffhand));
        savePersonalKits();
    }

    public void saveEditedInventory(String id, ItemStack[] contents, ItemStack offhand) {
        Kit kit = get(id);
        if (kit == null) {
            return;
        }
        int contentSize = contents == null ? 36 : Math.max(36, contents.length);
        kit.setInventory(cloneContents(contents, contentSize), kit.armor(), offhand == null ? null : offhand.clone());
        save();
    }

    public void saveEditedInventory(Player player, String id) {
        if (player == null) {
            return;
        }
        saveEditedInventory(player.getUniqueId(), id, player.getInventory().getStorageContents(), player.getInventory().getItemInOffHand());
    }

    private ItemStack[] cloneContents(ItemStack[] contents, int size) {
        ItemStack[] clonedContents = new ItemStack[size];
        int i = 0;
        while (i < size) {
            ItemStack item = (contents == null || i >= contents.length) ? null : contents[i];
            clonedContents[i] = item == null ? null : item.clone();
            i++;
        }
        return clonedContents;
    }

    public boolean resetPersonalKit(UUID playerId, String kitId) {
        Map<String, PersonalKitData> playerMap;
        if (playerId == null || kitId == null || (playerMap = this.personalKits.get(playerId)) == null) {
            return false;
        }
        boolean removed = playerMap.remove(kitId.toLowerCase(Locale.ROOT)) != null;
        if (playerMap.isEmpty()) {
            this.personalKits.remove(playerId);
        }
        if (removed) {
            savePersonalKits();
        }
        return removed;
    }

    public void createFromPlayer(Player p, String id, String displayName) {
        Kit k = new Kit(id, displayName);
        PlayerInventory inv = p.getInventory();
        k.setInventory(inv.getStorageContents(), inv.getArmorContents(), inv.getItemInOffHand());
        ItemStack icon = inv.getItemInMainHand();
        if (icon == null || icon.getType().isAir()) {
            icon = new ItemStack(Material.END_CRYSTAL);
        }
        k.setIcon(icon);
        this.kits.put(k.id(), k);
        save();
        this.messages.send(p, "kits.created", Map.of("id", k.id(), "name", k.displayName()));
    }

    public void updateFromPlayer(Player p, String id) {
        Kit k = get(id);
        if (k == null) {
            this.messages.send(p, "kits.not-found");
            return;
        }
        PlayerInventory inv = p.getInventory();
        k.setInventory(inv.getStorageContents(), inv.getArmorContents(), inv.getItemInOffHand());
        ItemStack icon = inv.getItemInMainHand();
        if (icon == null || icon.getType().isAir()) {
            icon = new ItemStack(Material.END_CRYSTAL);
        }
        k.setIcon(icon);
        save();
        this.messages.send(p, "kits.updated", Map.of("id", k.id()));
    }

    public boolean setBooleanAttribute(String id, String attribute, boolean value) {
        Kit kit = get(id);
        if (kit == null) {
            return false;
        }
        if (attribute.equalsIgnoreCase("naturalRegen")) {
            kit.setNaturalRegen(value);
        } else if (attribute.equalsIgnoreCase("naturalSaturationDecrease")) {
            kit.setNaturalSaturationDecrease(value);
        } else {
            return false;
        }
        save();
        return true;
    }

    public boolean setStringAttribute(String id, String attribute, String value) {
        List<String> breakBlocks;
        List<String> explodeBlocks;
        List<String> summaryInfo;
        List<String> hiddenTags;
        Kit kit = get(id);
        if (kit == null) {
            return false;
        }
        if (attribute.equalsIgnoreCase("consoleCommand")) {
            if (value != null && (value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null") || value.equals("-"))) {
                value = null;
            }
            kit.setConsoleCommand(value);
        } else if (attribute.equalsIgnoreCase("hideTag")) {
            if (value == null || value.isBlank() || value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null") || value.equals("-")) {
                hiddenTags = List.of();
            } else {
                hiddenTags = Arrays.stream(value.split(",")).map((v0) -> {
                    return v0.trim();
                }).filter(part -> {
                    return !part.isEmpty();
                }).toList();
            }
            kit.setHiddenTags(hiddenTags);
        } else if (attribute.equalsIgnoreCase("info")) {
            if (value == null || value.isBlank() || value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null") || value.equals("-")) {
                summaryInfo = List.of();
            } else {
                summaryInfo = Arrays.stream(value.split(",")).map((v0) -> {
                    return v0.trim();
                }).filter(part2 -> {
                    return !part2.isEmpty();
                }).toList();
            }
            kit.setSummaryInfo(summaryInfo);
        } else if (attribute.equalsIgnoreCase("gamemode") || attribute.equalsIgnoreCase("gameMode")) {
            GameMode gameMode = parseKitGameMode(value);
            kit.setGameMode(gameMode);
        } else if (attribute.equalsIgnoreCase("break-blocks") || attribute.equalsIgnoreCase("breakBlocks")) {
            if (value == null || value.isBlank() || value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null") || value.equals("-")) {
                breakBlocks = List.of();
            } else {
                breakBlocks = Arrays.stream(value.split(",")).map((v0) -> {
                    return v0.trim();
                }).filter(part3 -> {
                    return !part3.isEmpty();
                }).toList();
            }
            kit.setBreakBlocks(breakBlocks);
        } else if (attribute.equalsIgnoreCase("explode-blocks") || attribute.equalsIgnoreCase("explodeBlocks")) {
            if (value == null || value.isBlank() || value.equalsIgnoreCase("clear") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null") || value.equals("-")) {
                explodeBlocks = List.of();
            } else {
                explodeBlocks = Arrays.stream(value.split(",")).map((v0) -> {
                    return v0.trim();
                }).filter(part4 -> {
                    return !part4.isEmpty();
                }).toList();
            }
            kit.setExplodeBlocks(explodeBlocks);
        } else {
            return false;
        }
        save();
        return true;
    }

    private GameMode parseKitGameMode(String raw) {
        if (raw == null || raw.isBlank()) {
            return GameMode.SURVIVAL;
        }
        String normalized = raw.trim().toUpperCase(Locale.ROOT).replace('-', '_');
        try {
            GameMode gameMode = GameMode.valueOf(normalized);
            return gameMode == GameMode.ADVENTURE ? GameMode.ADVENTURE : GameMode.SURVIVAL;
        } catch (IllegalArgumentException e) {
            return GameMode.SURVIVAL;
        }
    }

    public void remove(Player p, String id) {
        Kit k = this.kits.remove(id.toLowerCase(Locale.ROOT));
        if (k == null) {
            this.messages.send(p, "kits.not-found");
            return;
        }
        for (Map<String, PersonalKitData> playerKits : this.personalKits.values()) {
            playerKits.remove(k.id());
        }
        this.personalKits.entrySet().removeIf(entry -> {
            return ((Map) entry.getValue()).isEmpty();
        });
        save();
        savePersonalKits();
        this.messages.send(p, "kits.removed", Map.of("id", k.id()));
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/KitManager$PersonalKitData.class */
    private static final class PersonalKitData extends Record {
        private final ItemStack[] contents;
        private final ItemStack offhand;

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, PersonalKitData.class), PersonalKitData.class, "contents;offhand", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, PersonalKitData.class), PersonalKitData.class, "contents;offhand", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, PersonalKitData.class, Object.class), PersonalKitData.class, "contents;offhand", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->contents:[Lorg/bukkit/inventory/ItemStack;", "FIELD:Ldev/rean/pvpcore/managers/KitManager$PersonalKitData;->offhand:Lorg/bukkit/inventory/ItemStack;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        private PersonalKitData(ItemStack[] contents, ItemStack offhand) {
            this.contents = contents == null ? new ItemStack[36] : cloneArray(contents);
            this.offhand = offhand == null ? null : offhand.clone();
        }

        private static ItemStack[] cloneArray(ItemStack[] source) {
            ItemStack[] copy = new ItemStack[source.length];
            for (int i = 0; i < source.length; i++) {
                copy[i] = source[i] == null ? null : source[i].clone();
            }
            return copy;
        }

        public ItemStack[] contents() {
            return cloneArray(this.contents);
        }

        public ItemStack offhand() {
            if (this.offhand == null) {
                return null;
            }
            return this.offhand.clone();
        }
    }
}
