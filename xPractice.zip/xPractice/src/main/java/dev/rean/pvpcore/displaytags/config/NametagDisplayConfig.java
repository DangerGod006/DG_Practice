package dev.rean.pvpcore.displaytags.config;

import dev.rean.pvpcore.displaytags.entities.DisplayBillboard;
import dev.rean.pvpcore.displaytags.entities.TextAlignment;
import java.util.List;
import org.bukkit.Color;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/config/NametagDisplayConfig.class */
public class NametagDisplayConfig {
    private final String id;
    private final boolean enabled;
    private final List<String> lines;
    private final boolean textShadow;
    private final boolean seeThrough;
    private final TextAlignment textAlignment;
    private final String background;
    private final DisplayBillboard billboard;
    private final Vector scale;
    private final Vector translation;

    public NametagDisplayConfig(String id, boolean enabled, List<String> lines, boolean textShadow, boolean seeThrough, TextAlignment textAlignment, String background, DisplayBillboard billboard, Vector scale, Vector translation) {
        this.id = id;
        this.enabled = enabled;
        this.lines = List.copyOf(lines);
        this.textShadow = textShadow;
        this.seeThrough = seeThrough;
        this.textAlignment = textAlignment;
        this.background = background;
        this.billboard = billboard;
        this.scale = scale.clone();
        this.translation = translation.clone();
    }

    public String getId() {
        return this.id;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public List<String> getLines() {
        return this.lines;
    }

    public boolean hasTextShadow() {
        return this.textShadow;
    }

    public boolean isSeeThrough() {
        return this.seeThrough;
    }

    public TextAlignment getTextAlignment() {
        return this.textAlignment;
    }

    public String getBackground() {
        return this.background;
    }

    public DisplayBillboard getBillboard() {
        return this.billboard;
    }

    public Vector getScale() {
        return this.scale.clone();
    }

    public Vector getTranslation() {
        return this.translation.clone();
    }

    public int getBackgroundColor() {
        String parsedBackground = this.background;
        if (parsedBackground == null || parsedBackground.equalsIgnoreCase("default")) {
            return -1;
        }
        if (parsedBackground.equalsIgnoreCase("transparent")) {
            return 0;
        }
        if (parsedBackground.startsWith("#")) {
            parsedBackground = parsedBackground.substring(1);
        }
        Color color = Color.fromARGB((int) Long.parseLong(parsedBackground, 16));
        if (parsedBackground.length() == 6) {
            color = color.setAlpha(255);
        }
        return color.asARGB();
    }
}
