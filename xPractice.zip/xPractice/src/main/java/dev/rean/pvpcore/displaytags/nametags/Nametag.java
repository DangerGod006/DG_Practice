package dev.rean.pvpcore.displaytags.nametags;

import com.github.retrooper.packetevents.util.Vector3f;
import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.config.NametagConfig;
import dev.rean.pvpcore.displaytags.config.TagDisplayConfig;
import dev.rean.pvpcore.displaytags.entities.ClientTextDisplay;
import dev.rean.pvpcore.displaytags.entities.DisplayBillboard;
import dev.rean.pvpcore.displaytags.entities.TextAlignment;
import dev.rean.pvpcore.displaytags.utils.ComponentUtils;
import dev.rean.pvpcore.displaytags.utils.handlers.NametagHandler;
import dev.rean.pvpcore.displaytags.utils.helpers.DependencyHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/nametags/Nametag.class */
public class Nametag {
    private final Player player;
    private final boolean hideSelf;
    private final int visibilityDistance;
    private final int deathVisibleTicks;
    private final Set<String> forcedVisibleTagIds;
    private final Set<String> forcedHiddenTagIds;
    private long deathVisibleUntilTick;
    private TemporaryTag temporarySpectatorTag;
    private final DisplayTags plugin = DisplayTags.getInstance();
    private final Set<UUID> viewers = new HashSet();
    private final List<TagRuntime> displays = new ArrayList();

    public Nametag(Player player, Set<String> forcedVisibleTagIds, Set<String> forcedHiddenTagIds) {
        this.player = player;
        NametagConfig config = this.plugin.config().getNametagConfig();
        this.hideSelf = config.shouldHideSelf();
        this.visibilityDistance = config.getVisibilityDistance();
        this.deathVisibleTicks = config.getDeathVisibleTicks();
        this.forcedVisibleTagIds = forcedVisibleTagIds == null ? Collections.emptySet() : new LinkedHashSet<>(forcedVisibleTagIds);
        this.forcedHiddenTagIds = forcedHiddenTagIds == null ? Collections.emptySet() : new LinkedHashSet<>(forcedHiddenTagIds);
        int stackIndex = 0;
        for (TagDisplayConfig displayConfig : config.getDisplays()) {
            if (shouldLoadDisplay(displayConfig)) {
                int i = stackIndex;
                stackIndex++;
                this.displays.add(createDisplay(displayConfig, i));
            }
        }
    }

    public Player getPlayer() {
        return this.player;
    }

    public void markDeathVisible() {
        this.deathVisibleUntilTick = Bukkit.getCurrentTick() + this.deathVisibleTicks;
    }

    public boolean isWithinDeathVisibilityWindow() {
        return this.deathVisibleUntilTick > ((long) Bukkit.getCurrentTick());
    }

    public void hideForAll() {
        removeTemporarySpectatorTag();
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            hide(viewer);
        }
    }

    public void updateVisibilityForAll() {
        Location baseLocation = this.player.getLocation().clone().setRotation(0.0f, 0.0f);
        for (TagRuntime runtime : this.displays) {
            runtime.cachedText = getText(runtime.lines);
            runtime.display.setLocation(baseLocation);
        }
        this.viewers.removeIf(uuid -> {
            Player viewer = Bukkit.getPlayer(uuid);
            return viewer == null || !viewer.isOnline();
        });
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            boolean shouldSee = shouldSee(viewer);
            boolean isVisible = this.viewers.contains(viewer.getUniqueId());
            if (shouldSee) {
                if (isVisible) {
                    update(viewer);
                } else {
                    show(viewer);
                }
            } else if (isVisible) {
                hide(viewer);
            }
        }
    }

    private boolean shouldSee(Player viewer) {
        if (viewer == null || !viewer.isOnline() || viewer.isDead()) {
            return false;
        }
        if ((this.hideSelf && this.player.getUniqueId().equals(viewer.getUniqueId())) || this.player.getGameMode().equals(GameMode.SPECTATOR) || !viewer.getWorld().getName().equals(this.player.getWorld().getName()) || this.player.isInvisible() || !viewer.canSee(this.player)) {
            return false;
        }
        return (!this.player.isDead() || isWithinDeathVisibilityWindow()) && viewer.getLocation().distanceSquared(this.player.getLocation()) < ((double) (this.visibilityDistance * this.visibilityDistance));
    }

    public void show(Player viewer) {
        if (this.displays.isEmpty()) {
            return;
        }
        NametagHandler.hide(this.player, viewer);
        if (this.hideSelf && this.player.getUniqueId().equals(viewer.getUniqueId())) {
            return;
        }
        this.viewers.add(viewer.getUniqueId());
        for (TagRuntime runtime : this.displays) {
            runtime.display.spawn(viewer);
        }
        update(viewer);
    }

    public void hide(Player viewer) {
        this.viewers.remove(viewer.getUniqueId());
        for (TagRuntime runtime : this.displays) {
            runtime.display.despawn(viewer);
        }
    }

    public void update(Player viewer) {
        if (this.displays.isEmpty()) {
            return;
        }
        int[] passengerIds = this.displays.stream().mapToInt(runtime -> {
            return runtime.display.getEntityId();
        }).toArray();
        Location baseLocation = this.player.getLocation().clone().setRotation(0.0f, 0.0f);
        for (TagRuntime runtime2 : this.displays) {
            runtime2.display.setLocation(baseLocation);
            runtime2.display.setText(runtime2.cachedText);
            runtime2.display.update(viewer);
        }
        if (passengerIds.length > 0) {
            this.displays.get(0).display.mount(this.player, viewer, passengerIds);
        }
    }

    public void syncToLocationForAll(Location baseLocation) {
        if (this.displays.isEmpty() || baseLocation == null) {
            return;
        }
        Location targetLocation = baseLocation.clone().setRotation(0.0f, 0.0f);
        for (TagRuntime runtime : this.displays) {
            runtime.display.setLocation(targetLocation);
        }
        int[] passengerIds = this.displays.stream().mapToInt(runtime2 -> {
            return runtime2.display.getEntityId();
        }).toArray();
        Iterator<UUID> iterator = this.viewers.iterator();
        while (iterator.hasNext()) {
            UUID viewerId = iterator.next();
            Player viewer = Bukkit.getPlayer(viewerId);
            if (viewer == null || !viewer.isOnline()) {
                iterator.remove();
            } else if (!shouldSee(viewer)) {
                hide(viewer);
            } else {
                for (TagRuntime runtime3 : this.displays) {
                    runtime3.display.teleportFor(viewer);
                }
                if (passengerIds.length > 0) {
                    this.displays.get(0).display.mount(this.player, viewer, passengerIds);
                }
            }
        }
    }

    public void teleportForAll() {
        teleportForAll(this.player.getLocation());
    }

    public void teleportForAll(Location baseLocation) {
        Location targetLocation = baseLocation.clone().setRotation(0.0f, 0.0f);
        for (TagRuntime runtime : this.displays) {
            runtime.display.setLocation(targetLocation);
        }
        for (UUID viewerId : this.viewers) {
            Player viewer = Bukkit.getPlayer(viewerId);
            if (viewer != null) {
                for (TagRuntime runtime2 : this.displays) {
                    runtime2.display.teleportFor(viewer);
                }
            }
        }
    }

    public void showTemporaryTagOneAtCurrentPosition(long ticks) {
        removeTemporarySpectatorTag();
        TagRuntime runtime = getRuntimeById("displayname");
        if (runtime == null) {
            runtime = this.displays.isEmpty() ? null : this.displays.get(0);
        }
        if (runtime == null) {
            return;
        }
        Location baseLocation = this.player.getLocation().clone().setRotation(0.0f, 0.0f);
        Location tagLocation = baseLocation.clone().add(runtime.translation.getX(), this.plugin.config().getNametagConfig().getTemporarySpectatorTagHeightOffset(), runtime.translation.getZ());
        ClientTextDisplay display = new ClientTextDisplay(tagLocation);
        display.setTranslation(new Vector3f(0.0f, 0.0f, 0.0f));
        display.setScale(runtime.scale);
        display.setTextShadow(runtime.textShadow);
        display.setTextAlignment(runtime.textAlignment);
        display.setSeeThrough(runtime.seeThrough);
        display.setBillboard(runtime.billboard);
        display.setBackground(runtime.background);
        display.setText(getText(runtime.lines));
        TemporaryTag temporaryTag = new TemporaryTag(display, tagLocation);
        this.temporarySpectatorTag = temporaryTag;
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (canSeeTemporaryTag(viewer, tagLocation)) {
                temporaryTag.viewers.add(viewer.getUniqueId());
                display.spawn(viewer);
                display.update(viewer);
            }
        }
        Bukkit.getScheduler().runTaskLater(this.plugin.getHost(), () -> {
            if (this.temporarySpectatorTag != temporaryTag) {
                return;
            }
            removeTemporarySpectatorTag();
        }, ticks);
    }

    public void removeTemporarySpectatorTag() {
        if (this.temporarySpectatorTag == null) {
            return;
        }
        for (UUID viewerId : this.temporarySpectatorTag.viewers) {
            Player viewer = Bukkit.getPlayer(viewerId);
            if (viewer != null && viewer.isOnline()) {
                this.temporarySpectatorTag.display.despawn(viewer);
            }
        }
        this.temporarySpectatorTag.viewers.clear();
        this.temporarySpectatorTag = null;
    }

    private boolean canSeeTemporaryTag(Player viewer, Location location) {
        if (viewer == null || !viewer.isOnline() || viewer.isDead()) {
            return false;
        }
        return !(this.hideSelf && this.player.getUniqueId().equals(viewer.getUniqueId())) && viewer.getWorld().getName().equals(location.getWorld().getName()) && viewer.getLocation().distanceSquared(location) < ((double) (this.visibilityDistance * this.visibilityDistance));
    }

    private TagRuntime getRuntimeById(String id) {
        for (TagRuntime runtime : this.displays) {
            if (runtime.id.equalsIgnoreCase(id)) {
                return runtime;
            }
        }
        return null;
    }

    private boolean shouldLoadDisplay(TagDisplayConfig displayConfig) {
        String displayId = displayConfig.getId().toLowerCase(Locale.ROOT);
        if (!this.forcedVisibleTagIds.isEmpty()) {
            return this.forcedVisibleTagIds.contains(displayId) && !this.forcedHiddenTagIds.contains(displayId);
        }
        if (this.forcedHiddenTagIds.isEmpty()) {
            return displayConfig.isWorldAllowed(this.player.getWorld().getName());
        }
        return !this.forcedHiddenTagIds.contains(displayId) && displayConfig.isWorldAllowed(this.player.getWorld().getName());
    }

    private TagRuntime createDisplay(TagDisplayConfig config, int stackIndex) {
        List<String> lines = filterLines(config).stream().map(line -> {
            return line.replace("{player}", this.player.getName());
        }).toList();
        ClientTextDisplay display = new ClientTextDisplay(this.player.getLocation().setRotation(0.0f, 0.0f));
        double stackedY = config.getPosition().getY() + (this.plugin.config().getNametagConfig().getStackedYOffset() * ((double) stackIndex));
        Vector3f translation = new Vector3f((float) config.getPosition().getX(), (float) stackedY, (float) config.getPosition().getZ());
        display.setTranslation(translation);
        display.setScale(config.getScale());
        display.setTextShadow(config.hasTextShadow());
        display.setTextAlignment(config.getTextAlignment());
        display.setSeeThrough(config.isSeeThrough());
        display.setBillboard(config.getBillboard());
        int background = getBackground(config.getBackground());
        display.setBackground(background);
        return new TagRuntime(config.getId(), display, lines, getText(lines), translation, config.getScale().clone(), config.hasTextShadow(), config.isSeeThrough(), config.getTextAlignment(), config.getBillboard(), background);
    }

    private List<String> filterLines(TagDisplayConfig config) {
        if (config.getVisibleLines().isEmpty()) {
            return config.getLines();
        }
        List<String> selected = new ArrayList<>();
        for (Integer visibleLine : config.getVisibleLines()) {
            int index = visibleLine.intValue() - 1;
            if (index >= 0 && index < config.getLines().size()) {
                selected.add(config.getLines().get(index));
            }
        }
        return selected.isEmpty() ? config.getLines() : selected;
    }

    private Component getText(List<String> lines) {
        String numberValue;
        List<Component> components = new ArrayList<>(lines.size());
        double health = this.player.getHealth();
        double absorption = this.player.getAbsorptionAmount();
        String heartColor = absorption > 0.0d ? "&#FFEF5A" : "&#FF2C2C";
        if (health >= 3.0d) {
            numberValue = "&f" + ((int) Math.floor(health));
        } else {
            int whole = (int) health;
            int decimal = (int) ((health * 10.0d) % 10.0d);
            numberValue = "&f" + whole + "&7." + decimal;
        }
        String healthValue = numberValue + " " + heartColor + "❤";
        for (String line : lines) {
            String modified = line.replace("{health}", healthValue);
            if (DependencyHelper.isPlaceholderAPIEnabled()) {
                modified = PlaceholderAPI.setPlaceholders(this.player, modified);
            }
            components.add(ComponentUtils.format(modified));
        }
        return ComponentUtils.join(components);
    }

    private int getBackground(String background) {
        if (background == null || background.equalsIgnoreCase("default")) {
            return -1;
        }
        if (background.equalsIgnoreCase("transparent")) {
            return 0;
        }
        if (background.startsWith("#")) {
            background = background.substring(1);
        }
        Color color = Color.fromARGB((int) Long.parseLong(background, 16));
        if (background.length() == 6) {
            color = color.setAlpha(255);
        }
        return color.asARGB();
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/nametags/Nametag$TagRuntime.class */
    private static class TagRuntime {
        private final String id;
        private final ClientTextDisplay display;
        private final List<String> lines;
        private Component cachedText;
        private final Vector3f translation;
        private final Vector scale;
        private final boolean textShadow;
        private final boolean seeThrough;
        private final TextAlignment textAlignment;
        private final DisplayBillboard billboard;
        private final int background;

        private TagRuntime(String id, ClientTextDisplay display, List<String> lines, Component cachedText, Vector3f translation, Vector scale, boolean textShadow, boolean seeThrough, TextAlignment textAlignment, DisplayBillboard billboard, int background) {
            this.id = id;
            this.display = display;
            this.lines = lines;
            this.cachedText = cachedText;
            this.translation = translation;
            this.scale = scale;
            this.textShadow = textShadow;
            this.seeThrough = seeThrough;
            this.textAlignment = textAlignment;
            this.billboard = billboard;
            this.background = background;
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/nametags/Nametag$TemporaryTag.class */
    private static class TemporaryTag {
        private final ClientTextDisplay display;
        private final Location location;
        private final Set<UUID> viewers = new HashSet();

        private TemporaryTag(ClientTextDisplay display, Location location) {
            this.display = display;
            this.location = location;
        }
    }
}
