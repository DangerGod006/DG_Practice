package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.fawe.FaweAdapter;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.util.U;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/ArenaManager.class */
public final class ArenaManager {
    private final PvPCorePlugin plugin;
    private final Settings settings;
    private final MessageManager messages;
    private final FaweAdapter fawe;
    private final Map<String, Arena> arenas = new HashMap();
    private final Map<String, Set<String>> categories = new HashMap();
    private final Map<String, ItemStack> categoryIcons = new HashMap();
    private final Map<String, Set<String>> kitBlacklist = new HashMap();
    private final File file;
    private YamlConfiguration cfg;

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/ArenaManager$ArenaOption.class */
    public static final class ArenaOption {
        private final String id;
        private final String displayName;
        private final ItemStack icon;
        private final boolean category;

        public ArenaOption(String id, String displayName, ItemStack icon, boolean category) {
            this.id = id == null ? "" : id.toLowerCase();
            this.displayName = (displayName == null || displayName.isBlank()) ? this.id : displayName;
            this.icon = icon == null ? null : icon.clone();
            this.category = category;
        }

        public String id() {
            return this.id;
        }

        public String displayName() {
            return this.displayName;
        }

        public ItemStack icon() {
            if (this.icon == null) {
                return null;
            }
            return this.icon.clone();
        }

        public boolean category() {
            return this.category;
        }
    }

    public ArenaManager(PvPCorePlugin plugin, Settings settings, MessageManager messages, FaweAdapter fawe) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.fawe = fawe;
        this.file = new File(plugin.getDataFolder(), "arenas.yml");
    }

    public void load() {
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.arenas.clear();
        this.categories.clear();
        this.categoryIcons.clear();
        this.kitBlacklist.clear();
        ConfigurationSection sec = this.cfg.getConfigurationSection("arenas");
        if (sec == null) {
            return;
        }
        for (String id : sec.getKeys(false)) {
            String path = "arenas." + id + ".";
            String name = this.cfg.getString(path + "displayName", id);
            Arena a = new Arena(id, name);
            a.setWorldName(this.cfg.getString(path + "world", (String) null));
            a.setRedSpawn(U.readLocation(this.cfg, path + "spawns.red", a.worldName()));
            a.setBlueSpawn(U.readLocation(this.cfg, path + "spawns.blue", a.worldName()));
            Location min = U.readLocation(this.cfg, path + "regen.min", a.worldName());
            Location max = U.readLocation(this.cfg, path + "regen.max", a.worldName());
            if (min != null && max != null) {
                a.setRegion(min, max);
            }
            loadSelectionPair(a, this.cfg, path + "walls.red", "red", false);
            loadSelectionPair(a, this.cfg, path + "walls.blue", "blue", false);
            loadSelectionPair(a, this.cfg, path + "final-walls.red", "red", true);
            loadSelectionPair(a, this.cfg, path + "final-walls.blue", "blue", true);
            loadPrefightWallSettings(a, this.cfg, path);
            File schem = new File(this.plugin.getDataFolder(), "arenas/" + id.toLowerCase() + ".schem");
            a.setSchematicFile(schem);
            ItemStack arenaIcon = this.cfg.getItemStack(path + "icon");
            if (arenaIcon != null) {
                a.setIcon(arenaIcon);
            }
            a.setInUse(false);
            a.setLastUsedMillis(0L);
            this.arenas.put(a.id(), a);
        }
        ConfigurationSection catSec = this.cfg.getConfigurationSection("subarenas");
        if (catSec != null) {
            for (String category : catSec.getKeys(false)) {
                Set<String> set = new LinkedHashSet<>();
                for (String arenaId : catSec.getStringList(category)) {
                    set.add(arenaId.toLowerCase());
                }
                this.categories.put(category.toLowerCase(), set);
            }
        }
        ConfigurationSection iconSec = this.cfg.getConfigurationSection("category-icons");
        if (iconSec != null) {
            for (String category2 : iconSec.getKeys(false)) {
                ItemStack icon = this.cfg.getItemStack("category-icons." + category2);
                if (icon != null) {
                    this.categoryIcons.put(category2.toLowerCase(), icon);
                }
            }
        }
        ConfigurationSection blSec = this.cfg.getConfigurationSection("kit-blacklist");
        if (blSec != null) {
            for (String kitId : blSec.getKeys(false)) {
                Set<String> set2 = new LinkedHashSet<>();
                for (String entry : blSec.getStringList(kitId)) {
                    set2.add(entry.toLowerCase());
                }
                this.kitBlacklist.put(kitId.toLowerCase(), set2);
            }
        }
    }

    public void save() {
        YamlConfiguration previous = this.cfg;
        this.cfg = new YamlConfiguration();
        this.cfg.createSection("arenas");
        for (Arena a : this.arenas.values()) {
            String path = "arenas." + a.id() + ".";
            this.cfg.set(path + "displayName", a.displayName());
            this.cfg.set(path + "world", a.worldName());
            if (a.icon() != null) {
                this.cfg.set(path + "icon", a.icon());
            }
            U.writeLocation(this.cfg, path + "spawns.red", a.redSpawn(), a.worldName());
            U.writeLocation(this.cfg, path + "spawns.blue", a.blueSpawn(), a.worldName());
            if (a.min() != null && a.max() != null) {
                U.writeLocation(this.cfg, path + "regen.min", a.min(), a.worldName());
                U.writeLocation(this.cfg, path + "regen.max", a.max(), a.worldName());
            }
            saveSelectionPair(this.cfg, path + "walls.red", a.wallMin("red"), a.wallMax("red"));
            saveSelectionPair(this.cfg, path + "walls.blue", a.wallMin("blue"), a.wallMax("blue"));
            saveSelectionPair(this.cfg, path + "final-walls.red", a.finalWallMin("red"), a.finalWallMax("red"));
            saveSelectionPair(this.cfg, path + "final-walls.blue", a.finalWallMin("blue"), a.finalWallMax("blue"));
            savePrefightWallSettings(this.cfg, path, a);
        }
        copySection(previous, this.cfg, "prefight-walls");
        for (Map.Entry<String, Set<String>> entry : this.categories.entrySet()) {
            this.cfg.set("subarenas." + entry.getKey(), new ArrayList(entry.getValue()));
        }
        for (Map.Entry<String, ItemStack> entry2 : this.categoryIcons.entrySet()) {
            this.cfg.set("category-icons." + entry2.getKey(), entry2.getValue());
        }
        for (Map.Entry<String, Set<String>> entry3 : this.kitBlacklist.entrySet()) {
            this.cfg.set("kit-blacklist." + entry3.getKey(), new ArrayList(entry3.getValue()));
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().severe("Failed to save arenas.yml: " + e.getMessage());
        }
    }

    private void loadPrefightWallSettings(Arena arena, YamlConfiguration cfg, String arenaPath) {
        String materialName = cfg.getString(arenaPath + "prefight-walls.material", cfg.getString("prefight-walls.material", (String) null));
        Material material = parseFenceMaterial(materialName);
        if (material != null) {
            arena.setPrefightWallMaterial(material);
        }
        Object faces = firstConfigured(cfg.get(arenaPath + "prefight-walls.facing." + arena.id()), cfg.get(arenaPath + "prefight-walls.facing.global"), cfg.get(arenaPath + "prefight-walls.facing"), cfg.get("prefight-walls.facing." + arena.id()), cfg.get("prefight-walls.facing.global"), cfg.get("prefight-walls.facing"));
        Set<BlockFace> parsedFaces = parseFacing(faces);
        if (!parsedFaces.isEmpty()) {
            arena.setPrefightWallFacing(parsedFaces);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x003c  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0058  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.lang.Object firstConfigured(java.lang.Object... r4) {
        /*
            r3 = this;
            r0 = r4
            if (r0 != 0) goto L6
            r0 = 0
            return r0
        L6:
            r0 = r4
            r5 = r0
            r0 = r5
            int r0 = r0.length
            r6 = r0
            r0 = 0
            r7 = r0
        Le:
            r0 = r7
            r1 = r6
            if (r0 >= r1) goto L83
            r0 = r5
            r1 = r7
            r0 = r0[r1]
            r8 = r0
            r0 = r8
            if (r0 != 0) goto L22
            goto L7d
        L22:
            r0 = r8
            boolean r0 = r0 instanceof java.lang.String
            if (r0 == 0) goto L3c
            r0 = r8
            java.lang.String r0 = (java.lang.String) r0
            r9 = r0
            r0 = r9
            boolean r0 = r0.isBlank()
            if (r0 == 0) goto L3c
            goto L7d
        L3c:
            r0 = r8
            boolean r0 = r0 instanceof java.util.Collection
            if (r0 == 0) goto L58
            r0 = r8
            java.util.Collection r0 = (java.util.Collection) r0
            r9 = r0
            r0 = r9
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L58
            goto L7d
        L58:
            r0 = r8
            boolean r0 = r0 instanceof org.bukkit.configuration.ConfigurationSection
            if (r0 == 0) goto L7a
            r0 = r8
            org.bukkit.configuration.ConfigurationSection r0 = (org.bukkit.configuration.ConfigurationSection) r0
            r9 = r0
            r0 = r9
            r1 = 0
            java.util.Set r0 = r0.getKeys(r1)
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L7a
            goto L7d
        L7a:
            r0 = r8
            return r0
        L7d:
            int r7 = r7 + 1
            goto Le
        L83:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: dev.rean.pvpcore.managers.ArenaManager.firstConfigured(java.lang.Object[]):java.lang.Object");
    }

    private Material parseFenceMaterial(String name) {
        Material material;
        if (name == null || name.isBlank() || (material = Material.matchMaterial(name.trim())) == null || !material.name().endsWith("_FENCE")) {
            return null;
        }
        return material;
    }

    private Set<BlockFace> parseFacing(Object raw) {
        Set<BlockFace> faces = new LinkedHashSet<>();
        if (raw instanceof String) {
            String string = (String) raw;
            addFaces(faces, Arrays.asList(string.split(",")));
        } else if (raw instanceof Collection) {
            Collection<?> collection = (Collection) raw;
            List<String> values = new ArrayList<>();
            for (Object value : collection) {
                values.add(String.valueOf(value));
            }
            addFaces(faces, values);
        }
        return faces;
    }

    private void addFaces(Set<BlockFace> faces, Collection<String> values) {
        for (String value : values) {
            if (value != null) {
                String normalized = value.trim().toUpperCase(Locale.ROOT).replace('-', '_');
                if (!normalized.isBlank()) {
                    try {
                        BlockFace face = BlockFace.valueOf(normalized);
                        if (face == BlockFace.NORTH || face == BlockFace.SOUTH || face == BlockFace.EAST || face == BlockFace.WEST) {
                            faces.add(face);
                        }
                    } catch (IllegalArgumentException e) {
                    }
                }
            }
        }
    }

    private void savePrefightWallSettings(YamlConfiguration cfg, String path, Arena arena) {
        if (arena.prefightWallMaterial() != null) {
            cfg.set(path + "prefight-walls.material", arena.prefightWallMaterial().name());
        }
        Set<BlockFace> faces = arena.prefightWallFacing();
        if (!faces.isEmpty()) {
            List<String> values = new ArrayList<>();
            for (BlockFace face : faces) {
                values.add(face.name().toLowerCase(Locale.ROOT));
            }
            cfg.set(path + "prefight-walls.facing", String.join(",", values));
        }
    }

    private void copySection(YamlConfiguration from, YamlConfiguration to, String path) {
        if (from == null || to == null || path == null || !from.isConfigurationSection(path)) {
            return;
        }
        copySectionValues(from.getConfigurationSection(path), to.createSection(path));
    }

    private void copySectionValues(ConfigurationSection from, ConfigurationSection to) {
        if (from == null || to == null) {
            return;
        }
        for (String key : from.getKeys(false)) {
            Object value = from.get(key);
            if (value instanceof ConfigurationSection) {
                ConfigurationSection child = (ConfigurationSection) value;
                copySectionValues(child, to.createSection(key));
            } else {
                to.set(key, value);
            }
        }
    }

    private void loadSelectionPair(Arena arena, YamlConfiguration cfg, String path, String side, boolean finalWall) {
        Location min = U.readLocation(cfg, path + ".min", arena.worldName());
        Location max = U.readLocation(cfg, path + ".max", arena.worldName());
        if (min == null || max == null) {
            return;
        }
        if (!finalWall) {
            arena.setWallRegion(side, min, max);
        } else {
            arena.setFinalWallRegion(side, min, max);
        }
    }

    private void saveSelectionPair(YamlConfiguration cfg, String path, Location min, Location max) {
        if (min == null || max == null) {
            return;
        }
        String fallbackWorld = (min == null || min.getWorld() == null) ? (max == null || max.getWorld() == null) ? null : max.getWorld().getName() : min.getWorld().getName();
        U.writeLocation(cfg, path + ".min", min, fallbackWorld);
        U.writeLocation(cfg, path + ".max", max, fallbackWorld);
    }

    public Arena get(String id) {
        if (id == null) {
            return null;
        }
        return this.arenas.get(id.toLowerCase(Locale.ROOT));
    }

    public Collection<Arena> all() {
        return this.arenas.values();
    }

    public Optional<Arena> findAvailable() {
        return findAvailable("random", null);
    }

    public Optional<Arena> findAvailableIgnoringBlacklist(String selection) {
        Stream<Arena> stream;
        String normalized = (selection == null || selection.isBlank()) ? "random" : selection.toLowerCase();
        if ("random".equals(normalized)) {
            stream = this.arenas.values().stream();
        } else if (this.categories.containsKey(normalized)) {
            stream = this.categories.get(normalized).stream().map(this::get).filter((v0) -> {
                return Objects.nonNull(v0);
            });
        } else {
            Arena specific = get(normalized);
            stream = specific == null ? Stream.empty() : Stream.of(specific);
        }
        return stream.filter(this::isUsableForMatch).filter(a -> {
            return !a.inUse();
        }).min(Comparator.comparingLong((v0) -> {
            return v0.lastUsedMillis();
        }));
    }

    public Optional<Arena> findAvailable(String selection, Kit kit) {
        Stream<Arena> stream;
        String normalized = (selection == null || selection.isBlank()) ? "random" : selection.toLowerCase();
        if ("random".equals(normalized)) {
            stream = this.arenas.values().stream();
        } else if (this.categories.containsKey(normalized)) {
            stream = this.categories.get(normalized).stream().map(this::get).filter((v0) -> {
                return Objects.nonNull(v0);
            });
        } else {
            Arena specific = get(normalized);
            stream = specific == null ? Stream.empty() : Stream.of(specific);
        }
        return stream.filter(this::isUsableForMatch).filter(a -> {
            return !a.inUse();
        }).filter(a2 -> {
            return isKitAllowed(kit, normalized, a2.id());
        }).min(Comparator.comparingLong((v0) -> {
            return v0.lastUsedMillis();
        }));
    }

    public boolean isUsableForMatch(Arena arena) {
        return arena != null && arena.ready() && isValidTeleportLocation(arena.redSpawn()) && isValidTeleportLocation(arena.blueSpawn()) && isValidRegionLocation(arena.min()) && isValidRegionLocation(arena.max());
    }

    public List<String> matchReadinessReasons(Arena arena) {
        if (arena == null) {
            return List.of("arena missing");
        }
        List<String> reasons = new ArrayList<>(arena.readyReasons());
        if (!isValidTeleportLocation(arena.redSpawn())) {
            reasons.add("red spawn world missing");
        }
        if (!isValidTeleportLocation(arena.blueSpawn())) {
            reasons.add("blue spawn world missing");
        }
        if (!isValidRegionLocation(arena.min()) || !isValidRegionLocation(arena.max())) {
            reasons.add("regen region world missing");
        }
        return reasons.stream().distinct().toList();
    }

    private boolean isValidTeleportLocation(Location location) {
        return (location == null || location.getWorld() == null) ? false : true;
    }

    private boolean isValidRegionLocation(Location location) {
        return (location == null || location.getWorld() == null) ? false : true;
    }

    public boolean create(String id, String displayName) {
        if (id == null || id.isBlank()) {
            return false;
        }
        String normalized = id.toLowerCase(Locale.ROOT);
        if (this.arenas.containsKey(normalized)) {
            return false;
        }
        Arena a = new Arena(normalized, displayName);
        this.arenas.put(a.id(), a);
        ensureArenaFolder();
        return true;
    }

    public boolean delete(String id) {
        String normalized;
        Arena a;
        if (id == null || id.isBlank() || (a = this.arenas.remove((normalized = id.toLowerCase(Locale.ROOT)))) == null) {
            return false;
        }
        if (a.schematicFile() != null && a.schematicFile().exists()) {
            a.schematicFile().delete();
        }
        this.categories.values().forEach(set -> {
            set.remove(normalized);
        });
        this.categories.entrySet().removeIf(entry -> {
            return entry.getValue() == null || ((Set) entry.getValue()).isEmpty();
        });
        this.kitBlacklist.values().forEach(set2 -> {
            set2.remove(normalized);
        });
        this.kitBlacklist.entrySet().removeIf(entry2 -> {
            return entry2.getValue() == null || ((Set) entry2.getValue()).isEmpty();
        });
        save();
        return true;
    }

    public void setSpawn(Player p, String arenaId, String side) {
        if (p == null) {
            return;
        }
        boolean updated = setSpawnDirect(arenaId, side, p.getLocation());
        if (!updated) {
            this.messages.send(p, "arenas.not-found");
            return;
        }
        Arena arena = get(arenaId);
        if (arena == null) {
            this.messages.send(p, "arenas.not-found");
        } else {
            this.messages.send(p, "arenas.spawn-set", Map.of("id", arena.id(), "side", side.toUpperCase(Locale.ROOT)));
        }
    }

    public boolean setSpawnDirect(String arenaId, String side, Location location) {
        Arena arena = get(arenaId);
        if (arena == null || location == null || location.getWorld() == null) {
            return false;
        }
        Location loc = location.clone();
        arena.setWorldName(loc.getWorld().getName());
        if (side != null && side.equalsIgnoreCase("red")) {
            arena.setRedSpawn(loc);
        } else {
            arena.setBlueSpawn(loc);
        }
        save();
        return true;
    }

    public void setWallRegionFromSelection(Player p, String arenaId, String side) {
        setSelectedWallRegionFromSelection(p, arenaId, side, false, null);
    }

    public void setWallRegionFromSelection(Player p, String arenaId, String side, Consumer<String> callback) {
        setSelectedWallRegionFromSelection(p, arenaId, side, false, callback);
    }

    public void setFinalWallRegionFromSelection(Player p, String arenaId, String side) {
        setSelectedWallRegionFromSelection(p, arenaId, side, true, null);
    }

    public void setFinalWallRegionFromSelection(Player p, String arenaId, String side, Consumer<String> callback) {
        setSelectedWallRegionFromSelection(p, arenaId, side, true, callback);
    }

    private void setSelectedWallRegionFromSelection(Player p, String arenaId, String side, boolean finalWall, Consumer<String> callback) {
        Arena a = get(arenaId);
        if (a == null) {
            this.messages.send(p, "arenas.not-found");
            finishCallback(callback, "Arena not found.");
        } else if (!side.equalsIgnoreCase("red") && !side.equalsIgnoreCase("blue")) {
            p.sendMessage(this.messages.format("&cUsage: /arena " + (finalWall ? "setfinalwall" : "setwall") + " <red|blue> <id>", Map.of()));
            finishCallback(callback, "Invalid side.");
        } else {
            this.fawe.readSelectionAsync(p, (min, max, worldName, err) -> {
                if (err != null) {
                    p.sendMessage(this.messages.format("&cFailed: " + err, Map.of()));
                    finishCallback(callback, err);
                    return;
                }
                a.setWorldName(worldName);
                if (finalWall) {
                    a.setFinalWallRegion(side, min, max);
                } else {
                    a.setWallRegion(side, min, max);
                }
                save();
                String kind = finalWall ? "final wall" : "wall";
                p.sendMessage(this.messages.format("%prefix%&fSet &e" + kind + "&f for &e" + a.id() + "&f side &e" + side.toUpperCase() + "&r.", Map.of()));
                finishCallback(callback, null);
            });
        }
    }

    public void giveRegenWand(Player p) {
        p.getInventory().addItem(new ItemStack[]{this.fawe.createRegenWand()});
        this.messages.send(p, "arenas.regen-wand-given");
    }

    public void setRegenRegionFromSelection(Player p, String arenaId) {
        setRegenRegionFromSelection(p, arenaId, null);
    }

    public void setRegenRegionFromSelection(Player p, String arenaId, Consumer<String> callback) {
        Arena a = get(arenaId);
        if (a == null) {
            this.messages.send(p, "arenas.not-found");
            finishCallback(callback, "Arena not found.");
        } else {
            ensureArenaFolder();
            File schem = new File(this.plugin.getDataFolder(), "arenas/" + a.id() + ".schem");
            a.setSchematicFile(schem);
            this.fawe.captureSelectionToSchematicAsync(p, schem, (min, max, worldName, err) -> {
                if (err != null) {
                    p.sendMessage(this.messages.format("&cFailed: " + err, Map.of()));
                    finishCallback(callback, err);
                    return;
                }
                a.setWorldName(worldName);
                a.setRegion(min, max);
                save();
                this.messages.send(p, "arenas.regen-region-set", Map.of("id", a.id()));
                finishCallback(callback, null);
            });
        }
    }

    private void finishCallback(Consumer<String> callback, String error) {
        if (callback != null) {
            callback.accept(error);
        }
    }

    public void regenArenaAsync(Arena a, Runnable doneSync) {
        if (a == null || a.schematicFile() == null || !a.schematicFile().exists()) {
            if (doneSync != null) {
                doneSync.run();
            }
        } else {
            Bukkit.getScheduler().runTask(this.plugin, () -> {
                removeEntitiesInRegenRegion(a);
            });
            this.fawe.pasteSchematicAsync(a.schematicFile(), a.worldName(), a.min(), err -> {
                if (err != null) {
                    this.plugin.getLogger().warning("Regen failed for arena " + a.id() + ": " + err);
                }
                if (doneSync != null) {
                    doneSync.run();
                }
            });
        }
    }

    private void removeEntitiesInRegenRegion(Arena a) {
        if (a == null) {
            return;
        }
        Location min = a.min();
        Location max = a.max();
        World w = a.world();
        if (min == null || max == null || w == null) {
            return;
        }
        int minX = Math.min(min.getBlockX(), max.getBlockX());
        int minY = Math.min(min.getBlockY(), max.getBlockY());
        int minZ = Math.min(min.getBlockZ(), max.getBlockZ());
        int maxX = Math.max(min.getBlockX(), max.getBlockX());
        int maxY = Math.max(min.getBlockY(), max.getBlockY());
        int maxZ = Math.max(min.getBlockZ(), max.getBlockZ());
        Location center = new Location(w, ((double) (minX + maxX)) / 2.0d, ((double) (minY + maxY)) / 2.0d, ((double) (minZ + maxZ)) / 2.0d);
        double halfX = (((double) ((maxX - minX) + 1)) / 2.0d) + 1.0d;
        double halfY = (((double) ((maxY - minY) + 1)) / 2.0d) + 1.0d;
        double halfZ = (((double) ((maxZ - minZ) + 1)) / 2.0d) + 1.0d;
        for (Entity e : w.getNearbyEntities(center, halfX, halfY, halfZ, entity -> {
            return !(entity instanceof Player);
        })) {
            Location l = e.getLocation();
            int x = l.getBlockX();
            int y = l.getBlockY();
            int z = l.getBlockZ();
            if (x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ) {
                e.remove();
            }
        }
    }

    public boolean addSubarena(String category, String arenaId) {
        if (get(arenaId) == null) {
            return false;
        }
        this.categories.computeIfAbsent(category.toLowerCase(), k -> {
            return new LinkedHashSet();
        }).add(arenaId.toLowerCase());
        save();
        return true;
    }

    public boolean removeSubarena(String category, String arenaId) {
        Set<String> set = this.categories.get(category.toLowerCase());
        if (set == null) {
            return false;
        }
        boolean removed = set.remove(arenaId.toLowerCase());
        if (set.isEmpty()) {
            this.categories.remove(category.toLowerCase());
        }
        if (removed) {
            save();
        }
        return removed;
    }

    public Set<String> listSubarenas(String category) {
        return new LinkedHashSet(this.categories.getOrDefault(category.toLowerCase(), Set.of()));
    }

    public Set<String> categoryIds() {
        return new LinkedHashSet(this.categories.keySet());
    }

    public boolean setCategoryIcon(String category, ItemStack icon) {
        if (category == null || category.isBlank() || icon == null || icon.getType().isAir()) {
            return false;
        }
        this.categoryIcons.put(category.toLowerCase(), icon.clone());
        save();
        return true;
    }

    public ItemStack getCategoryIcon(String selection) {
        if (selection == null || selection.isBlank()) {
            return null;
        }
        return cloneIcon(this.categoryIcons.get(selection.toLowerCase()));
    }

    public ItemStack getArenaOrCategoryIcon(String selection) {
        if (selection == null || selection.isBlank()) {
            return null;
        }
        String normalized = selection.toLowerCase();
        Arena arena = get(normalized);
        return (arena == null || arena.icon() == null) ? cloneIcon(this.categoryIcons.get(normalized)) : arena.icon();
    }

    public String getSelectionDisplayName(String selection) {
        String normalized = (selection == null || selection.isBlank()) ? "random" : selection.toLowerCase();
        if ("random".equals(normalized)) {
            return "Random";
        }
        Arena arena = get(normalized);
        if (arena != null) {
            return arena.displayName();
        }
        if (this.categories.containsKey(normalized)) {
            return Character.toUpperCase(normalized.charAt(0)) + normalized.substring(1);
        }
        return selection;
    }

    private ItemStack cloneIcon(ItemStack icon) {
        if (icon == null) {
            return null;
        }
        return icon.clone();
    }

    public boolean addKitBlacklist(String kitId, String arenaOrCategory) {
        this.kitBlacklist.computeIfAbsent(kitId.toLowerCase(), k -> {
            return new LinkedHashSet();
        }).add(arenaOrCategory.toLowerCase());
        save();
        return true;
    }

    public boolean removeKitBlacklist(String kitId, String arenaOrCategory) {
        Set<String> set = this.kitBlacklist.get(kitId.toLowerCase());
        if (set == null) {
            return false;
        }
        boolean removed = set.remove(arenaOrCategory.toLowerCase());
        if (set.isEmpty()) {
            this.kitBlacklist.remove(kitId.toLowerCase());
        }
        if (removed) {
            save();
        }
        return removed;
    }

    public Set<String> listKitBlacklist(String kitId) {
        return new LinkedHashSet(this.kitBlacklist.getOrDefault(kitId.toLowerCase(), Set.of()));
    }

    public boolean isKitAllowed(Kit kit, String selection, String arenaId) {
        Set<String> set;
        if (kit == null || (set = this.kitBlacklist.get(kit.id().toLowerCase())) == null || set.isEmpty()) {
            return true;
        }
        String normalizedSelection = selection == null ? "" : selection.toLowerCase();
        String normalizedArena = arenaId == null ? "" : arenaId.toLowerCase();
        return (set.contains(normalizedSelection) || set.contains(normalizedArena)) ? false : true;
    }

    public boolean isCategory(String selection) {
        return selection != null && this.categories.containsKey(selection.toLowerCase());
    }

    public List<ArenaOption> getArenaOptions(Kit kit, String contextSelection) {
        return getArenaOptionsInternal(kit, contextSelection, true);
    }

    public List<ArenaOption> getArenaOptionsIgnoringBlacklist(String contextSelection) {
        return getArenaOptionsInternal(null, contextSelection, false);
    }

    private List<ArenaOption> getArenaOptionsInternal(Kit kit, String contextSelection, boolean applyBlacklist) {
        List<ArenaOption> result = new ArrayList<>();
        String normalized = contextSelection == null ? "" : contextSelection.toLowerCase();
        if (isCategory(normalized)) {
            for (String arenaId : this.categories.getOrDefault(normalized, Set.of())) {
                Arena arena = get(arenaId);
                if (arena != null && isUsableForMatch(arena) && !arena.inUse() && (!applyBlacklist || isKitAllowed(kit, normalized, arena.id()))) {
                    result.add(new ArenaOption(arena.id(), arena.displayName(), arena.icon(), false));
                }
            }
            result.sort(Comparator.comparing((v0) -> {
                return v0.displayName();
            }, String.CASE_INSENSITIVE_ORDER));
            return result;
        }
        if (!this.categories.isEmpty()) {
            for (String categoryId : this.categories.keySet()) {
                if (hasAnyArenaOption(categoryId, kit, applyBlacklist)) {
                    result.add(new ArenaOption(categoryId, getSelectionDisplayName(categoryId), getCategoryIcon(categoryId), true));
                }
            }
            result.sort(Comparator.comparing((v0) -> {
                return v0.displayName();
            }, String.CASE_INSENSITIVE_ORDER));
            return result;
        }
        for (Arena arena2 : this.arenas.values()) {
            if (arena2 != null && isUsableForMatch(arena2) && !arena2.inUse() && (!applyBlacklist || isKitAllowed(kit, arena2.id(), arena2.id()))) {
                result.add(new ArenaOption(arena2.id(), arena2.displayName(), arena2.icon(), false));
            }
        }
        result.sort(Comparator.comparing((v0) -> {
            return v0.displayName();
        }, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    private boolean hasAnyArenaOption(String categoryId, Kit kit) {
        return hasAnyArenaOption(categoryId, kit, true);
    }

    private boolean hasAnyArenaOption(String categoryId, Kit kit, boolean applyBlacklist) {
        Set<String> arenaIds = this.categories.get(categoryId.toLowerCase());
        if (arenaIds == null || arenaIds.isEmpty()) {
            return false;
        }
        for (String arenaId : arenaIds) {
            Arena arena = get(arenaId);
            if (arena != null && isUsableForMatch(arena) && !arena.inUse() && (!applyBlacklist || isKitAllowed(kit, categoryId, arena.id()))) {
                return true;
            }
        }
        return false;
    }

    public void releaseAll() {
        for (Arena arena : this.arenas.values()) {
            if (arena != null) {
                arena.setInUse(false);
            }
        }
    }

    public boolean setArenaState(String arenaId, boolean inUse) {
        Arena arena = get(arenaId);
        if (arena == null) {
            return false;
        }
        arena.setInUse(inUse);
        if (!inUse) {
            markUsed(arena);
            return true;
        }
        return true;
    }

    public void markUsed(Arena a) {
        if (a == null) {
            return;
        }
        a.setLastUsedMillis(System.currentTimeMillis());
    }

    private void ensureArenaFolder() {
        File dir = new File(this.plugin.getDataFolder(), "arenas");
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
}
