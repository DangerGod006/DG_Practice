package dev.rean.pvpcore.arenaeditor;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorListener.class */
public final class ArenaEditorListener implements Listener {
    private final PvPCorePlugin plugin;

    public ArenaEditorListener(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (this.plugin.arenaEditorManager().isEditing(player.getUniqueId())) {
            if ((event.getHand() != null && event.getHand() != EquipmentSlot.HAND) || event.getAction() == Action.PHYSICAL || this.plugin.arenaEditorManager().isRegionStep(player.getUniqueId())) {
                return;
            }
            event.setCancelled(true);
            boolean left = event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK;
            boolean right = event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK;
            boolean sneaking = player.isSneaking();
            if (sneaking && right) {
                this.plugin.arenaEditorManager().confirmCurrent(player);
                return;
            }
            if (sneaking && left) {
                this.plugin.arenaEditorManager().teleportCurrent(player);
            } else if (right) {
                this.plugin.arenaEditorManager().nextStep(player);
            } else if (left) {
                this.plugin.arenaEditorManager().previousStep(player);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (this.plugin.arenaEditorManager().isEditing(player.getUniqueId()) && this.plugin.arenaEditorManager().isRegionStep(player.getUniqueId())) {
            event.setCancelled(true);
            if (player.isSneaking()) {
                this.plugin.arenaEditorManager().confirmCurrent(player);
            } else {
                this.plugin.arenaEditorManager().nextStep(player);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (this.plugin.arenaEditorManager().isEditing(player.getUniqueId()) && this.plugin.arenaEditorManager().isRegionStep(player.getUniqueId())) {
            event.setCancelled(true);
            if (player.isSneaking()) {
                this.plugin.arenaEditorManager().teleportCurrent(player);
            } else {
                this.plugin.arenaEditorManager().previousStep(player);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.plugin.arenaEditorManager().stop(event.getPlayer().getUniqueId());
    }
}
