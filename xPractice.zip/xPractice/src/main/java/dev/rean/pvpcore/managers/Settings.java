package dev.rean.pvpcore.managers;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/managers/Settings.class */
public final class Settings {
    private final PvPCorePlugin plugin;
    private String prefix;
    private int requestTimeoutSeconds;
    private int countdownSeconds;
    private int maxRounds;
    private int defaultRounds;
    private boolean allowCommandsInMatch;
    private boolean teleportToSpawnOnJoin;
    private boolean joinSpeedEnabled;
    private int joinSpeedLevel;
    private Location mainSpawn;

    public Settings(PvPCorePlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public PvPCorePlugin plugin() {
        return this.plugin;
    }

    public void reload() {
        this.prefix = this.plugin.getConfig().getString("prefix", "");
        this.requestTimeoutSeconds = this.plugin.getConfig().getInt("duels.request-timeout-seconds", 30);
        this.countdownSeconds = this.plugin.getConfig().getInt("duels.countdown-seconds", 5);
        this.maxRounds = this.plugin.getConfig().getInt("duels.max-rounds", 9);
        this.defaultRounds = this.plugin.getConfig().getInt("duels.default-rounds", 3);
        this.allowCommandsInMatch = this.plugin.getConfig().getBoolean("duels.allow-commands-in-match", false);
        this.teleportToSpawnOnJoin = this.plugin.getConfig().getBoolean("join.teleport-to-spawn", true);
        this.joinSpeedEnabled = this.plugin.getConfig().getBoolean("join.speed.enabled", true);
        this.joinSpeedLevel = Math.max(1, Math.min(255, this.plugin.getConfig().getInt("join.speed.level", 3)));
        this.mainSpawn = readLocation("spawn");
    }

    private Location readLocation(String path) {
        String world = this.plugin.getConfig().getString(path + ".world", "world");
        double x = this.plugin.getConfig().getDouble(path + ".x", 0.5d);
        double y = this.plugin.getConfig().getDouble(path + ".y", 80.0d);
        double z = this.plugin.getConfig().getDouble(path + ".z", 0.5d);
        float yaw = (float) this.plugin.getConfig().getDouble(path + ".yaw", 0.0d);
        float pitch = (float) this.plugin.getConfig().getDouble(path + ".pitch", 0.0d);
        if (Bukkit.getWorld(world) == null) {
            return null;
        }
        return new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
    }

    public String prefixRaw() {
        return this.prefix;
    }

    public String resetRaw() {
        return "&r";
    }

    public int requestTimeoutSeconds() {
        return this.requestTimeoutSeconds;
    }

    public int countdownSeconds() {
        return this.countdownSeconds;
    }

    public int maxRounds() {
        return this.maxRounds;
    }

    public int defaultRounds() {
        return this.defaultRounds;
    }

    public boolean allowCommandsInMatch() {
        return this.allowCommandsInMatch;
    }

    public boolean teleportToSpawnOnJoin() {
        return this.teleportToSpawnOnJoin;
    }

    public boolean joinSpeedEnabled() {
        return this.joinSpeedEnabled;
    }

    public int joinSpeedLevel() {
        return this.joinSpeedLevel;
    }

    public Location mainSpawn() {
        return this.mainSpawn;
    }
}
