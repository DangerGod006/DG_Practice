package dev.rean.pvpcore.prefight;

import com.github.retrooper.packetevents.event.PacketListener;
import com.github.retrooper.packetevents.event.PacketReceiveEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import dev.rean.pvpcore.PvPCorePlugin;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipPacketListener.class */
public final class PreFightSkipPacketListener implements PacketListener {
    private final PvPCorePlugin plugin;
    private final PreFightSkipManager manager;

    public PreFightSkipPacketListener(PvPCorePlugin plugin, PreFightSkipManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    public void onPacketReceive(PacketReceiveEvent event) {
        UUID playerId;
        if (event.getPacketType() != PacketType.Play.Client.INTERACT_ENTITY) {
            return;
        }
        WrapperPlayClientInteractEntity packet = new WrapperPlayClientInteractEntity(event);
        if (packet.getAction() == WrapperPlayClientInteractEntity.InteractAction.ATTACK && (playerId = event.getUser().getUUID()) != null) {
            int entityId = packet.getEntityId();
            Bukkit.getScheduler().runTask(this.plugin, () -> {
                Player player = Bukkit.getPlayer(playerId);
                if (player == null || !player.isOnline()) {
                    return;
                }
                this.manager.handleHit(player, entityId);
            });
        }
    }
}
