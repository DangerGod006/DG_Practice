package dev.rean.pvpcore.gui;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GuiKey.class */
public enum GuiKey {
    KIT_SELECT,
    DUEL_REQUEST,
    ROUND_SELECT,
    CONFIGURABLE
}
