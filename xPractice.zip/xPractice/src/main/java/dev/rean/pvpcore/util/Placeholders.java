package dev.rean.pvpcore.util;

import java.util.Map;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/util/Placeholders.class */
public final class Placeholders {
    private Placeholders() {
    }

    public static String apply(String s, Map<String, String> map) {
        if (s == null) {
            return "";
        }
        if (map == null || map.isEmpty()) {
            return s;
        }
        String out = s;
        for (Map.Entry<String, String> e : map.entrySet()) {
            out = out.replace("%" + e.getKey() + "%", e.getValue() == null ? "" : e.getValue());
        }
        return out;
    }
}
