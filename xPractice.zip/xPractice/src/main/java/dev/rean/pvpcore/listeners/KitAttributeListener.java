package dev.rean.pvpcore.listeners;

import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.model.Kit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExhaustionEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/listeners/KitAttributeListener.class */
public final class KitAttributeListener implements Listener {
    private final DuelManager duelManager;

    public KitAttributeListener(DuelManager duelManager) {
        this.duelManager = duelManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onNaturalRegen(EntityRegainHealthEvent event) {
        DuelMatch match;
        Kit kit;
        Player entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = entity;
            if (event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED && (match = this.duelManager.getMatch(player.getUniqueId())) != null && (kit = match.kit()) != null && !kit.naturalRegen()) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        Kit kit;
        Player entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = entity;
            DuelMatch match = this.duelManager.getMatch(player.getUniqueId());
            if (match != null && (kit = match.kit()) != null && !kit.naturalSaturationDecrease() && event.getFoodLevel() < player.getFoodLevel()) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onExhaustion(EntityExhaustionEvent event) {
        Kit kit;
        Player entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = entity;
            DuelMatch match = this.duelManager.getMatch(player.getUniqueId());
            if (match != null && (kit = match.kit()) != null && !kit.naturalSaturationDecrease()) {
                event.setExhaustion(0.0f);
            }
        }
    }
}
