package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelManager;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/DuelCommand.class */
public final class DuelCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;
    private final DuelManager duels;

    public DuelCommand(PvPCorePlugin plugin, DuelManager duels) {
        this.plugin = plugin;
        this.duels = duels;
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (args.length == 0) {
            this.plugin.messages().send(commandSender, "commands.duel.usage");
            return true;
        }
        if (args[0].equalsIgnoreCase("spectate") || args[0].equalsIgnoreCase("spec")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "spectators.usage");
                return true;
            }
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                this.plugin.messages().send(commandSender, "duels.offline");
                return true;
            }
            this.plugin.spectatorManager().spectate(commandSender, target);
            return true;
        }
        if (args[0].equalsIgnoreCase("accept")) {
            if (args.length < 2) {
                this.plugin.messages().send(commandSender, "commands.duel.usage-accept");
                return true;
            }
            Player challenger = Bukkit.getPlayer(args[1]);
            if (challenger == null) {
                this.plugin.messages().send(commandSender, "duels.offline");
                return true;
            }
            this.duels.accept(commandSender, challenger);
            return true;
        }
        Player target2 = Bukkit.getPlayer(args[0]);
        if (target2 == null) {
            this.plugin.messages().send(commandSender, "duels.offline");
            return true;
        }
        if (target2.getUniqueId().equals(commandSender.getUniqueId())) {
            this.plugin.messages().send(commandSender, "duels.self");
            return true;
        }
        if (this.duels.isInMatch(commandSender.getUniqueId()) || this.duels.isInMatch(target2.getUniqueId())) {
            this.plugin.messages().send(commandSender, "duels.already-in-match");
            return true;
        }
        this.duels.openDuelSetup(commandSender, target2);
        commandSender.playSound(commandSender, Sound.BLOCK_WOODEN_BUTTON_CLICK_ON, 1.0f, 0.5f);
        return true;
    }
}
