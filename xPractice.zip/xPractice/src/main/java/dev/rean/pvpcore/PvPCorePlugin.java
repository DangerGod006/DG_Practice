package dev.rean.pvpcore;

import dev.rean.pvpcore.arenaeditor.ArenaEditorListener;
import dev.rean.pvpcore.arenaeditor.ArenaEditorManager;
import dev.rean.pvpcore.commands.ArenaCommand;
import dev.rean.pvpcore.commands.DuelCommand;
import dev.rean.pvpcore.commands.DuelToggleCommand;
import dev.rean.pvpcore.commands.FriendCommand;
import dev.rean.pvpcore.commands.KitCommand;
import dev.rean.pvpcore.commands.LeaveCommand;
import dev.rean.pvpcore.commands.MsgCommand;
import dev.rean.pvpcore.commands.NickCommand;
import dev.rean.pvpcore.commands.PvPCoreCommand;
import dev.rean.pvpcore.commands.QueueCommand;
import dev.rean.pvpcore.commands.ReplyCommand;
import dev.rean.pvpcore.commands.SettingsCommand;
import dev.rean.pvpcore.commands.SpectateCommand;
import dev.rean.pvpcore.commands.StatusCommand;
import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.duel.DuelManager;
import dev.rean.pvpcore.effects.DuelVisualEffects;
import dev.rean.pvpcore.fawe.FaweAdapter;
import dev.rean.pvpcore.friends.FriendManager;
import dev.rean.pvpcore.gui.GuiConfigManager;
import dev.rean.pvpcore.gui.GuiListener;
import dev.rean.pvpcore.integrations.TabScoreboardHook;
import dev.rean.pvpcore.kits.KitEditorListener;
import dev.rean.pvpcore.kits.KitEditorManager;
import dev.rean.pvpcore.listeners.DuelChatListener;
import dev.rean.pvpcore.listeners.DuelSafetyListener;
import dev.rean.pvpcore.listeners.KitAttributeListener;
import dev.rean.pvpcore.listeners.PlayerCommandPreprocessListener;
import dev.rean.pvpcore.listeners.PlayerDataListener;
import dev.rean.pvpcore.listeners.PlayerDeathListener;
import dev.rean.pvpcore.listeners.PlayerQuitListener;
import dev.rean.pvpcore.listeners.QueuePlayerListener;
import dev.rean.pvpcore.listeners.SneakStatusListener;
import dev.rean.pvpcore.listeners.SocialVisibilityListener;
import dev.rean.pvpcore.listeners.TotemPopListener;
import dev.rean.pvpcore.lobby.LobbyItemListener;
import dev.rean.pvpcore.lobby.LobbyItemManager;
import dev.rean.pvpcore.managers.ArenaManager;
import dev.rean.pvpcore.managers.KitManager;
import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.managers.Settings;
import dev.rean.pvpcore.managers.SneakStatusManager;
import dev.rean.pvpcore.managers.ToggleManager;
import dev.rean.pvpcore.placeholders.PvPCoreExpansion;
import dev.rean.pvpcore.playerdata.PlayerDataManager;
import dev.rean.pvpcore.prefight.PreFightSkipManager;
import dev.rean.pvpcore.queue.QueueManager;
import dev.rean.pvpcore.spectator.SpectatorManager;
import dev.rean.pvpcore.tiers.TierResolver;
import java.io.File;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/PvPCorePlugin.class */
public final class PvPCorePlugin extends JavaPlugin {
    private static PvPCorePlugin instance;
    private Settings settings;
    private MessageManager messages;
    private PlayerDataManager playerData;
    private ToggleManager toggles;
    private GuiConfigManager guiConfigManager;
    private TabScoreboardHook tabScoreboardHook;
    private TierResolver tierResolver;
    private FriendManager friendManager;
    private SpectatorManager spectatorManager;
    private SneakStatusManager sneakStatusManager;
    private ArenaManager arenaManager;
    private KitManager kitManager;
    private DuelManager duelManager;
    private FaweAdapter fawe;
    private PreFightSkipManager preFightSkipManager;
    private DuelVisualEffects duelVisualEffects;
    private QueueManager queueManager;
    private LobbyItemManager lobbyItems;
    private KitEditorManager kitEditorManager;
    private ArenaEditorManager arenaEditorManager;
    private DisplayTags displayTags;

    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveResourceIfNotExists("messages.yml");
        saveResourceIfNotExists("inventories.yml");
        saveResourceIfNotExists("arenas.yml");
        saveResourceIfNotExists("kits.yml");
        saveResourceIfNotExists("displaytags.yml");
        this.settings = new Settings(this);
        this.messages = new MessageManager(this, this.settings);
        this.playerData = new PlayerDataManager(this);
        this.toggles = new ToggleManager(this.playerData);
        this.guiConfigManager = new GuiConfigManager(this);
        this.tabScoreboardHook = new TabScoreboardHook(this);
        this.tierResolver = new TierResolver(this);
        this.friendManager = new FriendManager(this, this.playerData);
        this.spectatorManager = new SpectatorManager(this);
        this.sneakStatusManager = new SneakStatusManager(this);
        this.fawe = new FaweAdapter(this);
        this.preFightSkipManager = new PreFightSkipManager(this);
        this.duelVisualEffects = new DuelVisualEffects(this);
        this.queueManager = new QueueManager(this);
        this.lobbyItems = new LobbyItemManager(this);
        this.kitEditorManager = new KitEditorManager(this);
        this.arenaEditorManager = new ArenaEditorManager(this);
        boolean packetEventsAvailable = isPacketEventsAvailable();
        if (packetEventsAvailable) {
            this.displayTags = new DisplayTags(this);
        } else {
            this.displayTags = null;
            getLogger().warning("PacketEvents is not installed. DisplayTags packet entities will stay disabled until PacketEvents is present.");
        }
        this.arenaManager = new ArenaManager(this, this.settings, this.messages, this.fawe);
        this.kitManager = new KitManager(this, this.settings, this.messages);
        this.duelManager = new DuelManager(this, this.settings, this.messages, this.arenaManager, this.kitManager, this.toggles);
        this.guiConfigManager.reload();
        this.arenaManager.load();
        this.kitManager.load();
        this.playerData.loadOnlinePlayers();
        registerCommands();
        registerListeners();
        if (this.displayTags != null) {
            this.displayTags.onEnable();
        }
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new PvPCoreExpansion(this).register();
            } catch (Throwable th) {
            }
        }
        registerPacketEventsHook();
        getLogger().info("PvPCore enabled.");
    }

    public void onDisable() {
        if (this.duelManager != null) {
            this.duelManager.forceEndAllMatches();
        }
        if (this.tabScoreboardHook != null) {
            this.tabScoreboardHook.shutdown();
        }
        if (this.spectatorManager != null) {
            this.spectatorManager.shutdown();
        }
        if (this.queueManager != null) {
            this.queueManager.shutdown();
        }
        if (this.displayTags != null) {
            this.displayTags.onDisable();
        }
        if (this.arenaManager != null) {
            this.arenaManager.releaseAll();
        }
        if (this.playerData != null) {
            this.playerData.saveAll();
        }
    }

    public void reloadAll() {
        reloadConfig();
        this.settings.reload();
        this.messages.reload();
        if (this.tierResolver != null) {
            this.tierResolver.reload();
        }
        this.guiConfigManager.reload();
        this.arenaManager.load();
        this.kitManager.load();
        if (this.displayTags != null) {
            this.displayTags.reloadPlugin();
        }
        if (this.playerData != null) {
            this.playerData.loadOnlinePlayers();
        }
    }

    private void registerCommands() {
        requirePluginCommand("pvpcore").setExecutor(new PvPCoreCommand(this));
        requirePluginCommand("settings").setExecutor(new SettingsCommand(this));
        requirePluginCommand("nick").setExecutor(new NickCommand(this));
        requirePluginCommand("name").setExecutor(new NickCommand(this));
        requirePluginCommand("status").setExecutor(new StatusCommand(this));
        requirePluginCommand("msg").setExecutor(new MsgCommand(this));
        requirePluginCommand("reply").setExecutor(new ReplyCommand(this));
        requirePluginCommand("leave").setExecutor(new LeaveCommand(this));
        SpectateCommand spectateCommand = new SpectateCommand(this);
        requirePluginCommand("spectate").setExecutor(spectateCommand);
        requirePluginCommand("spectate").setTabCompleter(spectateCommand);
        FriendCommand friendCommand = new FriendCommand(this);
        requirePluginCommand("friend").setExecutor(friendCommand);
        requirePluginCommand("friend").setTabCompleter(friendCommand);
        requirePluginCommand("friends").setExecutor(friendCommand);
        requirePluginCommand("friends").setTabCompleter(friendCommand);
        requirePluginCommand("duel").setExecutor(new DuelCommand(this, this.duelManager));
        requirePluginCommand("dueltoggle").setExecutor(new DuelToggleCommand(this.messages, this.toggles));
        ArenaCommand arenaCmd = new ArenaCommand(this, this.arenaManager);
        requirePluginCommand("arena").setExecutor(arenaCmd);
        requirePluginCommand("arena").setTabCompleter(arenaCmd);
        KitCommand kitCmd = new KitCommand(this, this.kitManager);
        requirePluginCommand("kit").setExecutor(kitCmd);
        requirePluginCommand("kit").setTabCompleter(kitCmd);
        QueueCommand queueCmd = new QueueCommand(this);
        requirePluginCommand("queue").setExecutor(queueCmd);
        requirePluginCommand("queue").setTabCompleter(queueCmd);
    }

    private boolean isPacketEventsAvailable() {
        return (Bukkit.getPluginManager().getPlugin("PacketEvents") == null && Bukkit.getPluginManager().getPlugin("packetevents") == null) ? false : true;
    }

    private void registerPacketEventsHook() {
        if (!isPacketEventsAvailable()) {
            getLogger().warning("PacketEvents is not installed. Packet-based duel visuals, prefight skip detection, fast crystals, and DisplayTags packet entities will stay disabled.");
            return;
        }
        try {
            Object api = Class.forName("com.github.retrooper.packetevents.PacketEvents").getMethod("getAPI", new Class[0]).invoke(null, new Object[0]);
            Object eventManager = api.getClass().getMethod("getEventManager", new Class[0]).invoke(api, new Object[0]);
            Class<?> priorityClass = Class.forName("com.github.retrooper.packetevents.event.PacketListenerPriority");
            Object normalPriority = Enum.valueOf(priorityClass.asSubclass(Enum.class), "NORMAL");
            Class<?> packetListenerClass = Class.forName("com.github.retrooper.packetevents.event.PacketListener");
            Method registerMethod = eventManager.getClass().getMethod("registerListener", packetListenerClass, priorityClass);
            registerMethod.invoke(eventManager, Class.forName("dev.rean.pvpcore.prefight.PreFightSkipPacketListener").getConstructor(PvPCorePlugin.class, PreFightSkipManager.class).newInstance(this, this.preFightSkipManager), normalPriority);
            registerMethod.invoke(eventManager, Class.forName("dev.rean.pvpcore.packets.FastCrystalPacketListener").getConstructor(PvPCorePlugin.class).newInstance(this), normalPriority);
            getLogger().info("PacketEvents hook enabled for skip barriers and fast crystals.");
        } catch (Throwable t) {
            getLogger().warning("Failed to register the PacketEvents listeners: " + t.getMessage());
        }
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new GuiListener(this, this.duelManager), this);
        Bukkit.getPluginManager().registerEvents(new PlayerDeathListener(this.duelManager), this);
        Bukkit.getPluginManager().registerEvents(new PlayerQuitListener(this.duelManager), this);
        Bukkit.getPluginManager().registerEvents(new QueuePlayerListener(this.queueManager), this);
        Bukkit.getPluginManager().registerEvents(new PlayerCommandPreprocessListener(this.settings, this.duelManager, this.messages), this);
        Bukkit.getPluginManager().registerEvents(new DuelChatListener(this, this.duelManager), this);
        Bukkit.getPluginManager().registerEvents(new KitAttributeListener(this.duelManager), this);
        Bukkit.getPluginManager().registerEvents(new KitEditorListener(this), this);
        Bukkit.getPluginManager().registerEvents(new LobbyItemListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ArenaEditorListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerDataListener(this), this);
        Bukkit.getPluginManager().registerEvents(new SocialVisibilityListener(this), this);
        Bukkit.getPluginManager().registerEvents(new TotemPopListener(this), this);
        Bukkit.getPluginManager().registerEvents(new DuelSafetyListener(this), this);
        Bukkit.getPluginManager().registerEvents(new SneakStatusListener(this), this);
    }

    private PluginCommand requirePluginCommand(String name) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            throw new IllegalStateException("Command not declared in plugin.yml: " + name);
        }
        return command;
    }

    private void saveResourceIfNotExists(String path) {
        if (getResource(path) != null && !new File(getDataFolder(), path).exists()) {
            saveResource(path, false);
        }
    }

    public static PvPCorePlugin getInstance() {
        return instance;
    }

    public Settings settings() {
        return this.settings;
    }

    public GuiConfigManager guiConfig() {
        return this.guiConfigManager;
    }

    public TierResolver tierResolver() {
        return this.tierResolver;
    }

    public FriendManager friendManager() {
        return this.friendManager;
    }

    public SpectatorManager spectatorManager() {
        return this.spectatorManager;
    }

    public SneakStatusManager sneakStatus() {
        return this.sneakStatusManager;
    }

    public MessageManager messages() {
        return this.messages;
    }

    public TabScoreboardHook tabScoreboardHook() {
        return this.tabScoreboardHook;
    }

    public PlayerDataManager playerData() {
        return this.playerData;
    }

    public ArenaManager arenaManager() {
        return this.arenaManager;
    }

    public KitManager kitManager() {
        return this.kitManager;
    }

    public DuelManager duelManager() {
        return this.duelManager;
    }

    public FaweAdapter fawe() {
        return this.fawe;
    }

    public PreFightSkipManager preFightSkipManager() {
        return this.preFightSkipManager;
    }

    public DuelVisualEffects duelVisualEffects() {
        return this.duelVisualEffects;
    }

    public QueueManager queueManager() {
        return this.queueManager;
    }

    public LobbyItemManager lobbyItems() {
        return this.lobbyItems;
    }

    public KitEditorManager kitEditorManager() {
        return this.kitEditorManager;
    }

    public ArenaEditorManager arenaEditorManager() {
        return this.arenaEditorManager;
    }

    public DisplayTags displayTags() {
        return this.displayTags;
    }
}
