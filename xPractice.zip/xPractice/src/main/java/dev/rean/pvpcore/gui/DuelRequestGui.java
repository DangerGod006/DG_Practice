package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.ItemBuilder;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/DuelRequestGui.class */
public final class DuelRequestGui {
    public static void open(PvPCorePlugin plugin, Player sender, Player target, GuiSession session) {
        YamlConfiguration cfg = GenericGui.loadInventories(plugin);
        if (GenericGui.resolveGuiRoot(cfg, "duel-request-gui") != null && cfg.getConfigurationSection("guis") != null) {
            GenericGui.open(plugin, sender, target, session, "duel-request-gui");
            return;
        }
        ConfigurationSection root = cfg.getConfigurationSection("duel-request-gui");
        if (root == null) {
            plugin.messages().send(sender, "gui.missing-duel-request");
            return;
        }
        String titleRaw = root.getString("title", "Duel Request: %target%");
        String title = GenericGui.formatGuiText(plugin, sender, titleRaw, Map.of("target", target.getName(), "target_name", target.getName(), "player", sender.getName(), "player_name", sender.getName(), "owner_uuid", sender.getUniqueId().toString()));
        int size = GenericGui.normalizeInventorySize(root.getInt("size", 27));
        session.setKey(GuiKey.DUEL_REQUEST);
        Inventory inv = Bukkit.createInventory(new ReanMenuHolder(session), size, HexColor.color(title));
        render(plugin, inv, session, root, target.getName());
        sender.openInventory(inv);
    }

    public static void render(PvPCorePlugin plugin, Inventory inv, GuiSession s, ConfigurationSection root, String targetName) {
        inv.clear();
        ConfigurationSection filler = root.getConfigurationSection("filler");
        if (filler != null) {
            Material mat = Material.matchMaterial(filler.getString("material", "BLACK_STAINED_GLASS_PANE"));
            if (mat == null) {
                mat = Material.BLACK_STAINED_GLASS_PANE;
            }
            ItemStack fill = new ItemBuilder(mat).name(filler.getString("name", " ")).build();
            for (int i = 0; i < inv.getSize(); i++) {
                inv.setItem(i, fill);
            }
        }
        ConfigurationSection items = root.getConfigurationSection("items");
        if (items == null) {
            return;
        }
        Player owner = Bukkit.getPlayer(s.owner());
        Map<String, String> ph = Map.of("target", targetName, "target_name", targetName, "kit", s.selectedKit().displayName(), "kit_name", s.selectedKit().displayName(), "kit_id", s.selectedKit().id(), "rounds", String.valueOf(s.firstTo()), "player", owner != null ? owner.getName() : "", "player_name", owner != null ? owner.getName() : "", "owner_uuid", s.owner().toString());
        ItemStack baseIcon = s.selectedKit().icon();
        if (baseIcon == null) {
            baseIcon = new ItemStack(Material.END_CRYSTAL);
        }
        setItem(inv, items.getConfigurationSection("kit"), plugin, ph, null, baseIcon.clone());
        OfflinePlayer target = Bukkit.getOfflinePlayer(s.target());
        setItem(inv, items.getConfigurationSection("opponent"), plugin, ph, target, null);
        setItem(inv, items.getConfigurationSection("rounds"), plugin, ph, null, null);
        setItem(inv, items.getConfigurationSection("arena"), plugin, ph, null, null);
        setItem(inv, items.getConfigurationSection("confirm"), plugin, ph, null, null);
    }

    private static void setItem(Inventory inv, ConfigurationSection sec, PvPCorePlugin plugin, Map<String, String> ph, OfflinePlayer skullOwnerOrNull, ItemStack providedItemOrNull) {
        if (sec == null) {
            return;
        }
        int slot = sec.getInt("slot", 0);
        Material mat = Material.matchMaterial(sec.getString("material", "STONE"));
        if (mat == null) {
            mat = Material.STONE;
        }
        String nameRaw = sec.getString("name", "");
        List<String> loreRaw = sec.getStringList("lore");
        Player owner = resolveOwner(ph);
        String name = GenericGui.formatGuiText(plugin, owner, nameRaw, ph);
        List<String> lore = loreRaw.stream().map(line -> {
            return GenericGui.formatGuiText(plugin, owner, line, ph);
        }).toList();
        ItemStack item = providedItemOrNull != null ? providedItemOrNull : new ItemBuilder(mat).name(name).lore(lore).build();
        if (skullOwnerOrNull != null) {
            item.setType(Material.PLAYER_HEAD);
            SkullMeta meta = Bukkit.getItemFactory().getItemMeta(Material.PLAYER_HEAD);
            if (meta != null) {
                meta.setOwningPlayer(skullOwnerOrNull);
                meta.setDisplayName(HexColor.color(name));
                meta.setLore(lore.stream().map(HexColor::color).toList());
                item.setItemMeta(meta);
            }
        } else {
            ItemMeta meta2 = item.getItemMeta();
            if (meta2 != null) {
                meta2.setDisplayName(HexColor.color(name));
                meta2.setLore(lore.stream().map(HexColor::color).toList());
                item.setItemMeta(meta2);
            }
        }
        inv.setItem(slot, item);
    }

    private static Player resolveOwner(Map<String, String> ph) {
        String ownerUuid = ph.get("owner_uuid");
        if (ownerUuid == null || ownerUuid.isBlank()) {
            return null;
        }
        try {
            return Bukkit.getPlayer(UUID.fromString(ownerUuid));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
