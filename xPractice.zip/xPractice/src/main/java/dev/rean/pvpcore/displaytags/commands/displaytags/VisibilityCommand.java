package dev.rean.pvpcore.displaytags.commands.displaytags;

import dev.rean.pvpcore.displaytags.DisplayTags;
import dev.rean.pvpcore.displaytags.commands.framework.CommandGroup;
import dev.rean.pvpcore.displaytags.commands.framework.Subcommand;
import dev.rean.pvpcore.displaytags.nametags.NametagManager;
import dev.rean.pvpcore.displaytags.utils.helpers.MessageHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/commands/displaytags/VisibilityCommand.class */
public class VisibilityCommand extends Subcommand {
    public VisibilityCommand(DisplayTags plugin, CommandGroup parentCommand) {
        super(plugin, parentCommand);
        super.setName("visibility");
        super.setDescription("Force which config tags are visible for a player.");
        super.setPermission("displaytags.admin");
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.Subcommand
    public void execute(CommandSender sender, String[] args) {
        if (args.length < 2) {
            MessageHelper.error(sender, "Usage: /displaytags visibility <player> <tag-1,tag-2|reset>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            MessageHelper.error(sender, "That player is not online.");
            return;
        }
        NametagManager manager = this.plugin.getNametagManager();
        String raw = args[1].trim();
        if (raw.equalsIgnoreCase("reset") || raw.equalsIgnoreCase("default") || raw.equalsIgnoreCase("clear")) {
            manager.clearForcedVisibleTags(target);
            MessageHelper.success(sender, "Reset forced tag visibility for <white>" + target.getName() + "<green>.");
            return;
        }
        Set<String> requestedTags = (Set) Arrays.stream(raw.split(",")).map((v0) -> {
            return v0.trim();
        }).filter(s -> {
            return !s.isEmpty();
        }).map(s2 -> {
            return s2.toLowerCase(Locale.ROOT);
        }).collect(Collectors.toCollection(LinkedHashSet::new));
        if (requestedTags.isEmpty()) {
            MessageHelper.error(sender, "You must provide at least one tag id from the config.");
            return;
        }
        Set<String> validTags = (Set) this.plugin.config().getNametagConfig().getDisplays().stream().map((v0) -> {
            return v0.getId();
        }).map(id -> {
            return id.toLowerCase(Locale.ROOT);
        }).collect(Collectors.toCollection(LinkedHashSet::new));
        List<String> invalidTags = requestedTags.stream().filter(id2 -> {
            return !validTags.contains(id2);
        }).toList();
        if (!invalidTags.isEmpty()) {
            MessageHelper.error(sender, "Unknown tag ids: <white>" + String.join(", ", invalidTags) + "<red>.");
        } else {
            manager.setForcedVisibleTags(target, requestedTags);
            MessageHelper.success(sender, "Forced visible tags for <white>" + target.getName() + "<green>: <white>" + String.join(", ", requestedTags));
        }
    }

    @Override // dev.rean.pvpcore.displaytags.commands.framework.Subcommand
    public List<String> tabComplete(CommandSender sender, String[] args) {
        if (args.length == 1) {
            String current = args[0].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream().map((v0) -> {
                return v0.getName();
            }).filter(name -> {
                return name.toLowerCase(Locale.ROOT).startsWith(current);
            }).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        }
        if (args.length == 2) {
            String current2 = args[1].toLowerCase(Locale.ROOT);
            List<String> suggestions = new ArrayList<>(this.plugin.config().getNametagConfig().getDisplays().stream().map((v0) -> {
                return v0.getId();
            }).toList());
            suggestions.add("reset");
            suggestions.add("clear");
            suggestions.add("default");
            return suggestions.stream().filter(option -> {
                return option.toLowerCase(Locale.ROOT).startsWith(current2);
            }).toList();
        }
        return List.of();
    }
}
