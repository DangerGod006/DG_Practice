package dev.rean.pvpcore.arenaeditor;

import dev.rean.pvpcore.kits.KitEditorManager;
import dev.rean.pvpcore.model.Arena;
import org.bukkit.Location;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/arenaeditor/ArenaEditorStep.class */
public enum ArenaEditorStep {
    RED_SPAWN("Red Spawn", true),
    BLUE_SPAWN("Blue Spawn", true),
    REGEN("Regen Region", false),
    RED_WALL("Red Wall", false),
    BLUE_WALL("Blue Wall", false),
    RED_FINAL_WALL("Final Red Wall", false),
    BLUE_FINAL_WALL("Final Blue Wall", false);

    private final String displayName;
    private final boolean spawnStep;

    ArenaEditorStep(String displayName, boolean spawnStep) {
        this.displayName = displayName;
        this.spawnStep = spawnStep;
    }

    public String displayName() {
        return this.displayName;
    }

    public boolean isSpawnStep() {
        return this.spawnStep;
    }

    public boolean isRegionStep() {
        return !this.spawnStep;
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: java.lang.MatchException */
    public boolean isCompleted(Arena arena) throws MatchException {
        if (arena == null) {
            return false;
        }
        switch (ordinal()) {
            case KitEditorManager.SLOT_TOP_FILLER_LEFT /* 0 */:
                return arena.redSpawn() != null;
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                return arena.blueSpawn() != null;
            case KitEditorManager.HELMET_SLOT /* 2 */:
                return (arena.min() == null || arena.max() == null) ? false : true;
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                return (arena.wallMin("red") == null || arena.wallMax("red") == null) ? false : true;
            case KitEditorManager.LEGGINGS_SLOT /* 4 */:
                return (arena.wallMin("blue") == null || arena.wallMax("blue") == null) ? false : true;
            case KitEditorManager.BOOTS_SLOT /* 5 */:
                return (arena.finalWallMin("red") == null || arena.finalWallMax("red") == null) ? false : true;
            case KitEditorManager.OFFHAND_SLOT /* 6 */:
                return (arena.finalWallMin("blue") == null || arena.finalWallMax("blue") == null) ? false : true;
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: java.lang.MatchException */
    public Location teleportTarget(Arena arena) throws MatchException {
        if (arena == null) {
            return null;
        }
        switch (ordinal()) {
            case KitEditorManager.SLOT_TOP_FILLER_LEFT /* 0 */:
                return arena.redSpawn();
            case KitEditorManager.SLOT_TOP_FILLER_MIDDLE /* 1 */:
                return arena.blueSpawn();
            case KitEditorManager.HELMET_SLOT /* 2 */:
                return arena.min();
            case KitEditorManager.CHESTPLATE_SLOT /* 3 */:
                return arena.wallMin("red");
            case KitEditorManager.LEGGINGS_SLOT /* 4 */:
                return arena.wallMin("blue");
            case KitEditorManager.BOOTS_SLOT /* 5 */:
                return arena.finalWallMin("red");
            case KitEditorManager.OFFHAND_SLOT /* 6 */:
                return arena.finalWallMin("blue");
            default:
                throw new MatchException((String) null, (Throwable) null);
        }
    }

    public String confirmHint() {
        if (this.spawnStep) {
            return "Shift-click to save your current position";
        }
        return "Shift-click to save your current WorldEdit selection";
    }
}
