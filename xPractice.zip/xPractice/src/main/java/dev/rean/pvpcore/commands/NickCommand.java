package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/NickCommand.class */
public final class NickCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public NickCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (!commandSender.hasPermission("pvpcore.nick")) {
            this.plugin.messages().send(commandSender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            this.plugin.messages().sendMiniMessage(commandSender, "social.error-usage", Map.of());
            return true;
        }
        String input = String.join(" ", args);
        if (input.equalsIgnoreCase("off")) {
            this.plugin.playerData().clearNick(commandSender);
            return true;
        }
        this.plugin.playerData().setNick(commandSender, input);
        return true;
    }
}
