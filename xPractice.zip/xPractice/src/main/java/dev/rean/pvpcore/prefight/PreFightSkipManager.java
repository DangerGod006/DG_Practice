package dev.rean.pvpcore.prefight;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipManager.class */
public final class PreFightSkipManager {
    private final PvPCorePlugin plugin;
    private final Map<UUID, PreFightSkipSequence> sequencesByPlayer = new ConcurrentHashMap();
    private final Map<Integer, PreFightSkipSequence> sequencesByInteractionEntityId = new ConcurrentHashMap();

    public PreFightSkipManager(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public PreFightSkipSequence begin(DuelMatch match, Player red, Player blue) {
        cleanup(match.red());
        cleanup(match.blue());
        PreFightSkipSequence sequence = new PreFightSkipSequence(this.plugin, this, match, red, blue);
        this.sequencesByPlayer.put(match.red(), sequence);
        this.sequencesByPlayer.put(match.blue(), sequence);
        try {
            sequence.spawn();
            return sequence;
        } catch (Throwable t) {
            this.plugin.getLogger().warning("Failed to start duel gates for arena " + (match.arena() == null ? "<null>" : match.arena().id()) + ": " + t.getMessage());
            cleanup(match.red());
            cleanup(match.blue());
            return null;
        }
    }

    public void registerInteractionEntity(int entityId, PreFightSkipSequence sequence) {
        this.sequencesByInteractionEntityId.put(Integer.valueOf(entityId), sequence);
    }

    public void unregisterInteractionEntity(int entityId) {
        this.sequencesByInteractionEntityId.remove(Integer.valueOf(entityId));
    }

    public boolean handleHit(Player player, int entityId) {
        PreFightSkipSequence sequence = this.sequencesByInteractionEntityId.get(Integer.valueOf(entityId));
        if (sequence == null) {
            return false;
        }
        return sequence.handleHit(player, entityId);
    }

    public void cleanup(UUID playerId) {
        PreFightSkipSequence sequence = this.sequencesByPlayer.remove(playerId);
        if (sequence == null) {
            return;
        }
        this.sequencesByPlayer.remove(sequence.match().red(), sequence);
        this.sequencesByPlayer.remove(sequence.match().blue(), sequence);
        sequence.destroy();
    }

    public void onSequenceDestroyed(PreFightSkipSequence sequence) {
        this.sequencesByPlayer.remove(sequence.match().red(), sequence);
        this.sequencesByPlayer.remove(sequence.match().blue(), sequence);
        for (Integer entityId : sequence.registeredInteractionIds()) {
            this.sequencesByInteractionEntityId.remove(entityId, sequence);
        }
    }
}
