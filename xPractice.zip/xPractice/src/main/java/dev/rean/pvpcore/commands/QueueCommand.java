package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.model.Kit;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/QueueCommand.class */
public final class QueueCommand implements CommandExecutor, TabCompleter {
    private final PvPCorePlugin plugin;

    public QueueCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        Player player = (Player) sender;
        if (args.length == 0) {
            this.plugin.queueManager().openQueueMenu(player);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "join":
                if (args.length < 2) {
                    this.plugin.messages().send(player, "queue.usage-join");
                    break;
                } else {
                    Kit kit = this.plugin.kitManager().get(args[1]);
                    if (kit == null) {
                        this.plugin.messages().send(player, "queue.kit-not-found", Map.of("kit_id", args[1]));
                    } else {
                        int rounds = this.plugin.settings().defaultRounds();
                        if (args.length >= 3) {
                            try {
                                rounds = Integer.parseInt(args[2]);
                            } catch (NumberFormatException e) {
                                this.plugin.messages().send(player, "queue.invalid-rounds", Map.of("rounds", args[2]));
                                return true;
                            }
                        }
                        this.plugin.queueManager().toggleQueue(player, kit, rounds);
                    }
                    break;
                }
                break;
            case "leave":
                if (args.length < 2) {
                    this.plugin.messages().send(player, "queue.usage-leave");
                    break;
                } else {
                    if (!this.plugin.queueManager().leave(player.getUniqueId(), args[1])) {
                        this.plugin.messages().send(player, "queue.not-queued", Map.of("kit_id", args[1]));
                    }
                    break;
                }
                break;
            case "leaveall":
                this.plugin.queueManager().leaveAllQuiet(player.getUniqueId());
                break;
            default:
                this.plugin.queueManager().openQueueMenu(player);
                break;
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return partial(args[0], List.of("join", "leave", "leaveall"));
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("join") || args[0].equalsIgnoreCase("leave"))) {
            return partial(args[1], (List) this.plugin.kitManager().list().stream().map((v0) -> {
                return v0.id();
            }).collect(Collectors.toList()));
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("join")) {
            return partial(args[2], List.of("1", "3", "5", "7", "9"));
        }
        return List.of();
    }

    private List<String> partial(String token, List<String> options) {
        String t = token.toLowerCase(Locale.ROOT);
        return options.stream().filter(s -> {
            return s.toLowerCase(Locale.ROOT).startsWith(t);
        }).toList();
    }
}
