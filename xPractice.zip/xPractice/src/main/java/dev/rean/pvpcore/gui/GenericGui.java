package dev.rean.pvpcore.gui;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.managers.ArenaManager;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.model.Kit;
import dev.rean.pvpcore.queue.QueueManager;
import dev.rean.pvpcore.util.HeadTextureUtil;
import dev.rean.pvpcore.util.HexColor;
import dev.rean.pvpcore.util.ItemBuilder;
import dev.rean.pvpcore.util.ItemSerialization;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkEffectMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/gui/GenericGui.class */
public final class GenericGui {
    private GenericGui() {
    }

    public static YamlConfiguration loadInventories(PvPCorePlugin plugin) {
        YamlConfiguration cfg = plugin.guiConfig().config();
        return cfg != null ? cfg : YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "inventories.yml"));
    }

    public static ConfigurationSection resolveGuiRoot(YamlConfiguration cfg, String guiId) {
        ConfigurationSection sec;
        ConfigurationSection guis = cfg.getConfigurationSection("guis");
        return (guis == null || (sec = guis.getConfigurationSection(guiId)) == null) ? cfg.getConfigurationSection(guiId) : sec;
    }

    public static int normalizeInventorySize(int configuredSize) {
        int size = Math.max(9, Math.min(54, configuredSize));
        return ((size + 8) / 9) * 9;
    }

    public static boolean open(PvPCorePlugin plugin, Player viewer, Player target, GuiSession session, String guiId) {
        YamlConfiguration cfg = loadInventories(plugin);
        ConfigurationSection root = resolveGuiRoot(cfg, guiId);
        if (root == null) {
            plugin.messages().send(viewer, "gui.missing-gui", Map.of("gui", guiId));
            return false;
        }
        String titleRaw = root.getString("title", guiId);
        String title = formatGuiText(plugin, viewer, titleRaw, placeholders(plugin, session, target));
        int size = normalizeInventorySize(root.getInt("size", 27));
        session.setKey(GuiKey.CONFIGURABLE);
        if (session.currentGuiId() != null && !session.currentGuiId().equalsIgnoreCase(guiId)) {
            session.pushHistory(session.currentGuiId());
        }
        session.setCurrentGuiId(guiId);
        Inventory inv = Bukkit.createInventory(new ReanMenuHolder(session), size, HexColor.color(title));
        render(plugin, inv, session, root);
        viewer.openInventory(inv);
        return true;
    }

    public static void render(PvPCorePlugin plugin, Inventory inv, GuiSession session, ConfigurationSection root) {
        ItemStack item;
        inv.clear();
        ConfigurationSection filler = root.getConfigurationSection("filler");
        if (filler != null) {
            ItemStack fill = buildConfiguredItem(plugin, filler, placeholders(plugin, session, Bukkit.getPlayer(session.target())));
            if (fill == null) {
                fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
            }
            for (int i = 0; i < inv.getSize(); i++) {
                inv.setItem(i, fill);
            }
        }
        ConfigurationSection items = root.getConfigurationSection("items");
        Map<String, String> ph = placeholders(plugin, session, Bukkit.getPlayer(session.target()));
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection itemSec = items.getConfigurationSection(key);
                if (itemSec != null && shouldRenderItem(plugin, itemSec, session)) {
                    List<Integer> slots = resolveSlots(itemSec, inv.getSize());
                    if (!slots.isEmpty() && (item = buildItemForSession(plugin, itemSec, ph, session)) != null) {
                        for (Integer slot : slots) {
                            if (slot != null && slot.intValue() >= 0 && slot.intValue() < inv.getSize()) {
                                inv.setItem(slot.intValue(), item.clone());
                            }
                        }
                    }
                }
            }
        }
        renderDynamicArenaItems(plugin, inv, session, root);
    }

    public static ItemStack buildItemForSession(PvPCorePlugin plugin, ConfigurationSection sec, Map<String, String> ph, GuiSession session) {
        Arena arena;
        ItemStack base;
        ItemStack base2;
        String guiText;
        String skullTarget = sec.getString("skull-owner", "");
        if (skullTarget != null && !skullTarget.isBlank()) {
            if ("%target%".equalsIgnoreCase(skullTarget)) {
                guiText = Bukkit.getOfflinePlayer(session.target()).getName();
            } else {
                guiText = formatGuiText(plugin, Bukkit.getPlayer(session.owner()), skullTarget, ph);
            }
            String resolvedSkullTarget = guiText;
            String resolvedMaterial = formatGuiText(plugin, Bukkit.getPlayer(session.owner()), sec.getString("material", ""), ph);
            if ((resolvedSkullTarget == null || resolvedSkullTarget.isBlank()) && "AIR".equalsIgnoreCase(resolvedMaterial)) {
                return null;
            }
            ItemStack skull = buildConfiguredItem(plugin, sec, ph);
            if (skull == null || skull.getType().isAir()) {
                skull = new ItemStack(Material.PLAYER_HEAD);
            }
            skull.setType(Material.PLAYER_HEAD);
            SkullMeta meta = Bukkit.getItemFactory().getItemMeta(Material.PLAYER_HEAD);
            if (meta != null) {
                if (resolvedSkullTarget != null && !resolvedSkullTarget.isBlank()) {
                    meta.setOwningPlayer(Bukkit.getOfflinePlayer(resolvedSkullTarget));
                }
                String name = sec.getString("name");
                if (name != null) {
                    meta.setDisplayName(formatGuiText(plugin, Bukkit.getPlayer(session.owner()), name, ph));
                }
                List<String> lore = sec.getStringList("lore");
                if (!lore.isEmpty()) {
                    meta.setLore((List) lore.stream().map(line -> {
                        return formatGuiText(plugin, Bukkit.getPlayer(session.owner()), line, ph);
                    }).collect(Collectors.toList()));
                }
                skull.setItemMeta(meta);
            }
            return skull;
        }
        String dynamic = sec.getString("dynamic", "");
        if ("selected-kit-icon".equalsIgnoreCase(dynamic)) {
            Kit kit = session.selectedKit();
            ItemStack base3 = kit != null ? kit.icon() : null;
            if (base3 == null || base3.getType().isAir()) {
                base2 = buildConfiguredItem(plugin, sec, ph);
            } else {
                base2 = base3.clone();
                applyDisplayOverrides(plugin, base2, sec, ph);
            }
            return base2;
        }
        if ("selected-arena-icon".equalsIgnoreCase(dynamic) || "arena".equalsIgnoreCase(dynamic) || "selected-arena".equalsIgnoreCase(dynamic)) {
            ItemStack base4 = plugin.arenaManager().getArenaOrCategoryIcon(session.selectedArena());
            if ((base4 == null || base4.getType().isAir()) && (arena = plugin.arenaManager().get(session.selectedArena())) != null && arena.icon() != null) {
                base4 = arena.icon();
            }
            if (base4 == null || base4.getType().isAir()) {
                base = buildConfiguredItem(plugin, sec, ph);
            } else {
                base = base4.clone();
                applyDisplayOverrides(plugin, base, sec, ph);
            }
            return base;
        }
        return buildConfiguredItem(plugin, sec, ph);
    }

    public static ItemStack buildConfiguredItem(PvPCorePlugin plugin, ConfigurationSection sec, Map<String, String> ph) {
        if (sec == null) {
            return null;
        }
        String serialized = sec.getString("serialized");
        if (serialized != null && !serialized.isBlank()) {
            try {
                ItemSerialization.InventoryData data = ItemSerialization.deserialize(serialized);
                if (data.contents().length > 0 && data.contents()[0] != null) {
                    ItemStack item = data.contents()[0].clone();
                    applyDisplayOverrides(plugin, item, sec, ph);
                    return item;
                }
            } catch (Throwable th) {
            }
        }
        ConfigurationSection itemSec = sec.getConfigurationSection("item");
        if (itemSec != null) {
            sec = itemSec;
        }
        String materialName = formatGuiText(plugin, null, sec.getString("material", "STONE"), ph);
        Material mat = Material.matchMaterial(materialName);
        if (mat == null) {
            mat = Material.STONE;
        }
        int amount = Math.max(1, Math.min(64, sec.getInt("amount", 1)));
        ItemStack item2 = new ItemStack(mat, amount);
        ItemMeta meta = item2.getItemMeta();
        if (meta == null) {
            return item2;
        }
        String name = resolveDisplayName(plugin, sec, ph);
        if (name != null) {
            meta.setDisplayName(name);
        }
        List<String> lore = sec.getStringList("lore");
        if (!lore.isEmpty()) {
            meta.setLore((List) lore.stream().map(line -> {
                return formatGuiText(plugin, null, line, ph);
            }).collect(Collectors.toList()));
        }
        if (sec.contains("custom-model-data")) {
            meta.setCustomModelData(Integer.valueOf(sec.getInt("custom-model-data")));
        }
        applyRgb(meta, sec.getString("rgb", sec.getString("color-rgb", (String) null)));
        if (sec.getBoolean("glow", false)) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
        }
        List<String> resolvedFlags = new ArrayList<>(sec.getStringList("flags"));
        if (sec.isList("hide_flags")) {
            resolvedFlags.addAll(sec.getStringList("hide_flags"));
        }
        if (sec.isList("item_flags")) {
            resolvedFlags.addAll(sec.getStringList("item_flags"));
        }
        for (String rawFlag : resolvedFlags) {
            try {
                meta.addItemFlags(new ItemFlag[]{ItemFlag.valueOf(rawFlag.toUpperCase(Locale.ROOT))});
            } catch (IllegalArgumentException e) {
            }
        }
        item2.setItemMeta(meta);
        applyConfiguredHead(plugin, item2, sec, ph);
        ConfigurationSection enchSec = sec.getConfigurationSection("enchants");
        if (enchSec != null) {
            for (String enchKey : enchSec.getKeys(false)) {
                Enchantment enchantment = Enchantment.getByName(enchKey.toUpperCase(Locale.ROOT));
                if (enchantment != null) {
                    item2.addUnsafeEnchantment(enchantment, Math.max(1, enchSec.getInt(enchKey, 1)));
                }
            }
        }
        return item2;
    }

    private static void applyConfiguredHead(PvPCorePlugin plugin, ItemStack item, ConfigurationSection sec, Map<String, String> ph) {
        String resolvedValue;
        if (item == null || item.getType() != Material.PLAYER_HEAD) {
            return;
        }
        String rawValue = sec.getString("value", (String) null);
        if (rawValue == null || rawValue.isBlank()) {
            rawValue = sec.getString("head", (String) null);
        }
        if (rawValue == null || rawValue.isBlank()) {
            rawValue = sec.getString("skull", (String) null);
        }
        if (rawValue == null || rawValue.isBlank()) {
            rawValue = sec.getString("texture", (String) null);
        }
        if (rawValue == null || rawValue.isBlank()) {
            rawValue = sec.getString("textures", (String) null);
        }
        if (rawValue == null || rawValue.isBlank() || rawValue.equalsIgnoreCase("VALUE") || (resolvedValue = formatGuiText(plugin, null, rawValue.trim(), ph)) == null || resolvedValue.isBlank() || resolvedValue.equalsIgnoreCase("VALUE")) {
            return;
        }
        HeadTextureUtil.applyValue(item, resolvedValue);
    }

    private static void applyDisplayOverrides(PvPCorePlugin plugin, ItemStack item, ConfigurationSection sec, Map<String, String> ph) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        String resolvedName = resolveDisplayName(plugin, sec, ph);
        if (resolvedName != null) {
            meta.setDisplayName(resolvedName);
        }
        if (sec.contains("lore")) {
            meta.setLore((List) sec.getStringList("lore").stream().map(line -> {
                return formatGuiText(plugin, null, line, ph);
            }).collect(Collectors.toList()));
        }
        if (sec.contains("custom-model-data")) {
            meta.setCustomModelData(Integer.valueOf(sec.getInt("custom-model-data")));
        }
        applyRgb(meta, sec.getString("rgb", sec.getString("color-rgb", (String) null)));
        if (sec.getBoolean("glow", false)) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
        }
        List<String> resolvedFlags = new ArrayList<>(sec.getStringList("flags"));
        if (sec.isList("hide_flags")) {
            resolvedFlags.addAll(sec.getStringList("hide_flags"));
        }
        if (sec.isList("item_flags")) {
            resolvedFlags.addAll(sec.getStringList("item_flags"));
        }
        for (String rawFlag : resolvedFlags) {
            try {
                meta.addItemFlags(new ItemFlag[]{ItemFlag.valueOf(rawFlag.toUpperCase(Locale.ROOT))});
            } catch (IllegalArgumentException e) {
            }
        }
        item.setItemMeta(meta);
    }

    public static boolean shouldRenderItem(PvPCorePlugin plugin, ConfigurationSection sec, GuiSession session) {
        if (sec == null) {
            return false;
        }
        List<String> configuredActions = new ArrayList<>();
        String singleAction = sec.getString("action");
        if (singleAction != null && !singleAction.isBlank()) {
            configuredActions.add(singleAction);
        }
        if (sec.isList("actions")) {
            configuredActions.addAll(sec.getStringList("actions"));
        }
        if (sec.isList("actions-left")) {
            configuredActions.addAll(sec.getStringList("actions-left"));
        }
        if (sec.isList("actions-right")) {
            configuredActions.addAll(sec.getStringList("actions-right"));
        }
        for (String action : configuredActions) {
            if (action != null && !action.isBlank()) {
                String upper = action.toUpperCase(Locale.ROOT);
                if (upper.startsWith("[SELECT_ARENA]")) {
                    String selection = action.substring(action.indexOf(93) + 1).trim().toLowerCase(Locale.ROOT);
                    if (selection.isBlank()) {
                        return true;
                    }
                    Kit kit = session.selectedKit();
                    if (session.context() == GuiContext.QUEUE) {
                        return plugin.arenaManager().findAvailable(selection, kit).isPresent();
                    }
                    return plugin.arenaManager().findAvailableIgnoringBlacklist(selection).isPresent();
                }
            }
        }
        return true;
    }

    private static void renderDynamicArenaItems(PvPCorePlugin plugin, Inventory inv, GuiSession session, ConfigurationSection root) {
        ConfigurationSection arenaItem;
        List<ArenaManager.ArenaOption> arenaOptionsIgnoringBlacklist;
        if (root == null || (arenaItem = root.getConfigurationSection("arena-item")) == null) {
            return;
        }
        String dynamic = arenaItem.getString("dynamic", "");
        if ("arena-icon".equalsIgnoreCase(dynamic)) {
            List<Integer> slots = resolveArenaSlots(root, inv.getSize());
            if (slots.isEmpty()) {
                return;
            }
            if (session.context() == GuiContext.QUEUE) {
                arenaOptionsIgnoringBlacklist = plugin.arenaManager().getArenaOptions(session.selectedKit(), session.selectedArena());
            } else {
                arenaOptionsIgnoringBlacklist = plugin.arenaManager().getArenaOptionsIgnoringBlacklist(session.selectedArena());
            }
            List<ArenaManager.ArenaOption> options = arenaOptionsIgnoringBlacklist;
            Map<String, String> base = placeholders(plugin, session, Bukkit.getPlayer(session.target()));
            for (int i = 0; i < slots.size(); i++) {
                int slot = slots.get(i).intValue();
                if (slot >= 0 && slot < inv.getSize()) {
                    if (i >= options.size()) {
                        inv.setItem(slot, (ItemStack) null);
                    } else {
                        ArenaManager.ArenaOption option = options.get(i);
                        Map<String, String> ph = new HashMap<>(base);
                        ph.put("arena", option.id());
                        ph.put("arena_id", option.id());
                        ph.put("arena_name", option.displayName());
                        ph.put("selected_arena", option.id());
                        ph.put("selected_arena_id", option.id());
                        ph.put("selected_arena_name", option.displayName());
                        ItemStack item = buildDynamicArenaItem(plugin, arenaItem, ph, option);
                        if (item != null) {
                            inv.setItem(slot, item);
                        } else {
                            inv.setItem(slot, (ItemStack) null);
                        }
                    }
                }
            }
        }
    }

    public static List<Integer> resolveArenaSlots(ConfigurationSection root, int inventorySize) {
        List<Integer> result = new ArrayList<>();
        if (root == null) {
            return result;
        }
        if (root.isList("arena-slots")) {
            for (Object raw : root.getList("arena-slots", Collections.emptyList())) {
                Integer parsed = parseSlot(raw);
                if (parsed != null && parsed.intValue() >= 0 && parsed.intValue() < inventorySize && !result.contains(parsed)) {
                    result.add(parsed);
                }
            }
        }
        String inline = root.getString("arena-slots");
        if (inline != null && !inline.isBlank()) {
            for (String split : inline.split(",")) {
                Integer parsed2 = parseSlot(split.trim());
                if (parsed2 != null && parsed2.intValue() >= 0 && parsed2.intValue() < inventorySize && !result.contains(parsed2)) {
                    result.add(parsed2);
                }
            }
        }
        return result;
    }

    private static ItemStack buildDynamicArenaItem(PvPCorePlugin plugin, ConfigurationSection sec, Map<String, String> ph, ArenaManager.ArenaOption option) {
        ItemStack base;
        ItemStack base2 = option.icon();
        if (base2 == null || base2.getType().isAir()) {
            base = buildConfiguredItem(plugin, sec, ph);
        } else {
            base = base2.clone();
            applyDisplayOverrides(plugin, base, sec, ph);
        }
        return base;
    }

    public static List<Integer> resolveSlots(ConfigurationSection sec, int inventorySize) {
        Integer parsed;
        List<Integer> result = new ArrayList<>();
        if (sec == null) {
            return result;
        }
        if (sec.isList("slots")) {
            for (Object raw : sec.getList("slots", Collections.emptyList())) {
                Integer parsed2 = parseSlot(raw);
                if (parsed2 != null && parsed2.intValue() >= 0 && parsed2.intValue() < inventorySize && !result.contains(parsed2)) {
                    result.add(parsed2);
                }
            }
        }
        String slotsInline = sec.getString("slots");
        if (slotsInline != null && !slotsInline.isBlank()) {
            for (String split : slotsInline.split(",")) {
                Integer parsed3 = parseSlot(split.trim());
                if (parsed3 != null && parsed3.intValue() >= 0 && parsed3.intValue() < inventorySize && !result.contains(parsed3)) {
                    result.add(parsed3);
                }
            }
        }
        if (result.isEmpty() && sec.contains("slot") && (parsed = parseSlot(sec.get("slot"))) != null && parsed.intValue() >= 0 && parsed.intValue() < inventorySize) {
            result.add(parsed);
        }
        return result;
    }

    private static Integer parseSlot(Object raw) {
        if (raw == null) {
            return null;
        }
        if (raw instanceof Number) {
            Number number = (Number) raw;
            return Integer.valueOf(number.intValue());
        }
        try {
            return Integer.valueOf(Integer.parseInt(String.valueOf(raw).trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String resolveDisplayName(PvPCorePlugin plugin, ConfigurationSection sec, Map<String, String> ph) {
        if (sec.contains("name")) {
            return formatGuiText(plugin, null, sec.getString("name", ""), ph);
        }
        if (sec.contains("display_name")) {
            return formatGuiText(plugin, null, sec.getString("display_name", ""), ph);
        }
        String nameColor = sec.getString("name-color", "").trim();
        if (nameColor.isEmpty()) {
            return null;
        }
        String displayBase = ph.getOrDefault("arena_name", ph.getOrDefault("kit_name", ""));
        String explicitBase = sec.getString("display-name-base", "").trim();
        if (!explicitBase.isEmpty()) {
            displayBase = formatGuiText(plugin, null, explicitBase, ph);
        }
        if (displayBase.isEmpty()) {
            return null;
        }
        return formatGuiText(plugin, null, nameColor + displayBase, ph);
    }

    private static void applyRgb(ItemMeta meta, String rawRgb) {
        FireworkEffect effect;
        if (meta == null || rawRgb == null || rawRgb.isBlank()) {
            return;
        }
        String cleaned = rawRgb.trim().replace("(", "").replace(")", "");
        String[] split = cleaned.split(",");
        if (split.length != 3) {
            return;
        }
        try {
            int red = Math.max(0, Math.min(255, Integer.parseInt(split[0].trim())));
            int green = Math.max(0, Math.min(255, Integer.parseInt(split[1].trim())));
            int blue = Math.max(0, Math.min(255, Integer.parseInt(split[2].trim())));
            Color color = Color.fromRGB(red, green, blue);
            if (meta instanceof LeatherArmorMeta) {
                LeatherArmorMeta leatherArmorMeta = (LeatherArmorMeta) meta;
                leatherArmorMeta.setColor(color);
                return;
            }
            if (meta instanceof PotionMeta) {
                PotionMeta potionMeta = (PotionMeta) meta;
                potionMeta.setColor(color);
                return;
            }
            if (meta instanceof FireworkEffectMeta) {
                FireworkEffectMeta fireworkEffectMeta = (FireworkEffectMeta) meta;
                if (fireworkEffectMeta.hasEffect()) {
                    FireworkEffect current = fireworkEffectMeta.getEffect();
                    effect = FireworkEffect.builder().with(current.getType()).flicker(current.hasFlicker()).trail(current.hasTrail()).withColor(color).withFade(current.getFadeColors()).build();
                } else {
                    effect = FireworkEffect.builder().withColor(color).build();
                }
                fireworkEffectMeta.setEffect(effect);
            }
        } catch (NumberFormatException e) {
        }
    }

    public static String formatGuiText(PvPCorePlugin plugin, Player viewer, String input, Map<String, String> local) {
        if (local == null) {
            local = Map.of();
        }
        Player resolvedViewer = viewer;
        if (resolvedViewer == null) {
            String ownerUuid = local.getOrDefault("owner_uuid", "");
            if (!ownerUuid.isBlank()) {
                try {
                    resolvedViewer = Bukkit.getPlayer(UUID.fromString(ownerUuid));
                } catch (IllegalArgumentException e) {
                }
            }
        }
        String out = plugin.messages().format(input, local);
        if (resolvedViewer != null) {
            String selectedKitId = local.getOrDefault("kit_id", "");
            if (!selectedKitId.isBlank()) {
                boolean queuedSelected = plugin.queueManager().isQueued(resolvedViewer.getUniqueId(), selectedKitId);
                out = out.replace("%queued%", queuedSelected ? "&9(Queued)" : "").replace("%queueboolean%", queuedSelected ? "&c◀ Click to leave!" : "&e▶ Click to play!").replace("%inqueue%", String.valueOf(plugin.queueManager().countInQueue(selectedKitId))).replace("%playing%", String.valueOf(plugin.duelManager().countQueuedAndPlaying(selectedKitId))).replace("%pvpcore_inqueue%", String.valueOf(plugin.queueManager().countInQueue(selectedKitId))).replace("%pvpcore_playing%", String.valueOf(plugin.duelManager().countQueuedAndPlaying(selectedKitId))).replace("%queued_" + selectedKitId + "%", queuedSelected ? "&9(Queued)" : "").replace("%queueboolean_" + selectedKitId + "%", queuedSelected ? "&c◀ Click to leave!" : "&e▶ Click to play!").replace("%inqueue_" + selectedKitId + "%", String.valueOf(plugin.queueManager().countInQueue(selectedKitId))).replace("%playing_" + selectedKitId + "%", String.valueOf(plugin.duelManager().countQueuedAndPlaying(selectedKitId))).replace("%pvpcore_inqueue_" + selectedKitId + "%", String.valueOf(plugin.queueManager().countInQueue(selectedKitId))).replace("%pvpcore_playing_" + selectedKitId + "%", String.valueOf(plugin.duelManager().countQueuedAndPlaying(selectedKitId)));
            } else {
                out = out.replace("%queued%", "").replace("%queueboolean%", "&e▶ Click to play!").replace("%inqueue%", "0").replace("%playing%", "0").replace("%pvpcore_inqueue%", "0").replace("%pvpcore_playing%", "0");
            }
            for (Kit kit : plugin.kitManager().list()) {
                boolean queued = plugin.queueManager().isQueued(resolvedViewer.getUniqueId(), kit.id());
                String inQueue = String.valueOf(plugin.queueManager().countInQueue(kit.id()));
                String playing = String.valueOf(plugin.duelManager().countQueuedAndPlaying(kit.id()));
                out = out.replace("%queued_" + kit.id() + "%", queued ? "&9(Queued)" : "").replace("%queueboolean_" + kit.id() + "%", queued ? "&c◀ Click to leave!" : "&e▶ Click to play!").replace("%inqueue_" + kit.id() + "%", inQueue).replace("%playing_" + kit.id() + "%", playing).replace("%pvpcore_inqueue_" + kit.id() + "%", inQueue).replace("%pvpcore_playing_" + kit.id() + "%", playing);
            }
            Map<String, String> social = plugin.playerData().guiPlaceholders(resolvedViewer);
            for (Map.Entry<String, String> entry : social.entrySet()) {
                out = out.replace("%" + entry.getKey() + "%", entry.getValue() == null ? "" : entry.getValue());
            }
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                try {
                    out = PlaceholderAPI.setPlaceholders(resolvedViewer, out);
                } catch (Throwable th) {
                }
            }
        }
        return HexColor.color(out);
    }

    public static Map<String, String> placeholders(PvPCorePlugin plugin, GuiSession session, Player target) {
        Map<String, String> ph = new HashMap<>();
        ph.put("target", target != null ? target.getName() : "Unknown");
        ph.put("target_name", target != null ? target.getName() : "Unknown");
        ph.put("kit", session.selectedKit() != null ? session.selectedKit().displayName() : "None");
        ph.put("kit_name", session.selectedKit() != null ? session.selectedKit().displayName() : "None");
        ph.put("kit_id", session.selectedKit() != null ? session.selectedKit().id() : "");
        ph.put("rounds", String.valueOf(session.firstTo()));
        ph.put("first_to", String.valueOf(session.firstTo()));
        String selectedArenaId = session.selectedArena();
        String selectedArenaName = plugin.arenaManager().getSelectionDisplayName(selectedArenaId);
        ph.put("arena", selectedArenaId);
        ph.put("arena_id", selectedArenaId);
        ph.put("selected_arena", selectedArenaId);
        ph.put("selected_arena_id", selectedArenaId);
        ph.put("selected_arena_name", selectedArenaName);
        ph.put("arena_name", selectedArenaName);
        ph.put("gui", session.currentGuiId() == null ? "" : session.currentGuiId());
        ph.put("context", session.context().name().toLowerCase(Locale.ROOT));
        ph.put("owner_uuid", session.owner().toString());
        if (session.selectedKit() != null) {
            ph.put("inqueue", String.valueOf(plugin.queueManager().countInQueue(session.selectedKit().id())));
            ph.put("playing", String.valueOf(plugin.duelManager().countQueuedAndPlaying(session.selectedKit().id())));
        } else {
            ph.put("inqueue", "0");
            ph.put("playing", "0");
        }
        QueueManager.QueueStats queueStats = plugin.queueManager().getStats(session.owner());
        ph.put("queue_modes", String.valueOf(queueStats.modeCount()));
        ph.put("queue_wait", String.valueOf(queueStats.waitSeconds()));
        ph.put("queue_wait_formatted", plugin.queueManager().formatWaitTime(queueStats.waitSeconds()));
        Player ownerPlayer = Bukkit.getPlayer(session.owner());
        if (ownerPlayer != null) {
            ph.putAll(plugin.playerData().guiPlaceholders(ownerPlayer));
        } else {
            ph.put("pvpcore_displayname", "");
            ph.put("pvpcore_displayname_raw", "");
            ph.put("pvpcore_status", "&a");
            ph.put("pvpcore_status_name", "Online");
            ph.put("pvpcore_duels_enabled", "true");
            ph.put("pvpcore_duels_state", "&aEnabled");
            ph.put("pvpcore_duels_toggle", "&cClick to disable");
        }
        return ph;
    }
}
