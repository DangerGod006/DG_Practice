package dev.rean.pvpcore.displaytags.config;

import dev.rean.pvpcore.displaytags.DisplayTags;
import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/config/DisplayTagsConfig.class */
public class DisplayTagsConfig {
    private final DisplayTags plugin;
    private final NametagConfig nametagConfig;

    public DisplayTagsConfig(DisplayTags plugin) {
        this.plugin = plugin;
        this.nametagConfig = new NametagConfig(plugin);
    }

    public void load() {
        this.nametagConfig.load();
    }

    public void reload() throws IOException, InvalidConfigurationException {
        File file = new File(this.plugin.getDataFolder(), "displaytags.yml");
        FileConfiguration yamlConfiguration = new YamlConfiguration();
        yamlConfiguration.load(file);
        this.nametagConfig.load(yamlConfiguration);
    }

    public NametagConfig getNametagConfig() {
        return this.nametagConfig;
    }
}
