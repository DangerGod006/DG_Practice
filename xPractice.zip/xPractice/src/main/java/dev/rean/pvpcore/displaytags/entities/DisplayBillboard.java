package dev.rean.pvpcore.displaytags.entities;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/displaytags/entities/DisplayBillboard.class */
public enum DisplayBillboard {
    FIXED(0),
    VERTICAL(1),
    HORIZONTAL(2),
    CENTER(3);

    public final int value;

    DisplayBillboard(int value) {
        this.value = value;
    }
}
