package dev.rean.pvpcore.prefight;

import dev.rean.pvpcore.PvPCorePlugin;
import dev.rean.pvpcore.duel.DuelMatch;
import dev.rean.pvpcore.managers.MessageManager;
import dev.rean.pvpcore.model.Arena;
import dev.rean.pvpcore.util.TitleFormat;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipSequence.class */
public final class PreFightSkipSequence {
    private static final boolean[][] PATTERN = {new boolean[]{true, true, true, true, true, true}, new boolean[]{true, true, true, true, true, true}, new boolean[]{true, true, true, true, true, true}, new boolean[]{true, true, true, true, true, true}, new boolean[]{true, true, true, true, true, true}, new boolean[]{true, true, true, true, true, true}};
    private final PvPCorePlugin plugin;
    private final PreFightSkipManager manager;
    private final DuelMatch match;
    private final MessageManager messages;
    private final Arena arena;
    private final UUID redId;
    private final UUID blueId;
    private final List<GatePiece> redPieces = new ArrayList();
    private final List<GatePiece> bluePieces = new ArrayList();
    private final Set<Integer> registeredInteractionIds = new HashSet();
    private final Map<BlockKey, StoredBlock> activeBarrierBlocks = new HashMap();
    private BukkitTask countdownTask;
    private BukkitTask liftTask;
    private BukkitTask returnTask;
    private volatile boolean redConfirmed;
    private volatile boolean blueConfirmed;
    private volatile boolean lifting;
    private volatile boolean fightStarted;
    private volatile boolean destroyed;

    public PreFightSkipSequence(PvPCorePlugin plugin, PreFightSkipManager manager, DuelMatch match, Player red, Player blue) {
        this.plugin = plugin;
        this.manager = manager;
        this.match = match;
        this.messages = plugin.messages();
        this.arena = match.arena();
        this.redId = red.getUniqueId();
        this.blueId = blue.getUniqueId();
    }

    public DuelMatch match() {
        return this.match;
    }

    public Set<Integer> registeredInteractionIds() {
        return Collections.unmodifiableSet(this.registeredInteractionIds);
    }

    public void spawn() {
        if (this.destroyed) {
            return;
        }
        Player red = Bukkit.getPlayer(this.redId);
        Player blue = Bukkit.getPlayer(this.blueId);
        if (red == null || blue == null) {
            destroy();
            return;
        }
        this.redPieces.addAll(createWallFor(red, "red"));
        this.bluePieces.addAll(createWallFor(blue, "blue"));
        placeInitialBarrierWall();
        playToBoth(Sound.ENTITY_BREEZE_SHOOT, 1.0f, 1.0f);
        startCountdown();
    }

    public boolean handleHit(Player player, int entityId) {
        if (this.destroyed || this.lifting) {
            return false;
        }
        if (!player.getUniqueId().equals(this.redId) && !player.getUniqueId().equals(this.blueId)) {
            return false;
        }
        boolean ownWall = ownsEntity(player.getUniqueId(), entityId);
        if (!ownWall) {
            return false;
        }
        if (player.getUniqueId().equals(this.redId)) {
            if (this.redConfirmed) {
                return true;
            }
            this.redConfirmed = true;
        } else {
            if (this.blueConfirmed) {
                return true;
            }
            this.blueConfirmed = true;
        }
        player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, 1.0f, 0.95f);
        sendReadyActionBar(player);
        if (this.redConfirmed && this.blueConfirmed) {
            beginFightIfNeeded(true);
            triggerLift(true);
            return true;
        }
        return true;
    }

    private int getConfirmedCount() {
        int count = 0;
        if (this.redConfirmed) {
            count = 0 + 1;
        }
        if (this.blueConfirmed) {
            count++;
        }
        return count;
    }

    private boolean ownsEntity(UUID playerId, int entityId) {
        List<GatePiece> pieces = playerId.equals(this.redId) ? this.redPieces : this.bluePieces;
        for (GatePiece piece : pieces) {
            if (piece.interactionId == entityId) {
                return true;
            }
        }
        return false;
    }

    private List<GatePiece> createWallFor(Player player, String side) {
        List<GatePiece> pieces = new ArrayList<>();
        BlockData fenceData = createFenceData(side);
        Vector interactionOffset = computeInteractionOffset(player, side);
        if (this.arena != null && this.arena.hasWall(side)) {
            Location wallMin = this.arena.wallMin(side);
            Location wallMax = this.arena.wallMax(side);
            if (isValidWallRegion(wallMin, wallMax)) {
                int minX = Math.min(wallMin.getBlockX(), wallMax.getBlockX());
                int maxX = Math.max(wallMin.getBlockX(), wallMax.getBlockX());
                int minY = Math.min(wallMin.getBlockY(), wallMax.getBlockY());
                int maxY = Math.max(wallMin.getBlockY(), wallMax.getBlockY());
                int minZ = Math.min(wallMin.getBlockZ(), wallMax.getBlockZ());
                int maxZ = Math.max(wallMin.getBlockZ(), wallMax.getBlockZ());
                int dx = 0;
                int dy = computeFallbackTargetDeltaY();
                int dz = 0;
                if (isValidWallRegion(this.arena.finalWallMin(side), this.arena.finalWallMax(side))) {
                    Location finalWallMin = this.arena.finalWallMin(side);
                    dx = finalWallMin.getBlockX() - minX;
                    dy = finalWallMin.getBlockY() - minY;
                    dz = finalWallMin.getBlockZ() - minZ;
                }
                for (int x = minX; x <= maxX; x++) {
                    for (int y = minY; y <= maxY; y++) {
                        for (int z = minZ; z <= maxZ; z++) {
                            Location start = new Location(wallMin.getWorld(), x, y, z);
                            Location target = new Location(wallMin.getWorld(), x + dx, y + dy, z + dz);
                            pieces.add(spawnGatePiece(player, fenceData, start, target, interactionOffset));
                        }
                    }
                }
                if (!pieces.isEmpty()) {
                    return pieces;
                }
            }
        }
        Location anchor = buildAnchor(player);
        Vector forwardFlat = player.getLocation().getDirection().clone();
        forwardFlat.setY(0);
        if (forwardFlat.lengthSquared() < 1.0E-4d) {
            forwardFlat.setX(0);
            forwardFlat.setZ(-1);
        }
        forwardFlat.normalize();
        Vector right = new Vector(-forwardFlat.getZ(), 0.0d, forwardFlat.getX()).normalize();
        int deltaY = computeFallbackTargetDeltaY();
        for (int row = 0; row < PATTERN.length; row++) {
            for (int col = 0; col < PATTERN[row].length; col++) {
                if (PATTERN[row][col]) {
                    double xOffset = (((double) col) - 2.5d) + 0.5d;
                    double yOffset = row;
                    Location start2 = anchor.clone().add(right.clone().multiply(xOffset)).add(0.0d, yOffset, 0.0d);
                    start2.setX(Math.floor(start2.getX()));
                    start2.setY(Math.floor(start2.getY()));
                    start2.setZ(Math.floor(start2.getZ()));
                    Location target2 = start2.clone().add(0.0d, deltaY, 0.0d);
                    pieces.add(spawnGatePiece(player, fenceData, start2, target2, interactionOffset));
                }
            }
        }
        return pieces;
    }

    private boolean isValidWallRegion(Location min, Location max) {
        return (min == null || max == null || min.getWorld() == null || max.getWorld() == null || !min.getWorld().equals(max.getWorld())) ? false : true;
    }

    private void placeInitialBarrierWall() {
        syncBarrierBlocks(this.activeBarrierBlocks, collectStartWallLocations());
    }

    private Set<BlockKey> collectStartWallLocations() {
        Set<BlockKey> keys = new HashSet<>();
        collectLocations(keys, this.redPieces, false);
        collectLocations(keys, this.bluePieces, false);
        return keys;
    }

    private Set<BlockKey> collectCurrentWallLocations() {
        Set<BlockKey> keys = new HashSet<>();
        collectLocations(keys, this.redPieces, true);
        collectLocations(keys, this.bluePieces, true);
        return keys;
    }

    private void collectLocations(Set<BlockKey> out, List<GatePiece> pieces, boolean currentPosition) {
        for (GatePiece piece : pieces) {
            Location location = currentPosition ? blockLocation(piece.display.getLocation()) : piece.startBlockLocation;
            if (location != null && location.getWorld() != null) {
                out.add(BlockKey.of(location));
            }
        }
    }

    private void syncBarrierBlocks(Map<BlockKey, StoredBlock> map, Set<BlockKey> desiredKeys) {
        Iterator<Map.Entry<BlockKey, StoredBlock>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<BlockKey, StoredBlock> entry = iterator.next();
            if (!desiredKeys.contains(entry.getKey())) {
                entry.getValue().restore();
                iterator.remove();
            }
        }
        for (BlockKey key : desiredKeys) {
            if (!map.containsKey(key)) {
                placeBarrierBlock(map, key);
            }
        }
    }

    private BlockData createFenceData(String side) {
        Material material = (this.arena == null || this.arena.prefightWallMaterial() == null) ? Material.SPRUCE_FENCE : this.arena.prefightWallMaterial();
        if (!material.name().endsWith("_FENCE")) {
            material = Material.SPRUCE_FENCE;
        }
        MultipleFacing multipleFacingCreateBlockData = Bukkit.createBlockData(material);
        if (multipleFacingCreateBlockData instanceof MultipleFacing) {
            MultipleFacing multipleFacing = multipleFacingCreateBlockData;
            Set<BlockFace> faces = this.arena == null ? Collections.emptySet() : this.arena.prefightWallFacing();
            if (faces.isEmpty()) {
                faces = Set.of(BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST);
            }
            for (BlockFace face : List.of(BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST)) {
                multipleFacing.setFace(face, faces.contains(face));
            }
        }
        return multipleFacingCreateBlockData;
    }

    private GatePiece spawnGatePiece(Player player, BlockData blockData, Location start, Location target, Vector interactionOffset) {
        if (start == null || start.getWorld() == null || target == null || target.getWorld() == null) {
            throw new IllegalArgumentException("Gate piece location has no world");
        }
        BlockDisplay display = start.getWorld().spawn(start, BlockDisplay.class, spawned -> {
            spawned.setBlock(blockData);
            spawned.setInterpolationDuration(1);
            spawned.setInterpolationDelay(0);
            spawned.setTeleportDuration(1);
            spawned.setViewRange((float) Math.max(32.0d, this.plugin.getConfig().getDouble("duels.skip-barrier.view-range", 96.0d)));
            spawned.setTransformation(new Transformation(new Vector3f(0.0f, 0.0f, 0.0f), new AxisAngle4f(), new Vector3f(1.0f, 1.0f, 1.0f), new AxisAngle4f()));
            spawned.setPersistent(false);
        });
        Interaction interaction = start.getWorld().spawn(interactionSpawnLocation(start, interactionOffset), Interaction.class, spawned2 -> {
            spawned2.setInteractionWidth(1.0f);
            spawned2.setInteractionHeight(1.0f);
            spawned2.setResponsive(true);
            spawned2.setPersistent(false);
        });
        GatePiece piece = new GatePiece(display, interaction, start, target, interactionOffset);
        this.registeredInteractionIds.add(Integer.valueOf(piece.interactionId));
        this.manager.registerInteractionEntity(piece.interactionId, this);
        return piece;
    }

    private Vector computeInteractionOffset(Player player, String side) {
        if (this.arena != null && this.arena.redSpawn() != null && this.arena.blueSpawn() != null) {
            Location ownSpawn = side.equalsIgnoreCase("red") ? this.arena.redSpawn() : this.arena.blueSpawn();
            Location otherSpawn = side.equalsIgnoreCase("red") ? this.arena.blueSpawn() : this.arena.redSpawn();
            Vector backward = ownSpawn.toVector().subtract(otherSpawn.toVector());
            backward.setY(0);
            if (backward.lengthSquared() > 1.0E-4d) {
                return backward.normalize().multiply(0.25d);
            }
        }
        Vector forward = player.getLocation().getDirection().clone();
        forward.setY(0);
        if (forward.lengthSquared() < 1.0E-4d) {
            return new Vector(0.0d, 0.0d, 0.25d);
        }
        return forward.normalize().multiply(-0.25d);
    }

    private Location interactionSpawnLocation(Location wallLocation, Vector interactionOffset) {
        return new Location(wallLocation.getWorld(), Math.floor(wallLocation.getX()) + 0.5d + interactionOffset.getX(), Math.floor(wallLocation.getY()) + 0.5d, Math.floor(wallLocation.getZ()) + 0.5d + interactionOffset.getZ(), wallLocation.getYaw(), wallLocation.getPitch());
    }

    private int computeFallbackTargetDeltaY() {
        double targetY = this.plugin.getConfig().getDouble("duels.skip-barrier.target-y", 66.0d);
        Player base = Bukkit.getPlayer(this.redId);
        if (base == null) {
            base = Bukkit.getPlayer(this.blueId);
        }
        int startY = base != null ? base.getLocation().getBlockY() : 0;
        return (int) Math.round(targetY - ((double) startY));
    }

    private Location buildAnchor(Player player) {
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize().multiply(3.0d);
        Location front = eye.clone().add(direction);
        return new Location(player.getWorld(), Math.floor(front.getX()) + 0.5d, Math.floor(player.getLocation().getY()), Math.floor(front.getZ()) + 0.5d, 180.0f, 0.0f);
    }

    private void sendReadyActionBar(Player confirmer) {
        String message = this.messages.get("duels.skip-ready-actionbar", Map.of("player", confirmer.getName(), "confirmed", String.valueOf(getConfirmedCount()), "total", "2"));
        if (message.isBlank()) {
            return;
        }
        Player red = Bukkit.getPlayer(this.redId);
        Player blue = Bukkit.getPlayer(this.blueId);
        if (red != null) {
            red.sendActionBar(message);
        }
        if (blue != null) {
            blue.sendActionBar(message);
        }
    }

    private void startCountdown() {
        int seconds = Math.max(1, this.plugin.settings().countdownSeconds());
        int[] left = {seconds};
        this.countdownTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.destroyed || this.lifting) {
                cancelCountdown();
                return;
            }
            Player red = Bukkit.getPlayer(this.redId);
            Player blue = Bukkit.getPlayer(this.blueId);
            if (red == null || blue == null) {
                destroy();
                return;
            }
            int t = left[0];
            if (t <= 0) {
                cancelCountdown();
                beginFightIfNeeded(false);
                triggerLift(false);
            } else {
                enforcePlayersOnCorrectSides();
                TitleFormat.send(red, this.messages.get("titles.countdown", Map.of("seconds", String.valueOf(t), "time", String.valueOf(t))), this.messages);
                TitleFormat.send(blue, this.messages.get("titles.countdown", Map.of("seconds", String.valueOf(t), "time", String.valueOf(t))), this.messages);
                red.playSound(red.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 1.0f);
                blue.playSound(blue.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 0.5f, 1.0f);
                left[0] = t - 1;
            }
        }, 0L, 20L);
    }

    private void triggerLift(boolean skippedByBoth) {
        if (this.destroyed || this.lifting) {
            return;
        }
        this.lifting = true;
        cancelCountdown();
        playToBoth(Sound.ENTITY_MINECART_RIDING, 1.0f, 1.0f);
        double step = Math.max(0.35d, this.plugin.getConfig().getDouble("duels.skip-barrier.step-per-tick", 1.1d));
        long period = Math.max(1L, this.plugin.getConfig().getLong("duels.skip-barrier.tick-period", 2L));
        this.liftTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.destroyed) {
                cancelLift();
                return;
            }
            boolean finished = movePiecesTowardsTarget(this.redPieces, step, true) & movePiecesTowardsTarget(this.bluePieces, step, true);
            syncBarrierBlocks(this.activeBarrierBlocks, collectCurrentWallLocations());
            enforcePlayersOnCorrectSides();
            if (finished) {
                cancelLift();
                stopMinecartSound();
                playToBoth(Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 1.0f);
                scheduleReturnToStart(skippedByBoth);
            }
        }, 0L, period);
    }

    private boolean movePiecesTowardsTarget(List<GatePiece> pieces, double step, boolean towardFinalWall) {
        boolean finished = true;
        for (GatePiece piece : pieces) {
            if (piece.display.isValid()) {
                Location displayLocation = piece.display.getLocation();
                Location target = towardFinalWall ? piece.targetBlockLocation : piece.startBlockLocation;
                double dx = target.getX() - displayLocation.getX();
                double dy = target.getY() - displayLocation.getY();
                double dz = target.getZ() - displayLocation.getZ();
                double distance = Math.sqrt((dx * dx) + (dy * dy) + (dz * dz));
                if (distance > 0.001d) {
                    finished = false;
                    double ratio = Math.min(1.0d, step / distance);
                    displayLocation.add(dx * ratio, dy * ratio, dz * ratio);
                } else {
                    displayLocation = target.clone();
                }
                piece.display.teleport(displayLocation);
                if (piece.interaction.isValid()) {
                    piece.interaction.teleport(interactionSpawnLocation(displayLocation, piece.interactionOffset));
                }
            }
        }
        return finished;
    }

    private Location blockLocation(Location location) {
        return new Location(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }

    private void scheduleReturnToStart(boolean skippedByBoth) {
        cancelReturnTask();
        this.returnTask = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            startLoweringToStart(skippedByBoth);
        }, 100L);
    }

    private void startLoweringToStart(boolean skippedByBoth) {
        if (this.destroyed) {
            return;
        }
        removeConfirmationInteractions();
        syncBarrierBlocks(this.activeBarrierBlocks, collectStartWallLocations());
        playToBoth(Sound.ENTITY_MINECART_RIDING, 1.0f, 1.0f);
        double step = Math.max(0.35d, this.plugin.getConfig().getDouble("duels.skip-barrier.step-per-tick", 1.1d));
        long period = Math.max(1L, this.plugin.getConfig().getLong("duels.skip-barrier.tick-period", 2L));
        this.returnTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.destroyed) {
                cancelReturnTask();
                return;
            }
            boolean finished = movePiecesTowardsTarget(this.redPieces, step, false) & movePiecesTowardsTarget(this.bluePieces, step, false);
            enforcePlayersOnCorrectSides();
            if (!finished) {
                playToBoth(Sound.BLOCK_CHAIN_STEP, 0.5f, 0.9f);
                return;
            }
            cancelReturnTask();
            stopMinecartSound();
            playToBoth(Sound.ITEM_MACE_SMASH_GROUND, 1.0f, 1.0f);
            Player red = Bukkit.getPlayer(this.redId);
            Player blue = Bukkit.getPlayer(this.blueId);
            boolean redBehindRed = red != null && isPlayerBehindWall("red", red);
            boolean redBehindBlue = red != null && isPlayerBehindWall("blue", red);
            boolean blueBehindRed = blue != null && isPlayerBehindWall("red", blue);
            boolean blueBehindBlue = blue != null && isPlayerBehindWall("blue", blue);
            if (redBehindRed && blueBehindRed) {
                teleportPlayerAheadOfWall("red", red, 1.0d);
                teleportPlayerAheadOfWall("red", blue, 1.0d);
            } else if (redBehindBlue && blueBehindBlue) {
                teleportPlayerAheadOfWall("blue", red, 1.0d);
                teleportPlayerAheadOfWall("blue", blue, 1.0d);
            } else {
                if (red != null) {
                    if (redBehindRed) {
                        teleportPlayerAheadOfWall("red", red, 1.0d);
                    } else if (redBehindBlue) {
                        teleportPlayerAheadOfWall("blue", red, 1.0d);
                    }
                }
                if (blue != null) {
                    if (blueBehindBlue) {
                        teleportPlayerAheadOfWall("blue", blue, 1.0d);
                    } else if (blueBehindRed) {
                        teleportPlayerAheadOfWall("red", blue, 1.0d);
                    }
                }
            }
            setInteractionsResponsive(false);
        }, 0L, period);
    }

    private void beginFightIfNeeded(boolean skippedByBoth) {
        if (this.fightStarted || this.destroyed) {
            return;
        }
        this.fightStarted = true;
        setInteractionsResponsive(false);
        this.match.onCountdownFinished(skippedByBoth);
    }

    private void enforcePlayersOnCorrectSides() {
    }

    private boolean isPlayerBehindWall(String side, Player player) {
        if (this.arena == null || !this.arena.hasWall(side) || player == null || player.getWorld() == null) {
            return false;
        }
        Location ownSpawn = side.equalsIgnoreCase("red") ? this.arena.redSpawn() : this.arena.blueSpawn();
        Location otherSpawn = side.equalsIgnoreCase("red") ? this.arena.blueSpawn() : this.arena.redSpawn();
        if (ownSpawn == null || otherSpawn == null) {
            return false;
        }
        Vector forward = otherSpawn.toVector().subtract(ownSpawn.toVector());
        forward.setY(0);
        if (forward.lengthSquared() < 1.0E-4d) {
            return false;
        }
        forward.normalize();
        Location wallCenter = centerOf(this.arena.wallMin(side), this.arena.wallMax(side));
        if (wallCenter == null) {
            return false;
        }
        Vector relative = player.getLocation().toVector().subtract(wallCenter.toVector());
        relative.setY(0);
        return relative.dot(forward) < 0.0d;
    }

    private void teleportPlayerAheadOfWall(String side, Player player, double blocksAhead) {
        if (this.arena == null || !this.arena.hasWall(side) || player == null || player.getWorld() == null) {
            return;
        }
        Location ownSpawn = side.equalsIgnoreCase("red") ? this.arena.redSpawn() : this.arena.blueSpawn();
        Location otherSpawn = side.equalsIgnoreCase("red") ? this.arena.blueSpawn() : this.arena.redSpawn();
        if (ownSpawn == null || otherSpawn == null) {
            return;
        }
        Vector forward = otherSpawn.toVector().subtract(ownSpawn.toVector());
        forward.setY(0);
        if (forward.lengthSquared() < 1.0E-4d) {
            return;
        }
        forward.normalize();
        Location wallCenter = centerOf(this.arena.wallMin(side), this.arena.wallMax(side));
        if (wallCenter == null) {
            return;
        }
        Vector relative = player.getLocation().toVector().subtract(wallCenter.toVector());
        relative.setY(0);
        if (relative.dot(forward) >= 0.0d) {
            return;
        }
        Location target = wallCenter.clone().add(forward.clone().multiply(blocksAhead));
        target.setY(player.getLocation().getY());
        target.setYaw(player.getLocation().getYaw());
        target.setPitch(player.getLocation().getPitch());
        player.teleport(target);
    }

    private Location centerOf(Location a, Location b) {
        if (a == null || b == null || a.getWorld() == null) {
            return null;
        }
        return new Location(a.getWorld(), ((Math.min(a.getX(), b.getX()) + Math.max(a.getX(), b.getX())) + 1.0d) / 2.0d, (Math.min(a.getY(), b.getY()) + Math.max(a.getY(), b.getY())) / 2.0d, ((Math.min(a.getZ(), b.getZ()) + Math.max(a.getZ(), b.getZ())) + 1.0d) / 2.0d);
    }

    private void placeBarrierBlock(Map<BlockKey, StoredBlock> map, BlockKey key) {
        World world = Bukkit.getWorld(key.worldName());
        if (world == null) {
            return;
        }
        Block block = world.getBlockAt(key.x(), key.y(), key.z());
        if (block.getType() == Material.AIR || block.isPassable()) {
            BlockData originalData = block.getBlockData().clone();
            block.setType(Material.BARRIER, false);
            map.put(key, new StoredBlock(key, originalData));
        }
    }

    private void clearStoredBlocks(Map<BlockKey, StoredBlock> map) {
        if (map.isEmpty()) {
            return;
        }
        List<StoredBlock> values = new ArrayList<>(map.values());
        map.clear();
        for (StoredBlock stored : values) {
            stored.restore();
        }
    }

    private void playToBoth(Sound sound, float volume, float pitch) {
        Player red = Bukkit.getPlayer(this.redId);
        Player blue = Bukkit.getPlayer(this.blueId);
        if (red != null) {
            red.playSound(red.getLocation(), sound, volume, pitch);
        }
        if (blue != null) {
            blue.playSound(blue.getLocation(), sound, volume, pitch);
        }
    }

    private void stopMinecartSound() {
        Player red = Bukkit.getPlayer(this.redId);
        Player blue = Bukkit.getPlayer(this.blueId);
        if (red != null) {
            red.stopSound(Sound.ENTITY_MINECART_RIDING);
        }
        if (blue != null) {
            blue.stopSound(Sound.ENTITY_MINECART_RIDING);
        }
    }

    private void cancelCountdown() {
        if (this.countdownTask != null) {
            this.countdownTask.cancel();
            this.countdownTask = null;
        }
    }

    private void cancelLift() {
        if (this.liftTask != null) {
            this.liftTask.cancel();
            this.liftTask = null;
        }
    }

    private void cancelReturnTask() {
        if (this.returnTask != null) {
            this.returnTask.cancel();
            this.returnTask = null;
        }
    }

    private void removeConfirmationInteractions() {
        removeInteractions(this.redPieces);
        removeInteractions(this.bluePieces);
    }

    private void removeInteractions(List<GatePiece> pieces) {
        for (GatePiece piece : pieces) {
            if (this.registeredInteractionIds.remove(Integer.valueOf(piece.interactionId))) {
                this.manager.unregisterInteractionEntity(piece.interactionId);
            }
            if (piece.interaction.isValid()) {
                piece.interaction.remove();
            }
        }
    }

    private void setInteractionsResponsive(boolean responsive) {
        setInteractionsResponsive(this.redPieces, responsive);
        setInteractionsResponsive(this.bluePieces, responsive);
    }

    private void setInteractionsResponsive(List<GatePiece> pieces, boolean responsive) {
        for (GatePiece piece : pieces) {
            if (piece.interaction.isValid()) {
                piece.interaction.setResponsive(responsive);
            }
        }
    }

    private void destroyVisualsOnly() {
        destroyPieces(this.redPieces);
        destroyPieces(this.bluePieces);
        this.redPieces.clear();
        this.bluePieces.clear();
        for (Integer id : new HashSet(this.registeredInteractionIds)) {
            this.manager.unregisterInteractionEntity(id.intValue());
        }
        this.registeredInteractionIds.clear();
    }

    public void destroy() {
        if (this.destroyed) {
            return;
        }
        this.destroyed = true;
        cancelCountdown();
        cancelLift();
        cancelReturnTask();
        stopMinecartSound();
        clearStoredBlocks(this.activeBarrierBlocks);
        destroyVisualsOnly();
        this.manager.onSequenceDestroyed(this);
    }

    private void destroyPieces(List<GatePiece> pieces) {
        for (GatePiece piece : pieces) {
            if (piece.display.isValid()) {
                piece.display.remove();
            }
            if (piece.interaction.isValid()) {
                piece.interaction.remove();
            }
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipSequence$GatePiece.class */
    private static final class GatePiece {
        private final BlockDisplay display;
        private final Interaction interaction;
        private final int interactionId;
        private final Location startBlockLocation;
        private final Location targetBlockLocation;
        private final Vector interactionOffset;

        private GatePiece(BlockDisplay display, Interaction interaction, Location startBlockLocation, Location targetBlockLocation, Vector interactionOffset) {
            this.display = display;
            this.interaction = interaction;
            this.interactionId = interaction.getEntityId();
            this.startBlockLocation = startBlockLocation.clone();
            this.targetBlockLocation = targetBlockLocation.clone();
            this.interactionOffset = interactionOffset.clone();
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey.class */
    private static final class BlockKey extends Record {
        private final String worldName;
        private final int x;
        private final int y;
        private final int z;

        private BlockKey(String worldName, int x, int y, int z) {
            this.worldName = worldName;
            this.x = x;
            this.y = y;
            this.z = z;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, BlockKey.class), BlockKey.class, "worldName;x;y;z", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->worldName:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->x:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->y:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->z:I").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, BlockKey.class), BlockKey.class, "worldName;x;y;z", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->worldName:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->x:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->y:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->z:I").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, BlockKey.class, Object.class), BlockKey.class, "worldName;x;y;z", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->worldName:Ljava/lang/String;", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->x:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->y:I", "FIELD:Ldev/rean/pvpcore/prefight/PreFightSkipSequence$BlockKey;->z:I").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String worldName() {
            return this.worldName;
        }

        public int x() {
            return this.x;
        }

        public int y() {
            return this.y;
        }

        public int z() {
            return this.z;
        }

        private static BlockKey of(Location location) {
            return new BlockKey(location.getWorld().getName(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
        }
    }

    /* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/prefight/PreFightSkipSequence$StoredBlock.class */
    private static final class StoredBlock {
        private final BlockKey key;
        private final BlockData originalData;

        private StoredBlock(BlockKey key, BlockData originalData) {
            this.key = key;
            this.originalData = originalData;
        }

        private void restore() {
            World world = Bukkit.getWorld(this.key.worldName());
            if (world == null) {
                return;
            }
            world.getBlockAt(this.key.x(), this.key.y(), this.key.z()).setBlockData(this.originalData, false);
        }
    }
}
