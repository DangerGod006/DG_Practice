package dev.rean.pvpcore.commands;

import dev.rean.pvpcore.PvPCorePlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: PvPCore-1.0.0.jar:dev/rean/pvpcore/commands/LeaveCommand.class */
public final class LeaveCommand implements CommandExecutor {
    private final PvPCorePlugin plugin;

    public LeaveCommand(PvPCorePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            this.plugin.messages().send(sender, "player-only");
            return true;
        }
        CommandSender commandSender = (Player) sender;
        if (this.plugin.spectatorManager().leave(commandSender, true)) {
            return true;
        }
        if (this.plugin.duelManager().isInMatch(commandSender.getUniqueId())) {
            this.plugin.duelManager().removePlayer(commandSender.getUniqueId());
            this.plugin.messages().send(commandSender, "leave.resigned");
            return true;
        }
        int removed = this.plugin.queueManager().leaveAllQuiet(commandSender.getUniqueId());
        if (removed <= 0) {
            this.plugin.messages().send(commandSender, "leave.nothing");
            return true;
        }
        return true;
    }
}
