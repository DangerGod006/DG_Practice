package ac.vulcan.anticheat;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kx.class */
public class Vulcan_kx extends Format {
    private static final long serialVersionUID = -4329119827877627683L;
    private final Format Vulcan_I;
    private final Format Vulcan_X;

    public Vulcan_kx(Format format, Format format2) {
        this.Vulcan_I = format;
        this.Vulcan_X = format2;
    }

    @Override // java.text.Format
    public StringBuffer format(Object obj, StringBuffer stringBuffer, FieldPosition fieldPosition) {
        return this.Vulcan_X.format(obj, stringBuffer, fieldPosition);
    }

    @Override // java.text.Format
    public Object parseObject(String str, ParsePosition parsePosition) {
        return this.Vulcan_I.parseObject(str, parsePosition);
    }

    public Format Vulcan_P(Object[] objArr) {
        return this.Vulcan_I;
    }

    public Format Vulcan_C(Object[] objArr) {
        return this.Vulcan_X;
    }

    public String Vulcan_T(Object[] objArr) {
        return format(parseObject((String) objArr[0]));
    }
}
