package ac.vulcan.anticheat;

import java.util.Locale;
import java.util.TimeZone;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_b.class */
class Vulcan_b {
    private final TimeZone Vulcan_s;
    private final int Vulcan_v;
    private final Locale Vulcan_P;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-3128100253262367812L, -8382938826893159910L, null).a(114554942068079L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_b(TimeZone timeZone, boolean z, int i, Locale locale) {
        long j = a ^ 129462975696366L;
        this.Vulcan_s = timeZone;
        this.Vulcan_v = z ? i | Integer.MIN_VALUE : i;
        this.Vulcan_P = locale;
    }

    public int hashCode() {
        return (this.Vulcan_v * 31) + this.Vulcan_P.hashCode();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_b.a
            r1 = 51017076467844(0x2e6656b86884, double:2.52057848340176E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r9 = r0
            r0 = r5
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r6
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0     // Catch: java.lang.RuntimeException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_b     // Catch: java.lang.RuntimeException -> L33
            r1 = r9
            if (r1 != 0) goto La0
            if (r0 == 0) goto L9f
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_b r0 = (ac.vulcan.anticheat.Vulcan_b) r0
            r10 = r0
            r0 = r5
            java.util.TimeZone r0 = r0.Vulcan_s     // Catch: java.lang.RuntimeException -> L54
            r1 = r10
            java.util.TimeZone r1 = r1.Vulcan_s     // Catch: java.lang.RuntimeException -> L54
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L54
            r1 = r9
            if (r1 != 0) goto L63
            if (r0 == 0) goto L9d
            goto L58
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5f
            throw r0     // Catch: java.lang.RuntimeException -> L5f
        L58:
            r0 = r5
            int r0 = r0.Vulcan_v     // Catch: java.lang.RuntimeException -> L5f
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L63:
            r1 = r9
            if (r1 != 0) goto L8a
            r1 = r10
            int r1 = r1.Vulcan_v     // Catch: java.lang.RuntimeException -> L73 java.lang.RuntimeException -> L86
            if (r0 != r1) goto L9d
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L86
            throw r0     // Catch: java.lang.RuntimeException -> L86
        L77:
            r0 = r5
            java.util.Locale r0 = r0.Vulcan_P     // Catch: java.lang.RuntimeException -> L86
            r1 = r10
            java.util.Locale r1 = r1.Vulcan_P     // Catch: java.lang.RuntimeException -> L86
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L86
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8a:
            r1 = r9
            if (r1 != 0) goto L9a
            if (r0 == 0) goto L9d
            goto L99
        L95:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L99:
            r0 = 1
        L9a:
            goto L9e
        L9d:
            r0 = 0
        L9e:
            return r0
        L9f:
            r0 = 0
        La0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_b.equals(java.lang.Object):boolean");
    }
}
