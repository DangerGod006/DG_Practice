package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_u.class */
class Vulcan_u extends C0030Vulcan_m {
    private static final long b = me.frep.vulcan.spigot.Vulcan_n.a(1932019487904061054L, 6734886581237581381L, null).a(1656143670585L);

    private static RuntimeException b(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_u() {
    }

    public Vulcan_u(int i) {
        super(i);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private int Vulcan_z(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_u.b
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = 0
            r12 = r1
            r11 = r0
            r0 = r6
            int r0 = r0.Vulcan_x
            r1 = 1
            int r0 = r0 - r1
            r13 = r0
        L2d:
            r0 = r12
            r1 = r13
            if (r0 > r1) goto Lb6
            r0 = r12
            r1 = r13
            int r0 = r0 + r1
            r1 = 1
            int r0 = r0 >>> r1
        L3b:
            r14 = r0
            r0 = r6
            int[] r0 = r0.Vulcan__
            r1 = r14
            r0 = r0[r1]
            r15 = r0
            r0 = r15
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lc1
            r1 = r10
            r2 = r11
            if (r2 != 0) goto Lbf
            r2 = r11
            if (r2 != 0) goto L93
            goto L61
        L5d:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0     // Catch: java.lang.RuntimeException -> L67
        L61:
            if (r0 >= r1) goto L7c
            goto L6b
        L67:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L6b:
            r0 = r14
            r1 = 1
            int r0 = r0 + r1
            r12 = r0
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lb3
            if (r0 == 0) goto Lb1
        L7c:
            r0 = r15
            r1 = r11
            if (r1 != 0) goto Lb0
            goto L8a
        L86:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L8f
            throw r0     // Catch: java.lang.RuntimeException -> L8f
        L8a:
            r1 = r10
            goto L93
        L8f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L93:
            if (r0 <= r1) goto La7
            r0 = r14
            r1 = 1
            int r0 = r0 - r1
            r13 = r0
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb3
            if (r0 == 0) goto Lb1
        La7:
            r0 = r14
            goto Lb0
        Lac:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        Lb0:
            return r0
        Lb1:
            r0 = r11
        Lb3:
            if (r0 == 0) goto L2d
        Lb6:
            r0 = r12
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L3b
            r1 = 1
        Lbf:
            int r0 = r0 + r1
            int r0 = -r0
        Lc1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_u.Vulcan_z(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v11, types: [ac.vulcan.anticheat.Vulcan_u, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v2, types: [ac.vulcan.anticheat.Vulcan_u, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.C0030Vulcan_m, ac.vulcan.anticheat.Vulcan_fn
    public void Vulcan_A(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 242
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_u.Vulcan_A(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_u, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.C0030Vulcan_m, ac.vulcan.anticheat.Vulcan_fn
    public java.lang.String Vulcan_K(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 91596274800458(0x534e6b6c174a, double:4.52545726659406E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.Vulcan_z(r1)
            r16 = r0
            r0 = r16
            if (r0 >= 0) goto L55
            r0 = 0
            return r0
        L51:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L51
            throw r0
        L55:
            r0 = r9
            java.lang.String[] r0 = r0.Vulcan_O
            r1 = r16
            r0 = r0[r1]
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_u.Vulcan_K(java.lang.Object[]):java.lang.String");
    }
}
