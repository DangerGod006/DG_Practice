package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_f4.class */
final class Vulcan_f4 extends Vulcan_fV {
    private static final long serialVersionUID = 1;

    Vulcan_f4() {
    }

    private Object readResolve() {
        return Vulcan_fV.Vulcan_w;
    }
}
