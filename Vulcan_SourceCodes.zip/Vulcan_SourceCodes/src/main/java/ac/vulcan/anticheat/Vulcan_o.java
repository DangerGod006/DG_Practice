package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_o.class */
class Vulcan_o implements Vulcan_fu {
    private final int Vulcan_d;
    private final int Vulcan_o;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5100597170536176313L, -8006934596428632961L, null).a(29482617902461L);
    private static final String b;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = "w\u001fJ5S;)\\Z[5K':JZ^<H'3]ZC;Sr=\\Z];T!6[\u0016H".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 50;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 11;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -5100597170536176313(0xb93709e5c3d42547, double:-4.437084938070382E-33)
            r1 = -8006934596428632961(0x90e1a7683815ec7f, double:-2.328813881506035E-227)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 29482617902461(0x1ad074f7957d, double:1.456634865507E-310)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_o.a = r0
            r0 = 50
            java.lang.String r1 = "w\u001fJ5S;)\\Z[5K':JZ^<H'3]ZC;Sr=\\Z];T!6[\u0016H"
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.Vulcan_o.b = r2
            goto Lab
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 11
            goto L84
        L69:
            r8 = 72
            goto L84
        L6e:
            r8 = 31
            goto L84
        L73:
            r8 = 102(0x66, float:1.43E-43)
            goto L84
        L78:
            r8 = 21
            goto L84
        L7d:
            r8 = 96
            goto L84
        L82:
            r8 = 109(0x6d, float:1.53E-43)
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_o.m553clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    Vulcan_o(int i, int i2) {
        long j = a ^ 118341744972954L;
        if (i2 < 3) {
            throw new IllegalArgumentException();
        }
        this.Vulcan_d = i;
        this.Vulcan_o = i2;
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return 4;
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Calendar r1 = (java.util.Calendar) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 110766544763656(0x64bdd88dbb08, double:5.4725944476259E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = r10
            int r3 = r3.Vulcan_d
            int r2 = r2.get(r3)
            r3 = r16
            r4 = r3; r3 = r2; r2 = r4; 
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_j(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_o.Vulcan_g(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_fu
    public final void Vulcan_j(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 354
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_o.Vulcan_j(java.lang.Object[]):void");
    }
}
