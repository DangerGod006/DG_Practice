package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fp.class */
public class Vulcan_fp {
    private final int Vulcan_d;
    private final int Vulcan_R;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(2627579823687366248L, 6885956828537227357L, null).a(170444282783644L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:8:0x0029
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_fp(int r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fp.a
            r1 = 75851995617428(0x44fcab411894, double:3.7475865203072E-310)
            long r0 = r0 ^ r1
            r7 = r0
            r0 = r5
            r0.<init>()
            r0 = r5
            r1 = r6
            r0.Vulcan_d = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = 0
            r10 = r1
            r9 = r0
            r0 = r6
            r11 = r0
            r0 = r9
            if (r0 != 0) goto L5b
            r0 = r11
            if (r0 == 0) goto L55
            goto L2d
        L29:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L37
            throw r0     // Catch: java.lang.RuntimeException -> L37
        L2d:
            r0 = r11
            r1 = 1
            r0 = r0 & r1
            if (r0 != 0) goto L55
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3b:
            int r10 = r10 + 1
            r0 = r11
            r1 = 1
            int r0 = r0 >> r1
            r11 = r0
            r0 = r9
            if (r0 != 0) goto L5b
            r0 = r9
            if (r0 == 0) goto L2d
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L55:
            r0 = r5
            r1 = r10
            r0.Vulcan_R = r1
        L5b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fp.<init>(int):void");
    }

    public int Vulcan_V(Object[] objArr) {
        return Vulcan_y(new Object[]{new Integer(((Integer) objArr[0]).intValue())}) >> this.Vulcan_R;
    }

    public short Vulcan_S(Object[] objArr) {
        return (short) Vulcan_V(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    public int Vulcan_y(Object[] objArr) {
        return ((Integer) objArr[0]).intValue() & this.Vulcan_d;
    }

    public short Vulcan_L(Object[] objArr) {
        return (short) Vulcan_y(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_p(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            Vulcan_k = iIntValue & this.Vulcan_d;
            return Vulcan_k == 0 ? Vulcan_k != 0 : Vulcan_k;
        } catch (RuntimeException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    public boolean Vulcan_N(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            try {
                Vulcan_k = iIntValue & this.Vulcan_d;
                return Vulcan_k == 0 ? Vulcan_k == this.Vulcan_d : Vulcan_k;
            } catch (RuntimeException unused) {
                Vulcan_k = a(Vulcan_k);
                throw Vulcan_k;
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_k);
        }
        throw a(Vulcan_k);
    }

    public int Vulcan_I(Object[] objArr) {
        return (((Integer) objArr[0]).intValue() & (this.Vulcan_d ^ (-1))) | ((((Integer) objArr[1]).intValue() << this.Vulcan_R) & this.Vulcan_d);
    }

    public short Vulcan_r(Object[] objArr) {
        return (short) Vulcan_I(new Object[]{new Integer(((Integer) objArr[0]).intValue()), new Integer(((Integer) objArr[1]).intValue())});
    }

    public int Vulcan_g(Object[] objArr) {
        return ((Integer) objArr[0]).intValue() & (this.Vulcan_d ^ (-1));
    }

    public short Vulcan_T(Object[] objArr) {
        return (short) Vulcan_g(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    public byte Vulcan_v(Object[] objArr) {
        return (byte) Vulcan_g(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    public int Vulcan_P(Object[] objArr) {
        return ((Integer) objArr[0]).intValue() | this.Vulcan_d;
    }

    public short Vulcan_w(Object[] objArr) {
        return (short) Vulcan_P(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public byte m396Vulcan_y(Object[] objArr) {
        return (byte) Vulcan_P(new Object[]{new Integer(((Integer) objArr[0]).intValue())});
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public int Vulcan_k(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        boolean zBooleanValue = ((Boolean) objArr[2]).booleanValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            return Vulcan_k == 0 ? zBooleanValue ? Vulcan_P(new Object[]{new Integer(iIntValue)}) : Vulcan_g(new Object[]{new Integer(iIntValue)}) : zBooleanValue ? 1 : 0;
        } catch (RuntimeException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public short Vulcan__(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            return Vulcan_k == 0 ? zBooleanValue ? Vulcan_w(new Object[]{new Integer(iIntValue)}) : Vulcan_T(new Object[]{new Integer(iIntValue)}) : zBooleanValue ? (short) 1 : (short) 0;
        } catch (RuntimeException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public byte Vulcan_E(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        long jLongValue = ((Long) objArr[1]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[2]).booleanValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            return Vulcan_k == 0 ? zBooleanValue ? m396Vulcan_y(new Object[]{new Integer(iIntValue)}) : Vulcan_v(new Object[]{new Integer(iIntValue)}) : zBooleanValue ? (byte) 1 : (byte) 0;
        } catch (RuntimeException unused) {
            throw a(Vulcan_k);
        }
    }
}
