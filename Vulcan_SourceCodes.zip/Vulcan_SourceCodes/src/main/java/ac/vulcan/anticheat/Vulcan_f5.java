package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_f5.class */
public class Vulcan_f5 {
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-818697418167571838L, 215364292666016046L, null).a(121329367220359L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x008f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Object Vulcan_U(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 35553554093323(0x2055f4f6550b, double:1.75657896650693E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r16 = r0
            r0 = 0
            r1 = r10
            if (r0 != r1) goto L38
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
            r10 = r0
        L38:
            r0 = r10
            int r0 = r0.length
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r17 = r0
            r0 = 0
            r18 = r0
        L42:
            r0 = r18
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L75
        L49:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L63
            r0 = r17
            r1 = r16
            if (r1 == 0) goto La1
            r1 = r18
            r2 = r10
            r3 = r18
            r2 = r2[r3]     // Catch: java.lang.NoSuchMethodException -> L71
            java.lang.Class r2 = r2.getClass()     // Catch: java.lang.NoSuchMethodException -> L71
            r0[r1] = r2     // Catch: java.lang.NoSuchMethodException -> L71
            int r18 = r18 + 1
        L63:
            r0 = r16
            if (r0 != 0) goto L42
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L49
            goto L75
        L71:
            java.lang.Exception r0 = a(r0)
            throw r0
        L75:
            r0 = r14
            r1 = r13
            r2 = r10
            r3 = r17
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_f(r0)
        La1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_U(java.lang.Object[]):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0075: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Object Vulcan_f(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 12269677148058(0xb28c1bf779a, double:6.062025964419E-311)
            long r1 = r1 ^ r2
            r14 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r16 = r0
            r0 = r12
            r1 = r16
            if (r1 == 0) goto L4e
            if (r0 != 0) goto L4d
            goto L48
        L44:
            java.lang.Exception r0 = a(r0)
            throw r0
        L48:
            java.lang.Class[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_o
            r12 = r0
        L4d:
            r0 = r9
        L4e:
            r1 = r16
            if (r1 == 0) goto L60
            if (r0 != 0) goto L61
            goto L5d
        L59:
            java.lang.Exception r0 = a(r0)
            throw r0
        L5d:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
        L60:
            r9 = r0
        L61:
            r0 = r14
            r1 = r13
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.reflect.Constructor r0 = Vulcan__(r0)
            r17 = r0
            r0 = 0
            r1 = r17
            if (r0 != r1) goto Lb5
            java.lang.NoSuchMethodException r0 = new java.lang.NoSuchMethodException     // Catch: java.lang.NoSuchMethodException -> Lb1
            r1 = r0
            java.lang.StringBuffer r2 = new java.lang.StringBuffer     // Catch: java.lang.NoSuchMethodException -> Lb1
            r3 = r2
            r3.<init>()     // Catch: java.lang.NoSuchMethodException -> Lb1
            java.lang.String[] r3 = ac.vulcan.anticheat.Vulcan_f5.b     // Catch: java.lang.NoSuchMethodException -> Lb1
            r4 = 0
            r3 = r3[r4]     // Catch: java.lang.NoSuchMethodException -> Lb1
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.NoSuchMethodException -> Lb1
            r3 = r13
            java.lang.String r3 = r3.getName()     // Catch: java.lang.NoSuchMethodException -> Lb1
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.NoSuchMethodException -> Lb1
            java.lang.String r2 = r2.toString()     // Catch: java.lang.NoSuchMethodException -> Lb1
            r1.<init>(r2)     // Catch: java.lang.NoSuchMethodException -> Lb1
            throw r0     // Catch: java.lang.NoSuchMethodException -> Lb1
        Lb1:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NoSuchMethodException -> Lb1
            throw r0
        Lb5:
            r0 = r17
            r1 = r9
            java.lang.Object r0 = r0.newInstance(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_f(java.lang.Object[]):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.reflect.Constructor Vulcan_Z(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 105733144322839(0x6029ea822317, double:5.2239114236689E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r12
            java.lang.reflect.Constructor r0 = r0.getConstructor(r1)     // Catch: java.lang.NoSuchMethodException -> L50
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.NoSuchMethodException -> L50
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.NoSuchMethodException -> L50
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NoSuchMethodException -> L50
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NoSuchMethodException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NoSuchMethodException -> L50
            r2[r3] = r4     // Catch: java.lang.NoSuchMethodException -> L50
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.NoSuchMethodException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NoSuchMethodException -> L50
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.NoSuchMethodException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NoSuchMethodException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NoSuchMethodException -> L50
            r3.<init>(r4)     // Catch: java.lang.NoSuchMethodException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NoSuchMethodException -> L50
            r1[r2] = r3     // Catch: java.lang.NoSuchMethodException -> L50
            java.lang.reflect.Constructor r0 = Vulcan_p(r0)     // Catch: java.lang.NoSuchMethodException -> L50
            return r0
        L50:
            r15 = move-exception
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_Z(java.lang.Object[]):java.lang.reflect.Constructor");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.reflect.Constructor Vulcan_p(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.reflect.Constructor r1 = (java.lang.reflect.Constructor) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 22075382291951(0x1413d351ddef, double:1.0906688009265E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r14 = r0
            r0 = r12
            r1 = r11
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L50
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L50
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L50
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L50
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.RuntimeException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L50
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L50
            r3.<init>(r4)     // Catch: java.lang.RuntimeException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L50
            r1[r2] = r3     // Catch: java.lang.RuntimeException -> L50
            boolean r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_p(r0)     // Catch: java.lang.RuntimeException -> L50
            r1 = r14
            if (r1 == 0) goto L71
            if (r0 == 0) goto L78
            goto L54
        L50:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5d
            throw r0     // Catch: java.lang.RuntimeException -> L5d
        L54:
            r0 = r11
            r1 = r14
            if (r1 == 0) goto L75
            goto L61
        L5d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6d
            throw r0     // Catch: java.lang.RuntimeException -> L6d
        L61:
            java.lang.Class r0 = r0.getDeclaringClass()     // Catch: java.lang.RuntimeException -> L6d
            int r0 = r0.getModifiers()     // Catch: java.lang.RuntimeException -> L6d
            boolean r0 = java.lang.reflect.Modifier.isPublic(r0)     // Catch: java.lang.RuntimeException -> L6d
            goto L71
        L6d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L71:
            if (r0 == 0) goto L78
            r0 = r11
        L75:
            goto L79
        L78:
            r0 = 0
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_p(java.lang.Object[]):java.lang.reflect.Constructor");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ac: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.reflect.Constructor Vulcan__(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 424
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan__(java.lang.Object[]):java.lang.reflect.Constructor");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0076, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 97;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 115;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006f, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0072). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.m184clinit():void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_i(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 45454422306009(0x29572eb1ecd9, double:2.2457468512959E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1
            r3 = 0
            r4 = r14
            r2[r3] = r4
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_U(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_i(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_L(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 133363716493462(0x794b28f29096, double:6.5890430721131E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1
            r3 = 0
            r4 = r13
            r2[r3] = r4
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_j(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_L(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Class[], java.lang.Exception, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x00a0: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x00a0: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_j(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 24014770374659(0x15d75fdb8803, double:1.1864873034885E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r16 = r0
            r0 = 0
            r1 = r13
            if (r0 != r1) goto L3a
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
            r13 = r0
        L3a:
            r0 = r13
            int r0 = r0.length
            r17 = r0
            r0 = r17
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r18 = r0
            r0 = 0
            r19 = r0
        L49:
            r0 = r19
            r1 = r17
            if (r0 >= r1) goto L7d
        L50:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L6b
            r0 = r18
            r1 = r16
            if (r1 == 0) goto La9
            r1 = r19
            r2 = r13
            r3 = r19
            r2 = r2[r3]     // Catch: java.lang.NoSuchMethodException -> L79
            java.lang.Class r2 = r2.getClass()     // Catch: java.lang.NoSuchMethodException -> L79
            r0[r1] = r2     // Catch: java.lang.NoSuchMethodException -> L79
            int r19 = r19 + 1
        L6b:
            r0 = r16
            if (r0 != 0) goto L49
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L50
            goto L7d
        L79:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7d:
            r0 = r12
            r1 = r14
            r2 = r13
            r3 = r18
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_z(r0)
        La9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_j(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0075: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0075: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_z(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 5103133416811(0x4a42a745d6b, double:2.521282907391E-311)
            long r1 = r1 ^ r2
            r16 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r18 = r0
            r0 = r12
            r1 = r18
            if (r1 == 0) goto L49
            if (r0 != 0) goto L4a
            goto L46
        L42:
            java.lang.Exception r0 = a(r0)
            throw r0
        L46:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
        L49:
            r12 = r0
        L4a:
            r0 = r11
            r1 = r18
            if (r1 == 0) goto L5d
            if (r0 != 0) goto L5e
            goto L5a
        L56:
            java.lang.Exception r0 = a(r0)
            throw r0
        L5a:
            java.lang.Class[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_o
        L5d:
            r11 = r0
        L5e:
            r0 = r15
            r1 = r11
            r2 = r16
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.reflect.Constructor r0 = Vulcan_Z(r0)
            r19 = r0
            r0 = 0
            r1 = r19
            if (r0 != r1) goto Lb1
            java.lang.NoSuchMethodException r0 = new java.lang.NoSuchMethodException     // Catch: java.lang.NoSuchMethodException -> Lad
            r1 = r0
            java.lang.StringBuffer r2 = new java.lang.StringBuffer     // Catch: java.lang.NoSuchMethodException -> Lad
            r3 = r2
            r3.<init>()     // Catch: java.lang.NoSuchMethodException -> Lad
            java.lang.String[] r3 = ac.vulcan.anticheat.Vulcan_f5.b     // Catch: java.lang.NoSuchMethodException -> Lad
            r4 = 1
            r3 = r3[r4]     // Catch: java.lang.NoSuchMethodException -> Lad
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.NoSuchMethodException -> Lad
            r3 = r15
            java.lang.String r3 = r3.getName()     // Catch: java.lang.NoSuchMethodException -> Lad
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.NoSuchMethodException -> Lad
            java.lang.String r2 = r2.toString()     // Catch: java.lang.NoSuchMethodException -> Lad
            r1.<init>(r2)     // Catch: java.lang.NoSuchMethodException -> Lad
            throw r0     // Catch: java.lang.NoSuchMethodException -> Lad
        Lad:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NoSuchMethodException -> Lad
            throw r0
        Lb1:
            r0 = r19
            r1 = r12
            java.lang.Object r0 = r0.newInstance(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_z(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.reflect.Constructor Vulcan_V(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f5.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 37519180417722(0x221f9d6bcaba, double:1.8536938104516E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            r1 = 1
            java.lang.Class[] r1 = new java.lang.Class[r1]
            r2 = r1
            r3 = 0
            r4 = r12
            r2[r3] = r4
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.reflect.Constructor r0 = Vulcan_Z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f5.Vulcan_V(java.lang.Object[]):java.lang.reflect.Constructor");
    }
}
