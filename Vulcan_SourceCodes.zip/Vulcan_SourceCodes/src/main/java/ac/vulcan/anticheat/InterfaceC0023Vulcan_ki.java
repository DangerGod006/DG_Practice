package ac.vulcan.anticheat;

import java.text.Format;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_ki, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_ki.class */
public interface InterfaceC0023Vulcan_ki {
    Format Vulcan_v(Object[] objArr);
}
