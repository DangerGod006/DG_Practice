package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kG.class */
final class Vulcan_kG extends Vulcan_kH {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_kG() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [char, int] */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v23 */
    @Override // ac.vulcan.anticheat.Vulcan_kH
    /* JADX INFO: renamed from: Vulcan_A */
    public int mo437Vulcan_A(Object[] objArr) {
        char[] cArr = (char[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        ((Integer) objArr[2]).intValue();
        ((Integer) objArr[3]).intValue();
        long jLongValue = ((Long) objArr[4]).longValue();
        char cVulcan_m = Vulcan_P.Vulcan_m();
        try {
            try {
                cVulcan_m = cArr[iIntValue];
                ?? r1 = cVulcan_m;
                ?? r12 = r1;
                if (jLongValue > 0) {
                    if (r1 != 0) {
                        return cVulcan_m;
                    }
                    r12 = 32;
                }
                return cVulcan_m <= r12 ? 1 : 0;
            } catch (RuntimeException unused) {
                throw a(cVulcan_m);
            }
        } catch (RuntimeException unused2) {
            cVulcan_m = a(cVulcan_m);
            throw cVulcan_m;
        }
    }
}
