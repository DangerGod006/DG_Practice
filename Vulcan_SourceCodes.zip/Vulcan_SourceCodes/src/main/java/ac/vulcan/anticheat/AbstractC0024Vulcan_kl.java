package ac.vulcan.anticheat;

import java.lang.reflect.Member;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_kl, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kl.class */
abstract class AbstractC0024Vulcan_kl {
    private static final int Vulcan_Y = 7;
    private static final Method Vulcan_o;
    private static final Class[] Vulcan_u;
    static Class Vulcan_U;
    private static final long a;

    private static Exception a(Exception exc) {
        return exc;
    }

    AbstractC0024Vulcan_kl() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r4v16, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00ed -> B:10:0x0085). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0119: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0119: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    static {
        /*
            Method dump skipped, instruction units count: 409
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.m468clinit():void");
    }

    static Class Vulcan_z(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.reflect.Member] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v21, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.reflect.AccessibleObject] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.reflect.AccessibleObject] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r2v5, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0092: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: SecurityException -> 0x00a6]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0092: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: SecurityException -> 0x00a6]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    static void Vulcan_Y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.reflect.AccessibleObject r1 = (java.lang.reflect.AccessibleObject) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 41481948195495(0x25ba44c96aa7, double:2.04948055259604E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 == 0) goto L38
            if (r0 == 0) goto L4a
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)
            throw r0
        L37:
            r0 = r12
        L38:
            r1 = r15
            if (r1 == 0) goto L50
            boolean r0 = r0.isAccessible()     // Catch: java.lang.SecurityException -> L46 java.lang.SecurityException -> L4b
            if (r0 == 0) goto L4f
            goto L4a
        L46:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L4b
            throw r0     // Catch: java.lang.SecurityException -> L4b
        L4a:
            return
        L4b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L4b
            throw r0
        L4f:
            r0 = r12
        L50:
            java.lang.reflect.Member r0 = (java.lang.reflect.Member) r0
            r16 = r0
            r0 = r16
            int r0 = r0.getModifiers()     // Catch: java.lang.SecurityException -> L70
            boolean r0 = java.lang.reflect.Modifier.isPublic(r0)     // Catch: java.lang.SecurityException -> L70
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Laa
            r1 = r15
            if (r1 == 0) goto Laa
            if (r0 == 0) goto Lbb
            goto L74
        L70:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> La6
            throw r0     // Catch: java.lang.SecurityException -> La6
        L74:
            r0 = r16
            java.lang.Class r0 = r0.getDeclaringClass()     // Catch: java.lang.SecurityException -> La6
            int r0 = r0.getModifiers()     // Catch: java.lang.SecurityException -> La6
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.SecurityException -> La6
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.SecurityException -> La6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.SecurityException -> La6
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.SecurityException -> La6
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.SecurityException -> La6
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.SecurityException -> La6
            r4.<init>(r5)     // Catch: java.lang.SecurityException -> La6
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.SecurityException -> La6
            r2[r3] = r4     // Catch: java.lang.SecurityException -> La6
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.SecurityException -> La6
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.SecurityException -> La6
            java.lang.Integer r3 = new java.lang.Integer     // Catch: java.lang.SecurityException -> La6
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.SecurityException -> La6
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.SecurityException -> La6
            r3.<init>(r4)     // Catch: java.lang.SecurityException -> La6
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.SecurityException -> La6
            r1[r2] = r3     // Catch: java.lang.SecurityException -> La6
            boolean r0 = Vulcan_m(r0)     // Catch: java.lang.SecurityException -> La6
            goto Laa
        La6:
            java.lang.Exception r0 = a(r0)
            throw r0
        Laa:
            if (r0 == 0) goto Lbb
            r0 = r12
            r1 = 1
            r0.setAccessible(r1)     // Catch: java.lang.ClassCastException -> Lb5 java.lang.SecurityException -> Lb9
            goto Lbb
        Lb5:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.ClassCastException -> Lb5
            throw r0
        Lb9:
            r17 = move-exception
        Lbb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_Y(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    static boolean Vulcan_m(Object[] objArr) throws Exception {
        int iIntValue = ((Integer) objArr[0]).intValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_d = Vulcan_Y.Vulcan_d();
        try {
            Vulcan_d = iIntValue & Vulcan_Y;
            return Vulcan_d != 0 ? Vulcan_d == 0 : Vulcan_d;
        } catch (SecurityException unused) {
            throw a(Vulcan_d);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0033
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    static boolean Vulcan_p(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.reflect.Member r1 = (java.lang.reflect.Member) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 48853449819541(0x2c6e9485c595, double:2.41368112366645E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 == 0) goto L38
            if (r0 == 0) goto L8d
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)
            throw r0
        L37:
            r0 = r10
        L38:
            int r0 = r0.getModifiers()     // Catch: java.lang.SecurityException -> L51
            boolean r0 = java.lang.reflect.Modifier.isPublic(r0)     // Catch: java.lang.SecurityException -> L51
            r1 = r15
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L7c
            if (r1 == 0) goto L7a
            if (r0 == 0) goto L8d
            goto L55
        L51:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L76
            throw r0     // Catch: java.lang.SecurityException -> L76
        L55:
            r0 = r10
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.SecurityException -> L76
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.SecurityException -> L76
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.SecurityException -> L76
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.SecurityException -> L76
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.SecurityException -> L76
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.SecurityException -> L76
            r4.<init>(r5)     // Catch: java.lang.SecurityException -> L76
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.SecurityException -> L76
            r2[r3] = r4     // Catch: java.lang.SecurityException -> L76
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.SecurityException -> L76
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.SecurityException -> L76
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.SecurityException -> L76
            r1[r2] = r3     // Catch: java.lang.SecurityException -> L76
            boolean r0 = Vulcan_v(r0)     // Catch: java.lang.SecurityException -> L76
            goto L7a
        L76:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7a:
            r1 = r15
        L7c:
            if (r1 == 0) goto L8a
            if (r0 != 0) goto L8d
            goto L89
        L85:
            java.lang.Exception r0 = a(r0)
            throw r0
        L89:
            r0 = 1
        L8a:
            goto L8e
        L8d:
            r0 = 0
        L8e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r0v7 */
    static boolean Vulcan_v(Object[] objArr) throws Exception {
        Member member = (Member) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_d = Vulcan_Y.Vulcan_d();
        try {
            Vulcan_d = Vulcan_o;
            ?? Invoke = Vulcan_d;
            if (Vulcan_d != 0) {
                if (Vulcan_d != 0) {
                    try {
                        Invoke = Vulcan_o.invoke(member, null);
                    } catch (Exception e) {
                        return false;
                    }
                } else {
                    return false;
                }
            }
            return ((Boolean) Invoke).booleanValue();
        } catch (Exception unused) {
            throw a(Vulcan_d);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    static int Vulcan_P(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 88681530284960(0x50a7c71c5ba0, double:4.3814497534429E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r15
            r1 = r16
            r2 = r17
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = Vulcan_X(r0)
            r20 = r0
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r1 = r15
            r2 = r12
            r3 = r17
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            float r1 = Vulcan_X(r1)
            r21 = r1
            r19 = r0
            r0 = r20
            r1 = r21
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r19
            if (r1 == 0) goto La7
            if (r0 >= 0) goto La2
            goto L9a
        L96:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L9e
            throw r0     // Catch: java.lang.SecurityException -> L9e
        L9a:
            r0 = -1
            goto Lbb
        L9e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L9e
            throw r0
        La2:
            r0 = r21
            r1 = r20
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        La7:
            r1 = r19
            if (r1 == 0) goto Lb7
            if (r0 >= 0) goto Lba
            goto Lb6
        Lb2:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lb6:
            r0 = 1
        Lb7:
            goto Lbb
        Lba:
            r0 = 0
        Lbb:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_P(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0067: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0067: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private static float Vulcan_X(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 45399892593402(0x294a7c788afa, double:2.24305272552824E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = 0
            r19 = r0
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r1 = 0
            r20 = r1
            r18 = r0
        L34:
            r0 = r20
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto L85
            r0 = r13
            r1 = r20
            r0 = r0[r1]
            r21 = r0
            r0 = r12
            r1 = r20
            r0 = r0[r1]
            r22 = r0
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L80
            r0 = r19
            r1 = r21
            r2 = r22
            r3 = r16
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            float r1 = Vulcan_a(r1)
            float r0 = r0 + r1
            r1 = r18
            if (r1 == 0) goto L87
            r19 = r0
            int r20 = r20 + 1
        L80:
            r0 = r18
            if (r0 != 0) goto L34
        L85:
            r0 = r19
        L87:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_X(java.lang.Object[]):float");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: NullPointerException in pass: ConstructorVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.sameRegAndSVar(jadx.core.dex.instructions.args.InsnArg)" because "resultArg" is null
        	at jadx.core.dex.visitors.MoveInlineVisitor.processMove(MoveInlineVisitor.java:52)
        	at jadx.core.dex.visitors.MoveInlineVisitor.moveInline(MoveInlineVisitor.java:41)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:43)
        */
    private static float Vulcan_a(
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r10v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    /*  JADX ERROR: NullPointerException in pass: ConstructorVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.sameRegAndSVar(jadx.core.dex.instructions.args.InsnArg)" because "resultArg" is null
        	at jadx.core.dex.visitors.MoveInlineVisitor.processMove(MoveInlineVisitor.java:52)
        	at jadx.core.dex.visitors.MoveInlineVisitor.moveInline(MoveInlineVisitor.java:41)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:38:0x0061, B:35:0x00b2], limit reached: 47 */
    /* JADX WARN: Removed duplicated region for block: B:25:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00ba A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:46:? A[LOOP:0: B:12:0x005b->B:46:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v12 */
    /* JADX WARN: Type inference failed for: r13v13 */
    /* JADX WARN: Type inference failed for: r13v14 */
    /* JADX WARN: Type inference failed for: r13v15 */
    /* JADX WARN: Type inference failed for: r13v16 */
    /* JADX WARN: Type inference failed for: r13v17 */
    /* JADX WARN: Type inference failed for: r13v18 */
    /* JADX WARN: Type inference failed for: r13v19 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v20 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7 */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11 */
    /* JADX WARN: Type inference failed for: r14v12 */
    /* JADX WARN: Type inference failed for: r14v13 */
    /* JADX WARN: Type inference failed for: r14v2, types: [int] */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v6 */
    /* JADX WARN: Type inference failed for: r14v7 */
    /* JADX WARN: Type inference failed for: r14v8 */
    /* JADX WARN: Type inference failed for: r14v9 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v30, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v3 */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static float Vulcan_r(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r7 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int[] r0 = ac.vulcan.anticheat.Vulcan_Y.Vulcan_d()
            r1 = 0
            r12 = r1
            r11 = r0
            r0 = r10
            r13 = r0
            r0 = r13
            boolean r0 = r0.isPrimitive()     // Catch: java.lang.SecurityException -> L3d
            r1 = r11
            if (r1 == 0) goto L59
            if (r0 != 0) goto L58
            goto L41
        L3d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L41:
            r0 = r12
            r1 = 1036831949(0x3dcccccd, float:0.1)
            float r0 = r0 + r1
            r12 = r0
            r0 = r13
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Class r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N(r0)
            r13 = r0
        L58:
            r0 = 0
        L59:
            r14 = r0
        L5b:
            r0 = r13
            r1 = r7
            if (r0 == r1) goto Lb2
            r0 = r14
            java.lang.Class[] r1 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_u     // Catch: java.lang.SecurityException -> L78
            int r1 = r1.length     // Catch: java.lang.SecurityException -> L78
            if (r0 >= r1) goto Lb2
            r0 = r13
            java.lang.Class[] r1 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_u     // Catch: java.lang.SecurityException -> L78
            r2 = r14
            r1 = r1[r2]     // Catch: java.lang.SecurityException -> L78
            if (r0 != r1) goto Laa
            goto L7c
        L78:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7c:
            r0 = r12
            r1 = 1036831949(0x3dcccccd, float:0.1)
            float r0 = r0 + r1
        L81:
            r12 = r0
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            if (r0 == 0) goto Lad
            r0 = r14
            java.lang.Class[] r1 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_u     // Catch: java.lang.SecurityException -> L9c
            int r1 = r1.length     // Catch: java.lang.SecurityException -> L9c
            r2 = 1
            int r1 = r1 - r2
            if (r0 >= r1) goto Laa
            goto La0
        L9c:
            java.lang.Exception r0 = a(r0)
            throw r0
        La0:
            java.lang.Class[] r0 = ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_u
            r1 = r14
            r2 = 1
            int r1 = r1 + r2
            r0 = r0[r1]
            r13 = r0
        Laa:
            int r14 = r14 + 1
        Lad:
            r0 = r11
        Laf:
            if (r0 != 0) goto L5b
        Lb2:
            r0 = r12
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L81
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0024Vulcan_kl.Vulcan_r(java.lang.Object[]):float");
    }
}
