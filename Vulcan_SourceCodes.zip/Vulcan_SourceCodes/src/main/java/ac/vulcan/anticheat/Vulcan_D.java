package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_D.class */
public class Vulcan_D {
    public static final String Vulcan_b;
    static final Object Vulcan_r;
    static final Object Vulcan_P;
    static final Object Vulcan_K;
    static final Object Vulcan_X;
    static final Object Vulcan_C;
    static final Object Vulcan_e;
    static final Object Vulcan__;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-8710760837884725618L, 1791177697185735325L, null).a(264743451178408L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0045: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_Y(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_D.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 74370464249904(0x43a3b91a7830, double:3.6743891451142E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_D.b
            r2 = 2
            r1 = r1[r2]
            r2 = r16
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_Y(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0054: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_n(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_D.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 46415121170477(0x2a36dccf402d, double:2.29321168178914E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_D.b
            r2 = 6
            r1 = r1[r2]
            r2 = r16
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_P(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_n(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0058: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_N(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_D.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 92898327642602(0x547d93d1c1ea, double:4.5897872244314E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            r1 = r16
            r2 = r17
            r3 = 1
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_P(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_N(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0055: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_P(java.lang.Object[] r16) {
        /*
            Method dump skipped, instruction units count: 649
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_P(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x007b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_f(java.lang.Object[] r15) {
        /*
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r20 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_D.a
            r1 = r20
            long r0 = r0 ^ r1
            r20 = r0
            r0 = r20
            r1 = r0; r1 = r0; 
            r2 = 128797508571773(0x752401bf127d, double:6.36344242552565E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r16
            r1 = r18
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_D.b
            r3 = 8
            r2 = r2[r3]
            r3 = 0
            java.util.TimeZone r4 = java.util.TimeZone.getDefault()
            r5 = r22
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_G(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_f(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x007f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_r(java.lang.Object[] r15) {
        /*
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r21 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_D.a
            r1 = r21
            long r0 = r0 ^ r1
            r21 = r0
            r0 = r21
            r1 = r0; r1 = r0; 
            r2 = 63146108642117(0x396e595fe345, double:3.1198322948629E-310)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r17
            r1 = r19
            r2 = r16
            r3 = 1
            java.util.TimeZone r4 = java.util.TimeZone.getDefault()
            r5 = r23
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_G(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_r(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0066: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_G(java.lang.Object[] r16) {
        /*
            Method dump skipped, instruction units count: 1613
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_G(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x01a9: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    static java.lang.String Vulcan_d(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 1716
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_d(java.lang.Object[]):java.lang.String");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v64 ??, still in use, count: 1, list:
          (r0v64 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x00a8: MOVE (r24v12 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v64 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.lang.String Vulcan_T(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v64 ??, still in use, count: 1, list:
          (r0v64 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x00a8: MOVE (r24v12 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v64 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r11 = "7-%kv&Vyxv\b7,%p|0Kd".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.Vulcan_D.b = r0;
        ac.vulcan.anticheat.Vulcan_D.Vulcan_b = ac.vulcan.anticheat.Vulcan_D.b[8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b7, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ba, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00be, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c6, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00ec, code lost:
    
        r7 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00f1, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f6, code lost:
    
        r7 = 67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00fb, code lost:
    
        r7 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0100, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0105, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0109, code lost:
    
        r7 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x010b, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0113, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0116, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x011b, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0120, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0124, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0133, code lost:
    
        ac.vulcan.anticheat.Vulcan_D.Vulcan_r = "y";
        ac.vulcan.anticheat.Vulcan_D.Vulcan_P = "M";
        ac.vulcan.anticheat.Vulcan_D.Vulcan_K = "d";
        ac.vulcan.anticheat.Vulcan_D.Vulcan_X = "H";
        ac.vulcan.anticheat.Vulcan_D.Vulcan_C = "m";
        ac.vulcan.anticheat.Vulcan_D.Vulcan_e = "s";
        ac.vulcan.anticheat.Vulcan_D.Vulcan__ = "S";
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x015d, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a7, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b7, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00ba, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00be, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00c6, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00ec, code lost:
    
        r7 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x010b, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0113, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0116, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00f1, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f6, code lost:
    
        r7 = 67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00fb, code lost:
    
        r7 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x0100, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0105, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0109, code lost:
    
        r7 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x011b, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0120, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003d, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0124, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "7-%kv&Vyxv\b7,%p|0Kd".length();
        r11 = '\n';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0068, code lost:
    
        r10 = r10 + 1;
        "7-%kv&Vyxv\b7,%p|0Kd".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0078, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ba, B:28:0x011b], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v19 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0120 -> B:15:0x00ba). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0120 -> B:35:0x00ba). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 350
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.m8clinit():void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    static ac.vulcan.anticheat.Vulcan_kC[] Vulcan_m(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 559
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_D.Vulcan_m(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_kC[]");
    }
}
