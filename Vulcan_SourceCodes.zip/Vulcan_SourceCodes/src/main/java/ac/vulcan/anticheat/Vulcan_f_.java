package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_f_.class */
public final class Vulcan_f_ {
    private final Number Vulcan_k;
    private final Number Vulcan_j;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(1428655247392189310L, -1742912669323975027L, null).a(279724615902194L);
    private static final String[] b;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0076, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 126;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 122;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006f, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0072). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.m376clinit():void");
    }

    private static NullPointerException a(NullPointerException nullPointerException) {
        return nullPointerException;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.NullPointerException, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public Vulcan_f_(Number number) {
        long j = a ^ 32047823118295L;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            if (Vulcan_k == 0) {
                if (number == null) {
                    throw new NullPointerException(b[0]);
                }
                this.Vulcan_k = number;
                this.Vulcan_j = number;
            }
        } catch (NullPointerException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x001d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_f_(java.lang.Number r6, java.lang.Number r7) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_f_.a
            r1 = 72343631846265(0x41cbd07a5b79, double:3.57425031906263E-310)
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r5
            r1.<init>()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L33
            if (r0 != 0) goto L32
            goto L21
        L1d:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L2e
            throw r0     // Catch: java.lang.NullPointerException -> L2e
        L21:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException     // Catch: java.lang.NullPointerException -> L2e
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_f_.b     // Catch: java.lang.NullPointerException -> L2e
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NullPointerException -> L2e
            r1.<init>(r2)     // Catch: java.lang.NullPointerException -> L2e
            throw r0     // Catch: java.lang.NullPointerException -> L2e
        L2e:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L2e
            throw r0
        L32:
            r0 = r7
        L33:
            r1 = r10
            if (r1 != 0) goto L54
            if (r0 != 0) goto L53
            goto L42
        L3e:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4f
            throw r0     // Catch: java.lang.NullPointerException -> L4f
        L42:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException     // Catch: java.lang.NullPointerException -> L4f
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_f_.b     // Catch: java.lang.NullPointerException -> L4f
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.NullPointerException -> L4f
            r1.<init>(r2)     // Catch: java.lang.NullPointerException -> L4f
            throw r0     // Catch: java.lang.NullPointerException -> L4f
        L4f:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4f
            throw r0
        L53:
            r0 = r7
        L54:
            double r0 = r0.doubleValue()     // Catch: java.lang.NullPointerException -> L71
            r1 = r6
            double r1 = r1.doubleValue()     // Catch: java.lang.NullPointerException -> L71
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L75
            r0 = r5
            r1 = r5
            r2 = r6
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L71 java.lang.NullPointerException -> L82
            r2.Vulcan_j = r3     // Catch: java.lang.NullPointerException -> L71 java.lang.NullPointerException -> L82
            r0.Vulcan_k = r1     // Catch: java.lang.NullPointerException -> L71 java.lang.NullPointerException -> L82
            r0 = r10
            if (r0 == 0) goto L86
            goto L75
        L71:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L82
            throw r0     // Catch: java.lang.NullPointerException -> L82
        L75:
            r0 = r5
            r1 = r6
            r0.Vulcan_k = r1     // Catch: java.lang.NullPointerException -> L82
            r0 = r5
            r1 = r7
            r0.Vulcan_j = r1     // Catch: java.lang.NullPointerException -> L82
            goto L86
        L82:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L86:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.<init>(java.lang.Number, java.lang.Number):void");
    }

    public Number Vulcan_D(Object[] objArr) {
        return this.Vulcan_k;
    }

    public Number Vulcan_n(Object[] objArr) {
        return this.Vulcan_j;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_J(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f_.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r9
            r1 = r12
            if (r1 != 0) goto L38
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L30
            throw r0     // Catch: java.lang.NullPointerException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L30
            throw r0
        L34:
            r0 = r7
            java.lang.Number r0 = r0.Vulcan_k
        L38:
            double r0 = r0.doubleValue()     // Catch: java.lang.NullPointerException -> L51
            r1 = r9
            double r1 = r1.doubleValue()     // Catch: java.lang.NullPointerException -> L51
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L6a
            if (r1 != 0) goto L68
            if (r0 > 0) goto L7b
            goto L55
        L51:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L64
            throw r0     // Catch: java.lang.NullPointerException -> L64
        L55:
            r0 = r7
            java.lang.Number r0 = r0.Vulcan_j     // Catch: java.lang.NullPointerException -> L64
            double r0 = r0.doubleValue()     // Catch: java.lang.NullPointerException -> L64
            r1 = r9
            double r1 = r1.doubleValue()     // Catch: java.lang.NullPointerException -> L64
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L68
        L64:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L68:
            r1 = r12
        L6a:
            if (r1 != 0) goto L78
            if (r0 < 0) goto L7b
            goto L77
        L73:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L77:
            r0 = 1
        L78:
            goto L7c
        L7b:
            r0 = 0
        L7c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.Vulcan_J(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_H(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_f_ r1 = (ac.vulcan.anticheat.Vulcan_f_) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f_.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 29780202671192(0x1b15be66cc58, double:1.47133750660257E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r17
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L3b
            throw r0     // Catch: java.lang.NullPointerException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L3b
            throw r0
        L3f:
            r0 = r10
        L40:
            r1 = r14
            java.lang.Number r1 = r1.Vulcan_k     // Catch: java.lang.NullPointerException -> L73
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.NullPointerException -> L73
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NullPointerException -> L73
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NullPointerException -> L73
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.NullPointerException -> L73
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NullPointerException -> L73
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.NullPointerException -> L73
            r5.<init>(r6)     // Catch: java.lang.NullPointerException -> L73
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L73
            r3[r4] = r5     // Catch: java.lang.NullPointerException -> L73
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L73
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L73
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L73
            r2[r3] = r4     // Catch: java.lang.NullPointerException -> L73
            boolean r0 = r0.Vulcan_J(r1)     // Catch: java.lang.NullPointerException -> L73
            r1 = r17
            r2 = r12
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto La3
            if (r1 != 0) goto La1
            if (r0 == 0) goto Lb4
            goto L77
        L73:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L9d
            throw r0     // Catch: java.lang.NullPointerException -> L9d
        L77:
            r0 = r10
            r1 = r14
            java.lang.Number r1 = r1.Vulcan_j     // Catch: java.lang.NullPointerException -> L9d
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.NullPointerException -> L9d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NullPointerException -> L9d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NullPointerException -> L9d
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.NullPointerException -> L9d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NullPointerException -> L9d
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.NullPointerException -> L9d
            r5.<init>(r6)     // Catch: java.lang.NullPointerException -> L9d
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L9d
            r3[r4] = r5     // Catch: java.lang.NullPointerException -> L9d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L9d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L9d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L9d
            r2[r3] = r4     // Catch: java.lang.NullPointerException -> L9d
            boolean r0 = r0.Vulcan_J(r1)     // Catch: java.lang.NullPointerException -> L9d
            goto La1
        L9d:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        La1:
            r1 = r17
        La3:
            if (r1 != 0) goto Lb1
            if (r0 == 0) goto Lb4
            goto Lb0
        Lac:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        Lb0:
            r0 = 1
        Lb1:
            goto Lb5
        Lb4:
            r0 = 0
        Lb5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.Vulcan_H(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_y(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.Vulcan_y(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_f_.a
            r1 = 47131937025675(0x2addc25d2e8b, double:2.3286270906339E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L20
            throw r0     // Catch: java.lang.NullPointerException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_f_     // Catch: java.lang.NullPointerException -> L33 java.lang.NullPointerException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L39
            throw r0     // Catch: java.lang.NullPointerException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_f_ r0 = (ac.vulcan.anticheat.Vulcan_f_) r0
            r10 = r0
            r0 = r5
            java.lang.Number r0 = r0.Vulcan_k     // Catch: java.lang.NullPointerException -> L5a
            r1 = r10
            java.lang.Number r1 = r1.Vulcan_k     // Catch: java.lang.NullPointerException -> L5a
            boolean r0 = r0.equals(r1)     // Catch: java.lang.NullPointerException -> L5a
            r1 = r9
            if (r1 != 0) goto L71
            if (r0 == 0) goto L84
            goto L5e
        L5a:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6d
            throw r0     // Catch: java.lang.NullPointerException -> L6d
        L5e:
            r0 = r5
            java.lang.Number r0 = r0.Vulcan_j     // Catch: java.lang.NullPointerException -> L6d
            r1 = r10
            java.lang.Number r1 = r1.Vulcan_j     // Catch: java.lang.NullPointerException -> L6d
            boolean r0 = r0.equals(r1)     // Catch: java.lang.NullPointerException -> L6d
            goto L71
        L6d:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L71:
            r1 = r9
            if (r1 != 0) goto L81
            if (r0 == 0) goto L84
            goto L80
        L7c:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L80:
            r0 = 1
        L81:
            goto L85
        L84:
            r0 = 0
        L85:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return (37 * ((37 * 17) + this.Vulcan_k.hashCode())) + this.Vulcan_j.hashCode();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockSplitter
        jadx.core.utils.exceptions.JadxRuntimeException: Unexpected missing predecessor for block: B:20:0x0115
        	at jadx.core.dex.visitors.blocks.BlockSplitter.addTempConnectionsForExcHandlers(BlockSplitter.java:280)
        	at jadx.core.dex.visitors.blocks.BlockSplitter.visit(BlockSplitter.java:79)
        */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 492
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f_.toString():java.lang.String");
    }
}
