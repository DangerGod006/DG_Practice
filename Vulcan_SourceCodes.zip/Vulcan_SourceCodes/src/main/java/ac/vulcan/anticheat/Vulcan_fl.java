package ac.vulcan.anticheat;

import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fl.class */
public class Vulcan_fl {
    private static final ThreadLocal Vulcan_w;
    private final int Vulcan_o;
    private int Vulcan_I;
    static Class Vulcan_q;
    private static int Vulcan_L;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-3445798925659630012L, 2250556550471771986L, null).a(4231573514327L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x007a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void Vulcan_Y(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 569
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_Y(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00b4: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_s(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 341
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_s(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_m(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 43336000044084(0x2769f2e37c34, double:2.14108288499567E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 23283117532301(0x152d05f3248d, double:1.1503388500794E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            r1 = r14
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String[] r1 = ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_r(r1)
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r2 = 3
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 2
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r1; 
            r2 = r0; r0 = r1; r1 = r2; 
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            Vulcan_r(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_m(java.lang.Object[]):int");
    }

    public static void Vulcan_p(int i) {
        Vulcan_L = i;
    }

    public static int Vulcan_F() {
        return Vulcan_L;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_V() {
        return Vulcan_F() == 0 ? 37 : 0;
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008d, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0090, code lost:
    
        r11 = "\u0014 i\u0012l*#9\u0003o\u0013C!\".ah\u001f^0..$iZN+g3%~ZB0+((j\u0016F 5\u001d=\"4\fZ)$=/4\u001bA1.?)\u007f\u001b[k\u0011)-y\u001bA\u001a!0".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0099, code lost:
    
        ac.vulcan.anticheat.Vulcan_fl.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b1, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b4, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b8, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c0, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e8, code lost:
    
        r7 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ed, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f2, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f7, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00fc, code lost:
    
        r7 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0100, code lost:
    
        r7 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0105, code lost:
    
        r7 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0107, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x010f, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0112, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0117, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x011c, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0120, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x012f, code lost:
    
        ac.vulcan.anticheat.Vulcan_fl.Vulcan_w = new java.lang.ThreadLocal();
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0139, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a1, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b1, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b4, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b8, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00c0, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e8, code lost:
    
        r7 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0107, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010f, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0112, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ed, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f2, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f7, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00fc, code lost:
    
        r7 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0100, code lost:
    
        r7 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0105, code lost:
    
        r7 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0117, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011c, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0042, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0120, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0052, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005e, code lost:
    
        r2 = "\u0014 i\u0012l*#9\u0003o\u0013C!\".ah\u001f^0..$iZN+g3%~ZB0+((j\u0016F 5\u001d=\"4\fZ)$=/4\u001bA1.?)\u007f\u001b[k\u0011)-y\u001bA\u001a!0".length();
        r11 = '*';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006d, code lost:
    
        r10 = r10 + 1;
        "\u0014 i\u0012l*#9\u0003o\u0013C!\".ah\u001f^0..$iZN+g3%~ZB0+((j\u0016F 5\u001d=\"4\fZ)$=/4\u001bA1.?)\u007f\u001b[k\u0011)-y\u001bA\u001a!0".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007d, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b4, B:28:0x0117], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v18 */
    /* JADX WARN: Type inference failed for: r5v28 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x011c -> B:15:0x00b4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x011c -> B:35:0x00b4). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 314
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.m386clinit():void");
    }

    static Set Vulcan_V(Object[] objArr) {
        return (Set) Vulcan_w.get();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static boolean Vulcan_k(java.lang.Object[] r5) throws java.lang.Exception {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = Vulcan_V()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.util.Set r1 = Vulcan_V(r1)
            r10 = r1
            r9 = r0
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L3a
            if (r0 == 0) goto L5a
            goto L38
        L34:
            java.lang.Exception r0 = a(r0)
            throw r0
        L38:
            r0 = r10
        L3a:
            ac.vulcan.anticheat.Vulcan_km r1 = new ac.vulcan.anticheat.Vulcan_km     // Catch: java.lang.IllegalArgumentException -> L52
            r2 = r1
            r3 = r6
            r2.<init>(r3)     // Catch: java.lang.IllegalArgumentException -> L52
            boolean r0 = r0.contains(r1)     // Catch: java.lang.IllegalArgumentException -> L52
            r1 = r9
            if (r1 != 0) goto L57
            if (r0 == 0) goto L5a
            goto L56
        L52:
            java.lang.Exception r0 = a(r0)
            throw r0
        L56:
            r0 = 1
        L57:
            goto L5b
        L5a:
            r0 = 0
        L5b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_k(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_X(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 70468152370284(0x40172530a46c, double:3.48158932120637E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r17
            r1 = r13
            r2 = r18
            r3 = r14
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_X(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x007e: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x007e: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_v(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r17 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 28166484677956(0x199e05505544, double:1.3916092443492E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            r1 = r18
            r2 = r19
            r3 = r17
            r4 = r16
            r5 = 0
            r6 = 0
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_v(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0087: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0087: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_T(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r18 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r14 = r1
            r1 = r0
            r2 = 5
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r19 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 113376033791720(0x671d6a385ee8, double:5.6015203358225E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r18
            r1 = r15
            r2 = r20
            r3 = r13
            r4 = r14
            r5 = r19
            r6 = 0
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_T(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_l(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 136902048209728(0x7c82fdf3db40, double:6.76385988657287E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = 17
            r1 = 37
            r2 = r16
            r3 = r15
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_l(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0068: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0068: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_j(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 3405789927349(0x318f8e617b5, double:1.6826838000553E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = 17
            r1 = 37
            r2 = r17
            r3 = r15
            r4 = r16
            r5 = 0
            r6 = 0
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_j(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0063: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0063: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_r(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 69126717517096(0x3eded1712d28, double:3.41531363349694E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = 17
            r1 = 37
            r2 = r17
            r3 = r14
            r4 = 0
            r5 = 0
            r6 = r13
            r7 = 7
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r9 = 6
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_s(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_r(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.ThreadLocal] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v9 */
    static void Vulcan_H(Object[] objArr) throws Exception {
        Object obj = objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_V = Vulcan_V();
        try {
            try {
                Vulcan_V = Vulcan_q;
                ?? r0 = Vulcan_V;
                if (Vulcan_V == 0) {
                    if (Vulcan_V == 0) {
                        Class clsVulcan_J = Vulcan_J(new Object[]{b[0]});
                        Vulcan_q = clsVulcan_J;
                        r0 = clsVulcan_J;
                    } else {
                        r0 = Vulcan_q;
                    }
                }
                ?? r1 = r0;
                synchronized (r0) {
                    int i = Vulcan_V;
                    try {
                        if (jLongValue >= 0) {
                            if (i == 0) {
                                i = 0;
                            }
                            Vulcan_V(new Object[0]).add(new C0025Vulcan_km(obj));
                        }
                        if (Vulcan_V(new Object[i]) == null) {
                            i = Vulcan_w;
                            i.set(new HashSet());
                        }
                        Vulcan_V(new Object[0]).add(new C0025Vulcan_km(obj));
                    } catch (IllegalArgumentException unused) {
                        throw a(i);
                    }
                }
            } catch (IllegalArgumentException unused2) {
                throw a(Vulcan_V);
            }
        } catch (IllegalArgumentException unused3) {
            throw a(Vulcan_V);
        }
    }

    static Class Vulcan_J(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception, java.util.Set] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    static void Vulcan_O(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object obj = objArr[1];
        long j = a ^ jLongValue;
        int iVulcan_F = Vulcan_F();
        ?? Vulcan_V = Vulcan_V(new Object[0]);
        boolean z = Vulcan_V == true ? 1 : 0;
        ?? r0 = z;
        if (iVulcan_F != 0) {
            if (z) {
                r0 = Vulcan_V == true ? 1 : 0;
            } else {
                return;
            }
        }
        try {
            try {
                r0.remove(new C0025Vulcan_km(obj));
                r0 = Vulcan_q;
                ?? r02 = r0;
                if (iVulcan_F != 0) {
                    if (r0 == 0) {
                        Class clsVulcan_J = Vulcan_J(new Object[]{b[7]});
                        Vulcan_q = clsVulcan_J;
                        r02 = clsVulcan_J;
                    } else {
                        r02 = Vulcan_q;
                    }
                }
                ?? r1 = r02;
                synchronized (r02) {
                    ?? Vulcan_V2 = Vulcan_V(new Object[0]);
                    try {
                        try {
                            if (j > 0) {
                                Vulcan_V = Vulcan_V2;
                                if (iVulcan_F != 0) {
                                    Vulcan_V2 = Vulcan_V == true ? 1 : 0;
                                }
                            }
                            if (Vulcan_V2 != 0) {
                                if (j >= 0) {
                                    if (Vulcan_V.isEmpty()) {
                                        Vulcan_w.set(null);
                                    }
                                }
                            }
                        } catch (IllegalArgumentException unused) {
                            throw a(Vulcan_V2);
                        }
                    } catch (IllegalArgumentException unused2) {
                        throw a(Vulcan_V2);
                    }
                }
            } catch (IllegalArgumentException unused3) {
                throw a(r0);
            }
        } catch (IllegalArgumentException unused4) {
            throw a(r0);
        }
    }

    public Vulcan_fl() {
        this.Vulcan_I = 0;
        this.Vulcan_o = 37;
        this.Vulcan_I = 17;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:18:0x0045
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_fl(int r6, int r7) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = 137823113057210(0x7d5971b213ba, double:6.80936653644616E-310)
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = Vulcan_F()
            r1 = r5
            r1.<init>()
            r10 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L22
            r0 = r6
            r1 = r10
            if (r1 == 0) goto L3a
            if (r0 != 0) goto L37
            goto L26
        L22:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L33
            throw r0     // Catch: java.lang.IllegalArgumentException -> L33
        L26:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L33
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fl.b     // Catch: java.lang.IllegalArgumentException -> L33
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L33
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L33
            throw r0     // Catch: java.lang.IllegalArgumentException -> L33
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L33
            throw r0
        L37:
            r0 = r6
            r1 = 2
            int r0 = r0 % r1
        L3a:
            r1 = r10
            if (r1 == 0) goto L5b
            if (r0 != 0) goto L5a
            goto L49
        L45:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0     // Catch: java.lang.IllegalArgumentException -> L56
        L49:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L56
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fl.b     // Catch: java.lang.IllegalArgumentException -> L56
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L56
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0     // Catch: java.lang.IllegalArgumentException -> L56
        L56:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0
        L5a:
            r0 = r7
        L5b:
            r1 = r10
            if (r1 == 0) goto L7e
            if (r0 != 0) goto L7b
            goto L6a
        L66:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L77
            throw r0     // Catch: java.lang.IllegalArgumentException -> L77
        L6a:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L77
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fl.b     // Catch: java.lang.IllegalArgumentException -> L77
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L77
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L77
            throw r0     // Catch: java.lang.IllegalArgumentException -> L77
        L77:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L77
            throw r0
        L7b:
            r0 = r7
            r1 = 2
            int r0 = r0 % r1
        L7e:
            if (r0 != 0) goto L93
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L8f
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fl.b     // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = 6
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L8f
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L8f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8f
        L8f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            throw r0
        L93:
            r0 = r5
            r1 = r7
            r0.Vulcan_o = r1     // Catch: java.lang.IllegalArgumentException -> Lac
            r0 = r5
            r1 = r6
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> Lac
            r0 = r10
            if (r0 != 0) goto Lb0
            r0 = 5
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = new me.frep.vulcan.spigot.check.AbstractCheck[r0]     // Catch: java.lang.IllegalArgumentException -> Lac
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r0)     // Catch: java.lang.IllegalArgumentException -> Lac
            goto Lb0
        Lac:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lb0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.<init>(int, int):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r2v5, types: [int] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    public Vulcan_fl Vulcan_U(Object[] objArr) throws Exception {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_V = Vulcan_V();
        try {
            Vulcan_V = this;
            int i = this.Vulcan_I * this.Vulcan_o;
            boolean z = zBooleanValue;
            ?? r2 = z;
            if (Vulcan_V == 0) {
                r2 = z ? 0 : 1;
            }
            Vulcan_V.Vulcan_I = i + r2;
            return this;
        } catch (IllegalArgumentException unused) {
            throw a(Vulcan_V);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r10v0, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v2, types: [int] */
    /* JADX WARN: Type inference failed for: r18v4 */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r3v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x007f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x00a7]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x007f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x00a7]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_C(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 95753663558087(0x5716631a31c7, double:4.73085956274917E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = Vulcan_V()
            r17 = r0
            r0 = r17
            if (r0 != 0) goto L4b
            r0 = r12
            if (r0 != 0) goto L56
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L47
            throw r0     // Catch: java.lang.IllegalArgumentException -> L47
        L37:
            r0 = r10
            r1 = r10
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L47
            r2 = r10
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L47
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L47
            goto L4b
        L47:
            java.lang.Exception r0 = a(r0)
            throw r0
        L4b:
            r0 = r17
            r1 = r13
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L57
            if (r0 == 0) goto Lab
        L56:
            r0 = 0
        L57:
            r18 = r0
        L59:
            r0 = r18
            r1 = r12
            int r1 = r1.length
            if (r0 >= r1) goto Lab
        L60:
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L99
            r0 = r10
            r1 = r12
            r2 = r18
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> La7
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> La7
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> La7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> La7
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> La7
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> La7
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> La7
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> La7
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> La7
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> La7
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> La7
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> La7
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> La7
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> La7
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> La7
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> La7
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> La7
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> La7
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_U(r1)     // Catch: java.lang.IllegalArgumentException -> La7
            r1 = r17
            if (r1 != 0) goto Lac
        L96:
            int r18 = r18 + 1
        L99:
            r0 = r17
            if (r0 == 0) goto L59
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L60
            goto Lab
        La7:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lab:
            r0 = r10
        Lac:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_C(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    public Vulcan_fl Vulcan_S(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((Integer) objArr[0]).intValue();
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if (r0 != 0) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004e A[PHI: r0
  0x004e: PHI (r0v8 ??) = (r0v20 ??), (r0v19 ??) binds: [B:14:0x0047, B:16:0x004d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0057 A[LOOP:1: B:20:0x0057->B:42:?, LOOP_START, PHI: r13
  0x0057: PHI (r13v2 ??) = (r13v1 ??), (r13v4 ??) binds: [B:19:0x0054, B:42:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_fl m387Vulcan_k(java.lang.Object[] r8) throws java.lang.Exception {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_V()
            r12 = r0
            r0 = r12
            if (r0 != 0) goto L42
            r0 = r9
            if (r0 != 0) goto L4d
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3e
        L2e:
            r0 = r7
            r1 = r7
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L3e
            r2 = r7
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L3e
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L3e
            goto L42
        L3e:
            java.lang.Exception r0 = a(r0)
            throw r0
        L42:
            r0 = r12
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L4e
            if (r0 == 0) goto L91
        L4d:
            r0 = 0
        L4e:
            r13 = r0
        L50:
            r0 = r13
            r1 = r9
            int r1 = r1.length
            if (r0 >= r1) goto L91
        L57:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7f
            r0 = r7
            r1 = r9
            r2 = r13
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_S(r1)     // Catch: java.lang.IllegalArgumentException -> L8d
            r1 = r12
            if (r1 != 0) goto L92
        L7c:
            int r13 = r13 + 1
        L7f:
            r0 = r12
            if (r0 == 0) goto L50
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L57
            goto L91
        L8d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L91:
            r0 = r7
        L92:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.m387Vulcan_k(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    public Vulcan_fl Vulcan_N(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((Integer) objArr[0]).intValue();
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if (r0 == 0) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004e A[PHI: r0
  0x004e: PHI (r0v8 ??) = (r0v20 ??), (r0v19 ??) binds: [B:14:0x0047, B:16:0x004d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0057 A[LOOP:1: B:20:0x0057->B:42:?, LOOP_START, PHI: r13
  0x0057: PHI (r13v2 ??) = (r13v1 ??), (r13v4 ??) binds: [B:19:0x0054, B:42:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_h(java.lang.Object[] r8) throws java.lang.Exception {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_F()
            r12 = r0
            r0 = r12
            if (r0 == 0) goto L42
            r0 = r9
            if (r0 != 0) goto L4d
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3e
        L2e:
            r0 = r7
            r1 = r7
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L3e
            r2 = r7
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L3e
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L3e
            goto L42
        L3e:
            java.lang.Exception r0 = a(r0)
            throw r0
        L42:
            r0 = r12
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L4e
            if (r0 != 0) goto L91
        L4d:
            r0 = 0
        L4e:
            r13 = r0
        L50:
            r0 = r13
            r1 = r9
            int r1 = r1.length
            if (r0 >= r1) goto L91
        L57:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7f
            r0 = r7
            r1 = r9
            r2 = r13
            char r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_N(r1)     // Catch: java.lang.IllegalArgumentException -> L8d
            r1 = r12
            if (r1 == 0) goto L92
        L7c:
            int r13 = r13 + 1
        L7f:
            r0 = r12
            if (r0 != 0) goto L50
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L57
            goto L91
        L8d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L91:
            r0 = r7
        L92:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_h(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [ac.vulcan.anticheat.Vulcan_fl, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_fl m388Vulcan_j(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            r0 = r9
            r1 = r11
            long r1 = java.lang.Double.doubleToLongBits(r1)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_x(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.m388Vulcan_j(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v2, types: [int] */
    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v5 */
    /* JADX WARN: Type inference failed for: r15v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v5, types: [ac.vulcan.anticheat.Vulcan_fl, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Double] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0074: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x008f]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0074: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x008f]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_b(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = Vulcan_F()
            r14 = r0
            r0 = r14
            if (r0 == 0) goto L42
            r0 = r11
            if (r0 != 0) goto L4d
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3e
        L2e:
            r0 = r9
            r1 = r9
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L3e
            r2 = r9
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L3e
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L3e
            goto L42
        L3e:
            java.lang.Exception r0 = a(r0)
            throw r0
        L42:
            r0 = r14
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L4e
            if (r0 != 0) goto L93
        L4d:
            r0 = 0
        L4e:
            r15 = r0
        L50:
            r0 = r15
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L93
        L57:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L81
            r0 = r9
            r1 = r11
            r2 = r15
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L8f
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L8f
            java.lang.Double r4 = new java.lang.Double     // Catch: java.lang.IllegalArgumentException -> L8f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8f
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.m388Vulcan_j(r1)     // Catch: java.lang.IllegalArgumentException -> L8f
            r1 = r14
            if (r1 == 0) goto L94
        L7e:
            int r15 = r15 + 1
        L81:
            r0 = r14
            if (r0 != 0) goto L50
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L57
            goto L93
        L8f:
            java.lang.Exception r0 = a(r0)
            throw r0
        L93:
            r0 = r9
        L94:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_b(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public Vulcan_fl m389Vulcan_T(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + Float.floatToIntBits(((Float) objArr[0]).floatValue());
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x004c, code lost:
    
        if (r0 == 0) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0050 A[PHI: r0
  0x0050: PHI (r0v8 ??) = (r0v20 ??), (r0v19 ??) binds: [B:14:0x0049, B:16:0x004f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005a A[LOOP:1: B:20:0x005a->B:42:?, LOOP_START, PHI: r13
  0x005a: PHI (r13v2 ??) = (r13v1 ??), (r13v4 ??) binds: [B:19:0x0057, B:42:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_a(java.lang.Object[] r8) throws java.lang.Exception {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_F()
            r12 = r0
            r0 = r12
            if (r0 == 0) goto L44
            r0 = r11
            if (r0 != 0) goto L4f
            goto L30
        L2c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L40
            throw r0     // Catch: java.lang.IllegalArgumentException -> L40
        L30:
            r0 = r7
            r1 = r7
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L40
            r2 = r7
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L40
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L40
            goto L44
        L40:
            java.lang.Exception r0 = a(r0)
            throw r0
        L44:
            r0 = r12
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L50
            if (r0 != 0) goto L95
        L4f:
            r0 = 0
        L50:
            r13 = r0
        L52:
            r0 = r13
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L95
        L5a:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L83
            r0 = r7
            r1 = r11
            r2 = r13
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L91
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L91
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L91
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L91
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> L91
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L91
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L91
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L91
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L91
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L91
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.m389Vulcan_T(r1)     // Catch: java.lang.IllegalArgumentException -> L91
            r1 = r12
            if (r1 == 0) goto L96
        L80:
            int r13 = r13 + 1
        L83:
            r0 = r12
            if (r0 != 0) goto L52
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5a
            goto L95
        L91:
            java.lang.Exception r0 = a(r0)
            throw r0
        L95:
            r0 = r7
        L96:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_a(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    public Vulcan_fl Vulcan_L(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((Integer) objArr[0]).intValue();
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if (r0 == 0) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004e A[PHI: r0
  0x004e: PHI (r0v8 ??) = (r0v20 ??), (r0v19 ??) binds: [B:14:0x0047, B:16:0x004d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0057 A[LOOP:1: B:20:0x0057->B:42:?, LOOP_START, PHI: r13
  0x0057: PHI (r13v2 ??) = (r13v1 ??), (r13v4 ??) binds: [B:19:0x0054, B:42:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_fl m390Vulcan_V(java.lang.Object[] r8) throws java.lang.Exception {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_F()
            r12 = r0
            r0 = r12
            if (r0 == 0) goto L42
            r0 = r9
            if (r0 != 0) goto L4d
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3e
        L2e:
            r0 = r7
            r1 = r7
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L3e
            r2 = r7
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L3e
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L3e
            goto L42
        L3e:
            java.lang.Exception r0 = a(r0)
            throw r0
        L42:
            r0 = r12
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L4e
            if (r0 != 0) goto L91
        L4d:
            r0 = 0
        L4e:
            r13 = r0
        L50:
            r0 = r13
            r1 = r9
            int r1 = r1.length
            if (r0 >= r1) goto L91
        L57:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7f
            r0 = r7
            r1 = r9
            r2 = r13
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_L(r1)     // Catch: java.lang.IllegalArgumentException -> L8d
            r1 = r12
            if (r1 == 0) goto L92
        L7c:
            int r13 = r13 + 1
        L7f:
            r0 = r12
            if (r0 != 0) goto L50
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L57
            goto L91
        L8d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L91:
            r0 = r7
        L92:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.m390Vulcan_V(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    public Vulcan_fl Vulcan_x(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((int) (jLongValue ^ (jLongValue >> 32)));
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v2, types: [int] */
    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v5 */
    /* JADX WARN: Type inference failed for: r15v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v5, types: [ac.vulcan.anticheat.Vulcan_fl, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0078: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0093]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0078: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0093]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_W(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = Vulcan_V()
            r14 = r0
            r0 = r14
            if (r0 != 0) goto L44
            r0 = r13
            if (r0 != 0) goto L4f
            goto L30
        L2c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L40
            throw r0     // Catch: java.lang.IllegalArgumentException -> L40
        L30:
            r0 = r9
            r1 = r9
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L40
            r2 = r9
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L40
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L40
            goto L44
        L40:
            java.lang.Exception r0 = a(r0)
            throw r0
        L44:
            r0 = r14
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L50
            if (r0 == 0) goto L97
        L4f:
            r0 = 0
        L50:
            r15 = r0
        L52:
            r0 = r15
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto L97
        L5a:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L85
            r0 = r9
            r1 = r13
            r2 = r15
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_x(r1)     // Catch: java.lang.IllegalArgumentException -> L93
            r1 = r14
            if (r1 != 0) goto L98
        L82:
            int r15 = r15 + 1
        L85:
            r0 = r14
            if (r0 == 0) goto L52
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5a
            goto L97
        L93:
            java.lang.Exception r0 = a(r0)
            throw r0
        L97:
            r0 = r9
        L98:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_W(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x006d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_g(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 973
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_g(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r17v0 */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2, types: [int] */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Type inference failed for: r17v5 */
    /* JADX WARN: Type inference failed for: r17v6 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_fl, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x008a: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x00a5]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x008a: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x00a5]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_fl m391Vulcan_v(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 89491569186352(0x516461311630, double:4.42147099274016E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_F()
            r16 = r0
            r0 = r16
            if (r0 == 0) goto L4d
            r0 = r13
            if (r0 != 0) goto L58
            goto L39
        L35:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L39:
            r0 = r9
            r1 = r9
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L49
            r2 = r9
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L49
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L49
            goto L4d
        L49:
            java.lang.Exception r0 = a(r0)
            throw r0
        L4d:
            r0 = r16
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L59
            if (r0 != 0) goto La9
        L58:
            r0 = 0
        L59:
            r17 = r0
        L5b:
            r0 = r17
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La9
        L63:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L97
            r0 = r9
            r1 = r13
            r2 = r17
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> La5
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> La5
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> La5
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> La5
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> La5
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> La5
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> La5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> La5
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> La5
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> La5
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> La5
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> La5
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> La5
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> La5
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> La5
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.Vulcan_g(r1)     // Catch: java.lang.IllegalArgumentException -> La5
            r1 = r16
            if (r1 == 0) goto Laa
        L94:
            int r17 = r17 + 1
        L97:
            r0 = r16
            if (r0 != 0) goto L5b
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L63
            goto La9
        La5:
            java.lang.Exception r0 = a(r0)
            throw r0
        La9:
            r0 = r9
        Laa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.m391Vulcan_v(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public Vulcan_fl m392Vulcan_X(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((Integer) objArr[0]).intValue();
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x004c, code lost:
    
        if (r0 == 0) goto L16;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0050 A[PHI: r0
  0x0050: PHI (r0v8 ??) = (r0v20 ??), (r0v19 ??) binds: [B:14:0x0049, B:16:0x004f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005a A[LOOP:1: B:20:0x005a->B:42:?, LOOP_START, PHI: r13
  0x005a: PHI (r13v2 ??) = (r13v1 ??), (r13v4 ??) binds: [B:19:0x0057, B:42:?] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fl] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [int] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_fl Vulcan_F(java.lang.Object[] r8) throws java.lang.Exception {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fl.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_F()
            r12 = r0
            r0 = r12
            if (r0 == 0) goto L44
            r0 = r11
            if (r0 != 0) goto L4f
            goto L30
        L2c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L40
            throw r0     // Catch: java.lang.IllegalArgumentException -> L40
        L30:
            r0 = r7
            r1 = r7
            int r1 = r1.Vulcan_I     // Catch: java.lang.IllegalArgumentException -> L40
            r2 = r7
            int r2 = r2.Vulcan_o     // Catch: java.lang.IllegalArgumentException -> L40
            int r1 = r1 * r2
            r0.Vulcan_I = r1     // Catch: java.lang.IllegalArgumentException -> L40
            goto L44
        L40:
            java.lang.Exception r0 = a(r0)
            throw r0
        L44:
            r0 = r12
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L50
            if (r0 != 0) goto L95
        L4f:
            r0 = 0
        L50:
            r13 = r0
        L52:
            r0 = r13
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L95
        L5a:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L83
            r0 = r7
            r1 = r11
            r2 = r13
            short r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L91
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L91
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L91
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L91
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L91
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L91
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L91
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L91
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L91
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L91
            ac.vulcan.anticheat.Vulcan_fl r0 = r0.m392Vulcan_X(r1)     // Catch: java.lang.IllegalArgumentException -> L91
            r1 = r12
            if (r1 == 0) goto L96
        L80:
            int r13 = r13 + 1
        L83:
            r0 = r12
            if (r0 != 0) goto L52
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5a
            goto L95
        L91:
            java.lang.Exception r0 = a(r0)
            throw r0
        L95:
            r0 = r7
        L96:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fl.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fl");
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public Vulcan_fl m393Vulcan_O(Object[] objArr) {
        this.Vulcan_I = (this.Vulcan_I * this.Vulcan_o) + ((Integer) objArr[0]).intValue();
        return this;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public int m394Vulcan_N(Object[] objArr) {
        return this.Vulcan_I;
    }

    public int hashCode() {
        return m394Vulcan_N(new Object[0]);
    }
}
