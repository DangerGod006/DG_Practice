package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OR.class */
class Vulcan_OR implements InterfaceC0031Vulcan_n {
    static final Vulcan_OR Vulcan_A = new Vulcan_OR(true);
    static final Vulcan_OR Vulcan_m = new Vulcan_OR(false);
    final boolean Vulcan__;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_OR(boolean z) {
        this.Vulcan__ = z;
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return 5;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0063, code lost:
    
        if (r0 != 0) goto L49;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x006d A[PHI: r12
  0x006d: PHI (r12v3 int) = (r12v10 int), (r12v11 int) binds: [B:16:0x005e, B:19:0x0066] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.RuntimeException, java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.StringBuffer] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_g(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 252
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OR.Vulcan_g(java.lang.Object[]):void");
    }
}
