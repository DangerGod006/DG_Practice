package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O3.class */
public final class Vulcan_O3 extends Vulcan_OA implements Serializable {
    private static final long serialVersionUID = 71849363892750L;
    private final float Vulcan_V;
    private final float Vulcan_r;
    private transient Float Vulcan_E;
    private transient Float Vulcan_o;
    private transient int Vulcan_h;
    private transient String Vulcan_K;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(729281599275901748L, -8374675197048186289L, null).a(12497006771849L);
    private static final String[] d;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0086, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0089, code lost:
    
        r11 = "c\u0017Z\u0006)\u001aCU\u001aMUg\u0002[D\u000b\u001fH(\u001b\u000eU\u001a\u001fH2\u0003B\u001ac\u0017Z\u0006)\u001aCU\u001aM\u0006*\u001a]C_QI3OLR_qG\t".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0092, code lost:
    
        ac.vulcan.anticheat.Vulcan_O3.d = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00aa, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b9, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e4, code lost:
    
        r7 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00e9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ee, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f3, code lost:
    
        r7 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f8, code lost:
    
        r7 = 89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fd, code lost:
    
        r7 = 24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0107, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0127, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009a, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00aa, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b9, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0107, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e4, code lost:
    
        r7 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ee, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f3, code lost:
    
        r7 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f8, code lost:
    
        r7 = 89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fd, code lost:
    
        r7 = 24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "c\u0017Z\u0006)\u001aCU\u001aMUg\u0002[D\u000b\u001fH(\u001b\u000eU\u001a\u001fH2\u0003B\u001ac\u0017Z\u0006)\u001aCU\u001aM\u0006*\u001a]C_QI3OLR_qG\t".length();
        r11 = 28;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r10 = r10 + 1;
        "c\u0017Z\u0006)\u001aCU\u001aMUg\u0002[D\u000b\u001fH(\u001b\u000eU\u001a\u001fH2\u0003B\u001ac\u0017Z\u0006)\u001aCU\u001aM\u0006*\u001a]C_QI3OLR_qG\t".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ad, B:28:0x010f], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0114 -> B:15:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0114 -> B:34:0x00ad). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.m40clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    public Vulcan_O3(float f) {
        long j = a ^ 6010827783712L;
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        this.Vulcan_E = null;
        try {
            try {
                this.Vulcan_o = null;
                this.Vulcan_h = 0;
                this.Vulcan_K = null;
                if (Vulcan_Q == 0) {
                    Vulcan_Q = Float.isNaN(f);
                    if (Vulcan_Q != 0) {
                        throw new IllegalArgumentException(d[6]);
                    }
                    this.Vulcan_V = f;
                    this.Vulcan_r = f;
                }
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00b8 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00a1 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [ac.vulcan.anticheat.Vulcan_O3] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_O3(java.lang.Number r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_O3.a
            r1 = 80109670774860(0x48dbfc78384c, double:3.9579436229511E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r1 = r5
            r1.<init>()
            r1 = r5
            r2 = 0
            r1.Vulcan_E = r2
            r1 = r5
            r2 = 0
            r1.Vulcan_o = r2
            r9 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_h = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r5
            r1 = 0
            r0.Vulcan_K = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r6
            if (r0 != 0) goto L46
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L35:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L42
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O3.d     // Catch: java.lang.IllegalArgumentException -> L42
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L42
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0
        L46:
            r0 = r5
            r1 = r6
            float r1 = r1.floatValue()
            r0.Vulcan_V = r1
            r0 = r5
            r1 = r6
            float r1 = r1.floatValue()
            r0.Vulcan_r = r1
        L56:
            r0 = r5
            float r0 = r0.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L68
            boolean r0 = java.lang.Float.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L68
            r1 = r9
            if (r1 == 0) goto L7a
            if (r0 != 0) goto L89
            goto L6c
        L68:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            throw r0     // Catch: java.lang.IllegalArgumentException -> L76
        L6c:
            r0 = r5
            float r0 = r0.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L76
            boolean r0 = java.lang.Float.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            goto L7a
        L76:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L7a:
            r1 = r9
            if (r1 == 0) goto L9e
            if (r0 == 0) goto L9a
            goto L89
        L85:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L96
            throw r0     // Catch: java.lang.IllegalArgumentException -> L96
        L89:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L96
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O3.d     // Catch: java.lang.IllegalArgumentException -> L96
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L96
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L96
            throw r0     // Catch: java.lang.IllegalArgumentException -> L96
        L96:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L96
            throw r0
        L9a:
            r0 = r6
            boolean r0 = r0 instanceof java.lang.Float
        L9e:
            if (r0 == 0) goto Lb8
            r0 = r5
            r1 = r6
            java.lang.Float r1 = (java.lang.Float) r1     // Catch: java.lang.IllegalArgumentException -> Lb4
            r0.Vulcan_E = r1     // Catch: java.lang.IllegalArgumentException -> Lb4
            r0 = r5
            r1 = r6
            java.lang.Float r1 = (java.lang.Float) r1     // Catch: java.lang.IllegalArgumentException -> Lb4
            r0.Vulcan_o = r1     // Catch: java.lang.IllegalArgumentException -> Lb4
            goto Lb8
        Lb4:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        Lb8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.<init>(java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0069 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_O3(float r6, float r7) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_O3.a
            r1 = 25857116843142(0x17845443ac86, double:1.27751131326995E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r5
            r0.<init>()
            r0 = r5
            r1 = 0
            r0.Vulcan_E = r1
            r0 = r5
            r1 = 0
            r0.Vulcan_o = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r5
            r2 = 0
            r1.Vulcan_h = r2
            r10 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_K = r1     // Catch: java.lang.IllegalArgumentException -> L34
            r0 = r6
            boolean r0 = java.lang.Float.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L34
            r1 = r10
            if (r1 != 0) goto L43
            if (r0 != 0) goto L52
            goto L38
        L34:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3f
        L38:
            r0 = r7
            boolean r0 = java.lang.Float.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L3f
            goto L43
        L3f:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L43:
            r1 = r10
            if (r1 != 0) goto L66
            if (r0 == 0) goto L63
            goto L52
        L4e:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L52:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L5f
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O3.d     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 3
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L5f
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L5f:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r7
            r1 = r6
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L66:
            if (r0 >= 0) goto L7f
            r0 = r5
            r1 = r7
            r0.Vulcan_V = r1     // Catch: java.lang.IllegalArgumentException -> L7b java.lang.IllegalArgumentException -> L8c
            r0 = r5
            r1 = r6
            r0.Vulcan_r = r1     // Catch: java.lang.IllegalArgumentException -> L7b java.lang.IllegalArgumentException -> L8c
            r0 = r10
            if (r0 == 0) goto L90
            goto L7f
        L7b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8c
        L7f:
            r0 = r5
            r1 = r6
            r0.Vulcan_V = r1     // Catch: java.lang.IllegalArgumentException -> L8c
            r0 = r5
            r1 = r7
            r0.Vulcan_r = r1     // Catch: java.lang.IllegalArgumentException -> L8c
            goto L90
        L8c:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L90:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.<init>(float, float):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:46:0x00b2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_O3(java.lang.Number r6, java.lang.Number r7) {
        /*
            Method dump skipped, instruction units count: 338
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.<init>(java.lang.Number, java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Float, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_v(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan_E;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan_E = new Float(this.Vulcan_V);
                }
                return this.Vulcan_E;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_j(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (long) this.Vulcan_V;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_g(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_V;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_Q(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_V;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_W(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_V;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Float, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_l(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan_o;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan_o = new Float(this.Vulcan_r);
                }
                return this.Vulcan_o;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_E(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (long) this.Vulcan_r;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_r;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_X(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_r;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_U(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_r;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_p(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r14 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 135827539685301(0x7b88d040efb5, double:6.7107721117646E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L24
            throw r0
        L28:
            r0 = r10
            r1 = r14
            float r1 = r1.floatValue()
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_x(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_x(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r11
            r1 = r7
            float r1 = r1.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L34
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L48
            if (r1 == 0) goto L46
            if (r0 < 0) goto L59
            goto L38
        L34:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L38:
            r0 = r11
            r1 = r7
            float r1 = r1.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L42
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L46
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L46:
            r1 = r12
        L48:
            if (r1 == 0) goto L56
            if (r0 > 0) goto L59
            goto L55
        L51:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L55:
            r0 = 1
        L56:
            goto L5a
        L59:
            r0 = 0
        L5a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.Vulcan_x(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0037
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_O(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 236
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_I(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 281
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.Vulcan_I(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_O3.a
            r1 = 121059801407228(0x6e1a6e759efc, double:5.9811488967675E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_O3     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_O3 r0 = (ac.vulcan.anticheat.Vulcan_O3) r0
            r10 = r0
            r0 = r5
            float r0 = r0.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L5d
            int r0 = java.lang.Float.floatToIntBits(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            r1 = r10
            float r1 = r1.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L5d
            int r1 = java.lang.Float.floatToIntBits(r1)     // Catch: java.lang.IllegalArgumentException -> L5d
            r2 = r9
            if (r2 != 0) goto L83
            if (r0 != r1) goto L8a
            goto L61
        L5d:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L70
            throw r0     // Catch: java.lang.IllegalArgumentException -> L70
        L61:
            r0 = r5
            float r0 = r0.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L70 java.lang.IllegalArgumentException -> L7f
            int r0 = java.lang.Float.floatToIntBits(r0)     // Catch: java.lang.IllegalArgumentException -> L70 java.lang.IllegalArgumentException -> L7f
            r1 = r9
            if (r1 != 0) goto L87
            goto L74
        L70:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L7f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L7f
        L74:
            r1 = r10
            float r1 = r1.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L7f
            int r1 = java.lang.Float.floatToIntBits(r1)     // Catch: java.lang.IllegalArgumentException -> L7f
            goto L83
        L7f:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L83:
            if (r0 != r1) goto L8a
            r0 = 1
        L87:
            goto L8b
        L8a:
            r0 = 0
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O3.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int hashCode() {
        long j = a ^ 115833311442392L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_h;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_h = 17;
                    this.Vulcan_h = (37 * this.Vulcan_h) + getClass().hashCode();
                    this.Vulcan_h = (37 * this.Vulcan_h) + Float.floatToIntBits(this.Vulcan_V);
                    this.Vulcan_h = (37 * this.Vulcan_h) + Float.floatToIntBits(this.Vulcan_r);
                }
                return this.Vulcan_h;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public String toString() {
        long j = a ^ 53767370579987L;
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            Vulcan_Q = this.Vulcan_K;
            if (Vulcan_Q != 0) {
                return Vulcan_Q;
            }
            if (Vulcan_Q == 0) {
                StringBuffer stringBuffer = new StringBuffer(32);
                stringBuffer.append(d[2]);
                stringBuffer.append(this.Vulcan_V);
                stringBuffer.append(',');
                stringBuffer.append(this.Vulcan_r);
                stringBuffer.append(']');
                this.Vulcan_K = stringBuffer.toString();
            }
            return this.Vulcan_K;
        } catch (IllegalArgumentException unused) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }
}
