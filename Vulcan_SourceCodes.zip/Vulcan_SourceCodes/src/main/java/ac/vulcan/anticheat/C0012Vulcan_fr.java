package ac.vulcan.anticheat;

import java.util.Locale;
import java.util.TimeZone;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fr, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fr.class */
class C0012Vulcan_fr implements InterfaceC0031Vulcan_n {
    private final TimeZone Vulcan_i;
    private final boolean Vulcan_h;
    private final Locale Vulcan_G;
    private final int Vulcan_x;
    private final String Vulcan_d;
    private final String Vulcan_M;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-281886432452239825L, 4960699525548336961L, null).a(155256016876235L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v18, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v26, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v9 ??, still in use, count: 2, list:
          (r6v9 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r6v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v9 ?? I:??[OBJECT, ARRAY])
          (r6v9 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r6v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    C0012Vulcan_fr(java.util.TimeZone r12, boolean r13, java.util.Locale r14, int r15) {
        /*
            r11 = this;
            long r0 = ac.vulcan.anticheat.C0012Vulcan_fr.a
            r1 = 116050259162179(0x698c0e793443, double:5.7336446243006E-310)
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 41074059131373(0x255b4cb439ed, double:2.02932815520634E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r0.<init>()
            r0 = r11
            r1 = r12
            r0.Vulcan_i = r1
            r0 = r11
            r1 = r13
            r0.Vulcan_h = r1
            r0 = r11
            r1 = r14
            r0.Vulcan_G = r1
            r0 = r11
            r1 = r15
            r0.Vulcan_x = r1
            r0 = r13
            if (r0 == 0) goto Lbd
            r0 = r11
            r1 = r12
            r2 = 0
            r3 = r18
            r4 = r15
            r5 = r14
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r1 = ac.vulcan.anticheat.Vulcan_G.m19Vulcan_D(r1)
            r0.Vulcan_d = r1
            r0 = r11
            r1 = r12
            r2 = 1
            r3 = r18
            r4 = r15
            r5 = r14
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r1 = ac.vulcan.anticheat.Vulcan_G.m19Vulcan_D(r1)
            r0.Vulcan_M = r1
            goto Lc7
        Lbd:
            r0 = r11
            r1 = 0
            r0.Vulcan_d = r1
            r0 = r11
            r1 = 0
            r0.Vulcan_M = r1
        Lc7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0012Vulcan_fr.<init>(java.util.TimeZone, boolean, java.util.Locale, int):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r11 = r0
            r0 = r7
            boolean r0 = r0.Vulcan_h     // Catch: java.lang.RuntimeException -> L26
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L46
            if (r1 != 0) goto L44
            if (r0 == 0) goto L40
            goto L2a
        L26:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3c
            throw r0     // Catch: java.lang.RuntimeException -> L3c
        L2a:
            r0 = r7
            java.lang.String r0 = r0.Vulcan_d     // Catch: java.lang.RuntimeException -> L3c
            int r0 = r0.length()     // Catch: java.lang.RuntimeException -> L3c
            r1 = r7
            java.lang.String r1 = r1.Vulcan_M     // Catch: java.lang.RuntimeException -> L3c
            int r1 = r1.length()     // Catch: java.lang.RuntimeException -> L3c
            int r0 = java.lang.Math.max(r0, r1)     // Catch: java.lang.RuntimeException -> L3c
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3c
            throw r0
        L40:
            r0 = r7
            int r0 = r0.Vulcan_x
        L44:
            r1 = r11
        L46:
            if (r1 != 0) goto L5b
            if (r0 != 0) goto L59
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L55
            throw r0     // Catch: java.lang.RuntimeException -> L55
        L53:
            r0 = 4
            return r0
        L55:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L55
            throw r0
        L59:
            r0 = 40
        L5b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0012Vulcan_fr.Vulcan_r(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.util.TimeZone] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v43, types: [int] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v18, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v26, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v26 ??, still in use, count: 2, list:
          (r6v26 ?? I:??[OBJECT, ARRAY][]) from 0x015b: APUT (r6v26 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v26 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0178]
          (r6v26 ?? I:??[OBJECT, ARRAY]) from 0x015b: APUT (r6v26 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v26 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0178]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 381
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0012Vulcan_fr.Vulcan_g(java.lang.Object[]):void");
    }
}
