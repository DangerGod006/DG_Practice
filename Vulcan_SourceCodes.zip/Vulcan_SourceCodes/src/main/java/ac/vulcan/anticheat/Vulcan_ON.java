package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_ON.class */
public final class Vulcan_ON extends Vulcan_OA implements Serializable {
    private static final long serialVersionUID = 71849363892710L;
    private final Number Vulcan_h;
    private final Number Vulcan_b;
    private transient int Vulcan_n;
    private transient String Vulcan_Z;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-1589636109334464022L, -3060306928999898397L, null).a(208316399265985L);
    private static final String[] d;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0086, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0089, code lost:
    
        r11 = "7fwA\u007fE\u0002\u0001k`A|E\u001c\u0017.|\u000ee\u0010\r\u0006.|\u0014}\\%7fwA\u007fE\u0002\u0001k`\u00121]\u001a\u0010z2\b|@\u0003\u0006cw\u000fe\u0010,\fcb\u0000cQ\r\u000fk".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0092, code lost:
    
        ac.vulcan.anticheat.Vulcan_ON.d = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00aa, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b9, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e4, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00e9, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ee, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f2, code lost:
    
        r7 = 115;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f7, code lost:
    
        r7 = 82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fc, code lost:
    
        r7 = 13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00fe, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0106, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0109, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x010e, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0113, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0117, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0126, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009a, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00aa, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b9, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00fe, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0106, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0109, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e4, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e9, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ee, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f2, code lost:
    
        r7 = 115;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f7, code lost:
    
        r7 = 82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fc, code lost:
    
        r7 = 13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x010e, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0113, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0117, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "7fwA\u007fE\u0002\u0001k`A|E\u001c\u0017.|\u000ee\u0010\r\u0006.|\u0014}\\%7fwA\u007fE\u0002\u0001k`\u00121]\u001a\u0010z2\b|@\u0003\u0006cw\u000fe\u0010,\fcb\u0000cQ\r\u000fk".length();
        r11 = 27;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r10 = r10 + 1;
        "7fwA\u007fE\u0002\u0001k`A|E\u001c\u0017.|\u000ee\u0010\r\u0006.|\u0014}\\%7fwA\u007fE\u0002\u0001k`\u00121]\u001a\u0010z2\b|@\u0003\u0006cw\u000fe\u0010,\fcb\u0000cQ\r\u000fk".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ad, B:28:0x010e], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0113 -> B:15:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0113 -> B:34:0x00ad). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.m90clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:29:0x0070
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_ON(java.lang.Number r6) {
        /*
            Method dump skipped, instruction units count: 226
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.<init>(java.lang.Number):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:66:0x00e2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_ON(java.lang.Number r6, java.lang.Number r7) {
        /*
            Method dump skipped, instruction units count: 444
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.<init>(java.lang.Number, java.lang.Number):void");
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_v(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_h;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_l(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_b;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_p(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r11 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r11
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L3a
            if (r1 == 0) goto L38
            if (r0 != 0) goto L36
            goto L30
        L2c:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L32
            throw r0     // Catch: java.lang.IllegalArgumentException -> L32
        L30:
            r0 = 0
            return r0
        L32:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L32
            throw r0
        L36:
            r0 = r11
        L38:
            r1 = r12
        L3a:
            if (r1 == 0) goto L67
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d java.lang.IllegalArgumentException -> L5f
            r1 = r7
            java.lang.Number r1 = r1.Vulcan_h     // Catch: java.lang.IllegalArgumentException -> L4d java.lang.IllegalArgumentException -> L5f
            java.lang.Class r1 = r1.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d java.lang.IllegalArgumentException -> L5f
            if (r0 == r1) goto L63
            goto L51
        L4d:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L51:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L5f
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_ON.d     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 6
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L5f
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L5f:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r7
            java.lang.Number r0 = r0.Vulcan_h
        L67:
            java.lang.Comparable r0 = (java.lang.Comparable) r0
            r1 = r11
            int r0 = r0.compareTo(r1)
            r13 = r0
            r0 = r7
            java.lang.Number r0 = r0.Vulcan_b
            java.lang.Comparable r0 = (java.lang.Comparable) r0
            r1 = r11
            int r0 = r0.compareTo(r1)
            r14 = r0
            r0 = r13
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L9e
            if (r1 == 0) goto L9c
            if (r0 > 0) goto Laf
            goto L9a
        L96:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L9a:
            r0 = r14
        L9c:
            r1 = r12
        L9e:
            if (r1 == 0) goto Lac
            if (r0 < 0) goto Laf
            goto Lab
        La7:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        Lab:
            r0 = 1
        Lac:
            goto Lb0
        Laf:
            r0 = 0
        Lb0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.Vulcan_p(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_ON.a
            r1 = 67841833580721(0x3db3a86438b1, double:3.35183193231133E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 == 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 == 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_ON     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_ON r0 = (ac.vulcan.anticheat.Vulcan_ON) r0
            r10 = r0
            r0 = r5
            java.lang.Number r0 = r0.Vulcan_h     // Catch: java.lang.IllegalArgumentException -> L5a
            r1 = r10
            java.lang.Number r1 = r1.Vulcan_h     // Catch: java.lang.IllegalArgumentException -> L5a
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L5a
            r1 = r9
            if (r1 == 0) goto L71
            if (r0 == 0) goto L84
            goto L5e
        L5a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6d
        L5e:
            r0 = r5
            java.lang.Number r0 = r0.Vulcan_b     // Catch: java.lang.IllegalArgumentException -> L6d
            r1 = r10
            java.lang.Number r1 = r1.Vulcan_b     // Catch: java.lang.IllegalArgumentException -> L6d
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L6d
            goto L71
        L6d:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L71:
            r1 = r9
            if (r1 == 0) goto L81
            if (r0 == 0) goto L84
            goto L80
        L7c:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L80:
            r0 = 1
        L81:
            goto L85
        L84:
            r0 = 0
        L85:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int hashCode() {
        long j = a ^ 105255712707889L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_n;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_n = 17;
                    this.Vulcan_n = (37 * this.Vulcan_n) + getClass().hashCode();
                    this.Vulcan_n = (37 * this.Vulcan_n) + this.Vulcan_h.hashCode();
                    this.Vulcan_n = (37 * this.Vulcan_n) + this.Vulcan_b.hashCode();
                }
                return this.Vulcan_n;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0036: PHI (r0v10 ?? I:ac.vulcan.anticheat.Vulcan_P) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 274
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_ON.toString():java.lang.String");
    }
}
