package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OA.class */
public abstract class Vulcan_OA {
    private static int Vulcan_y;
    private static final long b = me.frep.vulcan.spigot.Vulcan_n.a(7610705572005462541L, 2855649972330782273L, null).a(39843138500680L);
    private static final String c;

    public abstract Number Vulcan_v(Object[] objArr);

    public abstract Number Vulcan_l(Object[] objArr);

    public abstract boolean Vulcan_p(Object[] objArr);

    /*  JADX ERROR: Failed to decode insn: 0x00A3: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -2 out of bounds for object array[13]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public boolean Vulcan_A(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 261
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_A(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x006c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public boolean Vulcan_O(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 232
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: Failed to decode insn: 0x00F8: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[10]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:313)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public boolean Vulcan_I(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 305
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_I(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0082: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.toString():java.lang.String");
    }

    public static void Vulcan_A(int i) {
        Vulcan_y = i;
    }

    public static int Vulcan_u() {
        return Vulcan_y;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_Q() {
        return Vulcan_u() == 0 ? 118 : 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0042, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0049, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L12;
            case 1: goto L13;
            case 2: goto L14;
            case 3: goto L15;
            case 4: goto L16;
            case 5: goto L17;
            default: goto L18;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0070, code lost:
    
        r8 = 122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0075, code lost:
    
        r8 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007a, code lost:
    
        r8 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x007f, code lost:
    
        r8 = 17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r8 = 98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0089, code lost:
    
        r8 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008e, code lost:
    
        r8 = 10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0090, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009b, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00a0, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00a4, code lost:
    
        if (r3 > r11) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00a8, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x002e, code lost:
    
        r1 = "_.z\u0001p\u0001".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 119;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003c, code lost:
    
        if (r1 > 1) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x003f, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:23:0x00a4 -> B:9:0x003f). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 7610705572005462541(0x699ea864fd78c20d, double:5.8667554924931E200)
            r1 = 2855649972330782273(0x27a14e851ba15e41, double:8.578797874003585E-118)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 39843138500680(0x243cb41df848, double:1.96851259556807E-310)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_OA.b = r0
            int r0 = Vulcan_Q()
            if (r0 == 0) goto L20
            r0 = 114(0x72, float:1.6E-43)
            Vulcan_A(r0)
        L20:
            r0 = 119(0x77, float:1.67E-43)
            java.lang.String r1 = "_.z\u0001p\u0001"
            r2 = jsr -> L2e
        L28:
            ac.vulcan.anticheat.Vulcan_OA.c = r2
            goto Lb7
        L2e:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto La0
        L3f:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L42:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L70;
                case 1: goto L75;
                case 2: goto L7a;
                case 3: goto L7f;
                case 4: goto L84;
                case 5: goto L89;
                default: goto L8e;
            }
        L70:
            r8 = 122(0x7a, float:1.71E-43)
            goto L90
        L75:
            r8 = 56
            goto L90
        L7a:
            r8 = 99
            goto L90
        L7f:
            r8 = 17
            goto L90
        L84:
            r8 = 98
            goto L90
        L89:
            r8 = 45
            goto L90
        L8e:
            r8 = 10
        L90:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto La0
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L42
        La0:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L3f
        La8:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lb7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.m84clinit():void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public long Vulcan_j(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 91350897603959(0x531549cd3577, double:4.51333402228776E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_v(r1)
            long r0 = r0.longValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_j(java.lang.Object[]):long");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public int Vulcan_g(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 133474906028228(0x79650c5c38c4, double:6.5945365650436E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_v(r1)
            int r0 = r0.intValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_g(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public double Vulcan_Q(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 93787875120345(0x554cb0fb14d9, double:4.63373670934114E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_v(r1)
            double r0 = r0.doubleValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q(java.lang.Object[]):double");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public float Vulcan_W(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 79862438987684(0x48a26c4e87a4, double:3.9457287496907E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_v(r1)
            float r0 = r0.floatValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_W(java.lang.Object[]):float");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public long Vulcan_E(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 81497148124740(0x4a1f08906e44, double:4.02649411224694E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_l(r1)
            long r0 = r0.longValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_E(java.lang.Object[]):long");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public int Vulcan_f(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 1186278832885(0x11433ba7af5, double:5.86099617717E-312)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_l(r1)
            int r0 = r0.intValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_f(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public double Vulcan_X(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 15355794177327(0xdf74ca83d2f, double:7.5867703676263E-311)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_l(r1)
            double r0 = r0.doubleValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_X(java.lang.Object[]):double");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public float Vulcan_U(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 91232126491750(0x52f9a27ddc66, double:4.5074659496617E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Number r0 = r0.Vulcan_l(r1)
            float r0 = r0.floatValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_U(java.lang.Object[]):float");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_Z(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OA.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 33444952147817(0x1e6b027e0769, double:1.6524001883041E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            if (r0 != 0) goto L2e
            r0 = 0
            return r0
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2a
            throw r0
        L2e:
            r0 = r11
            r1 = r15
            long r1 = r1.longValue()
            r2 = r16
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_R(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_Z(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v6, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0053]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0053]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_R(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r0 = r15
            r1 = r0; r2 = r0; 
            r2 = 26930629923394(0x187e46a15242, double:1.33054990660133E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 10149309071654(0x93b11f64126, double:5.014424941329E-311)
            long r1 = r1 ^ r2
            r19 = r1
            int r0 = Vulcan_u()
            r21 = r0
            r0 = r13
            r1 = r11
            r2 = r17
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L53
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L53
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L53
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L53
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L53
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L53
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L53
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L53
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L53
            long r1 = r1.Vulcan_j(r2)     // Catch: java.lang.RuntimeException -> L53
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r21
            if (r1 == 0) goto L79
            if (r0 < 0) goto L8c
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L75
            throw r0     // Catch: java.lang.RuntimeException -> L75
        L57:
            r0 = r13
            r1 = r11
            r2 = r19
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L75
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L75
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L75
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L75
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L75
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L75
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L75
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L75
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L75
            long r1 = r1.Vulcan_E(r2)     // Catch: java.lang.RuntimeException -> L75
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L79
        L75:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L79:
            r1 = r21
            if (r1 == 0) goto L89
            if (r0 > 0) goto L8c
            goto L88
        L84:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L88:
            r0 = 1
        L89:
            goto L8d
        L8c:
            r0 = 0
        L8d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_R(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_r(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OA.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 132205193400836(0x783d6b971204, double:6.5318044261151E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            if (r0 != 0) goto L2c
            r0 = 0
            return r0
        L28:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L28
            throw r0
        L2c:
            r0 = r10
            r1 = r12
            int r1 = r1.intValue()
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.mo85Vulcan_W(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_r(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v6, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0041: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0050]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0041: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0050]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public boolean mo85Vulcan_W(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r0 = r13
            r1 = r0; r2 = r0; 
            r2 = 32662507155302(0x1db4d522ef66, double:1.61374226924786E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 120443714331904(0x6d8afccee500, double:5.95071015089108E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int r0 = Vulcan_u()
            r19 = r0
            r0 = r12
            r1 = r10
            r2 = r15
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L50
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L50
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L50
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L50
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L50
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L50
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L50
            int r1 = r1.Vulcan_g(r2)     // Catch: java.lang.RuntimeException -> L50
            r2 = r19
            if (r2 == 0) goto L81
            if (r0 < r1) goto L88
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5d
            throw r0     // Catch: java.lang.RuntimeException -> L5d
        L54:
            r0 = r12
            r1 = r19
            if (r1 == 0) goto L85
            goto L61
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7d
            throw r0     // Catch: java.lang.RuntimeException -> L7d
        L61:
            r1 = r10
            r2 = r17
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L7d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L7d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L7d
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L7d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L7d
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L7d
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L7d
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L7d
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L7d
            int r1 = r1.Vulcan_f(r2)     // Catch: java.lang.RuntimeException -> L7d
            goto L81
        L7d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L81:
            if (r0 > r1) goto L88
            r0 = 1
        L85:
            goto L89
        L88:
            r0 = 0
        L89:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.mo85Vulcan_W(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Double] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_h(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OA.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 131103871976946(0x773cffb7c5f2, double:6.4773919180578E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            if (r0 != 0) goto L2c
            r0 = 0
            return r0
        L28:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L28
            throw r0
        L2c:
            r0 = r11
            r1 = r13
            double r1 = r1.doubleValue()
            r2 = r16
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_A(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_h(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_s(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OA.b
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 52535286031856(0x2fc7d30fe5f0, double:2.59558800227836E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 != 0) goto L2e
            r0 = 0
            return r0
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2a
            throw r0
        L2e:
            r0 = r10
            r1 = r14
            float r1 = r1.floatValue()
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_x(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_s(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r4v26, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v6, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v20, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v30, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_x(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.Vulcan_x(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r11) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v6, types: [ac.vulcan.anticheat.Vulcan_OA, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public int hashCode() {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OA.b
            r1 = 24624383135179(0x16654f9c0dcb, double:1.21660617571245E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 64179413652649(0x3a5eef2714a9, double:3.17088434560085E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 55052776332542(0x3211f92d5cfe, double:2.7199685494091E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = 17
            r17 = r0
            r0 = 37
            r1 = r17
            int r0 = r0 * r1
            r1 = r10
            java.lang.Class r1 = r1.getClass()
            int r1 = r1.hashCode()
            int r0 = r0 + r1
            r17 = r0
            r0 = 37
            r1 = r17
            int r0 = r0 * r1
            r1 = r10
            r2 = r15
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.Number r1 = r1.Vulcan_v(r2)
            int r1 = r1.hashCode()
            int r0 = r0 + r1
            r17 = r0
            r0 = 37
            r1 = r17
            int r0 = r0 * r1
            r1 = r10
            r2 = r13
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.Number r1 = r1.Vulcan_l(r2)
            int r1 = r1.hashCode()
            int r0 = r0 + r1
            r17 = r0
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OA.hashCode():int");
    }
}
