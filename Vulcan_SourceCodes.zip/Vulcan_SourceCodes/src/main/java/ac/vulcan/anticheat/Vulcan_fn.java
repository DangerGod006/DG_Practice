package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fn.class */
interface Vulcan_fn {
    void Vulcan_A(Object[] objArr);

    String Vulcan_K(Object[] objArr);

    int Vulcan_n(Object[] objArr);
}
