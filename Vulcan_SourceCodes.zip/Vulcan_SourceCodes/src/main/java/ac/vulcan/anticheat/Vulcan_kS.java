package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kS.class */
class Vulcan_kS extends Vulcan_kU {
    private final Vulcan_P Vulcan_X;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_kS(Vulcan_P vulcan_P) {
        this.Vulcan_X = vulcan_P;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_kS, ac.vulcan.anticheat.Vulcan_kU] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v17, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v11, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v11 ??, still in use, count: 2, list:
          (r7v11 ?? I:??[OBJECT, ARRAY][]) from 0x00a1: APUT (r7v11 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v11 ?? I:??[OBJECT, ARRAY])
          (r7v11 ?? I:??[OBJECT, ARRAY]) from 0x00a1: APUT (r7v11 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v11 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_kU
    protected java.util.List Vulcan_N(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r0 = r15
            r1 = r0; r2 = r0; 
            r2 = 0
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r17
            if (r0 != 0) goto L87
            r0 = r12
            r1 = r12
            ac.vulcan.anticheat.Vulcan_P r1 = r1.Vulcan_X     // Catch: java.lang.RuntimeException -> L83
            char[] r1 = r1.Vulcan_b     // Catch: java.lang.RuntimeException -> L83
            r2 = 0
            r3 = r12
            ac.vulcan.anticheat.Vulcan_P r3 = r3.Vulcan_X     // Catch: java.lang.RuntimeException -> L83
            r4 = 0
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.RuntimeException -> L83
            int r3 = r3.Vulcan_M(r4)     // Catch: java.lang.RuntimeException -> L83
            r4 = r19
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch: java.lang.RuntimeException -> L83
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L83
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L83
            java.lang.Long r7 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L83
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.lang.RuntimeException -> L83
            r9 = r8; r8 = r7; r7 = r6; r6 = r9;      // Catch: java.lang.RuntimeException -> L83
            r7.<init>(r8)     // Catch: java.lang.RuntimeException -> L83
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.RuntimeException -> L83
            r5[r6] = r7     // Catch: java.lang.RuntimeException -> L83
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.RuntimeException -> L83
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L83
            java.lang.Integer r6 = new java.lang.Integer     // Catch: java.lang.RuntimeException -> L83
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.RuntimeException -> L83
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.RuntimeException -> L83
            r6.<init>(r7)     // Catch: java.lang.RuntimeException -> L83
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.RuntimeException -> L83
            r4[r5] = r6     // Catch: java.lang.RuntimeException -> L83
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.RuntimeException -> L83
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L83
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.RuntimeException -> L83
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.RuntimeException -> L83
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.RuntimeException -> L83
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L83
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L83
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L83
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L83
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L83
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L83
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L83
            java.util.List r0 = super.Vulcan_N(r1)     // Catch: java.lang.RuntimeException -> L83
            return r0
        L83:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L83
            throw r0
        L87:
            r0 = r12
            r1 = r17
            r2 = r18
            r3 = r14
            r4 = r19
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.util.List r0 = super.Vulcan_N(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kS.Vulcan_N(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_kU, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x002d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x002d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_kU
    public java.lang.String Vulcan_X(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 0
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_m()
            r1 = r10
            r2 = r14
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.String r1 = super.Vulcan_X(r2)
            r17 = r1
            r16 = r0
            r0 = r17
            r1 = r16
            if (r1 != 0) goto L54
            if (r0 != 0) goto L52
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4e
            throw r0     // Catch: java.lang.RuntimeException -> L4e
        L46:
            r0 = r10
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_X     // Catch: java.lang.RuntimeException -> L4e
            java.lang.String r0 = r0.toString()     // Catch: java.lang.RuntimeException -> L4e
            return r0
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4e
            throw r0
        L52:
            r0 = r17
        L54:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kS.Vulcan_X(java.lang.Object[]):java.lang.String");
    }
}
