package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_ku, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_ku.class */
public class C0027Vulcan_ku {
    public static final String Vulcan_W = "";
    public static final int Vulcan_E = -1;
    private static final int Vulcan_q = 8192;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(5225312529016519333L, -8787368624872809789L, null).a(154445719603326L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_c(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 81697998518596(0x4a4dcc2e3944, double:4.03641744020273E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r12
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L50
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L50
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L50
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L50
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L50
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L50
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L50
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L50
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L50
            r1 = r14
            if (r1 != 0) goto L55
            if (r0 != 0) goto L58
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_c(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0035: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_lC(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 77376619047345(0x465fa5e469b1, double:3.82291292626386E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r1 = r0; r2 = r0; 
            r2 = 4305506278291(0x3ea742c1b93, double:2.1272027400574E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r14
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Z(r0)
            r16 = r0
            r0 = r12
            r1 = r16
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L6f
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L6f
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L6f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L6f
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L6f
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L6f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L6f
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L6f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L6f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L6f
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L6f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L6f
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L6f
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L6f
            if (r0 == 0) goto L73
            r0 = 0
            goto L75
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6f
            throw r0
        L73:
            r0 = r16
        L75:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lC(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0050: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public static java.lang.String m471Vulcan_S(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 107779110201690(0x62064793e95a, double:5.3249955689993E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 107679235333945(0x61ef06925f39, double:5.3200610948957E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 103586199736687(0x5e360aa3916f, double:5.11783826731466E-310)
            long r1 = r1 ^ r2
            r19 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r21 = r0
            r0 = r13
            r1 = r21
            if (r1 != 0) goto Lc3
            r1 = r15
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lc0
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L6e java.lang.IllegalStateException -> L74
            if (r0 == 0) goto L78
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L74
            throw r0     // Catch: java.lang.IllegalStateException -> L74
        L72:
            r0 = r13
            return r0
        L74:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L74
            throw r0
        L78:
            r0 = r13
            r1 = r14
            r2 = r17
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_N(r0)
            r13 = r0
            r0 = r13
            r1 = r14
            r2 = r19
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
        Lc0:
            java.lang.String r0 = Vulcan_AD(r0)
        Lc3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m471Vulcan_S(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_t(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 27276049451231(0x18ceb33d08df, double:1.347615898812E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r13
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5a
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5a
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5a
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5a
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5a
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5a
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5a
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5a
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5a
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5a
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5a
            r1 = r15
            if (r1 != 0) goto L69
            if (r0 == 0) goto L64
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L60
            throw r0     // Catch: java.lang.IllegalStateException -> L60
        L5e:
            r0 = -1
            return r0
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L60
            throw r0
        L64:
            r0 = r10
            r1 = r9
            int r0 = r0.indexOf(r1)
        L69:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_t(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_m(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 97213948259692(0x586a62da6d6c, double:4.80300721317023E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r14
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L65
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L65
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L65
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L65
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L65
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L65
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L65
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L65
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L65
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L65
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L65
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L65
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L65
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L65
            r1 = r16
            if (r1 != 0) goto L76
            if (r0 == 0) goto L6f
            goto L69
        L65:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6b
            throw r0     // Catch: java.lang.IllegalStateException -> L6b
        L69:
            r0 = -1
            return r0
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6b
            throw r0
        L6f:
            r0 = r10
            r1 = r13
            r2 = r9
            int r0 = r0.indexOf(r1, r2)
        L76:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_m(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_K(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 15147691345726(0xdc6d8c3073e, double:7.48395390773E-311)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r13
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5a
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5a
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5a
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5a
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5a
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5a
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5a
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5a
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5a
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5a
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5a
            r1 = r15
            if (r1 != 0) goto L69
            if (r0 == 0) goto L64
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L60
            throw r0     // Catch: java.lang.IllegalStateException -> L60
        L5e:
            r0 = -1
            return r0
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L60
            throw r0
        L64:
            r0 = r10
            r1 = r9
            int r0 = r0.lastIndexOf(r1)
        L69:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_K(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static int m476Vulcan_N(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 121192185469769(0x6e39412a1b49, double:5.98768953850336E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r14
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L67
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L67
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L67
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L67
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L67
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L67
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L67
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L67
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L67
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L67
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L67
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L67
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L67
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L67
            r1 = r16
            if (r1 != 0) goto L79
            if (r0 == 0) goto L71
            goto L6b
        L67:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6d
            throw r0     // Catch: java.lang.IllegalStateException -> L6d
        L6b:
            r0 = -1
            return r0
        L6d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6d
            throw r0
        L71:
            r0 = r12
            r1 = r13
            r2 = r9
            int r0 = r0.lastIndexOf(r1, r2)
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m476Vulcan_N(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_l(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 73581544056486(0x42ec09cba6a6, double:3.6354113086264E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r13
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5c
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5c
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5c
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5c
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5c
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5c
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5c
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5c
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5c
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5c
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5c
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5c
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5c
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5c
            r1 = r15
            if (r1 != 0) goto L6c
            if (r0 == 0) goto L66
            goto L60
        L5c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L62
            throw r0     // Catch: java.lang.IllegalStateException -> L62
        L60:
            r0 = 0
            return r0
        L62:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L62
            throw r0
        L66:
            r0 = r12
            r1 = r9
            int r0 = r0.indexOf(r1)
        L6c:
            r1 = r15
            if (r1 != 0) goto L7c
            if (r0 < 0) goto L7f
            goto L7b
        L77:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7b:
            r0 = 1
        L7c:
            goto L80
        L7f:
            r0 = 0
        L80:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_l(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_J(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 443
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_J(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0041: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_f(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 46568857908013(0x2a5aa83bb32d, double:2.30080728584117E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 77936326991563(0x46e1f715decb, double:3.8505661729581E-310)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r18 = r0
            r0 = r14
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5e
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5e
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5e
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5e
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5e
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5e
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5e
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5e
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5e
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5e
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5e
            r1 = r18
            if (r1 != 0) goto L97
            if (r0 != 0) goto L96
            goto L62
        L5e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L88
            throw r0     // Catch: java.lang.IllegalStateException -> L88
        L62:
            r0 = r14
            r1 = r11
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            r1 = r18
            if (r1 != 0) goto Lc1
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L92
            throw r0     // Catch: java.lang.IllegalStateException -> L92
        L8c:
            if (r0 == 0) goto L98
            goto L96
        L92:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L96:
            r0 = -1
        L97:
            return r0
        L98:
            r0 = r10
            r1 = r11
            char[] r1 = r1.toCharArray()
            r2 = r16
            r3 = r2; r2 = r1; r1 = r3; 
            r2 = 3
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 2
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r1; 
            r2 = r0; r0 = r1; r1 = r2; 
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            Vulcan_J(r-1)
        Lc1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_f(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static boolean m478Vulcan_q(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 445
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m478Vulcan_q(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0049: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan__(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 465
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan__(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_E(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 433
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_E(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a3: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_x(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 210
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_x(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0071: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public static boolean m480Vulcan_f(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 136271110133702(0x7bf0171cd7c6, double:6.7326874037711E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L3f
            if (r0 == 0) goto L54
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3e:
            r0 = r10
        L3f:
            r1 = r15
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L5c
            if (r1 != 0) goto L5b
            if (r0 != 0) goto L5a
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L56
            throw r0     // Catch: java.lang.IllegalStateException -> L56
        L54:
            r0 = 0
            return r0
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L56
            throw r0
        L5a:
            r0 = r9
        L5b:
            r1 = r10
        L5c:
            char[] r1 = r1.toCharArray()
            r2 = r13
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_x(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m480Vulcan_f(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_M(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 88895940214546(0x50d9b2f03f12, double:4.39204301147645E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L7e
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L6e
            if (r0 != 0) goto L7c
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6e
            throw r0     // Catch: java.lang.IllegalStateException -> L6e
        L5f:
            r0 = r11
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L80
            r1 = r15
            if (r1 != 0) goto L80
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L78
            throw r0     // Catch: java.lang.IllegalStateException -> L78
        L72:
            if (r0 != 0) goto L7f
            goto L7c
        L78:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7c:
            r0 = r12
        L7e:
            return r0
        L7f:
            r0 = r11
        L80:
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L8e
            r1 = r15
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L99
            goto L92
        L8e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L95
            throw r0     // Catch: java.lang.IllegalStateException -> L95
        L92:
            java.lang.String r0 = ""
            return r0
        L95:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L95
            throw r0
        L99:
            r0 = r12
            r1 = r11
            int r0 = r0.indexOf(r1)
        L9f:
            r16 = r0
            r0 = r16
            r1 = -1
            if (r0 != r1) goto Lae
            r0 = r12
            return r0
        Laa:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> Laa
            throw r0
        Lae:
            r0 = r12
            r1 = 0
            r2 = r16
            java.lang.String r0 = r0.substring(r1, r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_M(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_I(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 103103219244956(0x5dc596c21f9c, double:5.0939758604571E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L67
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L62
            if (r0 == 0) goto L66
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L62
            throw r0     // Catch: java.lang.IllegalStateException -> L62
        L5f:
            r0 = r12
            return r0
        L62:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L62
            throw r0
        L66:
            r0 = r11
        L67:
            r1 = r15
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L86
            if (r1 != 0) goto L85
            if (r0 != 0) goto L83
            goto L7c
        L78:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7f
            throw r0     // Catch: java.lang.IllegalStateException -> L7f
        L7c:
            java.lang.String r0 = ""
            return r0
        L7f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7f
            throw r0
        L83:
            r0 = r12
        L85:
            r1 = r11
        L86:
            int r0 = r0.indexOf(r1)
            r16 = r0
            r0 = r16
            r1 = -1
            if (r0 != r1) goto L98
            java.lang.String r0 = ""
            return r0
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L94
            throw r0
        L98:
            r0 = r12
            r1 = r16
            r2 = r11
            int r2 = r2.length()
            int r1 = r1 + r2
            java.lang.String r0 = r0.substring(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_I(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static java.lang.String m483Vulcan_e(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 62079086015497(0x3875e9deb409, double:3.0671143725481E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L95
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5b java.lang.IllegalStateException -> L85
            if (r0 != 0) goto L93
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L85
            throw r0     // Catch: java.lang.IllegalStateException -> L85
        L5f:
            r0 = r13
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L85 java.lang.IllegalStateException -> L8f
            r1 = r15
            if (r1 != 0) goto L9c
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L8f
            throw r0     // Catch: java.lang.IllegalStateException -> L8f
        L89:
            if (r0 == 0) goto L96
            goto L93
        L8f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L93:
            r0 = r12
        L95:
            return r0
        L96:
            r0 = r12
            r1 = r9
            int r0 = r0.lastIndexOf(r1)
        L9c:
            r16 = r0
            r0 = r16
            r1 = -1
            if (r0 != r1) goto Lab
            r0 = r12
            return r0
        La7:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La7
            throw r0
        Lab:
            r0 = r12
            r1 = 0
            r2 = r16
            java.lang.String r0 = r0.substring(r1, r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m483Vulcan_e(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static java.lang.String m484Vulcan_G(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 226
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m484Vulcan_G(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x006f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static java.lang.String[] m486Vulcan_m(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 488
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m486Vulcan_m(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String[] Vulcan_C(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 24063051843280(0x15e29da846d0, double:1.18887272498615E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r12
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m498Vulcan_n(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_C(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String[] Vulcan_i(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 3206279508574(0x2ea8526b25e, double:1.584112556151E-311)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r10
            r2 = 1
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m498Vulcan_n(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_i(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0090: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public static java.lang.String m499Vulcan_d(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 45679251290887(0x298b878bfb07, double:2.25685487905767E-310)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r22 = r0
            r0 = r12
            r1 = r22
            if (r1 != 0) goto L49
            if (r0 != 0) goto L48
            goto L42
        L3e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L44
            throw r0     // Catch: java.lang.IllegalStateException -> L44
        L42:
            r0 = 0
            return r0
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L44
            throw r0
        L48:
            r0 = r12
        L49:
            r1 = r15
            r2 = 0
            r3 = r12
            int r3 = r3.length
            r18 = r3
            r19 = r2
            r20 = r1
            r21 = r0
            r0 = r16
            r1 = r21
            r2 = r20
            r3 = r19
            r4 = r18
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Zw(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m499Vulcan_d(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_Uh(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 57144530505912(0x33f8ff7110b8, double:2.8233149370698E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L45
            if (r0 != 0) goto L44
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L40
            throw r0     // Catch: java.lang.IllegalStateException -> L40
        L3e:
            r0 = 0
            return r0
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L40
            throw r0
        L44:
            r0 = r9
        L45:
            java.util.Iterator r0 = r0.iterator()
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_vB(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Uh(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0054: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_r(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 27353491134089(0x18e0bb1f5689, double:1.35144202631765E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 != 0) goto L66
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0     // Catch: java.lang.IllegalStateException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0
        L3d:
            r0 = r12
            r1 = r11
            java.lang.String[] r2 = ac.vulcan.anticheat.C0027Vulcan_ku.b
            r3 = 10
            r2 = r2[r3]
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fJ.Vulcan_t(r0)
        L66:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_r(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public static java.lang.String m502Vulcan_Y(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 206
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m502Vulcan_Y(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0042: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static java.lang.String m503Vulcan__(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 3498217809221(0x32e7e07a545, double:1.728349241206E-311)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L9a
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L5a java.lang.IllegalStateException -> L8b
            if (r0 != 0) goto L99
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L8b
            throw r0     // Catch: java.lang.IllegalStateException -> L8b
        L5e:
            r0 = r13
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L8b java.lang.IllegalStateException -> L95
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb3
            r1 = r15
            if (r1 != 0) goto Lb3
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L95
            throw r0     // Catch: java.lang.IllegalStateException -> L95
        L8f:
            if (r0 == 0) goto L9b
            goto L99
        L95:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L99:
            r0 = r9
        L9a:
            return r0
        L9b:
            r0 = r9
            r1 = r15
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto La9
            if (r1 != 0) goto Lc5
            r1 = r12
        La9:
            boolean r0 = r0.startsWith(r1)     // Catch: java.lang.IllegalStateException -> Laf
            goto Lb3
        Laf:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb3:
            if (r0 == 0) goto Lc4
            r0 = r9
            r1 = r12
            int r1 = r1.length()     // Catch: java.lang.IllegalStateException -> Lc0
            java.lang.String r0 = r0.substring(r1)     // Catch: java.lang.IllegalStateException -> Lc0
            return r0
        Lc0:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> Lc0
            throw r0
        Lc4:
            r0 = r9
        Lc5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m503Vulcan__(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_A6(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 240
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_A6(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public static java.lang.String m504Vulcan_p(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m504Vulcan_p(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0064: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_AA(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 294
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_AA(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static java.lang.String m505Vulcan_A(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 227
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m505Vulcan_A(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0045: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_ah(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_ah(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_X(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 612
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_X(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x03d8: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.String Vulcan_U(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1598
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_U(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0051: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static java.lang.String m508Vulcan_u(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 458
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m508Vulcan_u(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x006d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static java.lang.String m509Vulcan_s(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 108179298843242(0x626374adfa6a, double:5.34476751496396E-310)
            long r1 = r1 ^ r2
            r16 = r1
            ac.vulcan.anticheat.Vulcan_P r0 = new ac.vulcan.anticheat.Vulcan_P
            r1 = r0
            r2 = r13
            r3 = r10
            int r3 = r3.length()
            int r2 = r2 + r3
            r3 = r12
            int r3 = r3.length()
            int r2 = r2 + r3
            r3 = r11
            int r2 = r2 - r3
            r3 = 1
            int r2 = r2 + r3
            r1.<init>(r2)
            r1 = r12
            r2 = 0
            r3 = r13
            java.lang.String r1 = r1.substring(r2, r3)
            r2 = r16
            r3 = r2; r2 = r1; r1 = r3; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r-1.Vulcan_i(r0)
            r0 = r16
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r-1.Vulcan_i(r0)
            r0 = r12
            r1 = r11
            java.lang.String r0 = r0.substring(r1)
            r1 = r16
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r-1.Vulcan_i(r0)
            r-1.toString()
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m509Vulcan_s(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0128: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public static java.lang.String m510Vulcan_i(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 386
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m510Vulcan_i(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static java.lang.String m511Vulcan_c(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 290
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m511Vulcan_c(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0041: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_T(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 48840423509667(0x2c6b8c180ea3, double:2.41303753844636E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L7b
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L6c
            if (r0 != 0) goto L7a
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6c
            throw r0     // Catch: java.lang.IllegalStateException -> L6c
        L5d:
            r0 = r10
            r1 = r15
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L7f
            if (r1 != 0) goto L7d
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L76
            throw r0     // Catch: java.lang.IllegalStateException -> L76
        L70:
            if (r0 != 0) goto L7c
            goto L7a
        L76:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7a:
            r0 = r9
        L7b:
            return r0
        L7c:
            r0 = r9
        L7d:
            r1 = r15
        L7f:
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L89
            if (r1 != 0) goto Laa
            r1 = r10
        L89:
            boolean r0 = r0.endsWith(r1)     // Catch: java.lang.IllegalStateException -> L92 java.lang.IllegalStateException -> La5
            if (r0 == 0) goto La9
            goto L96
        L92:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La5
            throw r0     // Catch: java.lang.IllegalStateException -> La5
        L96:
            r0 = r9
            r1 = 0
            r2 = r9
            int r2 = r2.length()     // Catch: java.lang.IllegalStateException -> La5
            r3 = r10
            int r3 = r3.length()     // Catch: java.lang.IllegalStateException -> La5
            int r2 = r2 - r3
            java.lang.String r0 = r0.substring(r1, r2)     // Catch: java.lang.IllegalStateException -> La5
            return r0
        La5:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La5
            throw r0
        La9:
            r0 = r9
        Laa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_T(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0088: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_KC(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 267
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_KC(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0066: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_nr(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 447
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_nr(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0064: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public static java.lang.String m515Vulcan_n(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 439
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m515Vulcan_n(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0083: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_W(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 321
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_W(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_lz(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 110338337035365(0x645a25625465, double:5.45143817484267E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m519Vulcan_w(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lz(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static java.lang.String m521Vulcan_Q(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 84002569784966(0x4c665f550e86, double:4.15027838931336E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r11
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m520Vulcan_y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m521Vulcan_Q(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static int m522Vulcan_o(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m522Vulcan_o(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0068: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_h(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 48202731252994(0x2bd712ac6d02, double:2.38153135478225E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0     // Catch: java.lang.IllegalStateException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0
        L3d:
            r0 = r11
        L3e:
            int r0 = r0.length()
            r15 = r0
            r0 = 0
            r16 = r0
        L46:
            r0 = r16
            r1 = r15
            if (r0 >= r1) goto La5
        L4d:
            r0 = r11
            r1 = r16
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L8d
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L8d
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L8d
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalStateException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalStateException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalStateException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalStateException -> L8d
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L8d
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L8d
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L8d
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L8d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L8d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L8d
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L8d
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L8d
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L8d
            boolean r0 = ac.vulcan.anticheat.Vulcan_kI.Vulcan_X(r0)     // Catch: java.lang.IllegalStateException -> L8d
            r1 = r14
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L87
            if (r1 != 0) goto Lac
            r1 = r14
        L87:
            if (r1 != 0) goto L9c
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L97
            throw r0     // Catch: java.lang.IllegalStateException -> L97
        L91:
            if (r0 != 0) goto L9d
            goto L9b
        L97:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9b:
            r0 = 0
        L9c:
            return r0
        L9d:
            int r16 = r16 + 1
            r0 = r14
            if (r0 == 0) goto L46
        La5:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L4d
            r0 = 1
        Lac:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_h(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0045: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static boolean m530Vulcan_X(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 90206347328557(0x520acd49fc2d, double:4.45678572518633E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 != 0) goto L38
            if (r0 == 0) goto L66
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r11
        L38:
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L62
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L62
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L62
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L62
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L62
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L62
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L62
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L62
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L62
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L62
            r1 = r14
            if (r1 != 0) goto L70
            if (r0 == 0) goto L6c
            goto L66
        L62:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L68
            throw r0     // Catch: java.lang.IllegalStateException -> L68
        L66:
            r0 = 0
            return r0
        L68:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L68
            throw r0
        L6c:
            r0 = r11
            int r0 = r0.length()
        L70:
            r15 = r0
            r0 = 0
            r16 = r0
        L75:
            r0 = r16
            r1 = r15
            if (r0 >= r1) goto Lb0
        L7c:
            r0 = r11
            r1 = r16
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L98
            boolean r0 = java.lang.Character.isLowerCase(r0)     // Catch: java.lang.IllegalStateException -> L98
            r1 = r14
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L92
            if (r1 != 0) goto Lb7
            r1 = r14
        L92:
            if (r1 != 0) goto La7
            goto L9c
        L98:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La2
            throw r0     // Catch: java.lang.IllegalStateException -> La2
        L9c:
            if (r0 != 0) goto La8
            goto La6
        La2:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La6:
            r0 = 0
        La7:
            return r0
        La8:
            int r16 = r16 + 1
            r0 = r14
            if (r0 == 0) goto L75
        Lb0:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = 1
        Lb7:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m530Vulcan_X(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0045: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public static boolean m531Vulcan_j(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 73918554009760(0x433a812770a0, double:3.6520618126483E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 != 0) goto L38
            if (r0 == 0) goto L66
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r11
        L38:
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L62
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L62
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L62
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L62
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L62
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L62
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L62
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L62
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L62
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L62
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L62
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L62
            r1 = r14
            if (r1 != 0) goto L70
            if (r0 == 0) goto L6c
            goto L66
        L62:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L68
            throw r0     // Catch: java.lang.IllegalStateException -> L68
        L66:
            r0 = 0
            return r0
        L68:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L68
            throw r0
        L6c:
            r0 = r11
            int r0 = r0.length()
        L70:
            r15 = r0
            r0 = 0
            r16 = r0
        L75:
            r0 = r16
            r1 = r15
            if (r0 >= r1) goto Lb0
        L7c:
            r0 = r11
            r1 = r16
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L98
            boolean r0 = java.lang.Character.isUpperCase(r0)     // Catch: java.lang.IllegalStateException -> L98
            r1 = r14
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L92
            if (r1 != 0) goto Lb7
            r1 = r14
        L92:
            if (r1 != 0) goto La7
            goto L9c
        L98:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La2
            throw r0     // Catch: java.lang.IllegalStateException -> La2
        L9c:
            if (r0 != 0) goto La8
            goto La6
        La2:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La6:
            r0 = 0
        La7:
            return r0
        La8:
            int r16 = r16 + 1
            r0 = r14
            if (r0 == 0) goto L75
        Lb0:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = 1
        Lb7:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m531Vulcan_j(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0041: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_Av(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 112435377913852(0x664266c2bffc, double:5.5550457604412E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L65
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r3.<init>(r4)     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            boolean r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalStateException -> L59 java.lang.IllegalStateException -> L61
            if (r0 == 0) goto L68
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L61
            throw r0     // Catch: java.lang.IllegalStateException -> L61
        L5d:
            r0 = r10
            goto L65
        L61:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L65:
            goto L69
        L68:
            r0 = r9
        L69:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Av(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00d1: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public static java.lang.String m536Vulcan_b(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 274
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m536Vulcan_b(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x008e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_P(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 267
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_P(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0053: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static java.lang.String m539Vulcan_K(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 396
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m539Vulcan_K(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0049: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static boolean m546Vulcan_N(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 265
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m546Vulcan_N(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0049: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public static boolean m547Vulcan_k(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 139469316442728(0x7ed8bb104a68, double:6.89069979033136E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r12
            r2 = r11
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m549Vulcan_u(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m547Vulcan_k(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0079: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static boolean m548Vulcan_M(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r0 = r15
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r12
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r13
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 37458903903526(0x221194a92d26, double:1.8507157549601E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r18
            r1 = r14
            r2 = r11
            r3 = 1
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m549Vulcan_u(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m548Vulcan_M(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public static boolean m550Vulcan_P(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 264
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m550Vulcan_P(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0087, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008a, code lost:
    
        r11 = "\u000392e)}\u00011277\u0018pQ<=0rjtS\"=*7&pO7(;djqN>{'7'tU34i7\u0005pU^\u001dB".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0093, code lost:
    
        ac.vulcan.anticheat.C0027Vulcan_ku.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ab, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b2, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ba, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009b, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00ab, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ae, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b2, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00ba, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "\u000392e)}\u00011277\u0018pQ<=0rjtS\"=*7&pO7(;djqN>{'7'tU34i7\u0005pU^\u001dB".length();
        r11 = '.';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0067, code lost:
    
        r10 = r10 + 1;
        "\u000392e)}\u00011277\u0018pQ<=0rjtS\"=*7&pO7(;djqN>{'7'tU34i7\u0005pU^\u001dB".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0077, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ae, B:28:0x0110], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ae). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0115 -> B:34:0x00ae). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m470clinit():void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_Q(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L41
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L3d
            r1 = r9
            if (r1 != 0) goto L42
            if (r0 != 0) goto L45
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r0 = 1
        L42:
            goto L46
        L45:
            r0 = 0
        L46:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Q(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_S(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L44
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r10
        L2f:
            int r0 = r0.length()
            r1 = r0
            r12 = r1
            r1 = r11
            if (r1 != 0) goto L4b
            if (r0 != 0) goto L4a
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0     // Catch: java.lang.IllegalStateException -> L46
        L44:
            r0 = 1
            return r0
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0
        L4a:
            r0 = 0
        L4b:
            r13 = r0
        L4d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto L88
        L54:
            r0 = r10
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L70
            boolean r0 = java.lang.Character.isWhitespace(r0)     // Catch: java.lang.IllegalStateException -> L70
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L6a
            if (r1 != 0) goto L8f
            r1 = r11
        L6a:
            if (r1 != 0) goto L7f
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7a
            throw r0     // Catch: java.lang.IllegalStateException -> L7a
        L74:
            if (r0 != 0) goto L80
            goto L7e
        L7a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7e:
            r0 = 0
        L7f:
            return r0
        L80:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L4d
        L88:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L54
            r0 = 1
        L8f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_S(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalStateException -> 0x0050]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalStateException -> 0x0050]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static boolean Vulcan_e(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 83136144039896(0x4b9ca4555fd8, double:4.1074712697822E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalStateException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalStateException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalStateException -> L50
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> L50
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalStateException -> L50
            r4.<init>(r5)     // Catch: java.lang.IllegalStateException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> L50
            r2[r3] = r4     // Catch: java.lang.IllegalStateException -> L50
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalStateException -> L50
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalStateException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalStateException -> L50
            r1[r2] = r3     // Catch: java.lang.IllegalStateException -> L50
            boolean r0 = Vulcan_S(r0)     // Catch: java.lang.IllegalStateException -> L50
            r1 = r15
            if (r1 != 0) goto L55
            if (r0 != 0) goto L58
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_e(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_R(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L38
            if (r0 != 0) goto L37
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L33
            throw r0     // Catch: java.lang.IllegalStateException -> L33
        L2e:
            java.lang.String r0 = ""
            goto L3b
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L33
            throw r0
        L37:
            r0 = r6
        L38:
            java.lang.String r0 = r0.trim()
        L3b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_R(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_Z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L37
            if (r0 != 0) goto L36
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L32
            throw r0     // Catch: java.lang.IllegalStateException -> L32
        L2e:
            r0 = 0
            goto L3a
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L32
            throw r0
        L36:
            r0 = r8
        L37:
            java.lang.String r0 = r0.trim()
        L3a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Z(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_k(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L38
            if (r0 != 0) goto L37
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L33
            throw r0     // Catch: java.lang.IllegalStateException -> L33
        L2e:
            java.lang.String r0 = ""
            goto L3b
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L33
            throw r0
        L37:
            r0 = r8
        L38:
            java.lang.String r0 = r0.trim()
        L3b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_k(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_lZ(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 101017801572704(0x5be00a2dc160, double:4.9909425375481E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m471Vulcan_S(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lZ(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_l1(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 36596009066573(0x2148ac1ee04d, double:1.80808308546885E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 != 0) goto L63
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0     // Catch: java.lang.IllegalStateException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0
        L3d:
            r0 = r10
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m471Vulcan_S(r0)
            r10 = r0
            r0 = r10
        L63:
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L6d
            if (r0 != 0) goto L71
            r0 = 0
            goto L72
        L6d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6d
            throw r0
        L71:
            r0 = r10
        L72:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_l1(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_lB(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 101298106612514(0x5c214da93b22, double:5.0047914466007E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L41
            if (r0 != 0) goto L40
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3c
            throw r0     // Catch: java.lang.IllegalStateException -> L3c
        L37:
            java.lang.String r0 = ""
            goto L64
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3c
            throw r0
        L40:
            r0 = r12
        L41:
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m471Vulcan_S(r0)
        L64:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lB(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_N(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 294
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_N(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_AD(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_AD(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_B(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 19190023896901(0x1174068ebf45, double:9.4811315503313E-311)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_B(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String[] Vulcan_z(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 28463230453790(0x19e31cbd881e, double:1.406270433688E-310)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r18 = r0
            r0 = r12
            r1 = r18
            if (r1 != 0) goto L53
            if (r0 == 0) goto L52
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3e:
            r0 = r12
            int r0 = r0.length
            r1 = r0
            r19 = r1
            r1 = r18
            if (r1 != 0) goto L56
            if (r0 != 0) goto L54
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L52:
            r0 = r12
        L53:
            return r0
        L54:
            r0 = r19
        L56:
            java.lang.String[] r0 = new java.lang.String[r0]
            r20 = r0
            r0 = 0
            r21 = r0
        L5e:
            r0 = r21
            r1 = r19
            if (r0 >= r1) goto Lb1
        L65:
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L9f
            r0 = r20
            r1 = r18
            if (r1 != 0) goto Lb3
            r1 = r21
            r2 = r12
            r3 = r21
            r2 = r2[r3]     // Catch: java.lang.IllegalStateException -> Lad
            r3 = r16
            r4 = r13
            r5 = 3
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch: java.lang.IllegalStateException -> Lad
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.IllegalStateException -> Lad
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalStateException -> Lad
            r7 = 2
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.IllegalStateException -> Lad
            r5[r6] = r7     // Catch: java.lang.IllegalStateException -> Lad
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalStateException -> Lad
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalStateException -> Lad
            java.lang.Long r6 = new java.lang.Long     // Catch: java.lang.IllegalStateException -> Lad
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalStateException -> Lad
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.lang.IllegalStateException -> Lad
            r6.<init>(r7)     // Catch: java.lang.IllegalStateException -> Lad
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalStateException -> Lad
            r4[r5] = r6     // Catch: java.lang.IllegalStateException -> Lad
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalStateException -> Lad
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalStateException -> Lad
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalStateException -> Lad
            r3[r4] = r5     // Catch: java.lang.IllegalStateException -> Lad
            java.lang.String r2 = m471Vulcan_S(r2)     // Catch: java.lang.IllegalStateException -> Lad
            r0[r1] = r2     // Catch: java.lang.IllegalStateException -> Lad
            int r21 = r21 + 1
        L9f:
            r0 = r18
            if (r0 == 0) goto L5e
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L65
            goto Lb1
        Lad:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb1:
            r0 = r20
        Lb3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_z(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_p(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4e
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3e
            throw r0     // Catch: java.lang.IllegalStateException -> L3e
        L36:
            r0 = r9
            if (r0 != 0) goto L4a
            goto L42
        L3e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0     // Catch: java.lang.IllegalStateException -> L46
        L42:
            r0 = 1
            goto L54
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0
        L4a:
            r0 = 0
            goto L54
        L4e:
            r0 = r8
        L4f:
            r1 = r9
            boolean r0 = r0.equals(r1)
        L54:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_p(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_n(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4e
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3e
            throw r0     // Catch: java.lang.IllegalStateException -> L3e
        L36:
            r0 = r9
            if (r0 != 0) goto L4a
            goto L42
        L3e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0     // Catch: java.lang.IllegalStateException -> L46
        L42:
            r0 = 1
            goto L54
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L46
            throw r0
        L4a:
            r0 = 0
            goto L54
        L4e:
            r0 = r8
        L4f:
            r1 = r9
            boolean r0 = r0.equalsIgnoreCase(r1)
        L54:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_n(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static int m472Vulcan_c(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r10
            r1 = r12
            if (r1 != 0) goto L38
            if (r0 == 0) goto L4d
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L36:
            r0 = r11
        L38:
            r1 = r12
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L56
            if (r1 != 0) goto L54
            if (r0 != 0) goto L53
            goto L4d
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4f
            throw r0     // Catch: java.lang.IllegalStateException -> L4f
        L4d:
            r0 = -1
            return r0
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4f
            throw r0
        L53:
            r0 = r10
        L54:
            r1 = r11
        L56:
            int r0 = r0.indexOf(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m472Vulcan_c(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public static int m473Vulcan_S(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 6097127824259(0x58b99235b83, double:3.012381396269E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r12
            r2 = r17
            r3 = r13
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m474Vulcan_B(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m473Vulcan_S(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    private static int m474Vulcan_B(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m474Vulcan_B(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_G(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 != 0) goto L42
            if (r0 == 0) goto L57
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r0 = r8
        L42:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L5e
            r1 = r12
            if (r1 != 0) goto L5e
            if (r0 != 0) goto L5d
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L59
            throw r0     // Catch: java.lang.IllegalStateException -> L59
        L57:
            r0 = -1
            return r0
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L59
            throw r0
        L5d:
            r0 = r8
        L5e:
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L6c
            r1 = r12
            if (r1 != 0) goto L9d
            if (r0 != 0) goto L96
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L79
            throw r0     // Catch: java.lang.IllegalStateException -> L79
        L70:
            r0 = r7
            r1 = r12
            if (r1 != 0) goto L9d
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L88
            throw r0     // Catch: java.lang.IllegalStateException -> L88
        L7d:
            r1 = r11
            int r1 = r1.length()     // Catch: java.lang.IllegalStateException -> L88 java.lang.IllegalStateException -> L92
            if (r0 < r1) goto L96
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L92
            throw r0     // Catch: java.lang.IllegalStateException -> L92
        L8c:
            r0 = r11
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L92
            return r0
        L92:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L92
            throw r0
        L96:
            r0 = r11
            r1 = r8
            r2 = r7
            int r0 = r0.indexOf(r1, r2)
        L9d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_G(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static int m475Vulcan_e(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 33164620457936(0x1e29bd6be7d0, double:1.638549962563E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r11
            r2 = r15
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m475Vulcan_e(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_H(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_H(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_b(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r8
            r1 = r12
            if (r1 != 0) goto L36
            if (r0 == 0) goto L4b
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L35:
            r0 = r9
        L36:
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L53
            if (r1 != 0) goto L52
            if (r0 != 0) goto L51
            goto L4b
        L47:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4d
            throw r0     // Catch: java.lang.IllegalStateException -> L4d
        L4b:
            r0 = -1
            return r0
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4d
            throw r0
        L51:
            r0 = r8
        L52:
            r1 = r9
        L53:
            int r0 = r0.lastIndexOf(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_b(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_u(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 32491913830870(0x1d8d1cfb61d6, double:1.6053138391467E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r13
            r1 = r16
            r2 = r17
            r3 = r12
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m474Vulcan_B(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_u(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_q(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r8
            r1 = r13
            if (r1 != 0) goto L43
            if (r0 == 0) goto L58
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r0 = r12
        L43:
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L61
            if (r1 != 0) goto L5f
            if (r0 != 0) goto L5e
            goto L58
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L5a
            throw r0     // Catch: java.lang.IllegalStateException -> L5a
        L58:
            r0 = -1
            return r0
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L5a
            throw r0
        L5e:
            r0 = r8
        L5f:
            r1 = r12
        L61:
            r2 = r11
            int r0 = r0.lastIndexOf(r1, r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_q(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_d(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 99515579825984(0x5a8246c8ff40, double:4.9167229217991E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r17
            if (r1 != 0) goto L41
            if (r0 == 0) goto L50
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L40:
            r0 = r13
        L41:
            r1 = r17
            if (r1 != 0) goto L58
            if (r0 != 0) goto L56
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L52
            throw r0     // Catch: java.lang.IllegalStateException -> L52
        L50:
            r0 = -1
            return r0
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L52
            throw r0
        L56:
            r0 = r14
        L58:
            r1 = r15
            r2 = r13
            r3 = r14
            int r3 = r3.length()
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_d(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_y(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 251
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_y(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_s(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 != 0) goto L38
            if (r0 == 0) goto L4d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r8
        L38:
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L56
            if (r1 != 0) goto L55
            if (r0 != 0) goto L53
            goto L4d
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4f
            throw r0     // Catch: java.lang.IllegalStateException -> L4f
        L4d:
            r0 = 0
            return r0
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4f
            throw r0
        L53:
            r0 = r11
        L55:
            r1 = r8
        L56:
            int r0 = r0.indexOf(r1)     // Catch: java.lang.IllegalStateException -> L64
            r1 = r12
            if (r1 != 0) goto L69
            if (r0 < 0) goto L6c
            goto L68
        L64:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L68:
            r0 = 1
        L69:
            goto L6d
        L6c:
            r0 = 0
        L6d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_s(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static boolean m477Vulcan_G(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 != 0) goto L38
            if (r0 == 0) goto L47
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r8
        L38:
            r1 = r12
            if (r1 != 0) goto L4e
            if (r0 != 0) goto L4d
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L49
            throw r0     // Catch: java.lang.IllegalStateException -> L49
        L47:
            r0 = 0
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L49
            throw r0
        L4d:
            r0 = r8
        L4e:
            int r0 = r0.length()
            r13 = r0
            r0 = r11
            int r0 = r0.length()
            r1 = r13
            int r0 = r0 - r1
            r14 = r0
            r0 = 0
            r15 = r0
        L60:
            r0 = r15
            r1 = r14
            if (r0 > r1) goto L9e
        L67:
            r0 = r11
            r1 = 1
            r2 = r15
            r3 = r8
            r4 = 0
            r5 = r13
            boolean r0 = r0.regionMatches(r1, r2, r3, r4, r5)     // Catch: java.lang.IllegalStateException -> L86
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L80
            if (r1 != 0) goto La5
            r1 = r12
        L80:
            if (r1 != 0) goto L95
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L90
            throw r0     // Catch: java.lang.IllegalStateException -> L90
        L8a:
            if (r0 == 0) goto L96
            goto L94
        L90:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L94:
            r0 = 1
        L95:
            return r0
        L96:
            int r15 = r15 + 1
            r0 = r12
            if (r0 == 0) goto L60
        L9e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L67
            r0 = 0
        La5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m477Vulcan_G(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static boolean m479Vulcan_y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 30782799025879(0x1bff2dcd16d7, double:1.5208723481522E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r10
            r1 = r16
            if (r1 != 0) goto L45
            if (r0 != 0) goto L44
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L40
            throw r0     // Catch: java.lang.IllegalStateException -> L40
        L3e:
            r0 = 0
            return r0
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L40
            throw r0
        L44:
            r0 = r11
        L45:
            r1 = r10
            char[] r1 = r1.toCharArray()
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m478Vulcan_q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m479Vulcan_y(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_A(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 348
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_A(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_a(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 7949890470079(0x73afa65c0bf, double:3.9277677694668E-311)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r11
            r1 = r17
            if (r1 != 0) goto L3f
            if (r0 == 0) goto L54
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3e:
            r0 = r12
        L3f:
            r1 = r17
            r2 = r13
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5c
            if (r1 != 0) goto L5b
            if (r0 != 0) goto L5a
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L56
            throw r0     // Catch: java.lang.IllegalStateException -> L56
        L54:
            r0 = 1
            return r0
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L56
            throw r0
        L5a:
            r0 = r11
        L5b:
            r1 = r12
        L5c:
            char[] r1 = r1.toCharArray()
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_a(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_F(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_F(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_Y(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r8
            if (r0 == 0) goto L40
            r0 = r9
            r1 = r12
            if (r1 != 0) goto L47
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3c
            throw r0     // Catch: java.lang.IllegalStateException -> L3c
        L36:
            if (r0 != 0) goto L46
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L42
            throw r0     // Catch: java.lang.IllegalStateException -> L42
        L40:
            r0 = -1
            return r0
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L42
            throw r0
        L46:
            r0 = r9
        L47:
            int r0 = r0.length
            r13 = r0
            r0 = -1
            r14 = r0
            r0 = 0
            r15 = r0
            r0 = 0
            r16 = r0
        L53:
            r0 = r16
            r1 = r13
            if (r0 >= r1) goto Lb7
            r0 = r9
            r1 = r16
            r0 = r0[r1]
            r17 = r0
            r0 = r17
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L8d
            if (r1 != 0) goto L8b
            if (r0 != 0) goto L83
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7f
            throw r0     // Catch: java.lang.IllegalStateException -> L7f
        L77:
            r0 = r12
            if (r0 == 0) goto Laf
            goto L83
        L7f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L87
            throw r0     // Catch: java.lang.IllegalStateException -> L87
        L83:
            r0 = r8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8b:
            r1 = r17
        L8d:
            int r0 = r0.lastIndexOf(r1)
            r15 = r0
            r0 = r12
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lb4
            if (r0 != 0) goto Lb2
            r0 = r15
            r1 = r14
            if (r0 <= r1) goto Laf
            goto Lab
        La7:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lab:
            r0 = r15
            r14 = r0
        Laf:
            int r16 = r16 + 1
        Lb2:
            r0 = r12
        Lb4:
            if (r0 == 0) goto L53
        Lb7:
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Y(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static String Vulcan_jH(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        int iIntValue = ((Integer) objArr[2]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        if (str == null) {
            return null;
        }
        int i = iIntValue;
        String str2 = strVulcan_k;
        int i2 = i;
        int i3 = i;
        if (j >= 0) {
            if (str2 == null) {
                if (i < 0) {
                    iIntValue = str.length() + iIntValue;
                }
                i2 = iIntValue;
            }
            str2 = strVulcan_k;
            i3 = i2;
        }
        int i4 = i3;
        ?? r0 = i3;
        if (j >= 0) {
            if (str2 == null) {
                if (i3 < 0) {
                    iIntValue = 0;
                }
                i4 = iIntValue;
            }
            str2 = str;
            r0 = i4;
        }
        try {
            if (r0 > str2.length()) {
                return "";
            }
            return str.substring(iIntValue);
        } catch (IllegalStateException unused) {
            throw a(r0);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:64:0x00e4
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_m2(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 243
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_m2(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static java.lang.String m481Vulcan_q(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            if (r0 != 0) goto L32
            r0 = 0
            return r0
        L2e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L2e
            throw r0
        L32:
            r0 = r7
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L5f
            r1 = r11
            if (r1 != 0) goto L5f
            if (r0 >= 0) goto L4f
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4b
            throw r0     // Catch: java.lang.IllegalStateException -> L4b
        L48:
            java.lang.String r0 = ""
            return r0
        L4b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4b
            throw r0
        L4f:
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L6f
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L5b
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5f:
            r1 = r7
            if (r0 > r1) goto L69
            r0 = r8
            return r0
        L65:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L65
            throw r0
        L69:
            r0 = r8
            r1 = 0
            r2 = r7
            java.lang.String r0 = r0.substring(r1, r2)
        L6f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m481Vulcan_q(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_V(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            if (r0 != 0) goto L34
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r9
            r1 = r7
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L62
            r1 = r11
            if (r1 != 0) goto L62
            if (r0 >= 0) goto L51
            goto L4a
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4d
            throw r0     // Catch: java.lang.IllegalStateException -> L4d
        L4a:
            java.lang.String r0 = ""
            return r0
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4d
            throw r0
        L51:
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L79
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L5e
            goto L62
        L5e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L62:
            r1 = r9
            if (r0 > r1) goto L6d
            r0 = r10
            return r0
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L69
            throw r0
        L6d:
            r0 = r10
            r1 = r10
            int r1 = r1.length()
            r2 = r9
            int r1 = r1 - r2
            java.lang.String r0 = r0.substring(r1)
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_V(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:35:0x009b  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String m482Vulcan_x(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m482Vulcan_x(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_Af(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 133665606757445(0x799173026c45, double:6.6039584329379E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = r14
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m485Vulcan_a(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Af(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public static java.lang.String m485Vulcan_a(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r9
            r1 = r13
            if (r1 != 0) goto L40
            if (r0 == 0) goto L6d
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = r10
        L40:
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L59
            if (r1 != 0) goto L57
            if (r0 == 0) goto L6d
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L56:
            r0 = r8
        L57:
            r1 = r13
        L59:
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L75
            if (r1 != 0) goto L74
            if (r0 != 0) goto L73
            goto L6d
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6f
            throw r0     // Catch: java.lang.IllegalStateException -> L6f
        L6d:
            r0 = 0
            return r0
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6f
            throw r0
        L73:
            r0 = r9
        L74:
            r1 = r10
        L75:
            int r0 = r0.indexOf(r1)
            r14 = r0
            r0 = r14
            r1 = r13
            if (r1 != 0) goto L9f
            r1 = -1
            if (r0 == r1) goto Lb9
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L9b
            throw r0     // Catch: java.lang.IllegalStateException -> L9b
        L8c:
            r0 = r9
            r1 = r8
            r2 = r14
            r3 = r10
            int r3 = r3.length()     // Catch: java.lang.IllegalStateException -> L9b
            int r2 = r2 + r3
            int r0 = r0.indexOf(r1, r2)     // Catch: java.lang.IllegalStateException -> L9b
            goto L9f
        L9b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9f:
            r15 = r0
            r0 = r15
            r1 = -1
            if (r0 == r1) goto Lb9
            r0 = r9
            r1 = r14
            r2 = r10
            int r2 = r2.length()     // Catch: java.lang.IllegalStateException -> Lb5
            int r1 = r1 + r2
            r2 = r15
            java.lang.String r0 = r0.substring(r1, r2)     // Catch: java.lang.IllegalStateException -> Lb5
            return r0
        Lb5:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> Lb5
            throw r0
        Lb9:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m485Vulcan_a(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_AV(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 95617825198140(0x56f6c281503c, double:4.72414825604545E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r13
            r2 = r15
            r3 = r13
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m485Vulcan_a(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_AV(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_ms(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 59286792185282(0x35ebc83025c2, double:2.9291567270877E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            r1 = r14
            r2 = r16
            r3 = r15
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m485Vulcan_a(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_ms(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0039: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0039: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static java.lang.String[] m487Vulcan_t(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 118325727711996(0x6b9ddaf7d2fc, double:5.8460677081663E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = 0
            r2 = -1
            r3 = r15
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = Vulcan_j(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m487Vulcan_t(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0073: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0073: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static java.lang.String[] m488Vulcan_s(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r0 = r14
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r13
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r15
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 98052559680427(0x592da3fd33ab, double:4.84444012248975E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r16
            r1 = r12
            r2 = 0
            r3 = r19
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m494Vulcan__(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m488Vulcan_s(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_D(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 104995917686124(0x5f7e4460656c, double:5.1874875882289E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r13
            r2 = r16
            r3 = -1
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m497Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_D(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_j(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 131768686420364(0x77d7c9bf218c, double:6.510238115793E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            r1 = r16
            r2 = r17
            r3 = r15
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m497Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_j(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static java.lang.String[] m489Vulcan_K(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 45108001134495(0x29068662579f, double:2.2286313713122E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r13
            r2 = -1
            r3 = 0
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m492Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m489Vulcan_K(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public static java.lang.String[] m490Vulcan_I(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 64522351843830(0x3aaec7dc99f6, double:3.1878277434918E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r16
            r1 = r13
            r2 = r17
            r3 = 0
            r4 = r18
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m492Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m490Vulcan_I(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_L(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 107379456298979(0x61a93a594fe3, double:5.3052500426437E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r15
            r2 = -1
            r3 = 1
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m492Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_L(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static java.lang.String[] m491Vulcan_u(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 134225718867572(0x7a13dc4af674, double:6.63163164808126E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            r1 = r17
            r2 = r16
            r3 = 1
            r4 = r18
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m492Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m491Vulcan_u(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    private static java.lang.String[] m492Vulcan_N(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 584
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m492Vulcan_N(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public static java.lang.String[] m493Vulcan_H(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 92874339898273(0x5477fe09d3a1, double:4.58860207239197E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = 0
            r2 = r15
            r3 = -1
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m497Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m493Vulcan_H(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_w(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 13431732474303(0xc3751a491bf, double:6.6361575796834E-311)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            r1 = r12
            r2 = 1
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m494Vulcan__(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_w(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    private static java.lang.String[] m494Vulcan__(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 399
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m494Vulcan__(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x005d: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x005d: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public static java.lang.String[] m495Vulcan_a(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 72430035349973(0x41dfee8731d5, double:3.57851921934887E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            r1 = r14
            r2 = r16
            r3 = -1
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m497Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m495Vulcan_a(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0067: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public static java.lang.String[] m496Vulcan_d(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 13055798335448(0xbdfca38d7d8, double:6.450421436576E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r13
            r2 = r17
            r3 = r12
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m497Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m496Vulcan_d(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    private static java.lang.String[] m497Vulcan_A(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 685
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m497Vulcan_A(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    private static java.lang.String[] m498Vulcan_n(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 464
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m498Vulcan_n(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_dO(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 37859504665242(0x226eda53b29a, double:1.87050806236625E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = 0
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_o(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_dO(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_d3(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 66036018141501(0x3c0f3567593d, double:3.2626127951865E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = 0
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_o(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_d3(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_Zw(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 332
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Zw(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_o(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 6920060891009(0x64b33c56f81, double:3.418964353377E-311)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r18 = r0
            r0 = r12
            r1 = r18
            if (r1 != 0) goto L46
            if (r0 != 0) goto L45
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L41
            throw r0     // Catch: java.lang.IllegalStateException -> L41
        L3f:
            r0 = 0
            return r0
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L41
            throw r0
        L45:
            r0 = r12
        L46:
            r1 = r15
            r2 = r16
            r3 = 0
            r4 = r12
            int r4 = r4.length
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m500Vulcan_E(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_o(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public static java.lang.String m500Vulcan_E(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 347
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m500Vulcan_E(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_NU(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 385
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_NU(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_vB(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 405
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_vB(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public static java.lang.String m501Vulcan_J(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 37433531759004(0x220bac5cf99c, double:1.8494622044631E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r12
            r1 = r17
            if (r1 != 0) goto L48
            if (r0 != 0) goto L47
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L43
            throw r0     // Catch: java.lang.IllegalStateException -> L43
        L41:
            r0 = 0
            return r0
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L43
            throw r0
        L47:
            r0 = r12
        L48:
            java.util.Iterator r0 = r0.iterator()
            r1 = r11
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_NU(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m501Vulcan_J(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_m6(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 67655000418693(0x3d8828446985, double:3.34260114762514E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r15
            r1 = r16
            r2 = r14
            r3 = r17
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_X(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_m6(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_mg(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 126355140232986(0x72eb593fc71a, double:6.24277339645715E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r12
            r2 = r15
            r3 = r17
            r4 = -1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_X(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_mg(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0072: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0072: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public static java.lang.String m506Vulcan_f(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r17 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 127830320731287(0x7442d0dbd497, double:6.3156569970197E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            r1 = r18
            r2 = r16
            r3 = r17
            r4 = 0
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_U(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m506Vulcan_f(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_g(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 124386313102855(0x7120f201e607, double:6.14550041169736E-310)
            long r1 = r1 ^ r2
            r18 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r20 = r0
            r0 = r17
            r1 = r20
            if (r1 != 0) goto L52
            if (r0 != 0) goto L50
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4c
            throw r0     // Catch: java.lang.IllegalStateException -> L4c
        L48:
            r0 = 0
            goto L53
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4c
            throw r0
        L50:
            r0 = r17
        L52:
            int r0 = r0.length
        L53:
            r21 = r0
            r0 = r13
            r1 = r18
            r2 = r17
            r3 = r16
            r4 = 1
            r5 = r21
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_U(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_g(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public static java.lang.String m507Vulcan_C(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r6
            r1 = r11
            if (r1 != 0) goto L50
            if (r0 != 0) goto L49
            goto L43
        L3f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L45
            throw r0     // Catch: java.lang.IllegalStateException -> L45
        L43:
            r0 = 0
            return r0
        L45:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L45
            throw r0
        L49:
            r0 = r6
            r1 = r10
            r2 = r7
            java.lang.String r0 = r0.replace(r1, r2)
        L50:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m507Vulcan_C(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_lK(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 5441873002034(0x4f308e83e32, double:2.688642499336E-311)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            java.lang.String r2 = "\n"
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Ad(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lK(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    public static String Vulcan_Ad(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        ?? A = str;
        ?? Substring = A;
        if (strVulcan_k == null) {
            try {
                try {
                    A = A.length();
                    if (A == 0) {
                        return str;
                    }
                    Substring = str.substring(str.length() - str2.length());
                } catch (IllegalStateException unused) {
                    A = a(A);
                    throw A;
                }
            } catch (IllegalStateException unused2) {
                throw a(A);
            }
        }
        ?? r13 = Substring;
        ?? Equals = str2;
        String str3 = strVulcan_k;
        if (j >= 0) {
            if (str3 != null) {
                return Equals;
            }
            str3 = r13 == true ? 1 : 0;
        }
        try {
            try {
                Equals = Equals.equals(str3);
                if (Equals != 0) {
                    return str.substring(0, str.length() - str2.length());
                }
                return str;
            } catch (IllegalStateException unused3) {
                throw a(Equals);
            }
        } catch (IllegalStateException unused4) {
            throw a(Equals);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    public static String Vulcan_Ai(Object[] objArr) {
        String str = (String) objArr[0];
        String str2 = (String) objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        int iLastIndexOf = str.lastIndexOf(str2);
        try {
            try {
                Vulcan_k = iLastIndexOf;
                int length = str.length() - str2.length();
                ?? Substring = Vulcan_k;
                if (Vulcan_k == 0) {
                    if (Vulcan_k == length) {
                        return str2;
                    }
                    Substring = iLastIndexOf;
                    length = -1;
                }
                if (Substring != length) {
                    try {
                        Substring = str.substring(iLastIndexOf);
                        return Substring;
                    } catch (IllegalStateException unused) {
                        throw a(Substring);
                    }
                }
                return "";
            } catch (IllegalStateException unused2) {
                Vulcan_k = a(Vulcan_k);
                throw Vulcan_k;
            }
        } catch (IllegalStateException unused3) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public static String m512Vulcan_H(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        int iIndexOf = str.indexOf(str2);
        if (iIndexOf == -1) {
            return str;
        }
        return str.substring(iIndexOf + str2.length());
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static String m513Vulcan_t(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        int iIndexOf = str.indexOf(str2);
        if (iIndexOf == -1) {
            return "";
        }
        return str.substring(0, iIndexOf + str2.length());
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static java.lang.String m514Vulcan_l(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = r12
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L5d
            r1 = 2
            r2 = r11
            if (r2 != 0) goto L5c
            if (r0 >= r1) goto L59
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L55
            throw r0     // Catch: java.lang.IllegalStateException -> L55
        L52:
            java.lang.String r0 = ""
            return r0
        L55:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L55
            throw r0
        L59:
            r0 = r12
            r1 = 1
        L5c:
            int r0 = r0 - r1
        L5d:
            r13 = r0
            r0 = r10
            r1 = 0
            r2 = r13
            java.lang.String r0 = r0.substring(r1, r2)
            r14 = r0
            r0 = r10
            r1 = r13
            char r0 = r0.charAt(r1)
            r15 = r0
            r0 = r15
            r1 = 10
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto La7
            r2 = r11
            if (r2 != 0) goto La7
            if (r0 != r1) goto Lb9
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L93
            throw r0     // Catch: java.lang.IllegalStateException -> L93
        L89:
            r0 = r14
            r1 = r11
            if (r1 != 0) goto Lbb
            goto L97
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La3
            throw r0     // Catch: java.lang.IllegalStateException -> La3
        L97:
            r1 = r13
            r2 = 1
            int r1 = r1 - r2
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> La3
            r1 = 13
            goto La7
        La3:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La7:
            if (r0 != r1) goto Lb9
            r0 = r14
            r1 = 0
            r2 = r13
            r3 = 1
            int r2 = r2 - r3
            java.lang.String r0 = r0.substring(r1, r2)     // Catch: java.lang.IllegalStateException -> Lb5
            return r0
        Lb5:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> Lb5
            throw r0
        Lb9:
            r0 = r14
        Lbb:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m514Vulcan_l(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_l_(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r11
            int r1 = r1.length()
            r2 = 1
            int r1 = r1 - r2
            r13 = r1
            r12 = r0
            r0 = r13
            r1 = r12
            if (r1 != 0) goto L44
            if (r0 > 0) goto L3e
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3a
            throw r0     // Catch: java.lang.IllegalStateException -> L3a
        L37:
            java.lang.String r0 = ""
            return r0
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3a
            throw r0
        L3e:
            r0 = r11
            r1 = r13
            char r0 = r0.charAt(r1)
        L44:
            r14 = r0
            r0 = r14
            r1 = 10
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L82
            r2 = r12
            if (r2 != 0) goto L82
            if (r0 != r1) goto L9a
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L72
            throw r0     // Catch: java.lang.IllegalStateException -> L72
        L5f:
            r0 = r11
            r1 = r13
            r2 = 1
            r3 = r9
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto La8
            int r1 = r1 - r2
            r2 = r12
            if (r2 != 0) goto La6
            goto L76
        L72:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7e
            throw r0     // Catch: java.lang.IllegalStateException -> L7e
        L76:
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L7e
            r1 = 13
            goto L82
        L7e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L82:
            if (r0 != r1) goto La4
            int r13 = r13 + (-1)
            r0 = r12
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto La5
            if (r0 == 0) goto La4
            goto L9a
        L96:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La0
            throw r0     // Catch: java.lang.IllegalStateException -> La0
        L9a:
            int r13 = r13 + 1
            goto La4
        La0:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La4:
            r0 = r11
        La5:
            r1 = 0
        La6:
            r2 = r13
        La8:
            java.lang.String r0 = r0.substring(r1, r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_l_(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_lq(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 1952755510857(0x1c6a94c6e49, double:9.647894126416E-312)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_O5.Vulcan_P(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lq(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_jv(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 535
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jv(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x008d A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x007b A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x008a -> B:18:0x007b). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String Vulcan_Uu(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r7
            r1 = r11
            if (r1 != 0) goto L60
            if (r0 >= 0) goto L5f
            goto L3c
        L38:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            throw r0     // Catch: java.lang.IndexOutOfBoundsException -> L5b
        L3c:
            java.lang.IndexOutOfBoundsException r0 = new java.lang.IndexOutOfBoundsException     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            r1 = r0
            java.lang.StringBuffer r2 = new java.lang.StringBuffer     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            r3 = r2
            r3.<init>()     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            java.lang.String[] r3 = ac.vulcan.anticheat.C0027Vulcan_ku.b     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            r4 = 6
            r3 = r3[r4]     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            r3 = r7
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            java.lang.String r2 = r2.toString()     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            r1.<init>(r2)     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            throw r0     // Catch: java.lang.IndexOutOfBoundsException -> L5b
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IndexOutOfBoundsException -> L5b
            throw r0
        L5f:
            r0 = r7
        L60:
            char[] r0 = new char[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L67:
            r0 = r13
            r1 = r12
            int r1 = r1.length
            if (r0 >= r1) goto L7e
            r0 = r12
            r1 = r13
            r2 = r10
            r0[r1] = r2
            int r13 = r13 + 1
            r0 = r11
        L7b:
            if (r0 == 0) goto L67
        L7e:
            java.lang.String r0 = new java.lang.String
            r1 = r0
            r2 = r12
            r1.<init>(r2)
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L7b
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Uu(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_jx(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 44303647633390(0x284b3f2defee, double:2.1888910281114E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            r1 = r12
            r2 = r15
            r3 = 32
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_j4(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jx(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_j4(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_j4(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0053: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0053: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_jr(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 10315329723883(0x961b9905deb, double:5.0964500420957E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r11
            r2 = r15
            r3 = 32
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_jY(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jr(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_jY(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jY(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public static int m516Vulcan_C(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L37
            if (r0 != 0) goto L36
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L32
            throw r0     // Catch: java.lang.IllegalStateException -> L32
        L2e:
            r0 = 0
            goto L3a
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L32
            throw r0
        L36:
            r0 = r8
        L37:
            int r0 = r0.length()
        L3a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m516Vulcan_C(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_jc(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 26309743907009(0x17edb6f090c1, double:1.2998740615334E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r15
            r2 = 32
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_O(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jc(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_O(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_O(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static java.lang.String m517Vulcan_D(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L38
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.String r0 = r0.toUpperCase()
        L38:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m517Vulcan_D(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.util.Locale r1 = (java.util.Locale) r1
            r7 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3b
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L37
            throw r0     // Catch: java.lang.IllegalStateException -> L37
        L35:
            r0 = 0
            return r0
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L37
            throw r0
        L3b:
            r0 = r6
            r1 = r7
            java.lang.String r0 = r0.toUpperCase(r1)
        L40:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_v(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_lO(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L38
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.String r0 = r0.toLowerCase()
        L38:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lO(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public static java.lang.String m518Vulcan_z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Locale r1 = (java.util.Locale) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L42
            if (r0 != 0) goto L3c
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L38
            throw r0     // Catch: java.lang.IllegalStateException -> L38
        L36:
            r0 = 0
            return r0
        L38:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L38
            throw r0
        L3c:
            r0 = r8
            r1 = r9
            java.lang.String r0 = r0.toLowerCase(r1)
        L42:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m518Vulcan_z(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public static java.lang.String m519Vulcan_w(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 116896972411344(0x6a51328411d0, double:5.7754778171297E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 126089729576949(0x72ad8d8a8ff5, double:6.22966036773834E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r10
            r1 = r17
            if (r1 != 0) goto L55
            if (r0 == 0) goto L54
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L47
            throw r0     // Catch: java.lang.IllegalStateException -> L47
        L3e:
            r0 = r10
            r1 = r17
            if (r1 != 0) goto L55
            goto L4b
        L47:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4b:
            int r0 = r0.length()
            r1 = r0
            r18 = r1
            if (r0 != 0) goto L56
        L54:
            r0 = r10
        L55:
            return r0
        L56:
            ac.vulcan.anticheat.Vulcan_P r0 = new ac.vulcan.anticheat.Vulcan_P
            r1 = r0
            r2 = r18
            r1.<init>(r2)
            r1 = r10
            r2 = 0
            char r1 = r1.charAt(r2)
            char r1 = java.lang.Character.toTitleCase(r1)
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)
            r1 = r10
            r2 = 1
            java.lang.String r1 = r1.substring(r2)
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m519Vulcan_w(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static java.lang.String m520Vulcan_y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 89840264044555(0x51b59106600b, double:4.4386988077721E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 80578653781550(0x49492e08fe2e, double:3.98111446215997E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r10
            r1 = r17
            if (r1 != 0) goto L55
            if (r0 == 0) goto L54
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L47
            throw r0     // Catch: java.lang.IllegalStateException -> L47
        L3e:
            r0 = r10
            r1 = r17
            if (r1 != 0) goto L55
            goto L4b
        L47:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4b:
            int r0 = r0.length()
            r1 = r0
            r18 = r1
            if (r0 != 0) goto L56
        L54:
            r0 = r10
        L55:
            return r0
        L56:
            ac.vulcan.anticheat.Vulcan_P r0 = new ac.vulcan.anticheat.Vulcan_P
            r1 = r0
            r2 = r18
            r1.<init>(r2)
            r1 = r10
            r2 = 0
            char r1 = r1.charAt(r2)
            char r1 = java.lang.Character.toLowerCase(r1)
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)
            r1 = r10
            r2 = 1
            java.lang.String r1 = r1.substring(r2)
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m520Vulcan_y(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_lL(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 314
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lL(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_le(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 79468085136949(0x48469afc4e35, double:3.9262450806954E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_X.Vulcan_I(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_le(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static boolean m523Vulcan_D(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto L78
        L44:
            r0 = r10
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L60
            boolean r0 = java.lang.Character.isLetter(r0)     // Catch: java.lang.IllegalStateException -> L60
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L5a
            if (r1 != 0) goto L7f
            r1 = r11
        L5a:
            if (r1 != 0) goto L6f
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6a
            throw r0     // Catch: java.lang.IllegalStateException -> L6a
        L64:
            if (r0 != 0) goto L70
            goto L6e
        L6a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6e:
            r0 = 0
        L6f:
            return r0
        L70:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        L78:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
            r0 = 1
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m523Vulcan_D(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static boolean m524Vulcan_U(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto La3
        L44:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L66
            boolean r0 = java.lang.Character.isLetter(r0)     // Catch: java.lang.IllegalStateException -> L66
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5a
            if (r1 != 0) goto Laa
            r1 = r11
        L5a:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L83
            if (r1 != 0) goto L81
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L70
            throw r0     // Catch: java.lang.IllegalStateException -> L70
        L6a:
            if (r0 != 0) goto L9b
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7d
            throw r0     // Catch: java.lang.IllegalStateException -> L7d
        L74:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L7d
            goto L81
        L7d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L81:
            r1 = r11
        L83:
            if (r1 != 0) goto L9a
            r1 = 32
            if (r0 == r1) goto L9b
            goto L92
        L8e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L96
            throw r0     // Catch: java.lang.IllegalStateException -> L96
        L92:
            r0 = 0
            goto L9a
        L96:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9a:
            return r0
        L9b:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        La3:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
            r0 = 1
        Laa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m524Vulcan_U(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public static boolean m525Vulcan_b(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto L78
        L44:
            r0 = r10
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L60
            boolean r0 = java.lang.Character.isLetterOrDigit(r0)     // Catch: java.lang.IllegalStateException -> L60
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5a
            if (r1 != 0) goto L7f
            r1 = r11
        L5a:
            if (r1 != 0) goto L6f
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6a
            throw r0     // Catch: java.lang.IllegalStateException -> L6a
        L64:
            if (r0 != 0) goto L70
            goto L6e
        L6a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6e:
            r0 = 0
        L6f:
            return r0
        L70:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        L78:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
            r0 = 1
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m525Vulcan_b(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public static boolean m526Vulcan_B(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto La3
        L44:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L66
            boolean r0 = java.lang.Character.isLetterOrDigit(r0)     // Catch: java.lang.IllegalStateException -> L66
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L5a
            if (r1 != 0) goto Laa
            r1 = r11
        L5a:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L83
            if (r1 != 0) goto L81
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L70
            throw r0     // Catch: java.lang.IllegalStateException -> L70
        L6a:
            if (r0 != 0) goto L9b
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7d
            throw r0     // Catch: java.lang.IllegalStateException -> L7d
        L74:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L7d
            goto L81
        L7d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L81:
            r1 = r11
        L83:
            if (r1 != 0) goto L9a
            r1 = 32
            if (r0 == r1) goto L9b
            goto L92
        L8e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L96
            throw r0     // Catch: java.lang.IllegalStateException -> L96
        L92:
            r0 = 0
            goto L9a
        L96:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9a:
            return r0
        L9b:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        La3:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
            r0 = 1
        Laa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m526Vulcan_B(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static boolean m527Vulcan_t(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto L78
        L44:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L60
            boolean r0 = java.lang.Character.isDigit(r0)     // Catch: java.lang.IllegalStateException -> L60
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5a
            if (r1 != 0) goto L7f
            r1 = r11
        L5a:
            if (r1 != 0) goto L6f
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6a
            throw r0     // Catch: java.lang.IllegalStateException -> L6a
        L64:
            if (r0 != 0) goto L70
            goto L6e
        L6a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6e:
            r0 = 0
        L6f:
            return r0
        L70:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        L78:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
            r0 = 1
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m527Vulcan_t(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public static boolean m528Vulcan_F(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto La3
        L44:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L66
            boolean r0 = java.lang.Character.isDigit(r0)     // Catch: java.lang.IllegalStateException -> L66
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5a
            if (r1 != 0) goto Laa
            r1 = r11
        L5a:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L83
            if (r1 != 0) goto L81
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L70
            throw r0     // Catch: java.lang.IllegalStateException -> L70
        L6a:
            if (r0 != 0) goto L9b
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7d
            throw r0     // Catch: java.lang.IllegalStateException -> L7d
        L74:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L7d
            goto L81
        L7d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L81:
            r1 = r11
        L83:
            if (r1 != 0) goto L9a
            r1 = 32
            if (r0 == r1) goto L9b
            goto L92
        L8e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L96
            throw r0     // Catch: java.lang.IllegalStateException -> L96
        L92:
            r0 = 0
            goto L9a
        L96:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9a:
            return r0
        L9b:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        La3:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
            r0 = 1
        Laa:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m528Vulcan_F(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public static boolean m529Vulcan_I(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0     // Catch: java.lang.IllegalStateException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length()
            r12 = r0
            r0 = 0
            r13 = r0
        L3d:
            r0 = r13
            r1 = r12
            if (r0 >= r1) goto L78
        L44:
            r0 = r8
            r1 = r13
            char r0 = r0.charAt(r1)     // Catch: java.lang.IllegalStateException -> L60
            boolean r0 = java.lang.Character.isWhitespace(r0)     // Catch: java.lang.IllegalStateException -> L60
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L5a
            if (r1 != 0) goto L7f
            r1 = r11
        L5a:
            if (r1 != 0) goto L6f
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L6a
            throw r0     // Catch: java.lang.IllegalStateException -> L6a
        L64:
            if (r0 != 0) goto L70
            goto L6e
        L6a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6e:
            r0 = 0
        L6f:
            return r0
        L70:
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L3d
        L78:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
            r0 = 1
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m529Vulcan_I(java.lang.Object[]):boolean");
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public static String m532Vulcan_L(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        if (Vulcan_fX.Vulcan_k() == null) {
            return str == null ? "" : str;
        }
        return str;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public static String m533Vulcan_F(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        if (Vulcan_fX.Vulcan_k() == null) {
            return str == null ? str2 : str;
        }
        return str;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v7 ??, still in use, count: 3, list:
          (r0v7 ?? I:java.lang.String) from 0x0067: RETURN (r0v7 ?? I:java.lang.String) A[SYNTHETIC]
          (r0v7 ??) from 0x0057: PHI (r0v8 ??) = (r0v7 ??), (r0v12 ??) binds: [B:17:0x0034, B:18:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v7 ??) from 0x005f: PHI (r0v5 ??) = (r0v4 ??), (r0v7 ??), (r0v12 ??) binds: [B:16:0x002e, B:17:0x0034, B:18:?] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public static java.lang.String m534Vulcan_B(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v7 ??, still in use, count: 3, list:
          (r0v7 ?? I:java.lang.String) from 0x0067: RETURN (r0v7 ?? I:java.lang.String) A[SYNTHETIC]
          (r0v7 ??) from 0x0057: PHI (r0v8 ??) = (r0v7 ??), (r0v12 ??) binds: [B:17:0x0034, B:18:?] A[DONT_GENERATE, DONT_INLINE]
          (r0v7 ??) from 0x005f: PHI (r0v5 ??) = (r0v4 ??), (r0v7 ??), (r0v12 ??) binds: [B:16:0x002e, B:17:0x0034, B:18:?] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static java.lang.String m535Vulcan_h(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 92161607339439(0x53d20bde0daf, double:4.55338840519273E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 != 0) goto L60
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0     // Catch: java.lang.IllegalStateException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L39
            throw r0
        L3d:
            ac.vulcan.anticheat.Vulcan_P r0 = new ac.vulcan.anticheat.Vulcan_P
            r1 = r0
            r2 = r10
            r1.<init>(r2)
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_g(r1)
            java.lang.String r0 = r0.toString()
        L60:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m535Vulcan_h(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public static java.lang.String m537Vulcan_j(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 113075511579696(0x66d771b35430, double:5.5866725657452E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = 0
            r2 = r15
            r3 = r14
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m538Vulcan_m(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m537Vulcan_j(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static java.lang.String m538Vulcan_m(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 446
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m538Vulcan_m(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_A7(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 41034637220324(0x25521ef999e4, double:2.02738045401206E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r10
            r1 = r16
            if (r1 != 0) goto L48
            if (r0 != 0) goto L46
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L42
            throw r0     // Catch: java.lang.IllegalStateException -> L42
        L3f:
            r0 = r13
            return r0
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L42
            throw r0
        L46:
            r0 = r13
        L48:
            r1 = r16
            if (r1 != 0) goto L5e
            if (r0 != 0) goto L5d
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L59
            throw r0     // Catch: java.lang.IllegalStateException -> L59
        L57:
            r0 = r10
            return r0
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L59
            throw r0
        L5d:
            r0 = r10
        L5e:
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m540Vulcan_r(r0)
            r17 = r0
            r0 = r17
            r1 = -1
            if (r0 != r1) goto L91
            java.lang.String r0 = ""
            return r0
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L8d
            throw r0
        L91:
            r0 = r13
            r1 = r17
            java.lang.String r0 = r0.substring(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_A7(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static int m540Vulcan_r(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 283
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m540Vulcan_r(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public static int m541Vulcan_V(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 516
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m541Vulcan_V(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r16v0 */
    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0064: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0064: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_PQ(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 75656911009867(0x44cf3f4e384b, double:3.73794806004437E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L38
            if (r0 == 0) goto L48
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r0 = r12
        L38:
            int r0 = r0.length     // Catch: java.lang.IllegalStateException -> L44
            r1 = r15
            if (r1 != 0) goto L6d
            if (r0 != 0) goto L4f
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4b
            throw r0     // Catch: java.lang.IllegalStateException -> L4b
        L48:
            java.lang.String r0 = ""
            return r0
        L4b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L4b
            throw r0
        L4f:
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m541Vulcan_V(r0)
        L6d:
            r16 = r0
            r0 = r16
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lad
            r1 = r15
            if (r1 != 0) goto Lad
            r1 = -1
            if (r0 != r1) goto Lab
            goto L87
        L83:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L92
            throw r0     // Catch: java.lang.IllegalStateException -> L92
        L87:
            r0 = r12
            r1 = 0
            r0 = r0[r1]     // Catch: java.lang.IllegalStateException -> L92 java.lang.IllegalStateException -> L9c
            r1 = r15
            if (r1 != 0) goto Laa
            goto L96
        L92:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L9c
            throw r0     // Catch: java.lang.IllegalStateException -> L9c
        L96:
            if (r0 != 0) goto La7
            goto La0
        L9c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La3
            throw r0     // Catch: java.lang.IllegalStateException -> La3
        La0:
            java.lang.String r0 = ""
            return r0
        La3:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La3
            throw r0
        La7:
            r0 = r12
            r1 = 0
            r0 = r0[r1]
        Laa:
            return r0
        Lab:
            r0 = r16
        Lad:
            if (r0 != 0) goto Lb7
            java.lang.String r0 = ""
            return r0
        Lb3:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> Lb3
            throw r0
        Lb7:
            r0 = r12
            r1 = 0
            r0 = r0[r1]
            r1 = 0
            r2 = r16
            java.lang.String r0 = r0.substring(r1, r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_PQ(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static int m542Vulcan_s(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 416
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m542Vulcan_s(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public static boolean m543Vulcan_V(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 89179847005914(0x511bcd1a16da, double:4.40606987070005E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            r1 = r14
            r2 = 0
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m545Vulcan_w(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m543Vulcan_V(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static boolean m544Vulcan_o(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 74426370454653(0x43b0bd5f747d, double:3.6771512786298E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r15
            r2 = 1
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m545Vulcan_w(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m544Vulcan_o(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    private static boolean m545Vulcan_w(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0027Vulcan_ku.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r9
            r1 = r13
            if (r1 != 0) goto L61
            if (r0 == 0) goto L60
            goto L42
        L3e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L52
            throw r0     // Catch: java.lang.IllegalStateException -> L52
        L42:
            r0 = r8
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L86
            r1 = r13
            if (r1 != 0) goto L86
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L5c
            throw r0     // Catch: java.lang.IllegalStateException -> L5c
        L56:
            if (r0 != 0) goto L85
            goto L60
        L5c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L60:
            r0 = r9
        L61:
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L78
            r1 = r13
            if (r1 != 0) goto L78
            if (r0 != 0) goto L83
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            r0 = r8
        L78:
            if (r0 != 0) goto L83
            r0 = 1
            goto L84
        L7f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L7f
            throw r0
        L83:
            r0 = 0
        L84:
            return r0
        L85:
            r0 = r8
        L86:
            int r0 = r0.length()     // Catch: java.lang.IllegalStateException -> L9f
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L96
            if (r1 != 0) goto Lb5
            r1 = r9
        L96:
            int r1 = r1.length()     // Catch: java.lang.IllegalStateException -> L9f java.lang.IllegalStateException -> La5
            if (r0 <= r1) goto La9
            goto La3
        L9f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La5
            throw r0     // Catch: java.lang.IllegalStateException -> La5
        La3:
            r0 = 0
            return r0
        La5:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> La5
            throw r0
        La9:
            r0 = r9
            r1 = r10
            r2 = 0
            r3 = r8
            r4 = 0
            r5 = r8
            int r5 = r5.length()
            boolean r0 = r0.regionMatches(r1, r2, r3, r4, r5)
        Lb5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m545Vulcan_w(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    private static boolean m549Vulcan_u(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.m549Vulcan_u(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_lH(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 360
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_lH(java.lang.Object[]):java.lang.String");
    }
}
