package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OG.class */
public final class Vulcan_OG extends Vulcan_OA implements Serializable {
    private static final long serialVersionUID = 71849363892730L;
    private final int Vulcan_p;
    private final int Vulcan_G;
    private transient Integer Vulcan_B;
    private transient Integer Vulcan_v;
    private transient int Vulcan__;
    private transient String Vulcan_S;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-7560941783236173025L, 2275317180343884365L, null).a(105318171104951L);
    private static final String[] d;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0076, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 86;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 55;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006f, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0072). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.m88clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    public Vulcan_OG(int i) {
        this.Vulcan_B = null;
        this.Vulcan_v = null;
        this.Vulcan__ = 0;
        this.Vulcan_S = null;
        this.Vulcan_p = i;
        this.Vulcan_G = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0069 A[Catch: IllegalArgumentException -> 0x0074, TRY_LEAVE, TryCatch #1 {IllegalArgumentException -> 0x0074, blocks: (B:18:0x0063, B:20:0x0069), top: B:26:0x0063 }] */
    /* JADX WARN: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_OG] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OG(java.lang.Number r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OG.a
            r1 = 88230878129919(0x503eda262eff, double:4.35918457863987E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r5
            r1.<init>()
            r1 = r5
            r2 = 0
            r1.Vulcan_B = r2
            r1 = r5
            r2 = 0
            r1.Vulcan_v = r2
            r1 = r5
            r2 = 0
            r1.Vulcan__ = r2
            r1 = r5
            r2 = 0
            r1.Vulcan_S = r2
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L63
            if (r0 != 0) goto L46
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L35:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L42
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_OG.d     // Catch: java.lang.IllegalArgumentException -> L42
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L42
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0
        L46:
            r0 = r5
            r1 = r6
            int r1 = r1.intValue()     // Catch: java.lang.IllegalArgumentException -> L5f
            r0.Vulcan_p = r1     // Catch: java.lang.IllegalArgumentException -> L5f
            r0 = r5
            r1 = r6
            int r1 = r1.intValue()     // Catch: java.lang.IllegalArgumentException -> L5f
            r0.Vulcan_G = r1     // Catch: java.lang.IllegalArgumentException -> L5f
            r0 = r9
            if (r0 != 0) goto L78
            r0 = r6
            goto L63
        L5f:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L63:
            boolean r0 = r0 instanceof java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L74
            if (r0 == 0) goto L80
            r0 = r5
            r1 = r6
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch: java.lang.IllegalArgumentException -> L74
            r0.Vulcan_B = r1     // Catch: java.lang.IllegalArgumentException -> L74
            goto L78
        L74:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L78:
            r0 = r5
            r1 = r6
            java.lang.Integer r1 = (java.lang.Integer) r1
            r0.Vulcan_v = r1
        L80:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.<init>(java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    public Vulcan_OG(int i, int i2) {
        long j = a ^ 134446241458128L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                try {
                    this.Vulcan_B = null;
                    this.Vulcan_v = null;
                    this.Vulcan__ = 0;
                    this.Vulcan_S = null;
                    Vulcan_u = Vulcan_u;
                    if (Vulcan_u != 0) {
                        if (i2 < i) {
                            this.Vulcan_p = i2;
                            this.Vulcan_G = i;
                            if (Vulcan_u != 0) {
                                return;
                            }
                        }
                        this.Vulcan_p = i;
                    }
                    this.Vulcan_G = i2;
                } catch (IllegalArgumentException unused) {
                    throw a((IllegalArgumentException) Vulcan_u);
                }
            } catch (IllegalArgumentException unused2) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused3) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x003b  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00e1  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0101 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:78:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Number] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [ac.vulcan.anticheat.Vulcan_OG] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OG(java.lang.Number r6, java.lang.Number r7) {
        /*
            Method dump skipped, instruction units count: 273
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.<init>(java.lang.Number, java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Integer, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_v(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan_B;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan_B = new Integer(this.Vulcan_p);
                }
                return this.Vulcan_B;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_j(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_p;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_g(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_p;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_Q(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_p;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_W(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_p;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Integer, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_l(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_v;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_v = new Integer(this.Vulcan_G);
                }
                return this.Vulcan_v;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_E(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_G;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_G;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_X(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_G;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_U(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_G;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_p(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r14 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 24112156416177(0x15ee0c8498b1, double:1.19129881323836E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L24
            throw r0
        L28:
            r0 = r10
            r1 = r14
            int r1 = r1.intValue()
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.mo85Vulcan_W(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x004a A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    /* JADX INFO: renamed from: Vulcan_W */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean mo85Vulcan_W(java.lang.Object[] r5) {
        /*
            r4 = this;
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r4
            int r1 = r1.Vulcan_p     // Catch: java.lang.IllegalArgumentException -> L2b
            r2 = r9
            if (r2 != 0) goto L47
            if (r0 < r1) goto L4e
            goto L2f
        L2b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L38
            throw r0     // Catch: java.lang.IllegalArgumentException -> L38
        L2f:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L4b
            goto L3c
        L38:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0     // Catch: java.lang.IllegalArgumentException -> L43
        L3c:
            r1 = r4
            int r1 = r1.Vulcan_G     // Catch: java.lang.IllegalArgumentException -> L43
            goto L47
        L43:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L47:
            if (r0 > r1) goto L4e
            r0 = 1
        L4b:
            goto L4f
        L4e:
            r0 = 0
        L4f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.mo85Vulcan_W(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0035
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_O(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 232
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_I(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.Vulcan_I(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OG.a
            r1 = 35901822564464(0x20a70b617870, double:1.77378571521897E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_OG     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_OG r0 = (ac.vulcan.anticheat.Vulcan_OG) r0
            r10 = r0
            r0 = r5
            int r0 = r0.Vulcan_p     // Catch: java.lang.IllegalArgumentException -> L57
            r1 = r10
            int r1 = r1.Vulcan_p     // Catch: java.lang.IllegalArgumentException -> L57
            r2 = r9
            if (r2 != 0) goto L77
            if (r0 != r1) goto L7e
            goto L5b
        L57:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L67
            throw r0     // Catch: java.lang.IllegalArgumentException -> L67
        L5b:
            r0 = r5
            int r0 = r0.Vulcan_G     // Catch: java.lang.IllegalArgumentException -> L67 java.lang.IllegalArgumentException -> L73
            r1 = r9
            if (r1 != 0) goto L7b
            goto L6b
        L67:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L73
            throw r0     // Catch: java.lang.IllegalArgumentException -> L73
        L6b:
            r1 = r10
            int r1 = r1.Vulcan_G     // Catch: java.lang.IllegalArgumentException -> L73
            goto L77
        L73:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L77:
            if (r0 != r1) goto L7e
            r0 = 1
        L7b:
            goto L7f
        L7e:
            r0 = 0
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int hashCode() {
        long j = a ^ 60805552110413L;
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan__;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan__ = 17;
                    this.Vulcan__ = (37 * this.Vulcan__) + getClass().hashCode();
                    this.Vulcan__ = (37 * this.Vulcan__) + this.Vulcan_p;
                    this.Vulcan__ = (37 * this.Vulcan__) + this.Vulcan_G;
                }
                return this.Vulcan__;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0036: PHI (r0v10 ?? I:ac.vulcan.anticheat.Vulcan_P) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OG.toString():java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v7, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalArgumentException] */
    public int[] Vulcan_e(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        int iVulcan_Q = Vulcan_OA.Vulcan_Q();
        int[] iArr = new int[(this.Vulcan_G - this.Vulcan_p) + 1];
        int i = 0;
        loop0: while (i < iArr.length) {
            do {
                ?? r0 = iArr;
                int i2 = iVulcan_Q;
                if (jLongValue >= 0) {
                    if (i2 != 0) {
                        return r0;
                    }
                    i2 = i;
                }
                try {
                    r0[i2] = this.Vulcan_p + i;
                    i++;
                    r0 = iVulcan_Q;
                    if (r0 != 0) {
                    }
                } catch (IllegalArgumentException unused) {
                    throw a((IllegalArgumentException) r0);
                }
            } while (jLongValue < 0);
        }
        return iArr;
    }
}
