package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_km, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_km.class */
final class C0025Vulcan_km {
    private final Object Vulcan_x;
    private final int Vulcan_f;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(2723610340805633888L, -7337859886165034458L, null).a(119801381760283L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0025Vulcan_km(Object obj) {
        this.Vulcan_f = System.identityHashCode(obj);
        this.Vulcan_x = obj;
    }

    public int hashCode() {
        return this.Vulcan_f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [ac.vulcan.anticheat.Vulcan_km] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_km] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    public boolean equals(Object obj) {
        long j = a ^ 392423500440L;
        ?? Vulcan_F = Vulcan_fl.Vulcan_F();
        try {
            Vulcan_F = obj;
            ?? r0 = Vulcan_F;
            if (Vulcan_F != 0) {
                try {
                    Vulcan_F = Vulcan_F instanceof C0025Vulcan_km;
                    if (Vulcan_F == 0) {
                        return false;
                    }
                    r0 = obj;
                } catch (RuntimeException unused) {
                    throw a(Vulcan_F);
                }
            }
            ?? r02 = (C0025Vulcan_km) r0;
            try {
                r02 = this;
                ?? r03 = r02;
                if (Vulcan_F != 0) {
                    try {
                        r02 = r02.Vulcan_f;
                        if (r02 != r02.Vulcan_f) {
                            return false;
                        }
                        r03 = this.Vulcan_x;
                    } catch (RuntimeException unused2) {
                        throw a(r02);
                    }
                }
                try {
                    return r03 == r02.Vulcan_x;
                } catch (RuntimeException unused3) {
                    throw a(r03);
                }
            } catch (RuntimeException unused4) {
                throw a(r02);
            }
        } catch (RuntimeException unused5) {
            throw a(Vulcan_F);
        }
    }
}
