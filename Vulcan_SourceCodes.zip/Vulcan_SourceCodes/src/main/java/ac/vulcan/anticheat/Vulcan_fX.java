package ac.vulcan.anticheat;

import java.lang.reflect.Array;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fX.class */
public class Vulcan_fX {
    public static final Object[] Vulcan_c;
    public static final Class[] Vulcan_o;
    public static final String[] Vulcan_X;
    public static final long[] Vulcan_V;
    public static final Long[] Vulcan_h;
    public static final int[] Vulcan_P;
    public static final Integer[] Vulcan_C;
    public static final short[] Vulcan_Z;
    public static final Short[] Vulcan_t;
    public static final byte[] Vulcan_N;
    public static final Byte[] Vulcan_u;
    public static final double[] Vulcan_K;
    public static final Double[] Vulcan_Q;
    public static final float[] Vulcan_l;
    public static final Float[] Vulcan_a;
    public static final boolean[] Vulcan_A;
    public static final Boolean[] Vulcan_L;
    public static final char[] Vulcan_w;
    public static final Character[] Vulcan_D;
    public static final int Vulcan_B = -1;
    static Class Vulcan_m;
    private static String Vulcan_y;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(7691664112306421010L, -3860887883618867433L, null).a(120577230796271L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_e(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 37920429792936(0x227d09bf5ea8, double:1.87351816362246E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r14
            r2 = r13
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m254Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_e(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0040: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static boolean m256Vulcan_t(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 113845555575612(0x678abbe63b3c, double:5.62471779416203E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_k()
            r15 = r0
            r0 = r13
            r1 = r9
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L5e
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L5e
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5e
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L5e
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L5e
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L5e
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5e
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5e
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5e
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalArgumentException -> L5e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5e
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5e
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L5e
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5e
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5e
            int r0 = Vulcan_e(r0)     // Catch: java.lang.IllegalArgumentException -> L5e
            r1 = r15
            if (r1 != 0) goto L6a
            r1 = -1
            if (r0 == r1) goto L6d
            goto L62
        L5e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L66
            throw r0     // Catch: java.lang.IllegalArgumentException -> L66
        L62:
            r0 = 1
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6a:
            goto L6e
        L6d:
            r0 = 0
        L6e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m256Vulcan_t(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0058: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_B(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 131916496949634(0x77fa33f0d182, double:6.51754092625358E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r16
            r2 = r12
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_L(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_B(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static int m257Vulcan_h(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 16991467570429(0xf74226384fd, double:8.3949003989746E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r12
            r2 = r13
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m258Vulcan_X(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m257Vulcan_h(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static int m282Vulcan_q(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 204
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m282Vulcan_q(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public static int m283Vulcan_v(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 229
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m283Vulcan_v(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0054: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public static int m285Vulcan_g(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 15809433738461(0xe60ebae9cdd, double:7.810898090377E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r11
            r2 = r12
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_R(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m285Vulcan_g(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0058: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public static int m286Vulcan_S(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 95513976794656(0x56de94a86e20, double:4.71901746319176E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r13
            r2 = r14
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m287Vulcan_D(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m286Vulcan_S(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static long[] m333Vulcan_m(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 92842684740288(0x54709f3e72c0, double:4.58703809978456E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L64
            if (r0 != 0) goto L63
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L40:
            r0 = r13
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            long[] r0 = Vulcan_D(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r9
        L64:
            r1 = r15
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L73:
            r0 = r13
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            long[] r0 = Vulcan_D(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r12
            int r0 = r0.length
            r1 = r9
            int r1 = r1.length
            int r0 = r0 + r1
            long[] r0 = new long[r0]
        L9f:
            r16 = r0
            r0 = r12
            r1 = 0
            r2 = r16
            r3 = 0
            r4 = r12
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r9
            r1 = 0
            r2 = r16
            r3 = r12
            int r3 = r3.length
            r4 = r9
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m333Vulcan_m(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a8: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public static java.lang.Object[] m346Vulcan_L(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 111066234900357(0x65039f7a4f85, double:5.48740110772005E-310)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = Vulcan_k()
            r1 = 0
            r19 = r1
            r18 = r0
            r0 = r15
            r1 = r18
            if (r1 != 0) goto L5d
            if (r0 == 0) goto L5b
            goto L4e
        L4a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4e:
            r0 = r15
            java.lang.Class r0 = r0.getClass()
            java.lang.Class r0 = r0.getComponentType()
            r19 = r0
            goto L7f
        L5b:
            r0 = r14
        L5d:
            r1 = r18
            if (r1 != 0) goto L6e
            if (r0 == 0) goto L76
            goto L6c
        L68:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6c:
            r0 = r14
        L6e:
            java.lang.Class r0 = r0.getClass()
            r19 = r0
            goto L7f
        L76:
            r0 = 1
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r1 = r0
            r2 = 0
            r3 = 0
            r1[r2] = r3
            return r0
        L7f:
            r0 = r16
            r1 = r15
            r2 = r11
            r3 = r14
            r4 = r19
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m346Vulcan_L(java.lang.Object[]):java.lang.Object[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x008e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public static boolean[] m347Vulcan_R(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 43377816575983(0x2773af591fef, double:2.1431488961796E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r1 = r0; r2 = r0; 
            r2 = 8567052754469(0x7caac22de25, double:4.232686452093E-311)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r20
            r1 = r15
            r2 = r16
            r3 = r18
            r4 = r17
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 1
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 0
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            java.lang.Boolean r3 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r3)
            java.lang.Class r4 = java.lang.Boolean.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            boolean[] r0 = (boolean[]) r0
            boolean[] r0 = (boolean[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m347Vulcan_R(java.lang.Object[]):boolean[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static char[] m348Vulcan_t(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 78879866617739(0x47bda66dff8b, double:3.89718322443646E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r13
            r2 = r12
            java.lang.Character r3 = new java.lang.Character
            r4 = r3
            r5 = r11
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Character.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            char[] r0 = (char[]) r0
            char[] r0 = (char[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m348Vulcan_t(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static byte[] m349Vulcan_l(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 29929519236588(0x1b38825cc5ec, double:1.4787147251343E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r12
            r2 = r13
            java.lang.Byte r3 = new java.lang.Byte
            r4 = r3
            r5 = r11
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Byte.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            byte[] r0 = (byte[]) r0
            byte[] r0 = (byte[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m349Vulcan_l(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public static short[] m350Vulcan_C(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 78628084412443(0x4783070a701b, double:3.88474353064937E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r13
            r2 = r11
            java.lang.Short r3 = new java.lang.Short
            r4 = r3
            r5 = r12
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Short.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            short[] r0 = (short[]) r0
            short[] r0 = (short[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m350Vulcan_C(java.lang.Object[]):short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public static int[] m351Vulcan_Y(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 114740615236853(0x685b219cccf5, double:5.66893961712178E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r12
            r2 = r11
            java.lang.Integer r3 = new java.lang.Integer
            r4 = r3
            r5 = r13
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Integer.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            int[] r0 = (int[]) r0
            int[] r0 = (int[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m351Vulcan_Y(java.lang.Object[]):int[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static long[] m352Vulcan_q(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 118521970587979(0x6bcb8bf4794b, double:5.8557633944927E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r16
            r2 = r11
            java.lang.Long r3 = new java.lang.Long
            r4 = r3
            r5 = r14
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Long.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            long[] r0 = (long[]) r0
            long[] r0 = (long[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m352Vulcan_q(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static float[] m353Vulcan_U(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 116786088670408(0x6a37615474c8, double:5.7699994324218E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r12
            r2 = r11
            java.lang.Float r3 = new java.lang.Float
            r4 = r3
            r5 = r13
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Float.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            float[] r0 = (float[]) r0
            float[] r0 = (float[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m353Vulcan_U(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0069: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static double[] m354Vulcan_s(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 125320385242193(0x71fa6d0ba451, double:6.1916497071758E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r16
            r2 = r11
            java.lang.Double r3 = new java.lang.Double
            r4 = r3
            r5 = r14
            r4.<init>(r5)
            java.lang.Class r4 = java.lang.Double.TYPE
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m355Vulcan_X(r0)
            double[] r0 = (double[]) r0
            double[] r0 = (double[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m354Vulcan_s(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public static java.lang.Object[] m357Vulcan_n(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 114481911491894(0x681ee5aaed36, double:5.6561579538383E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 108058752304866(0x6247638bc6e2, double:5.3388117246303E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 106553315654809(0x60e8e0877c99, double:5.26443327155194E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r15
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_e(r0)
            r21 = r0
            r0 = r21
            r1 = -1
            if (r0 != r1) goto L89
            r0 = r14
            r1 = r17
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L85
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L85
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L85
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L85
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L85
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L85
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L85
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L85
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L85
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L85
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L85
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L85
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L85
            java.lang.Object[] r0 = m226Vulcan__(r0)     // Catch: java.lang.IllegalArgumentException -> L85
            return r0
        L85:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L85
            throw r0
        L89:
            r0 = r14
            r1 = r21
            r2 = r19
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object[] r0 = m356Vulcan_F(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m357Vulcan_n(java.lang.Object[]):java.lang.Object[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ae: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static byte[] m361Vulcan__(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 94981936391508(0x5662b4942554, double:4.69273117465226E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 116164672151277(0x69a6b204deed, double:5.73929737703573E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r1 = r0; r2 = r0; 
            r2 = 130400594893719(0x769941231b97, double:6.4426454134248E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            r1 = r18
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m270Vulcan_y(r0)
            r20 = r0
            r0 = r20
            r1 = -1
            if (r0 != r1) goto L93
            r0 = r12
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L8f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L8f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L8f
            byte[] r0 = Vulcan_U(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            return r0
        L8f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            throw r0
        L93:
            r0 = r16
            r1 = r12
            r2 = r20
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            byte[] r0 = m360Vulcan_g(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m361Vulcan__(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00b2: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static double[] m365Vulcan_U(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 57228539944938(0x340c8ecb5fea, double:2.82746555484474E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 16692627057976(0xf2e8e1b2d38, double:8.247253568186E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r1 = r0; r2 = r0; 
            r2 = 24979750249615(0x16b80d23e48f, double:1.2341636440029E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r16
            r1 = r21
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_m(r0)
            r23 = r0
            r0 = r23
            r1 = -1
            if (r0 != r1) goto L96
            r0 = r16
            r1 = r19
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L92
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L92
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L92
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L92
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L92
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L92
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L92
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L92
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L92
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L92
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L92
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L92
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L92
            double[] r0 = Vulcan_A(r0)     // Catch: java.lang.IllegalArgumentException -> L92
            return r0
        L92:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L92
            throw r0
        L96:
            r0 = r17
            r1 = r16
            r2 = r23
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            double[] r0 = m364Vulcan_K(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m365Vulcan_U(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ae: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public static long[] m371Vulcan_J(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 243
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m371Vulcan_J(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00b0: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static short[] m373Vulcan_y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 92201126424503(0x53db3f636fb7, double:4.55534090742125E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 115762942159002(0x6949290ba89a, double:5.719449278227E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r1 = r0; r2 = r0; 
            r2 = 123379002879666(0x703669a3aeb2, double:6.0957326740991E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            r1 = r16
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m262Vulcan_A(r0)
            r20 = r0
            r0 = r20
            r1 = -1
            if (r0 != r1) goto L94
            r0 = r13
            r1 = r18
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L90
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L90
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L90
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L90
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L90
            short[] r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            return r0
        L90:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0
        L94:
            r0 = r14
            r1 = r13
            r2 = r20
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            short[] r0 = m372Vulcan_e(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m373Vulcan_y(java.lang.Object[]):short[]");
    }

    public static void Vulcan_V(String str) {
        Vulcan_y = str;
    }

    public static String Vulcan_k() {
        return Vulcan_y;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008c, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008f, code lost:
    
        r11 = "Y\u0003\b\u00058[\u0013\u0018\u0018\u0014D \u0015\\\u001fJ\u001b^FFM8F\u0013\u0018J\n@7RG\u0011J\n@*F\u0013\r\u0002\u0007Ky\u0007".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0098, code lost:
    
        ac.vulcan.anticheat.Vulcan_fX.b = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b0, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bf, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e4, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e9, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ee, code lost:
    
        r7 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f3, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f8, code lost:
    
        r7 = 23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00fd, code lost:
    
        r7 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0102, code lost:
    
        r7 = 125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0104, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x010c, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0114, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0119, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x011d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x012c, code lost:
    
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_c = new java.lang.Object[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_o = new java.lang.Class[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_X = new java.lang.String[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_V = new long[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_h = new java.lang.Long[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_P = new int[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_C = new java.lang.Integer[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_Z = new short[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_t = new java.lang.Short[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_N = new byte[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_u = new java.lang.Byte[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_K = new double[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_Q = new java.lang.Double[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_l = new float[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_a = new java.lang.Float[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_A = new boolean[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_L = new java.lang.Boolean[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_w = new char[0];
        ac.vulcan.anticheat.Vulcan_fX.Vulcan_D = new java.lang.Character[0];
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x01a9, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a0, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b0, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00bf, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e4, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0104, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010c, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e9, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ee, code lost:
    
        r7 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f3, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f8, code lost:
    
        r7 = 23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fd, code lost:
    
        r7 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0102, code lost:
    
        r7 = 125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0114, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r1[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x011d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0051, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005d, code lost:
    
        r2 = "Y\u0003\b\u00058[\u0013\u0018\u0018\u0014D \u0015\\\u001fJ\u001b^FFM8F\u0013\u0018J\n@7RG\u0011J\n@*F\u0013\r\u0002\u0007Ky\u0007".length();
        r11 = 16;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006c, code lost:
    
        r10 = r10 + 1;
        "Y\u0003\b\u00058[\u0013\u0018\u0018\u0014D \u0015\\\u001fJ\u001b^FFM8F\u0013\u0018J\n@7RG\u0011J\n@*F\u0013\r\u0002\u0007Ky\u0007".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007c, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r1[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b3, B:28:0x0114], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r1v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0119 -> B:15:0x00b3). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0119 -> B:35:0x00b3). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 426
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m225clinit():void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_T(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 137357805112418(0x7ced1b2e4c62, double:6.7863772694203E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_fX.b
            r2 = 9
            r1 = r1[r2]
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_t(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_T(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: NullPointerException in pass: ModVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.setType(jadx.core.dex.instructions.args.ArgType)" because "result" is null
        	at jadx.core.dex.visitors.ModVisitor.removeCheckCast(ModVisitor.java:417)
        	at jadx.core.dex.visitors.ModVisitor.replaceStep(ModVisitor.java:152)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:96)
        */
    public static java.lang.String Vulcan_t(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 105861031623483(0x6047b12f7b3b, double:5.23022989584768E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            if (r0 != 0) goto L33
            r0 = r12
            return r0
        L2f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L2f
            throw r0
        L33:
            ac.vulcan.anticheat.Vulcan_F r0 = new ac.vulcan.anticheat.Vulcan_F
            r1 = r0
            r2 = r11
            ac.vulcan.anticheat.Vulcan_fV r3 = ac.vulcan.anticheat.Vulcan_fV.Vulcan_q
            r1.<init>(r2, r3)
            r1 = r11
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_F r0 = r0.m11Vulcan_K(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_t(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r0v4 ?? I:ac.vulcan.anticheat.Vulcan_fl) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static int Vulcan_P(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r0v4 ?? I:ac.vulcan.anticheat.Vulcan_fl) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r0v7 ?? I:ac.vulcan.anticheat.Vulcan_fR) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static boolean Vulcan__(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r0v7 ?? I:ac.vulcan.anticheat.Vulcan_fR) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Code restructure failed: missing block: B:23:0x0082, code lost:
    
        if (r0 != 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0114, code lost:
    
        if (r0 != 0) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0150, code lost:
    
        r13 = r13 + 1;
        r0 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:16:0x0053, B:32:0x009d], limit reached: 74 */
    /* JADX WARN: Path cross not found for [B:32:0x009d, B:16:0x0053], limit reached: 74 */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x00bc A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0160 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0155 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:76:? A[LOOP:0: B:10:0x003c->B:76:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v29, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.util.Map$Entry] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r14v0, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.StringBuffer] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.StringBuffer] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:59:0x015d -> B:13:0x0047). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.Map Vulcan_K(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 353
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_K(java.lang.Object[]):java.util.Map");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static java.lang.Object[] m226Vulcan__(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.Object r0 = r0.clone()
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            java.lang.Object[] r0 = (java.lang.Object[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m226Vulcan__(java.lang.Object[]):java.lang.Object[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static long[] Vulcan_D(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.Object r0 = r0.clone()
            long[] r0 = (long[]) r0
            long[] r0 = (long[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_D(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int[] Vulcan_g(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.Object r0 = r0.clone()
            int[] r0 = (int[]) r0
            int[] r0 = (int[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_g(java.lang.Object[]):int[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static short[] Vulcan_Q(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.Object r0 = r0.clone()
            short[] r0 = (short[]) r0
            short[] r0 = (short[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_Q(java.lang.Object[]):short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static char[] Vulcan_w(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
            java.lang.Object r0 = r0.clone()
            char[] r0 = (char[]) r0
            char[] r0 = (char[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_w(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static byte[] Vulcan_U(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
            java.lang.Object r0 = r0.clone()
            byte[] r0 = (byte[]) r0
            byte[] r0 = (byte[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_U(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static double[] Vulcan_A(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
            java.lang.Object r0 = r0.clone()
            double[] r0 = (double[]) r0
            double[] r0 = (double[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_A(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static float[] Vulcan_N(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
            java.lang.Object r0 = r0.clone()
            float[] r0 = (float[]) r0
            float[] r0 = (float[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_N(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static boolean[] m227Vulcan_K(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
            java.lang.Object r0 = r0.clone()
            boolean[] r0 = (boolean[]) r0
            boolean[] r0 = (boolean[]) r0
        L3e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m227Vulcan_K(java.lang.Object[]):boolean[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public static java.lang.Object[] m228Vulcan_T(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m228Vulcan_T(java.lang.Object[]):java.lang.Object[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String[] Vulcan_h(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_X     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_h(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static long[] Vulcan_y(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            long[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_y(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int[] Vulcan_X(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            int[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_P     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_X(java.lang.Object[]):int[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static short[] m229Vulcan_D(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            short[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_Z     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m229Vulcan_D(java.lang.Object[]):short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static char[] Vulcan_M(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            char[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_w     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_M(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static byte[] m230Vulcan_M(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            byte[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_N     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m230Vulcan_M(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static double[] m231Vulcan_t(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            double[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_K     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m231Vulcan_t(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static float[] Vulcan_b(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            float[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_l     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_b(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean[] Vulcan_z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            boolean[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_z(java.lang.Object[]):boolean[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static java.lang.Long[] m232Vulcan_t(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long[] r1 = (java.lang.Long[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Long[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_h     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m232Vulcan_t(java.lang.Object[]):java.lang.Long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Integer[] Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer[] r1 = (java.lang.Integer[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Integer[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_C     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_v(java.lang.Object[]):java.lang.Integer[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static java.lang.Short[] m233Vulcan_X(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Short[] r1 = (java.lang.Short[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Short[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_t     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m233Vulcan_X(java.lang.Object[]):java.lang.Short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public static java.lang.Character[] m234Vulcan_T(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Character[] r1 = (java.lang.Character[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Character[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_D     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m234Vulcan_T(java.lang.Object[]):java.lang.Character[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public static java.lang.Byte[] m235Vulcan_z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Byte[] r1 = (java.lang.Byte[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Byte[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_u     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r8
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m235Vulcan_z(java.lang.Object[]):java.lang.Byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Double[] Vulcan_E(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double[] r1 = (java.lang.Double[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Double[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_Q     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_E(java.lang.Object[]):java.lang.Double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Float[] Vulcan_o(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float[] r1 = (java.lang.Float[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Float[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_o(java.lang.Object[]):java.lang.Float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public static java.lang.Boolean[] m236Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean[] r1 = (java.lang.Boolean[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L46
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L37
            throw r0     // Catch: java.lang.IllegalArgumentException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L52
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L3b:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L42 java.lang.IllegalArgumentException -> L4c
            if (r0 != 0) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L46:
            java.lang.Boolean[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_L     // Catch: java.lang.IllegalArgumentException -> L4c
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            r0 = r6
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m236Vulcan_v(java.lang.Object[]):java.lang.Boolean[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static Object[] Vulcan_s(Object[] objArr) {
        Object[] objArr2 = (Object[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        String strVulcan_k = Vulcan_k();
        if (objArr2 == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (jLongValue >= 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (jLongValue >= 0) {
            try {
                int length = objArr2.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = objArr2.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        Class<?> componentType = objArr2.getClass().getComponentType();
        Object[] objArr3 = r13 == true ? 1 : 0;
        if (objArr3 <= 0) {
            try {
                objArr3 = (Object[]) Array.newInstance(componentType, 0);
                return objArr3;
            } catch (IllegalArgumentException unused2) {
                throw a(objArr3);
            }
        }
        Object[] objArr4 = (Object[]) Array.newInstance(componentType, r13 == true ? 1 : 0);
        System.arraycopy(objArr2, iIntValue, objArr4, 0, r13 == true ? 1 : 0);
        return objArr4;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static long[] m237Vulcan_M(Object[] objArr) {
        long[] jArr = (long[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        String strVulcan_k = Vulcan_k();
        if (jArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (jLongValue > 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (jLongValue > 0) {
            try {
                int length = jArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = jArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_V;
                }
                i2 = r13 == true ? 1 : 0;
            }
            long[] jArr2 = new long[i2];
            System.arraycopy(jArr, iIntValue, jArr2, 0, r13 == true ? 1 : 0);
            return jArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static int[] m238Vulcan_s(Object[] objArr) {
        int[] iArr = (int[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        String strVulcan_k = Vulcan_k();
        if (iArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (jLongValue >= 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (jLongValue > 0) {
            try {
                int length = iArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = iArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_P;
                }
                i2 = r13 == true ? 1 : 0;
            }
            int[] iArr2 = new int[i2];
            System.arraycopy(iArr, iIntValue, iArr2, 0, r13 == true ? 1 : 0);
            return iArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static short[] Vulcan_Y(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        short[] sArr = (short[]) objArr[1];
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (sArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j > 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j > 0) {
            try {
                int length = sArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = sArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_Z;
                }
                i2 = r13 == true ? 1 : 0;
            }
            short[] sArr2 = new short[i2];
            System.arraycopy(sArr, iIntValue, sArr2, 0, r13 == true ? 1 : 0);
            return sArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static char[] m239Vulcan_K(Object[] objArr) {
        char[] cArr = (char[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (cArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j >= 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j >= 0) {
            try {
                int length = cArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = cArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_w;
                }
                i2 = r13 == true ? 1 : 0;
            }
            char[] cArr2 = new char[i2];
            System.arraycopy(cArr, iIntValue, cArr2, 0, r13 == true ? 1 : 0);
            return cArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static byte[] m240Vulcan_o(Object[] objArr) {
        byte[] bArr = (byte[]) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (bArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j > 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j >= 0) {
            try {
                int length = bArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = bArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_N;
                }
                i2 = r13 == true ? 1 : 0;
            }
            byte[] bArr2 = new byte[i2];
            System.arraycopy(bArr, iIntValue, bArr2, 0, r13 == true ? 1 : 0);
            return bArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static double[] Vulcan_u(Object[] objArr) {
        double[] dArr = (double[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (dArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j >= 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j >= 0) {
            try {
                int length = dArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = dArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_K;
                }
                i2 = r13 == true ? 1 : 0;
            }
            double[] dArr2 = new double[i2];
            System.arraycopy(dArr, iIntValue, dArr2, 0, r13 == true ? 1 : 0);
            return dArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public static float[] m241Vulcan_g(Object[] objArr) {
        float[] fArr = (float[]) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (fArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j > 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j > 0) {
            try {
                int length = fArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = fArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_l;
                }
                i2 = r13 == true ? 1 : 0;
            }
            float[] fArr2 = new float[i2];
            System.arraycopy(fArr, iIntValue, fArr2, 0, r13 == true ? 1 : 0);
            return fArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static boolean[] m242Vulcan_o(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean[] zArr = (boolean[]) objArr[1];
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (zArr == null) {
            return null;
        }
        int i = iIntValue;
        ?? r0 = i;
        if (j >= 0) {
            r0 = i;
            if (strVulcan_k == null) {
                if (i < 0) {
                    iIntValue = 0;
                }
                r0 = iIntValue2;
            }
        }
        ?? r02 = r0;
        if (j >= 0) {
            try {
                int length = zArr.length;
                ?? r03 = r0;
                if (strVulcan_k == null) {
                    if (r0 > length) {
                        iIntValue2 = zArr.length;
                    }
                    r03 = iIntValue2;
                    length = iIntValue;
                }
                r02 = r03 - length;
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        ?? r13 = r02;
        try {
            int i2 = r13 == true ? 1 : 0;
            if (strVulcan_k == null) {
                if (i2 <= 0) {
                    return Vulcan_A;
                }
                i2 = r13 == true ? 1 : 0;
            }
            boolean[] zArr2 = new boolean[i2];
            System.arraycopy(zArr, iIntValue, zArr2, 0, r13 == true ? 1 : 0);
            return zArr2;
        } catch (IllegalArgumentException unused2) {
            throw a(r02);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static boolean m243Vulcan_N(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m243Vulcan_N(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_S(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_S(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_J(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_J(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_k(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_k(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_O(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static boolean m244Vulcan_u(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m244Vulcan_u(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static boolean m245Vulcan_h(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 249
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m245Vulcan_h(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_l(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_l(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_r(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 249
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_r(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public static int m246Vulcan_b(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = java.lang.reflect.Array.getLength(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m246Vulcan_b(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x003b  */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Object] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_j(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L36
            if (r0 == 0) goto L45
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L35:
            r0 = r7
        L36:
            r1 = r10
            if (r1 != 0) goto L58
            if (r0 != 0) goto L57
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L53
            throw r0     // Catch: java.lang.IllegalArgumentException -> L53
        L45:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L53
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fX.b     // Catch: java.lang.IllegalArgumentException -> L53
            r3 = 7
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L53
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L53
            throw r0     // Catch: java.lang.IllegalArgumentException -> L53
        L53:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L53
            throw r0
        L57:
            r0 = r6
        L58:
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getName()
            r1 = r7
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            boolean r0 = r0.equals(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_j(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static void Vulcan_I(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object[] objArr2 = (Object[]) objArr[1];
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (objArr2 == null) {
            return;
        }
        int i = 0;
        int length = objArr2.length - 1;
        while (length > i) {
            Object obj = objArr2[length];
            objArr2[length] = objArr2[i];
            objArr2[i] = obj;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static void m247Vulcan__(Object[] objArr) {
        long[] jArr = (long[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_k();
        if (jArr == null) {
            return;
        }
        int i = 0;
        int length = jArr.length - 1;
        while (length > i) {
            long j = jArr[length];
            jArr[length] = jArr[i];
            jArr[i] = j;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static void m248Vulcan_l(Object[] objArr) {
        int[] iArr = (int[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_k();
        if (iArr == null) {
            return;
        }
        int i = 0;
        int length = iArr.length - 1;
        while (length > i) {
            int i2 = iArr[length];
            iArr[length] = iArr[i];
            iArr[i] = i2;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static void m249Vulcan_X(Object[] objArr) {
        short[] sArr = (short[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_k();
        if (sArr == null) {
            return;
        }
        int i = 0;
        int length = sArr.length - 1;
        while (length > i) {
            short s = sArr[length];
            sArr[length] = sArr[i];
            sArr[i] = s;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static void m250Vulcan_t(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        char[] cArr = (char[]) objArr[1];
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (cArr == null) {
            return;
        }
        int i = 0;
        int length = cArr.length - 1;
        while (length > i) {
            char c = cArr[length];
            cArr[length] = cArr[i];
            cArr[i] = c;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public static void m251Vulcan_k(Object[] objArr) {
        byte[] bArr = (byte[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_k();
        if (bArr == null) {
            return;
        }
        int i = 0;
        int length = bArr.length - 1;
        while (length > i) {
            byte b2 = bArr[length];
            bArr[length] = bArr[i];
            bArr[i] = b2;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static void Vulcan_q(Object[] objArr) {
        double[] dArr = (double[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_k();
        if (dArr == null) {
            return;
        }
        int i = 0;
        int length = dArr.length - 1;
        while (length > i) {
            double d = dArr[length];
            dArr[length] = dArr[i];
            dArr[i] = d;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public static void m252Vulcan_g(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        float[] fArr = (float[]) objArr[1];
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (fArr == null) {
            return;
        }
        int i = 0;
        int length = fArr.length - 1;
        while (length > i) {
            float f = fArr[length];
            fArr[length] = fArr[i];
            fArr[i] = f;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public static void m253Vulcan_O(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean[] zArr = (boolean[]) objArr[1];
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_k();
        if (zArr == null) {
            return;
        }
        int i = 0;
        int length = zArr.length - 1;
        while (length > i) {
            boolean z = zArr[length];
            zArr[length] = zArr[i];
            zArr[i] = z;
            length--;
            i++;
            if (strVulcan_k != null) {
                return;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:39:0x008d  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v31, types: [int] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v21, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.Object, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Object] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x0092 -> B:23:0x0060). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int m254Vulcan_z(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m254Vulcan_z(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_p(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 30672142029872(0x1be56a215430, double:1.5154051661323E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r15
            r2 = r11
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m255Vulcan_l(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_p(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static int m255Vulcan_l(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 291
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m255Vulcan_l(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x005c, code lost:
    
        if (r0 < r1.length) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x005f, code lost:
    
        r0 = (r1 > r1[r15] ? 1 : (r1 == r1[r15] ? 0 : -1));
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x006b, code lost:
    
        if (r0 <= 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x006e, code lost:
    
        if (r1 != null) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0071, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0073, code lost:
    
        if (r1 != null) goto L45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0079, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x007c, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007d, code lost:
    
        if (r0 != 0) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0086, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0089, code lost:
    
        return r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x008a, code lost:
    
        r15 = r15 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008f, code lost:
    
        if (r0 == null) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0092, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0095, code lost:
    
        if (r0 <= 0) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0098, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:40:0x005f, B:36:0x0092], limit reached: 44 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x008f -> B:36:0x0092). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int Vulcan_L(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r14 = r0
            r0 = r12
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r13
            r1 = r14
            if (r1 != 0) goto L55
            if (r0 >= 0) goto L53
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            r0 = 0
            r13 = r0
        L53:
            r0 = r13
        L55:
            r15 = r0
        L57:
            r0 = r15
            r1 = r12
            int r1 = r1.length
            if (r0 >= r1) goto L92
        L5f:
            r0 = r10
            r1 = r12
            r2 = r15
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L79
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L73
            if (r1 != 0) goto L99
            r1 = r14
        L73:
            if (r1 != 0) goto L89
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L83
            throw r0     // Catch: java.lang.IllegalArgumentException -> L83
        L7d:
            if (r0 != 0) goto L8a
            goto L87
        L83:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L87:
            r0 = r15
        L89:
            return r0
        L8a:
            int r15 = r15 + 1
            r0 = r14
            if (r0 == 0) goto L57
        L92:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5f
            r0 = -1
        L99:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_L(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static int m258Vulcan_X(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = Vulcan_k()
            r14 = r0
            r0 = r10
            if (r0 != 0) goto L40
            r0 = -1
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0
        L40:
            r0 = r13
            r1 = r14
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L62
            if (r1 != 0) goto L60
            if (r0 >= 0) goto L5e
            goto L58
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5a
        L58:
            r0 = -1
            return r0
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5a
            throw r0
        L5e:
            r0 = r13
        L60:
            r1 = r14
        L62:
            if (r1 != 0) goto L79
            r1 = r10
            int r1 = r1.length     // Catch: java.lang.IllegalArgumentException -> L6d
            if (r0 < r1) goto L77
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L71:
            r0 = r10
            int r0 = r0.length
            r1 = 1
            int r0 = r0 - r1
            r13 = r0
        L77:
            r0 = r13
        L79:
            r15 = r0
        L7b:
            r0 = r15
            if (r0 < 0) goto Lb3
        L80:
            r0 = r8
            r1 = r10
            r2 = r15
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L9a
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L94
            if (r1 != 0) goto Lbb
            r1 = r14
        L94:
            if (r1 != 0) goto Laa
            goto L9e
        L9a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La4
            throw r0     // Catch: java.lang.IllegalArgumentException -> La4
        L9e:
            if (r0 != 0) goto Lab
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r0 = r15
        Laa:
            return r0
        Lab:
            int r15 = r15 + (-1)
            r0 = r14
            if (r0 == 0) goto L7b
        Lb3:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L80
            r0 = -1
        Lbb:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m258Vulcan_X(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006f]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006f]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static boolean Vulcan_c(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 1923158575318(0x1bfc52f08d6, double:9.501665835696E-312)
            long r1 = r1 ^ r2
            r17 = r1
            java.lang.String r0 = Vulcan_k()
            r19 = r0
            r0 = r12
            r1 = r13
            r2 = r17
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6f
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6f
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6f
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6f
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6f
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L6f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6f
            int r0 = Vulcan_B(r0)     // Catch: java.lang.IllegalArgumentException -> L6f
            r1 = r19
            if (r1 != 0) goto L7b
            r1 = -1
            if (r0 == r1) goto L7e
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L77
            throw r0     // Catch: java.lang.IllegalArgumentException -> L77
        L73:
            r0 = 1
            goto L7b
        L77:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7b:
            goto L7f
        L7e:
            r0 = 0
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_c(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_H(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 133082535994523(0x7909b148a49b, double:6.5751509096325E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r15
            r2 = r11
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m259Vulcan_O(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_H(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:13:0x004b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public static int m259Vulcan_O(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r11
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r10
            r1 = r13
            if (r1 != 0) goto L52
            if (r0 >= 0) goto L51
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            r0 = 0
            r10 = r0
        L51:
            r0 = r10
        L52:
            r14 = r0
        L54:
            r0 = r14
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L96
        L5c:
            r0 = r12
            r1 = r13
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L6b
            if (r1 != 0) goto L9d
            r1 = r13
        L6b:
            if (r1 != 0) goto L8d
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L80
            throw r0     // Catch: java.lang.IllegalArgumentException -> L80
        L75:
            r1 = r11
            r2 = r14
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L80 java.lang.IllegalArgumentException -> L89
            if (r0 != r1) goto L8e
            goto L84
        L80:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L89
            throw r0     // Catch: java.lang.IllegalArgumentException -> L89
        L84:
            r0 = r14
            goto L8d
        L89:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8d:
            return r0
        L8e:
            int r14 = r14 + 1
            r0 = r13
            if (r0 == 0) goto L54
        L96:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5c
            r0 = -1
        L9d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m259Vulcan_O(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static int m260Vulcan_u(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 26379140100686(0x17fddf46724e, double:1.3033026890582E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r11
            r2 = r15
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_d(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m260Vulcan_u(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_d(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r12
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r11
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L60
            if (r1 != 0) goto L5e
            if (r0 >= 0) goto L5c
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L58
            throw r0     // Catch: java.lang.IllegalArgumentException -> L58
        L56:
            r0 = -1
            return r0
        L58:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L58
            throw r0
        L5c:
            r0 = r11
        L5e:
            r1 = r13
        L60:
            if (r1 != 0) goto L79
            r1 = r12
            int r1 = r1.length     // Catch: java.lang.IllegalArgumentException -> L6c
            if (r0 < r1) goto L77
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L70:
            r0 = r12
            int r0 = r0.length
            r1 = 1
            int r0 = r0 - r1
            r11 = r0
        L77:
            r0 = r11
        L79:
            r14 = r0
        L7b:
            r0 = r14
            if (r0 < 0) goto Lb9
        L80:
            r0 = r8
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8e
            if (r1 != 0) goto Lc0
            r1 = r13
        L8e:
            if (r1 != 0) goto Lb0
            goto L98
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La3
            throw r0     // Catch: java.lang.IllegalArgumentException -> La3
        L98:
            r1 = r12
            r2 = r14
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> La3 java.lang.IllegalArgumentException -> Lac
            if (r0 != r1) goto Lb1
            goto La7
        La3:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> Lac
            throw r0     // Catch: java.lang.IllegalArgumentException -> Lac
        La7:
            r0 = r14
            goto Lb0
        Lac:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb0:
            return r0
        Lb1:
            int r14 = r14 + (-1)
            r0 = r13
            if (r0 == 0) goto L7b
        Lb9:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L80
            r0 = -1
        Lc0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_d(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static boolean m261Vulcan_X(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 1635799440200(0x17cdd3e9b48, double:8.08192306889E-312)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = Vulcan_k()
            r17 = r0
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6b
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6b
            int r0 = Vulcan_H(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            r1 = r17
            if (r1 != 0) goto L77
            r1 = -1
            if (r0 == r1) goto L7a
            goto L6f
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L73
            throw r0     // Catch: java.lang.IllegalArgumentException -> L73
        L6f:
            r0 = 1
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            goto L7b
        L7a:
            r0 = 0
        L7b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m261Vulcan_X(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005d: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005d: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static int m262Vulcan_A(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 41620683829892(0x25da92133284, double:2.056335003677E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            r1 = r15
            r2 = r12
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m263Vulcan_t(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m262Vulcan_A(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x005c, code lost:
    
        if (r14 < r1.length) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x005f, code lost:
    
        r0 = r1;
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0065, code lost:
    
        if (r0 < 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0068, code lost:
    
        if (r1 != null) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x006b, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x006d, code lost:
    
        if (r1 != null) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x007c, code lost:
    
        if (r0 != r1[r14]) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0082, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0085, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008e, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x008f, code lost:
    
        return r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0090, code lost:
    
        r14 = r14 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0095, code lost:
    
        if (r0 == null) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x009b, code lost:
    
        if (r0 < 0) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x009e, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:20:0x005f, B:39:0x0098], limit reached: 44 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x009b -> B:20:0x005f). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int m263Vulcan_t(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r12
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r11
            r1 = r13
            if (r1 != 0) goto L55
            if (r0 >= 0) goto L53
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            r0 = 0
            r11 = r0
        L53:
            r0 = r11
        L55:
            r14 = r0
        L57:
            r0 = r14
            r1 = r12
            int r1 = r1.length
            if (r0 >= r1) goto L98
        L5f:
            r0 = r8
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L6d
            if (r1 != 0) goto L9f
            r1 = r13
        L6d:
            if (r1 != 0) goto L8f
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L82
            throw r0     // Catch: java.lang.IllegalArgumentException -> L82
        L77:
            r1 = r12
            r2 = r14
            short r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L82 java.lang.IllegalArgumentException -> L8b
            if (r0 != r1) goto L90
            goto L86
        L82:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L86:
            r0 = r14
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8f:
            return r0
        L90:
            int r14 = r14 + 1
            r0 = r13
            if (r0 == 0) goto L57
        L98:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5f
            r0 = -1
        L9f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m263Vulcan_t(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_a(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 21396416015936(0x1375bdc6ae40, double:1.05712340976014E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r11
            r2 = r15
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_n(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_a(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_n(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r9
            if (r0 != 0) goto L3d
            r0 = -1
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r8
            r1 = r13
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L5c
            if (r1 != 0) goto L5a
            if (r0 >= 0) goto L59
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L55
            throw r0     // Catch: java.lang.IllegalArgumentException -> L55
        L53:
            r0 = -1
            return r0
        L55:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L55
            throw r0
        L59:
            r0 = r8
        L5a:
            r1 = r13
        L5c:
            if (r1 != 0) goto L71
            r1 = r9
            int r1 = r1.length     // Catch: java.lang.IllegalArgumentException -> L67
            if (r0 < r1) goto L70
            goto L6b
        L67:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6b:
            r0 = r9
            int r0 = r0.length
            r1 = 1
            int r0 = r0 - r1
            r8 = r0
        L70:
            r0 = r8
        L71:
            r14 = r0
        L73:
            r0 = r14
            if (r0 < 0) goto Lb1
        L78:
            r0 = r12
            r1 = r13
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L87
            if (r1 != 0) goto Lb8
            r1 = r13
        L87:
            if (r1 != 0) goto La8
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L9b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L9b
        L91:
            r1 = r9
            r2 = r14
            short r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L9b java.lang.IllegalArgumentException -> La4
            if (r0 != r1) goto La9
            goto L9f
        L9b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La4
            throw r0     // Catch: java.lang.IllegalArgumentException -> La4
        L9f:
            r0 = r14
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            return r0
        La9:
            int r14 = r14 + (-1)
            r0 = r13
            if (r0 == 0) goto L73
        Lb1:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L78
            r0 = -1
        Lb8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_n(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0069]
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0069]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static boolean m264Vulcan_M(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 105641058332552(0x601479c16f88, double:5.2193617712425E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r11
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L69
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L69
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L69
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L69
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.IllegalArgumentException -> L69
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L69
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L69
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L69
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L69
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L69
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L69
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L69
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L69
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L69
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L69
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L69
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L69
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L69
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L69
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L69
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L69
            int r0 = m262Vulcan_A(r0)     // Catch: java.lang.IllegalArgumentException -> L69
            r1 = r16
            if (r1 != 0) goto L75
            r1 = -1
            if (r0 == r1) goto L78
            goto L6d
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L71
            throw r0     // Catch: java.lang.IllegalArgumentException -> L71
        L6d:
            r0 = 1
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L75:
            goto L79
        L78:
            r0 = 0
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m264Vulcan_M(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public static int m265Vulcan_I(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 82049379154833(0x4a9f9c193b91, double:4.0537779503006E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r13
            r2 = r15
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m266Vulcan__(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m265Vulcan_I(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:13:0x004b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static int m266Vulcan__(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r12
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r8
            r1 = r13
            if (r1 != 0) goto L52
            if (r0 >= 0) goto L51
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            r0 = 0
            r8 = r0
        L51:
            r0 = r8
        L52:
            r14 = r0
        L54:
            r0 = r14
            r1 = r12
            int r1 = r1.length
            if (r0 >= r1) goto L96
        L5c:
            r0 = r11
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L6b
            if (r1 != 0) goto L9d
            r1 = r13
        L6b:
            if (r1 != 0) goto L8d
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L80
            throw r0     // Catch: java.lang.IllegalArgumentException -> L80
        L75:
            r1 = r12
            r2 = r14
            char r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L80 java.lang.IllegalArgumentException -> L89
            if (r0 != r1) goto L8e
            goto L84
        L80:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L89
            throw r0     // Catch: java.lang.IllegalArgumentException -> L89
        L84:
            r0 = r14
            goto L8d
        L89:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8d:
            return r0
        L8e:
            int r14 = r14 + 1
            r0 = r13
            if (r0 == 0) goto L54
        L96:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5c
            r0 = -1
        L9d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m266Vulcan__(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static int m267Vulcan_K(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 46330050756673(0x2a230e37c041, double:2.28900864489534E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r15
            r2 = r11
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m268Vulcan_T(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m267Vulcan_K(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public static int m268Vulcan_T(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r8
            if (r0 != 0) goto L3e
            r0 = -1
            return r0
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3a
            throw r0
        L3e:
            r0 = r12
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L5f
            if (r1 != 0) goto L5d
            if (r0 >= 0) goto L5b
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L57
            throw r0     // Catch: java.lang.IllegalArgumentException -> L57
        L55:
            r0 = -1
            return r0
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L57
            throw r0
        L5b:
            r0 = r12
        L5d:
            r1 = r13
        L5f:
            if (r1 != 0) goto L76
            r1 = r8
            int r1 = r1.length     // Catch: java.lang.IllegalArgumentException -> L6a
            if (r0 < r1) goto L74
            goto L6e
        L6a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6e:
            r0 = r8
            int r0 = r0.length
            r1 = 1
            int r0 = r0 - r1
            r12 = r0
        L74:
            r0 = r12
        L76:
            r14 = r0
        L78:
            r0 = r14
            if (r0 < 0) goto Lb6
        L7d:
            r0 = r11
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8c
            if (r1 != 0) goto Lbd
            r1 = r13
        L8c:
            if (r1 != 0) goto Lad
            goto L96
        L92:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La0
            throw r0     // Catch: java.lang.IllegalArgumentException -> La0
        L96:
            r1 = r8
            r2 = r14
            char r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> La0 java.lang.IllegalArgumentException -> La9
            if (r0 != r1) goto Lae
            goto La4
        La0:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La9
            throw r0     // Catch: java.lang.IllegalArgumentException -> La9
        La4:
            r0 = r14
            goto Lad
        La9:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lad:
            return r0
        Lae:
            int r14 = r14 + (-1)
            r0 = r13
            if (r0 == 0) goto L78
        Lb6:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7d
            r0 = -1
        Lbd:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m268Vulcan_T(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static boolean m269Vulcan_q(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 139527110508115(0x7ee62fdbbe53, double:6.8935551965555E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r11
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6b
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6b
            int r0 = m265Vulcan_I(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            r1 = r17
            if (r1 != 0) goto L77
            r1 = -1
            if (r0 == r1) goto L7a
            goto L6f
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L73
            throw r0     // Catch: java.lang.IllegalArgumentException -> L73
        L6f:
            r0 = 1
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            goto L7b
        L7a:
            r0 = 0
        L7b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m269Vulcan_q(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static int m270Vulcan_y(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 1617370728184(0x17892cec6f8, double:7.99087313385E-312)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r13
            r2 = 0
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m271Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m270Vulcan_y(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:13:0x004b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public static int m271Vulcan_Y(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r11
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r10
            r1 = r13
            if (r1 != 0) goto L52
            if (r0 >= 0) goto L51
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            r0 = 0
            r10 = r0
        L51:
            r0 = r10
        L52:
            r14 = r0
        L54:
            r0 = r14
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L96
        L5c:
            r0 = r12
            r1 = r13
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L6b
            if (r1 != 0) goto L9d
            r1 = r13
        L6b:
            if (r1 != 0) goto L8d
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L80
            throw r0     // Catch: java.lang.IllegalArgumentException -> L80
        L75:
            r1 = r11
            r2 = r14
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> L80 java.lang.IllegalArgumentException -> L89
            if (r0 != r1) goto L8e
            goto L84
        L80:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L89
            throw r0     // Catch: java.lang.IllegalArgumentException -> L89
        L84:
            r0 = r14
            goto L8d
        L89:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8d:
            return r0
        L8e:
            int r14 = r14 + 1
            r0 = r13
            if (r0 == 0) goto L54
        L96:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5c
            r0 = -1
        L9d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m271Vulcan_Y(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public static int m272Vulcan_E(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 76555978542119(0x45a093e80c27, double:3.78236789814206E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r15
            r2 = r11
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m273Vulcan_N(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m272Vulcan_E(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static int m273Vulcan_N(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r12
            if (r0 != 0) goto L3f
            r0 = -1
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r11
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L60
            if (r1 != 0) goto L5e
            if (r0 >= 0) goto L5c
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L58
            throw r0     // Catch: java.lang.IllegalArgumentException -> L58
        L56:
            r0 = -1
            return r0
        L58:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L58
            throw r0
        L5c:
            r0 = r11
        L5e:
            r1 = r13
        L60:
            if (r1 != 0) goto L79
            r1 = r12
            int r1 = r1.length     // Catch: java.lang.IllegalArgumentException -> L6c
            if (r0 < r1) goto L77
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L70:
            r0 = r12
            int r0 = r0.length
            r1 = 1
            int r0 = r0 - r1
            r11 = r0
        L77:
            r0 = r11
        L79:
            r14 = r0
        L7b:
            r0 = r14
            if (r0 < 0) goto Lb9
        L80:
            r0 = r8
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L8e
            if (r1 != 0) goto Lc0
            r1 = r13
        L8e:
            if (r1 != 0) goto Lb0
            goto L98
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La3
            throw r0     // Catch: java.lang.IllegalArgumentException -> La3
        L98:
            r1 = r12
            r2 = r14
            r1 = r1[r2]     // Catch: java.lang.IllegalArgumentException -> La3 java.lang.IllegalArgumentException -> Lac
            if (r0 != r1) goto Lb1
            goto La7
        La3:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> Lac
            throw r0     // Catch: java.lang.IllegalArgumentException -> Lac
        La7:
            r0 = r14
            goto Lb0
        Lac:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb0:
            return r0
        Lb1:
            int r14 = r14 + (-1)
            r0 = r13
            if (r0 == 0) goto L7b
        Lb9:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L80
            r0 = -1
        Lc0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m273Vulcan_N(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0085]
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0085]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static boolean m274Vulcan_o(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r0 = r11
            r1 = 16
            long r0 = r0 << r1
            r1 = r14
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_fX.a
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 68799550563663(0x3e92a4c5a54f, double:3.39914943828237E-310)
            long r1 = r1 ^ r2
            r17 = r1
            java.lang.String r0 = Vulcan_k()
            r19 = r0
            r0 = r13
            r1 = r17
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L85
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L85
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L85
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.IllegalArgumentException -> L85
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L85
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L85
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L85
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L85
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L85
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L85
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L85
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L85
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L85
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L85
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L85
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L85
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L85
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L85
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L85
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L85
            int r0 = m270Vulcan_y(r0)     // Catch: java.lang.IllegalArgumentException -> L85
            r1 = r19
            if (r1 != 0) goto L91
            r1 = -1
            if (r0 == r1) goto L94
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8d
        L89:
            r0 = 1
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L91:
            goto L95
        L94:
            r0 = 0
        L95:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m274Vulcan_o(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_m(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 40866883791779(0x252b10176ba3, double:2.01909233341045E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r17
            r2 = r14
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_G(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_m(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r6v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static int m275Vulcan_U(java.lang.Object[] r14) {
        /*
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r18 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r20 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r20
            long r0 = r0 ^ r1
            r20 = r0
            r0 = r20
            r1 = r0; r1 = r0; 
            r2 = 80280112093960(0x4903ab905b08, double:3.966364542991E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r15
            r1 = r16
            r2 = 0
            r3 = r22
            r4 = r18
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Double r7 = new java.lang.Double
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Double r4 = new java.lang.Double
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m276Vulcan_M(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m275Vulcan_U(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r19v0 */
    /* JADX WARN: Type inference failed for: r19v1 */
    /* JADX WARN: Type inference failed for: r19v2, types: [int] */
    /* JADX WARN: Type inference failed for: r19v3, types: [int] */
    /* JADX WARN: Type inference failed for: r19v4 */
    /* JADX WARN: Type inference failed for: r19v5 */
    /* JADX WARN: Type inference failed for: r19v6 */
    /* JADX WARN: Type inference failed for: r19v7 */
    /* JADX WARN: Type inference failed for: r19v8 */
    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r1v29, types: [double] */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Type inference failed for: r1v33 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x00bf -> B:41:0x00c2). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0053: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0067]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0053: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0067]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_G(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_G(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:18:0x008b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static int m276Vulcan_M(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 267
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m276Vulcan_M(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public static int m277Vulcan_j(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 101722953604191(0x5c843883dc5f, double:5.0257816769334E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r17
            r1 = r13
            r2 = 2147483647(0x7fffffff, float:NaN)
            r3 = r18
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Double r4 = new java.lang.Double
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m279Vulcan_c(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m277Vulcan_j(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r5v10, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static int m278Vulcan_s(java.lang.Object[] r14) {
        /*
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r19 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r21 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r19
            long r0 = r0 ^ r1
            r19 = r0
            r0 = r19
            r1 = r0; r1 = r0; 
            r2 = 26613802570334(0x1834823f925e, double:1.31489655552035E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r21
            r1 = r22
            r2 = r15
            r3 = 2147483647(0x7fffffff, float:NaN)
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Double r7 = new java.lang.Double
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_W(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m278Vulcan_s(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static int m279Vulcan_c(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m279Vulcan_c(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_W(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 310
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_W(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006d]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006d]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static boolean m280Vulcan_Q(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 90693760680906(0x527c496383ca, double:4.48086714445833E-310)
            long r1 = r1 ^ r2
            r17 = r1
            java.lang.String r0 = Vulcan_k()
            r19 = r0
            r0 = r16
            r1 = r17
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6d
            java.lang.Double r5 = new java.lang.Double     // Catch: java.lang.IllegalArgumentException -> L6d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6d
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6d
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6d
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6d
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6d
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L6d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6d
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6d
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6d
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6d
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6d
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6d
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6d
            int r0 = Vulcan_m(r0)     // Catch: java.lang.IllegalArgumentException -> L6d
            r1 = r19
            if (r1 != 0) goto L79
            r1 = -1
            if (r0 == r1) goto L7c
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L75
            throw r0     // Catch: java.lang.IllegalArgumentException -> L75
        L71:
            r0 = 1
            goto L79
        L75:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L79:
            goto L7d
        L7c:
            r0 = 0
        L7d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m280Vulcan_Q(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r6v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0099]
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0099]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static boolean m281Vulcan_A(java.lang.Object[] r14) {
        /*
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r19 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r21 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r19
            long r0 = r0 ^ r1
            r19 = r0
            r0 = r19
            r1 = r0; r1 = r0; 
            r2 = 44213826667575(0x2836556ec437, double:2.18445328276284E-310)
            long r1 = r1 ^ r2
            r22 = r1
            java.lang.String r0 = Vulcan_k()
            r24 = r0
            r0 = r21
            r1 = r15
            r2 = 0
            r3 = r22
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch: java.lang.IllegalArgumentException -> L99
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L99
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L99
            java.lang.Double r7 = new java.lang.Double     // Catch: java.lang.IllegalArgumentException -> L99
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.lang.IllegalArgumentException -> L99
            r9 = r8; r8 = r7; r7 = r6; r6 = r9;      // Catch: java.lang.IllegalArgumentException -> L99
            r7.<init>(r8)     // Catch: java.lang.IllegalArgumentException -> L99
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.IllegalArgumentException -> L99
            r5[r6] = r7     // Catch: java.lang.IllegalArgumentException -> L99
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L99
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L99
            java.lang.Long r6 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L99
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L99
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.lang.IllegalArgumentException -> L99
            r6.<init>(r7)     // Catch: java.lang.IllegalArgumentException -> L99
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L99
            r4[r5] = r6     // Catch: java.lang.IllegalArgumentException -> L99
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L99
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L99
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L99
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.IllegalArgumentException -> L99
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L99
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L99
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L99
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L99
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L99
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L99
            java.lang.Double r4 = new java.lang.Double     // Catch: java.lang.IllegalArgumentException -> L99
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L99
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L99
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L99
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L99
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L99
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L99
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L99
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L99
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L99
            int r0 = m276Vulcan_M(r0)     // Catch: java.lang.IllegalArgumentException -> L99
            r1 = r24
            if (r1 != 0) goto La5
            r1 = -1
            if (r0 == r1) goto La8
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La1
            throw r0     // Catch: java.lang.IllegalArgumentException -> La1
        L9d:
            r0 = 1
            goto La5
        La1:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La5:
            goto La9
        La8:
            r0 = 0
        La9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m281Vulcan_A(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_Z(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 51708874207404(0x2f07691430ac, double:2.5547578331005E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m282Vulcan_q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_Z(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_i(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 30017493630991(0x1b4cfe0b800f, double:1.4830612377331E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r13
            r2 = 2147483647(0x7fffffff, float:NaN)
            r3 = r16
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m283Vulcan_v(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_i(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public static boolean m284Vulcan_w(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 111061260021172(0x650276f3adb4, double:5.4871553160303E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = Vulcan_k()
            r17 = r0
            r0 = r13
            r1 = r14
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6b
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6b
            int r0 = Vulcan_Z(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            r1 = r17
            if (r1 != 0) goto L77
            r1 = -1
            if (r0 == r1) goto L7a
            goto L6f
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L73
            throw r0     // Catch: java.lang.IllegalArgumentException -> L73
        L6f:
            r0 = 1
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            goto L7b
        L7a:
            r0 = 0
        L7b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m284Vulcan_w(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v19, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v2 */
    /* JADX WARN: Type inference failed for: r18v3, types: [int] */
    /* JADX WARN: Type inference failed for: r18v4, types: [int] */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r18v7 */
    /* JADX WARN: Type inference failed for: r18v8 */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Type inference failed for: r1v33 */
    /* JADX WARN: Type inference failed for: r1v34 */
    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:45:0x00cb -> B:25:0x008f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0066]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0066]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_R(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 208
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_R(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static int m287Vulcan_D(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m287Vulcan_D(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static boolean m288Vulcan_G(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 57575847329732(0x345d6bed7fc4, double:2.8446248195821E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r11
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6b
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L6b
            int r0 = m285Vulcan_g(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            r1 = r17
            if (r1 != 0) goto L77
            r1 = -1
            if (r0 == r1) goto L7a
            goto L6f
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L73
            throw r0     // Catch: java.lang.IllegalArgumentException -> L73
        L6f:
            r0 = 1
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            goto L7b
        L7a:
            r0 = 0
        L7b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m288Vulcan_G(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static char[] m289Vulcan_l(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Character[] r1 = (java.lang.Character[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            char[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_w     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            char[] r0 = new char[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            char r2 = r2.charValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m289Vulcan_l(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public static char[] m290Vulcan_k(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Character[] r1 = (java.lang.Character[]) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r9
            r1 = r10
            if (r1 != 0) goto L42
            if (r0 != 0) goto L40
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3c
        L3a:
            r0 = 0
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0
        L40:
            r0 = r9
        L42:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4e
            r1 = r10
            if (r1 != 0) goto L5d
            if (r0 != 0) goto L5a
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0     // Catch: java.lang.IllegalArgumentException -> L56
        L52:
            char[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_w     // Catch: java.lang.IllegalArgumentException -> L56
            return r0
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0
        L5a:
            r0 = r9
            int r0 = r0.length
        L5d:
            char[] r0 = new char[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L64:
            r0 = r12
            r1 = r9
            int r1 = r1.length
            if (r0 >= r1) goto Laa
            r0 = r9
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto Lac
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9e
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0     // Catch: java.lang.IllegalArgumentException -> L90
        L8a:
            if (r2 != 0) goto L9c
            goto L94
        L90:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L98
            throw r0     // Catch: java.lang.IllegalArgumentException -> L98
        L94:
            r2 = r6
            goto La1
        L98:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L98
            throw r0
        L9c:
            r2 = r13
        L9e:
            char r2 = r2.charValue()
        La1:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L64
        Laa:
            r0 = r11
        Lac:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m290Vulcan_k(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static java.lang.Character[] m291Vulcan_l(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Character[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_D     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r10
            int r0 = r0.length
        L4f:
            java.lang.Character[] r0 = new java.lang.Character[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Character r2 = new java.lang.Character     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r10
            r5 = r13
            char r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m291Vulcan_l(java.lang.Object[]):java.lang.Character[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public static long[] m292Vulcan_i(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long[] r1 = (java.lang.Long[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            long[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            long[] r0 = new long[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            long r2 = r2.longValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m292Vulcan_i(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static long[] m293Vulcan_u(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long[] r1 = (java.lang.Long[]) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r6
            r1 = r11
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r6
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r11
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            long[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_V     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r6
            int r0 = r0.length
        L5a:
            long[] r0 = new long[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L61:
            r0 = r13
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r6
            r1 = r13
            r0 = r0[r1]
            r14 = r0
            r0 = r12
            r1 = r11
            if (r1 != 0) goto La8
            r1 = r13
            r2 = r14
            r3 = r11
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r14
        L9a:
            long r2 = r2.longValue()
        L9d:
            r0[r1] = r2
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L61
        La6:
            r0 = r12
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m293Vulcan_u(java.lang.Object[]):long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static java.lang.Long[] m294Vulcan_M(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Long[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_h     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r10
            int r0 = r0.length
        L4f:
            java.lang.Long[] r0 = new java.lang.Long[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Long r2 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r10
            r5 = r13
            r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m294Vulcan_M(java.lang.Object[]):java.lang.Long[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public static int[] m295Vulcan_B(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer[] r1 = (java.lang.Integer[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            int[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_P     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            int[] r0 = new int[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            int r2 = r2.intValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m295Vulcan_B(java.lang.Object[]):int[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static int[] m296Vulcan_h(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer[] r1 = (java.lang.Integer[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r6
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r10
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            int[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_P     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r6
            int r0 = r0.length
        L5a:
            int[] r0 = new int[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L61:
            r0 = r12
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r6
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto La8
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r13
        L9a:
            int r2 = r2.intValue()
        L9d:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L61
        La6:
            r0 = r11
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m296Vulcan_h(java.lang.Object[]):int[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static java.lang.Integer[] m297Vulcan_u(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Integer[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_C     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Integer[] r0 = new java.lang.Integer[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Integer r2 = new java.lang.Integer     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r8
            r5 = r13
            r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m297Vulcan_u(java.lang.Object[]):java.lang.Integer[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static short[] m298Vulcan_q(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Short[] r1 = (java.lang.Short[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            short[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_Z     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r6
            int r0 = r0.length
        L4f:
            short[] r0 = new short[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r6
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            short r2 = r2.shortValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m298Vulcan_q(java.lang.Object[]):short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static short[] m299Vulcan_U(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Short[] r1 = (java.lang.Short[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r6
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r10
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            short[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_Z     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r6
            int r0 = r0.length
        L5a:
            short[] r0 = new short[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L61:
            r0 = r12
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r6
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto La8
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r13
        L9a:
            short r2 = r2.shortValue()
        L9d:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L61
        La6:
            r0 = r11
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m299Vulcan_U(java.lang.Object[]):short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static java.lang.Short[] m300Vulcan_D(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Short[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_t     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Short[] r0 = new java.lang.Short[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Short r2 = new java.lang.Short     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r8
            r5 = r13
            short r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m300Vulcan_D(java.lang.Object[]):java.lang.Short[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static byte[] Vulcan_V(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Byte[] r1 = (java.lang.Byte[]) r1
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r0 = r10
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r8
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r7
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_fX.a
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = Vulcan_k()
            r13 = r0
            r0 = r9
            r1 = r13
            if (r1 != 0) goto L62
            if (r0 != 0) goto L61
            goto L5b
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5d
        L5b:
            r0 = 0
            return r0
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            throw r0
        L61:
            r0 = r9
        L62:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L6e
            r1 = r13
            if (r1 != 0) goto L7c
            if (r0 != 0) goto L7a
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            throw r0     // Catch: java.lang.IllegalArgumentException -> L76
        L72:
            byte[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_N     // Catch: java.lang.IllegalArgumentException -> L76
            return r0
        L76:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            throw r0
        L7a:
            r0 = r9
            int r0 = r0.length
        L7c:
            byte[] r0 = new byte[r0]
            r14 = r0
            r0 = 0
            r15 = r0
        L83:
            r0 = r15
            r1 = r9
            int r1 = r1.length
            if (r0 >= r1) goto Lb3
        L8a:
            r0 = r8
            if (r0 <= 0) goto La2
            r0 = r14
            r1 = r13
            if (r1 != 0) goto Lb5
            r1 = r15
            r2 = r9
            r3 = r15
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> Laf
            byte r2 = r2.byteValue()     // Catch: java.lang.IllegalArgumentException -> Laf
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> Laf
            int r15 = r15 + 1
        La2:
            r0 = r13
            if (r0 == 0) goto L83
            r0 = r10
            if (r0 < 0) goto L8a
            goto Lb3
        Laf:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb3:
            r0 = r14
        Lb5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_V(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static byte[] m301Vulcan_c(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Byte[] r1 = (java.lang.Byte[]) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r8
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r10
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            byte[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_N     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r8
            int r0 = r0.length
        L5a:
            byte[] r0 = new byte[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L61:
            r0 = r12
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r8
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto La8
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r13
        L9a:
            byte r2 = r2.byteValue()
        L9d:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L61
        La6:
            r0 = r11
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m301Vulcan_c(java.lang.Object[]):byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static java.lang.Byte[] m302Vulcan_K(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Byte[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_u     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Byte[] r0 = new java.lang.Byte[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Byte r2 = new java.lang.Byte     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r8
            r5 = r13
            r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m302Vulcan_K(java.lang.Object[]):java.lang.Byte[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public static double[] m303Vulcan_L(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double[] r1 = (java.lang.Double[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            double[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_K     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r6
            int r0 = r0.length
        L4f:
            double[] r0 = new double[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r6
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            double r2 = r2.doubleValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m303Vulcan_L(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static double[] m304Vulcan_r(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double[] r1 = (java.lang.Double[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L42
            if (r0 != 0) goto L40
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3c
        L3a:
            r0 = 0
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0
        L40:
            r0 = r10
        L42:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4e
            r1 = r11
            if (r1 != 0) goto L5d
            if (r0 != 0) goto L5a
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0     // Catch: java.lang.IllegalArgumentException -> L56
        L52:
            double[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_K     // Catch: java.lang.IllegalArgumentException -> L56
            return r0
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L56
            throw r0
        L5a:
            r0 = r10
            int r0 = r0.length
        L5d:
            double[] r0 = new double[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L64:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto Laa
            r0 = r10
            r1 = r13
            r0 = r0[r1]
            r14 = r0
            r0 = r12
            r1 = r11
            if (r1 != 0) goto Lac
            r1 = r13
            r2 = r14
            r3 = r11
            if (r3 != 0) goto L9e
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0     // Catch: java.lang.IllegalArgumentException -> L90
        L8a:
            if (r2 != 0) goto L9c
            goto L94
        L90:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L98
            throw r0     // Catch: java.lang.IllegalArgumentException -> L98
        L94:
            r2 = r8
            goto La1
        L98:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L98
            throw r0
        L9c:
            r2 = r14
        L9e:
            double r2 = r2.doubleValue()
        La1:
            r0[r1] = r2
            int r13 = r13 + 1
            r0 = r11
            if (r0 == 0) goto L64
        Laa:
            r0 = r12
        Lac:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m304Vulcan_r(java.lang.Object[]):double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public static java.lang.Double[] m305Vulcan_Y(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Double[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_Q     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r10
            int r0 = r0.length
        L4f:
            java.lang.Double[] r0 = new java.lang.Double[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Double r2 = new java.lang.Double     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r10
            r5 = r13
            r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m305Vulcan_Y(java.lang.Object[]):java.lang.Double[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static float[] m306Vulcan_u(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float[] r1 = (java.lang.Float[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            float[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_l     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            float[] r0 = new float[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            float r2 = r2.floatValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m306Vulcan_u(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static float[] m307Vulcan_X(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float[] r1 = (java.lang.Float[]) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r6
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r10
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            float[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_l     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r6
            int r0 = r0.length
        L5a:
            float[] r0 = new float[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L61:
            r0 = r12
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r6
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto La8
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r13
        L9a:
            float r2 = r2.floatValue()
        L9d:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L61
        La6:
            r0 = r11
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m307Vulcan_X(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public static java.lang.Float[] m308Vulcan_k(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r11
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Float[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Float[] r0 = new java.lang.Float[r0]
            r12 = r0
            r0 = 0
            r13 = r0
        L57:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L8e
        L5e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7c
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L90
            r1 = r13
            java.lang.Float r2 = new java.lang.Float     // Catch: java.lang.IllegalArgumentException -> L8a
            r3 = r2
            r4 = r8
            r5 = r13
            r4 = r4[r5]     // Catch: java.lang.IllegalArgumentException -> L8a
            r3.<init>(r4)     // Catch: java.lang.IllegalArgumentException -> L8a
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L8a
            int r13 = r13 + 1
        L7c:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5e
            goto L8e
        L8a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8e:
            r0 = r12
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m308Vulcan_k(java.lang.Object[]):java.lang.Float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public static boolean[] m309Vulcan_Y(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean[] r1 = (java.lang.Boolean[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            boolean[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r6
            int r0 = r0.length
        L4f:
            boolean[] r0 = new boolean[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L56:
            r0 = r11
            r1 = r6
            int r1 = r1.length
            if (r0 >= r1) goto L89
        L5d:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L77
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L8b
            r1 = r11
            r2 = r6
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L85
            boolean r2 = r2.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L85
            r0[r1] = r2     // Catch: java.lang.IllegalArgumentException -> L85
            int r11 = r11 + 1
        L77:
            r0 = r9
            if (r0 == 0) goto L56
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5d
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r0 = r10
        L8b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m309Vulcan_Y(java.lang.Object[]):boolean[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static boolean[] m310Vulcan_m(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean[] r1 = (java.lang.Boolean[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L39:
            r0 = 0
            return r0
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r8
        L40:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r10
            if (r1 != 0) goto L5a
            if (r0 != 0) goto L58
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0     // Catch: java.lang.IllegalArgumentException -> L54
        L50:
            boolean[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L54
            return r0
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L54
            throw r0
        L58:
            r0 = r8
            int r0 = r0.length
        L5a:
            boolean[] r0 = new boolean[r0]
            r11 = r0
            r0 = 0
            r12 = r0
        L61:
            r0 = r12
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto La6
            r0 = r8
            r1 = r12
            r0 = r0[r1]
            r13 = r0
            r0 = r11
            r1 = r10
            if (r1 != 0) goto La8
            r1 = r12
            r2 = r13
            r3 = r10
            if (r3 != 0) goto L9a
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8b
        L85:
            if (r2 != 0) goto L98
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0     // Catch: java.lang.IllegalArgumentException -> L94
        L8f:
            r2 = r9
            goto L9d
        L94:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L94
            throw r0
        L98:
            r2 = r13
        L9a:
            boolean r2 = r2.booleanValue()
        L9d:
            r0[r1] = r2
            int r12 = r12 + 1
            r0 = r10
            if (r0 == 0) goto L61
        La6:
            r0 = r11
        La8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m310Vulcan_m(java.lang.Object[]):boolean[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static java.lang.Boolean[] m311Vulcan_r(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L45:
            java.lang.Boolean[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_L     // Catch: java.lang.IllegalArgumentException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Boolean[] r0 = new java.lang.Boolean[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L57:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L8b
        L5e:
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L93
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L7b
            if (r2 == 0) goto L7f
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L7b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L7b
        L75:
            java.lang.Boolean r2 = java.lang.Boolean.TRUE     // Catch: java.lang.IllegalArgumentException -> L7b
            goto L82
        L7b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L7b
            throw r0
        L7f:
            java.lang.Boolean r2 = java.lang.Boolean.FALSE
        L82:
            r0[r1] = r2
            int r11 = r11 + 1
            r0 = r9
            if (r0 == 0) goto L57
        L8b:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5e
            r0 = r10
        L93:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m311Vulcan_r(java.lang.Object[]):java.lang.Boolean[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m312Vulcan_L(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m312Vulcan_L(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m313Vulcan_z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m313Vulcan_z(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m314Vulcan_P(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m314Vulcan_P(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m315Vulcan_e(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m315Vulcan_e(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m316Vulcan_Y(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m316Vulcan_Y(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_F(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_F(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m317Vulcan_s(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m317Vulcan_s(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m318Vulcan_p(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m318Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m319Vulcan_a(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 != 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m319Vulcan_a(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m320Vulcan_R(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m320Vulcan_R(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m321Vulcan_W(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m321Vulcan_W(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m322Vulcan_K(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m322Vulcan_K(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m323Vulcan_i(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m323Vulcan_i(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_C(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_C(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m324Vulcan_I(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m324Vulcan_I(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m325Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m325Vulcan_v(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m326Vulcan_E(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r6
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m326Vulcan_E(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m327Vulcan_H(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L43
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L3b
            r1 = r9
            if (r1 != 0) goto L40
            if (r0 == 0) goto L43
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r0 = 1
        L40:
            goto L44
        L43:
            r0 = 0
        L44:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m327Vulcan_H(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Object[] Vulcan_f(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 294
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.Vulcan_f(java.lang.Object[]):java.lang.Object[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public static boolean[] m328Vulcan_L(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 90286911440722(0x521d8f48c752, double:4.46076612119717E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L64
            if (r0 != 0) goto L63
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L40:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            boolean[] r0 = m227Vulcan_K(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r10
        L64:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L73:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            boolean[] r0 = m227Vulcan_K(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r13
            int r0 = r0.length
            r1 = r10
            int r1 = r1.length
            int r0 = r0 + r1
            boolean[] r0 = new boolean[r0]
        L9f:
            r17 = r0
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = r13
            int r3 = r3.length
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m328Vulcan_L(java.lang.Object[]):boolean[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static char[] m329Vulcan_G(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 40815046835550(0x251efe5e3d5e, double:2.01653124748467E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L64
            if (r0 != 0) goto L63
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L40:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            char[] r0 = Vulcan_w(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r10
        L64:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L73:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            char[] r0 = Vulcan_w(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r13
            int r0 = r0.length
            r1 = r10
            int r1 = r1.length
            int r0 = r0 + r1
            char[] r0 = new char[r0]
        L9f:
            r17 = r0
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = r13
            int r3 = r3.length
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m329Vulcan_G(java.lang.Object[]):char[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public static byte[] m330Vulcan_C(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 133553758981582(0x7977685ccdce, double:6.59843241857615E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L64
            if (r0 != 0) goto L63
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L40:
            r0 = r12
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            byte[] r0 = Vulcan_U(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r12
        L64:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L73:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            byte[] r0 = Vulcan_U(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r13
            int r0 = r0.length
            r1 = r12
            int r1 = r1.length
            int r0 = r0 + r1
            byte[] r0 = new byte[r0]
        L9f:
            r17 = r0
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r12
            r1 = 0
            r2 = r17
            r3 = r13
            int r3 = r3.length
            r4 = r12
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m330Vulcan_C(java.lang.Object[]):byte[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static short[] m331Vulcan_N(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 93580443939120(0x551c651e7130, double:4.6234882472892E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r10
            r1 = r16
            if (r1 != 0) goto L65
            if (r0 != 0) goto L63
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L3f:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            short[] r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r13
        L65:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L74:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            short[] r0 = Vulcan_Q(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r10
            int r0 = r0.length
            r1 = r13
            int r1 = r1.length
            int r0 = r0 + r1
            short[] r0 = new short[r0]
        L9f:
            r17 = r0
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = r10
            int r3 = r3.length
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m331Vulcan_N(java.lang.Object[]):short[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public static int[] m332Vulcan_H(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 109988167301062(0x64089da437c6, double:5.43413749124943E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L64
            if (r0 != 0) goto L63
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L40:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            int[] r0 = Vulcan_g(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r10
        L64:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L73:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            int[] r0 = Vulcan_g(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r13
            int r0 = r0.length
            r1 = r10
            int r1 = r1.length
            int r0 = r0 + r1
            int[] r0 = new int[r0]
        L9f:
            r17 = r0
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = r13
            int r3 = r3.length
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m332Vulcan_H(java.lang.Object[]):int[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static float[] m334Vulcan_e(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 94808465978763(0x563a50efb58b, double:4.68416059750154E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 != 0) goto L62
            if (r0 != 0) goto L61
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5d
        L3e:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5d
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5d
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5d
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5d
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5d
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5d
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5d
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5d
            float[] r0 = Vulcan_N(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            return r0
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5d
            throw r0
        L61:
            r0 = r10
        L62:
            r1 = r16
            if (r1 != 0) goto L9b
            if (r0 != 0) goto L94
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0     // Catch: java.lang.IllegalArgumentException -> L90
        L71:
            r0 = r11
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L90
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L90
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L90
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L90
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L90
            float[] r0 = Vulcan_N(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            return r0
        L90:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0
        L94:
            r0 = r11
            int r0 = r0.length
            r1 = r10
            int r1 = r1.length
            int r0 = r0 + r1
            float[] r0 = new float[r0]
        L9b:
            r17 = r0
            r0 = r11
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r11
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = r11
            int r3 = r3.length
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m334Vulcan_e(java.lang.Object[]):float[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public static double[] m335Vulcan_O(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 132625517567117(0x789f48dcdc8d, double:6.55257119918272E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_k()
            r16 = r0
            r0 = r10
            r1 = r16
            if (r1 != 0) goto L65
            if (r0 != 0) goto L63
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L3f:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L5f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L5f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L5f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L5f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L5f
            double[] r0 = Vulcan_A(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r13
        L65:
            r1 = r16
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L97
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0     // Catch: java.lang.IllegalArgumentException -> L93
        L74:
            r0 = r10
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L93
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L93
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L93
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L93
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L93
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L93
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L93
            double[] r0 = Vulcan_A(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            return r0
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L93
            throw r0
        L97:
            r0 = r10
            int r0 = r0.length
            r1 = r13
            int r1 = r1.length
            int r0 = r0 + r1
            double[] r0 = new double[r0]
        L9f:
            r17 = r0
            r0 = r10
            r1 = 0
            r2 = r17
            r3 = 0
            r4 = r10
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r13
            r1 = 0
            r2 = r17
            r3 = r10
            int r3 = r3.length
            r4 = r13
            int r4 = r4.length
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m335Vulcan_O(java.lang.Object[]):double[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public static java.lang.Object[] m336Vulcan_P(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 241
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m336Vulcan_P(java.lang.Object[]):java.lang.Object[]");
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    static Class m375Vulcan_f(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static boolean[] m337Vulcan_N(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 102390911742838(0x5d1fbdec3376, double:5.05878319384993E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            java.lang.Class r2 = java.lang.Boolean.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            boolean[] r0 = (boolean[]) r0
            boolean[] r0 = (boolean[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r10
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m337Vulcan_N(java.lang.Object[]):boolean[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v6, types: [int] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public static byte[] m338Vulcan_z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 78047023014011(0x46fbbd15207b, double:3.8560352831404E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            java.lang.Class r2 = java.lang.Byte.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            byte[] r0 = (byte[]) r0
            byte[] r0 = (byte[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r10
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m338Vulcan_z(java.lang.Object[]):byte[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public static char[] m339Vulcan_O(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 34302467088445(0x1f32aa5da03d, double:1.69476705560007E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            java.lang.Class r2 = java.lang.Character.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            char[] r0 = (char[]) r0
            char[] r0 = (char[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r12
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m339Vulcan_O(java.lang.Object[]):char[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static double[] m340Vulcan_e(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 119046069794454(0x6c4592b3b696, double:5.8816573357859E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            java.lang.Class r2 = java.lang.Double.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            double[] r0 = (double[]) r0
            double[] r0 = (double[]) r0
            r17 = r0
            r0 = r17
            r1 = r17
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r11
            r0[r1] = r2
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m340Vulcan_e(java.lang.Object[]):double[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public static float[] m341Vulcan_M(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 124390453647018(0x7121e8cd96aa, double:6.14570498175996E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            java.lang.Class r2 = java.lang.Float.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            float[] r0 = (float[]) r0
            float[] r0 = (float[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r10
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m341Vulcan_M(java.lang.Object[]):float[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static int[] m342Vulcan_c(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 53893512383640(0x31040fa94c98, double:2.66269330024763E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            r1 = r14
            java.lang.Class r2 = java.lang.Integer.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            int[] r0 = (int[]) r0
            int[] r0 = (int[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r11
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m342Vulcan_c(java.lang.Object[]):int[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public static long[] m343Vulcan_V(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 42794034343788(0x26ebc3372f6c, double:2.1143062216216E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r15
            java.lang.Class r2 = java.lang.Long.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            long[] r0 = (long[]) r0
            long[] r0 = (long[]) r0
            r17 = r0
            r0 = r17
            r1 = r17
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r10
            r0[r1] = r2
            r0 = r17
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m343Vulcan_V(java.lang.Object[]):long[]");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public static short[] m344Vulcan_B(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 95541923828969(0x56e5166e54e9, double:4.72039823014748E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            java.lang.Class r2 = java.lang.Short.TYPE
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m345Vulcan_F(r0)
            short[] r0 = (short[]) r0
            short[] r0 = (short[]) r0
            r16 = r0
            r0 = r16
            r1 = r16
            int r1 = r1.length
            r2 = 1
            int r1 = r1 - r2
            r2 = r10
            r0[r1] = r2
            r0 = r16
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m344Vulcan_B(java.lang.Object[]):short[]");
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    private static Object m345Vulcan_F(Object[] objArr) {
        Object obj = objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        Class cls = (Class) objArr[2];
        long j = a ^ jLongValue;
        if (Vulcan_k() == null) {
            if (obj != null) {
                int length = Array.getLength(obj);
                Object objNewInstance = Array.newInstance(obj.getClass().getComponentType(), length + 1);
                System.arraycopy(obj, 0, objNewInstance, 0, length);
                return objNewInstance;
            }
            return Array.newInstance((Class<?>) cls, 1);
        }
        return obj;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    private static java.lang.Object m355Vulcan_X(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 325
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m355Vulcan_X(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public static java.lang.Object[] m356Vulcan_F(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 21846874510498(0x13de9f31d4a2, double:1.0793790164642E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m356Vulcan_F(java.lang.Object[]):java.lang.Object[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static boolean[] m358Vulcan_A(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 109677704336038(0x63c0549b52a6, double:5.418798582717E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            r1 = r14
            r2 = r11
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            boolean[] r0 = (boolean[]) r0
            boolean[] r0 = (boolean[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m358Vulcan_A(java.lang.Object[]):boolean[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean[]] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v17, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v21, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v24, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public static boolean[] m359Vulcan_i(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 136343967839342(0x7c010dc5346e, double:6.73628705271027E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 86370044596351(0x4e8d97d3d07f, double:4.26724718648334E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 115728973083108(0x69414054b1e4, double:5.717770982885E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r11
            r1 = r12
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m285Vulcan_g(r0)
            r21 = r0
            r0 = r21
            r1 = -1
            if (r0 != r1) goto L91
            r0 = r11
            r1 = r19
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L8d
            boolean[] r0 = m227Vulcan_K(r0)     // Catch: java.lang.IllegalArgumentException -> L8d
            return r0
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8d
            throw r0
        L91:
            r0 = r11
            r1 = r17
            r2 = r21
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean[] r0 = m358Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m359Vulcan_i(java.lang.Object[]):boolean[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public static byte[] m360Vulcan_g(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 64070299389608(0x3a45876f8ea8, double:3.16549338471687E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            byte[] r0 = (byte[]) r0
            byte[] r0 = (byte[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m360Vulcan_g(java.lang.Object[]):byte[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static char[] m362Vulcan_m(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 96790510450589(0x5807cbfe379d, double:4.7820866057074E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r12
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            char[] r0 = (char[]) r0
            char[] r0 = (char[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m362Vulcan_m(java.lang.Object[]):char[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [char[]] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v17, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v21, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v24, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static char[] m363Vulcan_N(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 102852662846396(0x5d8b406ee3bc, double:5.08159672956966E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 102142170385531(0x5ce5d3c84c7b, double:5.0464937379154E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 72141833038774(0x419cd454ebb6, double:3.56428013324733E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r14
            r1 = r11
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m265Vulcan_I(r0)
            r21 = r0
            r0 = r21
            r1 = -1
            if (r0 != r1) goto L94
            r0 = r14
            r1 = r17
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L90
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L90
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L90
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L90
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L90
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L90
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L90
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L90
            char[] r0 = Vulcan_w(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            return r0
        L90:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L90
            throw r0
        L94:
            r0 = r14
            r1 = r19
            r2 = r21
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            char[] r0 = m362Vulcan_m(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m363Vulcan_N(java.lang.Object[]):char[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static double[] m364Vulcan_K(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 27207044083951(0x18bea232b0ef, double:1.34420658067685E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            double[] r0 = (double[]) r0
            double[] r0 = (double[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m364Vulcan_K(java.lang.Object[]):double[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static float[] m366Vulcan_r(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 139157741344521(0x7e902fbd9709, double:6.875305935119E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            float[] r0 = (float[]) r0
            float[] r0 = (float[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m366Vulcan_r(java.lang.Object[]):float[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v6 ??, still in use, count: 1, list:
          (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0068: MOVE (r0v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:4642)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public static float[] m367Vulcan_n(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v6 ??, still in use, count: 1, list:
          (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0068: MOVE (r0v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:4642)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r10v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static int[] m368Vulcan_A(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 35617647182685(0x2064e135435d, double:1.7597455858659E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            int[] r0 = (int[]) r0
            int[] r0 = (int[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m368Vulcan_A(java.lang.Object[]):int[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v17, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v21, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v24, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public static int[] m369Vulcan_z(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 118592753341013(0x6bdc06ef9255, double:5.8592605271519E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 26945190543704(0x1881aa82c158, double:1.33126929682906E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 89404784724319(0x51502c6f495f, double:4.41718327061183E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r11
            r1 = r14
            r2 = r19
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            r21 = r0
            r0 = r21
            r1 = -1
            if (r0 != r1) goto L93
            r0 = r11
            r1 = r17
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L8f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L8f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L8f
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8f
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8f
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L8f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8f
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L8f
            int[] r0 = Vulcan_g(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            return r0
        L8f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            throw r0
        L93:
            r0 = r11
            r1 = r15
            r2 = r21
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m368Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m369Vulcan_z(java.lang.Object[]):int[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public static long[] m370Vulcan_a(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 11165258932268(0xa279d4ae02c, double:5.5163708653557E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            long[] r0 = (long[]) r0
            long[] r0 = (long[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m370Vulcan_a(java.lang.Object[]):long[]");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static short[] m372Vulcan_e(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fX.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 13670356148232(0xc6ee0b8e008, double:6.754053339256E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = m374Vulcan_I(r0)
            short[] r0 = (short[]) r0
            short[] r0 = (short[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m372Vulcan_e(java.lang.Object[]):short[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.IndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    private static java.lang.Object m374Vulcan_I(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fX.m374Vulcan_I(java.lang.Object[]):java.lang.Object");
    }
}
