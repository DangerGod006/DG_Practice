package ac.vulcan.anticheat;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fK.class */
public abstract class Vulcan_fK implements Comparable, Serializable {
    private static final long serialVersionUID = -487045951170455942L;
    private static final Map Vulcan_n;
    private static Map Vulcan_f;
    private final String Vulcan_r;
    private final transient int Vulcan_C;
    protected transient String Vulcan_s;
    static Class Vulcan_O;
    static Class Vulcan_d;
    private static String Vulcan_B;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(248351792997369931L, 3329727772323687841L, null).a(179597566910055L);
    private static final String[] c;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_L(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 678
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_L(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String toString() {
        /*
            r8 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = 111903605719186(0x65c696ab0092, double:5.5287727231614E-310)
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 27919874993749(0x19649a3b2e55, double:1.37942510705935E-310)
            long r1 = r1 ^ r2
            r11 = r1
            java.lang.String r0 = Vulcan_p()
            r13 = r0
            r0 = r8
            java.lang.String r0 = r0.Vulcan_s     // Catch: java.lang.IllegalArgumentException -> L24
            r1 = r13
            if (r1 != 0) goto L7e
            if (r0 != 0) goto L7a
            goto L28
        L24:
            java.lang.Exception r0 = a(r0)
            throw r0
        L28:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Class r0 = r0.Vulcan_F(r1)
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(r0)
            r14 = r0
            r0 = r8
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r2 = r1
            r2.<init>()
            r2 = r14
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "["
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r2 = r2.Vulcan_C(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "]"
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.Vulcan_s = r1
        L7a:
            r0 = r8
            java.lang.String r0 = r0.Vulcan_s
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.toString():java.lang.String");
    }

    public static void Vulcan_X(String str) {
        Vulcan_B = str;
    }

    public static String Vulcan_p() {
        return Vulcan_B;
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008b, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008e, code lost:
    
        r11 = ")m\ru\tv\u001a\u000evH8?i\u000f]g\ru+:\b\bg\u000b9+i\b]j\u000eu\u000ft\u000e\u0010\u0007\u001a`\u001c\u001b+w\u001e".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0097, code lost:
    
        ac.vulcan.anticheat.Vulcan_fK.c = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00af, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b2, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b6, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00be, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e4, code lost:
    
        r7 = 52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e9, code lost:
    
        r7 = 76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ee, code lost:
    
        r7 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f3, code lost:
    
        r7 = 28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f8, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00fc, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0101, code lost:
    
        r7 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0103, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x010b, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010e, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0113, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0118, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x011c, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x012b, code lost:
    
        ac.vulcan.anticheat.Vulcan_fK.Vulcan_n = java.util.Collections.unmodifiableMap(new java.util.HashMap(0));
        ac.vulcan.anticheat.Vulcan_fK.Vulcan_f = new java.util.WeakHashMap();
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0143, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x009f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00af, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b2, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b6, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00be, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e4, code lost:
    
        r7 = 52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0103, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010e, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e9, code lost:
    
        r7 = 76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ee, code lost:
    
        r7 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f3, code lost:
    
        r7 = 28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f8, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fc, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0101, code lost:
    
        r7 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0113, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0118, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0040, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r1[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x011c, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0050, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005c, code lost:
    
        r2 = ")m\ru\tv\u001a\u000evH8?i\u000f]g\ru+:\b\bg\u000b9+i\b]j\u000eu\u000ft\u000e\u0010\u0007\u001a`\u001c\u001b+w\u001e".length();
        r11 = '$';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006b, code lost:
    
        r10 = r10 + 1;
        ")m\ru\tv\u001a\u000evH8?i\u000f]g\ru+:\b\bg\u000b9+i\b]j\u000eu\u000ft\u000e\u0010\u0007\u001a`\u001c\u001b+w\u001e".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007b, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r1[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b2, B:28:0x0113], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v19 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0118 -> B:15:0x00b2). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0118 -> B:35:0x00b2). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 324
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.m191clinit():void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_fK, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003a: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003a: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x006b]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected Vulcan_fK(java.lang.String r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = 45082385665445(0x29008f954da5, double:2.2273657989862E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 41175788648076(0x2572fc41768c, double:2.03435426114343E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_p()
            r1 = r9
            r1.<init>()
            r15 = r0
            r0 = r9
            r1 = 0
            r0.Vulcan_s = r1     // Catch: java.lang.IllegalArgumentException -> L6b
            r0 = r9
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L6b
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L6b
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L6b
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L6b
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L6b
            r0.Vulcan_L(r1)     // Catch: java.lang.IllegalArgumentException -> L6b
            r0 = r9
            r1 = r10
            r0.Vulcan_r = r1     // Catch: java.lang.IllegalArgumentException -> L6b
            r0 = r9
            r1 = 7
            r2 = r9
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6b
            java.lang.Class r2 = r2.Vulcan_F(r3)     // Catch: java.lang.IllegalArgumentException -> L6b
            int r2 = r2.hashCode()     // Catch: java.lang.IllegalArgumentException -> L6b
            int r1 = r1 + r2
            r2 = 3
            r3 = r10
            int r3 = r3.hashCode()     // Catch: java.lang.IllegalArgumentException -> L6b
            int r2 = r2 * r3
            int r1 = r1 + r2
            r0.Vulcan_C = r1     // Catch: java.lang.IllegalArgumentException -> L6b
            r0 = r15
            if (r0 == 0) goto L6f
            r0 = 4
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = new me.frep.vulcan.spigot.check.AbstractCheck[r0]     // Catch: java.lang.IllegalArgumentException -> L6b
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            goto L6f
        L6b:
            java.lang.Exception r0 = a(r0)
            throw r0
        L6f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.<init>(java.lang.String):void");
    }

    static Class Vulcan_g(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected java.lang.Object readResolve(long r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = Vulcan_p()
            java.util.Map r1 = ac.vulcan.anticheat.Vulcan_fK.Vulcan_f
            r2 = r5
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Class r2 = r2.Vulcan_F(r3)
            java.lang.Object r1 = r1.get(r2)
            ac.vulcan.anticheat.Vulcan_L r1 = (ac.vulcan.anticheat.Vulcan_L) r1
            r9 = r1
            r8 = r0
            r0 = r9
            r1 = r8
            if (r1 != 0) goto L47
            if (r0 != 0) goto L35
            goto L2f
        L2b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L31
            throw r0     // Catch: java.lang.IllegalArgumentException -> L31
        L2f:
            r0 = 0
            return r0
        L31:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L31
            throw r0
        L35:
            r0 = r9
            java.util.Map r0 = r0.Vulcan_E
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.String r1 = r1.Vulcan_C(r2)
            java.lang.Object r0 = r0.get(r1)
        L47:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.readResolve(long):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected static ac.vulcan.anticheat.Vulcan_fK Vulcan_M(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 2622808945968(0x262ab987530, double:1.295839795808E-311)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = Vulcan_p()
            r1 = r14
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_L r1 = Vulcan_V(r1)
            r17 = r1
            r16 = r0
            r0 = r17
            r1 = r16
            if (r1 != 0) goto L70
            if (r0 != 0) goto L65
            goto L5f
        L5b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L61
            throw r0     // Catch: java.lang.IllegalArgumentException -> L61
        L5f:
            r0 = 0
            return r0
        L61:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L61
            throw r0
        L65:
            r0 = r17
            java.util.Map r0 = r0.Vulcan_E
            r1 = r11
            java.lang.Object r0 = r0.get(r1)
        L70:
            ac.vulcan.anticheat.Vulcan_fK r0 = (ac.vulcan.anticheat.Vulcan_fK) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_M(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fK");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Exception, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected static java.util.Map Vulcan_t(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 114502650840939(0x6823b9d4476b, double:5.65718261382633E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_p()
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_L r1 = Vulcan_V(r1)
            r16 = r1
            r15 = r0
            r0 = r16
            r1 = r15
            if (r1 != 0) goto L62
            if (r0 != 0) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5c
        L58:
            java.util.Map r0 = ac.vulcan.anticheat.Vulcan_fK.Vulcan_n     // Catch: java.lang.IllegalArgumentException -> L5c
            return r0
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0
        L60:
            r0 = r16
        L62:
            java.util.Map r0 = r0.Vulcan_i
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_t(java.lang.Object[]):java.util.Map");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Exception, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected static java.util.List Vulcan_r(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 107692893746897(0x61f234ad36d1, double:5.32073591015734E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_p()
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_L r1 = Vulcan_V(r1)
            r16 = r1
            r15 = r0
            r0 = r16
            r1 = r15
            if (r1 != 0) goto L62
            if (r0 != 0) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5c
        L58:
            java.util.List r0 = java.util.Collections.EMPTY_LIST     // Catch: java.lang.IllegalArgumentException -> L5c
            return r0
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0
        L60:
            r0 = r16
        L62:
            java.util.List r0 = r0.Vulcan_P
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_r(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected static java.util.Iterator Vulcan_X(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 121114924436583(0x6e27440c4c67, double:5.9838723362774E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.util.List r0 = Vulcan_r(r0)
            java.util.Iterator r0 = r0.iterator()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_X(java.lang.Object[]):java.util.Iterator");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.ClassLoader, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r2v6, types: [boolean, java.lang.ClassLoader] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static Vulcan_L Vulcan_V(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        Class cls = (Class) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_p = Vulcan_p();
        try {
            Class cls2 = cls;
            ?? illegalArgumentException = cls2;
            if (Vulcan_p == 0) {
                if (cls2 == null) {
                    throw new IllegalArgumentException(c[6]);
                }
                illegalArgumentException = Vulcan_O;
            }
            try {
                if (Vulcan_p == 0) {
                    if (illegalArgumentException == 0) {
                        illegalArgumentException = Vulcan_g(new Object[]{c[4]});
                        Vulcan_O = illegalArgumentException;
                    } else {
                        illegalArgumentException = Vulcan_O;
                    }
                }
                ?? r0 = illegalArgumentException;
                if (j > 0) {
                    try {
                        if (!illegalArgumentException.isAssignableFrom(cls)) {
                            illegalArgumentException = new IllegalArgumentException(c[12]);
                            throw illegalArgumentException;
                        }
                        r0 = Vulcan_f.get(cls);
                    } catch (Exception unused) {
                        throw a(illegalArgumentException);
                    }
                }
                Vulcan_L vulcan_L = (Vulcan_L) r0;
                if (Vulcan_p == 0) {
                    if (vulcan_L == null) {
                        try {
                            Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) 1), cls.getClassLoader(), cls.getName());
                            vulcan_L = (Vulcan_L) Vulcan_f.get(cls);
                        } catch (Exception e) {
                        }
                    }
                    return vulcan_L;
                }
                return vulcan_L;
            } catch (Exception unused2) {
                throw a(illegalArgumentException);
            }
        } catch (Exception unused3) {
            throw a(Vulcan_p);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:68:0x0114, code lost:
    
        if (r0 == null) goto L3;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:20:0x0076, B:18:0x006e], limit reached: 67 */
    /* JADX WARN: Path cross not found for [B:53:0x010f, B:40:0x00cb], limit reached: 67 */
    /* JADX WARN: Path cross not found for [B:58:0x0032, B:55:0x0114], limit reached: 67 */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00be A[PHI: r0 r13
  0x00be: PHI (r0v24 ac.vulcan.anticheat.Vulcan_L) = (r0v15 ac.vulcan.anticheat.Vulcan_L), (r0v37 ac.vulcan.anticheat.Vulcan_L) binds: [B:35:0x00b1, B:56:0x0119] A[DONT_GENERATE, DONT_INLINE]
  0x00be: PHI (r13v2 java.lang.Class) = (r13v1 java.lang.Class), (r13v5 java.lang.Class) binds: [B:35:0x00b1, B:56:0x0119] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x011c A[EDGE_INSN: B:70:0x011c->B:57:0x011c BREAK  A[LOOP:0: B:3:0x002d->B:71:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:71:? A[LOOP:0: B:3:0x002d->B:71:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r14v0, types: [ac.vulcan.anticheat.Vulcan_L, java.lang.Exception] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x00fe -> B:55:0x0114). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static ac.vulcan.anticheat.Vulcan_L Vulcan_A(java.lang.Object[] r7) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 285
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.Vulcan_A(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_L");
    }

    public final String Vulcan_C(Object[] objArr) {
        return this.Vulcan_r;
    }

    public Class Vulcan_F(Object[] objArr) {
        return getClass();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public final boolean equals(java.lang.Object r8) {
        /*
            r7 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fK.a
            r1 = 135900749747277(0x7b99dbe9d44d, double:6.7143891694198E-310)
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = Vulcan_p()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L25
            r1 = r7
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r8
        L25:
            r1 = r11
            if (r1 != 0) goto L3b
            if (r0 != 0) goto L3a
            goto L34
        L30:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            throw r0     // Catch: java.lang.IllegalArgumentException -> L36
        L34:
            r0 = 0
            return r0
        L36:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            throw r0
        L3a:
            r0 = r8
        L3b:
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d
            r1 = r11
            if (r1 != 0) goto L68
            r1 = r7
            java.lang.Class r1 = r1.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d java.lang.IllegalArgumentException -> L60
            if (r0 != r1) goto L64
            goto L51
        L4d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0     // Catch: java.lang.IllegalArgumentException -> L60
        L51:
            r0 = r7
            java.lang.String r0 = r0.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L60
            r1 = r8
            ac.vulcan.anticheat.Vulcan_fK r1 = (ac.vulcan.anticheat.Vulcan_fK) r1     // Catch: java.lang.IllegalArgumentException -> L60
            java.lang.String r1 = r1.Vulcan_r     // Catch: java.lang.IllegalArgumentException -> L60
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L60
            return r0
        L60:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0
        L64:
            r0 = r8
            java.lang.Class r0 = r0.getClass()
        L68:
            java.lang.String r0 = r0.getName()     // Catch: java.lang.IllegalArgumentException -> L80
            r1 = r7
            java.lang.Class r1 = r1.getClass()     // Catch: java.lang.IllegalArgumentException -> L80
            java.lang.String r1 = r1.getName()     // Catch: java.lang.IllegalArgumentException -> L80
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L80
            r1 = r11
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L8a
            goto L84
        L80:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L86
            throw r0     // Catch: java.lang.IllegalArgumentException -> L86
        L84:
            r0 = 0
            return r0
        L86:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L86
            throw r0
        L8a:
            r0 = r7
            java.lang.String r0 = r0.Vulcan_r
            r1 = r7
            r2 = r8
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.String r1 = r1.Vulcan_O(r2)
            boolean r0 = r0.equals(r1)
        L9f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        return this.Vulcan_C;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // java.lang.Comparable
    public int compareTo(java.lang.Object r12) {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fK.compareTo(java.lang.Object):int");
    }

    private String Vulcan_O(Object[] objArr) {
        Object obj = objArr[0];
        try {
            Class<?> cls = obj.getClass();
            return (String) cls.getMethod(me.frep.vulcan.spigot.Vulcan_m.b(c[13], cls, (Class[]) null), null).invoke(obj, null);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            throw new IllegalStateException(c[5]);
        }
    }
}
