package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OY.class */
class Vulcan_OY extends C0000Vulcan_Od {
    private String[] Vulcan_W;
    private static final int Vulcan_H = 256;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(801946286878225833L, -7376711311341916114L, null).a(86190114070157L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_OY() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v7, types: [ac.vulcan.anticheat.Vulcan_OY, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v6, types: [ac.vulcan.anticheat.Vulcan_Od, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v11 ??, still in use, count: 2, list:
          (r4v11 ?? I:??[OBJECT, ARRAY][]) from 0x0074: APUT (r4v11 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v11 ?? I:??[OBJECT, ARRAY])
          (r4v11 ?? I:??[OBJECT, ARRAY]) from 0x0074: APUT (r4v11 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v11 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.C0000Vulcan_Od, ac.vulcan.anticheat.Vulcan_fn
    public java.lang.String Vulcan_K(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 68460137890944(0x3e439e334480, double:3.382380224147E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 0
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            r1 = 256(0x100, float:3.59E-43)
            if (r0 >= r1) goto L50
            r0 = r9
            r1 = r14
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L4c
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L4c
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L4c
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L4c
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L4c
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L4c
            r4.<init>(r5)     // Catch: java.lang.RuntimeException -> L4c
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L4c
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L4c
            java.lang.String[] r0 = r0.Vulcan__(r1)     // Catch: java.lang.RuntimeException -> L4c
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.RuntimeException -> L4c
            return r0
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0
        L50:
            r0 = r9
            r1 = r16
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r0 = super.Vulcan_K(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OY.Vulcan_K(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v3, types: [ac.vulcan.anticheat.Vulcan_OY, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x004f]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x004f]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private java.lang.String[] Vulcan__(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OY.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 37443396445159(0x220df85823e7, double:1.84994958471673E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            java.lang.String[] r0 = r0.Vulcan_W     // Catch: java.lang.RuntimeException -> L2f
            r1 = r15
            if (r1 != 0) goto L57
            if (r0 != 0) goto L53
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4f
            throw r0     // Catch: java.lang.RuntimeException -> L4f
        L33:
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L4f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L4f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L4f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L4f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L4f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L4f
            r4.<init>(r5)     // Catch: java.lang.RuntimeException -> L4f
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L4f
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L4f
            r0.Vulcan_Q(r1)     // Catch: java.lang.RuntimeException -> L4f
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L53:
            r0 = r9
            java.lang.String[] r0 = r0.Vulcan_W
        L57:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OY.Vulcan__(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_Od, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:9:0x006f -> B:6:0x0067). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x005f: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x005f: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private void Vulcan_Q(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OY.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 31123051341671(0x1c4e666b6767, double:1.5376830461673E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r11
            r2 = 256(0x100, float:3.59E-43)
            java.lang.String[] r2 = new java.lang.String[r2]
            r1.Vulcan_W = r2
            r17 = r0
            r0 = 0
            r18 = r0
        L2d:
            r0 = r18
            r1 = 256(0x100, float:3.59E-43)
            if (r0 >= r1) goto L6c
            r0 = r11
            java.lang.String[] r0 = r0.Vulcan_W
            r1 = r18
            r2 = r11
            r3 = r15
            r4 = r18
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 1
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 0
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            java.lang.String r2 = super.Vulcan_K(r3)
            r0[r1] = r2
            int r18 = r18 + 1
        L67:
            r0 = r17
            if (r0 == 0) goto L2d
        L6c:
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L67
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OY.Vulcan_Q(java.lang.Object[]):void");
    }
}
