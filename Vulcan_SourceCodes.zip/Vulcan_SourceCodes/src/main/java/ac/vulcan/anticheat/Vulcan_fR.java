package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fR.class */
public class Vulcan_fR {
    private boolean Vulcan_j = true;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-9188707707918746638L, -8908340083259629213L, null).a(31629551898837L);
    private static final String b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0058: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_P(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 71612674569878(0x4121a0077696, double:3.5381362311786E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r14
            r2 = r15
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_P(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0061: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_G(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 22644899037062(0x14986d29bf86, double:1.1188066667756E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r15
            r2 = r16
            r3 = 0
            r4 = 0
            r5 = r12
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_G(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0064: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_E(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 41675902177082(0x25e76d584f3a, double:2.05906315251366E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r17
            r1 = r14
            r2 = r13
            r3 = r12
            r4 = 0
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_E(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x006d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_b(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 98423494644143(0x5984016f91af, double:4.8627667447311E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r18
            r1 = r16
            r2 = r17
            r3 = r12
            r4 = r15
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_b(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0023, code lost:
    
        r1 = "$\u0004PJkYB\u0005\u000fQ\u0012RPM\u0014\rT^Z_B\u0014\u0019Fwc_D\u0001\u001e\\]u".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 78;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0031, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0034, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0037, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003e, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 63;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0034). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -9188707707918746638(0x807b2706049bfbf2, double:-2.4166469839292507E-306)
            r1 = -8908340083259629213(0x845f37e486efa163, double:-1.2813678763025172E-287)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 31629551898837(0x1cc4543490d5, double:1.5627074986568E-310)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_fR.a = r0
            r0 = 78
            java.lang.String r1 = "$\u0004PJkYB\u0005\u000fQ\u0012RPM\u0014\rT^Z_B\u0014\u0019Fwc_D\u0001\u001e\\]u"
            r2 = jsr -> L23
        L1d:
            ac.vulcan.anticheat.Vulcan_fR.b = r2
            goto Lab
        L23:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L34:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L37:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 63
            goto L84
        L69:
            r8 = 36
            goto L84
        L6e:
            r8 = 123(0x7b, float:1.72E-43)
            goto L84
        L73:
            r8 = 124(0x7c, float:1.74E-43)
            goto L84
        L78:
            r8 = 85
            goto L84
        L7d:
            r8 = 114(0x72, float:1.6E-43)
            goto L84
        L82:
            r8 = 111(0x6f, float:1.56E-43)
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L37
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L34
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.m202clinit():void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static boolean Vulcan__(java.lang.Object[] r13) {
        /*
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 91518006477186(0x533c32444182, double:4.52159029762543E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r1 = r0; r2 = r0; 
            r2 = 43024063584187(0x27215206d7bb, double:2.1256711761436E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r14
            r1 = r21
            r2 = r18
            r3 = r17
            r4 = r19
            r5 = 2
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 1
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 0
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            java.lang.String[] r3 = ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_r(r3)
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_G(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan__(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_h(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 575
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_h(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v35, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v39, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v46, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r1v15, types: [ac.vulcan.anticheat.Vulcan_fR, java.lang.Long] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v12, types: [ac.vulcan.anticheat.Vulcan_fR, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v19, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:61:0x018d -> B:7:0x007c). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x00b0: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalAccessException -> 0x00bf, IllegalAccessException -> 0x00dc]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x00b0: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalAccessException -> 0x00bf, IllegalAccessException -> 0x00dc]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private static void Vulcan_R(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 401
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_R(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    public Vulcan_fR Vulcan_H(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        long j = a ^ jLongValue;
        ?? A = this;
        if (Vulcan_fl.Vulcan_F() == 0) {
            return A;
        }
        try {
            try {
                A = A.Vulcan_j;
                if (A == 0) {
                    return this;
                }
                this.Vulcan_j = zBooleanValue;
                return this;
            } catch (IllegalArgumentException unused) {
                A = a(A);
                throw A;
            }
        } catch (IllegalArgumentException unused2) {
            throw a(A);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_Y(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1218
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_Y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v12, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public Vulcan_fR Vulcan_C(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        long jLongValue2 = ((Long) objArr[1]).longValue();
        long jLongValue3 = a ^ ((Long) objArr[2]).longValue();
        ?? Vulcan_F = Vulcan_fl.Vulcan_F();
        try {
            Vulcan_F = this;
            ?? r0 = Vulcan_F;
            if (Vulcan_F != 0) {
                try {
                    Vulcan_F = Vulcan_F.Vulcan_j;
                    if (Vulcan_F == 0) {
                        return this;
                    }
                    r0 = this;
                } catch (IllegalArgumentException unused) {
                    throw a(Vulcan_F);
                }
            }
            int i = (jLongValue > jLongValue2 ? 1 : (jLongValue == jLongValue2 ? 0 : -1));
            ?? r1 = i;
            if (Vulcan_F != 0) {
                r1 = i == 0 ? 1 : 0;
            }
            r0.Vulcan_j = r1;
            return this;
        } catch (IllegalArgumentException unused2) {
            throw a(Vulcan_F);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_v(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r0 = r10
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r8
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r9
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_fR.a
            long r0 = r0 ^ r1
            r13 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r15 = r0
            r0 = r6
            r1 = r15
            if (r1 == 0) goto L74
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L69 java.lang.IllegalArgumentException -> L6f
            if (r0 != 0) goto L73
            goto L6d
        L69:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6f
        L6d:
            r0 = r6
            return r0
        L6f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6f
            throw r0
        L73:
            r0 = r6
        L74:
            r1 = r12
            r2 = r15
            r3 = r9
            if (r3 <= 0) goto L81
            if (r2 == 0) goto L93
            r2 = r11
        L81:
            if (r1 != r2) goto L96
            goto L8b
        L87:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8f
        L8b:
            r1 = 1
            goto L93
        L8f:
            java.lang.Exception r0 = a(r0)
            throw r0
        L93:
            goto L97
        L96:
            r1 = 0
        L97:
            r0.Vulcan_j = r1
            r0 = r6
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_v(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_y(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L48
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L3d java.lang.IllegalArgumentException -> L43
            if (r0 != 0) goto L47
            goto L41
        L3d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0     // Catch: java.lang.IllegalArgumentException -> L43
        L41:
            r0 = r8
            return r0
        L43:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0
        L47:
            r0 = r8
        L48:
            r1 = r10
            r2 = r14
            r3 = r12
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L56
            if (r2 != 0) goto L68
            r2 = r11
        L56:
            if (r1 != r2) goto L6b
            goto L60
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L64
            throw r0     // Catch: java.lang.IllegalArgumentException -> L64
        L60:
            r1 = 1
            goto L68
        L64:
            java.lang.Exception r0 = a(r0)
            throw r0
        L68:
            goto L6c
        L6b:
            r1 = 0
        L6c:
            r0.Vulcan_j = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_s(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 == 0) goto L46
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L3b java.lang.IllegalArgumentException -> L41
            if (r0 != 0) goto L45
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L41
            throw r0     // Catch: java.lang.IllegalArgumentException -> L41
        L3f:
            r0 = r8
            return r0
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L41
            throw r0
        L45:
            r0 = r8
        L46:
            r1 = r10
            r2 = r14
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L54
            if (r2 == 0) goto L66
            r2 = r13
        L54:
            if (r1 != r2) goto L69
            goto L5e
        L5a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L62
            throw r0     // Catch: java.lang.IllegalArgumentException -> L62
        L5e:
            r1 = 1
            goto L66
        L62:
            java.lang.Exception r0 = a(r0)
            throw r0
        L66:
            goto L6a
        L69:
            r1 = 0
        L6a:
            r0.Vulcan_j = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_s(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_r(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L48
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L3d java.lang.IllegalArgumentException -> L43
            if (r0 != 0) goto L47
            goto L41
        L3d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0     // Catch: java.lang.IllegalArgumentException -> L43
        L41:
            r0 = r8
            return r0
        L43:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0
        L47:
            r0 = r8
        L48:
            r1 = r10
            r2 = r14
            r3 = r12
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L56
            if (r2 != 0) goto L68
            r2 = r11
        L56:
            if (r1 != r2) goto L6b
            goto L60
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L64
            throw r0     // Catch: java.lang.IllegalArgumentException -> L64
        L60:
            r1 = 1
            goto L68
        L64:
            java.lang.Exception r0 = a(r0)
            throw r0
        L68:
            goto L6c
        L6b:
            r1 = 0
        L6c:
            r0.Vulcan_j = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_r(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_fR, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_B(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r19 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 111093557323603(0x6509fc056753, double:5.48875101478875E-310)
            long r1 = r1 ^ r2
            r21 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r23 = r0
            r0 = r13
            r1 = r23
            if (r1 != 0) goto L92
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L48 java.lang.IllegalArgumentException -> L4e
            if (r0 != 0) goto L52
            goto L4c
        L48:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4e
        L4c:
            r0 = r13
            return r0
        L4e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4e
            throw r0
        L52:
            r0 = r13
            r1 = r15
            long r1 = java.lang.Double.doubleToLongBits(r1)
            r2 = r19
            long r2 = java.lang.Double.doubleToLongBits(r2)
            r3 = r21
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_fR r0 = r0.Vulcan_C(r1)
        L92:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_B(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fR] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    public Vulcan_fR Vulcan_D(Object[] objArr) throws Exception {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        long j = jLongValue ^ 7029690074820L;
        int i = (int) (jLongValue >>> 48);
        int i2 = (int) ((j << 16) >>> 32);
        int i3 = (int) ((j << 48) >>> 48);
        ?? Vulcan_F = Vulcan_fl.Vulcan_F();
        try {
            Vulcan_F = this;
            if (Vulcan_F == 0) {
                return Vulcan_F;
            }
            try {
                Vulcan_F = Vulcan_F.Vulcan_j;
                if (Vulcan_F == 0) {
                    return this;
                }
                return Vulcan_v(new Object[]{new Integer((char) i), new Integer(i2), new Integer((char) i3), new Integer(Float.floatToIntBits(fFloatValue)), new Integer(Float.floatToIntBits(fFloatValue2))});
            } catch (IllegalArgumentException unused) {
                throw a(Vulcan_F);
            }
        } catch (IllegalArgumentException unused2) {
            throw a(Vulcan_F);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_fR m203Vulcan_R(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fR.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L48
            boolean r0 = r0.Vulcan_j     // Catch: java.lang.IllegalArgumentException -> L3d java.lang.IllegalArgumentException -> L43
            if (r0 != 0) goto L47
            goto L41
        L3d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0     // Catch: java.lang.IllegalArgumentException -> L43
        L41:
            r0 = r8
            return r0
        L43:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L43
            throw r0
        L47:
            r0 = r8
        L48:
            r1 = r10
            r2 = r14
            r3 = r12
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L56
            if (r2 != 0) goto L68
            r2 = r11
        L56:
            if (r1 != r2) goto L6b
            goto L60
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L64
            throw r0     // Catch: java.lang.IllegalArgumentException -> L64
        L60:
            r1 = 1
            goto L68
        L64:
            java.lang.Exception r0 = a(r0)
            throw r0
        L68:
            goto L6c
        L6b:
            r1 = 0
        L6c:
            r0.Vulcan_j = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.m203Vulcan_R(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_x(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_x(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_S(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_S(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_Z(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 427
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_Z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_X(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 370
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_X(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_L(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 370
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_L(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_I(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_I(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_M(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 370
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_M(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_fR m204Vulcan_P(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 364
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.m204Vulcan_P(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_fR Vulcan_f(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fR.Vulcan_f(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fR");
    }

    public boolean Vulcan_V(Object[] objArr) {
        return this.Vulcan_j;
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    protected void m205Vulcan_X(Object[] objArr) {
        this.Vulcan_j = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public void m206Vulcan_r(Object[] objArr) {
        this.Vulcan_j = true;
    }
}
