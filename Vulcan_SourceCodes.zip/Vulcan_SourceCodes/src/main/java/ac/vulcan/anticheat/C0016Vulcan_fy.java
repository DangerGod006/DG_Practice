package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fy, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fy.class */
public class C0016Vulcan_fy {
    public static final Vulcan_Ob Vulcan_y;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-7334336015889014597L, -7982810057246174723L, null).a(195775036384289L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0042: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_b(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 65603767095583(0x3baa913bd11f, double:3.2412567559698E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r13
            r1 = r12
            r2 = r11
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.NullPointerException -> L5f
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.NullPointerException -> L5f
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L5f
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L5f
            r3[r4] = r5     // Catch: java.lang.NullPointerException -> L5f
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L5f
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L5f
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L5f
            r2[r3] = r4     // Catch: java.lang.NullPointerException -> L5f
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.NullPointerException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NullPointerException -> L5f
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.NullPointerException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NullPointerException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NullPointerException -> L5f
            r3.<init>(r4)     // Catch: java.lang.NullPointerException -> L5f
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L5f
            r1[r2] = r3     // Catch: java.lang.NullPointerException -> L5f
            boolean r0 = Vulcan_N(r0)     // Catch: java.lang.NullPointerException -> L5f
            r1 = r15
            if (r1 != 0) goto L64
            if (r0 != 0) goto L67
            goto L63
        L5f:
            java.lang.Exception r0 = a(r0)
            throw r0
        L63:
            r0 = 1
        L64:
            goto L68
        L67:
            r0 = 0
        L68:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_b(java.lang.Object[]):boolean");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0085, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0088, code lost:
    
        r11 = "_ZW\u0007<\u001c\u007fWV\u00076d4_ZW\u0007<0WPYV\f8rxY\u0016L\u0010)u4".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0091, code lost:
    
        ac.vulcan.anticheat.C0016Vulcan_fy.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_y = new ac.vulcan.anticheat.Vulcan_Ob();
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0132, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0099, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00a9, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00b8, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e0, code lost:
    
        r7 = 54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e5, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        r7 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ef, code lost:
    
        r7 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f4, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f9, code lost:
    
        r7 = 26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00fe, code lost:
    
        r7 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "_ZW\u0007<\u001c\u007fWV\u00076d4_ZW\u0007<0WPYV\f8rxY\u0016L\u0010)u4".length();
        r11 = 5;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0065, code lost:
    
        r10 = r10 + 1;
        "_ZW\u0007<\u001c\u007fWV\u00076d4_ZW\u0007<0WPYV\f8rxY\u0016L\u0010)u4".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0075, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ac, B:28:0x0110], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v18 */
    /* JADX WARN: Type inference failed for: r5v28 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ac). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0115 -> B:35:0x00ac). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 307
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.m408clinit():void");
    }

    public static Object Vulcan_x(Object[] objArr) {
        Object obj = objArr[0];
        Object obj2 = objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        if (Vulcan_fX.Vulcan_k() == null) {
            return obj != null ? obj : obj2;
        }
        return obj;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_N(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r8
            r1 = r12
            if (r1 != 0) goto L3f
            r1 = r11
            if (r0 != r1) goto L3e
            goto L38
        L34:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L3a
            throw r0     // Catch: java.lang.NullPointerException -> L3a
        L38:
            r0 = 1
            return r0
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L3a
            throw r0
        L3e:
            r0 = r8
        L3f:
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L58
            if (r1 != 0) goto L56
            if (r0 == 0) goto L6b
            goto L54
        L50:
            java.lang.Exception r0 = a(r0)
            throw r0
        L54:
            r0 = r11
        L56:
            r1 = r12
        L58:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L74
            if (r1 != 0) goto L72
            if (r0 != 0) goto L71
            goto L6b
        L67:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6d
            throw r0     // Catch: java.lang.NullPointerException -> L6d
        L6b:
            r0 = 0
            return r0
        L6d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6d
            throw r0
        L71:
            r0 = r8
        L72:
            r1 = r11
        L74:
            boolean r0 = r0.equals(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_N(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_R(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L37
            if (r0 != 0) goto L36
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L32
            throw r0     // Catch: java.lang.NullPointerException -> L32
        L2e:
            r0 = 0
            goto L3a
        L32:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L32
            throw r0
        L36:
            r0 = r6
        L37:
            int r0 = r0.hashCode()
        L3a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_R(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v5 ?? I:java.lang.StringBuffer) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.lang.String Vulcan_q(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v5 ?? I:java.lang.StringBuffer) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception, java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static void Vulcan_D(Object[] objArr) throws Exception {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        Object obj = objArr[2];
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            if (Vulcan_k == 0) {
                if (obj == null) {
                    throw new NullPointerException(b[2]);
                }
                stringBuffer.append(obj.getClass().getName()).append('@').append(Integer.toHexString(System.identityHashCode(obj)));
            }
        } catch (NullPointerException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public static StringBuffer m409Vulcan_N(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        Object obj = objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        if (obj == null) {
            return null;
        }
        if (strVulcan_k == null) {
            if (stringBuffer == null) {
                stringBuffer = new StringBuffer();
            }
            return stringBuffer.append(obj.getClass().getName()).append('@').append(Integer.toHexString(System.identityHashCode(obj)));
        }
        return stringBuffer;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public static java.lang.String m410Vulcan_b(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L38
            if (r0 != 0) goto L37
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L33
            throw r0     // Catch: java.lang.NullPointerException -> L33
        L2e:
            java.lang.String r0 = ""
            goto L3b
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L33
            throw r0
        L37:
            r0 = r8
        L38:
            java.lang.String r0 = r0.toString()
        L3b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.m410Vulcan_b(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_a(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r7
            r1 = r10
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L3d
            goto L35
        L31:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L39
            throw r0     // Catch: java.lang.NullPointerException -> L39
        L35:
            r0 = r6
            goto L41
        L39:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L39
            throw r0
        L3d:
            r0 = r7
        L3e:
            java.lang.String r0 = r0.toString()
        L41:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_a(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x006d, NullPointerException -> 0x0075]
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x006d, NullPointerException -> 0x0075]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public static java.lang.Object m411Vulcan_a(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 16719244137523(0xf34c09b9433, double:8.260404152783E-311)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r13
            r1 = r17
            if (r1 != 0) goto L79
            r1 = r14
            r2 = r15
            r3 = 1
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            java.lang.Boolean r6 = new java.lang.Boolean     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r6.<init>(r7)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r4[r5] = r6     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r5.<init>(r6)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r3[r4] = r5     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r2[r3] = r4     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            r1[r2] = r3     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            int r0 = Vulcan_C(r0)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L75
            if (r0 > 0) goto L7c
            goto L71
        L6d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L75
            throw r0     // Catch: java.lang.NullPointerException -> L75
        L71:
            r0 = r13
            goto L79
        L75:
            java.lang.Exception r0 = a(r0)
            throw r0
        L79:
            goto L7e
        L7c:
            r0 = r14
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.m411Vulcan_a(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x006d, NullPointerException -> 0x0076]
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x006d, NullPointerException -> 0x0076]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public static java.lang.Object m412Vulcan_R(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 62107571952273(0x387c8bc39a91, double:3.06852176482314E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r17
            if (r1 != 0) goto L7a
            r1 = r13
            r2 = r15
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            java.lang.Boolean r6 = new java.lang.Boolean     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r6.<init>(r7)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r4[r5] = r6     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r5.<init>(r6)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r3[r4] = r5     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r2[r3] = r4     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            r1[r2] = r3     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            int r0 = Vulcan_C(r0)     // Catch: java.lang.NullPointerException -> L6d java.lang.NullPointerException -> L76
            if (r0 < 0) goto L7d
            goto L71
        L6d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L76
            throw r0     // Catch: java.lang.NullPointerException -> L76
        L71:
            r0 = r14
            goto L7a
        L76:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7a:
            goto L7e
        L7d:
            r0 = r13
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.m412Vulcan_R(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_B(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 102797162700532(0x5d7e545ddef4, double:5.0788546580286E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r13
            r2 = r15
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_C(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_B(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_C(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r12
            r1 = r13
            if (r1 != 0) goto L4c
            r1 = r11
            if (r0 != r1) goto L4a
            goto L44
        L40:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L46
            throw r0     // Catch: java.lang.NullPointerException -> L46
        L44:
            r0 = 0
            return r0
        L46:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L46
            throw r0
        L4a:
            r0 = r12
        L4c:
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L82
            if (r1 != 0) goto L80
            if (r0 != 0) goto L7e
            goto L61
        L5d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6a
            throw r0     // Catch: java.lang.NullPointerException -> L6a
        L61:
            r0 = r8
            r1 = r13
            if (r1 != 0) goto L79
            goto L6e
        L6a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L74
            throw r0     // Catch: java.lang.NullPointerException -> L74
        L6e:
            if (r0 == 0) goto L7c
            goto L78
        L74:
            java.lang.Exception r0 = a(r0)
            throw r0
        L78:
            r0 = 1
        L79:
            goto L7d
        L7c:
            r0 = -1
        L7d:
            return r0
        L7e:
            r0 = r11
        L80:
            r1 = r13
        L82:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto Lb6
            if (r1 != 0) goto Lb4
            if (r0 != 0) goto Lb2
            goto L95
        L91:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L9e
            throw r0     // Catch: java.lang.NullPointerException -> L9e
        L95:
            r0 = r8
            r1 = r13
            if (r1 != 0) goto Lad
            goto La2
        L9e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> La8
            throw r0     // Catch: java.lang.NullPointerException -> La8
        La2:
            if (r0 == 0) goto Lb0
            goto Lac
        La8:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lac:
            r0 = -1
        Lad:
            goto Lb1
        Lb0:
            r0 = 1
        Lb1:
            return r0
        Lb2:
            r0 = r12
        Lb4:
            r1 = r11
        Lb6:
            int r0 = r0.compareTo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_C(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v46, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r16v0 */
    /* JADX WARN: Type inference failed for: r16v1 */
    /* JADX WARN: Type inference failed for: r16v2 */
    /* JADX WARN: Type inference failed for: r16v3 */
    /* JADX WARN: Type inference failed for: r16v4 */
    /* JADX WARN: Type inference failed for: r16v5 */
    /* JADX WARN: Type inference failed for: r16v7 */
    /* JADX WARN: Type inference failed for: r16v8 */
    /* JADX WARN: Type inference failed for: r18v0, types: [int] */
    /* JADX WARN: Type inference failed for: r18v1, types: [int] */
    /* JADX WARN: Type inference failed for: r18v2, types: [int] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v12 ??, still in use, count: 2, list:
          (r4v12 ?? I:??[OBJECT, ARRAY][]) from 0x0107: APUT (r4v12 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v12 ?? I:??[OBJECT, ARRAY]) A[Catch: NoSuchMethodException -> 0x0115, IllegalAccessException -> 0x0148, InvocationTargetException -> 0x0174]
          (r4v12 ?? I:??[OBJECT, ARRAY]) from 0x0107: APUT (r4v12 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v12 ?? I:??[OBJECT, ARRAY]) A[Catch: NoSuchMethodException -> 0x0115, IllegalAccessException -> 0x0148, InvocationTargetException -> 0x0174]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_W(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 420
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_W(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_V(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0016Vulcan_fy.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 30113996416791(0x1b63760f2717, double:1.4878291088523E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r11
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Object r1 = Vulcan_W(r1)
            r17 = r1
            r16 = r0
            r0 = r17
            r1 = r16
            if (r1 != 0) goto L59
            if (r0 != 0) goto L5c
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)
            throw r0
        L58:
            r0 = r11
        L59:
            goto L5e
        L5c:
            r0 = r17
        L5e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_V(java.lang.Object[]):java.lang.Object");
    }
}
