package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_k3.class */
final class Vulcan_k3 extends Vulcan_kH {
    private final char[] Vulcan_B;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_k3(String str) {
        this.Vulcan_B = str.toCharArray();
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x006b, code lost:
    
        if (r0 < r7.Vulcan_B.length) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x006e, code lost:
    
        r0 = r7.Vulcan_B[r17 == true ? 1 : 0];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x007a, code lost:
    
        if (r1 <= 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x007d, code lost:
    
        if (r1 == 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0080, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0082, code lost:
    
        if (r1 == 0) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0088, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x008b, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x008f, code lost:
    
        if (r1 <= 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0096, code lost:
    
        if (r0 == r1[r9]) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x009f, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00a8, code lost:
    
        return 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00a9, code lost:
    
        r17 = r17 + 1;
        r9 = r9 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00b1, code lost:
    
        if (r0 != 0) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00b4, code lost:
    
        r0 = (r1 > 0 ? 1 : (r1 == 0 ? 0 : -1));
        r0 = r0;
        r17 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00b7, code lost:
    
        if (r0 < 0) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00bc, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00b4, code lost:
    
        if (r0 != 0) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:44:0x006e, B:40:0x00b4], limit reached: 58 */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0054  */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [char, int] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r17v0 */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2, types: [int] */
    /* JADX WARN: Type inference failed for: r17v3, types: [int] */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Type inference failed for: r17v5 */
    /* JADX WARN: Type inference failed for: r17v6 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v35 */
    /* JADX WARN: Type inference failed for: r1v37 */
    /* JADX WARN: Type inference failed for: r1v39 */
    /* JADX WARN: Type inference failed for: r1v40 */
    @Override // ac.vulcan.anticheat.Vulcan_kH
    /* JADX INFO: renamed from: Vulcan_A */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int mo437Vulcan_A(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_W()
            r1 = r7
            char[] r1 = r1.Vulcan_B
            int r1 = r1.length
            r16 = r1
            r15 = r0
            r0 = r9
            r1 = r16
            int r0 = r0 + r1
            r1 = r15
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L51
            if (r1 == 0) goto L62
            r1 = r14
        L51:
            if (r0 <= r1) goto L61
            goto L5b
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5d
            throw r0     // Catch: java.lang.RuntimeException -> L5d
        L5b:
            r0 = 0
            return r0
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5d
            throw r0
        L61:
            r0 = 0
        L62:
            r17 = r0
        L64:
            r0 = r17
            r1 = r7
            char[] r1 = r1.Vulcan_B
            int r1 = r1.length
            if (r0 >= r1) goto Lb4
        L6e:
            r0 = r7
            char[] r0 = r0.Vulcan_B     // Catch: java.lang.RuntimeException -> L88
            r1 = r17
            char r0 = r0[r1]     // Catch: java.lang.RuntimeException -> L88
            r1 = r15
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L82
            if (r1 == 0) goto Lbc
            r1 = r15
        L82:
            if (r1 == 0) goto La8
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L9c
            throw r0     // Catch: java.lang.RuntimeException -> L9c
        L8c:
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lb1
            r1 = r13
            r2 = r9
            char r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La4
            if (r0 == r1) goto La9
            goto La0
        L9c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> La4
            throw r0     // Catch: java.lang.RuntimeException -> La4
        La0:
            r0 = 0
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            return r0
        La9:
            int r17 = r17 + 1
            int r9 = r9 + 1
            r0 = r15
        Lb1:
            if (r0 != 0) goto L64
        Lb4:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L6e
            r0 = r16
        Lbc:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_k3.mo437Vulcan_A(java.lang.Object[]):int");
    }
}
