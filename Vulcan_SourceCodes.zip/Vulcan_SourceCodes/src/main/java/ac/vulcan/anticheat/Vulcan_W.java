package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_W.class */
public class Vulcan_W {
    private static int Vulcan_L;

    public static void Vulcan_R(int i) {
        Vulcan_L = i;
    }

    public static int Vulcan_G() {
        return Vulcan_L;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_p() {
        return Vulcan_G() == 0 ? 20 : 0;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    static {
        if (Vulcan_p() != 0) {
            Vulcan_R(41);
        }
    }

    public static boolean Vulcan_T(Object[] objArr) {
        try {
            Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }
}
