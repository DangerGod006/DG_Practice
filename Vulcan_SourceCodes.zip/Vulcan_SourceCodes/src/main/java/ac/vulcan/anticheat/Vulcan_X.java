package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_X.class */
public class Vulcan_X {
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-482767748033491933L, -4541238184038317253L, null).a(185119308123186L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00da: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_k(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 364
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_k(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00d8: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_a(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 362
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_a(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0034: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_n(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 133518846243836(0x796f4766b3fc, double:6.5967075001439E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r9
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_n(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00dd: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_Y(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 339
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_Y(java.lang.Object[]):java.lang.String");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_d(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 129364564144270(0x75a808e4708e, double:6.391458693291E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r13
            r1 = r16
            r2 = 0
            r3 = 0
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_w(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_d(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_w(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 484
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_w(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_I(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 21740145270739(0x13c5c5a2dfd3, double:1.074105891387E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_k(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_I(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_x(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 96152649217875(0x577348803753, double:4.7505720735176E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = 0
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_b(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_x(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_b(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 46741327890490(0x2a82d03ec83a, double:2.30932843516924E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r12
            r1 = r16
            if (r1 != 0) goto L48
            if (r0 != 0) goto L47
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L43
            throw r0     // Catch: java.lang.RuntimeException -> L43
        L3f:
            r0 = -1
            goto L49
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L43
            throw r0
        L47:
            r0 = r12
        L48:
            int r0 = r0.length
        L49:
            r17 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L98
            if (r0 == 0) goto L8f
            goto L5c
        L58:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L66
            throw r0     // Catch: java.lang.RuntimeException -> L66
        L5c:
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L98
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L79
            throw r0     // Catch: java.lang.RuntimeException -> L79
        L6a:
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L91
            int r0 = r0.length()     // Catch: java.lang.RuntimeException -> L79 java.lang.RuntimeException -> L8b
            if (r0 == 0) goto L8f
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L8b
            throw r0     // Catch: java.lang.RuntimeException -> L8b
        L7d:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto La0
            r0 = r17
            if (r0 != 0) goto L99
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L94
            throw r0     // Catch: java.lang.RuntimeException -> L94
        L8f:
            r0 = r13
        L91:
            goto L98
        L94:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L98:
            return r0
        L99:
            r0 = r13
            java.lang.String r0 = r0.toLowerCase()
            r13 = r0
        La0:
            r0 = r13
            r1 = r14
            r2 = r12
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_k(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_b(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_B(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 28579678565401(0x19fe3996b419, double:1.412023734835E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_a(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_B(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_K(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 354
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_K(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0043, code lost:
    
        if (r13 < r0) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0046, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x004c, code lost:
    
        if (r0 <= 0) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x004f, code lost:
    
        if (r1 != null) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0052, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0054, code lost:
    
        if (r1 != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0063, code lost:
    
        if (r1 != r1[r13]) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x006c, code lost:
    
        throw a(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0074, code lost:
    
        throw a(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0075, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0076, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007b, code lost:
    
        if (r0 == null) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r0 < 0) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0084, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:?, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:?, code lost:
    
        return r1;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:12:0x0046, B:31:0x007e], limit reached: 42 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v7, types: [boolean, char, int, java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x0081 -> B:12:0x0046). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static boolean Vulcan_u(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_X.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r11
            if (r0 != 0) goto L37
            r0 = r10
            boolean r0 = java.lang.Character.isWhitespace(r0)     // Catch: java.lang.RuntimeException -> L33
            return r0
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0
        L37:
            r0 = 0
            r13 = r0
            r0 = r11
            int r0 = r0.length
            r14 = r0
        L3f:
            r0 = r13
            r1 = r14
            if (r0 >= r1) goto L7e
        L46:
            r0 = r10
            r1 = r12
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L54
            if (r1 != 0) goto L85
            r1 = r12
        L54:
            if (r1 != 0) goto L75
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L69
            throw r0     // Catch: java.lang.RuntimeException -> L69
        L5e:
            r1 = r11
            r2 = r13
            char r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L69 java.lang.RuntimeException -> L71
            if (r0 != r1) goto L76
            goto L6d
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L71
            throw r0     // Catch: java.lang.RuntimeException -> L71
        L6d:
            r0 = 1
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L75:
            return r0
        L76:
            int r13 = r13 + 1
            r0 = r12
            if (r0 == 0) goto L3f
        L7e:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L46
            r0 = 0
        L85:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_u(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_r(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 569
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_X.Vulcan_r(java.lang.Object[]):java.lang.String");
    }
}
