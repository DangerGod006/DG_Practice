package ac.vulcan.anticheat;

import java.util.Calendar;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_s.class */
class Vulcan_s implements InterfaceC0031Vulcan_n {
    private final int Vulcan_V;
    private final String[] Vulcan_G;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_s(int i, String[] strArr) {
        this.Vulcan_V = i;
        this.Vulcan_G = strArr;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r1 = 0
            r12 = r1
            r11 = r0
            r0 = r7
            java.lang.String[] r0 = r0.Vulcan_G
            int r0 = r0.length
            r13 = r0
        L1b:
            int r13 = r13 + (-1)
            r0 = r13
            if (r0 < 0) goto L64
            r0 = r7
            java.lang.String[] r0 = r0.Vulcan_G
            r1 = r13
            r0 = r0[r1]
            int r0 = r0.length()
            r14 = r0
            r0 = r14
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L3e
            if (r1 != 0) goto L66
            r1 = r11
        L3e:
            if (r1 != 0) goto L5d
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L50
            throw r0     // Catch: java.lang.RuntimeException -> L50
        L48:
            r1 = r12
            if (r0 <= r1) goto L5f
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L59
            throw r0     // Catch: java.lang.RuntimeException -> L59
        L54:
            r0 = r14
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5d:
            r12 = r0
        L5f:
            r0 = r11
            if (r0 == 0) goto L1b
        L64:
            r0 = r12
        L66:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_s.Vulcan_r(java.lang.Object[]):int");
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        Calendar calendar = (Calendar) objArr[1];
        ((Long) objArr[2]).longValue();
        stringBuffer.append(this.Vulcan_G[calendar.get(this.Vulcan_V)]);
    }
}
