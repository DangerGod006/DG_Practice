package ac.vulcan.anticheat;

import java.io.File;
import java.io.PrintStream;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fg.class */
public class Vulcan_fg {
    private static final int Vulcan__f = 3;
    private static final String Vulcan_q;
    private static final String Vulcan__;
    private static final String Vulcan__X;
    private static final String Vulcan__I;
    private static final String Vulcan__Y;
    public static final String Vulcan_X;
    public static final String Vulcan_U;
    public static final String Vulcan_u;
    public static final String Vulcan_i;
    public static final String Vulcan_m;
    public static final String Vulcan_d;
    public static final String Vulcan___;
    public static final String Vulcan_A;
    public static final String Vulcan_r;
    public static final String Vulcan__G;
    public static final String Vulcan_T;
    public static final String Vulcan_t;
    public static final String Vulcan_x;
    public static final String Vulcan_p;
    public static final String Vulcan_P;
    public static final String Vulcan_I;
    public static final String Vulcan_l;
    public static final String Vulcan__m;
    public static final String Vulcan_g;
    public static final String Vulcan_f;
    public static final String Vulcan_s;
    public static final String Vulcan_z;
    public static final String Vulcan__V;
    public static final String Vulcan_G;
    public static final String Vulcan_V;
    public static final String Vulcan__K;
    public static final String Vulcan__h;
    public static final String Vulcan__z;
    public static final String Vulcan_y;
    public static final String Vulcan_b;
    public static final String Vulcan_Q;
    public static final String Vulcan_F;
    public static final String Vulcan_w;
    public static final String Vulcan_J;
    public static final String Vulcan__5;
    public static final String Vulcan_c;
    public static final String Vulcan_N;
    public static final String Vulcan__i;
    public static final String Vulcan__P;
    public static final String Vulcan_a;
    public static final String Vulcan_j;
    public static final String Vulcan_Y;
    public static final String Vulcan_O;
    public static final float Vulcan_L;
    public static final int Vulcan_v;
    public static final boolean Vulcan_H;
    public static final boolean Vulcan_K;
    public static final boolean Vulcan_n;
    public static final boolean Vulcan__b;
    public static final boolean Vulcan_Z;
    public static final boolean Vulcan_R;
    public static final boolean Vulcan__d;
    public static final boolean Vulcan_e;
    public static final boolean Vulcan__U;
    public static final boolean Vulcan_D;
    public static final boolean Vulcan__J;
    public static final boolean Vulcan_E;
    public static final boolean Vulcan_k;
    public static final boolean Vulcan__a;
    public static final boolean Vulcan_W;
    public static final boolean Vulcan_M;
    public static final boolean Vulcan__1;
    public static final boolean Vulcan_h;
    public static final boolean Vulcan_B;
    public static final boolean Vulcan__v;
    public static final boolean Vulcan__4;
    public static final boolean Vulcan__g;
    public static final boolean Vulcan_S;
    public static final boolean Vulcan_o;
    public static final boolean Vulcan_C;
    public static final boolean Vulcan__8;
    private static final long a;
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static float Vulcan_Z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 47229354846851(0x2af470eb2a83, double:2.3334401705075E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r1 = r0; r2 = r0; 
            r2 = 25994277376618(0x17a443ab526a, double:1.28428794402553E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r12
            java.lang.String r1 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_G
            r2 = 3
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m383Vulcan_p(r0)
            r1 = r14
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = Vulcan_M(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_Z(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    private static int m380Vulcan_j(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 34660770886458(0x1f8616efb33a, double:1.71246961533733E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r1 = r0; r2 = r0; 
            r2 = 120186935827518(0x6d4f339ddc3e, double:5.9380236071303E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r14
            java.lang.String r1 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_G
            r2 = 3
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m383Vulcan_p(r0)
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m384Vulcan_Z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.m380Vulcan_j(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0036: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static boolean Vulcan_e(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 78207934429819(0x472134267a7b, double:3.86398536339784E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            java.lang.String r1 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_J
            r2 = r9
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = m382Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_e(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0043: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    static float Vulcan_o(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 69005147613394(0x3ec2834fa8d2, double:3.4093072821982E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 3928553934907(0x392b00fd03b, double:1.940963537072E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = r10
            r2 = 3
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m383Vulcan_p(r0)
            r1 = r15
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = Vulcan_M(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_o(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0071: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    static int Vulcan_U(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r0 = r13
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r11
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r12
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_fg.a
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 1065971932182(0xf830e0dc16, double:5.26660111122E-312)
            long r1 = r1 ^ r2
            r16 = r1
            r1 = r0; r2 = r0; 
            r2 = 125555140899602(0x72311592b312, double:6.20324817772506E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r18
            r1 = r10
            r2 = 3
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m383Vulcan_p(r0)
            r1 = r16
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = m384Vulcan_Z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_U(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    static int[] Vulcan_J(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 73420627358144(0x42c69269b1c0, double:3.6274609673771E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r10
            r2 = 2147483647(0x7fffffff, float:NaN)
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int[] r0 = m383Vulcan_p(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_J(java.lang.Object[]):int[]");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:102:0x0170 -> B:88:0x010b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0170 -> B:15:0x010b). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v235 ??, still in use, count: 1, list:
          (r5v235 ?? I:java.lang.Object[]) from 0x0536: INVOKE (r4v197 ?? I:java.lang.String) = (r5v235 ?? I:java.lang.Object[]) STATIC call: ac.vulcan.anticheat.Vulcan_fg.Vulcan_p(java.lang.Object[]):java.lang.String A[Catch: SecurityException -> 0x073b, MD:(java.lang.Object[]):java.lang.String (m)]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    static {
        /*
            Method dump skipped, instruction units count: 2545
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.m379clinit():void");
    }

    public static File Vulcan_j(Object[] objArr) {
        return new File(System.getProperty(b[65]));
    }

    public static File Vulcan_h(Object[] objArr) {
        return new File(System.getProperty(b[30]));
    }

    public static float Vulcan_T(Object[] objArr) {
        return Vulcan_L;
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private static boolean Vulcan_S(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 133487756301326(0x79680a4bd40e, double:6.59517145289136E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_O
            r1 = r13
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_P(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_S(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [char, java.lang.Exception] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static String Vulcan_p(Object[] objArr) throws Exception {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        if (Vulcan_G != null) {
            int i = 0;
            while (i < Vulcan_G.length()) {
                ?? CharAt = Vulcan_G.charAt(i);
                try {
                    if (jLongValue > 0) {
                        if (CharAt < 48 || CharAt > 57) {
                            i++;
                        } else {
                            return Vulcan_G.substring(i);
                        }
                    }
                    if (jLongValue <= 0) {
                        return null;
                    }
                } catch (SecurityException unused) {
                    throw a(CharAt);
                }
            }
            return null;
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private static boolean Vulcan_d(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 121568391795539(0x6e90d8cf1353, double:6.00627660063447E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_J
            r1 = r15
            java.lang.String r2 = ac.vulcan.anticheat.Vulcan_fg.Vulcan__5
            r3 = r14
            r4 = r11
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_O(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_d(java.lang.Object[]):boolean");
    }

    private static String Vulcan_E(Object[] objArr) {
        String str = (String) objArr[0];
        try {
            return System.getProperty(str);
        } catch (SecurityException e) {
            PrintStream printStream = System.err;
            StringBuffer stringBuffer = new StringBuffer();
            String[] strArr = b;
            printStream.println(stringBuffer.append(strArr[56]).append(str).append(strArr[76]).toString());
            return null;
        }
    }

    public static File Vulcan_y(Object[] objArr) {
        return new File(System.getProperty(b[19]));
    }

    public static File Vulcan_x(Object[] objArr) {
        return new File(System.getProperty(b[42]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String] */
    public static boolean Vulcan_a(Object[] objArr) throws Exception {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_k2 = Vulcan_fX.Vulcan_k();
        try {
            Vulcan_k2 = Vulcan_d;
            ?? r0 = Vulcan_k2;
            if (Vulcan_k2 == 0) {
                if (Vulcan_k2 == 0) {
                    return false;
                }
                r0 = Vulcan_d;
            }
            return r0.equals(Boolean.TRUE.toString());
        } catch (SecurityException unused) {
            throw a(Vulcan_k2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    public static boolean Vulcan_g(Object[] objArr) throws Exception {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        ?? LongValue = a ^ ((Long) objArr[1]).longValue();
        try {
            LongValue = (Vulcan_L > fFloatValue ? 1 : (Vulcan_L == fFloatValue ? 0 : -1));
            return LongValue >= 0;
        } catch (SecurityException unused) {
            throw a(LongValue);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public static boolean m381Vulcan_E(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k2 = Vulcan_fX.Vulcan_k();
        try {
            try {
                Vulcan_k2 = Vulcan_v;
                return Vulcan_k2 == 0 ? Vulcan_k2 >= iIntValue : Vulcan_k2;
            } catch (SecurityException unused) {
                throw a(Vulcan_k2);
            }
        } catch (SecurityException unused2) {
            Vulcan_k2 = a(Vulcan_k2);
            throw Vulcan_k2;
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    static boolean Vulcan_P(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        if (str == null) {
            return false;
        }
        return str.startsWith(str2);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    static boolean Vulcan_O(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r7 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r12
            if (r0 == 0) goto L46
            r0 = r7
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L4e
            if (r0 != 0) goto L4c
            goto L46
        L42:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L48
            throw r0     // Catch: java.lang.SecurityException -> L48
        L46:
            r0 = 0
            return r0
        L48:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L48
            throw r0
        L4c:
            r0 = r12
        L4e:
            r1 = r8
            boolean r0 = r0.startsWith(r1)     // Catch: java.lang.SecurityException -> L67
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L61
            if (r0 == 0) goto L73
            r0 = r7
            r1 = r11
            boolean r0 = r0.startsWith(r1)     // Catch: java.lang.SecurityException -> L67 java.lang.SecurityException -> L6f
        L61:
            if (r0 == 0) goto L73
            goto L6b
        L67:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L6f
            throw r0     // Catch: java.lang.SecurityException -> L6f
        L6b:
            r0 = 1
            goto L74
        L6f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L6f
            throw r0
        L73:
            r0 = 0
        L74:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_O(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    static boolean m382Vulcan_h(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        if (str == null) {
            return false;
        }
        return str.startsWith(str2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v34, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    private static int[] m383Vulcan_p(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.m383Vulcan_p(java.lang.Object[]):int[]");
    }

    /* JADX WARN: Code restructure failed: missing block: B:35:0x0090, code lost:
    
        return java.lang.Float.parseFloat(r0.toString());
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0093, code lost:
    
        return 0.0f;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [float] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static float Vulcan_M(java.lang.Object[] r6) throws java.lang.Exception {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fg.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            r0 = r9
            if (r0 == 0) goto L2f
            r0 = r9
            int r0 = r0.length     // Catch: java.lang.Exception -> L2b java.lang.Exception -> L31
            r1 = r7
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L37
            if (r0 != 0) goto L35
            goto L2f
        L2b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Exception -> L31
            throw r0     // Catch: java.lang.Exception -> L31
        L2f:
            r0 = 0
            return r0
        L31:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Exception -> L31
            throw r0
        L35:
            r0 = r9
            int r0 = r0.length     // Catch: java.lang.Exception -> L46
        L37:
            r1 = r7
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L44
            r1 = 1
            if (r0 != r1) goto L4a
            r0 = r9
            r1 = 0
            r0 = r0[r1]     // Catch: java.lang.Exception -> L46
        L44:
            float r0 = (float) r0     // Catch: java.lang.Exception -> L46
            return r0
        L46:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Exception -> L46
            throw r0
        L4a:
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r1 = r0
            r1.<init>()
            r10 = r0
            r0 = r10
            r1 = r9
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r10
            r1 = 46
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = 1
            r11 = r0
        L67:
            r0 = r11
            r1 = r9
            int r1 = r1.length     // Catch: java.lang.Exception -> L84
            if (r0 >= r1) goto L88
            r0 = r10
            r1 = r9
            r2 = r11
            r1 = r1[r2]     // Catch: java.lang.Exception -> L84
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.Exception -> L84
            r1 = r7
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L8a
        L7e:
            int r11 = r11 + 1
            goto L67
        L84:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Exception -> L84
            throw r0
        L88:
            r0 = r10
        L8a:
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Exception -> L91
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: java.lang.Exception -> L91
            return r0
        L91:
            r11 = move-exception
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fg.Vulcan_M(java.lang.Object[]):float");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    private static int m384Vulcan_Z(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int[] iArr = (int[]) objArr[1];
        long j = a ^ jLongValue;
        if (iArr == null) {
            return 0;
        }
        int i = 0;
        int length = iArr.length;
        int i2 = length;
        int i3 = 1;
        if (j > 0) {
            if (i2 >= 1) {
                i = iArr[0] * 100;
            }
            i2 = length;
            i3 = 2;
        }
        if (j >= 0) {
            if (i2 >= i3) {
                i += iArr[1] * 10;
            }
            i2 = length;
            if (j < 0) {
                return i2;
            }
            i3 = 3;
        }
        if (i2 >= i3) {
            i += iArr[2];
        }
        return i;
    }
}
