package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_c.class */
class Vulcan_c {
    private transient C0026Vulcan_ks[] Vulcan_h;
    private transient int Vulcan_T;
    private int Vulcan_A;
    private final float Vulcan_x;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(3601876429316099757L, -4311484256470815679L, null).a(115997861425439L);
    private static final String[] b;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0076, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 15;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006f, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0072). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.m174clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    public Vulcan_c() {
        this(20, 0.75f);
    }

    public Vulcan_c(int i) {
        this(i, 0.75f);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    public Vulcan_c(int i, float f) {
        long j = a ^ 45560085471738L;
        if (i < 0) {
            throw new IllegalArgumentException(new StringBuffer().append(b[1]).append(i).toString());
        }
        ?? illegalArgumentException = (f > 0.0f ? 1 : (f == 0.0f ? 0 : -1));
        if (illegalArgumentException <= 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(new StringBuffer().append(b[0]).append(f).toString());
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        } else {
            i = i == 0 ? 1 : i;
            this.Vulcan_x = f;
            this.Vulcan_h = new C0026Vulcan_ks[i];
            this.Vulcan_A = (int) (i * f);
        }
    }

    public int Vulcan_J(Object[] objArr) {
        return this.Vulcan_T;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean, int] */
    public boolean Vulcan_e(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            Vulcan_k = this.Vulcan_T;
            return Vulcan_k == 0 ? Vulcan_k == 0 : Vulcan_k;
        } catch (IllegalArgumentException unused) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x003e, code lost:
    
        if (r0 > 0) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0041, code lost:
    
        r14 = r0[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if ((r14 == true ? 1 : 0) == false) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x004d, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0050, code lost:
    
        if (r0 < 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0053, code lost:
    
        r0 = r14 == true ? 1 : 0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0057, code lost:
    
        if (r0 != null) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x005a, code lost:
    
        r0 = r0.Vulcan_L.equals(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0063, code lost:
    
        if (r0 != null) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0069, code lost:
    
        if (r0 <= 0) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0072, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0076, code lost:
    
        if (r0 <= 0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0079, code lost:
    
        if (r0 == 0) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007c, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0082, code lost:
    
        r0 = (r14 == true ? 1 : 0).Vulcan_V;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0087, code lost:
    
        r14 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0089, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x008b, code lost:
    
        if (r0 == null) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x008e, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0093, code lost:
    
        if (r0 < 0) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0096, code lost:
    
        if (r0 == null) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009c, code lost:
    
        if (r0 < 0) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x009f, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:13:0x0041, B:42:0x0099], limit reached: 56 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v26, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NullPointerException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x0093 -> B:38:0x008b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:43:0x009c -> B:13:0x0041). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_a(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_c.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            if (r0 != 0) goto L2e
            java.lang.NullPointerException r0 = new java.lang.NullPointerException     // Catch: java.lang.IllegalArgumentException -> L2a
            r1 = r0
            r1.<init>()     // Catch: java.lang.IllegalArgumentException -> L2a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L2a
        L2a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L2a
            throw r0
        L2e:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_ks[] r0 = r0.Vulcan_h
            r12 = r0
            r0 = r12
            int r0 = r0.length
            r13 = r0
        L39:
            r0 = r13
        L3b:
            int r13 = r13 + (-1)
        L3e:
            if (r0 <= 0) goto L99
        L41:
            r0 = r12
            r1 = r13
            r0 = r0[r1]
            r14 = r0
        L48:
            r0 = r14
            if (r0 == 0) goto L8e
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L89
            r0 = r14
            r1 = r11
            if (r1 != 0) goto L87
            java.lang.Object r0 = r0.Vulcan_L     // Catch: java.lang.IllegalArgumentException -> L6f
            r1 = r8
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L6f
            r1 = r11
            if (r1 != 0) goto L3e
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L3b
            goto L73
        L6f:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L73:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L7d
            if (r0 == 0) goto L82
            r0 = 1
        L7d:
            return r0
        L7e:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L7e
            throw r0
        L82:
            r0 = r14
            ac.vulcan.anticheat.Vulcan_ks r0 = r0.Vulcan_V
        L87:
            r14 = r0
        L89:
            r0 = r11
        L8b:
            if (r0 == 0) goto L48
        L8e:
            r0 = r11
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L8b
            if (r0 == 0) goto L39
        L99:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L41
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_a(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_c, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_w(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_c.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 80300181062380(0x490857c482ec, double:3.9673560817754E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = r14
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_a(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_w(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0053, code lost:
    
        if (r0 != null) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0059, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x005c, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x005f, code lost:
    
        if (r0 != r1) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0065, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0068, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0069, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x006e, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x006f, code lost:
    
        r0 = (r14 == true ? 1 : 0).Vulcan_V;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0074, code lost:
    
        r14 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0076, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0078, code lost:
    
        if (r0 == null) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x007b, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007e, code lost:
    
        if (r0 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0081, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003e, code lost:
    
        if (r0 != 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0041, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0044, code lost:
    
        if (r0 < 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0047, code lost:
    
        r0 = r14 == true ? 1 : 0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004b, code lost:
    
        if (r0 != null) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x004e, code lost:
    
        r0 = r0.Vulcan_A;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0041, B:27:0x007b], limit reached: 38 */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11 */
    /* JADX WARN: Type inference failed for: r14v12 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v8 */
    /* JADX WARN: Type inference failed for: r14v9 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:28:0x007e -> B:5:0x0041). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_K(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_c.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r5
            ac.vulcan.anticheat.Vulcan_ks[] r0 = r0.Vulcan_h
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r7
            r12 = r1
            r1 = r12
            r2 = 2147483647(0x7fffffff, float:NaN)
            r1 = r1 & r2
            r2 = r11
            int r2 = r2.length
            int r1 = r1 % r2
            r13 = r1
            r10 = r0
            r0 = r11
            r1 = r13
            r0 = r0[r1]
            r14 = r0
        L3c:
            r0 = r14
            if (r0 == 0) goto L7b
        L41:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L76
            r0 = r14
            r1 = r10
            if (r1 != 0) goto L74
            int r0 = r0.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L59 java.lang.IllegalArgumentException -> L65
            r1 = r10
            if (r1 != 0) goto L82
            goto L5d
        L59:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L65
            throw r0     // Catch: java.lang.IllegalArgumentException -> L65
        L5d:
            r1 = r12
            if (r0 != r1) goto L6f
            goto L69
        L65:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6b
        L69:
            r0 = 1
            return r0
        L6b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6b
            throw r0
        L6f:
            r0 = r14
            ac.vulcan.anticheat.Vulcan_ks r0 = r0.Vulcan_V
        L74:
            r14 = r0
        L76:
            r0 = r10
            if (r0 == 0) goto L3c
        L7b:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L41
            r0 = 0
        L82:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_K(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0055, code lost:
    
        if (r0 != r1) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x005e, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0064, code lost:
    
        return (r14 == true ? 1 : 0).Vulcan_L;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0068, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0069, code lost:
    
        r0 = (r14 == true ? 1 : 0).Vulcan_V;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x006e, code lost:
    
        r14 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0070, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0072, code lost:
    
        if (r0 == null) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0075, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0078, code lost:
    
        if (r0 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x007b, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0040, code lost:
    
        if (r0 != 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0043, code lost:
    
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0046, code lost:
    
        if (r0 <= 0) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0049, code lost:
    
        r0 = r14 == true ? 1 : 0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004d, code lost:
    
        if (r0 != null) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0050, code lost:
    
        r0 = r0.Vulcan_A;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0043, B:22:0x0075], limit reached: 30 */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [int] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11 */
    /* JADX WARN: Type inference failed for: r14v12 */
    /* JADX WARN: Type inference failed for: r14v13 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v9 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:23:0x0078 -> B:5:0x0043). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object Vulcan_v(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_c.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            r0 = r5
            ac.vulcan.anticheat.Vulcan_ks[] r0 = r0.Vulcan_h
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r9
            r12 = r1
            r1 = r12
            r2 = 2147483647(0x7fffffff, float:NaN)
            r1 = r1 & r2
            r2 = r11
            int r2 = r2.length
            int r1 = r1 % r2
            r13 = r1
            r1 = r11
            r2 = r13
            r1 = r1[r2]
            r14 = r1
            r10 = r0
        L3e:
            r0 = r14
            if (r0 == 0) goto L75
        L43:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L70
            r0 = r14
            r1 = r10
            if (r1 != 0) goto L6e
            int r0 = r0.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L5b java.lang.IllegalArgumentException -> L65
            r1 = r12
            if (r0 != r1) goto L69
            goto L5f
        L5b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L65
            throw r0     // Catch: java.lang.IllegalArgumentException -> L65
        L5f:
            r0 = r14
            java.lang.Object r0 = r0.Vulcan_L     // Catch: java.lang.IllegalArgumentException -> L65
            return r0
        L65:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L65
            throw r0
        L69:
            r0 = r14
            ac.vulcan.anticheat.Vulcan_ks r0 = r0.Vulcan_V
        L6e:
            r14 = r0
        L70:
            r0 = r10
            if (r0 == 0) goto L3e
        L75:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L43
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_v(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0089, code lost:
    
        if (r0 != null) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008c, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0091, code lost:
    
        if (r0 <= 0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0094, code lost:
    
        if (r0 == null) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0097, code lost:
    
        r0 = 2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x009b, code lost:
    
        if (r0 <= 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009e, code lost:
    
        me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(new me.frep.vulcan.spigot.check.AbstractCheck[2]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a4, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00a6, code lost:
    
        if (r0 == null) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ac, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00af, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x004a, code lost:
    
        continue;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x004a, code lost:
    
        continue;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x004f, code lost:
    
        if (r0 > 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0052, code lost:
    
        r16 = r1[r15];
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005b, code lost:
    
        if (r16 == null) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005e, code lost:
    
        r0 = r16;
        r16 = r16.Vulcan_V;
        r0 = (r0.Vulcan_A & Integer.MAX_VALUE) % r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0074, code lost:
    
        r18 = r0;
        r0.Vulcan_V = r0[r18];
        r0[r18] = r0;
     */
    /* JADX WARN: Path cross not found for [B:5:0x0052, B:19:0x00a9], limit reached: 31 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x00ac -> B:5:0x0052). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_i(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_c.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r6
            ac.vulcan.anticheat.Vulcan_ks[] r1 = r1.Vulcan_h
            int r1 = r1.length
            r11 = r1
            r1 = r6
            ac.vulcan.anticheat.Vulcan_ks[] r1 = r1.Vulcan_h
            r12 = r1
            r10 = r0
            r0 = r11
            r1 = 2
            int r0 = r0 * r1
            r1 = 1
            int r0 = r0 + r1
            r13 = r0
            r0 = r13
            ac.vulcan.anticheat.Vulcan_ks[] r0 = new ac.vulcan.anticheat.C0026Vulcan_ks[r0]
            r14 = r0
            r0 = r6
            r1 = r13
            float r1 = (float) r1
            r2 = r6
            float r2 = r2.Vulcan_x
            float r1 = r1 * r2
            int r1 = (int) r1
            r0.Vulcan_A = r1
            r0 = r6
            r1 = r14
            r0.Vulcan_h = r1
            r0 = r11
            r15 = r0
        L4a:
            r0 = r15
            int r15 = r15 + (-1)
            if (r0 <= 0) goto La9
        L52:
            r0 = r12
            r1 = r15
            r0 = r0[r1]
            r16 = r0
        L59:
            r0 = r16
            if (r0 == 0) goto La4
            r0 = r16
            r17 = r0
            r0 = r16
            ac.vulcan.anticheat.Vulcan_ks r0 = r0.Vulcan_V
            r16 = r0
            r0 = r17
            int r0 = r0.Vulcan_A
            r1 = 2147483647(0x7fffffff, float:NaN)
            r0 = r0 & r1
            r1 = r13
            int r0 = r0 % r1
        L74:
            r18 = r0
            r0 = r17
            r1 = r14
            r2 = r18
            r1 = r1[r2]
            r0.Vulcan_V = r1
            r0 = r14
            r1 = r18
            r2 = r17
            r0[r1] = r2
            r0 = r10
            if (r0 != 0) goto L4a
            r0 = r10
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto La6
            if (r0 == 0) goto L59
            r0 = 2
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L74
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = new me.frep.vulcan.spigot.check.AbstractCheck[r0]
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r0)
        La4:
            r0 = r10
        La6:
            if (r0 == 0) goto L4a
        La9:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L52
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_i(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_c] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [int] */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_c] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v33, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v34, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v38, types: [int] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r1v26, types: [ac.vulcan.anticheat.Vulcan_c] */
    /* JADX WARN: Type inference failed for: r21v0 */
    /* JADX WARN: Type inference failed for: r21v1 */
    /* JADX WARN: Type inference failed for: r21v10 */
    /* JADX WARN: Type inference failed for: r21v3 */
    /* JADX WARN: Type inference failed for: r21v4 */
    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_c, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v2 ??, still in use, count: 2, list:
          (r4v2 ?? I:??[OBJECT, ARRAY][]) from 0x00cf: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY])
          (r4v2 ?? I:??[OBJECT, ARRAY]) from 0x00cf: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.Object Vulcan_p(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 266
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_p(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0056, code lost:
    
        if (r0 != r1) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x005c, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x005f, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0060, code lost:
    
        r0 = r16 ? 1 : 0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0065, code lost:
    
        if (r0 <= 0) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0068, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x006a, code lost:
    
        if (r0 != null) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0070, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0073, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0074, code lost:
    
        if (r0 == false) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x007d, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x007e, code lost:
    
        r0 = r16 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0080, code lost:
    
        r0.Vulcan_V = (r15 == true ? 1 : 0).Vulcan_V;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x008d, code lost:
    
        if (r0 < 0) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0090, code lost:
    
        if (r0 == null) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0093, code lost:
    
        r0 = r1;
        r0[r0] = (r15 == true ? 1 : 0).Vulcan_V;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00a3, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00a4, code lost:
    
        r6.Vulcan_T--;
        r0 = (r15 == true ? 1 : 0).Vulcan_L;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00b3, code lost:
    
        r17 = r0;
        (r15 == true ? 1 : 0).Vulcan_L = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00bd, code lost:
    
        return r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00be, code lost:
    
        r16 = r15 == true ? 1 : 0 ? 1 : 0;
        r0 = (r15 == true ? 1 : 0).Vulcan_V;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00c7, code lost:
    
        r15 = r0;
        r16 = r16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00c9, code lost:
    
        r15 = r15;
        r16 = r16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00cb, code lost:
    
        if (r0 == null) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00ce, code lost:
    
        r15 = r15;
        r16 = r16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00d1, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00d4, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        if (r0 != 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0044, code lost:
    
        r15 = r15;
        r16 = r16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0047, code lost:
    
        if (r0 < 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004a, code lost:
    
        r0 = r15 == true ? 1 : 0;
        r0 = r0;
        r16 = r16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004e, code lost:
    
        if (r0 != null) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0051, code lost:
    
        r0 = r0.Vulcan_A;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0044, B:39:0x00ce], limit reached: 51 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v18, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v25, types: [int] */
    /* JADX WARN: Type inference failed for: r0v27, types: [ac.vulcan.anticheat.Vulcan_ks] */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v13 */
    /* JADX WARN: Type inference failed for: r15v14 */
    /* JADX WARN: Type inference failed for: r15v15 */
    /* JADX WARN: Type inference failed for: r15v16 */
    /* JADX WARN: Type inference failed for: r15v17 */
    /* JADX WARN: Type inference failed for: r15v2 */
    /* JADX WARN: Type inference failed for: r15v3 */
    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:40:0x00d1 -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object Vulcan_B(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 214
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_c.Vulcan_B(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    public synchronized void Vulcan_N(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        C0026Vulcan_ks[] c0026Vulcan_ksArr = this.Vulcan_h;
        int length = c0026Vulcan_ksArr.length;
        loop0: while (true) {
            length--;
            ?? r0 = length;
            if (r0 < 0) {
                break;
            }
            try {
                r0 = c0026Vulcan_ksArr;
                r0[length] = 0;
                do {
                    String str = strVulcan_k;
                    if (jLongValue > 0) {
                        if (str != null) {
                            return;
                        } else {
                            str = strVulcan_k;
                        }
                    }
                    if (str != null) {
                    }
                } while (jLongValue < 0);
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        }
        this.Vulcan_T = 0;
    }
}
