package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_Ot, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Ot.class */
public class C0005Vulcan_Ot extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = 5787169186L;
    private float Vulcan_b;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(4987122967071236697L, -5832663936795771549L, null).a(98003236208775L);

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public C0005Vulcan_Ot() {
    }

    public C0005Vulcan_Ot(float f) {
        this.Vulcan_b = f;
    }

    public C0005Vulcan_Ot(Number number) {
        this.Vulcan_b = number.floatValue();
    }

    public C0005Vulcan_Ot(String str) {
        this.Vulcan_b = Float.parseFloat(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Float(this.Vulcan_b);
    }

    public void Vulcan_n(Object[] objArr) {
        this.Vulcan_b = ((Float) objArr[0]).floatValue();
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        Vulcan_n(new Object[]{new Boolean(((Number) objArr[0]).floatValue())});
    }

    public boolean Vulcan_k(Object[] objArr) {
        return Float.isNaN(this.Vulcan_b);
    }

    public boolean Vulcan_Q(Object[] objArr) {
        return Float.isInfinite(this.Vulcan_b);
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_b += 1.0f;
    }

    public void Vulcan_x(Object[] objArr) {
        this.Vulcan_b -= 1.0f;
    }

    public void Vulcan_K(Object[] objArr) {
        this.Vulcan_b += ((Float) objArr[0]).floatValue();
    }

    public void Vulcan_O(Object[] objArr) {
        this.Vulcan_b += ((Number) objArr[0]).floatValue();
    }

    public void Vulcan_o(Object[] objArr) {
        this.Vulcan_b -= ((Float) objArr[0]).floatValue();
    }

    public void Vulcan_e(Object[] objArr) {
        this.Vulcan_b -= ((Number) objArr[0]).floatValue();
    }

    @Override // java.lang.Number
    public int intValue() {
        return (int) this.Vulcan_b;
    }

    @Override // java.lang.Number
    public long longValue() {
        return (long) this.Vulcan_b;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_b;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_b;
    }

    public Float Vulcan_p(Object[] objArr) {
        return new Float(floatValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0036 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.NumberFormatException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean, java.lang.NumberFormatException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.C0005Vulcan_Ot.a
            r1 = 118767151667737(0x6c04a1e2da19, double:5.8678769493446E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_n()
            r9 = r0
            r0 = r6
            boolean r0 = r0 instanceof ac.vulcan.anticheat.C0005Vulcan_Ot     // Catch: java.lang.NumberFormatException -> L1c
            r1 = r9
            if (r1 == 0) goto L31
            if (r0 == 0) goto L52
            goto L20
        L1c:
            java.lang.NumberFormatException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L2d
            throw r0     // Catch: java.lang.NumberFormatException -> L2d
        L20:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_Ot r0 = (ac.vulcan.anticheat.C0005Vulcan_Ot) r0     // Catch: java.lang.NumberFormatException -> L2d
            float r0 = r0.Vulcan_b     // Catch: java.lang.NumberFormatException -> L2d
            int r0 = java.lang.Float.floatToIntBits(r0)     // Catch: java.lang.NumberFormatException -> L2d
            goto L31
        L2d:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L31:
            r1 = r9
            if (r1 == 0) goto L4f
            r1 = r5
            float r1 = r1.Vulcan_b     // Catch: java.lang.NumberFormatException -> L43 java.lang.NumberFormatException -> L4b
            int r1 = java.lang.Float.floatToIntBits(r1)     // Catch: java.lang.NumberFormatException -> L43 java.lang.NumberFormatException -> L4b
            if (r0 != r1) goto L52
            goto L47
        L43:
            java.lang.NumberFormatException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L4b
            throw r0     // Catch: java.lang.NumberFormatException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0005Vulcan_Ot.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return Float.floatToIntBits(this.Vulcan_b);
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.lang.Comparable
    public int compareTo(java.lang.Object r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0005Vulcan_Ot.a
            r1 = 24516312134763(0x164c2613746b, double:1.21126675885073E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 55402127560175(0x326350220def, double:2.7372287933997E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            ac.vulcan.anticheat.Vulcan_Ot r0 = (ac.vulcan.anticheat.C0005Vulcan_Ot) r0
            r15 = r0
            r0 = r15
            float r0 = r0.Vulcan_b
            r16 = r0
            r0 = r9
            float r0 = r0.Vulcan_b
            r1 = r13
            r2 = r16
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            java.lang.Boolean r3 = new java.lang.Boolean
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = ac.vulcan.anticheat.Vulcan_O9.Vulcan_Q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0005Vulcan_Ot.compareTo(java.lang.Object):int");
    }

    public String toString() {
        return String.valueOf(this.Vulcan_b);
    }
}
