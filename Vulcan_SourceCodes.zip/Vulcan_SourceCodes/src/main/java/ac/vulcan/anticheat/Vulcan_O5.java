package ac.vulcan.anticheat;

import java.util.Locale;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O5.class */
public class Vulcan_O5 {
    private static final char Vulcan_m = ',';
    private static final char Vulcan_j = '\"';
    private static final String Vulcan_S;
    private static final char[] Vulcan_e;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(8277931585125795233L, -4605228148744291404L, null).a(279414979967496L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_S(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 111087753409134(0x6508a214b26e, double:5.4884642633137E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r9
            if (r0 != 0) goto L2c
            r0 = 0
            return r0
        L28:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L28
            throw r0
        L2c:
            java.io.StringWriter r0 = new java.io.StringWriter     // Catch: java.io.IOException -> L60
            r1 = r0
            r1.<init>()     // Catch: java.io.IOException -> L60
            r14 = r0
            r0 = r12
            r1 = r14
            r2 = r9
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.io.IOException -> L60
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.io.IOException -> L60
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L60
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L60
            r3[r4] = r5     // Catch: java.io.IOException -> L60
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.io.IOException -> L60
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L60
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L60
            r2[r3] = r4     // Catch: java.io.IOException -> L60
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.io.IOException -> L60
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.io.IOException -> L60
            java.lang.Long r3 = new java.lang.Long     // Catch: java.io.IOException -> L60
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.io.IOException -> L60
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.io.IOException -> L60
            r3.<init>(r4)     // Catch: java.io.IOException -> L60
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L60
            r1[r2] = r3     // Catch: java.io.IOException -> L60
            Vulcan_a(r0)     // Catch: java.io.IOException -> L60
            r0 = r14
            java.lang.String r0 = r0.toString()     // Catch: java.io.IOException -> L60
            return r0
        L60:
            r14 = move-exception
            ac.vulcan.anticheat.Vulcan_kj r0 = new ac.vulcan.anticheat.Vulcan_kj
            r1 = r0
            r2 = r14
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_S(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x012e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_a(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 332
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_a(java.lang.Object[]):void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0087, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008a, code lost:
    
        r11 = "4\b\u001eC\u007f\u001c}\u0014\u0005\tCE\u001bg\u0014@\u0015\f\\Nv\u0005@\u0015\u0016D\u0002\u0005<\u0015KS\u0018".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0093, code lost:
    
        ac.vulcan.anticheat.Vulcan_O5.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ab, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b2, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ba, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.Vulcan_O5.Vulcan_S = java.lang.String.valueOf('\"');
        ac.vulcan.anticheat.Vulcan_O5.Vulcan_e = new char[]{',', '\"', '\r', '\n'};
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x014a, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x009b, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ab, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00ae, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b2, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00ba, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e0, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e5, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        r7 = 43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ef, code lost:
    
        r7 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f4, code lost:
    
        r7 = 120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f9, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00fe, code lost:
    
        r7 = 68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "4\b\u001eC\u007f\u001c}\u0014\u0005\tCE\u001bg\u0014@\u0015\f\\Nv\u0005@\u0015\u0016D\u0002\u0005<\u0015KS\u0018".length();
        r11 = 27;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0067, code lost:
    
        r10 = r10 + 1;
        "4\b\u001eC\u007f\u001c}\u0014\u0005\tCE\u001bg\u0014@\u0015\f\\Nv\u0005@\u0015\u0016D\u0002\u0005<\u0015KS\u0018".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0077, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ae, B:28:0x0110], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v16 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v21 */
    /* JADX WARN: Type inference failed for: r5v31 */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ae). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0115 -> B:35:0x00ae). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 331
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.m42clinit():void");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x0053: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x0053: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_P(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 69403436905207(0x3f1f3f33f2f7, double:3.42898538781733E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            r2 = 0
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m43Vulcan_c(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_P(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_f(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 36422667642873(0x2120502aa7f9, double:1.7995188812237E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r13
            r2 = 0
            r3 = 0
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_h(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_f(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x0053: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x0053: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_g(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 73619274606039(0x42f4d2b625d7, double:3.63727544545967E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            r1 = r14
            r2 = 1
            r3 = 1
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m43Vulcan_c(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_g(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_c(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 7807351361957(0x719ca6791a5, double:3.857344092955E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r13
            r1 = r16
            r2 = 1
            r3 = 1
            r4 = r17
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_h(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_c(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x006e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x009c]
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x006e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x009c]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    private static java.lang.String m43Vulcan_c(java.lang.Object[] r12) {
        /*
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 84659624572933(0x4cff5ad97805, double:4.18274120913036E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r16
            if (r0 != 0) goto L43
            r0 = 0
            return r0
        L3f:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L3f
            throw r0
        L43:
            java.io.StringWriter r0 = new java.io.StringWriter     // Catch: java.io.IOException -> L9c
            r1 = r0
            r2 = r16
            int r2 = r2.length()     // Catch: java.io.IOException -> L9c
            r3 = 2
            int r2 = r2 * r3
            r1.<init>(r2)     // Catch: java.io.IOException -> L9c
            r20 = r0
            r0 = r20
            r1 = r16
            r2 = r17
            r3 = r13
            r4 = r18
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch: java.io.IOException -> L9c
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.io.IOException -> L9c
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.io.IOException -> L9c
            java.lang.Long r7 = new java.lang.Long     // Catch: java.io.IOException -> L9c
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.io.IOException -> L9c
            r9 = r8; r8 = r7; r7 = r6; r6 = r9;      // Catch: java.io.IOException -> L9c
            r7.<init>(r8)     // Catch: java.io.IOException -> L9c
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.io.IOException -> L9c
            r5[r6] = r7     // Catch: java.io.IOException -> L9c
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.io.IOException -> L9c
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L9c
            java.lang.Boolean r6 = new java.lang.Boolean     // Catch: java.io.IOException -> L9c
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.io.IOException -> L9c
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.io.IOException -> L9c
            r6.<init>(r7)     // Catch: java.io.IOException -> L9c
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.io.IOException -> L9c
            r4[r5] = r6     // Catch: java.io.IOException -> L9c
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.io.IOException -> L9c
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L9c
            java.lang.Boolean r5 = new java.lang.Boolean     // Catch: java.io.IOException -> L9c
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.io.IOException -> L9c
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.io.IOException -> L9c
            r5.<init>(r6)     // Catch: java.io.IOException -> L9c
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L9c
            r3[r4] = r5     // Catch: java.io.IOException -> L9c
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.io.IOException -> L9c
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L9c
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L9c
            r2[r3] = r4     // Catch: java.io.IOException -> L9c
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.io.IOException -> L9c
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.io.IOException -> L9c
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L9c
            r1[r2] = r3     // Catch: java.io.IOException -> L9c
            Vulcan_h(r0)     // Catch: java.io.IOException -> L9c
            r0 = r20
            java.lang.String r0 = r0.toString()     // Catch: java.io.IOException -> L9c
            return r0
        L9c:
            r20 = move-exception
            ac.vulcan.anticheat.Vulcan_kj r0 = new ac.vulcan.anticheat.Vulcan_kj
            r1 = r0
            r2 = r20
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.m43Vulcan_c(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:60:0x015a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static void Vulcan_h(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 1061
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_h(java.lang.Object[]):void");
    }

    private static String Vulcan_z(Object[] objArr) {
        return Integer.toHexString(((Integer) objArr[0]).intValue()).toUpperCase(Locale.ENGLISH);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v6 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.lang.String Vulcan_K(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v6 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static void Vulcan_R(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 753
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_R(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_q(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 108352694673975(0x628bd3e06237, double:5.3533344072737E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_K(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_q(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_Z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 65334258275609(0x3b6bd1419519, double:3.22794125104976E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_R(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_Z(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v6 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.lang.String Vulcan_B(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v6 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_f3, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_Q(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 43400918102085(0x2779104e7045, double:2.14429026322097E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            if (r0 != 0) goto L3e
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.io.IOException -> L3a
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O5.b     // Catch: java.io.IOException -> L3a
            r3 = 1
            r2 = r2[r3]     // Catch: java.io.IOException -> L3a
            r1.<init>(r2)     // Catch: java.io.IOException -> L3a
            throw r0     // Catch: java.io.IOException -> L3a
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L3a
            throw r0
        L3e:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L74
            r0 = r11
            if (r0 != 0) goto L4d
            return
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L49
            throw r0
        L4d:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_B
            r1 = r14
            r2 = r10
            r3 = r11
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_G(r1)
        L74:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_Q(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.Long, java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x006a]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x006a]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_V(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 5066473108089(0x49ba1547279, double:2.5031703082853E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            if (r0 != 0) goto L2c
            r0 = 0
            return r0
        L28:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L28
            throw r0
        L2c:
            java.io.StringWriter r0 = new java.io.StringWriter     // Catch: java.io.IOException -> L6a
            r1 = r0
            r2 = r13
            int r2 = r2.length()     // Catch: java.io.IOException -> L6a
            double r2 = (double) r2     // Catch: java.io.IOException -> L6a
            r3 = 4609434218613702656(0x3ff8000000000000, double:1.5)
            double r2 = r2 * r3
            int r2 = (int) r2     // Catch: java.io.IOException -> L6a
            r1.<init>(r2)     // Catch: java.io.IOException -> L6a
            r16 = r0
            r0 = r16
            r1 = r13
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.io.IOException -> L6a
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.io.IOException -> L6a
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.io.IOException -> L6a
            java.lang.Long r5 = new java.lang.Long     // Catch: java.io.IOException -> L6a
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.io.IOException -> L6a
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.io.IOException -> L6a
            r5.<init>(r6)     // Catch: java.io.IOException -> L6a
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L6a
            r3[r4] = r5     // Catch: java.io.IOException -> L6a
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.io.IOException -> L6a
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L6a
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L6a
            r2[r3] = r4     // Catch: java.io.IOException -> L6a
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.io.IOException -> L6a
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.io.IOException -> L6a
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.IOException -> L6a
            r1[r2] = r3     // Catch: java.io.IOException -> L6a
            Vulcan_H(r0)     // Catch: java.io.IOException -> L6a
            r0 = r16
            java.lang.String r0 = r0.toString()     // Catch: java.io.IOException -> L6a
            return r0
        L6a:
            r16 = move-exception
            ac.vulcan.anticheat.Vulcan_kj r0 = new ac.vulcan.anticheat.Vulcan_kj
            r1 = r0
            r2 = r16
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_V(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [ac.vulcan.anticheat.Vulcan_f3] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x006f: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x006f: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_H(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 60369266193990(0x36e7d0aab646, double:2.9826380491096E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 != 0) goto L41
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.io.IOException -> L3d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O5.b     // Catch: java.io.IOException -> L3d
            r3 = 8
            r2 = r2[r3]     // Catch: java.io.IOException -> L3d
            r1.<init>(r2)     // Catch: java.io.IOException -> L3d
            throw r0     // Catch: java.io.IOException -> L3d
        L3d:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L3d
            throw r0
        L41:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L78
            r0 = r11
            if (r0 != 0) goto L50
            return
        L4c:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L4c
            throw r0
        L50:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_B
            r1 = r14
            r2 = r15
            r3 = r11
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
        L78:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_H(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_f3, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0074: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0074: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static void m44Vulcan_K(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 121973310911378(0x6eef1fde7392, double:6.0262822630825E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            if (r0 != 0) goto L40
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.io.IOException -> L3c
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O5.b     // Catch: java.io.IOException -> L3c
            r3 = 8
            r2 = r2[r3]     // Catch: java.io.IOException -> L3c
            r1.<init>(r2)     // Catch: java.io.IOException -> L3c
            throw r0     // Catch: java.io.IOException -> L3c
        L3c:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L3c
            throw r0
        L40:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L78
            r0 = r13
            if (r0 != 0) goto L50
            return
        L4c:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L4c
            throw r0
        L50:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_G
            r1 = r14
            r2 = r10
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_G(r1)
        L78:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.m44Vulcan_K(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_s(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 46217746184981(0x2a08e857fb15, double:2.28346006182094E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L5e
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0
        L3d:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_G
            r1 = r13
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r0 = r0.Vulcan_H(r1)
        L5e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_s(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [ac.vulcan.anticheat.Vulcan_f3] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x006f: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x006f: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_o(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.io.Writer r1 = (java.io.Writer) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 105558652543327(0x600149fce15f, double:5.21529038429506E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            if (r0 != 0) goto L40
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.io.IOException -> L3c
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O5.b     // Catch: java.io.IOException -> L3c
            r3 = 8
            r2 = r2[r3]     // Catch: java.io.IOException -> L3c
            r1.<init>(r2)     // Catch: java.io.IOException -> L3c
            throw r0     // Catch: java.io.IOException -> L3c
        L3c:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L3c
            throw r0
        L40:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L78
            r0 = r14
            if (r0 != 0) goto L50
            return
        L4c:
            java.lang.Exception r0 = a(r0)     // Catch: java.io.IOException -> L4c
            throw r0
        L50:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_G
            r1 = r13
            r2 = r15
            r3 = r14
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
        L78:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_o(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_X(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 21303772518103(0x13602bcb16d7, double:1.05254621280116E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L5e
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0
        L3d:
            ac.vulcan.anticheat.Vulcan_f3 r0 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_G
            r1 = r13
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r0 = r0.m183Vulcan_G(r1)
        L5e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.Vulcan_X(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static java.lang.String m45Vulcan_Q(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O5.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 99324873798646(0x5a55dfd1f3f6, double:4.90730079214283E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L6c
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L39
            throw r0
        L3d:
            r0 = r12
            r1 = r13
            java.lang.String r2 = "'"
            java.lang.String[] r3 = ac.vulcan.anticheat.Vulcan_O5.b
            r4 = 2
            r3 = r3[r4]
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_mg(r0)
        L6c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.m45Vulcan_Q(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x006c: PHI (r0v13 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.lang.String Vulcan_x(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x006c: PHI (r0v13 ?? I:java.io.StringWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r10v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public static void m46Vulcan_q(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O5.m46Vulcan_q(java.lang.Object[]):void");
    }
}
