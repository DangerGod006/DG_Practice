package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kH.class */
public abstract class Vulcan_kH {
    private static final Vulcan_kH Vulcan_y;
    private static final Vulcan_kH Vulcan_X;
    private static final Vulcan_kH Vulcan_j;
    private static final Vulcan_kH Vulcan_w;
    private static final Vulcan_kH Vulcan_k;
    private static final Vulcan_kH Vulcan_t;
    private static final Vulcan_kH Vulcan_u;
    private static final Vulcan_kH Vulcan_M;
    private static final Vulcan_kH Vulcan_d;
    private static int Vulcan_s;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5481089478021005310L, -5034578629160645412L, null).a(267952535116564L);

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public abstract int mo437Vulcan_A(Object[] objArr);

    public static void Vulcan_H(int i) {
        Vulcan_s = i;
    }

    public static int Vulcan_a() {
        return Vulcan_s;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_m() {
        return Vulcan_a() == 0 ? 28 : 0;
    }

    private static RuntimeException b(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0075, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0079, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0081, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a8, code lost:
    
        r7 = 86;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ad, code lost:
    
        r7 = 91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b2, code lost:
    
        r7 = 58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b7, code lost:
    
        r7 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bc, code lost:
    
        r7 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00c1, code lost:
    
        r7 = 8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c6, code lost:
    
        r7 = 91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c8, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r18 = r18 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00d0, code lost:
    
        if (r2 != 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00d3, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d8, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00dd, code lost:
    
        if (r2 > r18) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00e1, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0062, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r18 = 0;
        r2 = 30;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0072, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00dd -> B:10:0x0075). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 353
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kH.m436clinit():void");
    }

    public static Vulcan_kH Vulcan_X(Object[] objArr) {
        return Vulcan_y;
    }

    public static Vulcan_kH Vulcan_d(Object[] objArr) {
        return Vulcan_X;
    }

    public static Vulcan_kH Vulcan_g(Object[] objArr) {
        return Vulcan_j;
    }

    public static Vulcan_kH Vulcan_u(Object[] objArr) {
        return Vulcan_w;
    }

    public static Vulcan_kH Vulcan_D(Object[] objArr) {
        return Vulcan_k;
    }

    public static Vulcan_kH Vulcan_h(Object[] objArr) {
        return Vulcan_t;
    }

    public static Vulcan_kH Vulcan_A(Object[] objArr) {
        return Vulcan_u;
    }

    public static Vulcan_kH Vulcan_R(Object[] objArr) {
        return Vulcan_M;
    }

    public static Vulcan_kH Vulcan_a(Object[] objArr) {
        return Vulcan_d;
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [char, int] */
    public static Vulcan_kH Vulcan_r(Object[] objArr) {
        return new Vulcan_kF(((Integer) objArr[0]).intValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0053 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [ac.vulcan.anticheat.Vulcan_kF, ac.vulcan.anticheat.Vulcan_kH] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static ac.vulcan.anticheat.Vulcan_kH Vulcan_E(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kH.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_W()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 == 0) goto L2f
            if (r0 == 0) goto L45
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length     // Catch: java.lang.RuntimeException -> L41
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L50
            if (r1 == 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0     // Catch: java.lang.RuntimeException -> L49
        L45:
            ac.vulcan.anticheat.Vulcan_kH r0 = ac.vulcan.anticheat.Vulcan_kH.Vulcan_d     // Catch: java.lang.RuntimeException -> L49
            return r0
        L49:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            r1 = 1
        L50:
            if (r0 != r1) goto L62
            ac.vulcan.anticheat.Vulcan_kF r0 = new ac.vulcan.anticheat.Vulcan_kF     // Catch: java.lang.RuntimeException -> L5e
            r1 = r0
            r2 = r8
            r3 = 0
            char r2 = r2[r3]     // Catch: java.lang.RuntimeException -> L5e
            r1.<init>(r2)     // Catch: java.lang.RuntimeException -> L5e
            return r0
        L5e:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L5e
            throw r0
        L62:
            ac.vulcan.anticheat.Vulcan_kA r0 = new ac.vulcan.anticheat.Vulcan_kA
            r1 = r0
            r2 = r8
            r1.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kH.Vulcan_E(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_kH");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x003a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0057 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [ac.vulcan.anticheat.Vulcan_kF, ac.vulcan.anticheat.Vulcan_kH] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static ac.vulcan.anticheat.Vulcan_kH Vulcan_e(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kH.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_m()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L47
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L2e:
            r0 = r10
        L2f:
            int r0 = r0.length()     // Catch: java.lang.RuntimeException -> L43
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L54
            if (r1 != 0) goto L53
            if (r0 != 0) goto L4f
            goto L47
        L43:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            ac.vulcan.anticheat.Vulcan_kH r0 = ac.vulcan.anticheat.Vulcan_kH.Vulcan_d     // Catch: java.lang.RuntimeException -> L4b
            return r0
        L4b:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0
        L4f:
            r0 = r10
            int r0 = r0.length()
        L53:
            r1 = 1
        L54:
            if (r0 != r1) goto L68
            ac.vulcan.anticheat.Vulcan_kF r0 = new ac.vulcan.anticheat.Vulcan_kF     // Catch: java.lang.RuntimeException -> L64
            r1 = r0
            r2 = r10
            r3 = 0
            char r2 = r2.charAt(r3)     // Catch: java.lang.RuntimeException -> L64
            r1.<init>(r2)     // Catch: java.lang.RuntimeException -> L64
            return r0
        L64:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L64
            throw r0
        L68:
            ac.vulcan.anticheat.Vulcan_kA r0 = new ac.vulcan.anticheat.Vulcan_kA
            r1 = r0
            r2 = r10
            char[] r2 = r2.toCharArray()
            r1.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kH.Vulcan_e(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_kH");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public static Vulcan_kH Vulcan_o(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        long j = a ^ jLongValue;
        ?? length = str;
        if (length != 0) {
            try {
                try {
                    length = str.length();
                    if (length != 0) {
                        return new Vulcan_k3(str);
                    }
                } catch (RuntimeException unused) {
                    throw b(length);
                }
            } catch (RuntimeException unused2) {
                throw b(length);
            }
        }
        return Vulcan_d;
    }

    protected Vulcan_kH() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public int m438Vulcan_X(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kH.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 131359551946440(0x7778876e7ec8, double:6.49002418698347E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            r1 = r18
            r2 = r17
            r3 = 0
            r4 = r18
            int r4 = r4.length
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.mo437Vulcan_A(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kH.m438Vulcan_X(java.lang.Object[]):int");
    }
}
