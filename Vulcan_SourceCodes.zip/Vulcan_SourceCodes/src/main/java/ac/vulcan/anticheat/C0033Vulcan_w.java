package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_w.class */
class C0033Vulcan_w implements InterfaceC0031Vulcan_n {
    private final char Vulcan_M;

    C0033Vulcan_w(char c) {
        this.Vulcan_M = c;
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return 1;
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        ((Long) objArr[2]).longValue();
        stringBuffer.append(this.Vulcan_M);
    }
}
