package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_ks, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_ks.class */
class C0026Vulcan_ks {
    final int Vulcan_A;
    final int Vulcan_G;
    Object Vulcan_L;
    C0026Vulcan_ks Vulcan_V;

    protected C0026Vulcan_ks(int i, int i2, Object obj, C0026Vulcan_ks c0026Vulcan_ks) {
        this.Vulcan_A = i;
        this.Vulcan_G = i2;
        this.Vulcan_L = obj;
        this.Vulcan_V = c0026Vulcan_ks;
    }
}
