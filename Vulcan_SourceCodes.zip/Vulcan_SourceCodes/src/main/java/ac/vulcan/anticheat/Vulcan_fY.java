package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fY.class */
final class Vulcan_fY extends Vulcan_fV {
    private static final long serialVersionUID = 1;

    Vulcan_fY() {
        Vulcan_M(new Object[]{new Boolean(true)});
        Vulcan_d(new Object[]{new Boolean(false)});
    }

    private Object readResolve() {
        return Vulcan_fV.Vulcan_T;
    }
}
