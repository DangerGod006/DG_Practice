package ac.vulcan.anticheat;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_yy.class */
public abstract class Vulcan_yy implements Comparable, Serializable {
    private static final long serialVersionUID = -487045951170455942L;
    private static final Map Vulcan_c;
    private static Map Vulcan_I;
    private final String Vulcan_e;
    private final transient int Vulcan_s;
    protected transient String Vulcan_i;
    static Class Vulcan_v;
    static Class Vulcan_D;
    private static int Vulcan_b;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(5660018046147235805L, 7827833960538836430L, null).a(47198794279434L);
    private static final String[] c;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_D(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 674
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.Vulcan_D(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String toString() {
        /*
            r8 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = 71477869372058(0x41023d03629a, double:3.5314759694662E-310)
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 9156969033342(0x85405e2ee7e, double:4.5241438194064E-311)
            long r1 = r1 ^ r2
            r11 = r1
            int r0 = Vulcan_d()
            r13 = r0
            r0 = r8
            java.lang.String r0 = r0.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L24
            r1 = r13
            if (r1 != 0) goto L7e
            if (r0 != 0) goto L7a
            goto L28
        L24:
            java.lang.Exception r0 = a(r0)
            throw r0
        L28:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Class r0 = r0.Vulcan_F(r1)
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(r0)
            r14 = r0
            r0 = r8
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r2 = r1
            r2.<init>()
            r2 = r14
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "["
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r2 = r2.Vulcan_p(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "]"
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.Vulcan_i = r1
        L7a:
            r0 = r8
            java.lang.String r0 = r0.Vulcan_i
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.toString():java.lang.String");
    }

    public static void Vulcan_X(int i) {
        Vulcan_b = i;
    }

    public static int Vulcan__() {
        return Vulcan_b;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_d() {
        return Vulcan__() == 0 ? 31 : 0;
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008d, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0090, code lost:
    
        r11 = "vdt\rApgRma;\\-#1lu;[%xtuu:A%k1ru8Jwi}`s;\u000fjl1uh!\\%i}`s;\u001fvdt\rApgRma;\\-#1lu;[%d~u *J%ddml".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0099, code lost:
    
        ac.vulcan.anticheat.Vulcan_yy.c = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b1, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b4, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b8, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c0, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e8, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ed, code lost:
    
        r7 = 32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f2, code lost:
    
        r7 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f7, code lost:
    
        r7 = 105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00fc, code lost:
    
        r7 = 14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0101, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0106, code lost:
    
        r7 = 43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0108, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0110, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0113, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0118, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x011d, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0121, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0130, code lost:
    
        ac.vulcan.anticheat.Vulcan_yy.Vulcan_c = java.util.Collections.unmodifiableMap(new java.util.HashMap(0));
        ac.vulcan.anticheat.Vulcan_yy.Vulcan_I = new java.util.WeakHashMap();
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0148, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a1, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b1, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b4, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b8, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00c0, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e8, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0110, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0113, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ed, code lost:
    
        r7 = 32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f2, code lost:
    
        r7 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f7, code lost:
    
        r7 = 105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00fc, code lost:
    
        r7 = 14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0101, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0106, code lost:
    
        r7 = 43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0118, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011d, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0042, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0121, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0052, code lost:
    
        if (r2 >= r1) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005e, code lost:
    
        r2 = "vdt\rApgRma;\\-#1lu;[%xtuu:A%k1ru8Jwi}`s;\u000fjl1uh!\\%i}`s;\u001fvdt\rApgRma;\\-#1lu;[%d~u *J%ddml".length();
        r11 = '5';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006d, code lost:
    
        r10 = r10 + 1;
        "vdt\rApgRma;\\-#1lu;[%xtuu:A%k1ru8Jwi}`s;\u000fjl1uh!\\%i}`s;\u001fvdt\rApgRma;\\-#1lu;[%d~u *J%ddml".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007d, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b4, B:28:0x0118], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v19 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x011d -> B:15:0x00b4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x011d -> B:35:0x00b4). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 329
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.m557clinit():void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_yy] */
    /* JADX WARN: Type inference failed for: r12v0, types: [java.lang.Long, java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0033: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0033: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected Vulcan_yy(java.lang.String r12) {
        /*
            r11 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = 59107191479674(0x35c1f726dd7a, double:2.92028327322674E-310)
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 124430659757990(0x712b454627a6, double:6.14769142757837E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            r0.<init>()
            r0 = r11
            r1 = 0
            r0.Vulcan_i = r1
            int r0 = Vulcan_d()
            r1 = r11
            r2 = r12
            r3 = r15
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r1.Vulcan_D(r2)
            r17 = r0
            r0 = r11
            r1 = r12
            r0.Vulcan_e = r1     // Catch: java.lang.IllegalArgumentException -> L6d
            r0 = r11
            r1 = 7
            r2 = r11
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L6d
            java.lang.Class r2 = r2.Vulcan_F(r3)     // Catch: java.lang.IllegalArgumentException -> L6d
            int r2 = r2.hashCode()     // Catch: java.lang.IllegalArgumentException -> L6d
            int r1 = r1 + r2
            r2 = 3
            r3 = r12
            int r3 = r3.hashCode()     // Catch: java.lang.IllegalArgumentException -> L6d
            int r2 = r2 * r3
            int r1 = r1 + r2
            r0.Vulcan_s = r1     // Catch: java.lang.IllegalArgumentException -> L6d
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_k()     // Catch: java.lang.IllegalArgumentException -> L6d
            if (r0 == 0) goto L71
            int r17 = r17 + 1
            r0 = r17
            Vulcan_X(r0)     // Catch: java.lang.IllegalArgumentException -> L6d
            goto L71
        L6d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L71:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.<init>(java.lang.String):void");
    }

    static Class Vulcan_N(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected java.lang.Object readResolve(long r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = Vulcan__()
            java.util.Map r1 = ac.vulcan.anticheat.Vulcan_yy.Vulcan_I
            r2 = r5
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Class r2 = r2.Vulcan_F(r3)
            java.lang.Object r1 = r1.get(r2)
            ac.vulcan.anticheat.Vulcan_kv r1 = (ac.vulcan.anticheat.C0028Vulcan_kv) r1
            r9 = r1
            r8 = r0
            r0 = r9
            r1 = r8
            if (r1 == 0) goto L47
            if (r0 != 0) goto L35
            goto L2f
        L2b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L31
            throw r0     // Catch: java.lang.IllegalArgumentException -> L31
        L2f:
            r0 = 0
            return r0
        L31:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L31
            throw r0
        L35:
            r0 = r9
            java.util.Map r0 = r0.Vulcan_y
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.String r1 = r1.Vulcan_p(r2)
            java.lang.Object r0 = r0.get(r1)
        L47:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.readResolve(long):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected static ac.vulcan.anticheat.Vulcan_yy Vulcan_H(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 135305648585526(0x7b0f4d1ebb36, double:6.68498726543767E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = Vulcan_d()
            r1 = r14
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_kv r1 = Vulcan_c(r1)
            r18 = r1
            r17 = r0
            r0 = r18
            r1 = r17
            if (r1 != 0) goto L72
            if (r0 != 0) goto L67
            goto L61
        L5d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L63
            throw r0     // Catch: java.lang.IllegalArgumentException -> L63
        L61:
            r0 = 0
            return r0
        L63:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L63
            throw r0
        L67:
            r0 = r18
            java.util.Map r0 = r0.Vulcan_y
            r1 = r13
            java.lang.Object r0 = r0.get(r1)
        L72:
            ac.vulcan.anticheat.Vulcan_yy r0 = (ac.vulcan.anticheat.Vulcan_yy) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.Vulcan_H(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_yy");
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected static java.util.Map Vulcan_K(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 118747500725768(0x6c000e994608, double:5.86690606381105E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_d()
            r1 = r11
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_kv r1 = Vulcan_c(r1)
            r17 = r1
            r16 = r0
            r0 = r17
            r1 = r16
            if (r1 != 0) goto L62
            if (r0 != 0) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5c
        L58:
            java.util.Map r0 = ac.vulcan.anticheat.Vulcan_yy.Vulcan_c     // Catch: java.lang.IllegalArgumentException -> L5c
            return r0
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5c
            throw r0
        L60:
            r0 = r17
        L62:
            java.util.Map r0 = r0.Vulcan_L
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.Vulcan_K(java.lang.Object[]):java.util.Map");
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0068: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0068: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    protected static java.util.List m558Vulcan_K(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r0 = r11
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r13
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r12
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_yy.a
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 62395132804410(0x38bf7fb9fd3a, double:3.0827291586361E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int r0 = Vulcan_d()
            r1 = r14
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_kv r1 = Vulcan_c(r1)
            r20 = r1
            r19 = r0
            r0 = r20
            r1 = r19
            if (r1 != 0) goto L90
            if (r0 != 0) goto L8e
            goto L86
        L82:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8a
        L86:
            java.util.List r0 = java.util.Collections.EMPTY_LIST     // Catch: java.lang.IllegalArgumentException -> L8a
            return r0
        L8a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0
        L8e:
            r0 = r20
        L90:
            java.util.List r0 = r0.Vulcan_k
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.m558Vulcan_K(java.lang.Object[]):java.util.List");
    }

    protected static Iterator Vulcan_J(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Class cls = (Class) objArr[1];
        long j = a ^ jLongValue;
        long j2 = j ^ 137641759053347L;
        return m558Vulcan_K(new Object[]{new Integer((int) (j >>> 32)), new Integer((char) ((j2 << 32) >>> 48)), cls, new Integer((short) ((j2 << 48) >>> 48))}).iterator();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.ClassLoader, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r2v6, types: [boolean, java.lang.ClassLoader] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static C0028Vulcan_kv Vulcan_c(Object[] objArr) throws Exception {
        Class cls = (Class) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_d = Vulcan_d();
        try {
            Class cls2 = cls;
            ?? illegalArgumentException = cls2;
            if (Vulcan_d == 0) {
                if (cls2 == null) {
                    throw new IllegalArgumentException(c[11]);
                }
                illegalArgumentException = Vulcan_v;
            }
            try {
                if (Vulcan_d == 0) {
                    if (illegalArgumentException == 0) {
                        illegalArgumentException = Vulcan_N(new Object[]{c[10]});
                        Vulcan_v = illegalArgumentException;
                    } else {
                        illegalArgumentException = Vulcan_v;
                    }
                }
                ?? r0 = illegalArgumentException;
                if (jLongValue > 0) {
                    try {
                        if (!illegalArgumentException.isAssignableFrom(cls)) {
                            illegalArgumentException = new IllegalArgumentException(c[8]);
                            throw illegalArgumentException;
                        }
                        r0 = Vulcan_I.get(cls);
                    } catch (Exception unused) {
                        throw a(illegalArgumentException);
                    }
                }
                C0028Vulcan_kv c0028Vulcan_kv = (C0028Vulcan_kv) r0;
                if (Vulcan_d == 0) {
                    if (c0028Vulcan_kv == null) {
                        try {
                            Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) 1), cls.getClassLoader(), cls.getName());
                            c0028Vulcan_kv = (C0028Vulcan_kv) Vulcan_I.get(cls);
                        } catch (Exception e) {
                        }
                    }
                    return c0028Vulcan_kv;
                }
                return c0028Vulcan_kv;
            } catch (Exception unused2) {
                throw a(illegalArgumentException);
            }
        } catch (Exception unused3) {
            throw a(Vulcan_d);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:68:0x0114, code lost:
    
        if (r0 == 0) goto L3;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:20:0x0076, B:18:0x006e], limit reached: 67 */
    /* JADX WARN: Path cross not found for [B:53:0x010f, B:40:0x00cb], limit reached: 67 */
    /* JADX WARN: Path cross not found for [B:58:0x0032, B:55:0x0114], limit reached: 67 */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00be A[PHI: r0 r13
  0x00be: PHI (r0v24 ac.vulcan.anticheat.Vulcan_kv) = (r0v15 ac.vulcan.anticheat.Vulcan_kv), (r0v37 ac.vulcan.anticheat.Vulcan_kv) binds: [B:35:0x00b1, B:56:0x0119] A[DONT_GENERATE, DONT_INLINE]
  0x00be: PHI (r13v2 java.lang.Class) = (r13v1 java.lang.Class), (r13v5 java.lang.Class) binds: [B:35:0x00b1, B:56:0x0119] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0111  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x011c A[EDGE_INSN: B:70:0x011c->B:57:0x011c BREAK  A[LOOP:0: B:3:0x002d->B:71:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:71:? A[LOOP:0: B:3:0x002d->B:71:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r14v0, types: [ac.vulcan.anticheat.Vulcan_kv, java.lang.Exception] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x00fe -> B:55:0x0114). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static ac.vulcan.anticheat.C0028Vulcan_kv Vulcan_f(java.lang.Object[] r7) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 285
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.Vulcan_f(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_kv");
    }

    public final String Vulcan_p(Object[] objArr) {
        return this.Vulcan_e;
    }

    public Class Vulcan_F(Object[] objArr) {
        return getClass();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public final boolean equals(java.lang.Object r8) {
        /*
            r7 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yy.a
            r1 = 9543958967976(0x8ae2048b6a8, double:4.7153422513954E-311)
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_d()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L25
            r1 = r7
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r8
        L25:
            r1 = r11
            if (r1 != 0) goto L3b
            if (r0 != 0) goto L3a
            goto L34
        L30:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            throw r0     // Catch: java.lang.IllegalArgumentException -> L36
        L34:
            r0 = 0
            return r0
        L36:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            throw r0
        L3a:
            r0 = r8
        L3b:
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d
            r1 = r11
            if (r1 != 0) goto L68
            r1 = r7
            java.lang.Class r1 = r1.getClass()     // Catch: java.lang.IllegalArgumentException -> L4d java.lang.IllegalArgumentException -> L60
            if (r0 != r1) goto L64
            goto L51
        L4d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0     // Catch: java.lang.IllegalArgumentException -> L60
        L51:
            r0 = r7
            java.lang.String r0 = r0.Vulcan_e     // Catch: java.lang.IllegalArgumentException -> L60
            r1 = r8
            ac.vulcan.anticheat.Vulcan_yy r1 = (ac.vulcan.anticheat.Vulcan_yy) r1     // Catch: java.lang.IllegalArgumentException -> L60
            java.lang.String r1 = r1.Vulcan_e     // Catch: java.lang.IllegalArgumentException -> L60
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L60
            return r0
        L60:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0
        L64:
            r0 = r8
            java.lang.Class r0 = r0.getClass()
        L68:
            java.lang.String r0 = r0.getName()     // Catch: java.lang.IllegalArgumentException -> L80
            r1 = r7
            java.lang.Class r1 = r1.getClass()     // Catch: java.lang.IllegalArgumentException -> L80
            java.lang.String r1 = r1.getName()     // Catch: java.lang.IllegalArgumentException -> L80
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L80
            r1 = r11
            if (r1 != 0) goto L9f
            if (r0 != 0) goto L8a
            goto L84
        L80:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L86
            throw r0     // Catch: java.lang.IllegalArgumentException -> L86
        L84:
            r0 = 0
            return r0
        L86:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L86
            throw r0
        L8a:
            r0 = r7
            java.lang.String r0 = r0.Vulcan_e
            r1 = r7
            r2 = r8
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.String r1 = r1.Vulcan_o(r2)
            boolean r0 = r0.equals(r1)
        L9f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        return this.Vulcan_s;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // java.lang.Comparable
    public int compareTo(java.lang.Object r12) {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yy.compareTo(java.lang.Object):int");
    }

    private String Vulcan_o(Object[] objArr) {
        Object obj = objArr[0];
        try {
            Class<?> cls = obj.getClass();
            return (String) cls.getMethod(me.frep.vulcan.spigot.Vulcan_m.b(c[6], cls, (Class[]) null), null).invoke(obj, null);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            throw new IllegalStateException(c[4]);
        }
    }
}
