package ac.vulcan.anticheat;

import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_yP.class */
public abstract class Vulcan_yP extends Vulcan_yy {
    private static final long serialVersionUID = -7129650521543789085L;
    private final int Vulcan_u;
    private static final long b = me.frep.vulcan.spigot.Vulcan_n.a(-1310183013827685914L, -5604691224743715329L, null).a(196996113626843L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // ac.vulcan.anticheat.Vulcan_yy
    public java.lang.String toString() {
        /*
            r8 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yP.b
            r1 = 112640140321803(0x6672138d240b, double:5.565162367574E-310)
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 121208263311470(0x6e3cff7a806e, double:5.98848388942773E-310)
            long r1 = r1 ^ r2
            r11 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_yy.Vulcan__()
            r13 = r0
            r0 = r8
            java.lang.String r0 = r0.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L24
            r1 = r13
            if (r1 == 0) goto L8c
            if (r0 != 0) goto L88
            goto L28
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L28:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Class r0 = r0.Vulcan_F(r1)
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(r0)
            r14 = r0
            r0 = r8
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r2 = r1
            r2.<init>()
            r2 = r14
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "["
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r2 = r2.Vulcan_p(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "="
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            int r2 = r2.Vulcan_O(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "]"
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.Vulcan_i = r1
        L88:
            r0 = r8
            java.lang.String r0 = r0.Vulcan_i
        L8c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yP.toString():java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0085, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0088, code lost:
    
        r11 = "G2R\u0004M6\u0019~ztHi+\u001f37BW|x\u0002|.\u0017Fmx\u0002f6[\bt?Cri4\u0019v".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0091, code lost:
    
        ac.vulcan.anticheat.Vulcan_yP.d = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ee, code lost:
    
        r7 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f3, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f8, code lost:
    
        r7 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fd, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0107, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0127, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0099, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a9, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b8, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0107, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ee, code lost:
    
        r7 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f3, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f8, code lost:
    
        r7 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fd, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003b, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004b, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0057, code lost:
    
        r2 = "G2R\u0004M6\u0019~ztHi+\u001f37BW|x\u0002|.\u0017Fmx\u0002f6[\bt?Cri4\u0019v".length();
        r11 = 31;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0065, code lost:
    
        r10 = r10 + 1;
        "G2R\u0004M6\u0019~ztHi+\u001f37BW|x\u0002|.\u0017Fmx\u0002f6[\bt?Cri4\u0019v".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0075, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ac, B:28:0x010f], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0114 -> B:15:0x00ac). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0114 -> B:34:0x00ac). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yP.m555clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    protected Vulcan_yP(String str, int i) {
        super(str);
        this.Vulcan_u = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_yP, ac.vulcan.anticheat.Vulcan_yy] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v22, types: [int] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    protected static Vulcan_yy Vulcan_W(Object[] objArr) {
        Class cls = (Class) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        long jLongValue = b ^ ((Long) objArr[2]).longValue();
        long j = jLongValue ^ 115622552939311L;
        int i = (int) (jLongValue >>> 32);
        int i2 = (int) ((j << 32) >>> 48);
        int i3 = (int) ((j << 48) >>> 48);
        ?? Vulcan_d = Vulcan_yy.Vulcan_d();
        try {
            Class cls2 = cls;
            if (Vulcan_d == 0) {
                if (cls2 == null) {
                    throw new IllegalArgumentException(d[2]);
                }
                cls2 = cls;
            }
            for (Vulcan_yP vulcan_yP : Vulcan_yy.m558Vulcan_K(new Object[]{new Integer(i), new Integer((char) i2), cls2, new Integer((short) i3)})) {
                ?? A = vulcan_yP;
                ?? r1 = Vulcan_d;
                int i4 = r1;
                if (jLongValue > 0) {
                    if (r1 != 0) {
                        return A;
                    }
                    i4 = 0;
                }
                try {
                    try {
                        A = A.Vulcan_O(new Object[i4]);
                        if (jLongValue >= 0) {
                            if (A == iIntValue) {
                                return vulcan_yP;
                            }
                            A = Vulcan_d;
                        }
                        if (A != 0) {
                            return null;
                        }
                    } catch (IllegalArgumentException unused) {
                        A = a((IllegalArgumentException) A);
                        throw A;
                    }
                } catch (IllegalArgumentException unused2) {
                    throw a((IllegalArgumentException) A);
                }
            }
            return null;
        } catch (IllegalArgumentException unused3) {
            throw a((IllegalArgumentException) Vulcan_d);
        }
    }

    public final int Vulcan_O(Object[] objArr) {
        return this.Vulcan_u;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_yy, java.lang.Comparable
    public int compareTo(java.lang.Object r12) {
        /*
            Method dump skipped, instruction units count: 216
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yP.compareTo(java.lang.Object):int");
    }

    private int Vulcan_s(Object[] objArr) {
        Object obj = objArr[0];
        try {
            Class<?> cls = obj.getClass();
            return ((Integer) cls.getMethod(me.frep.vulcan.spigot.Vulcan_m.b(d[3], cls, (Class[]) null), null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            throw new IllegalStateException(d[1]);
        }
    }
}
