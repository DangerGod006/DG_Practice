package ac.vulcan.anticheat;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Op.class */
class Vulcan_Op implements Iterator {
    private char Vulcan_R;
    private final Vulcan_A Vulcan_I;
    private boolean Vulcan_r;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(8009023057660321444L, -4946207187442050668L, null).a(8036367330444L);

    private static NoSuchElementException a(NoSuchElementException noSuchElementException) {
        return noSuchElementException;
    }

    Vulcan_Op(Vulcan_A vulcan_A, Vulcan_fZ vulcan_fZ) {
        this(vulcan_A);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v26, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [char] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v35, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Throwable, java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.util.NoSuchElementException] */
    private Vulcan_Op(Vulcan_A vulcan_A) {
        long j = a ^ 107518900240814L;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            try {
                try {
                    this.Vulcan_I = vulcan_A;
                    this.Vulcan_r = true;
                    Vulcan_k = this;
                    try {
                        try {
                            if (Vulcan_k == 0) {
                                Vulcan_k = Vulcan_A.Vulcan_P(new Object[]{Vulcan_k.Vulcan_I});
                                if (Vulcan_k != 0) {
                                    Vulcan_k = this;
                                    ?? r0 = Vulcan_k;
                                    if (Vulcan_k == 0) {
                                        try {
                                            Vulcan_k = Vulcan_A.Vulcan__(new Object[]{Vulcan_k.Vulcan_I});
                                            if (Vulcan_k == 0) {
                                                try {
                                                    Vulcan_Op vulcan_Op = this;
                                                    ?? r02 = vulcan_Op;
                                                    if (Vulcan_k == 0) {
                                                        if (Vulcan_A.Vulcan_G(new Object[]{vulcan_Op.Vulcan_I}) == 65535) {
                                                            this.Vulcan_r = false;
                                                            if (Vulcan_k == 0) {
                                                                return;
                                                            }
                                                        }
                                                        r02 = this;
                                                    }
                                                    try {
                                                        r02.Vulcan_R = (char) (Vulcan_A.Vulcan_G(new Object[]{this.Vulcan_I}) + 1);
                                                        r02 = Vulcan_k;
                                                        if (r02 == 0) {
                                                            return;
                                                        }
                                                    } catch (NoSuchElementException unused) {
                                                        throw a(r02);
                                                    }
                                                } catch (NoSuchElementException unused2) {
                                                    throw a(Vulcan_k);
                                                }
                                            }
                                            r0 = this;
                                        } catch (NoSuchElementException unused3) {
                                            throw a(Vulcan_k);
                                        }
                                    }
                                    try {
                                        r0.Vulcan_R = (char) 0;
                                        r0 = Vulcan_k;
                                        if (r0 == 0) {
                                            return;
                                        }
                                    } catch (NoSuchElementException unused4) {
                                        throw a(r0);
                                    }
                                }
                                Vulcan_k = this;
                            }
                            Vulcan_k.Vulcan_R = Vulcan_A.Vulcan__(new Object[]{this.Vulcan_I});
                        } catch (NoSuchElementException unused5) {
                            throw a(Vulcan_k);
                        }
                    } catch (NoSuchElementException unused6) {
                        throw a(Vulcan_k);
                    }
                } catch (NoSuchElementException unused7) {
                    throw a(Vulcan_k);
                }
            } catch (NoSuchElementException unused8) {
                Vulcan_k = a(Vulcan_k);
                throw Vulcan_k;
            }
        } catch (NoSuchElementException unused9) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:36:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0121  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0150 A[Catch: NoSuchElementException -> 0x0163, NoSuchElementException -> 0x016b, TRY_ENTER, TryCatch #3 {NoSuchElementException -> 0x0163, blocks: (B:79:0x013d, B:81:0x0150), top: B:94:0x013d, outer: #8 }] */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0098 A[EXC_TOP_SPLITTER, PHI: r0 r1
  0x0098: PHI (r0v33 ??) = (r0v65 ??), (r0v66 ??), (r0v67 ??) binds: [B:10:0x003f, B:12:0x0044, B:32:0x007c] A[DONT_GENERATE, DONT_INLINE]
  0x0098: PHI (r1v21 char) = (r1v20 char), (r1v20 char), (r1v53 char) binds: [B:10:0x003f, B:12:0x0044, B:32:0x007c] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Throwable, java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v30, types: [char] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v51, types: [ac.vulcan.anticheat.Vulcan_Op] */
    /* JADX WARN: Type inference failed for: r0v52, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v54, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v57, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v71 */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void Vulcan_A(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 372
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Op.Vulcan_A(java.lang.Object[]):void");
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.Vulcan_r;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r2v2, types: [ac.vulcan.anticheat.Vulcan_Op, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.util.Iterator
    public java.lang.Object next() {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_Op.a
            r1 = 9466652476983(0x89c20754637, double:4.677147769995E-311)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 28162523552048(0x199d19365930, double:1.3914135387262E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r9
            boolean r0 = r0.Vulcan_r     // Catch: java.util.NoSuchElementException -> L24
            r1 = r14
            if (r1 != 0) goto L38
            if (r0 != 0) goto L34
            goto L28
        L24:
            java.util.NoSuchElementException r0 = a(r0)     // Catch: java.util.NoSuchElementException -> L30
            throw r0     // Catch: java.util.NoSuchElementException -> L30
        L28:
            java.util.NoSuchElementException r0 = new java.util.NoSuchElementException     // Catch: java.util.NoSuchElementException -> L30
            r1 = r0
            r1.<init>()     // Catch: java.util.NoSuchElementException -> L30
            throw r0     // Catch: java.util.NoSuchElementException -> L30
        L30:
            java.util.NoSuchElementException r0 = a(r0)     // Catch: java.util.NoSuchElementException -> L30
            throw r0
        L34:
            r0 = r9
            char r0 = r0.Vulcan_R
        L38:
            r15 = r0
            r0 = r9
            r1 = r12
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_A(r1)
            java.lang.Character r0 = new java.lang.Character
            r1 = r0
            r2 = r15
            r1.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Op.next():java.lang.Object");
    }

    @Override // java.util.Iterator
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
