package ac.vulcan.anticheat;

import java.util.Map;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_p.class */
abstract class AbstractC0032Vulcan_p implements Vulcan_fn {
    protected final Map Vulcan_A;
    protected final Map Vulcan_r;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    AbstractC0032Vulcan_p(Map map, Map map2) {
        this.Vulcan_A = map;
        this.Vulcan_r = map2;
    }

    @Override // ac.vulcan.anticheat.Vulcan_fn
    public void Vulcan_A(Object[] objArr) {
        String str = (String) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        ((Long) objArr[2]).longValue();
        this.Vulcan_A.put(str, new Integer(iIntValue));
        this.Vulcan_r.put(new Integer(iIntValue), str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_fn
    public String Vulcan_K(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (String) this.Vulcan_r.get(new Integer(((Integer) objArr[1]).intValue()));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_fn
    public int Vulcan_n(java.lang.Object[] r5) {
        /*
            r4 = this;
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r4
            java.util.Map r1 = r1.Vulcan_A
            r2 = r8
            java.lang.Object r1 = r1.get(r2)
            r10 = r1
            r9 = r0
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0     // Catch: java.lang.RuntimeException -> L39
        L37:
            r0 = -1
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0
        L3d:
            r0 = r10
        L3f:
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0032Vulcan_p.Vulcan_n(java.lang.Object[]):int");
    }
}
