package ac.vulcan.anticheat;

import java.math.BigInteger;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O9.class */
public class Vulcan_O9 {
    public static final Long Vulcan_J;
    public static final Long Vulcan_v;
    public static final Long Vulcan__;
    public static final Integer Vulcan_D;
    public static final Integer Vulcan_U;
    public static final Integer Vulcan_y;
    public static final Short Vulcan_Y;
    public static final Short Vulcan_C;
    public static final Short Vulcan_W;
    public static final Byte Vulcan_t;
    public static final Byte Vulcan_G;
    public static final Byte Vulcan_f;
    public static final Double Vulcan_A;
    public static final Double Vulcan_p;
    public static final Double Vulcan_e;
    public static final Float Vulcan_H;
    public static final Float Vulcan_P;
    public static final Float Vulcan_K;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(2217979555929982118L, -8122953722424268886L, null).a(151832247007722L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static long Vulcan_X(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 74858529197596(0x44155c0a8e1c, double:3.6985027574736E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r14
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            long r0 = Vulcan_R(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_X(java.lang.Object[]):long");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static float m71Vulcan_y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 138265658823139(0x7dc07b7a91e3, double:6.83123120241196E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r10
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = m72Vulcan_g(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m71Vulcan_y(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static byte Vulcan_H(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 42603681072475(0x26bf7146c55b, double:2.1049015204287E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r12
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            byte r0 = Vulcan_u(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_H(java.lang.Object[]):byte");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x012f: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Number Vulcan_r(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 2172
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_r(java.lang.Object[]):java.lang.Number");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public static boolean m82Vulcan_D(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 7616728242267(0x6ed6861985b, double:3.763163758213E-311)
            long r1 = r1 ^ r2
            r12 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r14 = r0
            r0 = r12
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.NumberFormatException -> L50
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.NumberFormatException -> L50
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NumberFormatException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NumberFormatException -> L50
            r2[r3] = r4     // Catch: java.lang.NumberFormatException -> L50
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.NumberFormatException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NumberFormatException -> L50
            java.lang.Long r3 = new java.lang.Long     // Catch: java.lang.NumberFormatException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NumberFormatException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NumberFormatException -> L50
            r3.<init>(r4)     // Catch: java.lang.NumberFormatException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NumberFormatException -> L50
            r1[r2] = r3     // Catch: java.lang.NumberFormatException -> L50
            boolean r0 = ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_Q(r0)     // Catch: java.lang.NumberFormatException -> L50
            r1 = r14
            if (r1 != 0) goto L5b
            if (r0 == 0) goto L5a
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L56
            throw r0     // Catch: java.lang.NumberFormatException -> L56
        L54:
            r0 = 0
            return r0
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L56
            throw r0
        L5a:
            r0 = 0
        L5b:
            r15 = r0
        L5d:
            r0 = r15
            r1 = r9
            int r1 = r1.length()
            if (r0 >= r1) goto L9a
        L66:
            r0 = r9
            r1 = r15
            char r0 = r0.charAt(r1)     // Catch: java.lang.NumberFormatException -> L82
            boolean r0 = java.lang.Character.isDigit(r0)     // Catch: java.lang.NumberFormatException -> L82
            r1 = r14
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L7c
            if (r1 != 0) goto La1
            r1 = r14
        L7c:
            if (r1 != 0) goto L91
            goto L86
        L82:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L8c
            throw r0     // Catch: java.lang.NumberFormatException -> L8c
        L86:
            if (r0 != 0) goto L92
            goto L90
        L8c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L90:
            r0 = 0
        L91:
            return r0
        L92:
            int r15 = r15 + 1
            r0 = r14
            if (r0 == 0) goto L5d
        L9a:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L66
            r0 = 1
        La1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m82Vulcan_D(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public static boolean m83Vulcan_y(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 1715
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m83Vulcan_y(java.lang.Object[]):boolean");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r11 = "J\u0014,T\\2/J\u001c\u007f\u0002S12\u000e]1\u0001_?>\u0018S\u0002GP".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.Vulcan_O9.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ac, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bb, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_J = new java.lang.Long(0);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_v = new java.lang.Long(1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan__ = new java.lang.Long(-1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_D = new java.lang.Integer(0);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_U = new java.lang.Integer(1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_y = new java.lang.Integer(-1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_Y = new java.lang.Short((short) 0);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_C = new java.lang.Short((short) 1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_W = new java.lang.Short((short) -1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_t = new java.lang.Byte((byte) 0);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_G = new java.lang.Byte((byte) 1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_f = new java.lang.Byte((byte) -1);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_A = new java.lang.Double(0.0d);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_p = new java.lang.Double(1.0d);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_e = new java.lang.Double(-1.0d);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_H = new java.lang.Float(0.0f);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_P = new java.lang.Float(1.0f);
        ac.vulcan.anticheat.Vulcan_O9.Vulcan_K = new java.lang.Float(-1.0f);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x01f4, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x009c, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ac, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00bb, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e0, code lost:
    
        r7 = 67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e5, code lost:
    
        r7 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        r7 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ef, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f4, code lost:
    
        r7 = 27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f9, code lost:
    
        r7 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00fe, code lost:
    
        r7 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003d, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "J\u0014,T\\2/J\u001c\u007f\u0002S12\u000e]1\u0001_?>\u0018S\u0002GP".length();
        r11 = 23;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0068, code lost:
    
        r10 = r10 + 1;
        "J\u0014,T\\2/J\u001c\u007f\u0002S12\u000e]1\u0001_?>\u0018S\u0002GP".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0078, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00af, B:28:0x0110], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r5v30 */
    /* JADX WARN: Type inference failed for: r5v31 */
    /* JADX WARN: Type inference failed for: r5v35 */
    /* JADX WARN: Type inference failed for: r5v45 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00af). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0115 -> B:35:0x00af). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 501
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m70clinit():void");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_a(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 77431272019694(0x466c5f7696ee, double:3.82561314187194E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_K(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_a(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_K(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 215773039950(0x323d134d4e, double:1.06606046338E-312)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_K(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_g(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 106524632659953(0x60e232e3b7f1, double:5.2630161433141E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_g(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_y(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 != 0) goto L41
            if (r0 != 0) goto L40
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0     // Catch: java.lang.NumberFormatException -> L3c
        L39:
            r0 = r9
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0
        L40:
            r0 = r8
        L41:
            int r0 = java.lang.Integer.parseInt(r0)     // Catch: java.lang.NumberFormatException -> L45
            return r0
        L45:
            r11 = move-exception
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_y(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static long Vulcan_R(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 == 0) goto L42
            if (r0 != 0) goto L41
            goto L3b
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3d
            throw r0     // Catch: java.lang.NumberFormatException -> L3d
        L3b:
            r0 = r6
            return r0
        L3d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3d
            throw r0
        L41:
            r0 = r8
        L42:
            long r0 = java.lang.Long.parseLong(r0)     // Catch: java.lang.NumberFormatException -> L46
            return r0
        L46:
            r12 = move-exception
            r0 = r6
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_R(java.lang.Object[]):long");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public static float m72Vulcan_g(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L38
        L34:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3a
            throw r0     // Catch: java.lang.NumberFormatException -> L3a
        L38:
            r0 = r7
            return r0
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3a
            throw r0
        L3e:
            r0 = r6
        L3f:
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: java.lang.NumberFormatException -> L43
            return r0
        L43:
            r11 = move-exception
            r0 = r7
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m72Vulcan_g(java.lang.Object[]):float");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static double Vulcan_I(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 10068574730926(0x92845d1faae, double:4.974536877136E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r15
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            double r0 = Vulcan_x(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_I(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static double Vulcan_x(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L42
            if (r0 != 0) goto L40
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0     // Catch: java.lang.NumberFormatException -> L3c
        L3a:
            r0 = r8
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0
        L40:
            r0 = r10
        L42:
            double r0 = java.lang.Double.parseDouble(r0)     // Catch: java.lang.NumberFormatException -> L46
            return r0
        L46:
            r12 = move-exception
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_x(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static byte Vulcan_u(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r10 = r0
            r0 = r8
            r1 = r10
            if (r1 == 0) goto L41
            if (r0 != 0) goto L40
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0     // Catch: java.lang.NumberFormatException -> L3c
        L39:
            r0 = r9
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3c
            throw r0
        L40:
            r0 = r8
        L41:
            byte r0 = java.lang.Byte.parseByte(r0)     // Catch: java.lang.NumberFormatException -> L45
            return r0
        L45:
            r11 = move-exception
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_u(java.lang.Object[]):byte");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static short Vulcan_k(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 138588235093006(0x7e0b9685d40e, double:6.84716858772245E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            r2 = 0
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            short r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_k(java.lang.Object[]):short");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static short Vulcan_h(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L38
        L34:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3a
            throw r0     // Catch: java.lang.NumberFormatException -> L3a
        L38:
            r0 = r7
            return r0
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3a
            throw r0
        L3e:
            r0 = r6
        L3f:
            short r0 = java.lang.Short.parseShort(r0)     // Catch: java.lang.NumberFormatException -> L43
            return r0
        L43:
            r11 = move-exception
            r0 = r7
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_h(java.lang.Object[]):short");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static boolean Vulcan_F(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 1
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length()
            r1 = 1
            int r0 = r0 - r1
            r12 = r0
        L3c:
            r0 = r12
            if (r0 < 0) goto L81
            r0 = r10
        L42:
            r1 = r12
            char r0 = r0.charAt(r1)     // Catch: java.lang.NumberFormatException -> L5a
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8d
            if (r1 != 0) goto L8b
            r1 = r11
            if (r1 != 0) goto L78
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L6c
            throw r0     // Catch: java.lang.NumberFormatException -> L6c
        L5e:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L7e
            r1 = 48
            if (r0 == r1) goto L79
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L74
            throw r0     // Catch: java.lang.NumberFormatException -> L74
        L70:
            r0 = 0
            goto L78
        L74:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L78:
            return r0
        L79:
            int r12 = r12 + (-1)
            r0 = r11
        L7e:
            if (r0 == 0) goto L3c
        L81:
            r0 = r10
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L42
            int r0 = r0.length()
        L8b:
            r1 = r11
        L8d:
            if (r1 != 0) goto L9b
            if (r0 <= 0) goto L9e
            goto L9a
        L96:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9a:
            r0 = 1
        L9b:
            goto L9f
        L9e:
            r0 = 0
        L9f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_F(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Float Vulcan_q(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            java.lang.Float r0 = java.lang.Float.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_q(java.lang.Object[]):java.lang.Float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Double Vulcan_L(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            java.lang.Double r0 = java.lang.Double.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_L(java.lang.Object[]):java.lang.Double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static java.lang.Integer m73Vulcan_r(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 == 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            java.lang.Integer r0 = java.lang.Integer.decode(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m73Vulcan_r(java.lang.Object[]):java.lang.Integer");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Long Vulcan_U(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 == 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_U(java.lang.Object[]):java.lang.Long");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static BigInteger Vulcan_G(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        long j = a ^ jLongValue;
        if (str == null) {
            return null;
        }
        return new BigInteger(str);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.math.BigDecimal Vulcan_i(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 126954264554160(0x7376d7d76ab0, double:6.27237407092515E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L39
            throw r0     // Catch: java.lang.NumberFormatException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L39
            throw r0
        L3d:
            r0 = r10
        L3e:
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.NumberFormatException -> L6b
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NumberFormatException -> L6b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NumberFormatException -> L6b
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.NumberFormatException -> L6b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NumberFormatException -> L6b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NumberFormatException -> L6b
            r4.<init>(r5)     // Catch: java.lang.NumberFormatException -> L6b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NumberFormatException -> L6b
            r2[r3] = r4     // Catch: java.lang.NumberFormatException -> L6b
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.NumberFormatException -> L6b
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NumberFormatException -> L6b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NumberFormatException -> L6b
            r1[r2] = r3     // Catch: java.lang.NumberFormatException -> L6b
            boolean r0 = ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_S(r0)     // Catch: java.lang.NumberFormatException -> L6b
            if (r0 == 0) goto L6f
            java.lang.NumberFormatException r0 = new java.lang.NumberFormatException     // Catch: java.lang.NumberFormatException -> L6b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L6b
            r3 = 5
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L6b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L6b
            throw r0     // Catch: java.lang.NumberFormatException -> L6b
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L6b
            throw r0
        L6f:
            java.math.BigDecimal r0 = new java.math.BigDecimal
            r1 = r0
            r2 = r10
            r1.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_i(java.lang.Object[]):java.math.BigDecimal");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r15];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007f, code lost:
    
        if (r0 < 0) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0082, code lost:
    
        if (r1 == 0) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0087, code lost:
    
        if (r1 == 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008d, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0091, code lost:
    
        r0 = (r0 > r13 ? 1 : (r0 == r13 ? 0 : -1));
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0097, code lost:
    
        if (r0 < 0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x009a, code lost:
    
        if (r0 >= 0) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00a0, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00a3, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a4, code lost:
    
        r0 = r1[r15];
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00ae, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        r13 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b1, code lost:
    
        r15 = r15 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b6, code lost:
    
        if (r0 != 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00b9, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00bc, code lost:
    
        if (r0 < 0) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00c1, code lost:
    
        return r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00b9, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:57:0x0076, B:51:0x00b9], limit reached: 66 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [long] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27, types: [long] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7 */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [long] */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Type inference failed for: r1v6, types: [long[]] */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static long Vulcan_Z(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r11
        L40:
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L69
            if (r1 == 0) goto L68
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L52 java.lang.NumberFormatException -> L63
            if (r0 != 0) goto L67
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L63
            throw r0     // Catch: java.lang.NumberFormatException -> L63
        L56:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L63
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L63
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L63
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L63
            throw r0     // Catch: java.lang.NumberFormatException -> L63
        L63:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L63
            throw r0
        L67:
            r0 = r11
        L68:
            r1 = 0
        L69:
            r0 = r0[r1]
            r13 = r0
            r0 = 1
            r15 = r0
        L6f:
            r0 = r15
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto Lb9
        L76:
            r0 = r11
            r1 = r15
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L8d
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L87
            if (r1 == 0) goto Lc1
            r1 = r12
        L87:
            if (r1 == 0) goto Laf
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La0
            throw r0     // Catch: java.lang.NumberFormatException -> La0
        L91:
            r1 = r13
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb6
            if (r0 >= 0) goto Lb1
            goto La4
        La0:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> Lab
            throw r0     // Catch: java.lang.NumberFormatException -> Lab
        La4:
            r0 = r11
            r1 = r15
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> Lab
            goto Laf
        Lab:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Laf:
            r13 = r0
        Lb1:
            int r15 = r15 + 1
            r0 = r12
        Lb6:
            if (r0 != 0) goto L6f
        Lb9:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L76
            r0 = r13
        Lc1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_Z(java.lang.Object[]):long");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 < 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 == 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 >= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 != 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int m74Vulcan_R(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r10
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 == 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r10
            r1 = 0
            r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L81
            if (r1 == 0) goto Lba
            r1 = r11
        L81:
            if (r1 == 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            r1 = r12
            if (r0 >= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 != 0) goto L69
        Lb2:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m74Vulcan_R(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 < 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 == 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 >= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 != 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [short] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27, types: [short] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static short Vulcan_D(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r10
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 == 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r10
            r1 = 0
            short r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r10
            r1 = r13
            short r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L81
            if (r1 == 0) goto Lba
            r1 = r11
        L81:
            if (r1 == 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            r1 = r12
            if (r0 >= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r10
            r1 = r13
            short r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 != 0) goto L69
        Lb2:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_D(java.lang.Object[]):short");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 <= 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 == 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 >= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 != 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [byte] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v6, types: [byte[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static byte Vulcan_c(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r10
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 == 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r10
            r1 = 0
            r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L81
            if (r1 == 0) goto Lba
            r1 = r11
        L81:
            if (r1 == 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            r1 = r12
            if (r0 >= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 != 0) goto L69
        Lb2:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_c(java.lang.Object[]):byte");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r14];
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        if (r0 != 0) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x007f, code lost:
    
        r0 = java.lang.Double.isNaN(r0);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        if (r0 <= 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0088, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x008a, code lost:
    
        if (r0 != 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0094, code lost:
    
        if (r0 == 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009a, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x009e, code lost:
    
        return Double.NaN;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00a5, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00a6, code lost:
    
        r0 = r1[r14];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ac, code lost:
    
        if (r0 != 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00af, code lost:
    
        r0 = (r0 > r12 ? 1 : (r0 == r12 ? 0 : -1));
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00b8, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00b9, code lost:
    
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00bc, code lost:
    
        if (r0 <= 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00bf, code lost:
    
        if (r0 >= 0) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00c2, code lost:
    
        r0 = r1[r14];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00cc, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00cd, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00cf, code lost:
    
        r14 = r14 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00d4, code lost:
    
        if (r0 == 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00d7, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00da, code lost:
    
        if (r0 <= 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00df, code lost:
    
        return r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00d7, code lost:
    
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:70:0x0076, B:62:0x00d7], limit reached: 81 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [double] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [double] */
    /* JADX WARN: Type inference failed for: r0v36, types: [double] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [int] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v23, types: [double] */
    /* JADX WARN: Type inference failed for: r1v26 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v6, types: [double[]] */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static double Vulcan_n(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_n(java.lang.Object[]):double");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        if (r0 != 0) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x007f, code lost:
    
        r0 = java.lang.Float.isNaN(r0);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0088, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x008a, code lost:
    
        if (r0 != 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0094, code lost:
    
        if (r0 == 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009a, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x009e, code lost:
    
        return Float.NaN;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00a5, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00a6, code lost:
    
        r0 = r1[r13];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ac, code lost:
    
        if (r0 != 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00af, code lost:
    
        r0 = (r0 > (r12 == true ? 1 : 0 ? 1.0f : 0.0f) ? 1 : (r0 == (r12 == true ? 1 : 0 ? 1.0f : 0.0f) ? 0 : -1));
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00b8, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00b9, code lost:
    
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00bc, code lost:
    
        if (r0 <= 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00bf, code lost:
    
        if (r0 >= 0) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00c2, code lost:
    
        r0 = r1[r13];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00cc, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00cd, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00cf, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00d4, code lost:
    
        if (r0 == 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00d7, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00da, code lost:
    
        if (r0 < 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00df, code lost:
    
        return r12 == true ? 1 : 0 ? 1.0f : 0.0f;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00d7, code lost:
    
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:70:0x0076, B:62:0x00d7], limit reached: 81 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [float] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [float] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [int] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v2, types: [float[]] */
    /* JADX WARN: Type inference failed for: r1v26 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static float Vulcan_v(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_v(java.lang.Object[]):float");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r15];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007f, code lost:
    
        if (r0 <= 0) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0082, code lost:
    
        if (r1 == 0) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0087, code lost:
    
        if (r1 == 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008d, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0091, code lost:
    
        r0 = (r0 > r13 ? 1 : (r0 == r13 ? 0 : -1));
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0097, code lost:
    
        if (r0 < 0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x009a, code lost:
    
        if (r0 <= 0) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00a0, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00a3, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a4, code lost:
    
        r0 = r1[r15];
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00ae, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        r13 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b1, code lost:
    
        r15 = r15 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b6, code lost:
    
        if (r0 != 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00b9, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00bc, code lost:
    
        if (r0 <= 0) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00c1, code lost:
    
        return r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00b9, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:57:0x0076, B:51:0x00b9], limit reached: 66 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [long] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27, types: [long] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7 */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [long] */
    /* JADX WARN: Type inference failed for: r1v2, types: [long[]] */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static long Vulcan_o(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r11
        L40:
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L69
            if (r1 == 0) goto L68
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L52 java.lang.NumberFormatException -> L63
            if (r0 != 0) goto L67
            goto L56
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L63
            throw r0     // Catch: java.lang.NumberFormatException -> L63
        L56:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L63
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L63
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L63
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L63
            throw r0     // Catch: java.lang.NumberFormatException -> L63
        L63:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L63
            throw r0
        L67:
            r0 = r11
        L68:
            r1 = 0
        L69:
            r0 = r0[r1]
            r13 = r0
            r0 = 1
            r15 = r0
        L6f:
            r0 = r15
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto Lb9
        L76:
            r0 = r11
            r1 = r15
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L8d
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L87
            if (r1 == 0) goto Lc1
            r1 = r12
        L87:
            if (r1 == 0) goto Laf
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La0
            throw r0     // Catch: java.lang.NumberFormatException -> La0
        L91:
            r1 = r13
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb6
            if (r0 <= 0) goto Lb1
            goto La4
        La0:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> Lab
            throw r0     // Catch: java.lang.NumberFormatException -> Lab
        La4:
            r0 = r11
            r1 = r15
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> Lab
            goto Laf
        Lab:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Laf:
            r13 = r0
        Lb1:
            int r15 = r15 + 1
            r0 = r12
        Lb6:
            if (r0 != 0) goto L6f
        Lb9:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L76
            r0 = r13
        Lc1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_o(java.lang.Object[]):long");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 < 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 != 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 != 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 <= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 == 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 == 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v6, types: [int[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int Vulcan_s(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 0
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r8
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 != 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r8
            r1 = 0
            r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r8
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L81
            if (r1 != 0) goto Lba
            r1 = r11
        L81:
            if (r1 != 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            r1 = r12
            if (r0 <= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r8
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 == 0) goto L69
        Lb2:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_s(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 < 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 != 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 != 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 <= 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 <= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 == 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 == 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [short] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27, types: [short] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static short Vulcan_W(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r8
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 != 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r8
            r1 = 0
            short r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r8
            r1 = r13
            short r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L81
            if (r1 != 0) goto Lba
            r1 = r11
        L81:
            if (r1 != 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Laf
            r1 = r12
            if (r0 <= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r8
            r1 = r13
            short r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 == 0) goto L69
        Lb2:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_W(java.lang.Object[]):short");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x006d, code lost:
    
        if (r0 < r1.length) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0070, code lost:
    
        r0 = r1[r13];
        r1 = r0;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0079, code lost:
    
        if (r0 <= 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x007c, code lost:
    
        if (r1 == 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
    
        if (r1 == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0087, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x008a, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0091, code lost:
    
        r1 = r12 == true ? 1 : 0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        if (r0 <= r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00a7, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00a8, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00aa, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00af, code lost:
    
        if (r0 != 0) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b2, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00b5, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00ba, code lost:
    
        return r12 == true ? 1 : 0 ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00b2, code lost:
    
        if (r0 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x0070, B:49:0x00b2], limit reached: 63 */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [byte] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v6, types: [byte[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static byte m75Vulcan_F(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L2e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L3b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L3b
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L3b
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0     // Catch: java.lang.NumberFormatException -> L3b
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3b
            throw r0
        L3f:
            r0 = r10
        L40:
            int r0 = r0.length     // Catch: java.lang.NumberFormatException -> L4c
            r1 = r11
            if (r1 == 0) goto L64
            if (r0 != 0) goto L61
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L50:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.NumberFormatException -> L5d
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O9.b     // Catch: java.lang.NumberFormatException -> L5d
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.NumberFormatException -> L5d
            r1.<init>(r2)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0     // Catch: java.lang.NumberFormatException -> L5d
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L5d
            throw r0
        L61:
            r0 = r10
            r1 = 0
            r0 = r0[r1]
        L64:
            r12 = r0
            r0 = 1
            r13 = r0
        L69:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto Lb2
        L70:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> L87
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L81
            if (r1 == 0) goto Lba
            r1 = r11
        L81:
            if (r1 == 0) goto La8
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L99
            throw r0     // Catch: java.lang.NumberFormatException -> L99
        L8b:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Laf
            r1 = r12
            if (r0 <= r1) goto Laa
            goto L9d
        L99:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La4
            throw r0     // Catch: java.lang.NumberFormatException -> La4
        L9d:
            r0 = r10
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.NumberFormatException -> La4
            goto La8
        La4:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La8:
            r12 = r0
        Laa:
            int r13 = r13 + 1
            r0 = r11
        Laf:
            if (r0 != 0) goto L69
        Lb2:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L70
            r0 = r12
        Lba:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m75Vulcan_F(java.lang.Object[]):byte");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r14];
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        if (r0 == 0) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x007f, code lost:
    
        r0 = java.lang.Double.isNaN(r0);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        if (r0 < 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0088, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x008a, code lost:
    
        if (r0 == 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0094, code lost:
    
        if (r0 == 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009a, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x009e, code lost:
    
        return Double.NaN;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00a5, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00a6, code lost:
    
        r0 = r1[r14];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ac, code lost:
    
        if (r0 == 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00af, code lost:
    
        r0 = (r0 > r12 ? 1 : (r0 == r12 ? 0 : -1));
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00b8, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00b9, code lost:
    
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00bc, code lost:
    
        if (r0 < 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00bf, code lost:
    
        if (r0 <= 0) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00c2, code lost:
    
        r0 = r1[r14];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00cc, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00cd, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00cf, code lost:
    
        r14 = r14 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00d4, code lost:
    
        if (r0 != 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00d7, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00da, code lost:
    
        if (r0 < 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00df, code lost:
    
        return r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00d7, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:70:0x0076, B:62:0x00d7], limit reached: 81 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [double] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [double] */
    /* JADX WARN: Type inference failed for: r0v36, types: [double] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [int] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v23, types: [double] */
    /* JADX WARN: Type inference failed for: r1v26 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v6, types: [double[]] */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static double m76Vulcan_G(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m76Vulcan_G(java.lang.Object[]):double");
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0073, code lost:
    
        if (r0 < r1.length) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        r0 = r1[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        if (r0 != 0) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x007f, code lost:
    
        r0 = java.lang.Float.isNaN(r0);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0085, code lost:
    
        if (r0 <= 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0088, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x008a, code lost:
    
        if (r0 != 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0090, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0093, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0094, code lost:
    
        if (r0 == 0) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x009a, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x009d, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x009e, code lost:
    
        return Float.NaN;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00a5, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00a6, code lost:
    
        r0 = r1[r13];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ac, code lost:
    
        if (r0 != 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00af, code lost:
    
        r0 = (r0 > (r12 == true ? 1 : 0 ? 1.0f : 0.0f) ? 1 : (r0 == (r12 == true ? 1 : 0 ? 1.0f : 0.0f) ? 0 : -1));
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00b8, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00b9, code lost:
    
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00bc, code lost:
    
        if (r0 < 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00bf, code lost:
    
        if (r0 <= 0) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00c2, code lost:
    
        r0 = r1[r13];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00cc, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00cd, code lost:
    
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00cf, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00d4, code lost:
    
        if (r0 == 0) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00d7, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00da, code lost:
    
        if (r0 < 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00df, code lost:
    
        return r12 == true ? 1 : 0 ? 1.0f : 0.0f;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x00d7, code lost:
    
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:70:0x0076, B:62:0x00d7], limit reached: 81 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [float] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [float] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [int] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v26 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v6, types: [float[]] */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static float m77Vulcan_a(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m77Vulcan_a(java.lang.Object[]):float");
    }

    public static long Vulcan_T(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        long jLongValue2 = ((Long) objArr[1]).longValue();
        long jLongValue3 = ((Long) objArr[2]).longValue();
        long jLongValue4 = a ^ ((Long) objArr[3]).longValue();
        int iVulcan_Q = Vulcan_OA.Vulcan_Q();
        int i = (jLongValue2 > jLongValue ? 1 : (jLongValue2 == jLongValue ? 0 : -1));
        if (iVulcan_Q == 0) {
            if (i < 0) {
                jLongValue = jLongValue2;
            }
            if (iVulcan_Q == 0) {
                i = (jLongValue3 > jLongValue ? 1 : (jLongValue3 == jLongValue ? 0 : -1));
            } else {
                return jLongValue3;
            }
        }
        if (i < 0) {
            jLongValue = jLongValue3;
        }
        return jLongValue;
    }

    public static int Vulcan_Y(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        int iVulcan_u = Vulcan_OA.Vulcan_u();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_u != 0) {
            if (i < i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_u;
            if (j > 0) {
                if (i2 == 0) {
                    return i;
                }
                i2 = iIntValue;
            }
        }
        if (i < i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue;
    }

    public static short Vulcan_w(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        int iVulcan_Q = Vulcan_OA.Vulcan_Q();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_Q == 0) {
            if (i < i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_Q;
            if (j >= 0) {
                if (i2 != 0) {
                    return i == true ? (short) 1 : (short) 0;
                }
                i2 = iIntValue;
            }
        }
        if (i < i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue == true ? (short) 1 : (short) 0;
    }

    public static byte Vulcan_V(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        int iIntValue3 = ((Integer) objArr[2]).intValue();
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        int iVulcan_u = Vulcan_OA.Vulcan_u();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_u != 0) {
            if (i < i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_u;
            if (jLongValue >= 0) {
                if (i2 == 0) {
                    return i == true ? (byte) 1 : (byte) 0;
                }
                i2 = iIntValue;
            }
        }
        if (i < i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue == true ? (byte) 1 : (byte) 0;
    }

    public static double Vulcan_P(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        return Math.min(Math.min(dDoubleValue, dDoubleValue2), ((Double) objArr[2]).doubleValue());
    }

    public static float Vulcan_m(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        return Math.min(Math.min(fFloatValue, fFloatValue2), ((Float) objArr[2]).floatValue());
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public static long m78Vulcan_i(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        long jLongValue2 = ((Long) objArr[1]).longValue();
        long jLongValue3 = ((Long) objArr[2]).longValue();
        long jLongValue4 = a ^ ((Long) objArr[3]).longValue();
        int iVulcan_u = Vulcan_OA.Vulcan_u();
        int i = (jLongValue2 > jLongValue ? 1 : (jLongValue2 == jLongValue ? 0 : -1));
        if (iVulcan_u != 0) {
            if (i > 0) {
                jLongValue = jLongValue2;
            }
            if (iVulcan_u != 0) {
                i = (jLongValue3 > jLongValue ? 1 : (jLongValue3 == jLongValue ? 0 : -1));
            } else {
                return jLongValue3;
            }
        }
        if (i > 0) {
            jLongValue = jLongValue3;
        }
        return jLongValue;
    }

    public static int Vulcan_l(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        int iVulcan_Q = Vulcan_OA.Vulcan_Q();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_Q == 0) {
            if (i > i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_Q;
            if (j > 0) {
                if (i2 != 0) {
                    return i;
                }
                i2 = iIntValue;
            }
        }
        if (i > i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue;
    }

    public static short Vulcan_e(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        int iVulcan_Q = Vulcan_OA.Vulcan_Q();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_Q == 0) {
            if (i > i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_Q;
            if (j > 0) {
                if (i2 != 0) {
                    return i == true ? (short) 1 : (short) 0;
                }
                i2 = iIntValue;
            }
        }
        if (i > i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue == true ? (short) 1 : (short) 0;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public static byte m79Vulcan_n(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        int iIntValue3 = ((Integer) objArr[2]).intValue();
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        int iVulcan_u = Vulcan_OA.Vulcan_u();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (iVulcan_u != 0) {
            if (i > i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            i2 = iVulcan_u;
            if (jLongValue >= 0) {
                if (i2 == 0) {
                    return i == true ? (byte) 1 : (byte) 0;
                }
                i2 = iIntValue;
            }
        }
        if (i > i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue == true ? (byte) 1 : (byte) 0;
    }

    public static double Vulcan_d(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        return Math.max(Math.max(dDoubleValue, dDoubleValue2), ((Double) objArr[2]).doubleValue());
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static float m80Vulcan_e(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        return Math.max(Math.max(fFloatValue, fFloatValue2), ((Float) objArr[2]).floatValue());
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public static int m81Vulcan_k(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r14 = r0
            r0 = r10
            r1 = r12
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 == 0) goto L55
            if (r0 >= 0) goto L45
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L41
            throw r0     // Catch: java.lang.NumberFormatException -> L41
        L3f:
            r0 = -1
            return r0
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L41
            throw r0
        L45:
            r0 = r10
            r1 = r14
            if (r1 == 0) goto L65
            r1 = r12
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L55:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L5f
            if (r0 <= 0) goto L64
            r0 = 1
        L5f:
            return r0
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L60
            throw r0
        L64:
            r0 = r10
        L65:
            long r0 = java.lang.Double.doubleToLongBits(r0)
            r15 = r0
            r0 = r12
            long r0 = java.lang.Double.doubleToLongBits(r0)
            r17 = r0
            r0 = r15
            r1 = r17
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L98
            if (r1 == 0) goto L96
            if (r0 != 0) goto L91
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L8d
            throw r0     // Catch: java.lang.NumberFormatException -> L8d
        L8b:
            r0 = 0
            return r0
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L8d
            throw r0
        L91:
            r0 = r15
            r1 = r17
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L96:
            r1 = r14
        L98:
            if (r1 == 0) goto Lac
            if (r0 >= 0) goto Lab
            goto La5
        La1:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La7
            throw r0     // Catch: java.lang.NumberFormatException -> La7
        La5:
            r0 = -1
            return r0
        La7:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La7
            throw r0
        Lab:
            r0 = 1
        Lac:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.m81Vulcan_k(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_Q(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O9.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r9
            r1 = r8
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            if (r1 == 0) goto L46
            if (r0 >= 0) goto L43
            goto L3d
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3f
            throw r0     // Catch: java.lang.NumberFormatException -> L3f
        L3d:
            r0 = -1
            return r0
        L3f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3f
            throw r0
        L43:
            r0 = r9
            r1 = r8
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L46:
            r1 = r12
            if (r1 == 0) goto L5f
            if (r0 <= 0) goto L5b
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L57
            throw r0     // Catch: java.lang.NumberFormatException -> L57
        L55:
            r0 = 1
            return r0
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L57
            throw r0
        L5b:
            r0 = r9
            int r0 = java.lang.Float.floatToIntBits(r0)
        L5f:
            r13 = r0
            r0 = r8
            int r0 = java.lang.Float.floatToIntBits(r0)
            r14 = r0
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L9c
            r2 = r12
            if (r2 == 0) goto L9c
            if (r0 != r1) goto L86
            goto L80
        L7c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L82
            throw r0     // Catch: java.lang.NumberFormatException -> L82
        L80:
            r0 = 0
            return r0
        L82:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L82
            throw r0
        L86:
            r0 = r13
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L95
            if (r1 == 0) goto La6
            r1 = r14
        L95:
            goto L9c
        L98:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L9c:
            if (r0 >= r1) goto La5
            r0 = -1
            return r0
        La1:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La1
            throw r0
        La5:
            r0 = 1
        La6:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O9.Vulcan_Q(java.lang.Object[]):int");
    }
}
