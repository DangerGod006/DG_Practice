package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fk, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fk.class */
public class C0011Vulcan_fk implements Vulcan_Oi, Serializable {
    private static final long serialVersionUID = 86241875189L;
    private Object Vulcan_J;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-8751366100547875430L, -6818306060199249176L, null).a(4322314308317L);
    private static final String b;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = "\b\u0015=\u0017".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 15;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 105;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -8751366100547875430(0x868ce6e5f572cd9a, double:-4.07606492807824E-277)
            r1 = -6818306060199249176(0xa16082c35fee3ae8, double:-6.456246273113105E-148)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 4322314308317(0x3ee5e024add, double:2.1355070102675E-311)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.C0011Vulcan_fk.a = r0
            r0 = 15
            java.lang.String r1 = "\b\u0015=\u0017"
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.C0011Vulcan_fk.b = r2
            goto Lab
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 105(0x69, float:1.47E-43)
            goto L84
        L69:
            r8 = 111(0x6f, float:1.56E-43)
            goto L84
        L6e:
            r8 = 94
            goto L84
        L73:
            r8 = 116(0x74, float:1.63E-43)
            goto L84
        L78:
            r8 = 69
            goto L84
        L7d:
            r8 = 108(0x6c, float:1.51E-43)
            goto L84
        L82:
            r8 = 119(0x77, float:1.67E-43)
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0011Vulcan_fk.m385clinit():void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0011Vulcan_fk() {
    }

    public C0011Vulcan_fk(Object obj) {
        this.Vulcan_J = obj;
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_J;
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        this.Vulcan_J = objArr[0];
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:49:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v6, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.C0011Vulcan_fk.a
            r1 = 112663674789614(0x66778e509eee, double:5.5663251247779E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_w()
            r9 = r0
            r0 = r6
            boolean r0 = r0 instanceof ac.vulcan.anticheat.C0011Vulcan_fk     // Catch: java.lang.RuntimeException -> L1c
            r1 = r9
            if (r1 != 0) goto L7e
            if (r0 == 0) goto L7d
            goto L20
        L1c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L20:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_fk r0 = (ac.vulcan.anticheat.C0011Vulcan_fk) r0
            java.lang.Object r0 = r0.Vulcan_J
            r10 = r0
            r0 = r5
            java.lang.Object r0 = r0.Vulcan_J     // Catch: java.lang.RuntimeException -> L3a
            r1 = r9
            if (r1 != 0) goto L49
            r1 = r10
            if (r0 == r1) goto L77
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L45
            throw r0     // Catch: java.lang.RuntimeException -> L45
        L3e:
            r0 = r5
            java.lang.Object r0 = r0.Vulcan_J     // Catch: java.lang.RuntimeException -> L45
            goto L49
        L45:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L49:
            r1 = r9
            if (r1 != 0) goto L63
            if (r0 == 0) goto L7b
            goto L58
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5f
            throw r0     // Catch: java.lang.RuntimeException -> L5f
        L58:
            r0 = r5
            java.lang.Object r0 = r0.Vulcan_J     // Catch: java.lang.RuntimeException -> L5f
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L63:
            r1 = r10
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L73
            r1 = r9
            if (r1 != 0) goto L78
            if (r0 == 0) goto L7b
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            r0 = 1
        L78:
            goto L7c
        L7b:
            r0 = 0
        L7c:
            return r0
        L7d:
            r0 = 0
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0011Vulcan_fk.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object] */
    public int hashCode() {
        long j = a ^ 47198057711648L;
        ?? Vulcan_n = C0003Vulcan_On.Vulcan_n();
        try {
            try {
                Vulcan_n = this.Vulcan_J;
                ?? r0 = Vulcan_n;
                if (Vulcan_n != 0) {
                    if (Vulcan_n == 0) {
                        return 0;
                    }
                    r0 = this.Vulcan_J;
                }
                return r0.hashCode();
            } catch (RuntimeException unused) {
                throw a(Vulcan_n);
            }
        } catch (RuntimeException unused2) {
            Vulcan_n = a(Vulcan_n);
            throw Vulcan_n;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object] */
    public String toString() {
        long j = a ^ 106375453725373L;
        ?? Vulcan_w = C0003Vulcan_On.Vulcan_w();
        try {
            try {
                Vulcan_w = this.Vulcan_J;
                ?? r0 = Vulcan_w;
                if (Vulcan_w == 0) {
                    if (Vulcan_w == 0) {
                        return b;
                    }
                    r0 = this.Vulcan_J;
                }
                return r0.toString();
            } catch (RuntimeException unused) {
                throw a(Vulcan_w);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_w);
        }
    }
}
