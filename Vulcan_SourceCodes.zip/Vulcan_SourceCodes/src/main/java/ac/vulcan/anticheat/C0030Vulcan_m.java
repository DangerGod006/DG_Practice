package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_m.class */
class C0030Vulcan_m implements Vulcan_fn {
    protected final int Vulcan_l;
    protected int Vulcan_x;
    protected String[] Vulcan_O;
    protected int[] Vulcan__;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(5260063811573153766L, -8420153055456657517L, null).a(86043612042473L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0030Vulcan_m() {
        this.Vulcan_x = 0;
        this.Vulcan_l = 100;
        this.Vulcan_O = new String[this.Vulcan_l];
        this.Vulcan__ = new int[this.Vulcan_l];
    }

    public C0030Vulcan_m(int i) {
        this.Vulcan_x = 0;
        this.Vulcan_l = i;
        this.Vulcan_O = new String[i];
        this.Vulcan__ = new int[i];
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_m, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0051: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_fn
    public void Vulcan_A(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 61365929079183(0x37cfde67718f, double:3.03187973831547E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r9
            r1 = r9
            int r1 = r1.Vulcan_x
            r2 = 1
            int r1 = r1 + r2
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_H(r1)
            r0 = r9
            java.lang.String[] r0 = r0.Vulcan_O
            r1 = r9
            int r1 = r1.Vulcan_x
            r2 = r11
            r0[r1] = r2
            r0 = r9
            int[] r0 = r0.Vulcan__
            r1 = r9
            int r1 = r1.Vulcan_x
            r2 = r14
            r0[r1] = r2
            r0 = r9
            r1 = r0
            int r1 = r1.Vulcan_x
            r2 = 1
            int r1 = r1 + r2
            r0.Vulcan_x = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0030Vulcan_m.Vulcan_A(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    protected void Vulcan_H(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            try {
                Vulcan_k = iIntValue;
                int length = this.Vulcan_O.length;
                ?? r0 = Vulcan_k;
                if (Vulcan_k == 0) {
                    if (Vulcan_k > length) {
                        r0 = iIntValue;
                        length = this.Vulcan_x + this.Vulcan_l;
                    } else {
                        return;
                    }
                }
                int iMax = Math.max((int) r0, length);
                String[] strArr = new String[iMax];
                System.arraycopy(this.Vulcan_O, 0, strArr, 0, this.Vulcan_x);
                this.Vulcan_O = strArr;
                int[] iArr = new int[iMax];
                System.arraycopy(this.Vulcan__, 0, iArr, 0, this.Vulcan_x);
                this.Vulcan__ = iArr;
            } catch (RuntimeException unused) {
                throw a(Vulcan_k);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_k);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x003a, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x003d, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x003e, code lost:
    
        r0 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0045, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x004d, code lost:
    
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0052, code lost:
    
        if (r0 == null) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0058, code lost:
    
        if (r1 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x005b, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0024, code lost:
    
        if (r11 < r5.Vulcan_x) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0027, code lost:
    
        r0 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x002a, code lost:
    
        if (r0 != null) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x002d, code lost:
    
        r0 = r0.Vulcan__[r11];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0034, code lost:
    
        if (r0 != r1) goto L17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0027, B:19:0x0055], limit reached: 29 */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_m] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_m] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0058 -> B:5:0x0027). Please report as a decompilation issue!!! */
    @Override // ac.vulcan.anticheat.Vulcan_fn
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String Vulcan_K(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = 0
            r11 = r1
            r10 = r0
        L1e:
            r0 = r11
            r1 = r5
            int r1 = r1.Vulcan_x
            if (r0 >= r1) goto L55
        L27:
            r0 = r5
            r1 = r10
            if (r1 != 0) goto L46
            int[] r0 = r0.Vulcan__     // Catch: java.lang.RuntimeException -> L3a java.lang.RuntimeException -> L42
            r1 = r11
            r0 = r0[r1]     // Catch: java.lang.RuntimeException -> L3a java.lang.RuntimeException -> L42
            r1 = r7
            if (r0 != r1) goto L4d
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L42
            throw r0     // Catch: java.lang.RuntimeException -> L42
        L3e:
            r0 = r5
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L46:
            java.lang.String[] r0 = r0.Vulcan_O
            r1 = r11
            r0 = r0[r1]
            return r0
        L4d:
            int r11 = r11 + 1
            r0 = r10
            if (r0 == 0) goto L1e
        L55:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L27
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0030Vulcan_m.Vulcan_K(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0044, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0047, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0048, code lost:
    
        if (r0 == 0) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0051, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x005f, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0060, code lost:
    
        return r7.Vulcan__[r13];
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0061, code lost:
    
        r13 = r13 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0066, code lost:
    
        if (r0 == null) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0069, code lost:
    
        r0 = (r1 > 0 ? 1 : (r1 == 0 ? 0 : -1));
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x006c, code lost:
    
        if (r0 < 0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x006f, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        if (r0 < r7.Vulcan_x) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0025, code lost:
    
        r0 = r7.Vulcan_O[r13].equals(r1);
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0036, code lost:
    
        if (r1 <= 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0039, code lost:
    
        if (r1 != null) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003c, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x003e, code lost:
    
        if (r1 != null) goto L31;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:27:0x0025, B:23:0x0069], limit reached: 36 */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0066 -> B:23:0x0069). Please report as a decompilation issue!!! */
    @Override // ac.vulcan.anticheat.Vulcan_fn
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int Vulcan_n(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = 0
            r13 = r1
            r12 = r0
        L1c:
            r0 = r13
            r1 = r7
            int r1 = r1.Vulcan_x
            if (r0 >= r1) goto L69
        L25:
            r0 = r7
            java.lang.String[] r0 = r0.Vulcan_O     // Catch: java.lang.RuntimeException -> L44
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.RuntimeException -> L44
            r1 = r11
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L44
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L3e
            if (r1 != 0) goto L70
            r1 = r12
        L3e:
            if (r1 != 0) goto L60
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4e
            throw r0     // Catch: java.lang.RuntimeException -> L4e
        L48:
            if (r0 == 0) goto L61
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5c
            throw r0     // Catch: java.lang.RuntimeException -> L5c
        L52:
            r0 = r7
            int[] r0 = r0.Vulcan__     // Catch: java.lang.RuntimeException -> L5c
            r1 = r13
            r0 = r0[r1]     // Catch: java.lang.RuntimeException -> L5c
            goto L60
        L5c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L60:
            return r0
        L61:
            int r13 = r13 + 1
            r0 = r12
            if (r0 == 0) goto L1c
        L69:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L25
            r0 = -1
        L70:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0030Vulcan_m.Vulcan_n(java.lang.Object[]):int");
    }
}
