package ac.vulcan.anticheat;

import io.papermc.paper.threadedregions.scheduler.AsyncScheduler;
import io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler;
import io.papermc.paper.threadedregions.scheduler.RegionScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.lang.invoke.MethodHandles;
import java.util.concurrent.TimeUnit;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O0.class */
public class Vulcan_O0 implements Vulcan_H {
    final Plugin Vulcan_G;
    private final RegionScheduler Vulcan_m;
    private final GlobalRegionScheduler Vulcan_A;
    private final AsyncScheduler Vulcan_b;
    private static int Vulcan_h;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5862360953013875315L, 8419330270615074173L, MethodHandles.lookup().lookupClass()).a(272935829656178L);

    public static void Vulcan_T(int i) {
        Vulcan_h = i;
    }

    public static int Vulcan_l() {
        return Vulcan_h;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_k() {
        return Vulcan_l() == 0 ? 62 : 0;
    }

    static {
        if (Vulcan_k() == 0) {
            Vulcan_T(73);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public Vulcan_O0(Plugin plugin) {
        long j = a ^ 65812916633000L;
        ?? Vulcan_k = Vulcan_k();
        this.Vulcan_m = Bukkit.getServer().getRegionScheduler();
        this.Vulcan_A = Bukkit.getServer().getGlobalRegionScheduler();
        this.Vulcan_b = Bukkit.getServer().getAsyncScheduler();
        try {
            this.Vulcan_G = plugin;
            if (Vulcan_k == 0) {
                Vulcan_k = new AbstractCheck[4];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_k);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_k);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_d(Object[] objArr) {
        return Bukkit.getServer().isGlobalTickThread();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_y(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_D(Object[] objArr) {
        return Bukkit.getServer().isOwnedByCurrentRegion((Entity) objArr[0]);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_V(Object[] objArr) {
        return Bukkit.getServer().isOwnedByCurrentRegion((Location) objArr[0]);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_C(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        return new Vulcan_fT(this.Vulcan_A.run(this.Vulcan_G, (v1) -> {
            lambda$runTask$0(r4, v1);
        }));
    }

    private static void lambda$runTask$0(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r8v0, types: [ac.vulcan.anticheat.Vulcan_O0] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_o(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        Runnable runnable = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        ?? Vulcan_C = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
        if (Vulcan_C <= 0) {
            try {
                Vulcan_C = Vulcan_C(new Object[]{runnable});
                return Vulcan_C;
            } catch (RuntimeException unused) {
                throw a(Vulcan_C);
            }
        }
        return new Vulcan_fT(this.Vulcan_A.runDelayed(this.Vulcan_G, (v1) -> {
            lambda$runTaskLater$1(r4, v1);
        }, jLongValue));
    }

    private static void lambda$runTaskLater$1(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_w(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        ?? LongValue = ((Long) objArr[1]).longValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        ?? r3 = new Object[2];
        LongValue[1] = Long.valueOf(((Long) objArr[3]).longValue() ^ 5718730162758L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(this.Vulcan_A.runAtFixedRate(this.Vulcan_G, (v1) -> {
            lambda$runTaskTimer$2(r4, v1);
        }, r3.m38Vulcan_H(r3), jLongValue));
    }

    private static void lambda$runTaskTimer$2(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_e(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        return new Vulcan_fT(this.Vulcan_A.run(plugin, (v1) -> {
            lambda$runTask$3(r4, v1);
        }));
    }

    private static void lambda$runTask$3(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r8v0, types: [ac.vulcan.anticheat.Vulcan_O0] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_W(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        ((Long) objArr[3]).longValue();
        ?? Vulcan_e = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
        if (Vulcan_e <= 0) {
            try {
                Vulcan_e = Vulcan_e(new Object[]{plugin, runnable});
                return Vulcan_e;
            } catch (RuntimeException unused) {
                throw a(Vulcan_e);
            }
        }
        return new Vulcan_fT(this.Vulcan_A.runDelayed(plugin, (v1) -> {
            lambda$runTaskLater$4(r4, v1);
        }, jLongValue));
    }

    private static void lambda$runTaskLater$4(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_d */
    public Vulcan_t mo28Vulcan_d(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        Runnable runnable = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        long jLongValue2 = ((Long) objArr[4]).longValue();
        ?? r3 = new Object[2];
        LongValue[1] = Long.valueOf(jLongValue ^ 56179460073655L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(this.Vulcan_A.runAtFixedRate(plugin, (v1) -> {
            lambda$runTaskTimer$5(r4, v1);
        }, r3.m38Vulcan_H(r3), jLongValue2));
    }

    private static void lambda$runTaskTimer$5(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_A(Object[] objArr) {
        Location location = (Location) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        return new Vulcan_fT(this.Vulcan_m.run(this.Vulcan_G, location, (v1) -> {
            lambda$runTask$6(r5, v1);
        }));
    }

    private static void lambda$runTask$6(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_O0] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_s(Object[] objArr) {
        Location location = (Location) objArr[0];
        ((Long) objArr[1]).longValue();
        Runnable runnable = (Runnable) objArr[2];
        long jLongValue = ((Long) objArr[3]).longValue();
        ?? Vulcan_C = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
        if (Vulcan_C <= 0) {
            try {
                Vulcan_C = Vulcan_C(new Object[]{runnable});
                return Vulcan_C;
            } catch (RuntimeException unused) {
                throw a(Vulcan_C);
            }
        }
        return new Vulcan_fT(this.Vulcan_m.runDelayed(this.Vulcan_G, location, (v1) -> {
            lambda$runTaskLater$7(r5, v1);
        }, jLongValue));
    }

    private static void lambda$runTaskLater$7(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_z(Object[] objArr) {
        Location location = (Location) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        Runnable runnable = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        long jLongValue2 = ((Long) objArr[4]).longValue();
        ?? r3 = new Object[2];
        LongValue[1] = Long.valueOf(jLongValue ^ 95513564359522L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(this.Vulcan_m.runAtFixedRate(this.Vulcan_G, location, (v1) -> {
            lambda$runTaskTimer$8(r5, v1);
        }, r3.m38Vulcan_H(r3), jLongValue2));
    }

    private static void lambda$runTaskTimer$8(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_P(Object[] objArr) {
        Entity entity = (Entity) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        return new Vulcan_fT(entity.getScheduler().run(this.Vulcan_G, (v1) -> {
            lambda$runTask$9(r4, v1);
        }, (Runnable) null));
    }

    private static void lambda$runTask$9(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_O0] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_Z(Object[] objArr) {
        Entity entity = (Entity) objArr[0];
        ((Long) objArr[1]).longValue();
        Runnable runnable = (Runnable) objArr[2];
        long jLongValue = ((Long) objArr[3]).longValue();
        ?? Vulcan_P = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
        if (Vulcan_P <= 0) {
            try {
                Vulcan_P = Vulcan_P(new Object[]{entity, runnable});
                return Vulcan_P;
            } catch (RuntimeException unused) {
                throw a(Vulcan_P);
            }
        }
        return new Vulcan_fT(entity.getScheduler().runDelayed(this.Vulcan_G, (v1) -> {
            lambda$runTaskLater$10(r4, v1);
        }, (Runnable) null, jLongValue));
    }

    private static void lambda$runTaskLater$10(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_k(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Entity entity = (Entity) objArr[1];
        Runnable runnable = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        long jLongValue2 = ((Long) objArr[4]).longValue();
        ?? r3 = new Object[2];
        LongValue[1] = Long.valueOf(jLongValue ^ 55910739159563L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(entity.getScheduler().runAtFixedRate(this.Vulcan_G, (v1) -> {
            lambda$runTaskTimer$11(r4, v1);
        }, (Runnable) null, r3.m38Vulcan_H(r3), jLongValue2));
    }

    private static void lambda$runTaskTimer$11(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_E(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        return new Vulcan_fT(this.Vulcan_b.runNow(this.Vulcan_G, (v1) -> {
            lambda$runTaskAsynchronously$12(r4, v1);
        }));
    }

    private static void lambda$runTaskAsynchronously$12(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_n(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        ?? r3 = new Object[2];
        ((Long) objArr[1]).longValue()[1] = Long.valueOf(((Long) objArr[2]).longValue() ^ 94143671405711L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(this.Vulcan_b.runDelayed(this.Vulcan_G, (v1) -> {
            lambda$runTaskLaterAsynchronously$13(r4, v1);
        }, r3.m38Vulcan_H(r3) * 50, TimeUnit.MILLISECONDS));
    }

    private static void lambda$runTaskLaterAsynchronously$13(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_H(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        return new Vulcan_fT(this.Vulcan_b.runAtFixedRate(this.Vulcan_G, (v1) -> {
            lambda$runTaskTimerAsynchronously$14(r4, v1);
        }, ((Long) objArr[1]).longValue() * 50, ((Long) objArr[2]).longValue() * 50, TimeUnit.MILLISECONDS));
    }

    private static void lambda$runTaskTimerAsynchronously$14(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_T(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        return new Vulcan_fT(this.Vulcan_b.runNow(plugin, (v1) -> {
            lambda$runTaskAsynchronously$15(r4, v1);
        }));
    }

    private static void lambda$runTaskAsynchronously$15(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Type inference failed for: r1v9, types: [long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_O(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        ?? r3 = new Object[2];
        ((Long) objArr[2]).longValue()[1] = Long.valueOf(((Long) objArr[3]).longValue() ^ 38456598586480L);
        this[0] = Long.valueOf((long) r3);
        return new Vulcan_fT(this.Vulcan_b.runDelayed(plugin, (v1) -> {
            lambda$runTaskLaterAsynchronously$16(r4, v1);
        }, r3.m38Vulcan_H(r3) * 50, TimeUnit.MILLISECONDS));
    }

    private static void lambda$runTaskLaterAsynchronously$16(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [ac.vulcan.anticheat.Vulcan_fT, ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r1v9, types: [long] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_O0, java.lang.Object[], long] */
    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_q(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        ?? LongValue = ((Long) objArr[2]).longValue();
        long jLongValue = ((Long) objArr[3]).longValue();
        long jLongValue2 = ((Long) objArr[4]).longValue() ^ 90987020253863L;
        ?? Vulcan_l = Vulcan_l();
        ?? r4 = new Object[2];
        LongValue[1] = Long.valueOf(jLongValue2);
        this[0] = Long.valueOf((long) r4);
        try {
            Vulcan_l = new Vulcan_fT(this.Vulcan_b.runAtFixedRate(plugin, (v1) -> {
                lambda$runTaskTimerAsynchronously$17(r4, v1);
            }, r4.m38Vulcan_H(r4) * 50, jLongValue * 50, TimeUnit.MILLISECONDS));
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_T(Vulcan_l + 1);
            }
            return Vulcan_l;
        } catch (RuntimeException unused) {
            throw a(Vulcan_l);
        }
    }

    private static void lambda$runTaskTimerAsynchronously$17(Runnable runnable, ScheduledTask scheduledTask) {
        runnable.run();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public void Vulcan_F(Object[] objArr) {
        this.Vulcan_A.execute(this.Vulcan_G, (Runnable) objArr[0]);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_s */
    public void mo30Vulcan_s(Object[] objArr) {
        this.Vulcan_m.execute(this.Vulcan_G, (Location) objArr[0], (Runnable) objArr[1]);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_w */
    public void mo31Vulcan_w(Object[] objArr) {
        Entity entity = (Entity) objArr[0];
        entity.getScheduler().execute(this.Vulcan_G, (Runnable) objArr[1], (Runnable) null, 1L);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public void Vulcan_Q(Object[] objArr) {
        this.Vulcan_A.cancelTasks(this.Vulcan_G);
        this.Vulcan_b.cancelTasks(this.Vulcan_G);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_V */
    public void mo32Vulcan_V(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        this.Vulcan_A.cancelTasks(plugin);
        this.Vulcan_b.cancelTasks(plugin);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    private long m38Vulcan_H(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O0.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_l()
            r11 = r0
            r0 = r7
            r1 = r11
            if (r1 != 0) goto L3e
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L41
            goto L36
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3a
            throw r0     // Catch: java.lang.RuntimeException -> L3a
        L36:
            r0 = 1
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3e:
            goto L42
        L41:
            r0 = r7
        L42:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O0.m38Vulcan_H(java.lang.Object[]):long");
    }
}
