package ac.vulcan.anticheat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fv, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fv.class */
public class C0014Vulcan_fv {
    public static final char Vulcan_T = '.';
    public static final String Vulcan_F;
    public static final char Vulcan_e = '$';
    public static final String Vulcan_P;
    private static final Map Vulcan_N;
    private static final Map Vulcan_L;
    private static final Map Vulcan__;
    private static final Map Vulcan_C;
    static Class Vulcan_v;
    static Class Vulcan_K;
    static Class Vulcan_M;
    static Class Vulcan_D;
    static Class Vulcan_G;
    static Class Vulcan_U;
    static Class Vulcan_n;
    static Class Vulcan_m;
    static Class Vulcan_E;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-1527553783676038864L, -2826787154551376107L, null).a(55610951757079L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0055: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_u(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 56424369366347(0x3351527e254b, double:2.78773424921693E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L45
            if (r0 != 0) goto L44
            goto L3e
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L40
            throw r0     // Catch: java.lang.SecurityException -> L40
        L3e:
            r0 = r10
            return r0
        L40:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L40
            throw r0
        L44:
            r0 = r9
        L45:
            java.lang.Class r0 = r0.getClass()
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_u(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_A(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 100175258095700(0x5b1bdeac9054, double:4.94931535883656E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r9
            r1 = r14
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0     // Catch: java.lang.SecurityException -> L3a
        L37:
            java.lang.String r0 = ""
            return r0
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0
        L3e:
            r0 = r9
        L3f:
            java.lang.String r0 = r0.getName()
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_V(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0057: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_H(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 65826562068062(0x3bde70d94e5e, double:3.2522642901666E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r11
            r1 = r15
            if (r1 != 0) goto L47
            if (r0 != 0) goto L46
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L42
            throw r0     // Catch: java.lang.SecurityException -> L42
        L3f:
            r0 = r12
            return r0
        L42:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L42
            throw r0
        L46:
            r0 = r11
        L47:
            java.lang.Class r0 = r0.getClass()
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_x(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_H(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_y(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 62759858547212(0x39146b132a0c, double:3.10074900460336E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r14
            r2 = r13
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_e(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_y(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00df: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_e(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 292
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_e(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_m(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 45131870067260(0x290c15155a3c, double:2.2298106532804E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r13
            r2 = r14
            r3 = 0
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_l(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_m(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x014a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Class Vulcan_h(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 358
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_h(java.lang.Object[]):java.lang.Class");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0049: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Class Vulcan_Z(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.ClassLoader r1 = (java.lang.ClassLoader) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 34860643220316(0x1fb4a0417b5c, double:1.72234462070867E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r11
            r2 = r12
            r3 = 1
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Class r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_Z(java.lang.Object[]):java.lang.Class");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a5: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Class Vulcan_F(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 51466348438969(0x2ecef16aa5b9, double:2.542775468059E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            java.lang.Thread r1 = java.lang.Thread.currentThread()
            java.lang.ClassLoader r1 = r1.getContextClassLoader()
            r18 = r1
            r17 = r0
            r0 = r18
            if (r0 != 0) goto L80
            java.lang.Class r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_E     // Catch: java.lang.ClassNotFoundException -> L49 java.lang.ClassNotFoundException -> L53
            r1 = r17
            if (r1 != 0) goto L74
            goto L4d
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.ClassNotFoundException -> L53
            throw r0     // Catch: java.lang.ClassNotFoundException -> L53
        L4d:
            if (r0 != 0) goto L77
            goto L57
        L53:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.ClassNotFoundException -> L70
            throw r0     // Catch: java.lang.ClassNotFoundException -> L70
        L57:
            java.lang.String[] r0 = ac.vulcan.anticheat.C0014Vulcan_fv.b     // Catch: java.lang.ClassNotFoundException -> L70
            r1 = 19
            r0 = r0[r1]     // Catch: java.lang.ClassNotFoundException -> L70
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.ClassNotFoundException -> L70
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.ClassNotFoundException -> L70
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.ClassNotFoundException -> L70
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.ClassNotFoundException -> L70
            r1[r2] = r3     // Catch: java.lang.ClassNotFoundException -> L70
            java.lang.Class r0 = m406Vulcan_y(r0)     // Catch: java.lang.ClassNotFoundException -> L70
            r1 = r0
            ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_E = r1     // Catch: java.lang.ClassNotFoundException -> L70
            goto L74
        L70:
            java.lang.Exception r0 = a(r0)
            throw r0
        L74:
            goto L7a
        L77:
            java.lang.Class r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_E
        L7a:
            java.lang.ClassLoader r0 = r0.getClassLoader()
            goto L82
        L80:
            r0 = r18
        L82:
            r19 = r0
            r0 = r15
            r1 = r19
            r2 = r12
            r3 = r11
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Class r0 = Vulcan_h(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_F(java.lang.Object[]):java.lang.Class");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0058: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public static java.lang.String m405Vulcan_c(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 49139665007852(0x2cb13846f4ec, double:2.4278220328527E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L45
            if (r0 != 0) goto L44
            goto L3e
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L40
            throw r0     // Catch: java.lang.SecurityException -> L40
        L3e:
            r0 = r10
            return r0
        L40:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L40
            throw r0
        L44:
            r0 = r9
        L45:
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getName()
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_k(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.m405Vulcan_c(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_s(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 90870067164377(0x52a55612f4d9, double:4.48957784212054E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r9
            r1 = r14
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0     // Catch: java.lang.SecurityException -> L3a
        L37:
            java.lang.String r0 = ""
            return r0
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0
        L3e:
            r0 = r9
        L3f:
            java.lang.String r0 = r0.getName()
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_k(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_s(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0054: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_k(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 65657159849842(0x3bb6ffb09772, double:3.2438947085314E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 133233133023092(0x792cc190ef74, double:6.58259139145067E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_r(r0)
            r1 = r13
            r2 = r1; r1 = r0; r0 = r2; 
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r2 = new java.lang.Long
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r2.<init>(r3)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            Vulcan_V(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_k(java.lang.Object[]):java.lang.String");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x00e5, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x00ea, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x00ef, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x00f4, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x00f9, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x00fe, code lost:
    
        r7 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:108:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L129;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r11 = "\u000b\u0002Hw\u0003J \u000b\u000fH`\u0018R*\t\t\u0003`\u0002\b\u0015\u001f\r\u0005`\u0018y%\u001c\u000e\u0000\u0000\u0010`XJ\"\u0004\u0006HM\u0019H$".charAt(r10);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.C0014Vulcan_fv.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ac, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bb, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_F = java.lang.String.valueOf('.');
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_P = java.lang.String.valueOf('$');
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N = new java.util.HashMap();
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Boolean.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x014b, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_v != null) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x014e, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[12]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_v = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x016a, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x016b, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_v;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x016e, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Byte.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x017d, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_K != null) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0180, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[4]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_K = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x019b, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x019c, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_K;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x019f, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Character.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x01ae, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_M != null) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x01b1, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[1]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_M = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x01cc, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x01cd, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_M;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x01d0, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Short.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003d, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x01df, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_D != null) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x01e2, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[14]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_D = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x01fe, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x01ff, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_D;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0202, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Integer.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0211, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_G != null) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x0214, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[11]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_G = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0230, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0231, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_G;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0234, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Long.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0243, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_U != null) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0246, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[20]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_U = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x0262, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x0263, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_U;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0266, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Double.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0275, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_n != null) goto L72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x0278, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[6]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_n = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0294, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0295, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_n;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x0298, code lost:
    
        r4.put(r5, r6);
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N;
        r5 = java.lang.Float.TYPE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x02a7, code lost:
    
        if (ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_m != null) goto L78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x02aa, code lost:
    
        r6 = m406Vulcan_y(new java.lang.Object[]{ac.vulcan.anticheat.C0014Vulcan_fv.b[15]});
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_m = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x02c6, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x02c7, code lost:
    
        r6 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_m;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x02ca, code lost:
    
        r4.put(r5, r6);
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N.put(java.lang.Void.TYPE, java.lang.Void.TYPE);
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_L = new java.util.HashMap();
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N.keySet().iterator();
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "\u000b\u0002Hw\u0003J \u000b\u000fH`\u0018R*\t\t\u0003`\u0002\b\u0015\u001f\r\u0005`\u0018y%\u001c\u000e\u0000\u0000\u0010`XJ\"\u0004\u0006HM\u0019H$".length();
        r11 = 29;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x02ff, code lost:
    
        if (r4.hasNext() == false) goto L131;
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x0302, code lost:
    
        r4 = (java.lang.Class) r4.next();
        r4 = (java.lang.Class) ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N.get(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x0324, code lost:
    
        if (r4.equals(r4) != false) goto L134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x0327, code lost:
    
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_L.put(r4, r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x033a, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x033e, code lost:
    
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan__ = new java.util.HashMap();
        ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_C = new java.util.HashMap();
        r4 = ac.vulcan.anticheat.C0014Vulcan_fv.b;
        Vulcan_p(new java.lang.Object[]{r4[18], "I"});
        Vulcan_p(new java.lang.Object[]{r4[13], "Z"});
        Vulcan_p(new java.lang.Object[]{r4[17], "F"});
        Vulcan_p(new java.lang.Object[]{r4[7], "J"});
        Vulcan_p(new java.lang.Object[]{r4[8], "S"});
        Vulcan_p(new java.lang.Object[]{r4[2], "B"});
        Vulcan_p(new java.lang.Object[]{r4[9], "D"});
        Vulcan_p(new java.lang.Object[]{r4[16], "C"});
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0068, code lost:
    
        r10 = r10 + 1;
        "\u000b\u0002Hw\u0003J \u000b\u000fH`\u0018R*\t\t\u0003`\u0002\b\u0015\u001f\r\u0005`\u0018y%\u001c\u000e\u0000\u0000\u0010`XJ\"\u0004\u0006HM\u0019H$".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0415, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x009c, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
        r2 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x00ac, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x00bb, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x00e0, code lost:
    
        r7 = 59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0108, code lost:
    
        if (r2 != 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0078, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00af, B:28:0x0110], limit reached: 135 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v26 */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r2v29 */
    /* JADX WARN: Type inference failed for: r2v34 */
    /* JADX WARN: Type inference failed for: r2v38 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v31 */
    /* JADX WARN: Type inference failed for: r3v33 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v87 */
    /* JADX WARN: Type inference failed for: r4v91 */
    /* JADX WARN: Type inference failed for: r5v67 */
    /* JADX WARN: Type inference failed for: r5v68 */
    /* JADX WARN: Type inference failed for: r5v69 */
    /* JADX WARN: Type inference failed for: r5v73 */
    /* JADX WARN: Type inference failed for: r5v83 */
    /* JADX WARN: Type inference failed for: r7v97 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:107:0x0115 -> B:93:0x00af). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00af). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 1046
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.m400clinit():void");
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    static Class m406Vulcan_y(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    private static void Vulcan_p(Object[] objArr) {
        String str = (String) objArr[0];
        String str2 = (String) objArr[1];
        Vulcan__.put(str, str2);
        Vulcan_C.put(str2, str);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_V(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 416
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_V(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_x(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 136529549911099(0x7c2c4352e43b, double:6.7454560253242E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0     // Catch: java.lang.SecurityException -> L3a
        L37:
            java.lang.String r0 = ""
            return r0
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0
        L3e:
            r0 = r10
        L3f:
            java.lang.String r0 = r0.getName()
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_o(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_x(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x002a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_o(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 211
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_o(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x005d A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[LOOP:0: B:10:0x0037->B:23:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:18:0x005a -> B:15:0x0052). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List m401Vulcan_p(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L24
            throw r0
        L28:
            java.util.ArrayList r0 = new java.util.ArrayList
            r1 = r0
            r1.<init>()
            r10 = r0
            r0 = r8
            java.lang.Class r0 = r0.getSuperclass()
            r11 = r0
        L37:
            r0 = r11
            if (r0 == 0) goto L57
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L5f
            r1 = r11
            boolean r0 = r0.add(r1)
            r0 = r11
            java.lang.Class r0 = r0.getSuperclass()
            r11 = r0
        L52:
            r0 = r9
            if (r0 == 0) goto L37
        L57:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L52
            r0 = r10
        L5f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.m401Vulcan_p(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v5 ?? I:java.util.ArrayList) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public static java.util.List Vulcan_d(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x002c: PHI (r0v5 ?? I:java.util.ArrayList) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r10v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r19v0 */
    /* JADX WARN: Type inference failed for: r19v1, types: [int] */
    /* JADX WARN: Type inference failed for: r19v2 */
    /* JADX WARN: Type inference failed for: r19v3 */
    /* JADX WARN: Type inference failed for: r19v4, types: [int] */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.Long, java.util.List] */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:25:0x00b9 -> B:23:0x00ac). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0099: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0099: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private static void Vulcan_G(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.List r1 = (java.util.List) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 31112349848492(0x1c4be88f93ac, double:1.5371543221534E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
        L2f:
            r0 = r11
            if (r0 == 0) goto Lbf
            r0 = r11
            java.lang.Class[] r0 = r0.getInterfaces()
            r18 = r0
            r0 = 0
        L3a:
            r19 = r0
        L3c:
            r0 = r19
            r1 = r18
            int r1 = r1.length
            if (r0 >= r1) goto Laf
            r0 = r14
            r1 = r18
            r2 = r19
            r1 = r1[r2]
            boolean r0 = r0.contains(r1)
            r1 = r17
        L52:
            if (r1 != 0) goto L3a
            r1 = r17
            r2 = r12
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L52
            if (r1 != 0) goto L7d
            if (r0 != 0) goto La7
            goto L6a
        L66:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L79
            throw r0     // Catch: java.lang.SecurityException -> L79
        L6a:
            r0 = r14
            r1 = r18
            r2 = r19
            r1 = r1[r2]     // Catch: java.lang.SecurityException -> L79
            boolean r0 = r0.add(r1)     // Catch: java.lang.SecurityException -> L79
            goto L7d
        L79:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7d:
            r0 = r18
            r1 = r19
            r0 = r0[r1]
            r1 = r14
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_G(r0)
        La7:
            int r19 = r19 + 1
            r0 = r17
        Lac:
            if (r0 == 0) goto L3c
        Laf:
            r0 = r11
            java.lang.Class r0 = r0.getSuperclass()
            r11 = r0
            r0 = r17
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lac
            if (r0 == 0) goto L2f
        Lbf:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_G(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static List Vulcan_q(Object[] objArr) {
        List<String> list = (List) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        for (String str : list) {
            String strA = strVulcan_k;
            if (jLongValue > 0) {
                if (strA != null) {
                    return arrayList;
                }
                try {
                    strA = me.frep.vulcan.spigot.Vulcan_m.a(str);
                } catch (Exception e) {
                    arrayList.add(null);
                }
            }
            arrayList.add(Class.forName(strA));
            if (strVulcan_k != null) {
                break;
            }
        }
        return arrayList;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0024
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.util.List Vulcan_z(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.List r1 = (java.util.List) r1
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r7
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L24
            throw r0
        L28:
            java.util.ArrayList r0 = new java.util.ArrayList
            r1 = r0
            r2 = r7
            int r2 = r2.size()
            r1.<init>(r2)
            r11 = r0
            r0 = r7
            java.util.Iterator r0 = r0.iterator()
            r12 = r0
        L3f:
            r0 = r12
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto La0
            r0 = r12
            java.lang.Object r0 = r0.next()
        L50:
            java.lang.Class r0 = (java.lang.Class) r0
            r13 = r0
            r0 = r10
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L7e
            if (r0 != 0) goto L7c
            r0 = r13
            if (r0 != 0) goto L87
            goto L6c
        L68:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L78
            throw r0     // Catch: java.lang.SecurityException -> L78
        L6c:
            r0 = r11
            r1 = 0
            boolean r0 = r0.add(r1)     // Catch: java.lang.SecurityException -> L78
            goto L7c
        L78:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7c:
            r0 = r10
        L7e:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L9d
            if (r0 == 0) goto L9b
        L87:
            r0 = r11
            r1 = r13
            java.lang.String r1 = r1.getName()     // Catch: java.lang.SecurityException -> L97
            boolean r0 = r0.add(r1)     // Catch: java.lang.SecurityException -> L97
            goto L9b
        L97:
            java.lang.Exception r0 = a(r0)
            throw r0
        L9b:
            r0 = r10
        L9d:
            if (r0 == 0) goto L3f
        La0:
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L50
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_z(java.lang.Object[]):java.util.List");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_l(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 1278
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_l(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Class Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r8
            r10 = r1
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L5b
            if (r0 == 0) goto L59
            goto L31
        L2d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0     // Catch: java.lang.SecurityException -> L3a
        L31:
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L5b
            goto L3e
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L47
            throw r0     // Catch: java.lang.SecurityException -> L47
        L3e:
            boolean r0 = r0.isPrimitive()     // Catch: java.lang.SecurityException -> L47
            if (r0 == 0) goto L59
            goto L4b
        L47:
            java.lang.Exception r0 = a(r0)
            throw r0
        L4b:
            java.util.Map r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_N
            r1 = r8
            java.lang.Object r0 = r0.get(r1)
            java.lang.Class r0 = (java.lang.Class) r0
            r10 = r0
        L59:
            r0 = r10
        L5b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_v(java.lang.Object[]):java.lang.Class");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Class[] Vulcan_c(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 48966729198068(0x2c88f47fe9f4, double:2.4192778685977E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r17 = r0
            r0 = r14
            r1 = r17
            if (r1 != 0) goto L3e
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L39
            throw r0     // Catch: java.lang.SecurityException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L39
            throw r0
        L3d:
            r0 = r14
        L3e:
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L5f
            int r0 = r0.length     // Catch: java.lang.SecurityException -> L50
            r1 = r17
            if (r1 != 0) goto L5c
            if (r0 != 0) goto L5a
            goto L54
        L50:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L56
            throw r0     // Catch: java.lang.SecurityException -> L56
        L54:
            r0 = r14
            return r0
        L56:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L56
            throw r0
        L5a:
            r0 = r14
            int r0 = r0.length
        L5c:
            java.lang.Class[] r0 = new java.lang.Class[r0]
        L5f:
            r18 = r0
            r0 = 0
            r19 = r0
        L64:
            r0 = r19
            r1 = r14
            int r1 = r1.length
            if (r0 >= r1) goto Lb1
        L6b:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L9f
            r0 = r18
            r1 = r17
            if (r1 != 0) goto Lb3
            r1 = r19
            r2 = r14
            r3 = r19
            r2 = r2[r3]     // Catch: java.lang.SecurityException -> Lad
            r3 = r15
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.SecurityException -> Lad
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.SecurityException -> Lad
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.SecurityException -> Lad
            java.lang.Long r6 = new java.lang.Long     // Catch: java.lang.SecurityException -> Lad
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.SecurityException -> Lad
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: java.lang.SecurityException -> Lad
            r6.<init>(r7)     // Catch: java.lang.SecurityException -> Lad
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.SecurityException -> Lad
            r4[r5] = r6     // Catch: java.lang.SecurityException -> Lad
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.SecurityException -> Lad
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.SecurityException -> Lad
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.SecurityException -> Lad
            r3[r4] = r5     // Catch: java.lang.SecurityException -> Lad
            java.lang.Class r2 = Vulcan_v(r2)     // Catch: java.lang.SecurityException -> Lad
            r0[r1] = r2     // Catch: java.lang.SecurityException -> Lad
            int r19 = r19 + 1
        L9f:
            r0 = r17
            if (r0 == 0) goto L64
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L6b
            goto Lb1
        Lad:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lb1:
            r0 = r18
        Lb3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_c(java.lang.Object[]):java.lang.Class[]");
    }

    public static Class Vulcan_N(Object[] objArr) {
        return (Class) Vulcan_L.get((Class) objArr[0]);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static java.lang.Class[] m402Vulcan_o(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0     // Catch: java.lang.SecurityException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L56
            int r0 = r0.length     // Catch: java.lang.SecurityException -> L47
            r1 = r11
            if (r1 != 0) goto L53
            if (r0 != 0) goto L51
            goto L4b
        L47:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L4d
            throw r0     // Catch: java.lang.SecurityException -> L4d
        L4b:
            r0 = r10
            return r0
        L4d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L4d
            throw r0
        L51:
            r0 = r10
            int r0 = r0.length
        L53:
            java.lang.Class[] r0 = new java.lang.Class[r0]
        L56:
            r12 = r0
            r0 = 0
            r13 = r0
        L5b:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L97
        L62:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L85
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L99
            r1 = r13
            r2 = r10
            r3 = r13
            r2 = r2[r3]     // Catch: java.lang.SecurityException -> L93
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.SecurityException -> L93
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.SecurityException -> L93
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.SecurityException -> L93
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.SecurityException -> L93
            r3[r4] = r5     // Catch: java.lang.SecurityException -> L93
            java.lang.Class r2 = Vulcan_N(r2)     // Catch: java.lang.SecurityException -> L93
            r0[r1] = r2     // Catch: java.lang.SecurityException -> L93
            int r13 = r13 + 1
        L85:
            r0 = r11
            if (r0 == 0) goto L5b
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L62
            goto L97
        L93:
            java.lang.Exception r0 = a(r0)
            throw r0
        L97:
            r0 = r12
        L99:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.m402Vulcan_o(java.lang.Object[]):java.lang.Class[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_f(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0     // Catch: java.lang.SecurityException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            java.lang.String r0 = r0.getName()     // Catch: java.lang.SecurityException -> L48
            r1 = 36
            int r0 = r0.indexOf(r1)     // Catch: java.lang.SecurityException -> L48
            r1 = r9
            if (r1 != 0) goto L4d
            if (r0 < 0) goto L50
            goto L4c
        L48:
            java.lang.Exception r0 = a(r0)
            throw r0
        L4c:
            r0 = 1
        L4d:
            goto L51
        L50:
            r0 = 0
        L51:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_f(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static java.lang.Class m403Vulcan_o(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 118332173335700(0x6b9f5b283c94, double:5.8463861642901E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            r2 = 1
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Class r0 = Vulcan_F(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.m403Vulcan_o(java.lang.Object[]):java.lang.Class");
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x01a3 -> B:18:0x00ea). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x007b: PHI (r0v13 ?? I:java.util.ArrayList) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public static java.lang.reflect.Method m404Vulcan_p(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x007b: PHI (r0v13 ?? I:java.util.ArrayList) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0087
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.String Vulcan_g(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 476
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_g(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Class[] Vulcan_S(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0     // Catch: java.lang.SecurityException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            int r0 = r0.length     // Catch: java.lang.SecurityException -> L41
            r1 = r9
            if (r1 != 0) goto L4f
            if (r0 != 0) goto L4d
            goto L45
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L49
            throw r0     // Catch: java.lang.SecurityException -> L49
        L45:
            java.lang.Class[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_o     // Catch: java.lang.SecurityException -> L49
            return r0
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L49
            throw r0
        L4d:
            r0 = r8
            int r0 = r0.length
        L4f:
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r10 = r0
            r0 = 0
            r11 = r0
        L57:
            r0 = r11
            r1 = r8
            int r1 = r1.length
            if (r0 >= r1) goto L99
        L5e:
            r0 = r10
            r1 = r9
            if (r1 != 0) goto La1
            r1 = r11
            r2 = r8
            r3 = r11
            r2 = r2[r3]     // Catch: java.lang.SecurityException -> L73 java.lang.SecurityException -> L7d
            r3 = r9
            if (r3 != 0) goto L8d
            goto L77
        L73:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L7d
            throw r0     // Catch: java.lang.SecurityException -> L7d
        L77:
            if (r2 != 0) goto L89
            goto L81
        L7d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L85
            throw r0     // Catch: java.lang.SecurityException -> L85
        L81:
            r2 = 0
            goto L90
        L85:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L85
            throw r0
        L89:
            r2 = r8
            r3 = r11
            r2 = r2[r3]
        L8d:
            java.lang.Class r2 = r2.getClass()
        L90:
            r0[r1] = r2
            int r11 = r11 + 1
            r0 = r9
            if (r0 == 0) goto L57
        L99:
            r0 = r6
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5e
            r0 = r10
        La1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_S(java.lang.Object[]):java.lang.Class[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_U(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 86798066762787(0x4ef13fefc423, double:4.2883942912928E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L48
            if (r0 != 0) goto L46
            goto L40
        L3c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L42
            throw r0     // Catch: java.lang.SecurityException -> L42
        L40:
            r0 = r12
            return r0
        L42:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L42
            throw r0
        L46:
            r0 = r13
        L48:
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getName()
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_j(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_U(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_C(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 93410673954429(0x54f4de0a0e7d, double:4.6151004955761E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r10
            r1 = r15
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L3e
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0     // Catch: java.lang.SecurityException -> L3a
        L37:
            java.lang.String r0 = ""
            return r0
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.SecurityException -> L3a
            throw r0
        L3e:
            r0 = r10
        L3f:
            java.lang.String r0 = r0.getName()
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_j(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_C(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x003e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x003e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_j(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0014Vulcan_fv.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 90863810374867(0x52a3e123ecd3, double:4.4892687156455E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 26668599086044(0x184144600bdc, double:1.31760386311276E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_r(r0)
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_o(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_j(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.String Vulcan_r(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 404
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_r(java.lang.Object[]):java.lang.String");
    }
}
