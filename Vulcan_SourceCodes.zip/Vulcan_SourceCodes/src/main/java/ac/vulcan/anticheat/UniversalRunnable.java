package ac.vulcan.anticheat;

import java.lang.invoke.MethodHandles;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/UniversalRunnable.class */
public abstract class UniversalRunnable implements Runnable {
    Vulcan_t Vulcan_m;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(4691289720827225000L, 8972901971482272923L, MethodHandles.lookup().lookupClass()).a(31077405580607L);

    private static IllegalStateException a(IllegalStateException illegalStateException) {
        return illegalStateException;
    }

    public synchronized void Vulcan_l(Object[] objArr) {
        m2Vulcan_u(new Object[0]);
        this.Vulcan_m.Vulcan_T(new Object[0]);
    }

    public synchronized boolean Vulcan_K(Object[] objArr) {
        m2Vulcan_u(new Object[0]);
        return this.Vulcan_m.Vulcan_s(new Object[0]);
    }

    public synchronized Vulcan_t Vulcan_k(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Vulcan_X(new Object[0]);
        return m3Vulcan_K(new Object[]{UniversalScheduler.Vulcan_m(new Object[]{plugin}).Vulcan_C(new Object[]{this})});
    }

    public synchronized Vulcan_t Vulcan_q(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Vulcan_X(new Object[0]);
        return m3Vulcan_K(new Object[]{UniversalScheduler.Vulcan_m(new Object[]{plugin}).Vulcan_E(new Object[]{this})});
    }

    /* JADX WARN: Type inference failed for: r1v19, types: [ac.vulcan.anticheat.Vulcan_H] */
    /* JADX WARN: Type inference failed for: r5v2, types: [ac.vulcan.anticheat.Vulcan_H, java.lang.Object[]] */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public synchronized Vulcan_t m1Vulcan_l(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long jLongValue2 = (a ^ ((Long) objArr[2]).longValue()) ^ 64465864128032L;
        Vulcan_X(new Object[0]);
        ?? Vulcan_m = UniversalScheduler.Vulcan_m(new Object[]{plugin});
        ?? r5 = new Object[3];
        this[2] = Long.valueOf(jLongValue);
        r5[1] = r5;
        Vulcan_m[0] = Long.valueOf(jLongValue2);
        return m3Vulcan_K(new Object[]{r5.Vulcan_o(r5)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10, types: [long] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object[], long] */
    public synchronized Vulcan_t Vulcan_u(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Plugin plugin = (Plugin) objArr[1];
        ?? LongValue = ((Long) objArr[2]).longValue();
        long j = (a ^ jLongValue) ^ 68579493602938L;
        Vulcan_X(new Object[0]);
        Vulcan_H vulcan_HVulcan_m = UniversalScheduler.Vulcan_m(new Object[]{plugin});
        ?? r5 = new Object[3];
        LongValue[2] = Long.valueOf(j);
        this[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return m3Vulcan_K(new Object[]{vulcan_HVulcan_m.Vulcan_n(r5)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10, types: [long] */
    /* JADX WARN: Type inference failed for: r1v6, types: [long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Object[], long] */
    public synchronized Vulcan_t Vulcan_S(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        ?? LongValue = ((Long) objArr[1]).longValue();
        ?? LongValue2 = ((Long) objArr[2]).longValue();
        long jLongValue = (a ^ ((Long) objArr[3]).longValue()) ^ 48635504785283L;
        Vulcan_X(new Object[0]);
        Vulcan_H vulcan_HVulcan_m = UniversalScheduler.Vulcan_m(new Object[]{plugin});
        ?? r6 = new Object[4];
        LongValue2[3] = Long.valueOf(jLongValue);
        LongValue[2] = Long.valueOf((long) r6);
        this[1] = Long.valueOf((long) r6);
        r6[0] = r6;
        return m3Vulcan_K(new Object[]{vulcan_HVulcan_m.Vulcan_w((Object[]) r6)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v6, types: [long] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object[], long] */
    public synchronized Vulcan_t Vulcan_m(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        ?? LongValue = ((Long) objArr[1]).longValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        Vulcan_X(new Object[0]);
        Vulcan_H vulcan_HVulcan_m = UniversalScheduler.Vulcan_m(new Object[]{plugin});
        ?? r5 = new Object[3];
        LongValue[2] = Long.valueOf(jLongValue);
        this[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return m3Vulcan_K(new Object[]{vulcan_HVulcan_m.Vulcan_H(r5)});
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    private void m2Vulcan_u(Object[] objArr) {
        IllegalStateException illegalStateException;
        try {
            if (this.Vulcan_m == null) {
                illegalStateException = new IllegalStateException("Not scheduled yet");
                throw illegalStateException;
            }
        } catch (IllegalStateException unused) {
            throw a(illegalStateException);
        }
    }

    private void Vulcan_X(Object[] objArr) {
        IllegalStateException illegalStateException;
        try {
            if (this.Vulcan_m != null) {
                illegalStateException = new IllegalStateException("Already scheduled");
                throw illegalStateException;
            }
        } catch (IllegalStateException unused) {
            throw a(illegalStateException);
        }
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    private Vulcan_t m3Vulcan_K(Object[] objArr) {
        Vulcan_t vulcan_t = (Vulcan_t) objArr[0];
        this.Vulcan_m = vulcan_t;
        return vulcan_t;
    }
}
