package ac.vulcan.anticheat;

import java.util.Map;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OH.class */
class Vulcan_OH extends Vulcan_OT {
    private final Map Vulcan_L;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_OH(Map map) {
        this.Vulcan_L = map;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OT
    public java.lang.String Vulcan_B(java.lang.Object[] r5) {
        /*
            r4 = this;
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_W()
            r9 = r0
            r0 = r4
            java.util.Map r0 = r0.Vulcan_L     // Catch: java.lang.RuntimeException -> L28
            r1 = r9
            if (r1 == 0) goto L3d
            if (r0 != 0) goto L32
            goto L2c
        L28:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2e
            throw r0     // Catch: java.lang.RuntimeException -> L2e
        L2c:
            r0 = 0
            return r0
        L2e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2e
            throw r0
        L32:
            r0 = r4
            java.util.Map r0 = r0.Vulcan_L
            r1 = r8
            java.lang.Object r0 = r0.get(r1)
        L3d:
            r10 = r0
            r0 = r10
            r1 = r9
            if (r1 == 0) goto L58
            if (r0 != 0) goto L56
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L52
            throw r0     // Catch: java.lang.RuntimeException -> L52
        L50:
            r0 = 0
            return r0
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L52
            throw r0
        L56:
            r0 = r10
        L58:
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OH.Vulcan_B(java.lang.Object[]):java.lang.String");
    }
}
