package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Y.class */
public class Vulcan_Y {
    private static int[] Vulcan_g;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-4832280202202093491L, -5009467592673417297L, null).a(266052594081917L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0053: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Object Vulcan_K(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 61075725911641(0x378c4cf28659, double:3.0175417967758E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r14
            r2 = r12
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3
            r5 = 0
            r6 = r13
            r4[r5] = r6
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_D(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_K(java.lang.Object[]):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00b1: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Object Vulcan_D(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 3987270006691(0x3a05bcff7a3, double:1.969973130999E-311)
            long r1 = r1 ^ r2
            r16 = r1
            int[] r0 = Vulcan_d()
            r18 = r0
            r0 = r14
            r1 = r18
            if (r1 == 0) goto L4f
            if (r0 != 0) goto L4d
            goto L48
        L44:
            java.lang.Exception r0 = a(r0)
            throw r0
        L48:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
            r14 = r0
        L4d:
            r0 = r14
        L4f:
            int r0 = r0.length
            r19 = r0
            r0 = r19
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r20 = r0
            r0 = 0
            r21 = r0
        L5c:
            r0 = r21
            r1 = r19
            if (r0 >= r1) goto L90
        L63:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7e
            r0 = r20
            r1 = r18
            if (r1 == 0) goto Lc3
            r1 = r21
            r2 = r14
            r3 = r21
            r2 = r2[r3]     // Catch: java.lang.NoSuchMethodException -> L8c
            java.lang.Class r2 = r2.getClass()     // Catch: java.lang.NoSuchMethodException -> L8c
            r0[r1] = r2     // Catch: java.lang.NoSuchMethodException -> L8c
            int r21 = r21 + 1
        L7e:
            r0 = r18
            if (r0 != 0) goto L5c
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L63
            goto L90
        L8c:
            java.lang.Exception r0 = a(r0)
            throw r0
        L90:
            r0 = r16
            r1 = r15
            r2 = r11
            r3 = r14
            r4 = r20
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_Y(r0)
        Lc3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_D(java.lang.Object[]):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.reflect.Method Vulcan_X(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 251
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_X(java.lang.Object[]):java.lang.reflect.Method");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00f0: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.reflect.Method Vulcan_L(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 514
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_L(java.lang.Object[]):java.lang.reflect.Method");
    }

    public static void Vulcan_k(int[] iArr) {
        Vulcan_g = iArr;
    }

    public static int[] Vulcan_d() {
        return Vulcan_g;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008e, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0091, code lost:
    
        r11 = "_\u0002\u00048\u001f:\u00191\fG(\u000f*\u0002x\u000fH.J4\u0014e\u0005K/Py\u000e9D\u0004$\u0004y\u001es\u0007A(\u001ecQ".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x009a, code lost:
    
        ac.vulcan.anticheat.Vulcan_Y.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b2, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b5, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b9, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c1, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e8, code lost:
    
        r7 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ed, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f1, code lost:
    
        r7 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f6, code lost:
    
        r7 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00fb, code lost:
    
        r7 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00ff, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0104, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0106, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x010e, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0111, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0116, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x011b, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x011f, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x012e, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00a2, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00b2, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b5, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b9, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00c1, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e8, code lost:
    
        r7 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0106, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x010e, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0111, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00ed, code lost:
    
        r7 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00f1, code lost:
    
        r7 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f6, code lost:
    
        r7 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00fb, code lost:
    
        r7 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00ff, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0104, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0116, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x011b, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011f, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0043, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0053, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005f, code lost:
    
        r2 = "_\u0002\u00048\u001f:\u00191\fG(\u000f*\u0002x\u000fH.J4\u0014e\u0005K/Py\u000e9D\u0004$\u0004y\u001es\u0007A(\u001ecQ".length();
        r11 = 27;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006e, code lost:
    
        r10 = r10 + 1;
        "_\u0002\u00048\u001f:\u00191\fG(\u000f*\u0002x\u000fH.J4\u0014e\u0005K/Py\u000e9D\u0004$\u0004y\u001es\u0007A(\u001ecQ".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007e, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b5, B:28:0x0116], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x011b -> B:15:0x00b5). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x011b -> B:34:0x00b5). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 303
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.m163clinit():void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_m(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 43971861787928(0x27fdff33b518, double:2.17249862930947E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r15
            r2 = r11
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3
            r5 = 0
            r6 = r10
            r4[r5] = r6
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_j(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_m(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Class[], java.lang.Exception, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x00aa: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x00aa: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_j(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 129534560916098(0x75cf9d7d5282, double:6.39985764977743E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int[] r0 = Vulcan_d()
            r19 = r0
            r0 = r12
            r1 = r19
            if (r1 == 0) goto L4b
            if (r0 != 0) goto L4a
            goto L46
        L42:
            java.lang.Exception r0 = a(r0)
            throw r0
        L46:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
            r12 = r0
        L4a:
            r0 = r12
        L4b:
            int r0 = r0.length
            r20 = r0
            r0 = r20
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r21 = r0
            r0 = 0
            r22 = r0
        L58:
            r0 = r22
            r1 = r20
            if (r0 >= r1) goto L8b
        L5f:
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L79
            r0 = r21
            r1 = r19
            if (r1 == 0) goto Lbd
            r1 = r22
            r2 = r12
            r3 = r22
            r2 = r2[r3]     // Catch: java.lang.NoSuchMethodException -> L87
            java.lang.Class r2 = r2.getClass()     // Catch: java.lang.NoSuchMethodException -> L87
            r0[r1] = r2     // Catch: java.lang.NoSuchMethodException -> L87
            int r22 = r22 + 1
        L79:
            r0 = r19
            if (r0 != 0) goto L58
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5f
            goto L8b
        L87:
            java.lang.Exception r0 = a(r0)
            throw r0
        L8b:
            r0 = r13
            r1 = r16
            r2 = r12
            r3 = r17
            r4 = r21
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_H(r0)
        Lbd:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_j(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception, java.lang.Object, java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.Long, java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0091: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0091: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_H(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_H(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception, java.lang.Object, java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v10 ??, still in use, count: 2, list:
          (r4v10 ?? I:??[OBJECT, ARRAY][]) from 0x0097: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
          (r4v10 ?? I:??[OBJECT, ARRAY]) from 0x0097: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_Y(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_Y(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x004a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Object Vulcan_t(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_t(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_T(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 10751203877269(0x9c735b02195, double:5.311800487194E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = r15
            r2 = r14
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3
            r5 = 0
            r6 = r10
            r4[r5] = r6
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_b(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_T(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x00b8: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x00b8: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_b(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 220
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_b(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception, java.lang.Object, java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Long, java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0086: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0086: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_d(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_d(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_Z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 19815147031984(0x120592cccdb0, double:9.7899834157964E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = r15
            r2 = r10
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3
            r5 = 0
            r6 = r11
            r4[r5] = r6
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_Q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_Z(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Class[], java.lang.Exception, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x00b3: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x00b3: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Object Vulcan_Q(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 135859168589207(0x7b902d7bb597, double:6.71233478724814E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int[] r0 = Vulcan_d()
            r19 = r0
            r0 = r14
            r1 = r19
            if (r1 == 0) goto L4c
            if (r0 != 0) goto L4b
            goto L47
        L43:
            java.lang.Exception r0 = a(r0)
            throw r0
        L47:
            java.lang.Object[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_c
            r14 = r0
        L4b:
            r0 = r14
        L4c:
            int r0 = r0.length
            r20 = r0
            r0 = r20
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r21 = r0
            r0 = 0
            r22 = r0
        L59:
            r0 = r22
            r1 = r20
            if (r0 >= r1) goto L93
        L60:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L7a
            r0 = r21
            r1 = r19
            if (r1 == 0) goto Lc6
            r1 = r22
            r2 = r14
            r3 = r22
            r2 = r2[r3]     // Catch: java.lang.NoSuchMethodException -> L88
            java.lang.Class r2 = r2.getClass()     // Catch: java.lang.NoSuchMethodException -> L88
            r0[r1] = r2     // Catch: java.lang.NoSuchMethodException -> L88
            int r22 = r22 + 1
        L7a:
            r0 = r19
            if (r0 != 0) goto L59
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L60
            goto L8c
        L88:
            java.lang.Exception r0 = a(r0)
            throw r0
        L8c:
            r0 = 4
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = new me.frep.vulcan.spigot.check.AbstractCheck[r0]
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r0)
        L93:
            r0 = r16
            r1 = r15
            r2 = r14
            r3 = r17
            r4 = r21
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Object r0 = Vulcan_t(r0)
        Lc6:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_Q(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005a: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005a: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.reflect.Method Vulcan_n(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 110284152322261(0x644d87b938d5, double:5.44876109431523E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            r1 = r15
            r2 = r11
            r3 = 1
            java.lang.Class[] r3 = new java.lang.Class[r3]
            r4 = r3
            r5 = 0
            r6 = r10
            r4[r5] = r6
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.reflect.Method r0 = m164Vulcan_K(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.Vulcan_n(java.lang.Object[]):java.lang.reflect.Method");
    }

    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v2 ??, still in use, count: 2, list:
          (r4v2 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY]) A[Catch: NoSuchMethodException -> 0x0060]
          (r4v2 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY]) A[Catch: NoSuchMethodException -> 0x0060]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public static java.lang.reflect.Method m164Vulcan_K(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 16579254309591(0xf14289052d7, double:8.1912399880343E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            java.lang.String r2 = me.frep.vulcan.spigot.Vulcan_m.b(r2, r3, r4)     // Catch: java.lang.NoSuchMethodException -> L60
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            java.lang.reflect.Method r0 = r0.getMethod(r1, r2)     // Catch: java.lang.NoSuchMethodException -> L60
            r1 = r15
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.NoSuchMethodException -> L60
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.NoSuchMethodException -> L60
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.NoSuchMethodException -> L60
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.NoSuchMethodException -> L60
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.NoSuchMethodException -> L60
            r4.<init>(r5)     // Catch: java.lang.NoSuchMethodException -> L60
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.NoSuchMethodException -> L60
            r2[r3] = r4     // Catch: java.lang.NoSuchMethodException -> L60
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.NoSuchMethodException -> L60
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.NoSuchMethodException -> L60
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.NoSuchMethodException -> L60
            r1[r2] = r3     // Catch: java.lang.NoSuchMethodException -> L60
            java.lang.reflect.Method r0 = Vulcan_X(r0)     // Catch: java.lang.NoSuchMethodException -> L60
            return r0
        L60:
            r17 = move-exception
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.m164Vulcan_K(java.lang.Object[]):java.lang.reflect.Method");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x004d, code lost:
    
        if (r0 == 0) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0056, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0057, code lost:
    
        r0 = r13 == true ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0067, code lost:
    
        return r0.getMethod(me.frep.vulcan.spigot.Vulcan_m.b(r1, r0, r1), r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x006b, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x006e, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0070, code lost:
    
        r0 = (r13 == true ? 1 : 0).getSuperclass();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0075, code lost:
    
        r13 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0077, code lost:
    
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0079, code lost:
    
        if (r0 != null) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x007c, code lost:
    
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x007f, code lost:
    
        if (r0 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0082, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0037, code lost:
    
        if (r0 != 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x003a, code lost:
    
        r13 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x003d, code lost:
    
        if (r0 <= 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0040, code lost:
    
        r0 = r13 == true ? 1 : 0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0044, code lost:
    
        if (r0 == null) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0047, code lost:
    
        r0 = java.lang.reflect.Modifier.isPublic(r0.getModifiers());
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x003a, B:25:0x007c], limit reached: 34 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v10 */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v12 */
    /* JADX WARN: Type inference failed for: r13v13 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x007f -> B:5:0x003a). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.reflect.Method m165Vulcan_m(java.lang.Object[] r6) throws java.lang.Exception {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class[] r1 = (java.lang.Class[]) r1
            r7 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_Y.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int[] r0 = Vulcan_d()
            r1 = r11
            java.lang.Class r1 = r1.getSuperclass()
            r13 = r1
            r12 = r0
        L35:
            r0 = r13
            if (r0 == 0) goto L7c
        L3a:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L77
            r0 = r13
            r1 = r12
            if (r1 == 0) goto L75
            int r0 = r0.getModifiers()     // Catch: java.lang.NoSuchMethodException -> L53 java.lang.RuntimeException -> L68
            boolean r0 = java.lang.reflect.Modifier.isPublic(r0)     // Catch: java.lang.NoSuchMethodException -> L53 java.lang.RuntimeException -> L68
            if (r0 == 0) goto L70
            goto L57
        L53:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L68
            throw r0     // Catch: java.lang.RuntimeException -> L68
        L57:
            r0 = r13
            r1 = r10
            r2 = r7
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3;      // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            java.lang.String r2 = me.frep.vulcan.spigot.Vulcan_m.b(r2, r3, r4)     // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            java.lang.reflect.Method r0 = r0.getMethod(r1, r2)     // Catch: java.lang.RuntimeException -> L68 java.lang.NoSuchMethodException -> L6c
            return r0
        L68:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L68
            throw r0
        L6c:
            r14 = move-exception
            r0 = 0
            return r0
        L70:
            r0 = r13
            java.lang.Class r0 = r0.getSuperclass()
        L75:
            r13 = r0
        L77:
            r0 = r12
            if (r0 != 0) goto L35
        L7c:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L3a
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.m165Vulcan_m(java.lang.Object[]):java.lang.reflect.Method");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    private static java.lang.reflect.Method m166Vulcan_d(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_Y.m166Vulcan_d(java.lang.Object[]):java.lang.reflect.Method");
    }
}
