package ac.vulcan.anticheat;

import java.io.UnsupportedEncodingException;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_kf, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kf.class */
public class C0021Vulcan_kf {
    public static final String Vulcan_Q;
    public static final String Vulcan_I;
    public static final String Vulcan_e;
    public static final String Vulcan_G;
    public static final String Vulcan_a;
    public static final String Vulcan_x;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6633484426231044585L, -749192195743431943L, null).a(130156397769819L);

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r12 = "\u001a7DT@\u0018\n\u00060MTI\u0016\bvN3".charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_G = r0[1];
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_x = r0[0];
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_I = r0[3];
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_e = r0[4];
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_a = r0[2];
        ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_Q = r0[5];
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00d0, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00d3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00d7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00df, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0104, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0109, code lost:
    
        r7 = 53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x010e, code lost:
    
        r7 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0113, code lost:
    
        r7 = 47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0118, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x011d, code lost:
    
        r7 = 120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0122, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0124, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r18 = r18 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x012c, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x012f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0134, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0139, code lost:
    
        if (r2 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x013d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x014c, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00c0, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r18 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00d0, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00d3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00d7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r18 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00df, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0104, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0124, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r18 = r18 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x012c, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x012f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0109, code lost:
    
        r7 = 53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x010e, code lost:
    
        r7 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0113, code lost:
    
        r7 = 47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0118, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x011d, code lost:
    
        r7 = 120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0122, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0134, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0139, code lost:
    
        if (r2 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x013d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r14;
        r14 = r14 + 1;
        r0[r4] = r0;
        r2 = r11 + r12;
        r11 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "\u001a7DT@\u0018\n\u00060MTI\u0016\bvN3".length();
        r12 = 6;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0067, code lost:
    
        r11 = r11 + 1;
        "\u001a7DT@\u0018\n\u00060MTI\u0016\bvN3".substring(r11, r11 + r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0077, code lost:
    
        r6 = r14;
        r14 = r14 + 1;
        r0[r6] = r1;
        r4 = r11 + r12;
        r11 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00d3, B:28:0x0134], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v14, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v23 */
    /* JADX WARN: Type inference failed for: r5v24 */
    /* JADX WARN: Type inference failed for: r5v25 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r5v39 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0139 -> B:15:0x00d3). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0139 -> B:34:0x00d3). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 333
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0021Vulcan_kf.m467clinit():void");
    }

    private static UnsupportedEncodingException a(UnsupportedEncodingException unsupportedEncodingException) {
        return unsupportedEncodingException;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_N(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.C0021Vulcan_kf.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3f
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.io.UnsupportedEncodingException r0 = a(r0)     // Catch: java.io.UnsupportedEncodingException -> L30
            throw r0     // Catch: java.io.UnsupportedEncodingException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.io.UnsupportedEncodingException r0 = a(r0)     // Catch: java.io.UnsupportedEncodingException -> L30
            throw r0
        L34:
            java.lang.String r0 = new java.lang.String     // Catch: java.io.UnsupportedEncodingException -> L43
            r1 = r0
            byte[] r2 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_N     // Catch: java.io.UnsupportedEncodingException -> L43
            r3 = r8
            r1.<init>(r2, r3)     // Catch: java.io.UnsupportedEncodingException -> L43
        L3f:
            goto L47
        L43:
            r10 = move-exception
            r0 = 0
            return r0
        L47:
            r0 = 1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0021Vulcan_kf.Vulcan_N(java.lang.Object[]):boolean");
    }
}
