package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fx, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fx.class */
public abstract class AbstractC0015Vulcan_fx extends Vulcan_fK {
    private static final long serialVersionUID = -7129650521543789085L;
    private final int Vulcan_M;
    private static final long b = me.frep.vulcan.spigot.Vulcan_n.a(7971896725909028932L, 2725800796009551464L, null).a(263760801526323L);
    private static final String d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // ac.vulcan.anticheat.Vulcan_fK
    public java.lang.String toString() {
        /*
            r8 = this;
            long r0 = ac.vulcan.anticheat.AbstractC0015Vulcan_fx.b
            r1 = 61977456759145(0x385e404b5169, double:3.0620932201305E-310)
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 64931191462611(0x3b0df89a1ad3, double:3.20802710452165E-310)
            long r1 = r1 ^ r2
            r11 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fK.Vulcan_p()
            r13 = r0
            r0 = r8
            java.lang.String r0 = r0.Vulcan_s     // Catch: java.lang.IllegalArgumentException -> L24
            r1 = r13
            if (r1 != 0) goto L8c
            if (r0 != 0) goto L88
            goto L28
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L28:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Class r0 = r0.Vulcan_F(r1)
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(r0)
            r14 = r0
            r0 = r8
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r2 = r1
            r2.<init>()
            r2 = r14
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "["
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.String r2 = r2.Vulcan_C(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "="
            java.lang.StringBuffer r1 = r1.append(r2)
            r2 = r8
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            int r2 = r2.Vulcan_e(r3)
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r2 = "]"
            java.lang.StringBuffer r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.Vulcan_s = r1
        L88:
            r0 = r8
            java.lang.String r0 = r0.Vulcan_s
        L8c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0015Vulcan_fx.toString():java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = ":?5'f\u001d\u0003\u0003w\u0013kB\u0000\u0005N:%tWS\u0018\u0001#peFS\u0018\u001b;<".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 94;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 48;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 7971896725909028932(0x6ea1ddd5d5e84044, double:8.26660781985303E224)
            r1 = 2725800796009551464(0x25d3fd61cea05668, double:1.845651528549663E-126)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 263760801526323(0xefe398e17233, double:1.303151507537076E-309)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.AbstractC0015Vulcan_fx.b = r0
            r0 = 94
            java.lang.String r1 = ":?5'f\u001d\u0003\u0003w\u0013kB\u0000\u0005N:%tWS\u0018\u0001#peFS\u0018\u001b;<"
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.AbstractC0015Vulcan_fx.d = r2
            goto Lab
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 48
            goto L84
        L69:
            r8 = 9
            goto L84
        L6e:
            r8 = 14
            goto L84
        L73:
            r8 = 89
            goto L84
        L78:
            r8 = 125(0x7d, float:1.75E-43)
            goto L84
        L7d:
            r8 = 45
            goto L84
        L82:
            r8 = 40
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0015Vulcan_fx.m407clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    protected AbstractC0015Vulcan_fx(String str, int i) {
        super(str);
        this.Vulcan_M = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fK, ac.vulcan.anticheat.Vulcan_fx] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException, java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected static ac.vulcan.anticheat.Vulcan_fK Vulcan_w(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.AbstractC0015Vulcan_fx.b
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 79463210148690(0x48457869e352, double:3.9260042242731E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fK.Vulcan_p()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 != 0) goto L51
            if (r0 != 0) goto L50
            goto L41
        L3d:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L41:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L4c
            r1 = r0
            java.lang.String r2 = ac.vulcan.anticheat.AbstractC0015Vulcan_fx.d     // Catch: java.lang.IllegalArgumentException -> L4c
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L4c:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0
        L50:
            r0 = r11
        L51:
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.util.List r0 = ac.vulcan.anticheat.Vulcan_fK.Vulcan_r(r0)
            r17 = r0
            r0 = r17
            java.util.Iterator r0 = r0.iterator()
            r18 = r0
        L79:
            r0 = r18
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto Lb7
            r0 = r18
            java.lang.Object r0 = r0.next()
            ac.vulcan.anticheat.Vulcan_fx r0 = (ac.vulcan.anticheat.AbstractC0015Vulcan_fx) r0
            r19 = r0
            r0 = r19
            r1 = r16
            if (r1 != 0) goto Lb1
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> La4 java.lang.IllegalArgumentException -> Lad
            int r0 = r0.Vulcan_e(r1)     // Catch: java.lang.IllegalArgumentException -> La4 java.lang.IllegalArgumentException -> Lad
            r1 = r10
            if (r0 != r1) goto Lb2
            goto La8
        La4:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> Lad
            throw r0     // Catch: java.lang.IllegalArgumentException -> Lad
        La8:
            r0 = r19
            goto Lb1
        Lad:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        Lb1:
            return r0
        Lb2:
            r0 = r16
            if (r0 == 0) goto L79
        Lb7:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.AbstractC0015Vulcan_fx.Vulcan_w(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_fK");
    }

    public final int Vulcan_e(Object[] objArr) {
        return this.Vulcan_M;
    }

    @Override // ac.vulcan.anticheat.Vulcan_fK, java.lang.Comparable
    public int compareTo(Object obj) {
        return this.Vulcan_M - ((AbstractC0015Vulcan_fx) obj).Vulcan_M;
    }
}
