package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O7.class */
public final class Vulcan_O7 extends Number implements Comparable {
    private static final long serialVersionUID = 65382027393090L;
    public static final Vulcan_O7 Vulcan_n;
    public static final Vulcan_O7 Vulcan_s;
    public static final Vulcan_O7 Vulcan_y;
    public static final Vulcan_O7 Vulcan_M;
    public static final Vulcan_O7 Vulcan_F;
    public static final Vulcan_O7 Vulcan_V;
    public static final Vulcan_O7 Vulcan_L;
    public static final Vulcan_O7 Vulcan_d;
    public static final Vulcan_O7 Vulcan_l;
    public static final Vulcan_O7 Vulcan_a;
    public static final Vulcan_O7 Vulcan_v;
    public static final Vulcan_O7 Vulcan_Z;
    private final int Vulcan_b;
    private final int Vulcan_c;
    private transient int Vulcan_D = 0;
    private transient String Vulcan_S = null;
    private transient String Vulcan_W = null;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-169554421536524172L, 5163937099569506524L, null).a(140593134665962L);
    private static final String[] b;

    /*  JADX ERROR: Failed to decode insn: 0x007C: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[11]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public static ac.vulcan.anticheat.Vulcan_O7 Vulcan_C(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 522
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_C(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x018e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private ac.vulcan.anticheat.Vulcan_O7 Vulcan_j(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 923
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_j(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: Failed to decode insn: 0x0194: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[10]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:313)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public ac.vulcan.anticheat.Vulcan_O7 Vulcan_w(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 455
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_w(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    private static ArithmeticException a(ArithmeticException arithmeticException) {
        return arithmeticException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r11 = "\u000e2\u000bV\u001a66\u0016~NC\u001f>y\b7N\u0016\"ih\u001d\u000e2\u000bV\u001a66\u0016~NP\u00135y\r%\u001cC\u0019z-\u000ed\u0000A\u001b;-\u0004".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.Vulcan_O7.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ac, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bb, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_n = new ac.vulcan.anticheat.Vulcan_O7(0, 1);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_s = new ac.vulcan.anticheat.Vulcan_O7(1, 1);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_y = new ac.vulcan.anticheat.Vulcan_O7(1, 2);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_M = new ac.vulcan.anticheat.Vulcan_O7(1, 3);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_F = new ac.vulcan.anticheat.Vulcan_O7(2, 3);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_V = new ac.vulcan.anticheat.Vulcan_O7(1, 4);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_L = new ac.vulcan.anticheat.Vulcan_O7(2, 4);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_d = new ac.vulcan.anticheat.Vulcan_O7(3, 4);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_l = new ac.vulcan.anticheat.Vulcan_O7(1, 5);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_a = new ac.vulcan.anticheat.Vulcan_O7(2, 5);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_v = new ac.vulcan.anticheat.Vulcan_O7(3, 5);
        ac.vulcan.anticheat.Vulcan_O7.Vulcan_Z = new ac.vulcan.anticheat.Vulcan_O7(4, 5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x01b8, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x009c, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ac, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00af, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b3, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00bb, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e0, code lost:
    
        r7 = 22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e5, code lost:
    
        r7 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ef, code lost:
    
        r7 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f4, code lost:
    
        r7 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f9, code lost:
    
        r7 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00fe, code lost:
    
        r7 = 46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003d, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "\u000e2\u000bV\u001a66\u0016~NC\u001f>y\b7N\u0016\"ih\u001d\u000e2\u000bV\u001a66\u0016~NP\u00135y\r%\u001cC\u0019z-\u000ed\u0000A\u001b;-\u0004".length();
        r11 = 21;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0068, code lost:
    
        r10 = r10 + 1;
        "\u000e2\u000bV\u001a66\u0016~NC\u001f>y\b7N\u0016\"ih\u001d\u000e2\u000bV\u001a66\u0016~NP\u00135y\r%\u001cC\u0019z-\u000ed\u0000A\u001b;-\u0004".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0078, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00af, B:28:0x0110], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v23 */
    /* JADX WARN: Type inference failed for: r5v24 */
    /* JADX WARN: Type inference failed for: r5v25 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r5v39 */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00af). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0115 -> B:35:0x00af). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 441
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.m47clinit():void");
    }

    private Vulcan_O7(int i, int i2) {
        this.Vulcan_b = i;
        this.Vulcan_c = i2;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static ac.vulcan.anticheat.Vulcan_O7 Vulcan_F(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r12 = r0
            r0 = r10
            r1 = r12
            if (r1 == 0) goto L4f
            if (r0 != 0) goto L4e
            goto L3c
        L38:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L4a
            throw r0     // Catch: java.lang.ArithmeticException -> L4a
        L3c:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> L4a
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L4a
            r3 = 15
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L4a
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L4a
            throw r0     // Catch: java.lang.ArithmeticException -> L4a
        L4a:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L4a
            throw r0
        L4e:
            r0 = r10
        L4f:
            r1 = r12
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L68
            if (r1 == 0) goto L66
            if (r0 >= 0) goto Lb0
            goto L64
        L60:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L64:
            r0 = r11
        L66:
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
        L68:
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L93
            r2 = r12
            if (r2 == 0) goto L93
            if (r0 == r1) goto L96
            goto L7d
        L79:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L86
            throw r0     // Catch: java.lang.ArithmeticException -> L86
        L7d:
            r0 = r10
            r1 = r12
            if (r1 == 0) goto Laf
            goto L8a
        L86:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L8f
            throw r0     // Catch: java.lang.ArithmeticException -> L8f
        L8a:
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L93
        L8f:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L93:
            if (r0 != r1) goto La8
        L96:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> La4
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> La4
            r3 = 14
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> La4
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> La4
            throw r0     // Catch: java.lang.ArithmeticException -> La4
        La4:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> La4
            throw r0
        La8:
            r0 = r11
            int r0 = -r0
            r11 = r0
            r0 = r10
            int r0 = -r0
        Laf:
            r10 = r0
        Lb0:
            ac.vulcan.anticheat.Vulcan_O7 r0 = new ac.vulcan.anticheat.Vulcan_O7
            r1 = r0
            r2 = r11
            r3 = r10
            r1.<init>(r2, r3)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static ac.vulcan.anticheat.Vulcan_O7 Vulcan_y(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 302
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static ac.vulcan.anticheat.Vulcan_O7 Vulcan_B(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_B(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static ac.vulcan.anticheat.Vulcan_O7 Vulcan_G(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 512
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_G(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    public int Vulcan_b(Object[] objArr) {
        return this.Vulcan_b;
    }

    public int Vulcan_e(Object[] objArr) {
        return this.Vulcan_c;
    }

    public int Vulcan_S(Object[] objArr) {
        return Math.abs(this.Vulcan_b % this.Vulcan_c);
    }

    public int Vulcan_R(Object[] objArr) {
        return this.Vulcan_b / this.Vulcan_c;
    }

    @Override // java.lang.Number
    public int intValue() {
        return this.Vulcan_b / this.Vulcan_c;
    }

    @Override // java.lang.Number
    public long longValue() {
        return ((long) this.Vulcan_b) / ((long) this.Vulcan_c);
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_b / this.Vulcan_c;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return ((double) this.Vulcan_b) / ((double) this.Vulcan_c);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_O7 m48Vulcan_b(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.m48Vulcan_b(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.ArithmeticException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_O7] */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_O7] */
    /* JADX WARN: Type inference failed for: r0v20, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public Vulcan_O7 Vulcan_W(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ArithmeticException arithmeticExceptionVulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                arithmeticExceptionVulcan_Q = this.Vulcan_b;
                ArithmeticException vulcan_O7 = arithmeticExceptionVulcan_Q;
                if (arithmeticExceptionVulcan_Q == 0) {
                    if (arithmeticExceptionVulcan_Q == 0) {
                        throw new ArithmeticException(b[7]);
                    }
                    vulcan_O7 = this.Vulcan_b;
                }
                try {
                    if (jLongValue >= 0 && arithmeticExceptionVulcan_Q == 0) {
                        if (vulcan_O7 == -2147483648) {
                            throw new ArithmeticException(b[2]);
                        }
                        vulcan_O7 = this;
                        if (arithmeticExceptionVulcan_Q != 0) {
                            return vulcan_O7;
                        }
                        try {
                            vulcan_O7 = vulcan_O7.Vulcan_b;
                        } catch (ArithmeticException unused) {
                            throw a(vulcan_O7);
                        }
                    }
                    if (vulcan_O7 < 0) {
                        try {
                            vulcan_O7 = new Vulcan_O7(-this.Vulcan_c, -this.Vulcan_b);
                            return vulcan_O7;
                        } catch (ArithmeticException unused2) {
                            throw a(vulcan_O7);
                        }
                    }
                    return new Vulcan_O7(this.Vulcan_c, this.Vulcan_b);
                } catch (ArithmeticException unused3) {
                    throw a(vulcan_O7);
                }
            } catch (ArithmeticException unused4) {
                throw a(arithmeticExceptionVulcan_Q);
            }
        } catch (ArithmeticException unused5) {
            throw a(arithmeticExceptionVulcan_Q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_O7] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public Vulcan_O7 Vulcan_s(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ArithmeticException arithmeticException = this;
        if (Vulcan_OA.Vulcan_u() == 0) {
            return arithmeticException;
        }
        try {
            try {
                arithmeticException = arithmeticException.Vulcan_b;
                if (arithmeticException == -2147483648) {
                    throw new ArithmeticException(b[23]);
                }
                return new Vulcan_O7(-this.Vulcan_b, this.Vulcan_c);
            } catch (ArithmeticException unused) {
                throw a(arithmeticException);
            }
        } catch (ArithmeticException unused2) {
            throw a(arithmeticException);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [ac.vulcan.anticheat.Vulcan_O7] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.ArithmeticException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v3, types: [ac.vulcan.anticheat.Vulcan_O7, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_O7 Vulcan_P(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 64200559993160(0x3a63db92a148, double:3.17192911363903E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 == 0) goto L52
            int r0 = r0.Vulcan_b     // Catch: java.lang.ArithmeticException -> L2f java.lang.ArithmeticException -> L35
            if (r0 < 0) goto L39
            goto L33
        L2f:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L35
            throw r0     // Catch: java.lang.ArithmeticException -> L35
        L33:
            r0 = r9
            return r0
        L35:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L35
            throw r0
        L39:
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_O7 r0 = r0.Vulcan_s(r1)
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_P(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_O7 m49Vulcan_S(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 694
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.m49Vulcan_S(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static int Vulcan_d(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 450
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_d(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    private static int m50Vulcan_B(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r1 = r10
            long r1 = (long) r1
            r2 = r9
            long r2 = (long) r2
            long r1 = r1 * r2
            r12 = r1
            r11 = r0
            r0 = r12
            r1 = -2147483648(0xffffffff80000000, double:NaN)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r11
            if (r1 == 0) goto L56
            if (r0 < 0) goto L65
            goto L49
        L45:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L52
            throw r0     // Catch: java.lang.ArithmeticException -> L52
        L49:
            r0 = r12
            r1 = 2147483647(0x7fffffff, double:1.060997895E-314)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L56
        L52:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L56:
            r1 = r11
            if (r1 == 0) goto L79
            if (r0 <= 0) goto L76
            goto L65
        L61:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L72
            throw r0     // Catch: java.lang.ArithmeticException -> L72
        L65:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> L72
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L72
            r3 = 1
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L72
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L72
            throw r0     // Catch: java.lang.ArithmeticException -> L72
        L72:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L72
            throw r0
        L76:
            r0 = r12
            int r0 = (int) r0
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.m50Vulcan_B(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.ArithmeticException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static int Vulcan_z(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        long j2 = ((long) iIntValue) * ((long) iIntValue2);
        try {
            int i = (j2 > 2147483647L ? 1 : (j2 == 2147483647L ? 0 : -1));
            if (Vulcan_u == 0) {
                return i;
            }
            if (i > 0) {
                throw new ArithmeticException(b[20]);
            }
            return (int) j2;
        } catch (ArithmeticException unused) {
            throw a(Vulcan_u);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static int Vulcan_M(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r1 = r7
            long r1 = (long) r1
            r2 = r8
            long r2 = (long) r2
            long r1 = r1 + r2
            r12 = r1
            r11 = r0
            r0 = r12
            r1 = -2147483648(0xffffffff80000000, double:NaN)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r11
            if (r1 == 0) goto L54
            if (r0 < 0) goto L63
            goto L47
        L43:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L50
            throw r0     // Catch: java.lang.ArithmeticException -> L50
        L47:
            r0 = r12
            r1 = 2147483647(0x7fffffff, double:1.060997895E-314)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L54
        L50:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L54:
            r1 = r11
            if (r1 == 0) goto L78
            if (r0 <= 0) goto L75
            goto L63
        L5f:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L71
            throw r0     // Catch: java.lang.ArithmeticException -> L71
        L63:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> L71
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L71
            r3 = 12
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L71
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L71
            throw r0     // Catch: java.lang.ArithmeticException -> L71
        L71:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L71
            throw r0
        L75:
            r0 = r12
            int r0 = (int) r0
        L78:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_M(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static int Vulcan_U(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r10
            long r1 = (long) r1
            r2 = r7
            long r2 = (long) r2
            long r1 = r1 - r2
            r12 = r1
            r11 = r0
            r0 = r12
            r1 = -2147483648(0xffffffff80000000, double:NaN)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r11
            if (r1 != 0) goto L56
            if (r0 < 0) goto L65
            goto L49
        L45:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L52
            throw r0     // Catch: java.lang.ArithmeticException -> L52
        L49:
            r0 = r12
            r1 = 2147483647(0x7fffffff, double:1.060997895E-314)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L56
        L52:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L56:
            r1 = r11
            if (r1 != 0) goto L79
            if (r0 <= 0) goto L76
            goto L65
        L61:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L72
            throw r0     // Catch: java.lang.ArithmeticException -> L72
        L65:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> L72
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L72
            r3 = 4
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L72
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L72
            throw r0     // Catch: java.lang.ArithmeticException -> L72
        L72:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L72
            throw r0
        L76:
            r0 = r12
            int r0 = (int) r0
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_U(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_O7, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_O7 Vulcan_l(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_O7 r1 = (ac.vulcan.anticheat.Vulcan_O7) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 15725355722016(0xe4d583de520, double:7.769358030881E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = r14
            r3 = 1
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_O7 r0 = r0.Vulcan_j(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_l(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_O7, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_O7 Vulcan_X(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_O7 r1 = (ac.vulcan.anticheat.Vulcan_O7) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 124976822731755(0x71aa6f1fc3eb, double:6.17467546381515E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = r14
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_O7 r0 = r0.Vulcan_j(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_X(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.ArithmeticException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_O7] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x008f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x008f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_O7 Vulcan_D(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_O7 r1 = (ac.vulcan.anticheat.Vulcan_O7) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 98260836604371(0x595e2242d9d3, double:4.854730369784E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 47831298122933(0x2b809788a4b5, double:2.3631801198532E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r19 = r0
            r0 = r14
            r1 = r19
            if (r1 == 0) goto L54
            if (r0 != 0) goto L52
            goto L40
        L3c:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L4e
            throw r0     // Catch: java.lang.ArithmeticException -> L4e
        L40:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.ArithmeticException -> L4e
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L4e
            r3 = 16
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L4e
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L4e
            throw r0     // Catch: java.lang.ArithmeticException -> L4e
        L4e:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L4e
            throw r0
        L52:
            r0 = r14
        L54:
            r1 = r19
            if (r1 == 0) goto Lb0
            int r0 = r0.Vulcan_b     // Catch: java.lang.ArithmeticException -> L62 java.lang.ArithmeticException -> L74
            if (r0 != 0) goto L78
            goto L66
        L62:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L74
            throw r0     // Catch: java.lang.ArithmeticException -> L74
        L66:
            java.lang.ArithmeticException r0 = new java.lang.ArithmeticException     // Catch: java.lang.ArithmeticException -> L74
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_O7.b     // Catch: java.lang.ArithmeticException -> L74
            r3 = 19
            r2 = r2[r3]     // Catch: java.lang.ArithmeticException -> L74
            r1.<init>(r2)     // Catch: java.lang.ArithmeticException -> L74
            throw r0     // Catch: java.lang.ArithmeticException -> L74
        L74:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L74
            throw r0
        L78:
            r0 = r10
            r1 = r14
            r2 = r17
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            ac.vulcan.anticheat.Vulcan_O7 r1 = r1.Vulcan_W(r2)
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_O7 r0 = r0.Vulcan_w(r1)
        Lb0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.Vulcan_D(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_O7");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = 116042007507192(0x698a22a2f0f8, double:5.73323693837556E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L20
            throw r0     // Catch: java.lang.ArithmeticException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_O7     // Catch: java.lang.ArithmeticException -> L33 java.lang.ArithmeticException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L39
            throw r0     // Catch: java.lang.ArithmeticException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_O7 r0 = (ac.vulcan.anticheat.Vulcan_O7) r0
            r10 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.ArithmeticException -> L5f
            int r0 = r0.Vulcan_b(r1)     // Catch: java.lang.ArithmeticException -> L5f
            r1 = r10
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.ArithmeticException -> L5f
            int r1 = r1.Vulcan_b(r2)     // Catch: java.lang.ArithmeticException -> L5f
            r2 = r9
            if (r2 != 0) goto L87
            if (r0 != r1) goto L8e
            goto L63
        L5f:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L73
            throw r0     // Catch: java.lang.ArithmeticException -> L73
        L63:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.ArithmeticException -> L73 java.lang.ArithmeticException -> L83
            int r0 = r0.Vulcan_e(r1)     // Catch: java.lang.ArithmeticException -> L73 java.lang.ArithmeticException -> L83
            r1 = r9
            if (r1 != 0) goto L8b
            goto L77
        L73:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L83
            throw r0     // Catch: java.lang.ArithmeticException -> L83
        L77:
            r1 = r10
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.ArithmeticException -> L83
            int r1 = r1.Vulcan_e(r2)     // Catch: java.lang.ArithmeticException -> L83
            goto L87
        L83:
            java.lang.ArithmeticException r0 = a(r0)
            throw r0
        L87:
            if (r0 != r1) goto L8e
            r0 = 1
        L8b:
            goto L8f
        L8e:
            r0 = 0
        L8f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    public int hashCode() {
        long j = a ^ 131905244495485L;
        ArithmeticException arithmeticExceptionVulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                arithmeticExceptionVulcan_Q = this.Vulcan_D;
                if (arithmeticExceptionVulcan_Q != 0) {
                    return arithmeticExceptionVulcan_Q;
                }
                if (arithmeticExceptionVulcan_Q == 0) {
                    this.Vulcan_D = (37 * (629 + Vulcan_b(new Object[0]))) + Vulcan_e(new Object[0]);
                }
                return this.Vulcan_D;
            } catch (ArithmeticException unused) {
                throw a(arithmeticExceptionVulcan_Q);
            }
        } catch (ArithmeticException unused2) {
            throw a(arithmeticExceptionVulcan_Q);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // java.lang.Comparable
    public int compareTo(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_O7.a
            r1 = 121457914686247(0x6e771fdc2b27, double:6.00081830619916E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r1 = r6
            ac.vulcan.anticheat.Vulcan_O7 r1 = (ac.vulcan.anticheat.Vulcan_O7) r1
            r10 = r1
            r9 = r0
            r0 = r5
            r1 = r9
            if (r1 == 0) goto L2c
            r1 = r10
            if (r0 != r1) goto L2b
            goto L25
        L21:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L27
            throw r0     // Catch: java.lang.ArithmeticException -> L27
        L25:
            r0 = 0
            return r0
        L27:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L27
            throw r0
        L2b:
            r0 = r5
        L2c:
            int r0 = r0.Vulcan_b     // Catch: java.lang.ArithmeticException -> L3f
            r1 = r9
            if (r1 == 0) goto L6c
            r1 = r10
            int r1 = r1.Vulcan_b     // Catch: java.lang.ArithmeticException -> L3f java.lang.ArithmeticException -> L4f
            if (r0 != r1) goto L68
            goto L43
        L3f:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L4f
            throw r0     // Catch: java.lang.ArithmeticException -> L4f
        L43:
            r0 = r5
            int r0 = r0.Vulcan_c     // Catch: java.lang.ArithmeticException -> L4f java.lang.ArithmeticException -> L5e
            r1 = r9
            if (r1 == 0) goto L6c
            goto L53
        L4f:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L5e
            throw r0     // Catch: java.lang.ArithmeticException -> L5e
        L53:
            r1 = r10
            int r1 = r1.Vulcan_c     // Catch: java.lang.ArithmeticException -> L5e java.lang.ArithmeticException -> L64
            if (r0 != r1) goto L68
            goto L62
        L5e:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L64
            throw r0     // Catch: java.lang.ArithmeticException -> L64
        L62:
            r0 = 0
            return r0
        L64:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L64
            throw r0
        L68:
            r0 = r5
            int r0 = r0.Vulcan_b
        L6c:
            long r0 = (long) r0
            r1 = r10
            int r1 = r1.Vulcan_c
            long r1 = (long) r1
            long r0 = r0 * r1
            r11 = r0
            r0 = r10
            int r0 = r0.Vulcan_b
            long r0 = (long) r0
            r1 = r5
            int r1 = r1.Vulcan_c
            long r1 = (long) r1
            long r0 = r0 * r1
            r13 = r0
            r0 = r11
            r1 = r13
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            if (r1 == 0) goto La3
            if (r0 != 0) goto L9e
            goto L98
        L94:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L9a
            throw r0     // Catch: java.lang.ArithmeticException -> L9a
        L98:
            r0 = 0
            return r0
        L9a:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> L9a
            throw r0
        L9e:
            r0 = r11
            r1 = r13
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        La3:
            r1 = r9
            if (r1 == 0) goto Lb9
            if (r0 >= 0) goto Lb8
            goto Lb2
        Lae:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> Lb4
            throw r0     // Catch: java.lang.ArithmeticException -> Lb4
        Lb2:
            r0 = -1
            return r0
        Lb4:
            java.lang.ArithmeticException r0 = a(r0)     // Catch: java.lang.ArithmeticException -> Lb4
            throw r0
        Lb8:
            r0 = 1
        Lb9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.compareTo(java.lang.Object):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v19, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v16, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v19, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0055: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: ArithmeticException -> 0x00c2]
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0055: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: ArithmeticException -> 0x00c2]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 203
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_O7.toString():java.lang.String");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v44 ??, still in use, count: 2, list:
          (r0v44 ?? I:java.lang.ArithmeticException) from 0x0162: INVOKE (r0v45 ?? I:java.lang.ArithmeticException) = (r0v44 ?? I:java.lang.ArithmeticException) STATIC call: ac.vulcan.anticheat.Vulcan_O7.a(java.lang.ArithmeticException):java.lang.ArithmeticException A[MD:(java.lang.ArithmeticException):java.lang.ArithmeticException (m)]
          (r0v44 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0144: MOVE (r0v57 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v44 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public java.lang.String Vulcan_L(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v44 ??, still in use, count: 2, list:
          (r0v44 ?? I:java.lang.ArithmeticException) from 0x0162: INVOKE (r0v45 ?? I:java.lang.ArithmeticException) = (r0v44 ?? I:java.lang.ArithmeticException) STATIC call: ac.vulcan.anticheat.Vulcan_O7.a(java.lang.ArithmeticException):java.lang.ArithmeticException A[MD:(java.lang.ArithmeticException):java.lang.ArithmeticException (m)]
          (r0v44 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0144: MOVE (r0v57 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r0v44 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
}
