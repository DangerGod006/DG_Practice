package ac.vulcan.anticheat;

import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/UniversalScheduler.class */
public class UniversalScheduler {
    public static final boolean Vulcan_H = Vulcan_W.Vulcan_T(new Object[]{"io.papermc.paper.threadedregions.RegionizedServer"});
    public static final boolean Vulcan_i = Vulcan_W.Vulcan_T(new Object[]{"io.canvasmc.canvas.server.ThreadedServer"});
    public static final boolean Vulcan_A = Vulcan_W.Vulcan_T(new Object[]{"io.papermc.paper.threadedregions.scheduler.ScheduledTask"});

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [ac.vulcan.anticheat.Vulcan_H, ac.vulcan.anticheat.Vulcan_Ou] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v1 */
    public static Vulcan_H Vulcan_m(Object[] objArr) {
        ?? vulcan_Ou = objArr;
        Plugin plugin = (Plugin) vulcan_Ou[0];
        try {
            try {
                if (!Vulcan_H) {
                    vulcan_Ou = Vulcan_i;
                    if (vulcan_Ou == 0) {
                        try {
                            if (!Vulcan_A) {
                                return new Vulcan_OL(plugin);
                            }
                            vulcan_Ou = new Vulcan_Ou(plugin);
                            return vulcan_Ou;
                        } catch (RuntimeException unused) {
                            throw a(vulcan_Ou);
                        }
                    }
                }
                return new Vulcan_O0(plugin);
            } catch (RuntimeException unused2) {
                throw a(vulcan_Ou);
            }
        } catch (RuntimeException unused3) {
            throw a(vulcan_Ou);
        }
    }
}
