package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O1.class */
public class Vulcan_O1 extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = -1585823265;
    private byte Vulcan_w;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(7647737021769486644L, 1354911063889075152L, null).a(66839806196355L);

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public Vulcan_O1() {
    }

    public Vulcan_O1(byte b) {
        this.Vulcan_w = b;
    }

    public Vulcan_O1(Number number) {
        this.Vulcan_w = number.byteValue();
    }

    public Vulcan_O1(String str) {
        this.Vulcan_w = Byte.parseByte(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Byte(this.Vulcan_w);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [byte, int] */
    public void Vulcan_l(Object[] objArr) {
        this.Vulcan_w = ((Integer) objArr[0]).intValue();
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        Vulcan_l(new Object[]{new Integer(((Number) objArr[0]).byteValue())});
    }

    public void Vulcan_v(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w + 1);
    }

    public void Vulcan_E(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w - 1);
    }

    public void Vulcan_Z(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w + ((Integer) objArr[0]).intValue());
    }

    public void Vulcan_m(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w + ((Number) objArr[0]).byteValue());
    }

    public void Vulcan_e(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w - ((Integer) objArr[0]).intValue());
    }

    public void Vulcan_P(Object[] objArr) {
        this.Vulcan_w = (byte) (this.Vulcan_w - ((Number) objArr[0]).byteValue());
    }

    @Override // java.lang.Number
    public byte byteValue() {
        return this.Vulcan_w;
    }

    @Override // java.lang.Number
    public int intValue() {
        return this.Vulcan_w;
    }

    @Override // java.lang.Number
    public long longValue() {
        return this.Vulcan_w;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_w;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_w;
    }

    public Byte Vulcan_X(Object[] objArr) {
        return new Byte(byteValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean, byte] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    public boolean equals(Object obj) {
        long j = a ^ 91462236938692L;
        NumberFormatException numberFormatExceptionVulcan_n = C0003Vulcan_On.Vulcan_n();
        try {
            try {
                try {
                    numberFormatExceptionVulcan_n = obj instanceof Vulcan_O1;
                    try {
                        if (numberFormatExceptionVulcan_n == 0) {
                            return numberFormatExceptionVulcan_n;
                        }
                        if (numberFormatExceptionVulcan_n != 0) {
                            ?? r0 = this.Vulcan_w;
                            return numberFormatExceptionVulcan_n != 0 ? r0 == ((Vulcan_O1) obj).byteValue() : r0;
                        }
                        return false;
                    } catch (NumberFormatException unused) {
                        throw a(numberFormatExceptionVulcan_n);
                    }
                } catch (NumberFormatException unused2) {
                    throw a(numberFormatExceptionVulcan_n);
                }
            } catch (NumberFormatException unused3) {
                throw a(numberFormatExceptionVulcan_n);
            }
        } catch (NumberFormatException unused4) {
            throw a(numberFormatExceptionVulcan_n);
        }
    }

    public int hashCode() {
        return this.Vulcan_w;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [byte] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [byte, int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v4, types: [byte] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.NumberFormatException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    @Override // java.lang.Comparable
    public int compareTo(Object obj) {
        long j = a ^ 47798151363714L;
        boolean zVulcan_n = C0003Vulcan_On.Vulcan_n();
        ?? A = ((Vulcan_O1) obj).Vulcan_w;
        try {
            try {
                A = this.Vulcan_w;
                ?? r1 = A;
                ?? r0 = A;
                ?? r12 = r1;
                if (zVulcan_n) {
                    if (A < r1) {
                        return -1;
                    }
                    try {
                        A = this.Vulcan_w;
                        if (!zVulcan_n) {
                            return A;
                        }
                        r12 = A;
                        r0 = A;
                    } catch (NumberFormatException unused) {
                        throw a(A);
                    }
                }
                return r0 == r12 ? 0 : 1;
            } catch (NumberFormatException unused2) {
                throw a(A);
            }
        } catch (NumberFormatException unused3) {
            A = a(A);
            throw A;
        }
    }

    public String toString() {
        return String.valueOf((int) this.Vulcan_w);
    }
}
