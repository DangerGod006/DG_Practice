package ac.vulcan.anticheat;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kB.class */
public class Vulcan_kB {
    static final String Vulcan_X;
    private static final Object Vulcan_g;
    private static String[] Vulcan_u;
    private static final Method Vulcan_H;
    private static final Method Vulcan_E;
    static Class Vulcan_a;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-4644753821764608857L, -148842661481991242L, null).a(241836207435530L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_v(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 209
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_v(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_w(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 62579321536592(0x38ea623b0050, double:3.09182929112834E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r14 = r0
            r0 = r12
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_c(r0)
            if (r0 == 0) goto L95
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]
            java.util.ArrayList r0 = Vulcan_Q(r0)
            r15 = r0
            r0 = r15
            r1 = r9
            r2 = r14
            if (r2 != 0) goto L73
            boolean r0 = r0.remove(r1)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L64 ac.vulcan.anticheat.Vulcan_kM -> L6f
            if (r0 == 0) goto L95
            goto L68
        L64:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L6f
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L6f
        L68:
            java.lang.Object r0 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_g     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L6f
            r1 = r0
            goto L73
        L6f:
            java.lang.Exception r0 = a(r0)
            throw r0
        L73:
            r16 = r1
            monitor-enter(r0)
            r0 = r15
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.Throwable -> L8d
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.Throwable -> L8d
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.Throwable -> L8d
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.Throwable -> L8d
            r1[r2] = r3     // Catch: java.lang.Throwable -> L8d
            java.lang.String[] r0 = Vulcan_q(r0)     // Catch: java.lang.Throwable -> L8d
            ac.vulcan.anticheat.Vulcan_kB.Vulcan_u = r0     // Catch: java.lang.Throwable -> L8d
            r0 = r16
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L8d
            goto L95
        L8d:
            r17 = move-exception
            r0 = r16
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L8d
            r0 = r17
            throw r0
        L95:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_w(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0042: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_u(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 3822279658359(0x379f19f0b77, double:1.888457067993E-311)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            java.lang.Object r1 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_g
            r2 = r1
            r15 = r2
            monitor-enter(r1)
            r14 = r0
            r0 = r12
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_u     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r2 = r9
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r4 = r3; r3 = r2; r2 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r5 = r3; r3 = r4; r4 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r3[r4] = r5     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r3 = r2; r2 = r1; r1 = r3;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r4 = r2; r2 = r3; r3 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r2[r3] = r4     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            java.lang.Long r3 = new java.lang.Long     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r3.<init>(r4)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r1[r2] = r3     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            int r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_e(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5f java.lang.Throwable -> L6c
            r1 = r14
            if (r1 != 0) goto L64
            if (r0 < 0) goto L67
            goto L63
        L5f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Throwable -> L6c
            throw r0     // Catch: java.lang.Throwable -> L6c
        L63:
            r0 = 1
        L64:
            goto L68
        L67:
            r0 = 0
        L68:
            r1 = r15
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L6c
            return r0
        L6c:
            r16 = move-exception
            r0 = r15
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L6c
            r0 = r16
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_u(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a0: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_H(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 433
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_H(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public static int m424Vulcan_w(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 34532682160684(0x1f684440da2c, double:1.7061411914349E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r11
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.util.List r0 = m425Vulcan_w(r0)
            int r0 = r0.size()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m424Vulcan_w(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Throwable[] Vulcan_O(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 33165131889987(0x1e29dbe7bd43, double:1.63857523066365E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r11
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.util.List r0 = m425Vulcan_w(r0)
            r14 = r0
            r0 = r14
            r1 = r14
            int r1 = r1.size()
            java.lang.Throwable[] r1 = new java.lang.Throwable[r1]
            java.lang.Object[] r0 = r0.toArray(r1)
            java.lang.Throwable[] r0 = (java.lang.Throwable[]) r0
            java.lang.Throwable[] r0 = (java.lang.Throwable[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_O(java.lang.Object[]):java.lang.Throwable[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x007b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static int Vulcan_z(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 353
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_z(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0036: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public static void m427Vulcan_H(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 29740228918208(0x1b0c6fc7bbc0, double:1.4693625407941E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r9
            java.io.PrintStream r2 = java.lang.System.err
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            m428Vulcan_z(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m427Vulcan_H(java.lang.Object[]):void");
    }

    /*  JADX ERROR: Failed to decode insn: 0x00D5: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:313)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static java.lang.String[] m429Vulcan_Q(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 460
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m429Vulcan_Q(java.lang.Object[]):java.lang.String[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x004f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public static java.lang.String m431Vulcan_F(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 248
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m431Vulcan_F(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_D(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 76530579990857(0x459aaa08e949, double:3.7811130429788E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 11264773217259(0xa3ec8ce5beb, double:5.56553745484E-311)
            long r1 = r1 ^ r2
            r16 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r18 = r0
            r0 = r13
            r1 = r18
            if (r1 != 0) goto L47
            if (r0 != 0) goto L46
            goto L3e
        L3a:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L42
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L42
        L3e:
            java.lang.String r0 = ""
            return r0
        L42:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L42
            throw r0
        L46:
            r0 = r13
        L47:
            r1 = 0
            r2 = r16
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_u(r0)
            r19 = r0
            r0 = r13
            java.lang.String r0 = r0.getMessage()
            r20 = r0
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r1 = r0
            r1.<init>()
            r1 = r19
            java.lang.StringBuffer r0 = r0.append(r1)
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_kB.b
            r2 = 23
            r1 = r1[r2]
            java.lang.StringBuffer r0 = r0.append(r1)
            r1 = r20
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r1 = ac.vulcan.anticheat.C0027Vulcan_ku.m532Vulcan_L(r1)
            java.lang.StringBuffer r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_D(java.lang.Object[]):java.lang.String");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0088, code lost:
    
        if (r4 >= r2) goto L80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008b, code lost:
    
        r11 = "d>!aLDUf?\u0017[hIEf+!KB_\td>!lHBRf?".charAt(r10);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0094, code lost:
    
        ac.vulcan.anticheat.Vulcan_kB.b = r0;
        ac.vulcan.anticheat.Vulcan_kB.Vulcan_X = ac.vulcan.anticheat.Vulcan_kB.b[11];
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b7, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ba, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00be, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c6, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00ec, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00f1, code lost:
    
        r7 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f6, code lost:
    
        r7 = 38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00fb, code lost:
    
        r7 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0100, code lost:
    
        r7 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0105, code lost:
    
        r7 = 66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x010a, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x010c, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0114, code lost:
    
        if (r2 != 0) goto L79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0117, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x011c, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0121, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0125, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0134, code lost:
    
        ac.vulcan.anticheat.Vulcan_kB.Vulcan_g = new java.lang.Object();
        r7 = ac.vulcan.anticheat.Vulcan_kB.b;
        ac.vulcan.anticheat.Vulcan_kB.Vulcan_u = new java.lang.String[]{r7[16], r7[9], r7[12], r7[0], r7[21], r7[19], r7[25], r7[26], r7[3], r7[4], r7[8], r7[22]};
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x01a4, code lost:
    
        if (ac.vulcan.anticheat.Vulcan_kB.Vulcan_a != null) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x01a7, code lost:
    
        r4 = Vulcan_Y(new java.lang.Object[]{r7[1]});
        ac.vulcan.anticheat.Vulcan_kB.Vulcan_a = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x01bd, code lost:
    
        r4 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x01c0, code lost:
    
        r18 = r4.getMethod(ac.vulcan.anticheat.Vulcan_kB.b[18], null);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x01d3, code lost:
    
        r0 = 0;
        r18 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003d, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00a7, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
        r2 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00b7, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00ba, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00be, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00c6, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004d, code lost:
    
        if (r2 >= r0) goto L78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00ec, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x010c, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0114, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0117, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x00f1, code lost:
    
        r7 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00f6, code lost:
    
        r7 = 38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x00fb, code lost:
    
        r7 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0100, code lost:
    
        r7 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0105, code lost:
    
        r7 = 66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x010a, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x011c, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0121, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0125, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0059, code lost:
    
        r2 = "d>!aLDUf?\u0017[hIEf+!KB_\td>!lHBRf?".length();
        r11 = 20;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0068, code lost:
    
        r10 = r10 + 1;
        "d>!aLDUf?\u0017[hIEf+!KB_\td>!lHBRf?".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0078, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ba, B:28:0x011c], limit reached: 82 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v43 */
    /* JADX WARN: Type inference failed for: r5v44 */
    /* JADX WARN: Type inference failed for: r5v45 */
    /* JADX WARN: Type inference failed for: r5v49 */
    /* JADX WARN: Type inference failed for: r5v59 */
    /* JADX WARN: Type inference failed for: r7v33 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0121 -> B:15:0x00ba). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:71:0x0121 -> B:57:0x00ba). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 581
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m423clinit():void");
    }

    static Class Vulcan_Y(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_kM, java.lang.Throwable] */
    public static boolean Vulcan_E(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        Throwable th = (Throwable) objArr[1];
        Throwable th2 = (Throwable) objArr[2];
        long j = a ^ jLongValue;
        String strVulcan_J = Vulcan_k5.Vulcan_J();
        ?? vulcan_kM = th;
        if (vulcan_kM == 0) {
            try {
                vulcan_kM = new Vulcan_kM(b[15]);
                throw vulcan_kM;
            } catch (IllegalAccessException unused) {
                throw a(vulcan_kM);
            }
        }
        Object[] objArr2 = {th2};
        boolean z = false;
        ?? Invoke = (j > 0L ? 1 : (j == 0L ? 0 : -1));
        Invoke = Invoke;
        if (Invoke > 0) {
            try {
                Invoke = Vulcan_E;
                if (strVulcan_J == null) {
                    if (Invoke != 0) {
                        try {
                            Invoke = Vulcan_E.invoke(th, objArr2);
                        } catch (IllegalAccessException e) {
                        } catch (InvocationTargetException e2) {
                        }
                    }
                }
                Invoke = 1;
                z = true;
            } catch (IllegalAccessException unused2) {
                throw a(Invoke);
            }
        }
        try {
            try {
                try {
                    Invoke = th.getClass();
                    String str = b[24];
                    Class[] clsArr = new Class[1];
                    Class clsVulcan_Y = Vulcan_a;
                    if (strVulcan_J != null) {
                        clsArr[0] = clsVulcan_Y;
                        Invoke.getMethod(str, clsArr).invoke(th, objArr2);
                        z = true;
                    } else if (clsVulcan_Y == null) {
                        clsVulcan_Y = Vulcan_Y(new Object[]{b[17]});
                        Vulcan_a = clsVulcan_Y;
                        clsArr[0] = clsVulcan_Y;
                        Invoke.getMethod(str, clsArr).invoke(th, objArr2);
                        z = true;
                    } else {
                        clsVulcan_Y = Vulcan_a;
                        clsArr[0] = clsVulcan_Y;
                        Invoke.getMethod(str, clsArr).invoke(th, objArr2);
                        z = true;
                    }
                } catch (IllegalAccessException unused3) {
                    throw a(Invoke);
                }
            } catch (IllegalAccessException unused4) {
                throw a(Invoke);
            }
        } catch (IllegalAccessException e3) {
        } catch (NoSuchMethodException e4) {
        } catch (InvocationTargetException e5) {
        }
        return z;
    }

    private static String[] Vulcan_q(Object[] objArr) {
        List list = (List) objArr[0];
        return (String[]) list.toArray(new String[list.size()]);
    }

    private static ArrayList Vulcan_Q(Object[] objArr) {
        ArrayList arrayList;
        synchronized (Vulcan_g) {
            arrayList = new ArrayList(Arrays.asList(Vulcan_u));
        }
        return arrayList;
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: all -> 0x0053]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: all -> 0x0053]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Throwable Vulcan_y(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 57590920695727(0x3460ee5ecfaf, double:2.84536954281264E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.Object r0 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_g
            r1 = r0
            r15 = r1
            monitor-enter(r0)
            r0 = r10
            r1 = r13
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_u     // Catch: java.lang.Throwable -> L53
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.Throwable -> L53
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.Throwable -> L53
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.Throwable -> L53
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.Throwable -> L53
            r3[r4] = r5     // Catch: java.lang.Throwable -> L53
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.Throwable -> L53
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.Throwable -> L53
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.Throwable -> L53
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.Throwable -> L53
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.Throwable -> L53
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L53
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.Throwable -> L53
            r2[r3] = r4     // Catch: java.lang.Throwable -> L53
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.Throwable -> L53
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.Throwable -> L53
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.Throwable -> L53
            r1[r2] = r3     // Catch: java.lang.Throwable -> L53
            java.lang.Throwable r0 = Vulcan_j(r0)     // Catch: java.lang.Throwable -> L53
            r1 = r15
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L53
            return r0
        L53:
            r16 = move-exception
            r0 = r15
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L53
            r0 = r16
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_y(java.lang.Object[]):java.lang.Throwable");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Throwable Vulcan_j(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_j(java.lang.Object[]):java.lang.Throwable");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.Throwable Vulcan_b(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 122986488246622(0x6fdb05f1b15e, double:6.0763398745314E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r1 = r13
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.util.List r1 = m425Vulcan_w(r1)
            r16 = r1
            r15 = r0
            r0 = r16
            r1 = r15
            if (r1 != 0) goto L76
            int r0 = r0.size()     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L5a ac.vulcan.anticheat.Vulcan_kM -> L62
            r1 = 2
            if (r0 >= r1) goto L66
            goto L5e
        L5a:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L62
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L62
        L5e:
            r0 = 0
            goto L79
        L62:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L62
            throw r0
        L66:
            r0 = r16
            r1 = r16
            int r1 = r1.size()
            r2 = 1
            int r1 = r1 - r2
            java.lang.Object r0 = r0.get(r1)
        L76:
            java.lang.Throwable r0 = (java.lang.Throwable) r0
        L79:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_b(java.lang.Object[]):java.lang.Throwable");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static Throwable Vulcan_t(Object[] objArr) throws Exception {
        Object obj = (Throwable) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_J = Vulcan_k5.Vulcan_J();
        try {
            try {
                Vulcan_J = obj instanceof Vulcan_OV;
                ?? targetException = Vulcan_J;
                if (Vulcan_J == 0) {
                    if (Vulcan_J != 0) {
                        return ((Vulcan_OV) obj).getCause();
                    }
                    targetException = obj instanceof SQLException;
                }
                try {
                    if (jLongValue >= 0 && Vulcan_J == 0) {
                        if (targetException != 0) {
                            return ((SQLException) obj).getNextException();
                        }
                        targetException = obj;
                        if (Vulcan_J != 0) {
                            return targetException;
                        }
                        try {
                            targetException = targetException instanceof InvocationTargetException;
                        } catch (Vulcan_kM unused) {
                            throw a(targetException);
                        }
                    }
                    if (targetException != 0) {
                        try {
                            targetException = ((InvocationTargetException) obj).getTargetException();
                            return targetException;
                        } catch (Vulcan_kM unused2) {
                            throw a(targetException);
                        }
                    }
                    return null;
                } catch (Vulcan_kM unused3) {
                    throw a(targetException);
                }
            } catch (Vulcan_kM unused4) {
                throw a(Vulcan_J);
            }
        } catch (Vulcan_kM unused5) {
            throw a(Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    private static Throwable Vulcan_A(Object[] objArr) throws Exception {
        Throwable th = (Throwable) objArr[0];
        String str = (String) objArr[1];
        String strVulcan_J = Vulcan_k5.Vulcan_J();
        Method method = null;
        try {
            Class<?> cls = th.getClass();
            method = cls.getMethod(me.frep.vulcan.spigot.Vulcan_m.b(str, cls, (Class[]) null), null);
        } catch (NoSuchMethodException e) {
        } catch (SecurityException e2) {
        }
        ?? r0 = method;
        try {
            try {
                if (r0 == 0) {
                    return null;
                }
                try {
                    r0 = Vulcan_a;
                    ?? r02 = r0;
                    if (strVulcan_J == null) {
                        if (r0 == 0) {
                            Class clsVulcan_Y = Vulcan_Y(new Object[]{b[17]});
                            Vulcan_a = clsVulcan_Y;
                            r02 = clsVulcan_Y;
                        } else {
                            r02 = Vulcan_a;
                        }
                    }
                    try {
                        if (r02.isAssignableFrom(method.getReturnType())) {
                            try {
                                r02 = (Throwable) method.invoke(th, Vulcan_fX.Vulcan_c);
                                return r02;
                            } catch (IllegalAccessException e3) {
                                return null;
                            } catch (IllegalArgumentException e4) {
                                return null;
                            } catch (InvocationTargetException e5) {
                                return null;
                            }
                        }
                        return null;
                    } catch (NoSuchMethodException unused) {
                        throw a(r02);
                    }
                } catch (NoSuchMethodException unused2) {
                    throw a(r0);
                }
            } catch (NoSuchMethodException unused3) {
                throw a(r0);
            }
        } catch (NoSuchMethodException unused4) {
            throw a(r0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    private static Throwable Vulcan_W(Object[] objArr) throws Exception {
        Throwable th = (Throwable) objArr[0];
        String str = (String) objArr[1];
        String strVulcan_J = Vulcan_k5.Vulcan_J();
        Field field = null;
        try {
            Class<?> cls = th.getClass();
            field = cls.getField(me.frep.vulcan.spigot.Vulcan_m.c(cls, str));
        } catch (NoSuchFieldException e) {
        } catch (SecurityException e2) {
        }
        ?? r0 = field;
        try {
            try {
                if (r0 == 0) {
                    return null;
                }
                try {
                    r0 = Vulcan_a;
                    ?? r02 = r0;
                    if (strVulcan_J == null) {
                        if (r0 == 0) {
                            Class clsVulcan_Y = Vulcan_Y(new Object[]{b[17]});
                            Vulcan_a = clsVulcan_Y;
                            r02 = clsVulcan_Y;
                        } else {
                            r02 = Vulcan_a;
                        }
                    }
                    try {
                        if (r02.isAssignableFrom(field.getType())) {
                            try {
                                r02 = (Throwable) field.get(th);
                                return r02;
                            } catch (IllegalAccessException e3) {
                                return null;
                            } catch (IllegalArgumentException e4) {
                                return null;
                            }
                        }
                        return null;
                    } catch (NoSuchFieldException unused) {
                        throw a(r02);
                    }
                } catch (NoSuchFieldException unused2) {
                    throw a(r0);
                }
            } catch (NoSuchFieldException unused3) {
                throw a(r0);
            }
        } catch (NoSuchFieldException unused4) {
            throw a(r0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.reflect.Method] */
    public static boolean Vulcan_X(Object[] objArr) throws Exception {
        ?? LongValue = a ^ ((Long) objArr[0]).longValue();
        try {
            LongValue = Vulcan_H;
            return LongValue != 0;
        } catch (Vulcan_kM unused) {
            throw a(LongValue);
        }
    }

    /* JADX WARN: Type inference failed for: r1v11, types: [java.lang.Exception, java.util.ArrayList, java.util.List] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x008d -> B:15:0x0056). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x007b: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x007b: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public static java.util.List m425Vulcan_w(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 37144639583054(0x21c8690c334e, double:1.8351890345142E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            java.util.ArrayList r1 = new java.util.ArrayList
            r2 = r1
            r2.<init>()
            r16 = r1
            r15 = r0
        L30:
            r0 = r12
            if (r0 == 0) goto L8a
            r0 = r16
            r1 = r15
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L43
            if (r1 != 0) goto L92
            r1 = r15
        L43:
            if (r1 != 0) goto L92
            goto L4d
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L59
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L59
        L4d:
            r1 = r12
            boolean r0 = r0.contains(r1)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L59
            if (r0 != 0) goto L8a
        L56:
            goto L5d
        L59:
            java.lang.Exception r0 = a(r0)
            throw r0
        L5d:
            r0 = r16
            r1 = r12
            boolean r0 = r0.add(r1)
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Throwable r0 = Vulcan_y(r0)
            r12 = r0
            r0 = r15
            if (r0 == 0) goto L30
        L8a:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L56
            r0 = r16
        L92:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m425Vulcan_w(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan__(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 51924745592314(0x2f39ac041dfa, double:2.5654232966209E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            r1 = r12
            r2 = r16
            r3 = 0
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan__(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_e(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 1460225472066(0x153fc387642, double:7.2144724093E-312)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r14
            r1 = r16
            r2 = r17
            r3 = r15
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_e(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x005d: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x005d: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public static int m426Vulcan_X(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 31418144024861(0x1c931b50691d, double:1.55226256187763E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r12
            r1 = r15
            r2 = r16
            r3 = 0
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m426Vulcan_X(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v9 ??, still in use, count: 2, list:
          (r5v9 ?? I:??[OBJECT, ARRAY][]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
          (r5v9 ?? I:??[OBJECT, ARRAY]) from 0x0069: APUT (r5v9 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_F(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 63377271489956(0x39a42bc105a4, double:3.1312532570341E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            r1 = r16
            r2 = r17
            r3 = r15
            r4 = 1
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_F(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.io.PrintStream] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0062: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0062: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public static void m428Vulcan_z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.io.PrintStream r1 = (java.io.PrintStream) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 38979733984412(0x2373ad32949c, double:1.92585474457285E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r16 = r0
            r0 = r11
            if (r0 != 0) goto L37
            return
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L33
            throw r0
        L37:
            r0 = r10
            if (r0 != 0) goto L4d
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kB.b     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
            r3 = 13
            r2 = r2[r3]     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
            r1.<init>(r2)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L49
            throw r0
        L4d:
            r0 = r11
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m429Vulcan_Q(r0)
            r17 = r0
            r0 = 0
            r18 = r0
        L70:
            r0 = r18
            r1 = r17
            int r1 = r1.length
            if (r0 >= r1) goto La1
            r0 = r10
            r1 = r17
            r2 = r18
            r1 = r1[r2]     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L9d
            r0.println(r1)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L9d
            int r18 = r18 + 1
        L84:
            r0 = r16
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L91
            if (r0 != 0) goto La5
            r0 = r16
        L91:
            if (r0 == 0) goto L70
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L84
            goto La1
        L9d:
            java.lang.Exception r0 = a(r0)
            throw r0
        La1:
            r0 = r10
            r0.flush()
        La5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m428Vulcan_z(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.io.PrintWriter] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_L(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.io.PrintWriter r1 = (java.io.PrintWriter) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 116781448498455(0x6a364cc10d17, double:5.76977017746654E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r16 = r0
            r0 = r13
            if (r0 != 0) goto L39
            return
        L35:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L35
            throw r0
        L39:
            r0 = r10
            if (r0 != 0) goto L4f
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kB.b     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
            r3 = 10
            r2 = r2[r3]     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
            r1.<init>(r2)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
        L4b:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L4b
            throw r0
        L4f:
            r0 = r13
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m429Vulcan_Q(r0)
            r17 = r0
            r0 = 0
            r18 = r0
        L73:
            r0 = r18
            r1 = r17
            int r1 = r1.length
            if (r0 >= r1) goto La4
            r0 = r10
            r1 = r17
            r2 = r18
            r1 = r1[r2]     // Catch: ac.vulcan.anticheat.Vulcan_kM -> La0
            r0.println(r1)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> La0
            int r18 = r18 + 1
        L87:
            r0 = r16
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L94
            if (r0 != 0) goto La8
            r0 = r16
        L94:
            if (r0 == 0) goto L73
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L87
            goto La4
        La0:
            java.lang.Exception r0 = a(r0)
            throw r0
        La4:
            r0 = r10
            r0.flush()
        La8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_L(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:26:0x0078, B:41:0x00ca], limit reached: 48 */
    /* JADX WARN: Path cross not found for [B:41:0x00ca, B:24:0x0073], limit reached: 48 */
    /* JADX WARN: Path cross not found for [B:41:0x00ca, B:26:0x0078], limit reached: 48 */
    /* JADX WARN: Removed duplicated region for block: B:29:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00d0 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:? A[LOOP:0: B:22:0x006e->B:51:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v29, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.List] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:42:0x00cd -> B:26:0x0078). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void m430Vulcan_O(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 209
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m430Vulcan_O(java.lang.Object[]):void");
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public static String m432Vulcan_v(Object[] objArr) {
        Throwable th = (Throwable) objArr[0];
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter((Writer) stringWriter, true));
        return stringWriter.getBuffer().toString();
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception, java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v2 ??, still in use, count: 2, list:
          (r4v2 ?? I:??[OBJECT, ARRAY][]) from 0x0060: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY])
          (r4v2 ?? I:??[OBJECT, ARRAY]) from 0x0060: APUT (r4v2 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v2 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String[] Vulcan_m(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 101758930107162(0x5c8c98e1bb1a, double:5.02755915235093E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r15 = r0
            r0 = r12
            r1 = r15
            if (r1 != 0) goto L40
            if (r0 != 0) goto L3f
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L3b
            throw r0     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L3b
        L37:
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_X     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L3b
            return r0
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kM -> L3b
            throw r0
        L3f:
            r0 = r12
        L40:
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = m432Vulcan_v(r0)
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = Vulcan_C(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_m(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v12, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v13 */
    static String[] Vulcan_C(Object[] objArr) throws Exception {
        ?? r0;
        String str = (String) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_J = Vulcan_k5.Vulcan_J();
        StringTokenizer stringTokenizer = new StringTokenizer(str, Vulcan_fg.Vulcan_F);
        ArrayList arrayList = new ArrayList();
        loop0: while (stringTokenizer.hasMoreTokens()) {
            do {
                r0 = arrayList;
                String strNextToken = strVulcan_J;
                if (jLongValue > 0) {
                    if (strNextToken != null) {
                        break loop0;
                    }
                    try {
                        strNextToken = stringTokenizer.nextToken();
                    } catch (Vulcan_kM unused) {
                        throw a(r0);
                    }
                }
                r0.add(strNextToken);
                r0 = strVulcan_J;
                if (r0 != 0) {
                }
            } while (jLongValue <= 0);
        }
        r0 = arrayList;
        return Vulcan_q(new Object[]{r0});
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    static java.util.List Vulcan_T(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.Vulcan_T(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public static java.lang.String m433Vulcan_O(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kB.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 49979486827850(0x2d74c18ef54a, double:2.4693147438416E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 107441183191508(0x61b7998ef1d4, double:5.308299756346E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r1 = r13
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Throwable r1 = Vulcan_b(r1)
            r18 = r1
            r17 = r0
            r0 = r18
            r1 = r17
            if (r1 != 0) goto L60
            if (r0 != 0) goto L63
            goto L5f
        L5b:
            java.lang.Exception r0 = a(r0)
            throw r0
        L5f:
            r0 = r12
        L60:
            goto L65
        L63:
            r0 = r18
        L65:
            r18 = r0
            r0 = r18
            r1 = r15
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_D(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kB.m433Vulcan_O(java.lang.Object[]):java.lang.String");
    }
}
