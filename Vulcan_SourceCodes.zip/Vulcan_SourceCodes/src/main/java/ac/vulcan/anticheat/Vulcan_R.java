package ac.vulcan.anticheat;

import java.util.TreeMap;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_R.class */
class Vulcan_R extends AbstractC0032Vulcan_p {
    public Vulcan_R() {
        super(new TreeMap(), new TreeMap());
    }
}
