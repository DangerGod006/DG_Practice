package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kz.class */
public class Vulcan_kz extends Vulcan_k5 {
    private static final long serialVersionUID = 20091223;

    public Vulcan_kz(String str) {
        super(str);
    }

    public Vulcan_kz(Throwable th) {
        super(th);
    }

    public Vulcan_kz(String str, Throwable th) {
        super(str, th);
    }
}
