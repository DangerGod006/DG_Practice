package ac.vulcan.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OL.class */
public class Vulcan_OL implements Vulcan_H {
    final Plugin Vulcan_H;
    private static String[] Vulcan_Z;

    public static void Vulcan_Q(String[] strArr) {
        Vulcan_Z = strArr;
    }

    public static String[] Vulcan_b() {
        return Vulcan_Z;
    }

    static {
        if (Vulcan_b() == null) {
            Vulcan_Q(new String[3]);
        }
    }

    public Vulcan_OL(Plugin plugin) {
        this.Vulcan_H = plugin;
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_d(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_D(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_V(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_C(Object[] objArr) {
        return new Vulcan_O_(Bukkit.getScheduler().runTask(this.Vulcan_H, (Runnable) objArr[0]));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_o(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskLater(this.Vulcan_H, (Runnable) objArr[1], ((Long) objArr[2]).longValue()));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_w(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long jLongValue2 = ((Long) objArr[2]).longValue();
        ((Long) objArr[3]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskTimer(this.Vulcan_H, runnable, jLongValue, jLongValue2));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_E(Object[] objArr) {
        return new Vulcan_O_(Bukkit.getScheduler().runTaskAsynchronously(this.Vulcan_H, (Runnable) objArr[0]));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_n(Object[] objArr) {
        Runnable runnable = (Runnable) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        ((Long) objArr[2]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskLaterAsynchronously(this.Vulcan_H, runnable, jLongValue));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_H(Object[] objArr) {
        return new Vulcan_O_(Bukkit.getScheduler().runTaskTimerAsynchronously(this.Vulcan_H, (Runnable) objArr[0], ((Long) objArr[1]).longValue(), ((Long) objArr[2]).longValue()));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_e(Object[] objArr) {
        return new Vulcan_O_(Bukkit.getScheduler().runTask((Plugin) objArr[0], (Runnable) objArr[1]));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_W(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        ((Long) objArr[3]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskLater(plugin, runnable, jLongValue));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_d */
    public Vulcan_t mo28Vulcan_d(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        ((Long) objArr[1]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskTimer(plugin, (Runnable) objArr[2], ((Long) objArr[3]).longValue(), ((Long) objArr[4]).longValue()));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_T(Object[] objArr) {
        return new Vulcan_O_(Bukkit.getScheduler().runTaskAsynchronously((Plugin) objArr[0], (Runnable) objArr[1]));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_O(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        ((Long) objArr[3]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, runnable, jLongValue));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public Vulcan_t Vulcan_q(Object[] objArr) {
        Plugin plugin = (Plugin) objArr[0];
        Runnable runnable = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        long jLongValue2 = ((Long) objArr[3]).longValue();
        ((Long) objArr[4]).longValue();
        return new Vulcan_O_(Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, runnable, jLongValue, jLongValue2));
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public void Vulcan_F(Object[] objArr) {
        Bukkit.getScheduler().scheduleSyncDelayedTask(this.Vulcan_H, (Runnable) objArr[0]);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    public void Vulcan_Q(Object[] objArr) {
        Bukkit.getScheduler().cancelTasks(this.Vulcan_H);
    }

    @Override // ac.vulcan.anticheat.Vulcan_H
    /* JADX INFO: renamed from: Vulcan_V */
    public void mo32Vulcan_V(Object[] objArr) {
        Bukkit.getScheduler().cancelTasks((Plugin) objArr[0]);
    }
}
