package ac.vulcan.anticheat;

import java.io.Reader;
import java.io.Writer;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_P.class */
public class Vulcan_P implements Cloneable {
    static final int Vulcan_h = 32;
    private static final long serialVersionUID = 7628716375283629643L;
    protected char[] Vulcan_b;
    protected int Vulcan_f;
    private String Vulcan_G;
    private String Vulcan_S;
    private static int Vulcan_y;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-1163423320147574098L, -5539931667134287357L, null).a(106478063085016L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00f8: INVOKE (r-1 I:ac.vulcan.anticheat.Vulcan_P), (r0 I:java.lang.Object[]) DIRECT call: ac.vulcan.anticheat.Vulcan_P.Vulcan_k(java.lang.Object[]):void
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_S(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 253
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_S(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    public static void Vulcan_W(int i) {
        Vulcan_y = i;
    }

    public static int Vulcan_m() {
        return Vulcan_y;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_W() {
        return Vulcan_m() == 0 ? 105 : 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x008c, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008f, code lost:
    
        r11 = "\u001eG\u0017yO\u0005=\u000fH\u0001-\u000b\u001eG\u0017yO\u0005=\u000fH\u0001-".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0098, code lost:
    
        ac.vulcan.anticheat.Vulcan_P.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b0, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bf, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e4, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e9, code lost:
    
        r7 = 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ee, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00f3, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f8, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00fd, code lost:
    
        r7 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0102, code lost:
    
        r7 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0104, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x010c, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0114, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0119, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x011d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x012c, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00a0, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00b0, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b3, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b7, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00bf, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e4, code lost:
    
        r7 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0104, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x010c, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010f, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e9, code lost:
    
        r7 = 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ee, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f3, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f8, code lost:
    
        r7 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00fd, code lost:
    
        r7 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0102, code lost:
    
        r7 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0114, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0119, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011d, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0051, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x005d, code lost:
    
        r2 = "\u001eG\u0017yO\u0005=\u000fH\u0001-\u000b\u001eG\u0017yO\u0005=\u000fH\u0001-".length();
        r11 = 11;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x006c, code lost:
    
        r10 = r10 + 1;
        "\u001eG\u0017yO\u0005=\u000fH\u0001-\u000b\u001eG\u0017yO\u0005=\u000fH\u0001-".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x007c, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b3, B:28:0x0114], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0119 -> B:15:0x00b3). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0119 -> B:34:0x00b3). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 301
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m112clinit():void");
    }

    private static StringIndexOutOfBoundsException a(StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
        return stringIndexOutOfBoundsException;
    }

    public Vulcan_P() {
        this(Vulcan_h);
    }

    public Vulcan_P(int i) {
        long j = a ^ 67900747402998L;
        this.Vulcan_b = new char[i <= 0 ? Vulcan_h : i];
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x006d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x006d: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public Vulcan_P(java.lang.String r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = 114896674365279(0x687f77761f5f, double:5.6766499625293E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 134176327168726(0x7a085c5172d6, double:6.6291913739223E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int r0 = Vulcan_W()
            r1 = r9
            r1.<init>()
            r15 = r0
            r0 = r15
            if (r0 == 0) goto L52
            r0 = r10
            if (r0 != 0) goto L3e
            goto L2a
        L26:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L3a
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L3a
        L2a:
            r0 = r9
            r1 = 32
            char[] r1 = new char[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L3a java.lang.StringIndexOutOfBoundsException -> L4e
            r0.Vulcan_b = r1     // Catch: java.lang.StringIndexOutOfBoundsException -> L3a java.lang.StringIndexOutOfBoundsException -> L4e
            r0 = r15
            if (r0 != 0) goto L72
            goto L3e
        L3a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4e
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L4e
        L3e:
            r0 = r9
            r1 = r10
            int r1 = r1.length()     // Catch: java.lang.StringIndexOutOfBoundsException -> L4e
            r2 = 32
            int r1 = r1 + r2
            char[] r1 = new char[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L4e
            r0.Vulcan_b = r1     // Catch: java.lang.StringIndexOutOfBoundsException -> L4e
            goto L52
        L4e:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L52:
            r0 = r9
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
        L72:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.<init>(java.lang.String):void");
    }

    public String Vulcan_E(Object[] objArr) {
        return this.Vulcan_G;
    }

    public Vulcan_P Vulcan_jq(Object[] objArr) {
        this.Vulcan_G = (String) objArr[0];
        return this;
    }

    public String Vulcan_f(Object[] objArr) {
        return this.Vulcan_S;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public Vulcan_P Vulcan_D(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_m = Vulcan_m();
        try {
            if (Vulcan_m == 0) {
                if (str != null && str.length() == 0) {
                    str = null;
                }
                this.Vulcan_S = str;
            }
            return this;
        } catch (StringIndexOutOfBoundsException unused) {
            throw a(Vulcan_m);
        }
    }

    public int Vulcan_e(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 7, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x002b: MOVE (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:198)
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0077: MOVE (r0v34 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:203)
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x004a: MOVE (r0v37 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) (LINE:201)
          (r1v3 ?? I:int) from 0x0068: IPUT (r1v3 ?? I:int), (r10v0 'this' ?? I:ac.vulcan.anticheat.Vulcan_P A[IMMUTABLE_TYPE, THIS]) A[Catch: StringIndexOutOfBoundsException -> 0x0073, StringIndexOutOfBoundsException -> 0x0081] (LINE:202) ac.vulcan.anticheat.Vulcan_P.Vulcan_f int
          (r1v3 ?? I:int) from 0x00d0: IPUT (r1v3 ?? I:int), (r10v0 'this' ?? I:ac.vulcan.anticheat.Vulcan_P A[IMMUTABLE_TYPE, THIS]) (LINE:207) ac.vulcan.anticheat.Vulcan_P.Vulcan_f int
          (r1v3 ?? I:??[int, byte, short, char]) from 0x00db: IF  (r0v23 ?? I:??[int, byte, short, char]) >= (r1v3 ?? I:??[int, byte, short, char])  -> B:64:0x0106 (LINE:206)
          (r1v3 ?? I:int) from 0x0042: CONSTRUCTOR (r0v38 ?? I:java.lang.StringIndexOutOfBoundsException) = (r1v3 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x0046, MD:(int):void (c)] (LINE:199) call: java.lang.StringIndexOutOfBoundsException.<init>(int):void type: CONSTRUCTOR
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_u(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 7, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x002b: MOVE (r0v6 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:198)
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0077: MOVE (r0v34 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:203)
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x004a: MOVE (r0v37 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) (LINE:201)
          (r1v3 ?? I:int) from 0x0068: IPUT (r1v3 ?? I:int), (r10v0 'this' ?? I:ac.vulcan.anticheat.Vulcan_P A[IMMUTABLE_TYPE, THIS]) A[Catch: StringIndexOutOfBoundsException -> 0x0073, StringIndexOutOfBoundsException -> 0x0081] (LINE:202) ac.vulcan.anticheat.Vulcan_P.Vulcan_f int
          (r1v3 ?? I:int) from 0x00d0: IPUT (r1v3 ?? I:int), (r10v0 'this' ?? I:ac.vulcan.anticheat.Vulcan_P A[IMMUTABLE_TYPE, THIS]) (LINE:207) ac.vulcan.anticheat.Vulcan_P.Vulcan_f int
          (r1v3 ?? I:??[int, byte, short, char]) from 0x00db: IF  (r0v23 ?? I:??[int, byte, short, char]) >= (r1v3 ?? I:??[int, byte, short, char])  -> B:64:0x0106 (LINE:206)
          (r1v3 ?? I:int) from 0x0042: CONSTRUCTOR (r0v38 ?? I:java.lang.StringIndexOutOfBoundsException) = (r1v3 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x0046, MD:(int):void (c)] (LINE:199) call: java.lang.StringIndexOutOfBoundsException.<init>(int):void type: CONSTRUCTOR
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    public int Vulcan_Q(Object[] objArr) {
        return this.Vulcan_b.length;
    }

    public Vulcan_P Vulcan_eZ(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        if (iIntValue > this.Vulcan_b.length) {
            char[] cArr = this.Vulcan_b;
            this.Vulcan_b = new char[iIntValue * 2];
            System.arraycopy(cArr, 0, this.Vulcan_b, 0, this.Vulcan_f);
        }
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    public Vulcan_P Vulcan_n(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        StringIndexOutOfBoundsException length = this;
        if (Vulcan_W() == 0) {
            return length;
        }
        try {
            length = length.Vulcan_b.length;
            if (length > Vulcan_e(new Object[0])) {
                char[] cArr = this.Vulcan_b;
                this.Vulcan_b = new char[Vulcan_e(new Object[0])];
                System.arraycopy(cArr, 0, this.Vulcan_b, 0, this.Vulcan_f);
            }
            return this;
        } catch (StringIndexOutOfBoundsException unused) {
            throw a(length);
        }
    }

    public int Vulcan_M(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean, int] */
    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public boolean m113Vulcan_n(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        StringIndexOutOfBoundsException stringIndexOutOfBoundsExceptionVulcan_W = Vulcan_W();
        try {
            stringIndexOutOfBoundsExceptionVulcan_W = this.Vulcan_f;
            return stringIndexOutOfBoundsExceptionVulcan_W != 0 ? stringIndexOutOfBoundsExceptionVulcan_W == 0 : stringIndexOutOfBoundsExceptionVulcan_W;
        } catch (StringIndexOutOfBoundsException unused) {
            throw a(stringIndexOutOfBoundsExceptionVulcan_W);
        }
    }

    public Vulcan_P Vulcan_q(Object[] objArr) {
        this.Vulcan_f = 0;
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x003a  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v7, types: [char, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public char Vulcan_B(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_W()
            r12 = r0
            r0 = r9
            r1 = r12
            if (r1 == 0) goto L32
            if (r0 < 0) goto L4f
            goto L31
        L2d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L31:
            r0 = r9
        L32:
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L45
            if (r1 == 0) goto L62
            r1 = r7
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b java.lang.StringIndexOutOfBoundsException -> L58
            int r1 = r1.Vulcan_e(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b java.lang.StringIndexOutOfBoundsException -> L58
        L45:
            if (r0 < r1) goto L5c
            goto L4f
        L4b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
        L4f:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r1 = r0
            r2 = r9
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
        L58:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            throw r0
        L5c:
            r0 = r7
            char[] r0 = r0.Vulcan_b
            r1 = r9
            char r0 = r0[r1]
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_B(java.lang.Object[]):char");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0057  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_lq(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_W()
            r11 = r0
            r0 = r7
            r1 = r11
            if (r1 == 0) goto L3f
            if (r0 < 0) goto L4a
            goto L3e
        L3a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L3e:
            r0 = r7
        L3f:
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
            int r1 = r1.Vulcan_e(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
            if (r0 < r1) goto L57
        L4a:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
            r1 = r0
            r2 = r7
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
        L53:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L53
            throw r0
        L57:
            r0 = r5
            char[] r0 = r0.Vulcan_b
            r1 = r7
            r2 = r8
            r0[r1] = r2
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_lq(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004a  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_eN(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = Vulcan_W()
            r14 = r0
            r0 = r13
            r1 = r14
            if (r1 == 0) goto L35
            if (r0 < 0) goto L3c
            goto L33
        L2f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L33:
            r0 = r13
        L35:
            r1 = r9
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            if (r0 < r1) goto L4a
        L3c:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            r1 = r0
            r2 = r13
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
        L46:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            throw r0
        L4a:
            r0 = r9
            r1 = r13
            r2 = r13
            r3 = 1
            int r2 = r2 + r3
            r3 = 1
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.m122Vulcan_X(r1)
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_eN(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public char[] Vulcan_x(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        StringIndexOutOfBoundsException stringIndexOutOfBoundsExceptionVulcan_W = Vulcan_W();
        try {
            try {
                stringIndexOutOfBoundsExceptionVulcan_W = this.Vulcan_f;
                int i = stringIndexOutOfBoundsExceptionVulcan_W;
                if (stringIndexOutOfBoundsExceptionVulcan_W != 0) {
                    if (stringIndexOutOfBoundsExceptionVulcan_W == 0) {
                        return Vulcan_fX.Vulcan_w;
                    }
                    i = this.Vulcan_f;
                }
                char[] cArr = new char[i];
                System.arraycopy(this.Vulcan_b, 0, cArr, 0, this.Vulcan_f);
                return cArr;
            } catch (StringIndexOutOfBoundsException unused) {
                throw a(stringIndexOutOfBoundsExceptionVulcan_W);
            }
        } catch (StringIndexOutOfBoundsException unused2) {
            throw a(stringIndexOutOfBoundsExceptionVulcan_W);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v6, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public char[] Vulcan_v(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 86884397433054(0x4f0559a540de, double:4.29265959312894E-310)
            long r1 = r1 ^ r2
            r18 = r1
            int r0 = Vulcan_W()
            r1 = r12
            r2 = r15
            r3 = r14
            r4 = r18
            r5 = 3
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 2
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            int r1 = r1.m154Vulcan_I(r2)
            r14 = r1
            r20 = r0
            r0 = r14
            r1 = r15
            int r0 = r0 - r1
            r21 = r0
            r0 = r21
            r1 = r20
            if (r1 == 0) goto L8e
            if (r0 != 0) goto L8c
            goto L84
        L80:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L88
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L88
        L84:
            char[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_w     // Catch: java.lang.StringIndexOutOfBoundsException -> L88
            return r0
        L88:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L88
            throw r0
        L8c:
            r0 = r21
        L8e:
            char[] r0 = new char[r0]
            r22 = r0
            r0 = r12
            char[] r0 = r0.Vulcan_b
            r1 = r15
            r2 = r22
            r3 = 0
            r4 = r21
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r22
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_v(java.lang.Object[]):char[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public char[] m114Vulcan_q(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_m()
            r1 = r6
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            int r1 = r1.Vulcan_e(r2)
            r12 = r1
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L63
            if (r0 == 0) goto L58
            goto L38
        L34:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L41
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L41
        L38:
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L71
            goto L45
        L41:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
        L45:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L68
            int r0 = r0.length     // Catch: java.lang.StringIndexOutOfBoundsException -> L54 java.lang.StringIndexOutOfBoundsException -> L5f
            r1 = r12
            if (r0 >= r1) goto L64
            goto L58
        L54:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
        L58:
            r0 = r12
            char[] r0 = new char[r0]     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            goto L63
        L5f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L63:
            r8 = r0
        L64:
            r0 = r6
            char[] r0 = r0.Vulcan_b
        L68:
            r1 = 0
            r2 = r8
            r3 = 0
            r4 = r12
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r8
        L71:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m114Vulcan_q(java.lang.Object[]):char[]");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x004d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_G(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = Vulcan_W()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 == 0) goto L5f
            if (r0 >= 0) goto L5e
            goto L51
        L4d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
        L51:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
            r1 = r0
            r2 = r9
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
        L5a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5a
            throw r0
        L5e:
            r0 = r10
        L5f:
            r1 = r15
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L7e
            if (r1 == 0) goto L76
            if (r0 < 0) goto L94
            goto L75
        L71:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L75:
            r0 = r10
        L76:
            r1 = r7
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L90
            int r1 = r1.Vulcan_e(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L90
        L7e:
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto La3
            r2 = r15
            if (r2 == 0) goto La3
            if (r0 <= r1) goto La1
            goto L94
        L90:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
        L94:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
            r1 = r0
            r2 = r10
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
        L9d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L9d
            throw r0
        La1:
            r0 = r9
            r1 = r10
        La3:
            if (r0 <= r1) goto Lb8
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_P.b     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
            r3 = 9
            r2 = r2[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
        Lb4:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb4
            throw r0
        Lb8:
            r0 = r7
            char[] r0 = r0.Vulcan_b
            r1 = r9
            r2 = r14
            r3 = r13
            r4 = r10
            r5 = r9
            int r4 = r4 - r5
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_G(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r3v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v13 ??, still in use, count: 2, list:
          (r4v13 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r4v13 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v13 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0057]
          (r4v13 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r4v13 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v13 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0057]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_wE(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 45075125139341(0x28feded2778d, double:2.22700708133435E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int r0 = Vulcan_m()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 != 0) goto L7f
            java.lang.String r0 = r0.Vulcan_G     // Catch: java.lang.StringIndexOutOfBoundsException -> L2f java.lang.StringIndexOutOfBoundsException -> L57
            if (r0 != 0) goto L5b
            goto L33
        L2f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
        L33:
            r0 = r9
            r1 = r13
            java.lang.String r2 = ac.vulcan.anticheat.Vulcan_fg.Vulcan_F     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            r0 = r9
            return r0
        L57:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L57
            throw r0
        L5b:
            r0 = r9
            r1 = r9
            java.lang.String r1 = r1.Vulcan_G
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_wE(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_wI(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 28664007119995(0x1a11dbf6547b, double:1.41619011901384E-310)
            long r1 = r1 ^ r2
            r13 = r1
            int r0 = Vulcan_W()
            r15 = r0
            r0 = r9
            r1 = r15
            if (r1 == 0) goto L5d
            java.lang.String r0 = r0.Vulcan_S     // Catch: java.lang.StringIndexOutOfBoundsException -> L2f java.lang.StringIndexOutOfBoundsException -> L35
            if (r0 != 0) goto L39
            goto L33
        L2f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
        L33:
            r0 = r9
            return r0
        L35:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
            throw r0
        L39:
            r0 = r9
            r1 = r9
            java.lang.String r1 = r1.Vulcan_S
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
        L5d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_wI(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r2v6, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v7, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v10 ??, still in use, count: 2, list:
          (r4v10 ?? I:??[OBJECT, ARRAY][]) from 0x006e: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
          (r4v10 ?? I:??[OBJECT, ARRAY]) from 0x006e: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m115Vulcan_v(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 73708272819205(0x43098b6b1c05, double:3.64167254142633E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 130471725288770(0x76a9d0d6cd42, double:6.4461597218818E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            if (r0 != 0) goto L4d
            r0 = r9
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wI(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            return r0
        L49:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L49
            throw r0
        L4d:
            r0 = r9
            r1 = r13
            java.lang.String r1 = r1.toString()
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m115Vulcan_v(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_i(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 206
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_i(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:60:0x0108
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_O9(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 355
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_O9(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_sp(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_sp(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:60:0x0108
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_AS(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 360
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_AS(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_se(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_se(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:64:0x0126
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m116Vulcan_x(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 455
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m116Vulcan_x(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_b6(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 136035524932580(0x7bb93d23f3e4, double:6.7210479483168E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 47882270803723(0x2b8c75be070b, double:2.3656985048987E-310)
            long r1 = r1 ^ r2
            r17 = r1
            int r0 = Vulcan_m()
            r19 = r0
            r0 = r12
            r1 = r19
            if (r1 != 0) goto L5d
            if (r0 != 0) goto L5c
            goto L3e
        L3a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
        L3e:
            r0 = r10
            r1 = r17
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wI(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            return r0
        L58:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L58
            throw r0
        L5c:
            r0 = r12
        L5d:
            int r0 = r0.length
            r20 = r0
            r0 = r20
            r1 = r19
            if (r1 != 0) goto L80
            if (r0 <= 0) goto Lc6
            goto L71
        L6d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L7c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L7c
        L71:
            r0 = r10
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L7c
            int r0 = r0.Vulcan_e(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L7c
            goto L80
        L7c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L80:
            r21 = r0
            r0 = r10
            r1 = r21
            r2 = r20
            int r1 = r1 + r2
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_eZ(r1)
            r0 = r12
            r1 = 0
            r2 = r10
            char[] r2 = r2.Vulcan_b
            r3 = r21
            r4 = r20
            java.lang.System.arraycopy(r0, r1, r2, r3, r4)
            r0 = r10
            r1 = r0
            int r1 = r1.Vulcan_f
            r2 = r20
            int r1 = r1 + r2
            r0.Vulcan_f = r1
        Lc6:
            r0 = r10
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_b6(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:60:0x0127
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_K(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 388
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_K(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r3v20, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v3, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v10, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v10 ??, still in use, count: 2, list:
          (r5v10 ?? I:??[OBJECT, ARRAY][]) from 0x0055: APUT (r5v10 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v10 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00bd, StringIndexOutOfBoundsException -> 0x0139]
          (r5v10 ?? I:??[OBJECT, ARRAY]) from 0x0055: APUT (r5v10 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v10 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00bd, StringIndexOutOfBoundsException -> 0x0139]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_t(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 364
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_t(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_JA(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 91088411246257(0x52d82c653eb1, double:4.5003654731035E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            int r0 = r0.Vulcan_e(r1)
            r17 = r0
            r0 = r10
            r1 = r17
            r2 = 1
            int r1 = r1 + r2
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_eZ(r1)
            r0 = r10
            char[] r0 = r0.Vulcan_b
            r1 = r10
            r2 = r1
            int r2 = r2.Vulcan_f
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = 1
            int r3 = r3 + r4
            r2.Vulcan_f = r3
            r2 = r12
            r0[r1] = r2
            r0 = r10
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_JA(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_eq(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 23243578408295(0x1523d13bfd67, double:1.1483853577956E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = r11
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_eq(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_eR(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 36622833184660(0x214eeaf66f94, double:1.80940837299153E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r9
            r1 = r11
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_eR(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_c(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 57767284173712(0x3489fe73eb90, double:2.854083056378E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = r13
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_c(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Ia(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 5380113495974(0x4e4a7c0f7a6, double:2.6581292490876E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r9
            r1 = r11
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r15
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Ia(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_vj(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 85183873522007(0x4d796a859957, double:4.20864254869094E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 42392388170463(0x268e3f3cf2df, double:2.09446226401926E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r14
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m115Vulcan_v(r1)
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_vj(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m117Vulcan_M(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 129182439244498(0x757da16702d2, double:6.38246052766805E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 125563368829027(0x7232fffef063, double:6.2036546914516E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m117Vulcan_M(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_O(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 124655451160586(0x715f9be2c00a, double:6.1587975985287E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r1 = r0; r2 = r0; 
            r2 = 78267928465556(0x472f2c12d094, double:3.86694946259914E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r12
            r1 = r14
            r2 = r16
            r3 = r15
            r4 = r19
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_O9(r1)
            r1 = r21
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_O(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_sd(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 4427302855022(0x406cfd0616e, double:2.187378244401E-311)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 72638014897533(0x42105b133d7d, double:3.58879477429757E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r10
            r1 = r12
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_sp(r1)
            r1 = r17
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_sd(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Ak(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r18 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 83628524023806(0x4c0f4877affe, double:4.1317980732572E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r1 = r0; r2 = r0; 
            r2 = 113366617447452(0x671b38f65c1c, double:5.6010551066013E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r12
            r1 = r18
            r2 = r17
            r3 = r16
            r4 = r19
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_AS(r1)
            r1 = r21
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Ak(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_U(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_P r1 = (ac.vulcan.anticheat.Vulcan_P) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 69576768526861(0x3f479a929a0d, double:3.43754910777705E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 134746654077288(0x7a8d26737168, double:6.65736926716423E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_se(r1)
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_U(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_T(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_P r1 = (ac.vulcan.anticheat.Vulcan_P) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 60739574896108(0x373e08c915ec, double:3.00093372991684E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r1 = r0; r2 = r0; 
            r2 = 98339847096595(0x597087a74913, double:4.85863400677086E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r12
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r19
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m116Vulcan_x(r1)
            r1 = r21
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_T(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_b(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 14880277818631(0xd8895ac6d07, double:7.351834070759E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 65259435838662(0x3b5a657dccc6, double:3.2242445314864E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_b6(r1)
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_b(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0078: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0078: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_y(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 33463669689859(0x1e6f5e250e03, double:1.65332495775383E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r1 = r0; r2 = r0; 
            r2 = 204059279071(0x2f82e17edf, double:1.00818679504E-312)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r11
            r1 = r18
            r2 = r13
            r3 = r17
            r4 = r16
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_K(r1)
            r1 = r20
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m118Vulcan_f(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 12374969818895(0xb4145ae1f0f, double:6.1140474558383E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 119184435346866(0x6c65c9ee7db2, double:5.88849350238736E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r14
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_t(r1)
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m118Vulcan_f(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v14, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0069: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0069: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_J(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r0 = r13
            r1 = 8
            long r0 = r0 << r1
            r1 = r11
            long r1 = (long) r1
            r2 = 56
            long r1 = r1 << r2
            r2 = 56
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_P.a
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 36498897424638(0x21320fd0d0fe, double:1.8032851328597E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 68727769381994(0x3e81ee47bc6a, double:3.3956029766943E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r9
            r1 = r17
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)
            r1 = r19
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_J(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_L(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 117979912224447(0x6b4d56c23ebf, double:5.8289821529465E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 95177971315797(0x5690592bb455, double:4.7024165867999E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_eq(r1)
            r1 = r17
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_L(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m119Vulcan_e(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 15894769483125(0xe74ca16bd75, double:7.853059550178E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 8542659716460(0x7c4fe32a56c, double:4.220634690015E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r11
            r1 = r13
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_eR(r1)
            r1 = r19
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m119Vulcan_e(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_X(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 82723401104783(0x4b3c8aeffd8f, double:4.0870790593019E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 95982491427218(0x574baa4e6192, double:4.74216516164404E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_c(r1)
            r1 = r17
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_X(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [double, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_I(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 119631628118742(0x6ccde8b2aad6, double:5.9105877609526E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 71294605339389(0x40d791a02afd, double:3.5224215232002E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r11
            r1 = r15
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Double r4 = new java.lang.Double
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Ia(r1)
            r1 = r19
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_wE(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_I(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r17v0 */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2, types: [int] */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Type inference failed for: r17v5 */
    /* JADX WARN: Type inference failed for: r17v6 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0078: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0093]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0078: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0093]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_P(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 95287967360439(0x56a9f57225b7, double:4.7078511134835E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_W()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 == 0) goto L38
            if (r0 == 0) goto L97
            goto L37
        L33:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L37:
            r0 = r11
        L38:
            int r0 = r0.length     // Catch: java.lang.StringIndexOutOfBoundsException -> L44
            r1 = r16
            if (r1 == 0) goto L49
            if (r0 <= 0) goto L97
            goto L48
        L44:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L48:
            r0 = 0
        L49:
            r17 = r0
        L4b:
            r0 = r17
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L97
        L52:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L85
            r0 = r9
            r1 = r11
            r2 = r17
            r1 = r1[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m115Vulcan_v(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L93
            r1 = r16
            if (r1 == 0) goto L98
        L82:
            int r17 = r17 + 1
        L85:
            r0 = r16
            if (r0 != 0) goto L4b
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L52
            goto L97
        L93:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L97:
            r0 = r9
        L98:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_P(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r0v18, types: [int] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0092: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00aa]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0092: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00aa]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_s(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 100632229874943(0x5b8644508cff, double:4.97189276456085E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_m()
            r16 = r0
            r0 = r13
            r1 = r16
            if (r1 != 0) goto L3b
            if (r0 == 0) goto Lae
            goto L39
        L35:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L39:
            r0 = r13
        L3b:
            r1 = r16
            if (r1 != 0) goto L58
            int r0 = r0.size()     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b java.lang.StringIndexOutOfBoundsException -> L54
            if (r0 <= 0) goto Lae
            goto L4f
        L4b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
        L4f:
            r0 = r13
            goto L58
        L54:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L58:
            java.util.Iterator r0 = r0.iterator()
            r17 = r0
        L5f:
            r0 = r17
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto Lae
        L69:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L9c
            r0 = r9
            r1 = r17
            java.lang.Object r1 = r1.next()     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m115Vulcan_v(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> Laa
            r1 = r16
            if (r1 != 0) goto Laf
        L9c:
            r0 = r16
            if (r0 == 0) goto L5f
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L69
            goto Lae
        Laa:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lae:
            r0 = r9
        Laf:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_s(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0062: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x006e, StringIndexOutOfBoundsException -> 0x0081]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0062: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x006e, StringIndexOutOfBoundsException -> 0x0081]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_V(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Iterator r1 = (java.util.Iterator) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 23601208367439(0x157715a4194f, double:1.16605462546926E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_W()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 == 0) goto L38
            if (r0 == 0) goto L85
            goto L37
        L33:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L37:
            r0 = r11
        L38:
            boolean r0 = r0.hasNext()     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            if (r0 == 0) goto L85
            r0 = r9
            r1 = r11
            java.lang.Object r1 = r1.next()     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r2 = r14
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m115Vulcan_v(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e java.lang.StringIndexOutOfBoundsException -> L81
            r1 = r16
            if (r1 == 0) goto L86
            goto L72
        L6e:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L81
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L81
        L72:
            r0 = r16
            if (r0 != 0) goto L37
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L85
            goto L85
        L81:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L85:
            r0 = r9
        L86:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_V(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v23, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r3v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v21, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v22, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0090: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0090: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_d(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 265
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_d(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockSplitter
        jadx.core.utils.exceptions.JadxRuntimeException: Unexpected missing predecessor for block: B:31:0x00b6
        	at jadx.core.dex.visitors.blocks.BlockSplitter.addTempConnectionsForExcHandlers(BlockSplitter.java:280)
        	at jadx.core.dex.visitors.blocks.BlockSplitter.visit(BlockSplitter.java:79)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_z(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 265
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockSplitter
        jadx.core.utils.exceptions.JadxRuntimeException: Unexpected missing predecessor for block: B:24:0x0096
        	at jadx.core.dex.visitors.blocks.BlockSplitter.addTempConnectionsForExcHandlers(BlockSplitter.java:280)
        	at jadx.core.dex.visitors.blocks.BlockSplitter.visit(BlockSplitter.java:79)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_jx(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_jx(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x003e: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x003e: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_j(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 22400860025613(0x145f9b4df30d, double:1.1067495375954E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r12
            r2 = r15
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_dQ(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_j(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v3, types: [long] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r2v7, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v6, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0054]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0054]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_dQ(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 132851851665673(0x78d3fb6d2109, double:6.5637535894406E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 41308655665917(0x2591ebbf42fd, double:2.0409187640415E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r9
            r1 = r15
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            boolean r0 = r0.m113Vulcan_n(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            if (r0 == 0) goto L58
            r0 = r12
            goto L59
        L54:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L54
            throw r0
        L58:
            r0 = r11
        L59:
            r19 = r0
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L88
            r0 = r19
            if (r0 == 0) goto L8f
            r0 = r9
            r1 = r17
            r2 = r19
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8b
        L88:
            goto L8f
        L8b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L8f:
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_dQ(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0066: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x006e]
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0066: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x006e]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_h(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 129083160825041(0x756683f28cd1, double:6.37755552202534E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_m()
            r16 = r0
            r0 = r9
            r1 = r16
            if (r1 != 0) goto L73
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L3e java.lang.StringIndexOutOfBoundsException -> L6e
            int r0 = r0.Vulcan_M(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L3e java.lang.StringIndexOutOfBoundsException -> L6e
            if (r0 <= 0) goto L72
            goto L42
        L3e:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
        L42:
            r0 = r9
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L6e
            goto L72
        L6e:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L72:
            r0 = r9
        L73:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_h(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r3v11, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v15 ??, still in use, count: 2, list:
          (r4v15 ?? I:??[OBJECT, ARRAY][]) from 0x0079: APUT (r4v15 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v15 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x008d, StringIndexOutOfBoundsException -> 0x00bb]
          (r4v15 ?? I:??[OBJECT, ARRAY]) from 0x0079: APUT (r4v15 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v15 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x008d, StringIndexOutOfBoundsException -> 0x00bb]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_W(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 98370507913923(0x5977ab2e3ac3, double:4.8601488524224E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = Vulcan_m()
            r17 = r0
            r0 = r9
            r1 = r17
            if (r1 != 0) goto Lbf
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L52 java.lang.StringIndexOutOfBoundsException -> L8d
            r2 = r13
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto Lb5
            int r0 = r0.Vulcan_M(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L52 java.lang.StringIndexOutOfBoundsException -> L8d
            if (r0 <= 0) goto L91
            goto L56
        L52:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d
        L56:
            r0 = r9
            r1 = r15
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8d java.lang.StringIndexOutOfBoundsException -> Lbb
            r1 = r13
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lc1
        L85:
            r0 = r17
            if (r0 == 0) goto Lc0
            goto L91
        L8d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
        L91:
            r0 = r9
            r1 = r15
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
        Lb5:
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbb
            goto Lbf
        Lbb:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lbf:
        Lc0:
            r0 = r9
        Lc1:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_W(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.StringIndexOutOfBoundsException, long] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0063]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0063]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_N(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 20465344134608(0x129cf5913dd0, double:1.01112234672285E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 == 0) goto L67
            r0 = r13
            if (r0 <= 0) goto L67
            goto L3f
        L3b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
        L3f:
            r0 = r9
            r1 = r15
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L63
            goto L67
        L63:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L67:
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_N(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x005a: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0062]
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x005a: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0062]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m120Vulcan_Q(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 57412660373285(0x34376d3a2725, double:2.8365623126791E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r11
            if (r0 <= 0) goto L66
            r0 = r9
            r1 = r15
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            goto L66
        L62:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L66:
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m120Vulcan_Q(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r3v3, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0060: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0076]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0060: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0076]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m121Vulcan_G(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 58644576684897(0x355641294b61, double:2.897427065491E-310)
            long r1 = r1 ^ r2
            r16 = r1
            int r0 = Vulcan_m()
            r18 = r0
            r0 = r12
            r1 = r18
            if (r1 != 0) goto L7a
            if (r0 < 0) goto Lb4
            goto L45
        L41:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
        L45:
            r0 = r10
            r1 = r10
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r2 = r12
            int r1 = r1 + r2
            r2 = r16
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_eZ(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L76
            r0 = 0
            goto L7a
        L76:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L7a:
            r19 = r0
        L7c:
            r0 = r19
            r1 = r12
            if (r0 >= r1) goto Lb4
        L82:
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto La2
            r0 = r10
            r1 = r18
            if (r1 != 0) goto Lb5
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            r1 = r10
            r2 = r1
            int r2 = r2.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            r4 = 1
            int r3 = r3 + r4
            r2.Vulcan_f = r3     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            r2 = r15
            r0[r1] = r2     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            int r19 = r19 + 1
        La2:
            r0 = r18
            if (r0 == 0) goto L7c
            r0 = r13
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L82
            goto Lb4
        Lb0:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lb4:
            r0 = r10
        Lb5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m121Vulcan_G(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:17:0x0091
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Qp(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 357
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Qp(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_m(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 3536176243479(0x33754876317, double:1.747103199543E-311)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r17
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r13
            r3 = r18
            r4 = r16
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qp(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_m(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:17:0x0092
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_QK(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 357
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_QK(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Fn(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 129554172211192(0x75d42e69eff8, double:6.40082657649507E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r16
            java.lang.String r1 = java.lang.String.valueOf(r1)
            r2 = r13
            r3 = r18
            r4 = r17
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_QK(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Fn(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v15, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v23, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v23 ??, still in use, count: 2, list:
          (r4v23 ?? I:??[OBJECT, ARRAY][]) from 0x0097: APUT (r4v23 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v23 ?? I:??[OBJECT, ARRAY])
          (r4v23 ?? I:??[OBJECT, ARRAY]) from 0x0097: APUT (r4v23 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v23 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_YH(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 138510801197152(0x7df98f1a5860, double:6.84334284494594E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 != 0) goto L69
            r0 = r9
            r1 = r15
            r2 = r13
            r3 = r9
            java.lang.String r3 = r3.Vulcan_S     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4[r5] = r6     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            return r0
        L65:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L65
            throw r0
        L69:
            r0 = r9
            r1 = r15
            r2 = r13
            r3 = r14
            java.lang.String r3 = r3.toString()
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_YH(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Qo(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 274
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Qo(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0074
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Mt(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 302
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Mt(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 6, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0058: MOVE (r1v27 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0097: MOVE (r1v57 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v3 ?? I:int) from 0x01cc: INVOKE (r0v28 ?? I:java.lang.Object), (r1v3 ?? I:int), (r2v29 ?? I:java.lang.Object), (r3v22 ?? I:int), (r4v25 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[Catch: StringIndexOutOfBoundsException -> 0x01ec, MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)]
          (r1v3 ?? I:int) from 0x01c4: ARITH (r3v22 ?? I:int) = (r1v3 ?? I:int) + (r1v18 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x01ec]
          (r1v3 ?? I:int) from 0x01cb: ARITH (r4v25 ?? I:int) = (r4v24 ?? I:int) - (r1v3 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x01ec]
          (r1v3 ?? I:int) from 0x01db: INVOKE (r1v6 ?? I:java.lang.Object), (r1v10 ?? I:int), (r2v31 ?? I:java.lang.Object), (r1v3 ?? I:int), (r1v18 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[Catch: StringIndexOutOfBoundsException -> 0x01ec, MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)] (LINE:1412)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_H(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 6, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0058: MOVE (r1v27 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0097: MOVE (r1v57 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v3 ?? I:int) from 0x01cc: INVOKE (r0v28 ?? I:java.lang.Object), (r1v3 ?? I:int), (r2v29 ?? I:java.lang.Object), (r3v22 ?? I:int), (r4v25 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[Catch: StringIndexOutOfBoundsException -> 0x01ec, MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)]
          (r1v3 ?? I:int) from 0x01c4: ARITH (r3v22 ?? I:int) = (r1v3 ?? I:int) + (r1v18 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x01ec]
          (r1v3 ?? I:int) from 0x01cb: ARITH (r4v25 ?? I:int) = (r4v24 ?? I:int) - (r1v3 ?? I:int) A[Catch: StringIndexOutOfBoundsException -> 0x01ec]
          (r1v3 ?? I:int) from 0x01db: INVOKE (r1v6 ?? I:java.lang.Object), (r1v10 ?? I:int), (r2v31 ?? I:java.lang.Object), (r1v3 ?? I:int), (r1v18 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[Catch: StringIndexOutOfBoundsException -> 0x01ec, MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)] (LINE:1412)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v7 ??, still in use, count: 1, list:
          (r1v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0015: MOVE (r14v0 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_z7(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v7 ??, still in use, count: 1, list:
          (r1v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0015: MOVE (r14v0 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v7 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:247)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 4, list:
          (r1v3 ?? I:int) from 0x00a2: INVOKE (r0v8 ?? I:java.lang.Object), (r1v3 ?? I:int), (r2v18 ?? I:java.lang.Object), (r3v19 ?? I:int), (r4v25 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)]
          (r1v3 ?? I:int) from 0x009a: ARITH (r3v19 ?? I:int) = (r1v3 ?? I:int) + (r4v22 ?? I:int)
          (r1v3 ?? I:int) from 0x00a1: ARITH (r4v25 ?? I:int) = (r4v24 ?? I:int) - (r1v3 ?? I:int)
          (r1v3 ?? I:??[int, short, byte, char]) from 0x00ad: APUT (r0v10 ?? I:char[] A[IMMUTABLE_TYPE]), (r1v3 ?? I:??[int, short, byte, char]), (r1v7 ?? I:char A[IMMUTABLE_TYPE])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_l(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 4, list:
          (r1v3 ?? I:int) from 0x00a2: INVOKE (r0v8 ?? I:java.lang.Object), (r1v3 ?? I:int), (r2v18 ?? I:java.lang.Object), (r3v19 ?? I:int), (r4v25 ?? I:int) STATIC call: java.lang.System.arraycopy(java.lang.Object, int, java.lang.Object, int, int):void A[MD:(java.lang.Object, int, java.lang.Object, int, int):void (c)]
          (r1v3 ?? I:int) from 0x009a: ARITH (r3v19 ?? I:int) = (r1v3 ?? I:int) + (r4v22 ?? I:int)
          (r1v3 ?? I:int) from 0x00a1: ARITH (r4v25 ?? I:int) = (r4v24 ?? I:int) - (r1v3 ?? I:int)
          (r1v3 ?? I:??[int, short, byte, char]) from 0x00ad: APUT (r0v10 ?? I:char[] A[IMMUTABLE_TYPE]), (r1v3 ?? I:??[int, short, byte, char]), (r1v7 ?? I:char A[IMMUTABLE_TYPE])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_o(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 102510354449486(0x5d3b8d43444e, double:5.06468444765004E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r9
            r1 = r15
            r2 = r11
            r3 = r12
            java.lang.String r3 = java.lang.String.valueOf(r3)
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_o(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_RR(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 67415471605560(0x3d50633cc738, double:3.3307668518493E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r16
            r2 = r15
            r3 = r11
            java.lang.String r3 = java.lang.String.valueOf(r3)
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_RR(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x005f: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_A(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 115638940928612(0x692c49ff0a64, double:5.71332280342924E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r9
            r1 = r15
            r2 = r13
            r3 = r14
            java.lang.String r3 = java.lang.String.valueOf(r3)
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_A(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v9 ??, still in use, count: 2, list:
          (r4v9 ?? I:??[OBJECT, ARRAY][]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
          (r4v9 ?? I:??[OBJECT, ARRAY]) from 0x0061: APUT (r4v9 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_C(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 137362735086066(0x7cee4107b9f2, double:6.78662084248173E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r9
            r1 = r16
            r2 = r15
            r3 = r11
            java.lang.String r3 = java.lang.String.valueOf(r3)
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_Qo(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_C(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    private void m122Vulcan_X(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        int iIntValue3 = ((Integer) objArr[2]).intValue();
        System.arraycopy(this.Vulcan_b, iIntValue2, this.Vulcan_b, iIntValue, this.Vulcan_f - iIntValue2);
        this.Vulcan_f -= iIntValue3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_tZ(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 32589410987633(0x1da3d043ee71, double:1.61013083871907E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            r1 = r15
            r2 = r16
            r3 = r17
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m154Vulcan_I(r1)
            r16 = r0
            r0 = r16
            r1 = r15
            int r0 = r0 - r1
            r19 = r0
            r0 = r19
            if (r0 <= 0) goto Lb2
            r0 = r11
            r1 = r15
            r2 = r16
            r3 = r19
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            java.lang.Integer r6 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r6.<init>(r7)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r4[r5] = r6     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            r0.m122Vulcan_X(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            goto Lb2
        Lae:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lb2:
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_tZ(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0041, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0044, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0048, code lost:
    
        if (r0 <= 0) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x004c, code lost:
    
        if (r0 != r1) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0052, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0055, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0056, code lost:
    
        r0 = r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x005e, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x005f, code lost:
    
        r16 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0061, code lost:
    
        r15 = r15 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x006a, code lost:
    
        if (r15 >= r9.Vulcan_f) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0075, code lost:
    
        if (r9.Vulcan_b[r15] == r1) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007b, code lost:
    
        r0 = r15 - (r16 == true ? 1 : 0);
        m122Vulcan_X(new java.lang.Object[]{new java.lang.Integer(r16 == true ? 1 : 0), new java.lang.Integer(r15), new java.lang.Integer(r0)});
        r15 = r15 - r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00be, code lost:
    
        r15 = r15 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00c3, code lost:
    
        if (r0 != 0) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00c9, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00cd, code lost:
    
        return r9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x002a, code lost:
    
        if (r15 < r9.Vulcan_f) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x002d, code lost:
    
        r0 = r9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0030, code lost:
    
        if (r0 == 0) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0033, code lost:
    
        r0 = r0.Vulcan_b[r15];
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003b, code lost:
    
        if (r0 == 0) goto L22;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x002d, B:31:0x00c6], limit reached: 47 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [char] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v8, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r16v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x00c9 -> B:5:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_r(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 206
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_r(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00b1 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v21, types: [char] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_J8(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = Vulcan_W()
            r1 = 0
            r15 = r1
            r14 = r0
        L25:
            r0 = r15
            r1 = r9
            int r1 = r1.Vulcan_f
            if (r0 >= r1) goto Lc1
        L2e:
            r0 = r9
            r1 = r14
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L3c
            if (r1 == 0) goto Lc2
            r1 = r14
        L3c:
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L6e
            if (r1 == 0) goto L6c
            goto L4c
        L48:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L60
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L60
        L4c:
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L60 java.lang.StringIndexOutOfBoundsException -> L68
            r1 = r15
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L60 java.lang.StringIndexOutOfBoundsException -> L68
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lb1
            r1 = r13
            if (r0 != r1) goto Lac
            goto L64
        L60:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L68
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L68
        L64:
            r0 = r9
            goto L6c
        L68:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L6c:
            r1 = r15
        L6e:
            r2 = r15
            r3 = 1
            int r2 = r2 + r3
            r3 = 1
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            java.lang.Integer r6 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r6.<init>(r7)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r4[r5] = r6     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            java.lang.Integer r5 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r6 = r5; r5 = r4; r4 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r0.m122Vulcan_X(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lbd
            r0 = r14
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb1
            if (r0 != 0) goto Lc1
        Lac:
            int r15 = r15 + 1
            r0 = r14
        Lb1:
            if (r0 != 0) goto L25
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L2e
            goto Lc1
        Lbd:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lc1:
            r0 = r9
        Lc2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_J8(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Y(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 272
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan__(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 232
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan__(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v9 ??, still in use, count: 2, list:
          (r7v9 ?? I:??[OBJECT, ARRAY][]) from 0x005c: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
          (r7v9 ?? I:??[OBJECT, ARRAY]) from 0x005c: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m123Vulcan_B(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 89435926851571(0x51576ca66ff3, double:4.4187218961332E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            r1 = r15
            r2 = 0
            r3 = 0
            r4 = r13
            int r4 = r4.Vulcan_f
            r5 = r18
            r6 = r5; r5 = r4; r4 = r6; 
            r6 = -1
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Integer r9 = new java.lang.Integer
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 5
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m125Vulcan_E(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m123Vulcan_B(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v9 ??, still in use, count: 2, list:
          (r7v9 ?? I:??[OBJECT, ARRAY][]) from 0x0078: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
          (r7v9 ?? I:??[OBJECT, ARRAY]) from 0x0078: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Z(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r18 = r1
            r0 = r15
            r1 = 8
            long r0 = r0 << r1
            r1 = r18
            long r1 = (long) r1
            r2 = 56
            long r1 = r1 << r2
            r2 = 56
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_P.a
            long r0 = r0 ^ r1
            r19 = r0
            r0 = r19
            r1 = r0; r1 = r0; 
            r2 = 126246305655779(0x72d20233ebe3, double:6.2373962538894E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r0 = r13
            r1 = r17
            r2 = 0
            r3 = 0
            r4 = r13
            int r4 = r4.Vulcan_f
            r5 = r21
            r6 = r5; r5 = r4; r4 = r6; 
            r6 = 1
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Integer r9 = new java.lang.Integer
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 5
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m125Vulcan_E(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r1v30, types: [int, java.lang.Long] */
    /* JADX WARN: Type inference failed for: r3v3, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0088: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00bb]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0088: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x00bb]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    private void Vulcan_k(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 216
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_k(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_WW(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_m()
            r14 = r0
            r0 = r12
            r1 = r14
            if (r1 != 0) goto L48
            r1 = r13
            if (r0 == r1) goto L9b
            goto L40
        L3c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L44
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L44
        L40:
            r0 = 0
            goto L48
        L44:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L48:
            r15 = r0
        L4a:
            r0 = r15
            r1 = r8
            int r1 = r1.Vulcan_f
            if (r0 >= r1) goto L9b
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L9c
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L6c java.lang.StringIndexOutOfBoundsException -> L7f
            r1 = r15
            r2 = r14
            r3 = r10
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L92
            if (r2 != 0) goto L90
            goto L70
        L6c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f
        L70:
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f java.lang.StringIndexOutOfBoundsException -> L8c
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L98
            r1 = r12
            if (r0 != r1) goto L93
            goto L83
        L7f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
        L83:
            r0 = r8
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
            r1 = r15
            goto L90
        L8c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L90:
            r2 = r13
        L92:
            r0[r1] = r2
        L93:
            int r15 = r15 + 1
            r0 = r14
        L98:
            if (r0 == 0) goto L4a
        L9b:
            r0 = r8
        L9c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_WW(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_Wf(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = Vulcan_W()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 == 0) goto L47
            r1 = r10
            if (r0 == r1) goto Lb4
            goto L3f
        L3b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L43
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L43
        L3f:
            r0 = 0
            goto L47
        L43:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L47:
            r15 = r0
        L49:
            r0 = r15
            r1 = r8
            int r1 = r1.Vulcan_f
            if (r0 >= r1) goto Lb4
        L52:
            r0 = r8
            r1 = r14
            if (r1 == 0) goto Lb5
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L6c java.lang.StringIndexOutOfBoundsException -> L7f
            r1 = r15
            r2 = r14
            r3 = r12
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L91
            if (r2 == 0) goto L90
            goto L70
        L6c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f
        L70:
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L7f java.lang.StringIndexOutOfBoundsException -> L8c
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto La3
            r1 = r11
            if (r0 != r1) goto L9e
            goto L83
        L7f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
        L83:
            r0 = r8
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L8c
            r1 = r15
            goto L90
        L8c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L90:
            r2 = r10
        L91:
            r0[r1] = r2     // Catch: java.lang.StringIndexOutOfBoundsException -> Lb0
            r0 = r14
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto La3
            if (r0 != 0) goto Lb4
        L9e:
            int r15 = r15 + 1
            r0 = r14
        La3:
            if (r0 != 0) goto L49
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L52
            goto Lb4
        Lb0:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lb4:
            r0 = r8
        Lb5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_Wf(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_R(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 356
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_R(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_a(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 319
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_a(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v9 ??, still in use, count: 2, list:
          (r7v9 ?? I:??[OBJECT, ARRAY][]) from 0x0067: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
          (r7v9 ?? I:??[OBJECT, ARRAY]) from 0x0067: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_F(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 26930309950630(0x187e338eeca6, double:1.3305340978463E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            r1 = r16
            r2 = r15
            r3 = 0
            r4 = r13
            int r4 = r4.Vulcan_f
            r5 = r19
            r6 = r5; r5 = r4; r4 = r6; 
            r6 = -1
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Integer r9 = new java.lang.Integer
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 5
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m125Vulcan_E(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v9, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v9 ??, still in use, count: 2, list:
          (r7v9 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
          (r7v9 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r7v9 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v9 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m124Vulcan_k(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 7734982185370(0x708f0dd919a, double:3.8215889689854E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            r1 = r18
            r2 = r15
            r3 = 0
            r4 = r13
            int r4 = r4.Vulcan_f
            r5 = r19
            r6 = r5; r5 = r4; r4 = r6; 
            r6 = 1
            r7 = 6
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Integer r9 = new java.lang.Integer
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 5
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Integer r8 = new java.lang.Integer
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.m125Vulcan_E(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m124Vulcan_k(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v23, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v5, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x006d: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x006d: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_P m125Vulcan_E(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m125Vulcan_E(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private ac.vulcan.anticheat.Vulcan_P Vulcan_p(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 468
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_p(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r10v0 */
    public Vulcan_P Vulcan_g(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_m = Vulcan_m();
        try {
            try {
                Vulcan_m = this.Vulcan_f;
                ?? r0 = Vulcan_m;
                if (Vulcan_m == 0) {
                    if (Vulcan_m == 0) {
                        return this;
                    }
                    r0 = this.Vulcan_f / 2;
                }
                ?? r10 = r0;
                char[] cArr = this.Vulcan_b;
                int i = 0;
                int i2 = this.Vulcan_f - 1;
                while (i < r10) {
                    char c = cArr[i];
                    cArr[i] = cArr[i2];
                    cArr[i2] = c;
                    i++;
                    i2--;
                    if (Vulcan_m != 0) {
                        break;
                    }
                }
                return this;
            } catch (StringIndexOutOfBoundsException unused) {
                Vulcan_m = a(Vulcan_m);
                throw Vulcan_m;
            }
        } catch (StringIndexOutOfBoundsException unused2) {
            throw a(Vulcan_m);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v29, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v42, types: [char] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v48, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v53, types: [char] */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r10v0, types: [ac.vulcan.anticheat.Vulcan_P] */
    /* JADX WARN: Type inference failed for: r17v0 */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v10 */
    /* JADX WARN: Type inference failed for: r17v11 */
    /* JADX WARN: Type inference failed for: r17v12 */
    /* JADX WARN: Type inference failed for: r17v13 */
    /* JADX WARN: Type inference failed for: r17v14 */
    /* JADX WARN: Type inference failed for: r17v15 */
    /* JADX WARN: Type inference failed for: r17v16 */
    /* JADX WARN: Type inference failed for: r17v17 */
    /* JADX WARN: Type inference failed for: r17v2 */
    /* JADX WARN: Type inference failed for: r17v3 */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Type inference failed for: r17v5, types: [int] */
    /* JADX WARN: Type inference failed for: r17v6, types: [int] */
    /* JADX WARN: Type inference failed for: r17v7 */
    /* JADX WARN: Type inference failed for: r17v8 */
    /* JADX WARN: Type inference failed for: r17v9 */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v33 */
    /* JADX WARN: Type inference failed for: r1v34 */
    /* JADX WARN: Type inference failed for: r1v36 */
    /* JADX WARN: Type inference failed for: r2v24 */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v26 */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r4v17, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v2, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:60:0x00d5 -> B:37:0x008c). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x016d: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0182]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x016d: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x0182]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_P Vulcan_w(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 392
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.Vulcan_w(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_P");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public boolean m126Vulcan_I(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 211
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m126Vulcan_I(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public boolean m127Vulcan_i(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m127Vulcan_i(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x006f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x006f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public java.lang.String m128Vulcan_o(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r0 = r13
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r14
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r15
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_P.a
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 51594901187139(0x2eecdfc1ea43, double:2.5491268177139E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r11
            r1 = r16
            r2 = r11
            int r2 = r2.Vulcan_f
            r3 = r19
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r0 = r0.m129Vulcan_Z(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m128Vulcan_o(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public java.lang.String m129Vulcan_Z(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 82683072970365(0x4b3327317e7d, double:4.08508658472423E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            r1 = r13
            r2 = r16
            r3 = r17
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m154Vulcan_I(r1)
            r16 = r0
            java.lang.String r0 = new java.lang.String
            r1 = r0
            r2 = r11
            char[] r2 = r2.Vulcan_b
            r3 = r13
            r4 = r16
            r5 = r13
            int r4 = r4 - r5
            r1.<init>(r2, r3, r4)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m129Vulcan_Z(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public java.lang.String m130Vulcan_S(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_m()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L3a
            if (r0 > 0) goto L39
            goto L31
        L2d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
        L31:
            java.lang.String r0 = ""
            return r0
        L35:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L35
            throw r0
        L39:
            r0 = r8
        L3a:
            r1 = r6
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            if (r0 < r1) goto L56
            java.lang.String r0 = new java.lang.String     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            r1 = r0
            r2 = r6
            char[] r2 = r2.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            r3 = 0
            r4 = r6
            int r4 = r4.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            r1.<init>(r2, r3, r4)     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            return r0
        L52:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L52
            throw r0
        L56:
            java.lang.String r0 = new java.lang.String
            r1 = r0
            r2 = r6
            char[] r2 = r2.Vulcan_b
            r3 = 0
            r4 = r8
            r1.<init>(r2, r3, r4)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m130Vulcan_S(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public java.lang.String m131Vulcan_a(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = Vulcan_W()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 == 0) goto L3d
            if (r0 > 0) goto L3b
            goto L33
        L2f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L37
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L37
        L33:
            java.lang.String r0 = ""
            return r0
        L37:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L37
            throw r0
        L3b:
            r0 = r10
        L3d:
            r1 = r6
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            if (r0 < r1) goto L59
            java.lang.String r0 = new java.lang.String     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            r1 = r0
            r2 = r6
            char[] r2 = r2.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            r3 = 0
            r4 = r6
            int r4 = r4.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            r1.<init>(r2, r3, r4)     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            return r0
        L55:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L55
            throw r0
        L59:
            java.lang.String r0 = new java.lang.String
            r1 = r0
            r2 = r6
            char[] r2 = r2.Vulcan_b
            r3 = r6
            int r3 = r3.Vulcan_f
            r4 = r10
            int r3 = r3 - r4
            r4 = r10
            r1.<init>(r2, r3, r4)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m131Vulcan_a(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public String m132Vulcan_A(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        long j = a ^ jLongValue;
        int iVulcan_W = Vulcan_W();
        int i = iIntValue;
        int i2 = i;
        if (iVulcan_W != 0) {
            if (i < 0) {
                iIntValue = 0;
            }
            i2 = iIntValue2;
        }
        int i3 = iVulcan_W;
        ?? A = i2;
        ?? r0 = i2;
        if (j >= 0) {
            if (i3 != 0) {
                if (i2 <= 0) {
                    return "";
                }
                A = iIntValue;
            }
            try {
                try {
                    i3 = this.Vulcan_f;
                    r0 = A;
                } catch (StringIndexOutOfBoundsException unused) {
                    throw a(A);
                }
            } catch (StringIndexOutOfBoundsException unused2) {
                A = a(A);
                throw A;
            }
        }
        ?? str = r0;
        if (j >= 0) {
            str = r0;
            if (iVulcan_W != 0) {
                if (r0 >= i3) {
                    return "";
                }
                i3 = iIntValue + iIntValue2;
                str = this.Vulcan_f;
            }
        }
        if (str <= i3) {
            try {
                str = new String(this.Vulcan_b, iIntValue, this.Vulcan_f - iIntValue);
                return str;
            } catch (StringIndexOutOfBoundsException unused3) {
                throw a(str);
            }
        }
        return new String(this.Vulcan_b, iIntValue, iIntValue2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x004b, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x004e, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0052, code lost:
    
        if (r0 <= 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0056, code lost:
    
        if (r0 != r1) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x005c, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x005f, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0067, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0068, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0069, code lost:
    
        r14 = r14 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x006e, code lost:
    
        if (r0 != 0) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0071, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0074, code lost:
    
        if (r0 <= 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0077, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0071, code lost:
    
        if (r0 != 0) goto L3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0030, code lost:
    
        if (r0 < r7.Vulcan_f) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0033, code lost:
    
        r0 = r1[r14];
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x003d, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0040, code lost:
    
        if (r1 == 0) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0043, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0045, code lost:
    
        if (r1 == 0) goto L36;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:30:0x0033, B:26:0x0071], limit reached: 41 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m133Vulcan_Q(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_W()
            r1 = r7
            char[] r1 = r1.Vulcan_b
            r13 = r1
            r1 = 0
            r14 = r1
            r12 = r0
        L2a:
            r0 = r14
            r1 = r7
            int r1 = r1.Vulcan_f
            if (r0 >= r1) goto L71
        L33:
            r0 = r13
            r1 = r14
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L45
            if (r1 == 0) goto L78
            r1 = r12
        L45:
            if (r1 == 0) goto L68
            goto L4f
        L4b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L5c
        L4f:
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L6e
            r1 = r9
            if (r0 != r1) goto L69
            goto L60
        L5c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L64
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L64
        L60:
            r0 = 1
            goto L68
        L64:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L68:
            return r0
        L69:
            int r14 = r14 + 1
            r0 = r12
        L6e:
            if (r0 != 0) goto L2a
        L71:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L33
            r0 = 0
        L78:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m133Vulcan_Q(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x005f]
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x005f]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public boolean m134Vulcan_s(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 74637035285797(0x43e1c9f9ad25, double:3.6875595042153E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = Vulcan_m()
            r17 = r0
            r0 = r10
            r1 = r15
            r2 = r12
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            java.lang.Integer r6 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6.<init>(r7)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4[r5] = r6     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4.<init>(r5)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            int r0 = r0.m139Vulcan_D(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r1 = r17
            if (r1 != 0) goto L64
            if (r0 < 0) goto L67
            goto L63
        L5f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L63:
            r0 = 1
        L64:
            goto L68
        L67:
            r0 = 0
        L68:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m134Vulcan_s(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x005f]
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x005f]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public boolean m135Vulcan_T(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 72323488256465(0x41c71fd391d1, double:3.5732550934922E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = Vulcan_W()
            r17 = r0
            r0 = r10
            r1 = r12
            r2 = r15
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            java.lang.Integer r6 = new java.lang.Integer     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r7 = r6; r6 = r5; r5 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r8 = r6; r6 = r7; r7 = r8;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6.<init>(r7)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4[r5] = r6     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            int r0 = r0.m141Vulcan_h(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L5f
            r1 = r17
            if (r1 == 0) goto L64
            if (r0 < 0) goto L67
            goto L63
        L5f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L63:
            r0 = 1
        L64:
            goto L68
        L67:
            r0 = 0
        L68:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m135Vulcan_T(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public int m136Vulcan_i(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 28562272394133(0x19fa2c199b95, double:1.4111637557101E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m137Vulcan_k(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m136Vulcan_i(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0079, code lost:
    
        if (r0 < r7.Vulcan_f) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x007c, code lost:
    
        r0 = r0[r15 == true ? 1 : 0];
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0086, code lost:
    
        if (r0 < 0) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0089, code lost:
    
        if (r1 == 0) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x008c, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x008e, code lost:
    
        if (r1 == 0) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0094, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0097, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x009b, code lost:
    
        if (r0 < 0) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x009f, code lost:
    
        if (r0 != r1) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00a5, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00a8, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00b1, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00b2, code lost:
    
        return r15 == true ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00b3, code lost:
    
        r15 = r15 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00b8, code lost:
    
        if (r0 != 0) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00bb, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00be, code lost:
    
        if (r0 <= 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00c1, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00bb, code lost:
    
        if (r0 != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:53:0x007c, B:49:0x00bb], limit reached: 65 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v21, types: [char, int] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int, java.lang.StringIndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int m137Vulcan_k(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = Vulcan_W()
            r13 = r0
            r0 = r12
            r1 = r13
            if (r1 == 0) goto L3e
            if (r0 >= 0) goto L41
            goto L3d
        L39:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L3d:
            r0 = 0
        L3e:
            goto L43
        L41:
            r0 = r12
        L43:
            r12 = r0
            r0 = r12
            r1 = r13
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L56
            if (r1 == 0) goto L68
            r1 = r7
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L5c java.lang.StringIndexOutOfBoundsException -> L64
        L56:
            if (r0 < r1) goto L69
            goto L60
        L5c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L64
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L64
        L60:
            r0 = -1
            goto L68
        L64:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L68:
            return r0
        L69:
            r0 = r7
            char[] r0 = r0.Vulcan_b
            r14 = r0
            r0 = r12
            r15 = r0
        L73:
            r0 = r15
            r1 = r7
            int r1 = r1.Vulcan_f
            if (r0 >= r1) goto Lbb
        L7c:
            r0 = r14
            r1 = r15
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L94
            r1 = r13
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8e
            if (r1 == 0) goto Lc2
            r1 = r13
        L8e:
            if (r1 == 0) goto Lb2
            goto L98
        L94:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> La5
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> La5
        L98:
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb8
            r1 = r9
            if (r0 != r1) goto Lb3
            goto La9
        La5:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> Lae
        La9:
            r0 = r15
            goto Lb2
        Lae:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Lb2:
            return r0
        Lb3:
            int r15 = r15 + 1
            r0 = r13
        Lb8:
            if (r0 != 0) goto L73
        Lbb:
            r0 = r10
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L7c
            r0 = -1
        Lc2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m137Vulcan_k(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public int m138Vulcan_K(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 51582611118116(0x2eea03365824, double:2.548519607625E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = r12
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m139Vulcan_D(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m138Vulcan_K(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public int m139Vulcan_D(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 404
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m139Vulcan_D(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public int m140Vulcan_Z(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 40257167458825(0x249d1a2a8209, double:1.98896834402836E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = 0
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m141Vulcan_h(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m140Vulcan_Z(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x00fe -> B:49:0x0101). Please report as a decompilation issue!!! */
    /*  JADX ERROR: NullPointerException in pass: ConstructorVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.sameRegAndSVar(jadx.core.dex.instructions.args.InsnArg)" because "resultArg" is null
        	at jadx.core.dex.visitors.MoveInlineVisitor.processMove(MoveInlineVisitor.java:52)
        	at jadx.core.dex.visitors.MoveInlineVisitor.moveInline(MoveInlineVisitor.java:41)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:43)
        */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public int m141Vulcan_h(
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r14v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    /*  JADX ERROR: NullPointerException in pass: ConstructorVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.sameRegAndSVar(jadx.core.dex.instructions.args.InsnArg)" because "resultArg" is null
        	at jadx.core.dex.visitors.MoveInlineVisitor.processMove(MoveInlineVisitor.java:52)
        	at jadx.core.dex.visitors.MoveInlineVisitor.moveInline(MoveInlineVisitor.java:41)
        */

    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v10 ??, still in use, count: 2, list:
          (r4v10 ?? I:??[OBJECT, ARRAY][]) from 0x005d: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
          (r4v10 ?? I:??[OBJECT, ARRAY]) from 0x005d: APUT (r4v10 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v10 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public int m142Vulcan_O(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 116647949309680(0x6a17379516f0, double:5.7631744411744E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = r14
            r3 = r10
            int r3 = r3.Vulcan_f
            r4 = 1
            int r3 = r3 - r4
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m143Vulcan_L(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m142Vulcan_O(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public int m143Vulcan_L(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_m()
            r13 = r0
            r0 = r12
            r1 = r7
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L3e
            r2 = r13
            if (r2 != 0) goto L4e
            if (r0 < r1) goto L52
            goto L42
        L3e:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4a
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L4a
        L42:
            r0 = r7
            int r0 = r0.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L4a
            r1 = 1
            goto L4e
        L4a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L4e:
            int r0 = r0 - r1
            goto L54
        L52:
            r0 = r12
        L54:
            r12 = r0
            r0 = r12
            r1 = r13
            if (r1 != 0) goto L6f
            if (r0 >= 0) goto L6d
            goto L67
        L63:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L69
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L69
        L67:
            r0 = -1
            return r0
        L69:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L69
            throw r0
        L6d:
            r0 = r12
        L6f:
            r14 = r0
        L71:
            r0 = r14
            if (r0 < 0) goto Lb8
        L76:
            r0 = r7
            char[] r0 = r0.Vulcan_b     // Catch: java.lang.StringIndexOutOfBoundsException -> L90
            r1 = r14
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L90
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8a
            if (r1 != 0) goto Lbf
            r1 = r13
        L8a:
            if (r1 != 0) goto Laf
            goto L94
        L90:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> La2
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> La2
        L94:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto Lb5
            r1 = r11
            if (r0 != r1) goto Lb0
            goto La6
        La2:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> Lab
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> Lab
        La6:
            r0 = r14
            goto Laf
        Lab:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        Laf:
            return r0
        Lb0:
            int r14 = r14 + (-1)
            r0 = r13
        Lb5:
            if (r0 == 0) goto L71
        Lb8:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L76
            r0 = -1
        Lbf:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m143Vulcan_L(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public int m144Vulcan_H(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 23598825018089(0x1576879512e9, double:1.16593687236567E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r12
            r2 = r10
            int r2 = r2.Vulcan_f
            r3 = 1
            int r2 = r2 - r3
            r3 = r15
            r4 = r3; r3 = r2; r2 = r4; 
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m145Vulcan_E(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m144Vulcan_H(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public int m145Vulcan_E(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 461
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m145Vulcan_E(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public int m146Vulcan_w(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_kH r1 = (ac.vulcan.anticheat.Vulcan_kH) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 96349443091361(0x57a11a546ba1, double:4.76029498273777E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = r12
            r3 = r10
            int r3 = r3.Vulcan_f
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.m147Vulcan_A(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m146Vulcan_w(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public int m147Vulcan_A(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 273
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m147Vulcan_A(java.lang.Object[]):int");
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public Vulcan_kU m148Vulcan_Z(Object[] objArr) {
        return new Vulcan_kS(this);
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public Reader m149Vulcan_w(Object[] objArr) {
        return new Vulcan_I(this);
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public Writer m150Vulcan_t(Object[] objArr) {
        return new Vulcan_yf(this);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public boolean m151Vulcan_G(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m151Vulcan_G(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public boolean m152Vulcan_W(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_P r1 = (ac.vulcan.anticheat.Vulcan_P) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = Vulcan_W()
            r12 = r0
            r0 = r7
            r1 = r12
            if (r1 == 0) goto L38
            r1 = r11
            if (r0 != r1) goto L37
            goto L31
        L2d:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L33
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L33
        L31:
            r0 = 1
            return r0
        L33:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L33
            throw r0
        L37:
            r0 = r7
        L38:
            r1 = r12
            if (r1 == 0) goto L56
            int r0 = r0.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b java.lang.StringIndexOutOfBoundsException -> L51
            r1 = r11
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L4b java.lang.StringIndexOutOfBoundsException -> L51
            if (r0 == r1) goto L55
            goto L4f
        L4b:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L51
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L51
        L4f:
            r0 = 0
            return r0
        L51:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L51
            throw r0
        L55:
            r0 = r7
        L56:
            char[] r0 = r0.Vulcan_b
            r13 = r0
            r0 = r11
            char[] r0 = r0.Vulcan_b
            r14 = r0
            r0 = r7
            int r0 = r0.Vulcan_f
            r1 = 1
            int r0 = r0 - r1
            r15 = r0
        L6a:
            r0 = r15
            if (r0 < 0) goto Lb1
        L6f:
            r0 = r13
            r1 = r15
            char r0 = r0[r1]     // Catch: java.lang.StringIndexOutOfBoundsException -> L87
            r1 = r12
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L81
            if (r1 == 0) goto Lb8
            r1 = r12
        L81:
            if (r1 == 0) goto La8
            goto L8b
        L87:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L9c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L9c
        L8b:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto Lae
            r1 = r14
            r2 = r15
            char r1 = r1[r2]     // Catch: java.lang.StringIndexOutOfBoundsException -> L9c java.lang.StringIndexOutOfBoundsException -> La4
            if (r0 == r1) goto La9
            goto La0
        L9c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> La4
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> La4
        La0:
            r0 = 0
            goto La8
        La4:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        La8:
            return r0
        La9:
            int r15 = r15 + (-1)
            r0 = r12
        Lae:
            if (r0 != 0) goto L6a
        Lb1:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L6f
            r0 = 1
        Lb8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m152Vulcan_W(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x004c]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: StringIndexOutOfBoundsException -> 0x004c]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean equals(java.lang.Object r11) {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = 97005592552726(0x5839dfe2a516, double:4.79271307347754E-310)
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 23262756893526(0x1528485c7356, double:1.1493329008648E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = Vulcan_m()
            r16 = r0
            r0 = r11
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_P     // Catch: java.lang.StringIndexOutOfBoundsException -> L25
            r1 = r16
            if (r1 != 0) goto L51
            if (r0 == 0) goto L50
            goto L29
        L25:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
        L29:
            r0 = r10
            r1 = r11
            ac.vulcan.anticheat.Vulcan_P r1 = (ac.vulcan.anticheat.Vulcan_P) r1     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r5.<init>(r6)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r3[r4] = r5     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            r2[r3] = r4     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            boolean r0 = r0.m152Vulcan_W(r1)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            return r0
        L4c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L4c
            throw r0
        L50:
            r0 = 0
        L51:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        long j = a ^ 88520670729006L;
        char[] cArr = this.Vulcan_b;
        int i = 0;
        int iVulcan_W = Vulcan_W();
        int i2 = this.Vulcan_f - 1;
        while (i2 >= 0) {
            int i3 = (31 * i) + cArr[i2];
            if (iVulcan_W == 0) {
                return i3;
            }
            i = i3;
            i2--;
            if (iVulcan_W == 0) {
                break;
            }
        }
        return i;
    }

    public String toString() {
        return new String(this.Vulcan_b, 0, this.Vulcan_f);
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public StringBuffer m153Vulcan_K(Object[] objArr) {
        return new StringBuffer(this.Vulcan_f).append(this.Vulcan_b, 0, this.Vulcan_f);
    }

    public Object clone() {
        Vulcan_P vulcan_P = (Vulcan_P) super.clone();
        vulcan_P.Vulcan_b = new char[this.Vulcan_b.length];
        System.arraycopy(this.Vulcan_b, 0, vulcan_P.Vulcan_b, 0, this.Vulcan_b.length);
        return vulcan_P;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x003a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    protected int m154Vulcan_I(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = Vulcan_m()
            r13 = r0
            r0 = r10
            r1 = r13
            if (r1 != 0) goto L4c
            if (r0 >= 0) goto L4b
            goto L3e
        L3a:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
        L3e:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
            r1 = r0
            r2 = r10
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
        L47:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L47
            throw r0
        L4b:
            r0 = r9
        L4c:
            r1 = r7
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L62
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L80
            r2 = r13
            if (r2 != 0) goto L80
            if (r0 <= r1) goto L6b
            goto L66
        L62:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L66:
            r0 = r7
            int r0 = r0.Vulcan_f
            r9 = r0
        L6b:
            r0 = r10
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L79
            if (r1 != 0) goto L96
            r1 = r9
        L79:
            goto L80
        L7c:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L80:
            if (r0 <= r1) goto L95
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_P.b     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
            r3 = 8
            r2 = r2[r3]     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
        L91:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L91
            throw r0
        L95:
            r0 = r9
        L96:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m154Vulcan_I(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004a A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.StringIndexOutOfBoundsException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void m155Vulcan_C(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_P.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = Vulcan_m()
            r10 = r0
            r0 = r9
            r1 = r10
            if (r1 != 0) goto L35
            if (r0 < 0) goto L3c
            goto L33
        L2f:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)
            throw r0
        L33:
            r0 = r9
        L35:
            r1 = r5
            int r1 = r1.Vulcan_f     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            if (r0 <= r1) goto L4a
        L3c:
            java.lang.StringIndexOutOfBoundsException r0 = new java.lang.StringIndexOutOfBoundsException     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            r1 = r0
            r2 = r9
            r1.<init>(r2)     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            throw r0     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
        L46:
            java.lang.StringIndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.StringIndexOutOfBoundsException -> L46
            throw r0
        L4a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_P.m155Vulcan_C(java.lang.Object[]):void");
    }
}
