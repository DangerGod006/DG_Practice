package ac.vulcan.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Ou.class */
public class Vulcan_Ou extends Vulcan_O0 {
    private static String Vulcan_U;

    public static void Vulcan_P(String str) {
        Vulcan_U = str;
    }

    public static String Vulcan_B() {
        return Vulcan_U;
    }

    static {
        if (Vulcan_B() == null) {
            Vulcan_P("St4fQb");
        }
    }

    public Vulcan_Ou(Plugin plugin) {
        super(plugin);
    }

    @Override // ac.vulcan.anticheat.Vulcan_O0, ac.vulcan.anticheat.Vulcan_H
    public boolean Vulcan_d(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }
}
