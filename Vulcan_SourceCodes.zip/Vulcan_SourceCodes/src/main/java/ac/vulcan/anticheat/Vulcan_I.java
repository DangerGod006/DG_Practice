package ac.vulcan.anticheat;

import java.io.Reader;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_I.class */
class Vulcan_I extends Reader {
    private int Vulcan_E;
    private int Vulcan_V;
    private final Vulcan_P Vulcan_p;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(1414223905535436439L, -2440152047617141161L, null).a(7915116404860L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0051: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // java.io.Reader
    public int read() {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_I.a
            r1 = 42024537691428(0x263899a41524, double:2.0762880355695E-310)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 105661755347114(0x60194b64d0aa, double:5.22038433962917E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_m()
            r14 = r0
            r0 = r9
            boolean r0 = r0.ready()     // Catch: java.lang.IndexOutOfBoundsException -> L24
            r1 = r14
            if (r1 != 0) goto L63
            if (r0 != 0) goto L2e
            goto L28
        L24:
            java.lang.IndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.IndexOutOfBoundsException -> L2a
            throw r0     // Catch: java.lang.IndexOutOfBoundsException -> L2a
        L28:
            r0 = -1
            return r0
        L2a:
            java.lang.IndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.IndexOutOfBoundsException -> L2a
            throw r0
        L2e:
            r0 = r9
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_p
            r1 = r9
            r2 = r1
            int r2 = r2.Vulcan_E
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = 1
            int r3 = r3 + r4
            r2.Vulcan_E = r3
            r2 = r12
            r3 = r2; r2 = r1; r1 = r3; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r4 = new java.lang.Integer
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r-1.Vulcan_B(r0)
        L63:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_I.read():int");
    }

    private static IndexOutOfBoundsException a(IndexOutOfBoundsException indexOutOfBoundsException) {
        return indexOutOfBoundsException;
    }

    Vulcan_I(Vulcan_P vulcan_P) {
        this.Vulcan_p = vulcan_P;
    }

    @Override // java.io.Reader, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // java.io.Reader
    public int read(char[] r14, int r15, int r16) {
        /*
            Method dump skipped, instruction units count: 341
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_I.read(char[], int, int):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:18:0x0056
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // java.io.Reader
    public long skip(long r7) {
        /*
            r6 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_I.a
            r1 = 19871058557238(0x12129762f936, double:9.817607379631E-311)
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_P.Vulcan_W()
            r11 = r0
            r0 = r6
            int r0 = r0.Vulcan_E     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            long r0 = (long) r0     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            r1 = r7
            long r0 = r0 + r1
            r1 = r6
            ac.vulcan.anticheat.Vulcan_P r1 = r1.Vulcan_p     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            int r1 = r1.Vulcan_M(r2)     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            long r1 = (long) r1     // Catch: java.lang.IndexOutOfBoundsException -> L2c
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r11
            if (r1 == 0) goto L51
            if (r0 <= 0) goto L42
            goto L30
        L2c:
            java.lang.IndexOutOfBoundsException r0 = a(r0)
            throw r0
        L30:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_p
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            int r0 = r0.Vulcan_M(r1)
            r1 = r6
            int r1 = r1.Vulcan_E
            int r0 = r0 - r1
            long r0 = (long) r0
            r7 = r0
        L42:
            r0 = r7
            r1 = r11
            if (r1 == 0) goto L67
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L51
        L4d:
            java.lang.IndexOutOfBoundsException r0 = a(r0)
            throw r0
        L51:
            if (r0 >= 0) goto L5a
            r0 = 0
            return r0
        L56:
            java.lang.IndexOutOfBoundsException r0 = a(r0)     // Catch: java.lang.IndexOutOfBoundsException -> L56
            throw r0
        L5a:
            r0 = r6
            r1 = r0
            int r1 = r1.Vulcan_E
            long r1 = (long) r1
            r2 = r7
            long r1 = r1 + r2
            int r1 = (int) r1
            r0.Vulcan_E = r1
            r0 = r7
        L67:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_I.skip(long):long");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IndexOutOfBoundsException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    @Override // java.io.Reader
    public boolean ready() {
        long j = a ^ 41916149338916L;
        ?? Vulcan_W = Vulcan_P.Vulcan_W();
        try {
            try {
                Vulcan_W = this.Vulcan_E;
                return Vulcan_W != 0 ? Vulcan_W < this.Vulcan_p.Vulcan_M(new Object[0]) : Vulcan_W;
            } catch (IndexOutOfBoundsException unused) {
                throw a(Vulcan_W);
            }
        } catch (IndexOutOfBoundsException unused2) {
            throw a(Vulcan_W);
        }
    }

    @Override // java.io.Reader
    public boolean markSupported() {
        return true;
    }

    @Override // java.io.Reader
    public void mark(int i) {
        this.Vulcan_V = this.Vulcan_E;
    }

    @Override // java.io.Reader
    public void reset() {
        this.Vulcan_E = this.Vulcan_V;
    }
}
