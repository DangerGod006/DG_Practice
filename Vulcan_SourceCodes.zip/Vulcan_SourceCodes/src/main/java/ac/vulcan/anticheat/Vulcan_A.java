package ac.vulcan.anticheat;

import java.io.Serializable;
import java.util.Iterator;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_A.class */
public final class Vulcan_A implements Serializable {
    private static final long serialVersionUID = 8270183163158333422L;
    private final char Vulcan_y;
    private final char Vulcan_k;
    private final boolean Vulcan_v;
    private transient String Vulcan_R;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-3637808543380568181L, 7573611364344904666L, null).a(261015930481475L);
    private static final String b;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = "\u00044DFe\u0002=79\u0001\u000bB\u0010'p2N\u0012\u0017\u00016p2T\n[".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 9;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 89;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -3637808543380568181(0xcd83e8675aeb878b, double:-2.6206736142001213E65)
            r1 = 7573611364344904666(0x691adf68bea3bbda, double:2.0087613294042113E198)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 261015930481475(0xed6481d12b43, double:1.28959004268184E-309)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_A.a = r0
            r0 = 9
            java.lang.String r1 = "\u00044DFe\u0002=79\u0001\u000bB\u0010'p2N\u0012\u0017\u00016p2T\n["
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.Vulcan_A.b = r2
            goto Lab
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 89
            goto L84
        L69:
            r8 = 85
            goto L84
        L6e:
            r8 = 40
            goto L84
        L73:
            r8 = 111(0x6f, float:1.56E-43)
            goto L84
        L78:
            r8 = 62
            goto L84
        L7d:
            r8 = 106(0x6a, float:1.49E-43)
            goto L84
        L82:
            r8 = 90
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_A.m5clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    static boolean Vulcan_P(Object[] objArr) {
        return ((Vulcan_A) objArr[0]).Vulcan_v;
    }

    static char Vulcan__(Object[] objArr) {
        return ((Vulcan_A) objArr[0]).Vulcan_y;
    }

    static char Vulcan_G(Object[] objArr) {
        return ((Vulcan_A) objArr[0]).Vulcan_k;
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [char, int] */
    public static Vulcan_A Vulcan_r(Object[] objArr) {
        ?? IntValue = ((Integer) objArr[0]).intValue();
        return new Vulcan_A(IntValue, IntValue, false);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [char, int] */
    public static Vulcan_A Vulcan_j(Object[] objArr) {
        ?? IntValue = ((Integer) objArr[0]).intValue();
        return new Vulcan_A(IntValue, IntValue, true);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [char, int] */
    /* JADX WARN: Type inference failed for: r1v7, types: [char, int] */
    public static Vulcan_A Vulcan_A(Object[] objArr) {
        return new Vulcan_A(((Integer) objArr[0]).intValue(), ((Integer) objArr[1]).intValue(), false);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [char, int] */
    /* JADX WARN: Type inference failed for: r1v7, types: [char, int] */
    public static Vulcan_A Vulcan_b(Object[] objArr) {
        return new Vulcan_A(((Integer) objArr[0]).intValue(), ((Integer) objArr[1]).intValue(), true);
    }

    public Vulcan_A(char c) {
        this(c, c, false);
    }

    public Vulcan_A(char c, boolean z) {
        this(c, c, z);
    }

    public Vulcan_A(char c, char c2) {
        this(c, c2, false);
    }

    public Vulcan_A(char c, char c2, boolean z) {
        long j = a ^ 32129554001420L;
        if (c > c2) {
            c = c2;
            c2 = c;
        }
        this.Vulcan_y = c;
        this.Vulcan_k = c2;
        this.Vulcan_v = z;
    }

    public char Vulcan_y(Object[] objArr) {
        return this.Vulcan_y;
    }

    public char Vulcan_H(Object[] objArr) {
        return this.Vulcan_k;
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public boolean m6Vulcan_A(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0054  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_z(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_A.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r6
            char r1 = r1.Vulcan_y     // Catch: java.lang.IllegalArgumentException -> L31
            r2 = r11
            if (r2 != 0) goto L4d
            if (r0 < r1) goto L54
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3e
        L35:
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L51
            goto L42
        L3e:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L42:
            r1 = r6
            char r1 = r1.Vulcan_k     // Catch: java.lang.IllegalArgumentException -> L49
            goto L4d
        L49:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L4d:
            if (r0 > r1) goto L54
            r0 = 1
        L51:
            goto L55
        L54:
            r0 = 0
        L55:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L63
            r1 = r6
            boolean r1 = r1.Vulcan_v     // Catch: java.lang.IllegalArgumentException -> L66
            if (r0 == r1) goto L6a
            r0 = 1
        L63:
            goto L6b
        L66:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L66
            throw r0
        L6a:
            r0 = 0
        L6b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_A.Vulcan_z(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public boolean m7Vulcan_y(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 417
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_A.m7Vulcan_y(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_A.a
            r1 = 129031149264735(0x755a67d11f5f, double:6.37498580951196E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_A r0 = (ac.vulcan.anticheat.Vulcan_A) r0
            r10 = r0
            r0 = r5
            char r0 = r0.Vulcan_y     // Catch: java.lang.IllegalArgumentException -> L57
            r1 = r10
            char r1 = r1.Vulcan_y     // Catch: java.lang.IllegalArgumentException -> L57
            r2 = r9
            if (r2 != 0) goto L6b
            if (r0 != r1) goto L9d
            goto L5b
        L57:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L67
            throw r0     // Catch: java.lang.IllegalArgumentException -> L67
        L5b:
            r0 = r5
            char r0 = r0.Vulcan_k     // Catch: java.lang.IllegalArgumentException -> L67
            r1 = r10
            char r1 = r1.Vulcan_k     // Catch: java.lang.IllegalArgumentException -> L67
            goto L6b
        L67:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L6b:
            r2 = r9
            if (r2 != 0) goto L96
            if (r0 != r1) goto L9d
            goto L7a
        L76:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L86
            throw r0     // Catch: java.lang.IllegalArgumentException -> L86
        L7a:
            r0 = r5
            boolean r0 = r0.Vulcan_v     // Catch: java.lang.IllegalArgumentException -> L86 java.lang.IllegalArgumentException -> L92
            r1 = r9
            if (r1 != 0) goto L9a
            goto L8a
        L86:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L92
            throw r0     // Catch: java.lang.IllegalArgumentException -> L92
        L8a:
            r1 = r10
            boolean r1 = r1.Vulcan_v     // Catch: java.lang.IllegalArgumentException -> L92
            goto L96
        L92:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L96:
            if (r0 != r1) goto L9d
            r0 = 1
        L9a:
            goto L9e
        L9d:
            r0 = 0
        L9e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_A.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v7, types: [int] */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r1v9 */
    public int hashCode() {
        long j = a ^ 140205734855110L;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            Vulcan_k = 'S' + this.Vulcan_y + (7 * this.Vulcan_k);
            boolean z = this.Vulcan_v;
            ?? r1 = z;
            if (Vulcan_k == 0) {
                r1 = z ? 1 : 0;
            }
            return Vulcan_k + r1;
        } catch (IllegalArgumentException unused) {
            throw a(Vulcan_k);
        }
    }

    /*  JADX ERROR: ConcurrentModificationException in pass: ConstructorVisitor
        java.util.ConcurrentModificationException
        	at java.base/java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1096)
        	at java.base/java.util.ArrayList$Itr.next(ArrayList.java:1050)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:139)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_A.toString():java.lang.String");
    }

    public Iterator Vulcan_Z(Object[] objArr) {
        return new Vulcan_Op(this, null);
    }
}
