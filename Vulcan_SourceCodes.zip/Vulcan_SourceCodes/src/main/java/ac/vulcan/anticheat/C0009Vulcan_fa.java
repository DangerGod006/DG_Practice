package ac.vulcan.anticheat;

import java.util.Random;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fa, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fa.class */
public class C0009Vulcan_fa {
    public static final Random Vulcan_d = new Vulcan_fH();

    public static int Vulcan_O(Object[] objArr) {
        return Vulcan_m(new Object[]{Vulcan_d});
    }

    public static int Vulcan_m(Object[] objArr) {
        return ((Random) objArr[0]).nextInt();
    }

    public static int Vulcan_z(Object[] objArr) {
        return Vulcan_l(new Object[]{Vulcan_d, new Integer(((Integer) objArr[0]).intValue())});
    }

    public static int Vulcan_l(Object[] objArr) {
        return ((Random) objArr[0]).nextInt(((Integer) objArr[1]).intValue());
    }

    public static long Vulcan_x(Object[] objArr) {
        return Vulcan_a(new Object[]{Vulcan_d});
    }

    public static long Vulcan_a(Object[] objArr) {
        return ((Random) objArr[0]).nextLong();
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public static boolean m378Vulcan_m(Object[] objArr) {
        return Vulcan_D(new Object[]{Vulcan_d});
    }

    public static boolean Vulcan_D(Object[] objArr) {
        return ((Random) objArr[0]).nextBoolean();
    }

    public static float Vulcan_I(Object[] objArr) {
        return Vulcan_W(new Object[]{Vulcan_d});
    }

    public static float Vulcan_W(Object[] objArr) {
        return ((Random) objArr[0]).nextFloat();
    }

    public static double Vulcan_u(Object[] objArr) {
        return Vulcan_v(new Object[]{Vulcan_d});
    }

    public static double Vulcan_v(Object[] objArr) {
        return ((Random) objArr[0]).nextDouble();
    }
}
