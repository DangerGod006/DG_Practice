package ac.vulcan.anticheat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_kv, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kv.class */
class C0028Vulcan_kv {
    final Map Vulcan_y;
    final Map Vulcan_L;
    final List Vulcan_m;
    final List Vulcan_k;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-4635758415539451165L, -7151497671012168516L, null).a(53676501522619L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    protected C0028Vulcan_kv() {
        long j = a ^ 79964401625401L;
        ?? Vulcan_d = Vulcan_yy.Vulcan_d();
        this.Vulcan_y = new HashMap();
        this.Vulcan_L = Collections.unmodifiableMap(this.Vulcan_y);
        this.Vulcan_m = new ArrayList(25);
        try {
            this.Vulcan_k = Collections.unmodifiableList(this.Vulcan_m);
            if (Vulcan_d != 0) {
                Vulcan_d = new AbstractCheck[4];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_d);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_d);
        }
    }
}
