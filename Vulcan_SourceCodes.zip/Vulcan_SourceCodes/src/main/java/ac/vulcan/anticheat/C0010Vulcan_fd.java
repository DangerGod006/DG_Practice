package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_fd, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fd.class */
final class C0010Vulcan_fd extends Vulcan_fV {
    private static final long serialVersionUID = 1;

    C0010Vulcan_fd() {
        Vulcan_y(new Object[]{new Boolean(false)});
    }

    private Object readResolve() {
        return Vulcan_fV.Vulcan_f;
    }
}
