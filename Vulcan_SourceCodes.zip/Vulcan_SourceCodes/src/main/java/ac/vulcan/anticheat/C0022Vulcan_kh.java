package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_kh, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kh.class */
public class C0022Vulcan_kh extends Vulcan_k5 {
    private static final long serialVersionUID = 4029025366392702726L;

    public C0022Vulcan_kh() {
    }

    public C0022Vulcan_kh(String str) {
        super(str);
    }

    public C0022Vulcan_kh(Throwable th) {
        super(th);
    }

    public C0022Vulcan_kh(String str, Throwable th) {
        super(str, th);
    }
}
