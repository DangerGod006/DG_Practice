package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_On, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_On.class */
public class C0003Vulcan_On extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = -2135791679;
    private short Vulcan_l;
    private static boolean Vulcan__;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-3337482445329656884L, -6073335510755135891L, null).a(262890340113000L);

    public static void Vulcan_m(boolean z) {
        Vulcan__ = z;
    }

    public static boolean Vulcan_w() {
        return Vulcan__;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_n() {
        return !Vulcan_w();
    }

    static {
        if (Vulcan_w()) {
            Vulcan_m(true);
        }
    }

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public C0003Vulcan_On() {
    }

    public C0003Vulcan_On(short s) {
        this.Vulcan_l = s;
    }

    public C0003Vulcan_On(Number number) {
        this.Vulcan_l = number.shortValue();
    }

    public C0003Vulcan_On(String str) {
        this.Vulcan_l = Short.parseShort(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Short(this.Vulcan_l);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [int, short] */
    public void Vulcan_j(Object[] objArr) {
        this.Vulcan_l = ((Integer) objArr[0]).intValue();
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        Vulcan_j(new Object[]{new Integer(((Number) objArr[0]).shortValue())});
    }

    public void Vulcan_L(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l + 1);
    }

    public void Vulcan_C(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l - 1);
    }

    public void Vulcan_i(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l + ((Integer) objArr[0]).intValue());
    }

    public void Vulcan_l(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l + ((Number) objArr[0]).shortValue());
    }

    public void Vulcan_o(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l - ((Integer) objArr[0]).intValue());
    }

    public void Vulcan_u(Object[] objArr) {
        this.Vulcan_l = (short) (this.Vulcan_l - ((Number) objArr[0]).shortValue());
    }

    @Override // java.lang.Number
    public short shortValue() {
        return this.Vulcan_l;
    }

    @Override // java.lang.Number
    public int intValue() {
        return this.Vulcan_l;
    }

    @Override // java.lang.Number
    public long longValue() {
        return this.Vulcan_l;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_l;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_l;
    }

    public Short Vulcan_G(Object[] objArr) {
        return new Short(shortValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean, short] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    public boolean equals(Object obj) {
        long j = a ^ 100701632660739L;
        NumberFormatException numberFormatExceptionVulcan_w = Vulcan_w();
        try {
            try {
                try {
                    numberFormatExceptionVulcan_w = obj instanceof C0003Vulcan_On;
                    try {
                        if (numberFormatExceptionVulcan_w != 0) {
                            return numberFormatExceptionVulcan_w;
                        }
                        if (numberFormatExceptionVulcan_w != 0) {
                            ?? r0 = this.Vulcan_l;
                            return numberFormatExceptionVulcan_w == 0 ? r0 == ((C0003Vulcan_On) obj).shortValue() : r0;
                        }
                        return false;
                    } catch (NumberFormatException unused) {
                        throw a(numberFormatExceptionVulcan_w);
                    }
                } catch (NumberFormatException unused2) {
                    throw a(numberFormatExceptionVulcan_w);
                }
            } catch (NumberFormatException unused3) {
                throw a(numberFormatExceptionVulcan_w);
            }
        } catch (NumberFormatException unused4) {
            throw a(numberFormatExceptionVulcan_w);
        }
    }

    public int hashCode() {
        return this.Vulcan_l;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [short] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [int, short] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.NumberFormatException, java.lang.Throwable] */
    @Override // java.lang.Comparable
    public int compareTo(Object obj) {
        long j = a ^ 17356135428278L;
        ?? Vulcan_w = Vulcan_w();
        short s = ((C0003Vulcan_On) obj).Vulcan_l;
        try {
            try {
                Vulcan_w = this.Vulcan_l;
                short s2 = s;
                ?? r0 = Vulcan_w;
                if (Vulcan_w == 0) {
                    if (Vulcan_w < s2) {
                        return -1;
                    }
                    try {
                        Vulcan_w = this.Vulcan_l;
                        if (Vulcan_w != 0) {
                            return Vulcan_w;
                        }
                        s2 = s;
                        r0 = Vulcan_w;
                    } catch (NumberFormatException unused) {
                        throw a(Vulcan_w);
                    }
                }
                return r0 == s2 ? 0 : 1;
            } catch (NumberFormatException unused2) {
                throw a(Vulcan_w);
            }
        } catch (NumberFormatException unused3) {
            Vulcan_w = a(Vulcan_w);
            throw Vulcan_w;
        }
    }

    public String toString() {
        return String.valueOf((int) this.Vulcan_l);
    }
}
