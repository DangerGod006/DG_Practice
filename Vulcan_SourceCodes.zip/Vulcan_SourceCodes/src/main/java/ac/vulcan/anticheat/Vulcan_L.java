package ac.vulcan.anticheat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_L.class */
class Vulcan_L {
    final Map Vulcan_E;
    final Map Vulcan_i;
    final List Vulcan_e;
    final List Vulcan_P;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6553195061655366868L, 6326137351244107780L, null).a(221691041206666L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.String] */
    protected Vulcan_L() {
        long j = a ^ 69302113065430L;
        ?? Vulcan_p = Vulcan_fK.Vulcan_p();
        this.Vulcan_E = new HashMap();
        this.Vulcan_i = Collections.unmodifiableMap(this.Vulcan_E);
        try {
            this.Vulcan_e = new ArrayList(25);
            this.Vulcan_P = Collections.unmodifiableList(this.Vulcan_e);
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_p = "z0wHX";
                Vulcan_fK.Vulcan_X("z0wHX");
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_p);
        }
    }
}
