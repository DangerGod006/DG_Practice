package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kD.class */
final class Vulcan_kD extends Vulcan_kH {
    Vulcan_kD() {
    }

    @Override // ac.vulcan.anticheat.Vulcan_kH
    /* JADX INFO: renamed from: Vulcan_A */
    public int mo437Vulcan_A(Object[] objArr) {
        ((Integer) objArr[1]).intValue();
        ((Integer) objArr[2]).intValue();
        ((Integer) objArr[3]).intValue();
        ((Long) objArr[4]).longValue();
        return 0;
    }
}
