package ac.vulcan.anticheat;

import java.lang.invoke.MethodHandles;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import org.bukkit.Bukkit;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_H.class */
public interface Vulcan_H {
    public static final long b = me.frep.vulcan.spigot.Vulcan_n.a(7454009809385406670L, -1336921721128098399L, MethodHandles.lookup().lookupClass()).a(10177053596965L);

    boolean Vulcan_d(Object[] objArr);

    boolean Vulcan_D(Object[] objArr);

    boolean Vulcan_V(Object[] objArr);

    Vulcan_t Vulcan_C(Object[] objArr);

    Vulcan_t Vulcan_o(Object[] objArr);

    Vulcan_t Vulcan_w(Object[] objArr);

    Vulcan_t Vulcan_E(Object[] objArr);

    Vulcan_t Vulcan_n(Object[] objArr);

    Vulcan_t Vulcan_H(Object[] objArr);

    void Vulcan_F(Object[] objArr);

    void Vulcan_Q(Object[] objArr);

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    void mo32Vulcan_V(Object[] objArr);

    default boolean Vulcan_y(Object[] objArr) {
        return Bukkit.getServer().isPrimaryThread();
    }

    @Deprecated
    default Vulcan_t Vulcan_e(Object[] objArr) {
        return Vulcan_C(new Object[]{(Runnable) objArr[1]});
    }

    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_H, java.lang.Object[]] */
    @Deprecated
    default Vulcan_t Vulcan_W(Object[] objArr) {
        ?? r1 = (Runnable) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        long jLongValue2 = ((Long) objArr[3]).longValue() ^ 85969214310763L;
        ?? r4 = new Object[3];
        r1[2] = Long.valueOf(jLongValue);
        r4[1] = r4;
        this[0] = Long.valueOf(jLongValue2);
        return r4.Vulcan_o(r4);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r1v17, types: [long] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[], long] */
    @Deprecated
    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    default Vulcan_t mo28Vulcan_d(Object[] objArr) {
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? r1 = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        ?? r5 = new Object[4];
        ((Long) objArr[4]).longValue()[3] = Long.valueOf(jLongValue ^ 59559152691953L);
        LongValue[2] = Long.valueOf((long) r5);
        r1[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return Vulcan_w((Object[]) r5);
    }

    default Vulcan_t Vulcan_A(Object[] objArr) {
        return Vulcan_C(new Object[]{(Runnable) objArr[1]});
    }

    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_H, java.lang.Object[]] */
    default Vulcan_t Vulcan_s(Object[] objArr) {
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? r4 = new Object[3];
        ((Runnable) objArr[2])[2] = Long.valueOf(((Long) objArr[3]).longValue());
        r4[1] = r4;
        this[0] = Long.valueOf(jLongValue ^ 130799601499588L);
        return r4.Vulcan_o(r4);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r1v17, types: [long] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[], long] */
    default Vulcan_t Vulcan_z(Object[] objArr) {
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? r1 = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        ?? r5 = new Object[4];
        ((Long) objArr[4]).longValue()[3] = Long.valueOf(jLongValue ^ 92277421795620L);
        LongValue[2] = Long.valueOf((long) r5);
        r1[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return Vulcan_w((Object[]) r5);
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_H, java.lang.Object[]] */
    @Deprecated
    default Vulcan_t Vulcan_l(Object[] objArr) {
        ?? r1 = (Runnable) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long jLongValue2 = (b ^ ((Long) objArr[2]).longValue()) ^ 115483277707937L;
        ?? r4 = new Object[3];
        r1[2] = Long.valueOf(jLongValue);
        r4[1] = r4;
        this[0] = Long.valueOf(jLongValue2);
        return r4.Vulcan_o(r4);
    }

    @Deprecated
    default Vulcan_t Vulcan_m(Object[] objArr) {
        return Vulcan_C(new Object[]{(Runnable) objArr[0]});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10, types: [long] */
    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r1v6, types: [long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[], long] */
    @Deprecated
    default Vulcan_t Vulcan_b(Object[] objArr) {
        ?? r1 = (Runnable) objArr[0];
        ?? LongValue = ((Long) objArr[1]).longValue();
        ?? r5 = new Object[4];
        ((Long) objArr[2]).longValue()[3] = Long.valueOf((b ^ ((Long) objArr[3]).longValue()) ^ 131612328178116L);
        LongValue[2] = Long.valueOf((long) r5);
        r1[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return Vulcan_w((Object[]) r5);
    }

    default Vulcan_t Vulcan_P(Object[] objArr) {
        return Vulcan_C(new Object[]{(Runnable) objArr[1]});
    }

    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_H, java.lang.Object[]] */
    default Vulcan_t Vulcan_Z(Object[] objArr) {
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? r4 = new Object[3];
        ((Runnable) objArr[2])[2] = Long.valueOf(((Long) objArr[3]).longValue());
        r4[1] = r4;
        this[0] = Long.valueOf(jLongValue ^ 119988703295111L);
        return r4.Vulcan_o(r4);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v13, types: [long] */
    /* JADX WARN: Type inference failed for: r1v17, types: [long] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[], long] */
    default Vulcan_t Vulcan_k(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        ?? r1 = (Runnable) objArr[2];
        ?? LongValue = ((Long) objArr[3]).longValue();
        ?? r5 = new Object[4];
        ((Long) objArr[4]).longValue()[3] = Long.valueOf(jLongValue ^ 61481473173581L);
        LongValue[2] = Long.valueOf((long) r5);
        r1[1] = Long.valueOf((long) r5);
        r5[0] = r5;
        return Vulcan_w((Object[]) r5);
    }

    @Deprecated
    default Vulcan_t Vulcan_T(Object[] objArr) {
        return Vulcan_E(new Object[]{(Runnable) objArr[1]});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r1v9, types: [long] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[], long] */
    @Deprecated
    default Vulcan_t Vulcan_O(Object[] objArr) {
        ?? r1 = (Runnable) objArr[1];
        ?? r4 = new Object[3];
        ((Long) objArr[2]).longValue()[2] = Long.valueOf(((Long) objArr[3]).longValue() ^ 131281445873919L);
        r1[1] = Long.valueOf((long) r4);
        r4[0] = r4;
        return Vulcan_n(r4);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r1v9, types: [long] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[], long] */
    @Deprecated
    default Vulcan_t Vulcan_q(Object[] objArr) {
        ?? r1 = (Runnable) objArr[1];
        ?? LongValue = ((Long) objArr[2]).longValue();
        long jLongValue = ((Long) objArr[3]).longValue();
        ((Long) objArr[4]).longValue();
        ?? r4 = new Object[3];
        LongValue[2] = Long.valueOf(jLongValue);
        r1[1] = Long.valueOf((long) r4);
        r4[0] = r4;
        return Vulcan_H(r4);
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    default Future m29Vulcan_b(Object[] objArr) {
        Callable callable = (Callable) objArr[0];
        CompletableFuture completableFuture = new CompletableFuture();
        Vulcan_F(new Object[]{() -> {
            lambda$callSyncMethod$0(r1, r2);
        }});
        return completableFuture;
    }

    private static void lambda$callSyncMethod$0(CompletableFuture completableFuture, Callable callable) {
        try {
            completableFuture.complete(callable.call());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    default void mo30Vulcan_s(Object[] objArr) {
        Vulcan_F(new Object[]{(Runnable) objArr[1]});
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    default void mo31Vulcan_w(Object[] objArr) {
        Vulcan_F(new Object[]{(Runnable) objArr[1]});
    }
}
