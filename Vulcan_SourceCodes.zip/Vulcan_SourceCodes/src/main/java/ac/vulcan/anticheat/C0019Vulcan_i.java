package ac.vulcan.anticheat;

import java.util.HashMap;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_i.class */
class C0019Vulcan_i extends AbstractC0032Vulcan_p {
    public C0019Vulcan_i() {
        super(new HashMap(), new HashMap());
    }
}
