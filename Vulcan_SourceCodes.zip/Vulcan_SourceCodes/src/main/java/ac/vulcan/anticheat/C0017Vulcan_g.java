package ac.vulcan.anticheat;

import java.lang.reflect.Field;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_g.class */
public class C0017Vulcan_g extends Vulcan_F {
    private boolean Vulcan_j;
    private boolean Vulcan_H;
    private String[] Vulcan_A;
    private Class Vulcan_I;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6305183337872300617L, 9051020061521703850L, null).a(115505061829974L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0052: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    static java.lang.String[] Vulcan_r(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 29107503907698(0x1a791e6e4372, double:1.43810177169834E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r14 = r0
            r0 = r11
            r1 = r14
            if (r1 == 0) goto L40
            if (r0 != 0) goto L3f
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3b
        L37:
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_X     // Catch: java.lang.IllegalArgumentException -> L3b
            return r0
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3b
            throw r0
        L3f:
            r0 = r11
        L40:
            java.lang.Object[] r0 = r0.toArray()
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = m414Vulcan_U(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_r(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0073, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0077, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007f, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0060, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 92;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0070, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0073). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.m413clinit():void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    public static String Vulcan_F(Object[] objArr) {
        return Vulcan_R(new Object[]{objArr[0], null, new Boolean(false), new Boolean(false), null});
    }

    public static String Vulcan_v(Object[] objArr) {
        return Vulcan_R(new Object[]{objArr[0], (Vulcan_fV) objArr[1], new Boolean(false), new Boolean(false), null});
    }

    public static String Vulcan_U(Object[] objArr) {
        return Vulcan_R(new Object[]{objArr[0], (Vulcan_fV) objArr[1], new Boolean(((Boolean) objArr[2]).booleanValue()), new Boolean(false), null});
    }

    public static String Vulcan_i(Object[] objArr) {
        return Vulcan_R(new Object[]{objArr[0], (Vulcan_fV) objArr[1], new Boolean(((Boolean) objArr[2]).booleanValue()), new Boolean(((Boolean) objArr[3]).booleanValue()), null});
    }

    public static String Vulcan_R(Object[] objArr) {
        return new C0017Vulcan_g(objArr[0], (Vulcan_fV) objArr[1], null, (Class) objArr[4], ((Boolean) objArr[2]).booleanValue(), ((Boolean) objArr[3]).booleanValue()).toString();
    }

    public static String Vulcan_y(Object[] objArr) {
        return new C0017Vulcan_g(objArr[0], (Vulcan_fV) objArr[1], null, (Class) objArr[3], ((Boolean) objArr[2]).booleanValue()).toString();
    }

    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_Z(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 33441707899717(0x1e6a411ebb45, double:1.6522399011508E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            r1 = 1
            java.lang.String[] r1 = new java.lang.String[r1]
            r2 = r1
            r3 = 0
            r4 = r11
            r2[r3] = r4
            r2 = r15
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_Z(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0062: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0062: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_J(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r15 = r1
            r0 = r11
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r12
            r2 = 32
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.C0017Vulcan_g.a
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 66502804868818(0x3c7be40f8ed2, double:3.2856751237767E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r1 = r0; r2 = r0; 
            r2 = 135618913751065(0x7b583d2dd019, double:6.7004646210708E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r14
            r1 = r15
            r2 = r18
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String[] r1 = Vulcan_r(r1)
            r2 = r20
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_J(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:13:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x007d A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0072 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:36:? A[LOOP:0: B:3:0x002c->B:36:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r14v0, types: [java.lang.Exception, java.lang.Object] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x007a -> B:10:0x0042). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static java.lang.String[] m414Vulcan_U(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            java.util.ArrayList r1 = new java.util.ArrayList
            r2 = r1
            r3 = r10
            int r3 = r3.length
            r2.<init>(r3)
            r12 = r1
            r11 = r0
            r0 = 0
            r13 = r0
        L2c:
            r0 = r13
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L75
            r0 = r10
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L41
            if (r1 == 0) goto L83
            r1 = r13
        L41:
            r0 = r0[r1]
        L42:
            r14 = r0
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L72
            if (r0 == 0) goto L70
            r0 = r14
            if (r0 == 0) goto L6d
            goto L5b
        L57:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L69
            throw r0     // Catch: java.lang.IllegalArgumentException -> L69
        L5b:
            r0 = r12
            r1 = r14
            java.lang.String r1 = r1.toString()     // Catch: java.lang.IllegalArgumentException -> L69
            boolean r0 = r0.add(r1)     // Catch: java.lang.IllegalArgumentException -> L69
            goto L6d
        L69:
            java.lang.Exception r0 = a(r0)
            throw r0
        L6d:
            int r13 = r13 + 1
        L70:
            r0 = r11
        L72:
            if (r0 != 0) goto L2c
        L75:
            r0 = r12
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L42
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_X
            java.lang.Object[] r0 = r0.toArray(r1)
        L83:
            java.lang.String[] r0 = (java.lang.String[]) r0
            java.lang.String[] r0 = (java.lang.String[]) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.m414Vulcan_U(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_q(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 121667392230469(0x6ea7e5b1d445, double:6.0111678720167E-310)
            long r1 = r1 ^ r2
            r15 = r1
            ac.vulcan.anticheat.Vulcan_g r0 = new ac.vulcan.anticheat.Vulcan_g
            r1 = r0
            r2 = r14
            r1.<init>(r2)
            r1 = r13
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_g r0 = r0.Vulcan_V(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_q(java.lang.Object[]):java.lang.String");
    }

    public C0017Vulcan_g(Object obj) {
        super(obj);
        this.Vulcan_j = false;
        this.Vulcan_H = false;
        this.Vulcan_I = null;
    }

    public C0017Vulcan_g(Object obj, Vulcan_fV vulcan_fV) {
        super(obj, vulcan_fV);
        this.Vulcan_j = false;
        this.Vulcan_H = false;
        this.Vulcan_I = null;
    }

    public C0017Vulcan_g(Object obj, Vulcan_fV vulcan_fV, StringBuffer stringBuffer) {
        super(obj, vulcan_fV, stringBuffer);
        this.Vulcan_j = false;
        this.Vulcan_H = false;
        this.Vulcan_I = null;
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0040: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0040: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public C0017Vulcan_g(java.lang.Object r11, ac.vulcan.anticheat.Vulcan_fV r12, java.lang.StringBuffer r13, java.lang.Class r14, boolean r15) {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = 31708375013242(0x1cd6ae6dd77a, double:1.5666018779494E-310)
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 132395201881017(0x7869a8fa63b9, double:6.5411920923627E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r10
            r1 = r11
            r2 = r12
            r3 = r13
            r0.<init>(r1, r2, r3)
            r0 = r10
            r1 = 0
            r0.Vulcan_j = r1
            r0 = r10
            r1 = 0
            r0.Vulcan_H = r1
            r0 = r10
            r1 = 0
            r0.Vulcan_I = r1
            r0 = r10
            r1 = r14
            r2 = r18
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_k(r1)
            r0 = r10
            r1 = r15
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.m418Vulcan_i(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.<init>(java.lang.Object, ac.vulcan.anticheat.Vulcan_fV, java.lang.StringBuffer, java.lang.Class, boolean):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_g] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public C0017Vulcan_g(java.lang.Object r12, ac.vulcan.anticheat.Vulcan_fV r13, java.lang.StringBuffer r14, java.lang.Class r15, boolean r16, boolean r17) {
        /*
            r11 = this;
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = 27289274387357(0x18d1c7818b9d, double:1.34826929747285E-310)
            long r0 = r0 ^ r1
            r18 = r0
            r0 = r18
            r1 = r0; r1 = r0; 
            r2 = 136815127707486(0x7c6ec1163f5e, double:6.75956544316517E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r0.<init>(r1, r2, r3)
            r0 = r11
            r1 = 0
            r0.Vulcan_j = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r1 = r11
            r2 = 0
            r1.Vulcan_H = r2
            r1 = r11
            r2 = 0
            r1.Vulcan_I = r2
            r1 = r11
            r2 = r15
            r3 = r20
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r1.Vulcan_k(r2)
            r22 = r0
            r0 = r11
            r1 = r16
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            r0.m418Vulcan_i(r1)     // Catch: java.lang.IllegalArgumentException -> L8d
            r0 = r11
            r1 = r17
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L8d
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L8d
            java.lang.Boolean r4 = new java.lang.Boolean     // Catch: java.lang.IllegalArgumentException -> L8d
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L8d
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L8d
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L8d
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L8d
            r0.Vulcan_I(r1)     // Catch: java.lang.IllegalArgumentException -> L8d
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_k()     // Catch: java.lang.IllegalArgumentException -> L8d
            if (r0 == 0) goto L91
            int r22 = r22 + 1
            r0 = r22
            ac.vulcan.anticheat.Vulcan_fl.Vulcan_p(r0)     // Catch: java.lang.IllegalArgumentException -> L8d
            goto L91
        L8d:
            java.lang.Exception r0 = a(r0)
            throw r0
        L91:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.<init>(java.lang.Object, ac.vulcan.anticheat.Vulcan_fV, java.lang.StringBuffer, java.lang.Class, boolean, boolean):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected boolean Vulcan_o(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 286
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_o(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Long, java.lang.reflect.Field] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v29, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r10v0, types: [ac.vulcan.anticheat.Vulcan_g] */
    /* JADX WARN: Type inference failed for: r2v26, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_g, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v22, types: [ac.vulcan.anticheat.Vulcan_g, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v29, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v7 ??, still in use, count: 2, list:
          (r5v7 ?? I:??[OBJECT, ARRAY][]) from 0x00c0: APUT (r5v7 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v7 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalAccessException -> 0x00cf]
          (r5v7 ?? I:??[OBJECT, ARRAY]) from 0x00c0: APUT (r5v7 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v7 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalAccessException -> 0x00cf]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_w(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 316
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_w(java.lang.Object[]):void");
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public String[] m415Vulcan_q(Object[] objArr) {
        return this.Vulcan_A;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public Class m416Vulcan_r(Object[] objArr) {
        return this.Vulcan_I;
    }

    protected Object Vulcan_x(Object[] objArr) {
        return ((Field) objArr[0]).get(Vulcan_T(new Object[0]));
    }

    public boolean Vulcan__(Object[] objArr) {
        return this.Vulcan_j;
    }

    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_H;
    }

    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004a: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004a: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m417Vulcan_y(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 130878887256910(0x77089d95634e, double:6.4662761959569E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_n(r1)
            r1 = r12
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.StringBuffer r1 = r1.Vulcan__(r2)
            r2 = 0
            r3 = r16
            r4 = r17
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_kn(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.m417Vulcan_y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    public void Vulcan_I(Object[] objArr) {
        this.Vulcan_j = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public void m418Vulcan_i(Object[] objArr) {
        this.Vulcan_H = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_g, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0069: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0077]
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0069: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0077]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_F
    public ac.vulcan.anticheat.C0017Vulcan_g Vulcan_V(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 25596046062190(0x17478b3bb26e, double:1.2646127028698E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 != 0) goto L7b
            if (r0 != 0) goto L4e
            goto L37
        L33:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4a
        L37:
            r0 = r9
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L7f
            r1 = 0
            r0.Vulcan_A = r1     // Catch: java.lang.IllegalArgumentException -> L4a java.lang.IllegalArgumentException -> L77
            r0 = r16
            if (r0 == 0) goto L7e
            goto L4e
        L4a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L77
            throw r0     // Catch: java.lang.IllegalArgumentException -> L77
        L4e:
            r0 = r9
            r1 = r14
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.IllegalArgumentException -> L77
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.IllegalArgumentException -> L77
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L77
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L77
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L77
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L77
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L77
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L77
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L77
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L77
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L77
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L77
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L77
            java.lang.String[] r1 = m414Vulcan_U(r1)     // Catch: java.lang.IllegalArgumentException -> L77
            r0.Vulcan_A = r1     // Catch: java.lang.IllegalArgumentException -> L77
            r0 = r9
            java.lang.String[] r0 = r0.Vulcan_A     // Catch: java.lang.IllegalArgumentException -> L77
            goto L7b
        L77:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7b:
            java.util.Arrays.sort(r0)
        L7e:
            r0 = r9
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_V(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_g");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:8:0x002c
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_k(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r10 = r0
            r0 = r10
            if (r0 == 0) goto L79
            r0 = r9
            if (r0 == 0) goto L73
            goto L30
        L2c:
            java.lang.Exception r0 = a(r0)
            throw r0
        L30:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Object r0 = r0.Vulcan_T(r1)
            r11 = r0
            r0 = r10
            if (r0 == 0) goto L79
            r0 = r11
            if (r0 == 0) goto L73
            goto L4b
        L47:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5e
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5e
        L4b:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L79
            r0 = r9
            r1 = r11
            boolean r0 = r0.isInstance(r1)     // Catch: java.lang.IllegalArgumentException -> L5e java.lang.IllegalArgumentException -> L6f
            if (r0 != 0) goto L73
            goto L62
        L5e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6f
        L62:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L6f
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.C0017Vulcan_g.d     // Catch: java.lang.IllegalArgumentException -> L6f
            r3 = 0
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L6f
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L6f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6f
        L6f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6f
            throw r0
        L73:
            r0 = r5
            r1 = r9
            r0.Vulcan_I = r1
        L79:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_k(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v2 */
    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_g, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v10, types: [ac.vulcan.anticheat.Vulcan_g, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0068: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0068: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_F
    public java.lang.String toString() {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0017Vulcan_g.a
            r1 = 125847157500427(0x7275131e6a0b, double:6.21767571477335E-310)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 133254328975284(0x7931b0f17fb4, double:6.58363861063156E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r14 = r0
            r0 = r9
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> L28
            java.lang.Object r0 = r0.Vulcan_T(r1)     // Catch: java.lang.IllegalArgumentException -> L28
            r1 = r14
            if (r1 == 0) goto L48
            if (r0 != 0) goto L40
            goto L2c
        L28:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3c
        L2c:
            r0 = r9
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> L3c
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_n(r1)     // Catch: java.lang.IllegalArgumentException -> L3c
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> L3c
            java.lang.String r0 = r0.mo221Vulcan_D(r1)     // Catch: java.lang.IllegalArgumentException -> L3c
            return r0
        L3c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0
        L40:
            r0 = r9
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Object r0 = r0.Vulcan_T(r1)
        L48:
            java.lang.Class r0 = r0.getClass()
            r15 = r0
            r0 = r9
            r1 = r12
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
        L6c:
            r0 = r15
            java.lang.Class r0 = r0.getSuperclass()
            if (r0 == 0) goto Lbf
            r0 = r15
            r1 = r14
            if (r1 == 0) goto L99
            r1 = r9
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L89 java.lang.IllegalArgumentException -> L95
            java.lang.Class r1 = r1.m416Vulcan_r(r2)     // Catch: java.lang.IllegalArgumentException -> L89 java.lang.IllegalArgumentException -> L95
            if (r0 == r1) goto Lbf
            goto L8d
        L89:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L95
            throw r0     // Catch: java.lang.IllegalArgumentException -> L95
        L8d:
            r0 = r15
            java.lang.Class r0 = r0.getSuperclass()     // Catch: java.lang.IllegalArgumentException -> L95
            goto L99
        L95:
            java.lang.Exception r0 = a(r0)
            throw r0
        L99:
            r15 = r0
            r0 = r9
            r1 = r12
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            r0 = r14
            if (r0 != 0) goto L6c
        Lbf:
            r0 = r9
            java.lang.String r0 = super.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0017Vulcan_g.toString():java.lang.String");
    }
}
