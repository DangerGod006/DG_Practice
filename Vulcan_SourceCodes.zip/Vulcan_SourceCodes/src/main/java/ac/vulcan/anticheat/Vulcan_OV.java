package ac.vulcan.anticheat;

import java.io.PrintStream;
import java.io.PrintWriter;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OV.class */
public interface Vulcan_OV {
    Throwable getCause();

    String getMessage();

    String Vulcan_Q(Object[] objArr);

    String[] Vulcan_o(Object[] objArr);

    Throwable Vulcan_i(Object[] objArr);

    int Vulcan_K(Object[] objArr);

    Throwable[] Vulcan_U(Object[] objArr);

    int Vulcan_y(Object[] objArr);

    int Vulcan_E(Object[] objArr);

    void printStackTrace(PrintWriter printWriter);

    void printStackTrace(PrintStream printStream);

    void Vulcan_G(Object[] objArr);
}
