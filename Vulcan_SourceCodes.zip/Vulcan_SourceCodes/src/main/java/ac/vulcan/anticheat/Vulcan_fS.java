package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fS.class */
public class Vulcan_fS {
    private static final int Vulcan_W = 0;
    private static final int Vulcan_x = 1;
    private static final int Vulcan_f = 2;
    private static final int Vulcan_r = 3;
    private static final int Vulcan_m = 10;
    private static final int Vulcan_t = 11;
    private int Vulcan_l = 0;
    private int Vulcan_F = 10;
    private long Vulcan_S = -1;
    private long Vulcan_C = -1;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(3679139931422834659L, 7853374372027540731L, null).a(129008676759555L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0044: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String toString() {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fS.a
            r1 = 9973833252940(0x91236c9c04c, double:4.9277283676267E-311)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 99865481034658(0x5ad3be85bba2, double:4.9340103384635E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 57570683703317(0x345c3826d015, double:2.84436970254014E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            r1 = r15
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            long r0 = r0.Vulcan_V(r1)
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_D.Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.toString():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0050: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String Vulcan_n(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fS.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 72318265810163(0x41c5e88b5cf3, double:3.5729970703617E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 9521572372667(0x8a8e9f060bb, double:4.704281803726E-311)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r10
            r1 = r14
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            long r0 = r0.Vulcan_I(r1)
            r1 = r16
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_D.Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.Vulcan_n(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0086, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0089, code lost:
    
        r11 = "\u001c1Z*\/R\u0007,-\u00157-@\u0007o'Pz+F\u0000? [>=WS;*\u0015(=@\u0006\" \u001bz\u001a\u001c1Z*\/R\u0007,-\u00153+\u0013\u001d 1\u0015(-]\u001d&+Rtx".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0092, code lost:
    
        ac.vulcan.anticheat.Vulcan_fS.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00aa, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b9, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009a, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00aa, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b9, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "\u001c1Z*\/R\u0007,-\u00157-@\u0007o'Pz+F\u0000? [>=WS;*\u0015(=@\u0006\" \u001bz\u001a\u001c1Z*\/R\u0007,-\u00153+\u0013\u001d 1\u0015(-]\u001d&+Rtx".length();
        r11 = '\'';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r10 = r10 + 1;
        "\u001c1Z*\/R\u0007,-\u00157-@\u0007o'Pz+F\u0000? [>=WS;*\u0015(=@\u0006\" \u001bz\u001a\u001c1Z*\/R\u0007,-\u00153+\u0013\u001d 1\u0015(-]\u001d&+Rtx".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ad, B:28:0x0110], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0115 -> B:34:0x00ad). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.m207clinit():void");
    }

    private static IllegalStateException a(IllegalStateException illegalStateException) {
        return illegalStateException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0055 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.IllegalStateException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v20, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_E(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fS.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r9 = r0
            r0 = r5
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L27
            r1 = r9
            if (r1 != 0) goto L52
            r1 = 2
            if (r0 != r1) goto L3c
            goto L2b
        L27:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L38
            throw r0     // Catch: java.lang.IllegalStateException -> L38
        L2b:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch: java.lang.IllegalStateException -> L38
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fS.b     // Catch: java.lang.IllegalStateException -> L38
            r3 = 5
            r2 = r2[r3]     // Catch: java.lang.IllegalStateException -> L38
            r1.<init>(r2)     // Catch: java.lang.IllegalStateException -> L38
            throw r0     // Catch: java.lang.IllegalStateException -> L38
        L38:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L38
            throw r0
        L3c:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L79
            r0 = r5
            r1 = r9
            if (r1 != 0) goto L75
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L4e
            goto L52
        L4e:
            java.lang.IllegalStateException r0 = a(r0)
            throw r0
        L52:
            if (r0 == 0) goto L66
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch: java.lang.IllegalStateException -> L62
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fS.b     // Catch: java.lang.IllegalStateException -> L62
            r3 = 0
            r2 = r2[r3]     // Catch: java.lang.IllegalStateException -> L62
            r1.<init>(r2)     // Catch: java.lang.IllegalStateException -> L62
            throw r0     // Catch: java.lang.IllegalStateException -> L62
        L62:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L62
            throw r0
        L66:
            r0 = r5
            r1 = -1
            r0.Vulcan_C = r1
            r0 = r5
            long r1 = java.lang.System.currentTimeMillis()
            r0.Vulcan_S = r1
            r0 = r5
        L75:
            r1 = 1
            r0.Vulcan_l = r1
        L79:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.Vulcan_E(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0078 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v22, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [int] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalStateException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_K(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fS.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r11 = r0
            r0 = r7
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L27
            r1 = 1
            r2 = r11
            if (r2 != 0) goto L75
            if (r0 == r1) goto L5e
            goto L2b
        L27:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3e
            throw r0     // Catch: java.lang.IllegalStateException -> L3e
        L2b:
            r0 = r7
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L3e java.lang.IllegalStateException -> L48
            r1 = 3
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L75
            r2 = r11
            if (r2 != 0) goto L75
            goto L42
        L3e:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L48
            throw r0     // Catch: java.lang.IllegalStateException -> L48
        L42:
            if (r0 == r1) goto L5e
            goto L4c
        L48:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L5a
            throw r0     // Catch: java.lang.IllegalStateException -> L5a
        L4c:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch: java.lang.IllegalStateException -> L5a
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fS.b     // Catch: java.lang.IllegalStateException -> L5a
            r3 = 6
            r2 = r2[r3]     // Catch: java.lang.IllegalStateException -> L5a
            r1.<init>(r2)     // Catch: java.lang.IllegalStateException -> L5a
            throw r0     // Catch: java.lang.IllegalStateException -> L5a
        L5a:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L5a
            throw r0
        L5e:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L8b
            r0 = r7
            r1 = r11
            if (r1 != 0) goto L87
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L71
            r1 = 1
            goto L75
        L71:
            java.lang.IllegalStateException r0 = a(r0)
            throw r0
        L75:
            if (r0 != r1) goto L86
            r0 = r7
            long r1 = java.lang.System.currentTimeMillis()     // Catch: java.lang.IllegalStateException -> L82
            r0.Vulcan_C = r1     // Catch: java.lang.IllegalStateException -> L82
            goto L86
        L82:
            java.lang.IllegalStateException r0 = a(r0)
            throw r0
        L86:
            r0 = r7
        L87:
            r1 = 2
            r0.Vulcan_l = r1
        L8b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.Vulcan_K(java.lang.Object[]):void");
    }

    public void Vulcan_C(Object[] objArr) {
        this.Vulcan_l = 0;
        this.Vulcan_F = 10;
        this.Vulcan_S = -1L;
        this.Vulcan_C = -1L;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public void Vulcan_S(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? r0 = this;
        ?? r02 = r0;
        if (Vulcan_G.Vulcan_Y() == null) {
            try {
                try {
                    r0 = r0.Vulcan_l;
                    if (r0 != 1) {
                        throw new IllegalStateException(b[9]);
                    }
                    this.Vulcan_C = System.currentTimeMillis();
                    r02 = this;
                } catch (IllegalStateException unused) {
                    throw a(r0);
                }
            } catch (IllegalStateException unused2) {
                throw a(r0);
            }
        }
        r02.Vulcan_F = Vulcan_t;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public void Vulcan_e(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? r0 = this;
        ?? r02 = r0;
        if (Vulcan_G.Vulcan_Y() == null) {
            try {
                try {
                    r0 = r0.Vulcan_F;
                    if (r0 != Vulcan_t) {
                        throw new IllegalStateException(b[4]);
                    }
                    this.Vulcan_C = -1L;
                    r02 = this;
                } catch (IllegalStateException unused) {
                    throw a(r0);
                }
            } catch (IllegalStateException unused2) {
                throw a(r0);
            }
        }
        r02.Vulcan_F = 10;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public void Vulcan_g(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? r0 = this;
        ?? r02 = r0;
        if (Vulcan_G.Vulcan_Y() == null) {
            try {
                try {
                    r0 = r0.Vulcan_l;
                    if (r0 != 1) {
                        throw new IllegalStateException(b[3]);
                    }
                    this.Vulcan_C = System.currentTimeMillis();
                    r02 = this;
                } catch (IllegalStateException unused) {
                    throw a(r0);
                }
            } catch (IllegalStateException unused2) {
                throw a(r0);
            }
        }
        r02.Vulcan_l = 3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v14, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public void Vulcan_m(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? r0 = this;
        ?? r02 = r0;
        if (Vulcan_G.Vulcan_Y() == null) {
            try {
                try {
                    r0 = r0.Vulcan_l;
                    if (r0 != 3) {
                        throw new IllegalStateException(b[8]);
                    }
                    this.Vulcan_S += System.currentTimeMillis() - this.Vulcan_C;
                    this.Vulcan_C = -1L;
                    r02 = this;
                } catch (IllegalStateException unused) {
                    throw a(r0);
                }
            } catch (IllegalStateException unused2) {
                throw a(r0);
            }
        }
        r02.Vulcan_l = 1;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public long Vulcan_V(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fS.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_G.Vulcan_Y()
            r11 = r0
            r0 = r7
            r1 = r11
            if (r1 != 0) goto L54
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L27 java.lang.IllegalStateException -> L3d
            r1 = 2
            if (r0 == r1) goto L4c
            goto L2b
        L27:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L3d
            throw r0     // Catch: java.lang.IllegalStateException -> L3d
        L2b:
            r0 = r7
            int r0 = r0.Vulcan_l     // Catch: java.lang.IllegalStateException -> L3d java.lang.IllegalStateException -> L48
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L69
            if (r1 != 0) goto L61
            goto L41
        L3d:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L48
            throw r0     // Catch: java.lang.IllegalStateException -> L48
        L41:
            r1 = 3
            if (r0 != r1) goto L5d
            goto L4c
        L48:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L50
            throw r0     // Catch: java.lang.IllegalStateException -> L50
        L4c:
            r0 = r7
            goto L54
        L50:
            java.lang.IllegalStateException r0 = a(r0)
            throw r0
        L54:
            long r0 = r0.Vulcan_C
            r1 = r7
            long r1 = r1.Vulcan_S
            long r0 = r0 - r1
            return r0
        L5d:
            r0 = r7
            int r0 = r0.Vulcan_l
        L61:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L80
            r1 = r11
        L69:
            if (r1 != 0) goto L80
            if (r0 != 0) goto L7c
            goto L76
        L72:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L78
            throw r0     // Catch: java.lang.IllegalStateException -> L78
        L76:
            r0 = 0
            return r0
        L78:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L78
            throw r0
        L7c:
            r0 = r7
            int r0 = r0.Vulcan_l
        L80:
            r1 = 1
            if (r0 != r1) goto L91
            long r0 = java.lang.System.currentTimeMillis()     // Catch: java.lang.IllegalStateException -> L8d
            r1 = r7
            long r1 = r1.Vulcan_S     // Catch: java.lang.IllegalStateException -> L8d
            long r0 = r0 - r1
            return r0
        L8d:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L8d
            throw r0
        L91:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fS.b
            r3 = 2
            r2 = r2[r3]
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fS.Vulcan_V(java.lang.Object[]):long");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v12, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public long Vulcan_I(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? r0 = this;
        ?? r02 = r0;
        if (Vulcan_G.Vulcan_Y() == null) {
            try {
                try {
                    r0 = r0.Vulcan_F;
                    if (r0 != Vulcan_t) {
                        throw new IllegalStateException(b[1]);
                    }
                    r02 = this;
                } catch (IllegalStateException unused) {
                    throw a(r0);
                }
            } catch (IllegalStateException unused2) {
                throw a(r0);
            }
        }
        return r02.Vulcan_C - this.Vulcan_S;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_fS] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_fS] */
    public long Vulcan_R(Object[] objArr) {
        long jIntValue = ((((long) ((Integer) objArr[0]).intValue()) << 48) | ((((Long) objArr[1]).longValue() << 16) >>> 16)) ^ a;
        ?? Vulcan_Y = Vulcan_G.Vulcan_Y();
        try {
            Vulcan_Y = this;
            ?? r0 = Vulcan_Y;
            if (Vulcan_Y == 0) {
                try {
                    Vulcan_Y = Vulcan_Y.Vulcan_l;
                    if (Vulcan_Y == 0) {
                        throw new IllegalStateException(b[7]);
                    }
                    r0 = this;
                } catch (IllegalStateException unused) {
                    throw a(Vulcan_Y);
                }
            }
            return r0.Vulcan_S;
        } catch (IllegalStateException unused2) {
            throw a(Vulcan_Y);
        }
    }
}
