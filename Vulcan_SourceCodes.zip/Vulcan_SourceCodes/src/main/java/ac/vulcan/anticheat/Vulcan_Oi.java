package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Oi.class */
public interface Vulcan_Oi {
    Object Vulcan_f(Object[] objArr);

    void Vulcan_J(Object[] objArr);
}
