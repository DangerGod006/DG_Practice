package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_N.class */
public class Vulcan_N extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = 62986528375L;
    private long Vulcan_m;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(2999905068634420299L, 7026239294220217061L, null).a(191351161448125L);

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public Vulcan_N() {
    }

    public Vulcan_N(long j) {
        this.Vulcan_m = j;
    }

    public Vulcan_N(Number number) {
        this.Vulcan_m = number.longValue();
    }

    public Vulcan_N(String str) {
        this.Vulcan_m = Long.parseLong(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Long(this.Vulcan_m);
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_m = ((Long) objArr[0]).longValue();
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [ac.vulcan.anticheat.Vulcan_N, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r0 = r9
            r1 = r11
            java.lang.Number r1 = (java.lang.Number) r1
            long r1 = r1.longValue()
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_N(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_N.Vulcan_J(java.lang.Object[]):void");
    }

    public void Vulcan_j(Object[] objArr) {
        this.Vulcan_m++;
    }

    public void Vulcan_E(Object[] objArr) {
        this.Vulcan_m--;
    }

    public void Vulcan_C(Object[] objArr) {
        this.Vulcan_m += ((Long) objArr[0]).longValue();
    }

    public void Vulcan_m(Object[] objArr) {
        this.Vulcan_m += ((Number) objArr[0]).longValue();
    }

    public void Vulcan_L(Object[] objArr) {
        this.Vulcan_m -= ((Long) objArr[0]).longValue();
    }

    public void Vulcan_z(Object[] objArr) {
        this.Vulcan_m -= ((Number) objArr[0]).longValue();
    }

    @Override // java.lang.Number
    public int intValue() {
        return (int) this.Vulcan_m;
    }

    @Override // java.lang.Number
    public long longValue() {
        return this.Vulcan_m;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_m;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_m;
    }

    public Long Vulcan_D(Object[] objArr) {
        return new Long(longValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    public boolean equals(Object obj) {
        long j = a ^ 97186110727652L;
        NumberFormatException numberFormatExceptionVulcan_n = C0003Vulcan_On.Vulcan_n();
        try {
            try {
                try {
                    numberFormatExceptionVulcan_n = obj instanceof Vulcan_N;
                    if (numberFormatExceptionVulcan_n == 0) {
                        return numberFormatExceptionVulcan_n;
                    }
                    if (numberFormatExceptionVulcan_n != 0) {
                        ?? r0 = (this.Vulcan_m > ((Vulcan_N) obj).longValue() ? 1 : (this.Vulcan_m == ((Vulcan_N) obj).longValue() ? 0 : -1));
                        return numberFormatExceptionVulcan_n != 0 ? r0 == 0 : r0;
                    }
                    return false;
                } catch (NumberFormatException unused) {
                    throw a(numberFormatExceptionVulcan_n);
                }
            } catch (NumberFormatException unused2) {
                throw a(numberFormatExceptionVulcan_n);
            }
        } catch (NumberFormatException unused3) {
            throw a(numberFormatExceptionVulcan_n);
        }
    }

    public int hashCode() {
        return (int) (this.Vulcan_m ^ (this.Vulcan_m >>> 32));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0044  */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [int, java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v4, types: [long] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.NumberFormatException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // java.lang.Comparable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int compareTo(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_N.a
            r1 = 39918741095382(0x244e4e6203d6, double:1.97224786004594E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_n()
            r1 = r6
            ac.vulcan.anticheat.Vulcan_N r1 = (ac.vulcan.anticheat.Vulcan_N) r1
            r10 = r1
            r9 = r0
            r0 = r10
            long r0 = r0.Vulcan_m
            r11 = r0
            r0 = r5
            long r0 = r0.Vulcan_m     // Catch: java.lang.NumberFormatException -> L2c
            r1 = r11
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            if (r1 == 0) goto L3f
            if (r0 >= 0) goto L38
            goto L30
        L2c:
            java.lang.NumberFormatException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L34
            throw r0     // Catch: java.lang.NumberFormatException -> L34
        L30:
            r0 = -1
            goto L53
        L34:
            java.lang.NumberFormatException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L34
            throw r0
        L38:
            r0 = r5
            long r0 = r0.Vulcan_m
            r1 = r11
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L3f:
            r1 = r9
            if (r1 == 0) goto L4f
            if (r0 != 0) goto L52
            goto L4e
        L4a:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L4e:
            r0 = 0
        L4f:
            goto L53
        L52:
            r0 = 1
        L53:
            r1 = r9
            if (r1 != 0) goto L66
            r1 = 3
            me.frep.vulcan.spigot.check.AbstractCheck[] r1 = new me.frep.vulcan.spigot.check.AbstractCheck[r1]     // Catch: java.lang.NumberFormatException -> L62
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r1)     // Catch: java.lang.NumberFormatException -> L62
            goto L66
        L62:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L66:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_N.compareTo(java.lang.Object):int");
    }

    public String toString() {
        return String.valueOf(this.Vulcan_m);
    }
}
