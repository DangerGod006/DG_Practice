package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_h.class */
public class C0018Vulcan_h extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = 1587163916;
    private double Vulcan_T;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6279705471512603888L, 421876841373768875L, null).a(124295744160428L);

    /*  JADX ERROR: Failed to decode insn: 0x0024: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[12]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    @Override // java.lang.Comparable
    public int compareTo(java.lang.Object r13) {
        /*
            r12 = this;
            long r0 = ac.vulcan.anticheat.C0018Vulcan_h.a
            r1 = 86297297710707(0x4e7ca7c66e73, double:4.2636530127795E-310)
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 86968019939424(0x4f18d1ef7060, double:4.2967910938906E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_h r0 = (ac.vulcan.anticheat.C0018Vulcan_h) r0
            r18 = r0
            r0 = r18
            double r0 = r0.Vulcan_T
            r19 = r0
            r0 = r12
            double r0 = r0.Vulcan_T
            r1 = r16
            // decode failed: arraycopy: source index -1 out of bounds for object array[12]
            r1 = r19
            r2 = 3
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Double r4 = new java.lang.Double
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 2
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r3 = new java.lang.Double
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r2 = new java.lang.Long
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r2.<init>(r3)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            ac.vulcan.anticheat.Vulcan_O9.m81Vulcan_k(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0018Vulcan_h.compareTo(java.lang.Object):int");
    }

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public C0018Vulcan_h() {
    }

    public C0018Vulcan_h(double d) {
        this.Vulcan_T = d;
    }

    public C0018Vulcan_h(Number number) {
        this.Vulcan_T = number.doubleValue();
    }

    public C0018Vulcan_h(String str) {
        this.Vulcan_T = Double.parseDouble(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Double(this.Vulcan_T);
    }

    public void Vulcan__(Object[] objArr) {
        this.Vulcan_T = ((Double) objArr[0]).doubleValue();
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [ac.vulcan.anticheat.Vulcan_h, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0023: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r0 = r9
            r1 = r11
            java.lang.Number r1 = (java.lang.Number) r1
            double r1 = r1.doubleValue()
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Double r4 = new java.lang.Double
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan__(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0018Vulcan_h.Vulcan_J(java.lang.Object[]):void");
    }

    public boolean Vulcan_C(Object[] objArr) {
        return Double.isNaN(this.Vulcan_T);
    }

    public boolean Vulcan_V(Object[] objArr) {
        return Double.isInfinite(this.Vulcan_T);
    }

    public void Vulcan_s(Object[] objArr) {
        this.Vulcan_T += 1.0d;
    }

    public void Vulcan_r(Object[] objArr) {
        this.Vulcan_T -= 1.0d;
    }

    public void Vulcan_p(Object[] objArr) {
        this.Vulcan_T += ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_b(Object[] objArr) {
        this.Vulcan_T += ((Number) objArr[0]).doubleValue();
    }

    public void Vulcan_v(Object[] objArr) {
        this.Vulcan_T -= ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_U(Object[] objArr) {
        this.Vulcan_T -= ((Number) objArr[0]).doubleValue();
    }

    @Override // java.lang.Number
    public int intValue() {
        return (int) this.Vulcan_T;
    }

    @Override // java.lang.Number
    public long longValue() {
        return (long) this.Vulcan_T;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return (float) this.Vulcan_T;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_T;
    }

    public Double Vulcan_q(Object[] objArr) {
        return new Double(doubleValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003e  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.C0018Vulcan_h.a
            r1 = 21466691132624(0x13861a7fdcd0, double:1.06059546185144E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_n()
            r9 = r0
            r0 = r6
            boolean r0 = r0 instanceof ac.vulcan.anticheat.C0018Vulcan_h     // Catch: java.lang.NumberFormatException -> L1c
            r1 = r9
            if (r1 == 0) goto L39
            if (r0 == 0) goto L4c
            goto L20
        L1c:
            java.lang.NumberFormatException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L35
            throw r0     // Catch: java.lang.NumberFormatException -> L35
        L20:
            r0 = r6
            ac.vulcan.anticheat.Vulcan_h r0 = (ac.vulcan.anticheat.C0018Vulcan_h) r0     // Catch: java.lang.NumberFormatException -> L35
            double r0 = r0.Vulcan_T     // Catch: java.lang.NumberFormatException -> L35
            long r0 = java.lang.Double.doubleToLongBits(r0)     // Catch: java.lang.NumberFormatException -> L35
            r1 = r5
            double r1 = r1.Vulcan_T     // Catch: java.lang.NumberFormatException -> L35
            long r1 = java.lang.Double.doubleToLongBits(r1)     // Catch: java.lang.NumberFormatException -> L35
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L39
        L35:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L39:
            r1 = r9
            if (r1 == 0) goto L49
            if (r0 != 0) goto L4c
            goto L48
        L44:
            java.lang.NumberFormatException r0 = a(r0)
            throw r0
        L48:
            r0 = 1
        L49:
            goto L4d
        L4c:
            r0 = 0
        L4d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0018Vulcan_h.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        long jDoubleToLongBits = Double.doubleToLongBits(this.Vulcan_T);
        return (int) (jDoubleToLongBits ^ (jDoubleToLongBits >>> 32));
    }

    public String toString() {
        return String.valueOf(this.Vulcan_T);
    }
}
