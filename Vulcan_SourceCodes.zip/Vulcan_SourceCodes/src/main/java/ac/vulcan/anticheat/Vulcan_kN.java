package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kN.class */
public class Vulcan_kN {
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-7793529843316301937L, 2867697881791025976L, null).a(2355419231038L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0035: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_q(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 107403664866936(0x61aedd4abe78, double:5.30644610481995E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 97889135592288(0x590797278360, double:4.8363658997245E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r15
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Boolean r0 = Vulcan_o(r0)
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = Vulcan_m(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_q(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0052: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.String Vulcan_z(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 4046069758395(0x3ae0c8cf9bb, double:1.9990240683E-311)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r12
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r15 = r2
            r2 = r15
            r3 = 6
            r2 = r2[r3]
            r3 = r15
            r4 = 7
            r3 = r3[r4]
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_d(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_z(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0080: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public static java.lang.String m452Vulcan_u(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r12 = r1
            r0 = r10
            long r0 = (long) r0
            r1 = 32
            long r0 = r0 << r1
            r1 = r13
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r11
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_kN.a
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 120046485799649(0x6d2e802482e1, double:5.93108445375756E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r16
            r1 = r12
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r18 = r2
            r2 = r18
            r3 = 10
            r2 = r2[r3]
            r3 = r18
            r4 = 20
            r3 = r3[r4]
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_d(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m452Vulcan_u(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0051: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public static java.lang.String m453Vulcan_a(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 121939336708889(0x6ee736d94319, double:6.02460371445305E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r10
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r15 = r2
            r2 = r15
            r3 = 16
            r2 = r2[r3]
            r3 = r15
            r4 = 2
            r3 = r3[r4]
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_d(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m453Vulcan_a(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0085, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0088, code lost:
    
        r11 = "Q~f\u00189\bw`qfJP\u0002ja6mW\u0004Fndb`PP\u0003jq~fJP\u0015s`uj^\u0019\u0003g%`bT\u0005\u0003,Q~f\u0018\u0011\u0014qdo#U\u0005\u0015w%xlLP\u0005lkbbQ\u001eFbko#V\u0005\no%so]\u001d\u0003mqe".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0091, code lost:
    
        ac.vulcan.anticheat.Vulcan_kN.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0099, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a9, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b8, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003b, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004b, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0057, code lost:
    
        r2 = "Q~f\u00189\bw`qfJP\u0002ja6mW\u0004Fndb`PP\u0003jq~fJP\u0015s`uj^\u0019\u0003g%`bT\u0005\u0003,Q~f\u0018\u0011\u0014qdo#U\u0005\u0015w%xlLP\u0005lkbbQ\u001eFbko#V\u0005\no%so]\u001d\u0003mqe".length();
        r11 = '0';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0065, code lost:
    
        r10 = r10 + 1;
        "Q~f\u00189\bw`qfJP\u0002ja6mW\u0004Fndb`PP\u0003jq~fJP\u0015s`uj^\u0019\u0003g%`bT\u0005\u0003,Q~f\u0018\u0011\u0014qdo#U\u0005\u0015w%xlLP\u0005lkbbQ\u001eFbko#V\u0005\no%so]\u001d\u0003mqe".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0075, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ac, B:28:0x0110], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ac). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0115 -> B:34:0x00ac). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m447clinit():void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Boolean Vulcan__(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            r1 = r9
            if (r1 != 0) goto L51
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L43 java.lang.IllegalArgumentException -> L4d
            if (r0 == 0) goto L54
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4d
        L47:
            java.lang.Boolean r0 = java.lang.Boolean.FALSE     // Catch: java.lang.IllegalArgumentException -> L4d
            goto L51
        L4d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L51:
            goto L57
        L54:
            java.lang.Boolean r0 = java.lang.Boolean.TRUE
        L57:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan__(java.lang.Object[]):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_H(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L43
            r1 = r9
            if (r1 != 0) goto L48
            if (r0 == 0) goto L4b
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L47:
            r0 = 1
        L48:
            goto L4c
        L4b:
            r0 = 0
        L4c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_H(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0050]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0050]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static boolean Vulcan_L(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 109421867168048(0x6384c385f130, double:5.40615854715367E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r10
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L50
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L50
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L50
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L50
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L50
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L50
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L50
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L50
            boolean r0 = Vulcan_H(r0)     // Catch: java.lang.IllegalArgumentException -> L50
            r1 = r15
            if (r1 != 0) goto L55
            if (r0 != 0) goto L58
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_L(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_G(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L43
            r1 = r9
            if (r1 != 0) goto L48
            if (r0 == 0) goto L4b
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L47:
            r0 = 0
        L48:
            goto L4c
        L4b:
            r0 = 1
        L4c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_G(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0050]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x003c: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0050]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static boolean Vulcan_O(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 60198005494330(0x36bff0bbd23a, double:2.9741766462911E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r15 = r0
            r0 = r12
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L50
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.IllegalArgumentException -> L50
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L50
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L50
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L50
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L50
            r4.<init>(r5)     // Catch: java.lang.IllegalArgumentException -> L50
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L50
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L50
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.IllegalArgumentException -> L50
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.IllegalArgumentException -> L50
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L50
            r1[r2] = r3     // Catch: java.lang.IllegalArgumentException -> L50
            boolean r0 = Vulcan_G(r0)     // Catch: java.lang.IllegalArgumentException -> L50
            r1 = r15
            if (r1 != 0) goto L55
            if (r0 != 0) goto L58
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_O(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Boolean] */
    public static Boolean Vulcan_Z(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        long j = a ^ jLongValue;
        ?? r0 = zBooleanValue;
        if (r0 == 0) {
            return Boolean.FALSE;
        }
        try {
            r0 = Boolean.TRUE;
            return r0;
        } catch (IllegalArgumentException unused) {
            throw a(r0);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_m(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L43
            r1 = r9
            if (r1 != 0) goto L48
            if (r0 == 0) goto L4b
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L47:
            r0 = 1
        L48:
            goto L4c
        L4b:
            r0 = 0
        L4c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_m(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_r(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r9
            r1 = r10
            if (r1 != 0) goto L42
            if (r0 != 0) goto L40
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L3c
        L3a:
            r0 = r6
            return r0
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L3c
            throw r0
        L40:
            r0 = r9
        L42:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L50
            r1 = r10
            if (r1 != 0) goto L55
            if (r0 == 0) goto L58
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_r(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r1v7, types: [boolean, int] */
    public static boolean Vulcan_U(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        ?? IntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        if (Vulcan_fX.Vulcan_k() == null) {
            return IntValue != 0;
        }
        return IntValue;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Boolean] */
    public static Boolean Vulcan_t(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? r0 = iIntValue;
        if (r0 != 0) {
            return Boolean.TRUE;
        }
        try {
            r0 = Boolean.FALSE;
            return r0;
        } catch (IllegalArgumentException unused) {
            throw a(r0);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Boolean Vulcan_i(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r6
        L35:
            int r0 = r0.intValue()     // Catch: java.lang.IllegalArgumentException -> L41
            if (r0 != 0) goto L45
            java.lang.Boolean r0 = java.lang.Boolean.FALSE     // Catch: java.lang.IllegalArgumentException -> L41
            goto L48
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L41
            throw r0
        L45:
            java.lang.Boolean r0 = java.lang.Boolean.TRUE
        L48:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_i(java.lang.Object[]):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_v(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r9
            r1 = r10
            r2 = r11
            if (r2 != 0) goto L5f
            if (r0 != r1) goto L50
            goto L4a
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4c
        L4a:
            r0 = 1
            return r0
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4c
            throw r0
        L50:
            r0 = r9
            r1 = r11
            if (r1 != 0) goto L63
            r1 = r8
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5f:
            if (r0 != r1) goto L64
            r0 = 0
        L63:
            return r0
        L64:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r3 = 21
            r2 = r2[r3]
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_v(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_D(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r9
            r1 = r13
            if (r1 != 0) goto L6e
            if (r0 != 0) goto L6d
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4f
        L3f:
            r0 = r10
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L64
            r1 = r13
            if (r1 != 0) goto L64
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L59
            throw r0     // Catch: java.lang.IllegalArgumentException -> L59
        L53:
            if (r0 != 0) goto L63
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L5d:
            r0 = 1
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r8
        L64:
            if (r0 != 0) goto La4
            r0 = 0
            return r0
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L69
            throw r0
        L6d:
            r0 = r9
        L6e:
            r1 = r10
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L84
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L95
            if (r1 != 0) goto L93
            if (r0 == 0) goto L8e
            goto L88
        L84:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8a
        L88:
            r0 = 1
            return r0
        L8a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0
        L8e:
            r0 = r9
            r1 = r8
            boolean r0 = r0.equals(r1)
        L93:
            r1 = r13
        L95:
            if (r1 != 0) goto La3
            if (r0 == 0) goto La4
            goto La2
        L9e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La2:
            r0 = 0
        La3:
            return r0
        La4:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r3 = 17
            r2 = r2[r3]
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_D(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public static Boolean m448Vulcan_U(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        int iIntValue4 = ((Integer) objArr[4]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_k = Vulcan_fX.Vulcan_k();
        try {
            int i = iIntValue;
            int i2 = iIntValue2;
            ?? r0 = i;
            if (Vulcan_k == 0) {
                if (i == i2) {
                    return Boolean.TRUE;
                }
                r0 = iIntValue;
                i2 = iIntValue3;
            }
            try {
                if (j > 0 && Vulcan_k == 0) {
                    if (r0 == i2) {
                        return Boolean.FALSE;
                    }
                    r0 = iIntValue;
                    i2 = iIntValue4;
                }
                if (r0 == i2) {
                    return null;
                }
                throw new IllegalArgumentException(b[8]);
            } catch (IllegalArgumentException unused) {
                throw a(r0);
            }
        } catch (IllegalArgumentException unused2) {
            throw a(Vulcan_k);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Boolean Vulcan_J(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 248
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_J(java.lang.Object[]):java.lang.Boolean");
    }

    public static int Vulcan_u(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        return Vulcan_fX.Vulcan_k() == null ? zBooleanValue ? 1 : 0 : zBooleanValue ? 1 : 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Integer] */
    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public static Integer m449Vulcan_L(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        long j = a ^ jLongValue;
        ?? r0 = zBooleanValue;
        if (r0 == 0) {
            return Vulcan_O9.Vulcan_D;
        }
        try {
            r0 = Vulcan_O9.Vulcan_U;
            return r0;
        } catch (IllegalArgumentException unused) {
            throw a(r0);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public static java.lang.Integer m450Vulcan_t(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0     // Catch: java.lang.IllegalArgumentException -> L30
        L2e:
            r0 = 0
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r8
        L35:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L41
            if (r0 == 0) goto L45
            java.lang.Integer r0 = ac.vulcan.anticheat.Vulcan_O9.Vulcan_U     // Catch: java.lang.IllegalArgumentException -> L41
            goto L48
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L41
            throw r0
        L45:
            java.lang.Integer r0 = ac.vulcan.anticheat.Vulcan_O9.Vulcan_D
        L48:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m450Vulcan_t(java.lang.Object[]):java.lang.Integer");
    }

    public static int Vulcan_E(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        return Vulcan_fX.Vulcan_k() == null ? zBooleanValue ? iIntValue : iIntValue2 : zBooleanValue ? 1 : 0;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static int m451Vulcan_G(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r6
            r1 = r12
            if (r1 != 0) goto L57
            if (r0 != 0) goto L56
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L52
            throw r0     // Catch: java.lang.IllegalArgumentException -> L52
        L4f:
            r0 = r9
            return r0
        L52:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L52
            throw r0
        L56:
            r0 = r6
        L57:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L65
            r1 = r12
            if (r1 != 0) goto L6b
            if (r0 == 0) goto L6e
            goto L69
        L65:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L69:
            r0 = r11
        L6b:
            goto L70
        L6e:
            r0 = r10
        L70:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m451Vulcan_G(java.lang.Object[]):int");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static Integer Vulcan_a(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        Integer num = (Integer) objArr[2];
        Integer num2 = (Integer) objArr[3];
        long j = a ^ jLongValue;
        return zBooleanValue ? num : num2;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Integer Vulcan_A(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r9 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 != 0) goto L50
            if (r0 != 0) goto L4e
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4a
        L47:
            r0 = r10
            return r0
        L4a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4a
            throw r0
        L4e:
            r0 = r11
        L50:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L5a
            if (r0 == 0) goto L5e
            r0 = r8
            goto L60
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5a
            throw r0
        L5e:
            r0 = r9
        L60:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_A(java.lang.Object[]):java.lang.Integer");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Boolean Vulcan_o(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 1562
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_o(java.lang.Object[]):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Boolean Vulcan_B(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 249
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_B(java.lang.Object[]):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_p(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r13 = r0
            r0 = r8
            r1 = r13
            if (r1 != 0) goto L6e
            if (r0 != 0) goto L6d
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4f
        L3f:
            r0 = r10
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L64
            r1 = r13
            if (r1 != 0) goto L64
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L59
            throw r0     // Catch: java.lang.IllegalArgumentException -> L59
        L53:
            if (r0 != 0) goto L63
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L5f
        L5d:
            r0 = 1
            return r0
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L5f
            throw r0
        L63:
            r0 = r9
        L64:
            if (r0 != 0) goto La4
            r0 = 0
            return r0
        L69:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L69
            throw r0
        L6d:
            r0 = r8
        L6e:
            r1 = r10
            boolean r0 = r0.equals(r1)     // Catch: java.lang.IllegalArgumentException -> L84
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L95
            if (r1 != 0) goto L93
            if (r0 == 0) goto L8e
            goto L88
        L84:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8a
        L88:
            r0 = 1
            return r0
        L8a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8a
            throw r0
        L8e:
            r0 = r8
            r1 = r9
            boolean r0 = r0.equals(r1)
        L93:
            r1 = r13
        L95:
            if (r1 != 0) goto La3
            if (r0 == 0) goto La4
            goto La2
        L9e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La2:
            r0 = 0
        La3:
            return r0
        La4:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_kN.b
            r3 = 4
            r2 = r2[r3]
            r1.<init>(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_P(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 76493339684367(0x4591fe56ee0f, double:3.77927312737106E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_kN.b
            r17 = r1
            r1 = r17
            r2 = 19
            r1 = r1[r2]
            r2 = r17
            r3 = 14
            r2 = r2[r3]
            r3 = r15
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_P(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x004a: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x004a: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_N(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 78289759108965(0x47344147ff65, double:3.86802803969264E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_kN.b
            r17 = r1
            r1 = r17
            r2 = 0
            r1 = r1[r2]
            r2 = r17
            r3 = 3
            r2 = r2[r3]
            r3 = r15
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_N(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static java.lang.String Vulcan_b(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 60960389937658(0x3771726339fa, double:3.0118434425283E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_kN.b
            r17 = r1
            r1 = r17
            r2 = 9
            r1 = r1[r2]
            r2 = r17
            r3 = 5
            r2 = r2[r3]
            r3 = r15
            r4 = 0
            r5 = 5
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = Vulcan_Y(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_b(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.String Vulcan_Y(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_kN.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r8
            r1 = r12
            if (r1 != 0) goto L4e
            if (r0 != 0) goto L4d
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L47:
            r0 = r7
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            r0 = r8
        L4e:
            boolean r0 = r0.booleanValue()     // Catch: java.lang.IllegalArgumentException -> L59
            if (r0 == 0) goto L5d
            r0 = r9
            goto L5e
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L59
            throw r0
        L5d:
            r0 = r6
        L5e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.Vulcan_Y(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static String Vulcan_d(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        String str = (String) objArr[2];
        String str2 = (String) objArr[3];
        long j = a ^ jLongValue;
        return zBooleanValue ? str : str2;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static boolean m454Vulcan__(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 248
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m454Vulcan__(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Boolean] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v16, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x007e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x008c]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x007e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: NullPointerException -> 0x008c]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public static java.lang.Boolean m455Vulcan_p(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 204
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kN.m455Vulcan_p(java.lang.Object[]):java.lang.Boolean");
    }
}
