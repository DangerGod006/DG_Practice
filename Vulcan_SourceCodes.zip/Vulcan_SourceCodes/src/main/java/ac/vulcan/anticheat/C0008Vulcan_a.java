package ac.vulcan.anticheat;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_a.class */
public class C0008Vulcan_a implements Serializable {
    private static final long serialVersionUID = 5947847346149275958L;
    public static final C0008Vulcan_a Vulcan_j;
    public static final C0008Vulcan_a Vulcan_B;
    public static final C0008Vulcan_a Vulcan_c;
    public static final C0008Vulcan_a Vulcan__;
    public static final C0008Vulcan_a Vulcan_Y;
    protected static final Map Vulcan_M;
    private final Set Vulcan_w;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5466911249845526709L, 7498823817813277675L, null).a(160370773106393L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0087, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008a, code lost:
    
        r12 = "\u0012Y!I>\u0005\u00062Y\u0001i>%".charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r18 = r18 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_j = new ac.vulcan.anticheat.C0008Vulcan_a((java.lang.String) null);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_B = new ac.vulcan.anticheat.C0008Vulcan_a((java.lang.String) r0[8]);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_c = new ac.vulcan.anticheat.C0008Vulcan_a((java.lang.String) r0[2]);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan__ = new ac.vulcan.anticheat.C0008Vulcan_a((java.lang.String) r0[5]);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_Y = new ac.vulcan.anticheat.C0008Vulcan_a((java.lang.String) r0[6]);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M = java.util.Collections.synchronizedMap(new java.util.HashMap());
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(null, ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_j);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put("", ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_j);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(r0[3], ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_B);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(r0[7], ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_B);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(r0[1], ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_c);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(r0[0], ac.vulcan.anticheat.C0008Vulcan_a.Vulcan__);
        ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_M.put(r0[4], ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_Y);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x01e0, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0099, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r18 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00a9, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r18 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00b8, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e0, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r18 = r18 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00e5, code lost:
    
        r7 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        r7 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ef, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f4, code lost:
    
        r7 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f9, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00fe, code lost:
    
        r7 = 77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0115, code lost:
    
        if (r2 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003b, code lost:
    
        r4 = r14;
        r14 = r14 + 1;
        r0[r4] = r0;
        r2 = r11 + r12;
        r11 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "\u0012Y!I>\u0005\u00062Y\u0001i>%".length();
        r12 = 6;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r11 = r11 + 1;
        "\u0012Y!I>\u0005\u00062Y\u0001i>%".substring(r11, r11 + r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r14;
        r14 = r14 + 1;
        r0[r6] = r1;
        r4 = r11 + r12;
        r11 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ac, B:28:0x0110], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v20, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v22, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v24, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v26, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r5v30 */
    /* JADX WARN: Type inference failed for: r5v31 */
    /* JADX WARN: Type inference failed for: r5v35 */
    /* JADX WARN: Type inference failed for: r5v45 */
    /* JADX WARN: Type inference failed for: r6v11, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v7, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ac). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0115 -> B:35:0x00ac). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 481
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.m172clinit():void");
    }

    public static C0008Vulcan_a Vulcan_P(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        Object obj = Vulcan_M.get(str);
        Object obj2 = obj;
        if (strVulcan_k == null) {
            if (obj2 != null) {
                obj2 = obj;
            } else {
                return new C0008Vulcan_a(str);
            }
        }
        return (C0008Vulcan_a) obj2;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static C0008Vulcan_a Vulcan_L(Object[] objArr) {
        String[] strArr = (String[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        if (strArr == null) {
            return null;
        }
        return new C0008Vulcan_a(strArr);
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_a, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003e: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003e: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected C0008Vulcan_a(java.lang.String r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0008Vulcan_a.a
            r1 = 129934453901913(0x762cb8f80a59, double:6.41961498840783E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 110938758886845(0x64e5f150b5bd, double:5.48110295582554E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r0.<init>()
            r0 = r9
            java.util.HashSet r1 = new java.util.HashSet
            r2 = r1
            r2.<init>()
            java.util.Set r1 = java.util.Collections.synchronizedSet(r1)
            r0.Vulcan_w = r1
            r0 = r9
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_r(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.<init>(java.lang.String):void");
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_a, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected C0008Vulcan_a(java.lang.String[] r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0008Vulcan_a.a
            r1 = 11883127747655(0xacec19bb447, double:5.871045185259E-311)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 26420628884387(0x180788330ba3, double:1.30535250732966E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r0.<init>()
            r0 = r9
            java.util.HashSet r1 = new java.util.HashSet
            r2 = r1
            r2.<init>()
            java.util.Set r1 = java.util.Collections.synchronizedSet(r1)
            r0.Vulcan_w = r1
            r0 = r10
            int r0 = r0.length
            r16 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = 0
            r17 = r1
            r15 = r0
        L2f:
            r0 = r17
            r1 = r16
            if (r0 >= r1) goto L62
            r0 = r9
            r1 = r10
            r2 = r17
            r1 = r1[r2]
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_r(r1)
            int r17 = r17 + 1
            r0 = r15
            if (r0 == 0) goto L2f
        L62:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.<init>(java.lang.String[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00c6 A[PHI: r0 r1
  0x00c6: PHI (r0v11 ??) = (r0v51 ??), (r0v52 ??), (r0v53 ??), (r0v50 ??) binds: [B:13:0x0042, B:16:0x0054, B:22:0x006f, B:30:0x00c3] A[DONT_GENERATE, DONT_INLINE]
  0x00c6: PHI (r1v11 char) = (r1v10 char), (r1v37 char), (r1v40 char), (r1v45 char) binds: [B:13:0x0042, B:16:0x0054, B:22:0x006f, B:30:0x00c3] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0138 A[PHI: r0 r1
  0x0138: PHI (r0v12 ??) = (r0v54 ??), (r0v55 ??), (r0v34 ??) binds: [B:32:0x00c9, B:35:0x00dd, B:45:0x0137] A[DONT_GENERATE, DONT_INLINE]
  0x0138: PHI (r1v12 char) = (r1v11 char), (r1v27 char), (r1v34 char) binds: [B:32:0x00c9, B:35:0x00dd, B:45:0x0137] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0185  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x013b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [char] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v30, types: [char] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v44, types: [char] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_r(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 436
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_r(java.lang.Object[]):void");
    }

    public Vulcan_A[] Vulcan_M(Object[] objArr) {
        return (Vulcan_A[]) this.Vulcan_w.toArray(new Vulcan_A[this.Vulcan_w.size()]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [ac.vulcan.anticheat.Vulcan_A] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r3v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0062: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0086]
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0062: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x0086]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public boolean Vulcan_l(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0008Vulcan_a.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 89439557108510(0x51584507c31e, double:4.4189012546571E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r10
            java.util.Set r1 = r1.Vulcan_w
            java.util.Iterator r1 = r1.iterator()
            r18 = r1
            r17 = r0
        L35:
            r0 = r18
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto L9b
            r0 = r18
            java.lang.Object r0 = r0.next()
            ac.vulcan.anticheat.Vulcan_A r0 = (ac.vulcan.anticheat.Vulcan_A) r0
            r19 = r0
            r0 = r19
            r1 = r12
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L86
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L86
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L86
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L86
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L86
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.RuntimeException -> L86
            r5.<init>(r6)     // Catch: java.lang.RuntimeException -> L86
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L86
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L86
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L86
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L86
            java.lang.Integer r4 = new java.lang.Integer     // Catch: java.lang.RuntimeException -> L86
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.RuntimeException -> L86
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L86
            r4.<init>(r5)     // Catch: java.lang.RuntimeException -> L86
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L86
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L86
            boolean r0 = r0.Vulcan_z(r1)     // Catch: java.lang.RuntimeException -> L86
            r1 = r17
            r2 = r13
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L80
            if (r1 != 0) goto L9c
            r1 = r17
        L80:
            if (r1 != 0) goto L95
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L90
            throw r0     // Catch: java.lang.RuntimeException -> L90
        L8a:
            if (r0 == 0) goto L96
            goto L94
        L90:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L94:
            r0 = 1
        L95:
            return r0
        L96:
            r0 = r17
            if (r0 == 0) goto L35
        L9b:
            r0 = 0
        L9c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.Vulcan_l(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.C0008Vulcan_a.a
            r1 = 18967210722061(0x114025db830d, double:9.371047215202E-311)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0     // Catch: java.lang.RuntimeException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.C0008Vulcan_a     // Catch: java.lang.RuntimeException -> L33 java.lang.RuntimeException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0     // Catch: java.lang.RuntimeException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_a r0 = (ac.vulcan.anticheat.C0008Vulcan_a) r0
            r10 = r0
            r0 = r5
            java.util.Set r0 = r0.Vulcan_w
            r1 = r10
            java.util.Set r1 = r1.Vulcan_w
            boolean r0 = r0.equals(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0008Vulcan_a.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return 89 + this.Vulcan_w.hashCode();
    }

    public String toString() {
        return this.Vulcan_w.toString();
    }
}
