package ac.vulcan.anticheat;

import java.io.StringWriter;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_f3.class */
class Vulcan_f3 {
    private static final String[][] Vulcan_a;
    private static final String[][] Vulcan_C;
    static final String[][] Vulcan_p;
    static final String[][] Vulcan_g;
    public static final Vulcan_f3 Vulcan_G;
    public static final Vulcan_f3 Vulcan_e;
    public static final Vulcan_f3 Vulcan_B;
    private final Vulcan_fn Vulcan_W;
    private static final long a;
    private static final String[] b;

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x012d -> B:15:0x00c6). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x012d -> B:35:0x00c6). Please report as a decompilation issue!!! */
    /*  JADX ERROR: NullPointerException in pass: ConstructorVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.RegisterArg.sameRegAndSVar(jadx.core.dex.instructions.args.InsnArg)" because "resultArg" is null
        	at jadx.core.dex.visitors.MoveInlineVisitor.processMove(MoveInlineVisitor.java:52)
        	at jadx.core.dex.visitors.MoveInlineVisitor.moveInline(MoveInlineVisitor.java:41)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:43)
        */
    static {
        /*
            Method dump skipped, instruction units count: 6485
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.m181clinit():void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    static void Vulcan_t(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            ac.vulcan.anticheat.Vulcan_f3 r1 = (ac.vulcan.anticheat.Vulcan_f3) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 108882131494038(0x630718c52496, double:5.37949206171734E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            java.lang.String[][] r1 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_a
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_e(r1)
            r0 = r13
            java.lang.String[][] r1 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_p
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_e(r1)
            r0 = r13
            java.lang.String[][] r1 = ac.vulcan.anticheat.Vulcan_f3.Vulcan_g
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_e(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_t(java.lang.Object[]):void");
    }

    public Vulcan_f3() {
        this.Vulcan_W = new Vulcan_OY();
    }

    Vulcan_f3(Vulcan_fn vulcan_fn) {
        this.Vulcan_W = vulcan_fn;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_f3] */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0054: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: Vulcan_kj -> 0x0070]
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0054: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: Vulcan_kj -> 0x0070]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_e(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String[][] r1 = (java.lang.String[][]) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 63214262323596(0x397e37a6898c, double:3.12319953412854E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = 0
            r18 = r0
        L26:
            r0 = r18
            r1 = r15
            int r1 = r1.length     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            if (r0 >= r1) goto L74
            r0 = r11
            r1 = r15
            r2 = r18
            r1 = r1[r2]     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r2 = 0
            r1 = r1[r2]     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r2 = r15
            r3 = r18
            r2 = r2[r3]     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r3 = 1
            r2 = r2[r3]     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            int r2 = java.lang.Integer.parseInt(r2)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r3 = r16
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            java.lang.Long r6 = new java.lang.Long     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r8 = r7; r7 = r6; r6 = r5; r5 = r8;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r6.<init>(r7)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r4[r5] = r6     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r4 = r3; r3 = r2; r2 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r5 = r3; r3 = r4; r4 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            java.lang.Integer r5 = new java.lang.Integer     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r6 = r5; r5 = r4; r4 = r6;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r7 = r5; r5 = r6; r6 = r7;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r5.<init>(r6)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r3[r4] = r5     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r3 = r2; r2 = r1; r1 = r3;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r4 = r2; r2 = r3; r3 = r4;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r2[r3] = r4     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            r0.Vulcan_f(r1)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            int r18 = r18 + 1
            goto L26
        L70:
            java.lang.Exception r0 = a(r0)     // Catch: ac.vulcan.anticheat.Vulcan_kj -> L70
            throw r0
        L74:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_e(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_f(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 48629339378298(0x2c3a667fd27a, double:2.4026085966772E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fn r0 = r0.Vulcan_W
            r1 = r15
            r2 = r16
            r3 = r17
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_A(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_f(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_fn, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String Vulcan_L(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 104466470665165(0x5f02fedffbcd, double:5.16132942979404E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_fn r0 = r0.Vulcan_W
            r1 = r14
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String r0 = r0.Vulcan_K(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_L(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003d: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public int m182Vulcan_t(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 99997415774378(0x5af2767218aa, double:4.94052878070237E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r10
            ac.vulcan.anticheat.Vulcan_fn r0 = r0.Vulcan_W
            r1 = r14
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.Vulcan_n(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.m182Vulcan_t(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v4, types: [ac.vulcan.anticheat.Vulcan_f3, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v11 ??, still in use, count: 2, list:
          (r4v11 ?? I:??[OBJECT, ARRAY][]) from 0x0057: APUT (r4v11 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v11 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x005e]
          (r4v11 ?? I:??[OBJECT, ARRAY]) from 0x0057: APUT (r4v11 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v11 ?? I:??[OBJECT, ARRAY]) A[Catch: IOException -> 0x005e]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String Vulcan_H(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_f3.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 89312099952311(0x513a97fde6b7, double:4.41260403443765E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.io.StringWriter r0 = r0.Vulcan_R(r1)
            r16 = r0
            r0 = r9
            r1 = r14
            r2 = r16
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.io.IOException -> L5e
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.io.IOException -> L5e
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L5e
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.io.IOException -> L5e
            r4[r5] = r6     // Catch: java.io.IOException -> L5e
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.io.IOException -> L5e
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L5e
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.io.IOException -> L5e
            r3[r4] = r5     // Catch: java.io.IOException -> L5e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.io.IOException -> L5e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.io.IOException -> L5e
            java.lang.Long r4 = new java.lang.Long     // Catch: java.io.IOException -> L5e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.io.IOException -> L5e
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.io.IOException -> L5e
            r4.<init>(r5)     // Catch: java.io.IOException -> L5e
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.io.IOException -> L5e
            r2[r3] = r4     // Catch: java.io.IOException -> L5e
            r0.Vulcan_G(r1)     // Catch: java.io.IOException -> L5e
            goto L6a
        L5e:
            r17 = move-exception
            ac.vulcan.anticheat.Vulcan_kj r0 = new ac.vulcan.anticheat.Vulcan_kj
            r1 = r0
            r2 = r17
            r1.<init>(r2)
            throw r0
        L6a:
            r0 = r16
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_H(java.lang.Object[]):java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_G(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 267
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_G(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v5 ??, still in use, count: 1, list:
          (r0v5 ?? I:??[int, byte, short, char]) from 0x002c: IF  (r0v5 ?? I:??[int, byte, short, char]) >= (0 ??[int, byte, short, char])  -> B:9:0x0035 (LINE:895)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public java.lang.String m183Vulcan_G(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r0v5 ??, still in use, count: 1, list:
          (r0v5 ?? I:??[int, byte, short, char]) from 0x002c: IF  (r0v5 ?? I:??[int, byte, short, char]) >= (0 ??[int, byte, short, char])  -> B:9:0x0035 (LINE:895)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r13v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    private StringWriter Vulcan_R(Object[] objArr) {
        String str = (String) objArr[0];
        return new StringWriter((int) (((double) str.length()) + (((double) str.length()) * 0.1d)));
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v15 ??, still in use, count: 1, list:
          (r1v15 ?? I:??[int, byte, short, char]) from 0x0040: IF  (r1v15 ?? I:??[int, byte, short, char]) >= (0 ??[int, byte, short, char])  -> B:14:0x0056
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_w(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v15 ??, still in use, count: 1, list:
          (r1v15 ?? I:??[int, byte, short, char]) from 0x0040: IF  (r1v15 ?? I:??[int, byte, short, char]) >= (0 ??[int, byte, short, char])  -> B:14:0x0056
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r13v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void Vulcan_n(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 644
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_f3.Vulcan_n(java.lang.Object[]):void");
    }
}
