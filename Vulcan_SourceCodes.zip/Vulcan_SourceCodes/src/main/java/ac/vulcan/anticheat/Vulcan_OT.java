package ac.vulcan.anticheat;

import java.util.Map;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OT.class */
public abstract class Vulcan_OT {
    private static final Vulcan_OT Vulcan_d = new Vulcan_OH(null);
    private static final Vulcan_OT Vulcan__;

    public abstract String Vulcan_B(Object[] objArr);

    static {
        Vulcan_OT vulcan_OH;
        try {
            vulcan_OH = new Vulcan_OH(System.getProperties());
        } catch (SecurityException e) {
            vulcan_OH = Vulcan_d;
        }
        Vulcan__ = vulcan_OH;
    }

    public static Vulcan_OT Vulcan_K(Object[] objArr) {
        return Vulcan_d;
    }

    public static Vulcan_OT Vulcan_h(Object[] objArr) {
        return Vulcan__;
    }

    public static Vulcan_OT Vulcan_C(Object[] objArr) {
        return new Vulcan_OH((Map) objArr[0]);
    }

    protected Vulcan_OT() {
    }
}
