package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_n.class */
interface InterfaceC0031Vulcan_n {
    int Vulcan_r(Object[] objArr);

    void Vulcan_g(Object[] objArr);
}
