package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fD.class */
class Vulcan_fD {
    private final Object Vulcan_Q;
    private final Object Vulcan_C;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(1315541650955982593L, 2858359902746701842L, null).a(7689864691302L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_fD(Object obj, Object obj2) {
        this.Vulcan_Q = obj;
        this.Vulcan_C = obj2;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            Method dump skipped, instruction units count: 216
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fD.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object] */
    public int hashCode() {
        ?? A;
        int iHashCode;
        long j = a ^ 51866011260534L;
        ?? Vulcan_Y = Vulcan_G.Vulcan_Y();
        try {
            try {
                Vulcan_Y = this.Vulcan_Q;
                ?? r0 = Vulcan_Y;
                if (Vulcan_Y != 0) {
                    A = r0.hashCode();
                } else if (Vulcan_Y == 0) {
                    A = 0;
                } else {
                    r0 = this.Vulcan_Q;
                    A = r0.hashCode();
                }
                try {
                    try {
                        Object obj = this.Vulcan_C;
                        if (Vulcan_Y != 0) {
                            iHashCode = obj.hashCode();
                        } else if (obj == null) {
                            iHashCode = 0;
                        } else {
                            obj = this.Vulcan_C;
                            iHashCode = obj.hashCode();
                        }
                        return A + iHashCode;
                    } catch (RuntimeException unused) {
                        throw a(A);
                    }
                } catch (RuntimeException unused2) {
                    A = a(A);
                    throw A;
                }
            } catch (RuntimeException unused3) {
                throw a(Vulcan_Y);
            }
        } catch (RuntimeException unused4) {
            Vulcan_Y = a(Vulcan_Y);
            throw Vulcan_Y;
        }
    }

    public String toString() {
        return new StringBuffer().append("[").append(this.Vulcan_Q).append(':').append(this.Vulcan_C).append(']').toString();
    }
}
