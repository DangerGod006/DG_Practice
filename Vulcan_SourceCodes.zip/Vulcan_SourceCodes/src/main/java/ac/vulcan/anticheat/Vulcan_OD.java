package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OD.class */
public final class Vulcan_OD extends Vulcan_OA implements Serializable {
    private static final long serialVersionUID = 71849363892740L;
    private final double Vulcan_a;
    private final double Vulcan_z;
    private transient Double Vulcan_q;
    private transient Double Vulcan_Z;
    private transient int Vulcan_o;
    private transient String Vulcan_P;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(5928048026840377800L, -9197262553265378081L, null).a(154329495018835L);
    private static final String[] d;

    /*  JADX ERROR: Failed to decode insn: 0x00B1: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[11]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_O(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 244
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: Failed to decode insn: 0x00E7: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[11]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_I(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 298
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.Vulcan_I(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0086, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0089, code lost:
    
        r11 = "W=0Dc\u0001\u0010a0'\u0017-\u0019\bp!u\nb\u0000]a0u*l:\u001aW=0Dc\u0001\u0010a0'D`\u0001\u000ewu;\u000byT\u001ffu\u001b\u0005C".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0092, code lost:
    
        ac.vulcan.anticheat.Vulcan_OD.d = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00aa, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b9, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009a, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00aa, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b9, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "W=0Dc\u0001\u0010a0'\u0017-\u0019\bp!u\nb\u0000]a0u*l:\u001aW=0Dc\u0001\u0010a0'D`\u0001\u000ewu;\u000byT\u001ffu\u001b\u0005C".length();
        r11 = 27;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r10 = r10 + 1;
        "W=0Dc\u0001\u0010a0'\u0017-\u0019\bp!u\nb\u0000]a0u*l:\u001aW=0Dc\u0001\u0010a0'D`\u0001\u000ewu;\u000byT\u001ffu\u001b\u0005C".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ad, B:28:0x0110], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0115 -> B:34:0x00ad). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.m87clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    public Vulcan_OD(double d2) {
        long j = a ^ 122395578305961L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        this.Vulcan_q = null;
        try {
            try {
                this.Vulcan_Z = null;
                this.Vulcan_o = 0;
                this.Vulcan_P = null;
                if (Vulcan_u != 0) {
                    Vulcan_u = Double.isNaN(d2);
                    if (Vulcan_u != 0) {
                        throw new IllegalArgumentException(d[4]);
                    }
                    this.Vulcan_a = d2;
                    this.Vulcan_z = d2;
                }
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00b9 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00a2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [ac.vulcan.anticheat.Vulcan_OD] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OD(java.lang.Number r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OD.a
            r1 = 15502597144416(0xe197acbbf60, double:7.6593006703726E-311)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r5
            r1.<init>()
            r1 = r5
            r2 = 0
            r1.Vulcan_q = r2
            r9 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_Z = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r5
            r1 = 0
            r0.Vulcan_o = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r5
            r1 = 0
            r0.Vulcan_P = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r9
            if (r0 != 0) goto L56
            r0 = r6
            if (r0 != 0) goto L46
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L35:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L42
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_OD.d     // Catch: java.lang.IllegalArgumentException -> L42
            r3 = 3
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L42
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0
        L46:
            r0 = r5
            r1 = r6
            double r1 = r1.doubleValue()
            r0.Vulcan_a = r1
            r0 = r5
            r1 = r6
            double r1 = r1.doubleValue()
            r0.Vulcan_z = r1
        L56:
            r0 = r5
            double r0 = r0.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L68
            boolean r0 = java.lang.Double.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L68
            r1 = r9
            if (r1 != 0) goto L7a
            if (r0 != 0) goto L89
            goto L6c
        L68:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            throw r0     // Catch: java.lang.IllegalArgumentException -> L76
        L6c:
            r0 = r5
            double r0 = r0.Vulcan_z     // Catch: java.lang.IllegalArgumentException -> L76
            boolean r0 = java.lang.Double.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L76
            goto L7a
        L76:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L7a:
            r1 = r9
            if (r1 != 0) goto L9f
            if (r0 == 0) goto L9b
            goto L89
        L85:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L97
            throw r0     // Catch: java.lang.IllegalArgumentException -> L97
        L89:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L97
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_OD.d     // Catch: java.lang.IllegalArgumentException -> L97
            r3 = 6
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L97
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L97
            throw r0     // Catch: java.lang.IllegalArgumentException -> L97
        L97:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L97
            throw r0
        L9b:
            r0 = r6
            boolean r0 = r0 instanceof java.lang.Double
        L9f:
            if (r0 == 0) goto Lb9
            r0 = r5
            r1 = r6
            java.lang.Double r1 = (java.lang.Double) r1     // Catch: java.lang.IllegalArgumentException -> Lb5
            r0.Vulcan_q = r1     // Catch: java.lang.IllegalArgumentException -> Lb5
            r0 = r5
            r1 = r6
            java.lang.Double r1 = (java.lang.Double) r1     // Catch: java.lang.IllegalArgumentException -> Lb5
            r0.Vulcan_Z = r1     // Catch: java.lang.IllegalArgumentException -> Lb5
            goto Lb9
        Lb5:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        Lb9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.<init>(java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x006a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OD(double r6, double r8) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OD.a
            r1 = 13624076972414(0xc641a44b17e, double:6.7311883883666E-311)
            long r0 = r0 ^ r1
            r10 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r5
            r1.<init>()
            r12 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_q = r1     // Catch: java.lang.IllegalArgumentException -> L35
            r0 = r5
            r1 = 0
            r0.Vulcan_Z = r1     // Catch: java.lang.IllegalArgumentException -> L35
            r0 = r5
            r1 = 0
            r0.Vulcan_o = r1     // Catch: java.lang.IllegalArgumentException -> L35
            r0 = r5
            r1 = 0
            r0.Vulcan_P = r1     // Catch: java.lang.IllegalArgumentException -> L35
            r0 = r6
            boolean r0 = java.lang.Double.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L35
            r1 = r12
            if (r1 != 0) goto L44
            if (r0 != 0) goto L53
            goto L39
        L35:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L40
            throw r0     // Catch: java.lang.IllegalArgumentException -> L40
        L39:
            r0 = r8
            boolean r0 = java.lang.Double.isNaN(r0)     // Catch: java.lang.IllegalArgumentException -> L40
            goto L44
        L40:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L44:
            r1 = r12
            if (r1 != 0) goto L67
            if (r0 == 0) goto L64
            goto L53
        L4f:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0     // Catch: java.lang.IllegalArgumentException -> L60
        L53:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L60
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_OD.d     // Catch: java.lang.IllegalArgumentException -> L60
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L60
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0     // Catch: java.lang.IllegalArgumentException -> L60
        L60:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L60
            throw r0
        L64:
            r0 = r8
            r1 = r6
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L67:
            if (r0 >= 0) goto L80
            r0 = r5
            r1 = r8
            r0.Vulcan_a = r1     // Catch: java.lang.IllegalArgumentException -> L7c java.lang.IllegalArgumentException -> L8d
            r0 = r5
            r1 = r6
            r0.Vulcan_z = r1     // Catch: java.lang.IllegalArgumentException -> L7c java.lang.IllegalArgumentException -> L8d
            r0 = r12
            if (r0 == 0) goto L91
            goto L80
        L7c:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L8d
            throw r0     // Catch: java.lang.IllegalArgumentException -> L8d
        L80:
            r0 = r5
            r1 = r6
            r0.Vulcan_a = r1     // Catch: java.lang.IllegalArgumentException -> L8d
            r0 = r5
            r1 = r8
            r0.Vulcan_z = r1     // Catch: java.lang.IllegalArgumentException -> L8d
            goto L91
        L8d:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L91:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.<init>(double, double):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:46:0x00b2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_OD(java.lang.Number r6, java.lang.Number r7) {
        /*
            Method dump skipped, instruction units count: 359
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.<init>(java.lang.Number, java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Double, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_v(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan_q;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan_q = new Double(this.Vulcan_a);
                }
                return this.Vulcan_q;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_j(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (long) this.Vulcan_a;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_g(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_a;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_Q(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_a;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_W(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (float) this.Vulcan_a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Double, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_l(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                Vulcan_Q = this.Vulcan_Z;
                if (Vulcan_Q != 0) {
                    return Vulcan_Q;
                }
                if (Vulcan_Q == 0) {
                    this.Vulcan_Z = new Double(this.Vulcan_z);
                }
                return this.Vulcan_Z;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_E(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (long) this.Vulcan_z;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_z;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_X(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_z;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_U(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (float) this.Vulcan_z;
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_OD, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Double] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0044: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_p(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r15 = r1
            r0 = r13
            r1 = r0; r2 = r0; 
            r2 = 105550352242296(0x5fff5b405678, double:5.2148802949361E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L24
            throw r0
        L28:
            r0 = r11
            r1 = r15
            double r1 = r1.doubleValue()
            r2 = r16
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_A(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_A(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r13 = r0
            r0 = r11
            r1 = r7
            double r1 = r1.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L34
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r13
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L48
            if (r1 == 0) goto L46
            if (r0 < 0) goto L59
            goto L38
        L34:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L38:
            r0 = r11
            r1 = r7
            double r1 = r1.Vulcan_z     // Catch: java.lang.IllegalArgumentException -> L42
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L46
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L46:
            r1 = r13
        L48:
            if (r1 == 0) goto L56
            if (r0 > 0) goto L59
            goto L55
        L51:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L55:
            r0 = 1
        L56:
            goto L5a
        L59:
            r0 = 0
        L5a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.Vulcan_A(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OD.a
            r1 = 56288958003280(0x3331cb58b850, double:2.78104403896213E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 == 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 == 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_OD     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_OD r0 = (ac.vulcan.anticheat.Vulcan_OD) r0
            r10 = r0
            r0 = r5
            double r0 = r0.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L5e
            long r0 = java.lang.Double.doubleToLongBits(r0)     // Catch: java.lang.IllegalArgumentException -> L5e
            r1 = r10
            double r1 = r1.Vulcan_a     // Catch: java.lang.IllegalArgumentException -> L5e
            long r1 = java.lang.Double.doubleToLongBits(r1)     // Catch: java.lang.IllegalArgumentException -> L5e
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            if (r1 == 0) goto L79
            if (r0 != 0) goto L8c
            goto L62
        L5e:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L75
            throw r0     // Catch: java.lang.IllegalArgumentException -> L75
        L62:
            r0 = r5
            double r0 = r0.Vulcan_z     // Catch: java.lang.IllegalArgumentException -> L75
            long r0 = java.lang.Double.doubleToLongBits(r0)     // Catch: java.lang.IllegalArgumentException -> L75
            r1 = r10
            double r1 = r1.Vulcan_z     // Catch: java.lang.IllegalArgumentException -> L75
            long r1 = java.lang.Double.doubleToLongBits(r1)     // Catch: java.lang.IllegalArgumentException -> L75
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L79
        L75:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L79:
            r1 = r9
            if (r1 == 0) goto L89
            if (r0 != 0) goto L8c
            goto L88
        L84:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L88:
            r0 = 1
        L89:
            goto L8d
        L8c:
            r0 = 0
        L8d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int hashCode() {
        long j = a ^ 57706862289766L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            Vulcan_u = this.Vulcan_o;
            if (Vulcan_u == 0) {
                return Vulcan_u;
            }
            if (Vulcan_u == 0) {
                this.Vulcan_o = 17;
                this.Vulcan_o = (37 * this.Vulcan_o) + getClass().hashCode();
                long jDoubleToLongBits = Double.doubleToLongBits(this.Vulcan_a);
                this.Vulcan_o = (37 * this.Vulcan_o) + ((int) (jDoubleToLongBits ^ (jDoubleToLongBits >> 32)));
                long jDoubleToLongBits2 = Double.doubleToLongBits(this.Vulcan_z);
                this.Vulcan_o = (37 * this.Vulcan_o) + ((int) (jDoubleToLongBits2 ^ (jDoubleToLongBits2 >> 32)));
            }
            return this.Vulcan_o;
        } catch (IllegalArgumentException unused) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0036: PHI (r0v10 ?? I:ac.vulcan.anticheat.Vulcan_P) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 290
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OD.toString():java.lang.String");
    }
}
