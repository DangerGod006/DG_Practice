package ac.vulcan.anticheat;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fV.class */
public abstract class Vulcan_fV implements Serializable {
    public static final Vulcan_fV Vulcan_w;
    public static final Vulcan_fV Vulcan_m;
    public static final Vulcan_fV Vulcan_f;
    public static final Vulcan_fV Vulcan_T;
    public static final Vulcan_fV Vulcan_q;
    private static final ThreadLocal Vulcan_a;
    private boolean Vulcan__ = true;
    private boolean Vulcan_J = true;
    private boolean Vulcan_n = false;
    private boolean Vulcan_p = true;
    private String Vulcan_H = "[";
    private String Vulcan_W = "]";
    private String Vulcan_o = "=";
    private boolean Vulcan_R = false;
    private boolean Vulcan_Q = false;
    private String Vulcan_v = ",";
    private String Vulcan_h = "{";
    private String Vulcan_B = ",";
    private boolean Vulcan_M = true;
    private String Vulcan_b = "}";
    private boolean Vulcan_L = true;
    private String Vulcan_u;
    private String Vulcan_s;
    private String Vulcan_V;
    private String Vulcan_x;
    private String Vulcan_I;
    private static boolean Vulcan_E;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-7997205157380283820L, -7939459502137570612L, null).a(182363824967463L);
    private static final String[] c;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x008e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_J9(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 130318576299981(0x76862872afcd, double:6.4385931564762E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r1 = r0; r2 = r0; 
            r2 = 19050352321994(0x1153817ba5ca, double:9.4121246234693E-311)
            long r1 = r1 ^ r2
            r17 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r19 = r0
            r0 = r9
            r1 = r19
            if (r1 != 0) goto L81
            boolean r0 = r0.Vulcan_Q     // Catch: java.lang.RuntimeException -> L48 java.lang.RuntimeException -> L6e
            if (r0 != 0) goto L72
            goto L4c
        L48:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6e
            throw r0     // Catch: java.lang.RuntimeException -> L6e
        L4c:
            r0 = r9
            r1 = r15
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L6e
            r4 = r3; r3 = r2; r2 = r4;      // Catch: java.lang.RuntimeException -> L6e
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L6e
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L6e
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L6e
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L6e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L6e
            java.lang.Long r4 = new java.lang.Long     // Catch: java.lang.RuntimeException -> L6e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L6e
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.RuntimeException -> L6e
            r4.<init>(r5)     // Catch: java.lang.RuntimeException -> L6e
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L6e
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L6e
            r0.Vulcan_X7(r1)     // Catch: java.lang.RuntimeException -> L6e
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L72:
            r0 = r9
            r1 = r11
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_S(r1)
            r0 = r12
        L81:
            r1 = r17
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_vd(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_J9(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x095a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    protected void Vulcan_Y(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 2452
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_Y(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0030: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    protected java.lang.String m211Vulcan_l(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 42126365818851(0x26504f11ffe3, double:2.0813190135235E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r13
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0014Vulcan_fv.Vulcan_A(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.m211Vulcan_l(java.lang.Object[]):java.lang.String");
    }

    public static void Vulcan_i(boolean z) {
        Vulcan_E = z;
    }

    public static boolean Vulcan_u() {
        return Vulcan_E;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_H() {
        return !Vulcan_u();
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0077, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x007b, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0083, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a8, code lost:
    
        r7 = 21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00ad, code lost:
    
        r7 = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b2, code lost:
    
        r7 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b7, code lost:
    
        r7 = 59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00bc, code lost:
    
        r7 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00c1, code lost:
    
        r7 = 72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c6, code lost:
    
        r7 = 46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c8, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00d0, code lost:
    
        if (r2 != 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00d3, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d8, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00dd, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00e1, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0064, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 72;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0074, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00dd -> B:10:0x0077). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 301
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.m208clinit():void");
    }

    static Map Vulcan_l(Object[] objArr) {
        return (Map) Vulcan_a.get();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0045  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static boolean Vulcan_C(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.util.Map r1 = Vulcan_l(r1)
            r10 = r1
            r9 = r0
            r0 = r10
            r1 = r9
            if (r1 != 0) goto L3a
            if (r0 == 0) goto L53
            goto L38
        L34:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L38:
            r0 = r10
        L3a:
            r1 = r6
            boolean r0 = r0.containsKey(r1)     // Catch: java.lang.RuntimeException -> L4b
            r1 = r9
            if (r1 != 0) goto L50
            if (r0 == 0) goto L53
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            r0 = 1
        L50:
            goto L54
        L53:
            r0 = 0
        L54:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_C(java.lang.Object[]):boolean");
    }

    static void Vulcan_vf(Object[] objArr) {
        Object obj = objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        int iVulcan_V = Vulcan_fl.Vulcan_V();
        if (obj != null) {
            Map mapVulcan_l = Vulcan_l(new Object[0]);
            if (iVulcan_V == 0) {
                if (mapVulcan_l == null) {
                    mapVulcan_l = new WeakHashMap();
                    Vulcan_a.set(mapVulcan_l);
                }
                mapVulcan_l.put(obj, null);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.ThreadLocal] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    static void Vulcan_vd(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object obj = objArr[1];
        long j = a ^ jLongValue;
        int iVulcan_V = Vulcan_fl.Vulcan_V();
        if (obj != null) {
            ?? Vulcan_l = Vulcan_l(new Object[0]);
            try {
                ?? r0 = Vulcan_l;
                ?? r02 = r0;
                if (j >= 0) {
                    r02 = r0;
                    if (iVulcan_V == 0) {
                        if (r0 != 0) {
                            Vulcan_l.remove(obj);
                            r02 = Vulcan_l;
                        } else {
                            return;
                        }
                    }
                }
                try {
                    if (r02.isEmpty()) {
                        r02 = Vulcan_a;
                        r02.set(null);
                    }
                } catch (RuntimeException unused) {
                    throw a(r02);
                }
            } catch (RuntimeException unused2) {
                throw a(Vulcan_l);
            }
        }
    }

    protected Vulcan_fV() {
        String[] strArr = c;
        this.Vulcan_u = strArr[0];
        this.Vulcan_s = strArr[1];
        this.Vulcan_V = ">";
        this.Vulcan_x = "<";
        this.Vulcan_I = ">";
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_wC(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 122341161881852(0x6f44c57ed0fc, double:6.04445651581257E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r10
            r1 = r12
            r2 = r16
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_h(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_wC(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_h(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 242
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_h(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0048: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_JB(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0048: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    protected void Vulcan_X7(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 258
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_X7(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v9 ??, still in use, count: 3, list:
          (r1v9 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x00b0: MOVE (r2v15 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v9 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v9 ?? I:??[OBJECT, ARRAY]) from 0x011a: APUT (r3v17 ?? I:??[OBJECT, ARRAY][]), (r5v14 ?? I:??[int, short, byte, char]), (r1v9 ?? I:??[OBJECT, ARRAY])
          (r1v9 ?? I:??[OBJECT, ARRAY]) from 0x0092: APUT (r3v10 ?? I:??[OBJECT, ARRAY][]), (r5v10 ?? I:??[int, short, byte, char]), (r1v9 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00aa, RuntimeException -> 0x00b5]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_Kh(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v9 ??, still in use, count: 3, list:
          (r1v9 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x00b0: MOVE (r2v15 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v9 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
          (r1v9 ?? I:??[OBJECT, ARRAY]) from 0x011a: APUT (r3v17 ?? I:??[OBJECT, ARRAY][]), (r5v14 ?? I:??[int, short, byte, char]), (r1v9 ?? I:??[OBJECT, ARRAY])
          (r1v9 ?? I:??[OBJECT, ARRAY]) from 0x0092: APUT (r3v10 ?? I:??[OBJECT, ARRAY][]), (r5v10 ?? I:??[int, short, byte, char]), (r1v9 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00aa, RuntimeException -> 0x00b5]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.lambda$unbindInsns$1(InsnRemover.java:99)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at jadx.core.utils.InsnRemover.unbindInsns(InsnRemover.java:98)
        	at jadx.core.utils.InsnRemover.perform(InsnRemover.java:73)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:59)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r15v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_kH(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 24159229025741(0x15f902439dcd, double:1.19362450916293E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            r1 = r16
            r2 = r11
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_D(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_kH(java.lang.Object[]):void");
    }

    protected void Vulcan_k(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(objArr[2]);
    }

    protected void Vulcan_t(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append((Collection) objArr[2]);
    }

    protected void Vulcan_zI(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append((Map) objArr[2]);
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_kd(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 118792255558561(0x6c0a7a31d3a1, double:5.8691172463479E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r16
            r1 = r11
            java.lang.String r1 = r1.Vulcan_x
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r16
            r1 = r11
            r2 = r15
            java.lang.Class r2 = r2.getClass()
            r3 = r18
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.String r1 = r1.m211Vulcan_l(r2)
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r16
            r1 = r11
            java.lang.String r1 = r1.Vulcan_I
            java.lang.StringBuffer r0 = r0.append(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_kd(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_n(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    protected void Vulcan_nf(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Long) objArr[2]).longValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan__(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 63788533050438(0x3a03ecda6c46, double:3.15157227788304E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_j(r1)
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan__(java.lang.Object[]):void");
    }

    protected void Vulcan_j(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Integer) objArr[2]).intValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_VZ(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 69674756217167(0x3f5e6b18194f, double:3.4423903429266E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_V(r1)
            r0 = r11
            r1 = r13
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_VZ(java.lang.Object[]):void");
    }

    protected void Vulcan_V(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Integer) objArr[2]).intValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public void m209Vulcan_l(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 118901189667621(0x6c23d72c6b25, double:5.87449930644257E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r13
            r2 = r17
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r13
            r2 = r17
            r3 = r16
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Z(r1)
            r0 = r11
            r1 = r13
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.m209Vulcan_l(java.lang.Object[]):void");
    }

    protected void Vulcan_Z(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Integer) objArr[2]).intValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_bF(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 112053242575832(0x65e96db83bd8, double:5.53616576618343E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r14
            r2 = r17
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r14
            r2 = r17
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_z(r1)
            r0 = r11
            r1 = r14
            r2 = r17
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_bF(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v9, types: [char, int] */
    protected void Vulcan_z(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append((char) ((Integer) objArr[2]).intValue());
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_G(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0000: PHI (r1v9 ?? I:java.lang.Long) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r12v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    protected void Vulcan_G6(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Double) objArr[2]).doubleValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_JV(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 35982882161647(0x20b9eae8c3ef, double:1.77779059144236E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r14
            r2 = r15
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r14
            r2 = r15
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_J(r1)
            r0 = r11
            r1 = r14
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_JV(java.lang.Object[]):void");
    }

    protected void Vulcan_J(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Float) objArr[2]).floatValue());
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_e(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 114959811736300(0x688e2abdf2ec, double:5.6797693631283E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r11
            r1 = r17
            r2 = r16
            r3 = r18
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w3(r1)
            r0 = r11
            r1 = r17
            r2 = r16
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ep(r1)
            r0 = r11
            r1 = r17
            r2 = r16
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_w(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_e(java.lang.Object[]):void");
    }

    protected void Vulcan_ep(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(((Boolean) objArr[2]).booleanValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v16, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_a(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_a(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r13v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r6v2, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x00c9: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00ec]
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x00c9: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00ec]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_bk(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 264
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_bk(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r13v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r6v2, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00f4]
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00f4]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_kn(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 272
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_kn(java.lang.Object[]):void");
    }

    protected void Vulcan_b(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((Object[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v33, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v39, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_ai(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_ai(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00b2 -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x008e: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x008e: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_A(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r17
            r2 = r11
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r18 = r0
            r0 = 0
            r19 = r0
        L3d:
            r0 = r19
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La4
        L44:
            r0 = r18
            r1 = r15
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L52
            if (r0 == 0) goto Lb5
            r0 = r19
        L52:
            r1 = r15
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto La1
            if (r0 <= 0) goto L74
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L70
            throw r0     // Catch: java.lang.RuntimeException -> L70
        L63:
            r0 = r17
            r1 = r11
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L70
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L70
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L74:
            r0 = r11
            r1 = r17
            r2 = r14
            r3 = r13
            r4 = r19
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_nf(r1)
            int r19 = r19 + 1
            r0 = r18
        La1:
            if (r0 != 0) goto L3d
        La4:
            r0 = r17
            r1 = r11
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r15
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
        Lb5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_A(java.lang.Object[]):void");
    }

    protected void Vulcan_AS(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((long[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v33, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v39, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_ld(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_ld(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0054, code lost:
    
        if (r0 <= 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0057, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0061, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0071, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0072, code lost:
    
        Vulcan_j(new java.lang.Object[]{r1, r1, new java.lang.Integer(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009f, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a2, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00af, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00b2, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0044, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0049, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004c, code lost:
    
        if (r0 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004f, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0044, B:20:0x00a2], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00af -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_sD(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r15
            r2 = r9
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r1 = 0
            r17 = r1
            r16 = r0
        L3c:
            r0 = r17
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La2
        L44:
            r0 = r16
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L51
            if (r0 == 0) goto Lb2
            r0 = r17
        L51:
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L9f
            if (r0 <= 0) goto L72
            goto L61
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6e
            throw r0     // Catch: java.lang.RuntimeException -> L6e
        L61:
            r0 = r15
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6e
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6e
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L72:
            r0 = r9
            r1 = r15
            r2 = r14
            r3 = r13
            r4 = r17
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_j(r1)
            int r17 = r17 + 1
            r0 = r16
        L9f:
            if (r0 != 0) goto L3c
        La2:
            r0 = r15
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
        Lb2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_sD(java.lang.Object[]):void");
    }

    protected void Vulcan_sd(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((int[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v32, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00ce: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00dd, RuntimeException -> 0x011c]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00ce: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00dd, RuntimeException -> 0x011c]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_Xl(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 345
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_Xl(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0052, code lost:
    
        if (r0 <= 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0055, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x005f, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x006f, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0070, code lost:
    
        Vulcan_V(new java.lang.Object[]{r1, r1, new java.lang.Integer(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009c, code lost:
    
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x009f, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ac, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00af, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003f, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0042, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0047, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004a, code lost:
    
        if (r0 != 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004d, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0042, B:20:0x009f], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00ac -> B:5:0x0042). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_q(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r1 = r14
            r2 = r9
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r1 = 0
            r17 = r1
            r16 = r0
        L3b:
            r0 = r17
            r1 = r11
            int r1 = r1.length
            if (r0 >= r1) goto L9f
        L42:
            r0 = r16
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L4f
            if (r0 != 0) goto Laf
            r0 = r17
        L4f:
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L9c
            if (r0 <= 0) goto L70
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6c
            throw r0     // Catch: java.lang.RuntimeException -> L6c
        L5f:
            r0 = r14
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6c
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6c
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L70:
            r0 = r9
            r1 = r14
            r2 = r15
            r3 = r11
            r4 = r17
            short r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_V(r1)
            int r17 = r17 + 1
            r0 = r16
        L9c:
            if (r0 == 0) goto L3b
        L9f:
            r0 = r14
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L42
        Laf:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_q(java.lang.Object[]):void");
    }

    protected void Vulcan_N(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((short[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_x(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_x(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0056, code lost:
    
        if (r0 <= 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0059, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0063, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0072, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0073, code lost:
    
        Vulcan_Z(new java.lang.Object[]{r1, r1, new java.lang.Integer(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009e, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a1, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ae, code lost:
    
        if (r0 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00b1, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0044, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x004a, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004d, code lost:
    
        if (r0 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0050, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0044, B:20:0x00a1], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00ae -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_P(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r11
            r2 = r9
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r16 = r0
            r0 = 0
            r17 = r0
        L3c:
            r0 = r17
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La1
        L44:
            r0 = r16
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L52
            if (r0 == 0) goto Lb1
            r0 = r17
        L52:
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L9e
            if (r0 <= 0) goto L73
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6f
            throw r0     // Catch: java.lang.RuntimeException -> L6f
        L63:
            r0 = r11
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6f
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6f
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L73:
            r0 = r9
            r1 = r11
            r2 = r12
            r3 = r13
            r4 = r17
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Z(r1)
            int r17 = r17 + 1
            r0 = r16
        L9e:
            if (r0 != 0) goto L3c
        La1:
            r0 = r11
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
        Lb1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_P(java.lang.Object[]):void");
    }

    protected void Vulcan_u(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((byte[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_d0(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_d0(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0054, code lost:
    
        if (r0 < 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0057, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0061, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0071, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0072, code lost:
    
        Vulcan_z(new java.lang.Object[]{r1, r1, new java.lang.Integer(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009f, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a2, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00af, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00b2, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0044, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0049, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004c, code lost:
    
        if (r0 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004f, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0044, B:20:0x00a2], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00af -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_m(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r13
            r2 = r9
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r16 = r0
            r0 = 0
            r17 = r0
        L3c:
            r0 = r17
            r1 = r15
            int r1 = r1.length
            if (r0 >= r1) goto La2
        L44:
            r0 = r16
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L51
            if (r0 == 0) goto Lb2
            r0 = r17
        L51:
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L9f
            if (r0 <= 0) goto L72
            goto L61
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6e
            throw r0     // Catch: java.lang.RuntimeException -> L6e
        L61:
            r0 = r13
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6e
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6e
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L72:
            r0 = r9
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r17
            char r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_z(r1)
            int r17 = r17 + 1
            r0 = r16
        L9f:
            if (r0 != 0) goto L3c
        La2:
            r0 = r13
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L44
        Lb2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_m(java.lang.Object[]):void");
    }

    protected void Vulcan_D(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((char[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_K(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_K(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Double] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00ae -> B:5:0x0042). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x008b: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x008b: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_v(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r1 = r17
            r2 = r11
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r18 = r0
            r0 = 0
            r19 = r0
        L3b:
            r0 = r19
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La1
        L42:
            r0 = r18
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L4f
            if (r0 != 0) goto Lb1
            r0 = r19
        L4f:
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L9e
            if (r0 <= 0) goto L70
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6c
            throw r0     // Catch: java.lang.RuntimeException -> L6c
        L5f:
            r0 = r17
            r1 = r11
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6c
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6c
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L70:
            r0 = r11
            r1 = r17
            r2 = r16
            r3 = r13
            r4 = r19
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Double r6 = new java.lang.Double
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_G6(r1)
            int r19 = r19 + 1
            r0 = r18
        L9e:
            if (r0 == 0) goto L3b
        La1:
            r0 = r17
            r1 = r11
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L42
        Lb1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_v(java.lang.Object[]):void");
    }

    protected void Vulcan_Mj(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((double[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r12v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00cf: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00de, RuntimeException -> 0x011d]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00cf: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00de, RuntimeException -> 0x011d]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_Zh(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 347
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_Zh(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0056, code lost:
    
        if (r0 < 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0059, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0063, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0072, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0073, code lost:
    
        Vulcan_J(new java.lang.Object[]{r1, r1, new java.lang.Boolean(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009e, code lost:
    
        if (r0 == 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a1, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ae, code lost:
    
        if (r0 <= 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00b1, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0041, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0044, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x004a, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004d, code lost:
    
        if (r0 != 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0050, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0044, B:20:0x00a1], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00ae -> B:5:0x0044). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_c(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r11
            r1 = r9
            java.lang.String r1 = r1.Vulcan_h
            java.lang.StringBuffer r0 = r0.append(r1)
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r1 = 0
            r17 = r1
            r16 = r0
        L3c:
            r0 = r17
            r1 = r13
            int r1 = r1.length
            if (r0 >= r1) goto La1
        L44:
            r0 = r16
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L52
            if (r0 != 0) goto Lb1
            r0 = r17
        L52:
            r1 = r14
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L9e
            if (r0 <= 0) goto L73
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6f
            throw r0     // Catch: java.lang.RuntimeException -> L6f
        L63:
            r0 = r11
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6f
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6f
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L73:
            r0 = r9
            r1 = r11
            r2 = r12
            r3 = r13
            r4 = r17
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_J(r1)
            int r17 = r17 + 1
            r0 = r16
        L9e:
            if (r0 == 0) goto L3c
        La1:
            r0 = r11
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L44
        Lb1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_c(java.lang.Object[]):void");
    }

    protected void Vulcan_cR(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((float[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r3v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v32, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v18 ??, still in use, count: 2, list:
          (r5v18 ?? I:??[OBJECT, ARRAY][]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
          (r5v18 ?? I:??[OBJECT, ARRAY]) from 0x00d1: APUT (r5v18 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v18 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x00e0, RuntimeException -> 0x0120]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_Vw(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_Vw(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0053, code lost:
    
        if (r0 <= 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0056, code lost:
    
        if (r0 <= 0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0060, code lost:
    
        r1.append(r9.Vulcan_B);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0070, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0071, code lost:
    
        Vulcan_ep(new java.lang.Object[]{r1, r1, new java.lang.Boolean(r1[r17])});
        r17 = r17 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009d, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a0, code lost:
    
        r1.append(r9.Vulcan_b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ad, code lost:
    
        if (r0 < 0) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00b0, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0040, code lost:
    
        if (r17 < r1.length) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0043, code lost:
    
        r0 = r0;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0048, code lost:
    
        if (r0 < 0) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004b, code lost:
    
        if (r0 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x004e, code lost:
    
        r0 = r17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:5:0x0043, B:20:0x00a0], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r9v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x00ad -> B:5:0x0043). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void Vulcan_O(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r15
            r2 = r9
            java.lang.String r2 = r2.Vulcan_h
            java.lang.StringBuffer r1 = r1.append(r2)
            r1 = 0
            r17 = r1
            r16 = r0
        L3b:
            r0 = r17
            r1 = r14
            int r1 = r1.length
            if (r0 >= r1) goto La0
        L43:
            r0 = r16
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L50
            if (r0 == 0) goto Lb0
            r0 = r17
        L50:
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L9d
            if (r0 <= 0) goto L71
            goto L60
        L5c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6d
            throw r0     // Catch: java.lang.RuntimeException -> L6d
        L60:
            r0 = r15
            r1 = r9
            java.lang.String r1 = r1.Vulcan_B     // Catch: java.lang.RuntimeException -> L6d
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L6d
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L71:
            r0 = r9
            r1 = r15
            r2 = r11
            r3 = r14
            r4 = r17
            r3 = r3[r4]
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ep(r1)
            int r17 = r17 + 1
            r0 = r16
        L9d:
            if (r0 != 0) goto L3b
        La0:
            r0 = r15
            r1 = r9
            java.lang.String r1 = r1.Vulcan_b
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L43
        Lb0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_O(java.lang.Object[]):void");
    }

    protected void Vulcan_H(Object[] objArr) {
        m210Vulcan_C(new Object[]{(StringBuffer) objArr[0], (String) objArr[1], new Integer(((boolean[]) objArr[2]).length)});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.StringBuffer] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v5, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r11v0, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v2, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x007e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x009c]
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x007e: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY]) A[Catch: RuntimeException -> 0x009c]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_F(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 241
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_F(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v5, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0075: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0075: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    protected void Vulcan_i(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fV.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 81172810193274(0x49d38484597a, double:4.0104696892889E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r17 = r0
            r0 = r9
            r1 = r17
            if (r1 == 0) goto L51
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L45 java.lang.RuntimeException -> L4d
            boolean r0 = r0.mo214Vulcan_n(r1)     // Catch: java.lang.RuntimeException -> L45 java.lang.RuntimeException -> L4d
            if (r0 == 0) goto L91
            goto L49
        L45:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0     // Catch: java.lang.RuntimeException -> L4d
        L49:
            r0 = r11
            goto L51
        L4d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L51:
            r1 = r17
            if (r1 == 0) goto L61
            if (r0 == 0) goto L91
            goto L60
        L5c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L60:
            r0 = r11
        L61:
            r1 = r15
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_vf(r0)
            r0 = r12
            r1 = 64
            java.lang.StringBuffer r0 = r0.append(r1)
            r0 = r12
            r1 = r11
            int r1 = java.lang.System.identityHashCode(r1)
            java.lang.String r1 = java.lang.Integer.toHexString(r1)
            java.lang.StringBuffer r0 = r0.append(r1)
        L91:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fV.Vulcan_i(java.lang.Object[]):void");
    }

    protected void Vulcan_U(Object[] objArr) {
        ((StringBuffer) objArr[0]).append(this.Vulcan_H);
    }

    protected void Vulcan_S(Object[] objArr) {
        ((StringBuffer) objArr[0]).append(this.Vulcan_W);
    }

    protected void Vulcan_g(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        stringBuffer.append(this.Vulcan_u);
    }

    protected void Vulcan_X(Object[] objArr) {
        ((StringBuffer) objArr[0]).append(this.Vulcan_v);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    protected void Vulcan_w3(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        String str = (String) objArr[1];
        ?? LongValue = a ^ ((Long) objArr[2]).longValue();
        try {
            try {
                LongValue = this.Vulcan__;
                if (LongValue != 0 && str != null) {
                    stringBuffer.append(str);
                    stringBuffer.append(this.Vulcan_o);
                }
            } catch (RuntimeException unused) {
                throw a(LongValue);
            }
        } catch (RuntimeException unused2) {
            throw a(LongValue);
        }
    }

    protected void Vulcan_w(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        Vulcan_X(new Object[]{stringBuffer});
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    protected void m210Vulcan_C(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        int iIntValue = ((Integer) objArr[2]).intValue();
        stringBuffer.append(this.Vulcan_s);
        stringBuffer.append(iIntValue);
        stringBuffer.append(this.Vulcan_V);
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    protected boolean Vulcan_y(Object[] objArr) {
        Boolean bool = (Boolean) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_V = Vulcan_fl.Vulcan_V();
        try {
            Boolean bool2 = bool;
            if (Vulcan_V == 0) {
                if (bool2 == null) {
                    return this.Vulcan_L;
                }
                bool2 = bool;
            }
            return bool2.booleanValue();
        } catch (RuntimeException unused) {
            throw a(Vulcan_V);
        }
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    protected boolean mo212Vulcan_b(Object[] objArr) {
        return this.Vulcan_J;
    }

    protected void Vulcan_p(Object[] objArr) {
        this.Vulcan_J = ((Boolean) objArr[0]).booleanValue();
    }

    protected boolean Vulcan_d(Object[] objArr) {
        return this.Vulcan_n;
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    protected boolean mo213Vulcan_P(Object[] objArr) {
        return this.Vulcan_n;
    }

    protected void Vulcan_M(Object[] objArr) {
        this.Vulcan_n = ((Boolean) objArr[0]).booleanValue();
    }

    protected void Vulcan_I(Object[] objArr) {
        this.Vulcan_n = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    protected boolean mo214Vulcan_n(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX INFO: renamed from: Vulcan_d */
    protected void mo192Vulcan_d(Object[] objArr) {
        this.Vulcan_p = ((Boolean) objArr[0]).booleanValue();
    }

    protected boolean Vulcan_W(Object[] objArr) {
        return this.Vulcan__;
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    protected void mo215Vulcan_y(Object[] objArr) {
        this.Vulcan__ = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    protected boolean mo216Vulcan_O(Object[] objArr) {
        return this.Vulcan_L;
    }

    protected void Vulcan_Ml(Object[] objArr) {
        this.Vulcan_L = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    protected boolean mo217Vulcan_Y(Object[] objArr) {
        return this.Vulcan_M;
    }

    /* JADX INFO: renamed from: Vulcan_W */
    protected void mo193Vulcan_W(Object[] objArr) {
        this.Vulcan_M = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_n */
    protected String mo194Vulcan_n(Object[] objArr) {
        return this.Vulcan_h;
    }

    protected void Vulcan_E(Object[] objArr) {
        String str = (String) objArr[0];
        ((Long) objArr[1]).longValue();
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_h = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_I */
    protected String mo195Vulcan_I(Object[] objArr) {
        return this.Vulcan_b;
    }

    protected void Vulcan_L(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_b = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_y */
    protected String mo196Vulcan_y(Object[] objArr) {
        return this.Vulcan_B;
    }

    protected void Vulcan_Ru(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_F() != 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_B = str;
        }
    }

    protected String Vulcan_Q(Object[] objArr) {
        return this.Vulcan_H;
    }

    protected void Vulcan_f(Object[] objArr) {
        String str = (String) objArr[0];
        if (((Long) objArr[1]).longValue() > 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_H = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    protected String mo218Vulcan_X(Object[] objArr) {
        return this.Vulcan_W;
    }

    protected void Vulcan_Re(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (jLongValue > 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_W = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_f */
    protected String mo197Vulcan_f(Object[] objArr) {
        return this.Vulcan_o;
    }

    /* JADX INFO: renamed from: Vulcan_Q */
    protected void mo198Vulcan_Q(Object[] objArr) {
        String str = (String) objArr[0];
        ((Long) objArr[1]).longValue();
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_o = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    protected String mo219Vulcan_j(Object[] objArr) {
        return this.Vulcan_v;
    }

    protected void Vulcan_B(Object[] objArr) {
        String str = (String) objArr[0];
        if (((Long) objArr[1]).longValue() >= 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_v = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    protected boolean mo220Vulcan_K(Object[] objArr) {
        return this.Vulcan_R;
    }

    protected void Vulcan_r(Object[] objArr) {
        this.Vulcan_R = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_E */
    protected boolean mo199Vulcan_E(Object[] objArr) {
        return this.Vulcan_Q;
    }

    protected void Vulcan_s(Object[] objArr) {
        this.Vulcan_Q = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    protected String mo221Vulcan_D(Object[] objArr) {
        return this.Vulcan_u;
    }

    protected void Vulcan_o(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_u = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    protected String mo222Vulcan_w(Object[] objArr) {
        return this.Vulcan_s;
    }

    protected void Vulcan_RC(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_s = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    protected String mo223Vulcan_G(Object[] objArr) {
        return this.Vulcan_V;
    }

    protected void Vulcan_R(Object[] objArr) {
        String str = (String) objArr[0];
        ((Long) objArr[1]).longValue();
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_V = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    protected String mo224Vulcan_k(Object[] objArr) {
        return this.Vulcan_x;
    }

    protected void Vulcan_T(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_x = str;
        }
    }

    /* JADX INFO: renamed from: Vulcan_T */
    protected String mo200Vulcan_T(Object[] objArr) {
        return this.Vulcan_I;
    }

    protected void Vulcan_R6(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        if (Vulcan_fl.Vulcan_V() == 0) {
            if (str == null) {
                str = "";
            }
            this.Vulcan_I = str;
        }
    }
}
