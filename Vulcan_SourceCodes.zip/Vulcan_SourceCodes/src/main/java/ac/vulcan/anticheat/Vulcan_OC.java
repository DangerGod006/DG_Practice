package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OC.class */
public final class Vulcan_OC extends Vulcan_OA implements Serializable {
    private static final long serialVersionUID = 71849363892720L;
    private final long Vulcan_H;
    private final long Vulcan_i;
    private transient Long Vulcan_F;
    private transient Long Vulcan_j;
    private transient int Vulcan_n;
    private transient String Vulcan_A;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(2446666403468988756L, -4226566769689725926L, null).a(235877844014566L);
    private static final String[] d;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0076, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a4, code lost:
    
        r7 = 61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        r7 = 12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ae, code lost:
    
        r7 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b3, code lost:
    
        r7 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        r7 = 28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00bd, code lost:
    
        r7 = 42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00c2, code lost:
    
        r7 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00c4, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00cc, code lost:
    
        if (r2 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00cf, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00d4, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00d9, code lost:
    
        if (r2 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00dd, code lost:
    
        r1 = new java.lang.String(r1).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x005f, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = 44;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006f, code lost:
    
        if (r2 > 1) goto L23;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00d9 -> B:10:0x0072). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.m86clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    public Vulcan_OC(long j) {
        this.Vulcan_F = null;
        this.Vulcan_j = null;
        this.Vulcan_n = 0;
        this.Vulcan_A = null;
        this.Vulcan_H = j;
        this.Vulcan_i = j;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0069 A[Catch: IllegalArgumentException -> 0x0074, TRY_LEAVE, TryCatch #1 {IllegalArgumentException -> 0x0074, blocks: (B:18:0x0063, B:20:0x0069), top: B:26:0x0063 }] */
    /* JADX WARN: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_OC] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OC(java.lang.Number r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OC.a
            r1 = 75530561784259(0x44b1d44e09c3, double:3.7317055788692E-310)
            long r0 = r0 ^ r1
            r7 = r0
            r0 = r5
            r0.<init>()
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r5
            r2 = 0
            r1.Vulcan_F = r2
            r1 = r5
            r2 = 0
            r1.Vulcan_j = r2
            r9 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_n = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r5
            r1 = 0
            r0.Vulcan_A = r1     // Catch: java.lang.IllegalArgumentException -> L31
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L63
            if (r0 != 0) goto L46
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L35:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L42
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_OC.d     // Catch: java.lang.IllegalArgumentException -> L42
            r3 = 2
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L42
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0     // Catch: java.lang.IllegalArgumentException -> L42
        L42:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L42
            throw r0
        L46:
            r0 = r5
            r1 = r6
            long r1 = r1.longValue()     // Catch: java.lang.IllegalArgumentException -> L5f
            r0.Vulcan_H = r1     // Catch: java.lang.IllegalArgumentException -> L5f
            r0 = r5
            r1 = r6
            long r1 = r1.longValue()     // Catch: java.lang.IllegalArgumentException -> L5f
            r0.Vulcan_i = r1     // Catch: java.lang.IllegalArgumentException -> L5f
            r0 = r9
            if (r0 != 0) goto L78
            r0 = r6
            goto L63
        L5f:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L63:
            boolean r0 = r0 instanceof java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L74
            if (r0 == 0) goto L80
            r0 = r5
            r1 = r6
            java.lang.Long r1 = (java.lang.Long) r1     // Catch: java.lang.IllegalArgumentException -> L74
            r0.Vulcan_F = r1     // Catch: java.lang.IllegalArgumentException -> L74
            goto L78
        L74:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L78:
            r0 = r5
            r1 = r6
            java.lang.Long r1 = (java.lang.Long) r1
            r0.Vulcan_j = r1
        L80:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.<init>(java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    public Vulcan_OC(long j, long j2) {
        long j3 = a ^ 11775281445843L;
        ?? Vulcan_Q = Vulcan_OA.Vulcan_Q();
        try {
            try {
                try {
                    this.Vulcan_F = null;
                    this.Vulcan_j = null;
                    this.Vulcan_n = 0;
                    this.Vulcan_A = null;
                    Vulcan_Q = Vulcan_Q;
                    if (Vulcan_Q == 0) {
                        if (j2 < j) {
                            this.Vulcan_H = j2;
                            this.Vulcan_i = j;
                            if (Vulcan_Q == 0) {
                                return;
                            }
                        }
                        this.Vulcan_H = j;
                    }
                    this.Vulcan_i = j2;
                } catch (IllegalArgumentException unused) {
                    throw a((IllegalArgumentException) Vulcan_Q);
                }
            } catch (IllegalArgumentException unused2) {
                throw a((IllegalArgumentException) Vulcan_Q);
            }
        } catch (IllegalArgumentException unused3) {
            throw a((IllegalArgumentException) Vulcan_Q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x003b  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0102 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:75:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Number] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.IllegalArgumentException, long] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [int] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [ac.vulcan.anticheat.Vulcan_OC] */
    /* JADX WARN: Type inference failed for: r0v27, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_OC(java.lang.Number r6, java.lang.Number r7) {
        /*
            Method dump skipped, instruction units count: 274
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.<init>(java.lang.Number, java.lang.Number):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Long, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_v(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_F;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_F = new Long(this.Vulcan_H);
                }
                return this.Vulcan_F;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_j(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_H;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_g(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_H;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_Q(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_H;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_W(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_H;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Long, java.lang.Number] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public Number Vulcan_l(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_j;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_j = new Long(this.Vulcan_i);
                }
                return this.Vulcan_j;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public long Vulcan_E(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_i;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return (int) this.Vulcan_i;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public double Vulcan_X(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_i;
    }

    @Override // ac.vulcan.anticheat.Vulcan_OA
    public float Vulcan_U(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_i;
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_OC, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_p(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r15 = r1
            r0 = r13
            r1 = r0; r2 = r0; 
            r2 = 64136118937638(0x3a54da962826, double:3.1687453024675E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            if (r0 != 0) goto L28
            r0 = 0
            return r0
        L24:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L24
            throw r0
        L28:
            r0 = r11
            r1 = r15
            long r1 = r1.longValue()
            r2 = r16
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_R(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.Vulcan_p(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_R(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_u()
            r13 = r0
            r0 = r9
            r1 = r7
            long r1 = r1.Vulcan_H     // Catch: java.lang.IllegalArgumentException -> L34
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r13
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L47
            if (r1 == 0) goto L45
            if (r0 < 0) goto L58
            goto L38
        L34:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L41
            throw r0     // Catch: java.lang.IllegalArgumentException -> L41
        L38:
            r0 = r9
            r1 = r7
            long r1 = r1.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L41
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L45
        L41:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L45:
            r1 = r13
        L47:
            if (r1 == 0) goto L55
            if (r0 > 0) goto L58
            goto L54
        L50:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L54:
            r0 = 1
        L55:
            goto L59
        L58:
            r0 = 0
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.Vulcan_R(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0035
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_O(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 236
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.Vulcan_O(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean Vulcan_I(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 287
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.Vulcan_I(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OC.a
            r1 = 69524891233340(0x3f3b8671ec3c, double:3.43498602892425E-310)
            long r0 = r0 ^ r1
            r7 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r5
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0     // Catch: java.lang.IllegalArgumentException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_OC     // Catch: java.lang.IllegalArgumentException -> L33 java.lang.IllegalArgumentException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0     // Catch: java.lang.IllegalArgumentException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            ac.vulcan.anticheat.Vulcan_OC r0 = (ac.vulcan.anticheat.Vulcan_OC) r0
            r10 = r0
            r0 = r5
            long r0 = r0.Vulcan_H     // Catch: java.lang.IllegalArgumentException -> L58
            r1 = r10
            long r1 = r1.Vulcan_H     // Catch: java.lang.IllegalArgumentException -> L58
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            if (r1 != 0) goto L6d
            if (r0 != 0) goto L80
            goto L5c
        L58:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L69
            throw r0     // Catch: java.lang.IllegalArgumentException -> L69
        L5c:
            r0 = r5
            long r0 = r0.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L69
            r1 = r10
            long r1 = r1.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L69
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L6d
        L69:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L6d:
            r1 = r9
            if (r1 != 0) goto L7d
            if (r0 != 0) goto L80
            goto L7c
        L78:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L7c:
            r0 = 1
        L7d:
            goto L81
        L80:
            r0 = 0
        L81:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public int hashCode() {
        long j = a ^ 92480044205041L;
        ?? Vulcan_u = Vulcan_OA.Vulcan_u();
        try {
            try {
                Vulcan_u = this.Vulcan_n;
                if (Vulcan_u == 0) {
                    return Vulcan_u;
                }
                if (Vulcan_u == 0) {
                    this.Vulcan_n = 17;
                    this.Vulcan_n = (37 * this.Vulcan_n) + getClass().hashCode();
                    this.Vulcan_n = (37 * this.Vulcan_n) + ((int) (this.Vulcan_H ^ (this.Vulcan_H >> 32)));
                    this.Vulcan_n = (37 * this.Vulcan_n) + ((int) (this.Vulcan_i ^ (this.Vulcan_i >> 32)));
                }
                return this.Vulcan_n;
            } catch (IllegalArgumentException unused) {
                throw a((IllegalArgumentException) Vulcan_u);
            }
        } catch (IllegalArgumentException unused2) {
            throw a((IllegalArgumentException) Vulcan_u);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0036: PHI (r0v10 ?? I:ac.vulcan.anticheat.Vulcan_P) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OA
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 290
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OC.toString():java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v7, types: [long[]] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.IllegalArgumentException] */
    public long[] Vulcan_d(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        int iVulcan_u = Vulcan_OA.Vulcan_u();
        long[] jArr = new long[(int) ((this.Vulcan_i - this.Vulcan_H) + 1)];
        int i = 0;
        loop0: while (i < jArr.length) {
            do {
                ?? r0 = jArr;
                int i2 = iVulcan_u;
                if (jLongValue >= 0) {
                    if (i2 == 0) {
                        return r0;
                    }
                    i2 = i;
                }
                try {
                    r0[i2] = this.Vulcan_H + ((long) i);
                    i++;
                    r0 = iVulcan_u;
                    if (r0 == 0) {
                    }
                } catch (IllegalArgumentException unused) {
                    throw a((IllegalArgumentException) r0);
                }
            } while (jLongValue <= 0);
        }
        return jArr;
    }
}
