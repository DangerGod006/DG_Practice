package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan__.class */
public class Vulcan__ {
    private int Vulcan_G = 0;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(7307963552985829619L, 3773933750638912682L, null).a(21104871341100L);
    private static final String b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00f6: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static int Vulcan_H(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 418
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_H(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0168: INVOKE (r-1 I:ac.vulcan.anticheat.Vulcan__), (r0 I:java.lang.Object[]) VIRTUAL call: ac.vulcan.anticheat.Vulcan__.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void Vulcan_M(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 400
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_M(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0023, code lost:
    
        r1 = "\u001f\u0004\u0012\u000b>8\u0006>\u000f\u0013S\u00071\t/\r\u0016\u001f\u000f>\u0006/\u0019\u000466>\u0000:\u001e\u001e\u001c ".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 19;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0031, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0034, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0037, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003e, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 89;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0034). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 7307963552985829619(0x656b1a21d738d0f3, double:3.5143905691534793E180)
            r1 = 3773933750638912682(0x345fb4c044b0a4aa, double:2.020426631163444E-56)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 21104871341100(0x1331dc5bfc2c, double:1.0427191889537E-310)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan__.a = r0
            r0 = 19
            java.lang.String r1 = "\u001f\u0004\u0012\u000b>8\u0006>\u000f\u0013S\u00071\t/\r\u0016\u001f\u000f>\u0006/\u0019\u000466>\u0000:\u001e\u001e\u001c "
            r2 = jsr -> L23
        L1d:
            ac.vulcan.anticheat.Vulcan__.b = r2
            goto Lab
        L23:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L34:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L37:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 89
            goto L84
        L69:
            r8 = 121(0x79, float:1.7E-43)
            goto L84
        L6e:
            r8 = 100
            goto L84
        L73:
            r8 = 96
            goto L84
        L78:
            r8 = 93
            goto L84
        L7d:
            r8 = 78
            goto L84
        L82:
            r8 = 118(0x76, float:1.65E-43)
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L37
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L34
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.m168clinit():void");
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v8 ??, still in use, count: 2, list:
          (r6v8 ?? I:??[OBJECT, ARRAY][]) from 0x004f: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
          (r6v8 ?? I:??[OBJECT, ARRAY]) from 0x004f: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_Z(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 65662077981741(0x3bb824d5542d, double:3.2441376965327E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r15
            r1 = r14
            r2 = 0
            r3 = r16
            r4 = 0
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_Z(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v8 ??, still in use, count: 2, list:
          (r6v8 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
          (r6v8 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_k(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 78332454508829(0x473e3220191d, double:3.87013747272347E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r13
            r1 = r12
            r2 = r14
            r3 = r17
            r4 = 0
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_k(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_U(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 74695151942976(0x43ef51ff7d40, double:3.69043084859165E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r1 = r0; r2 = r0; 
            r2 = 76398072081918(0x457bcff2adfe, double:3.7745662824179E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r12
            r1 = r15
            r2 = r16
            r3 = r19
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 1
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            java.lang.String[] r2 = ac.vulcan.anticheat.C0017Vulcan_g.Vulcan_r(r2)
            r3 = r17
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_O(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_U(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v8 ??, still in use, count: 2, list:
          (r6v8 ?? I:??[OBJECT, ARRAY][]) from 0x0056: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
          (r6v8 ?? I:??[OBJECT, ARRAY]) from 0x0056: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_O(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String[] r1 = (java.lang.String[]) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 46312147421306(0x2a1ee318887a, double:2.28812410260026E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r16
            r1 = r12
            r2 = 0
            r3 = r17
            r4 = 0
            r5 = r13
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_O(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [boolean, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v8 ??, still in use, count: 2, list:
          (r6v8 ?? I:??[OBJECT, ARRAY][]) from 0x0064: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
          (r6v8 ?? I:??[OBJECT, ARRAY]) from 0x0064: APUT (r6v8 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r6v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static int Vulcan_p(java.lang.Object[] r11) {
        /*
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r15 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 40832367122575(0x252306bcd88f, double:2.0173869833642E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            r1 = r14
            r2 = r15
            r3 = r18
            r4 = r13
            r5 = 0
            r6 = 6
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 5
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 4
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Boolean r5 = new java.lang.Boolean
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = Vulcan_H(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_p(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [ac.vulcan.anticheat.Vulcan__] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public Vulcan__ m169Vulcan_p(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? A = this;
        if (Vulcan_fl.Vulcan_F() == 0) {
            return A;
        }
        try {
            try {
                A = A.Vulcan_G;
                if (A != 0) {
                    return this;
                }
                this.Vulcan_G = iIntValue;
                return this;
            } catch (NullPointerException unused) {
                A = a(A);
                throw A;
            }
        } catch (NullPointerException unused2) {
            throw a(A);
        }
    }

    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v4 ??, still in use, count: 2, list:
          (r6v4 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
          (r6v4 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r6v4 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_F(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 77074976426807(0x46196a974b37, double:3.80800980065093E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            r1 = r13
            r2 = r16
            r3 = r17
            r4 = 0
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan__ r0 = r0.m170Vulcan_Z(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan__ m170Vulcan_Z(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 1239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.m170Vulcan_Z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_I(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r16 = r0
            r0 = r8
            r1 = r16
            if (r1 == 0) goto L49
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L3e java.lang.NullPointerException -> L44
            if (r0 == 0) goto L48
            goto L42
        L3e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L44
            throw r0     // Catch: java.lang.NullPointerException -> L44
        L42:
            r0 = r8
            return r0
        L44:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L44
            throw r0
        L48:
            r0 = r8
        L49:
            r1 = r10
            r2 = r12
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            r2 = r16
            r3 = r14
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L71
            if (r2 == 0) goto L6f
            if (r1 >= 0) goto L6b
            goto L63
        L5f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L67
            throw r0     // Catch: java.lang.NullPointerException -> L67
        L63:
            r1 = -1
            goto L83
        L67:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L67
            throw r0
        L6b:
            r1 = r10
            r2 = r12
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
        L6f:
            r2 = r16
        L71:
            if (r2 == 0) goto L7f
            if (r1 <= 0) goto L82
            goto L7e
        L7a:
            java.lang.Exception r0 = a(r0)
            throw r0
        L7e:
            r1 = 1
        L7f:
            goto L83
        L82:
            r1 = 0
        L83:
            r0.Vulcan_G = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_I(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_u(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L46
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L3b java.lang.NullPointerException -> L41
            if (r0 == 0) goto L45
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0     // Catch: java.lang.NullPointerException -> L41
        L3f:
            r0 = r8
            return r0
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0
        L45:
            r0 = r8
        L46:
            r1 = r10
            r2 = r13
            r3 = r14
            if (r3 != 0) goto L75
            if (r1 >= r2) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0     // Catch: java.lang.NullPointerException -> L5c
        L58:
            r1 = -1
            goto L7d
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0
        L60:
            r1 = r10
            r2 = r14
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L6e
            if (r2 != 0) goto L79
            r2 = r13
        L6e:
            goto L75
        L71:
            java.lang.Exception r0 = a(r0)
            throw r0
        L75:
            if (r1 <= r2) goto L7c
            r1 = 1
        L79:
            goto L7d
        L7c:
            r1 = 0
        L7d:
            r0.Vulcan_G = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_u(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_R(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L46
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L3b java.lang.NullPointerException -> L41
            if (r0 == 0) goto L45
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0     // Catch: java.lang.NullPointerException -> L41
        L3f:
            r0 = r8
            return r0
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0
        L45:
            r0 = r8
        L46:
            r1 = r13
            r2 = r10
            r3 = r14
            if (r3 != 0) goto L75
            if (r1 >= r2) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0     // Catch: java.lang.NullPointerException -> L5c
        L58:
            r1 = -1
            goto L7d
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0
        L60:
            r1 = r13
            r2 = r14
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L6e
            if (r2 != 0) goto L79
            r2 = r10
        L6e:
            goto L75
        L71:
            java.lang.Exception r0 = a(r0)
            throw r0
        L75:
            if (r1 <= r2) goto L7c
            r1 = 1
        L79:
            goto L7d
        L7c:
            r1 = 0
        L7d:
            r0.Vulcan_G = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_R(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_J(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L46
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L3b java.lang.NullPointerException -> L41
            if (r0 == 0) goto L45
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0     // Catch: java.lang.NullPointerException -> L41
        L3f:
            r0 = r8
            return r0
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0
        L45:
            r0 = r8
        L46:
            r1 = r10
            r2 = r13
            r3 = r14
            if (r3 != 0) goto L75
            if (r1 >= r2) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0     // Catch: java.lang.NullPointerException -> L5c
        L58:
            r1 = -1
            goto L7d
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0
        L60:
            r1 = r10
            r2 = r14
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L6e
            if (r2 != 0) goto L79
            r2 = r13
        L6e:
            goto L75
        L71:
            java.lang.Exception r0 = a(r0)
            throw r0
        L75:
            if (r1 <= r2) goto L7c
            r1 = 1
        L79:
            goto L7d
        L7c:
            r1 = 0
        L7d:
            r0.Vulcan_G = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_J(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_x(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r14 = r0
            r0 = r8
            r1 = r14
            if (r1 == 0) goto L46
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L3b java.lang.NullPointerException -> L41
            if (r0 == 0) goto L45
            goto L3f
        L3b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0     // Catch: java.lang.NullPointerException -> L41
        L3f:
            r0 = r8
            return r0
        L41:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L41
            throw r0
        L45:
            r0 = r8
        L46:
            r1 = r10
            r2 = r13
            r3 = r14
            if (r3 == 0) goto L75
            if (r1 >= r2) goto L60
            goto L58
        L54:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0     // Catch: java.lang.NullPointerException -> L5c
        L58:
            r1 = -1
            goto L7d
        L5c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L5c
            throw r0
        L60:
            r1 = r10
            r2 = r14
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L6e
            if (r2 == 0) goto L79
            r2 = r13
        L6e:
            goto L75
        L71:
            java.lang.Exception r0 = a(r0)
            throw r0
        L75:
            if (r1 <= r2) goto L7c
            r1 = 1
        L79:
            goto L7d
        L7c:
            r1 = 0
        L7d:
            r0.Vulcan_G = r1
            r0 = r8
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_x(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan__] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan__, double, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v6, types: [java.lang.Double] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Double] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x006a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x006a: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_c(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r19 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 125478141712619(0x721f281058eb, double:6.19944391242046E-310)
            long r1 = r1 ^ r2
            r21 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r23 = r0
            r0 = r13
            r1 = r23
            if (r1 == 0) goto L90
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L48 java.lang.NullPointerException -> L4e
            if (r0 == 0) goto L52
            goto L4c
        L48:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4e
            throw r0     // Catch: java.lang.NullPointerException -> L4e
        L4c:
            r0 = r13
            return r0
        L4e:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4e
            throw r0
        L52:
            r0 = r13
            r1 = r21
            r2 = r15
            r3 = r19
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Double r6 = new java.lang.Double
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r5 = new java.lang.Double
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r1 = ac.vulcan.anticheat.Vulcan_O9.m81Vulcan_k(r1)
            r0.Vulcan_G = r1
            r0 = r13
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_c(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan__] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r4v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0075: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0075: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_b(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 1742333753786(0x195ab2f39ba, double:8.608272513353E-312)
            long r1 = r1 ^ r2
            r16 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r18 = r0
            r0 = r10
            r1 = r18
            if (r1 != 0) goto L8a
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L47 java.lang.NullPointerException -> L4d
            if (r0 == 0) goto L51
            goto L4b
        L47:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4d
            throw r0     // Catch: java.lang.NullPointerException -> L4d
        L4b:
            r0 = r10
            return r0
        L4d:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L4d
            throw r0
        L51:
            r0 = r10
            r1 = r12
            r2 = r16
            r3 = r13
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r1 = ac.vulcan.anticheat.Vulcan_O9.Vulcan_Q(r1)
            r0.Vulcan_G = r1
            r0 = r10
        L8a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_b(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan__ m171Vulcan_H(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r11 = r1
            r0 = r9
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r12
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r8
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan__.a
            long r0 = r0 ^ r1
            r13 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_V()
            r15 = r0
            r0 = r6
            int r0 = r0.Vulcan_G     // Catch: java.lang.NullPointerException -> L69
            r1 = r15
            if (r1 != 0) goto L75
            if (r0 == 0) goto L73
            goto L6d
        L69:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6f
            throw r0     // Catch: java.lang.NullPointerException -> L6f
        L6d:
            r0 = r6
            return r0
        L6f:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L6f
            throw r0
        L73:
            r0 = r10
        L75:
            r1 = r9
            if (r1 < 0) goto L92
            r1 = r15
            if (r1 != 0) goto L92
            r1 = r11
            if (r0 != r1) goto L90
            goto L8a
        L86:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L8c
            throw r0     // Catch: java.lang.NullPointerException -> L8c
        L8a:
            r0 = r6
            return r0
        L8c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> L8c
            throw r0
        L90:
            r0 = r10
        L92:
            r1 = r8
            if (r1 < 0) goto La5
            if (r0 != 0) goto Laf
            r0 = r6
            r1 = r12
            if (r1 < 0) goto Lbc
            r1 = -1
            r0.Vulcan_G = r1     // Catch: java.lang.NullPointerException -> Lab java.lang.NullPointerException -> Lb7
            r0 = r15
        La5:
            if (r0 == 0) goto Lbb
            goto Laf
        Lab:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.NullPointerException -> Lb7
            throw r0     // Catch: java.lang.NullPointerException -> Lb7
        Laf:
            r0 = r6
            r1 = 1
            r0.Vulcan_G = r1     // Catch: java.lang.NullPointerException -> Lb7
            goto Lbb
        Lb7:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lbb:
            r0 = r6
        Lbc:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.m171Vulcan_H(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_g(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan__.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 15499929013934(0xe18dbc34eae, double:7.657982438763E-311)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            r1 = r16
            r2 = r17
            r3 = 0
            r4 = r18
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan__ r0 = r0.Vulcan_L(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_g(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_L(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 382
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_L(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_v(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 379
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_v(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_j(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 377
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_j(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_r(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 377
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_r(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_s(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 375
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_s(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_o(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 375
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_o(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_y(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 387
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_f(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 383
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_f(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public ac.vulcan.anticheat.Vulcan__ Vulcan_S(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 433
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan__.Vulcan_S(java.lang.Object[]):ac.vulcan.anticheat.Vulcan__");
    }

    public int Vulcan__(Object[] objArr) {
        return this.Vulcan_G;
    }
}
