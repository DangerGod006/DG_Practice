package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Q.class */
class Vulcan_Q implements InterfaceC0031Vulcan_n {
    private final String Vulcan_c;

    Vulcan_Q(String str) {
        this.Vulcan_c = str;
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return this.Vulcan_c.length();
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        ((Long) objArr[2]).longValue();
        stringBuffer.append(this.Vulcan_c);
    }
}
