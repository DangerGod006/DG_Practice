package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Ob.class */
public class Vulcan_Ob implements Serializable {
    private static final long serialVersionUID = 7092611880189329093L;

    Vulcan_Ob() {
    }

    private Object readResolve() {
        return C0016Vulcan_fy.Vulcan_y;
    }
}
