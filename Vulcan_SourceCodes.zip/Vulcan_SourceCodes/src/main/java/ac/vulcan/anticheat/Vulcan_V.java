package ac.vulcan.anticheat;

import java.math.BigDecimal;
import java.math.BigInteger;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_V.class */
public final class Vulcan_V {
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(1862812274829076965L, -5661533049690971923L, null).a(108300434825785L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x02a0: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.lang.Number Vulcan_h(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 1839
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.Vulcan_h(java.lang.Object[]):java.lang.Number");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_j(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 1557
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.Vulcan_j(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0085, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0088, code lost:
    
        r11 = "\\\u000bGDE\nY\u0011]GL\u0016\\V\u0012@\u0003\rX_Z\u001cL\u0015\u0003\u0017^@\u0014\rXEC^HG[WF^\u001a\t\tX[HR\f\u0007".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0091, code lost:
    
        ac.vulcan.anticheat.Vulcan_V.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a9, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b8, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0108, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0099, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a9, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ac, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b0, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b8, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0100, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0108, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010b, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0110, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0115, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0119, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003b, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004b, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0057, code lost:
    
        r2 = "\\\u000bGDE\nY\u0011]GL\u0016\\V\u0012@\u0003\rX_Z\u001cL\u0015\u0003\u0017^@\u0014\rXEC^HG[WF^\u001a\t\tX[HR\f\u0007".length();
        r11 = 25;
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0065, code lost:
    
        r10 = r10 + 1;
        "\\\u000bGDE\nY\u0011]GL\u0016\\V\u0012@\u0003\rX_Z\u001cL\u0015\u0003\u0017^@\u0014\rXEC^HG[WF^\u001a\t\tX[HR\f\u0007".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0075, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ac, B:28:0x0110], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0115 -> B:15:0x00ac). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0115 -> B:34:0x00ac). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.m156clinit():void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public static int Vulcan_Q(Object[] objArr) {
        return Vulcan_k(new Object[]{(String) objArr[0], new Integer(0)});
    }

    public static int Vulcan_k(Object[] objArr) {
        try {
            return Integer.parseInt((String) objArr[0]);
        } catch (NumberFormatException e) {
            return ((Integer) objArr[1]).intValue();
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static boolean Vulcan_V(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_V.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r10
            r1 = r11
            if (r1 != 0) goto L35
            if (r0 != 0) goto L34
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0     // Catch: java.lang.NumberFormatException -> L30
        L2e:
            r0 = 1
            return r0
        L30:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L30
            throw r0
        L34:
            r0 = r10
        L35:
            int r0 = r0.length()
            r1 = 1
            int r0 = r0 - r1
            r12 = r0
        L3c:
            r0 = r12
            if (r0 < 0) goto L7b
            r0 = r10
        L42:
            r1 = r12
            char r0 = r0.charAt(r1)     // Catch: java.lang.NumberFormatException -> L5a
            r1 = r11
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L87
            if (r1 != 0) goto L85
            r1 = r11
            if (r1 != 0) goto L72
            goto L5e
        L5a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L66
            throw r0     // Catch: java.lang.NumberFormatException -> L66
        L5e:
            r1 = 48
            if (r0 == r1) goto L73
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L6e
            throw r0     // Catch: java.lang.NumberFormatException -> L6e
        L6a:
            r0 = 0
            goto L72
        L6e:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L72:
            return r0
        L73:
            int r12 = r12 + (-1)
            r0 = r11
            if (r0 == 0) goto L3c
        L7b:
            r0 = r10
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L42
            int r0 = r0.length()
        L85:
            r1 = r11
        L87:
            if (r1 != 0) goto L95
            if (r0 <= 0) goto L98
            goto L94
        L90:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L94:
            r0 = 1
        L95:
            goto L99
        L98:
            r0 = 0
        L99:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.Vulcan_V(java.lang.Object[]):boolean");
    }

    public static Float Vulcan_Z(Object[] objArr) {
        return Float.valueOf((String) objArr[0]);
    }

    public static Double Vulcan_D(Object[] objArr) {
        return Double.valueOf((String) objArr[0]);
    }

    public static Integer Vulcan_s(Object[] objArr) {
        return Integer.decode((String) objArr[0]);
    }

    public static Long Vulcan_y(Object[] objArr) {
        return Long.valueOf((String) objArr[0]);
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static BigInteger m157Vulcan_s(Object[] objArr) {
        return new BigInteger((String) objArr[0]);
    }

    public static BigDecimal Vulcan_a(Object[] objArr) {
        return new BigDecimal((String) objArr[0]);
    }

    public static long Vulcan_E(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        long jLongValue2 = ((Long) objArr[1]).longValue();
        long jLongValue3 = ((Long) objArr[2]).longValue();
        long jLongValue4 = a ^ ((Long) objArr[3]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        int i = (jLongValue2 > jLongValue ? 1 : (jLongValue2 == jLongValue ? 0 : -1));
        if (strVulcan_k == null) {
            if (i < 0) {
                jLongValue = jLongValue2;
            }
            if (strVulcan_k == null) {
                i = (jLongValue3 > jLongValue ? 1 : (jLongValue3 == jLongValue ? 0 : -1));
            } else {
                return jLongValue3;
            }
        }
        if (i < 0) {
            jLongValue = jLongValue3;
        }
        return jLongValue;
    }

    public static int Vulcan_M(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        long jLongValue = ((Long) objArr[1]).longValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (strVulcan_k == null) {
            if (i < i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            if (strVulcan_k != null) {
                return i;
            }
            i2 = iIntValue;
        }
        if (i < i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue;
    }

    public static long Vulcan_d(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        long jLongValue2 = ((Long) objArr[1]).longValue();
        long jLongValue3 = ((Long) objArr[2]).longValue();
        long jLongValue4 = a ^ ((Long) objArr[3]).longValue();
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        int i = (jLongValue2 > jLongValue ? 1 : (jLongValue2 == jLongValue ? 0 : -1));
        if (strVulcan_k == null) {
            if (i > 0) {
                jLongValue = jLongValue2;
            }
            if (strVulcan_k == null) {
                i = (jLongValue3 > jLongValue ? 1 : (jLongValue3 == jLongValue ? 0 : -1));
            } else {
                return jLongValue3;
            }
        }
        if (i > 0) {
            jLongValue = jLongValue3;
        }
        return jLongValue;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static int m158Vulcan_h(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        int iIntValue3 = ((Integer) objArr[3]).intValue();
        long j = a ^ jLongValue;
        String strVulcan_k = Vulcan_fX.Vulcan_k();
        int i = iIntValue2;
        int i2 = iIntValue;
        if (strVulcan_k == null) {
            if (i > i2) {
                iIntValue = iIntValue2;
            }
            i = iIntValue3;
            if (strVulcan_k != null) {
                return i;
            }
            i2 = iIntValue;
        }
        if (i > i2) {
            iIntValue = iIntValue3;
        }
        return iIntValue;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_u(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_V.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r14 = r0
            r0 = r8
            r1 = r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 != 0) goto L55
            if (r0 >= 0) goto L46
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L42
            throw r0     // Catch: java.lang.NumberFormatException -> L42
        L40:
            r0 = -1
            return r0
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L42
            throw r0
        L46:
            r0 = r8
            r1 = r14
            if (r1 != 0) goto L66
            r1 = r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L55:
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L60
            if (r0 <= 0) goto L65
            r0 = 1
        L60:
            return r0
        L61:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L61
            throw r0
        L65:
            r0 = r8
        L66:
            long r0 = java.lang.Double.doubleToLongBits(r0)
            r15 = r0
            r0 = r10
            long r0 = java.lang.Double.doubleToLongBits(r0)
            r17 = r0
            r0 = r15
            r1 = r17
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            r2 = r12
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L99
            if (r1 != 0) goto L97
            if (r0 != 0) goto L92
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L8e
            throw r0     // Catch: java.lang.NumberFormatException -> L8e
        L8c:
            r0 = 0
            return r0
        L8e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L8e
            throw r0
        L92:
            r0 = r15
            r1 = r17
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L97:
            r1 = r14
        L99:
            if (r1 != 0) goto Lad
            if (r0 >= 0) goto Lac
            goto La6
        La2:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La8
            throw r0     // Catch: java.lang.NumberFormatException -> La8
        La6:
            r0 = -1
            return r0
        La8:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> La8
            throw r0
        Lac:
            r0 = 1
        Lad:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.Vulcan_u(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public static int m159Vulcan_s(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_V.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r12 = r0
            r0 = r9
            r1 = r8
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            if (r1 != 0) goto L46
            if (r0 >= 0) goto L43
            goto L3d
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3f
            throw r0     // Catch: java.lang.NumberFormatException -> L3f
        L3d:
            r0 = -1
            return r0
        L3f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L3f
            throw r0
        L43:
            r0 = r9
            r1 = r8
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L46:
            r1 = r12
            if (r1 != 0) goto L5f
            if (r0 <= 0) goto L5b
            goto L55
        L51:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L57
            throw r0     // Catch: java.lang.NumberFormatException -> L57
        L55:
            r0 = 1
            return r0
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L57
            throw r0
        L5b:
            r0 = r9
            int r0 = java.lang.Float.floatToIntBits(r0)
        L5f:
            r13 = r0
            r0 = r8
            int r0 = java.lang.Float.floatToIntBits(r0)
            r14 = r0
            r0 = r13
            r1 = r14
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L96
            r2 = r12
            if (r2 != 0) goto L96
            if (r0 != r1) goto L86
            goto L80
        L7c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L82
            throw r0     // Catch: java.lang.NumberFormatException -> L82
        L80:
            r0 = 0
            return r0
        L82:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L82
            throw r0
        L86:
            r0 = r13
            r1 = r12
            if (r1 != 0) goto La0
            r1 = r14
            goto L96
        L92:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L96:
            if (r0 >= r1) goto L9f
            r0 = -1
            return r0
        L9b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L9b
            throw r0
        L9f:
            r0 = 1
        La0:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.m159Vulcan_s(java.lang.Object[]):int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x0050, code lost:
    
        if (r0 < r1.length()) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0053, code lost:
    
        r0 = java.lang.Character.isDigit(r1.charAt(r12 == true ? 1 : 0));
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0061, code lost:
    
        if (r0 < 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0064, code lost:
    
        if (r1 != null) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0067, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0069, code lost:
    
        if (r1 != null) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x006f, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0072, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0073, code lost:
    
        if (r0 != 0) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x007c, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x007d, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x007f, code lost:
    
        r12 = r12 + 1;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0084, code lost:
    
        if (r0 == null) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0087, code lost:
    
        r0 = (r0 > 0 ? 1 : (r0 == 0 ? 0 : -1));
        r0 = r0;
        r12 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x008a, code lost:
    
        if (r0 < 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x008d, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:46:0x0053, B:40:0x0087], limit reached: 53 */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v2, types: [int] */
    /* JADX WARN: Type inference failed for: r12v3, types: [int] */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:39:0x0084 -> B:40:0x0087). Please report as a decompilation issue!!! */
    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m160Vulcan_M(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_V.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r11 = r0
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L2f
            if (r0 == 0) goto L41
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2e:
            r0 = r8
        L2f:
            int r0 = r0.length()     // Catch: java.lang.NumberFormatException -> L3d
            r1 = r11
            if (r1 != 0) goto L48
            if (r0 != 0) goto L47
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L43
            throw r0     // Catch: java.lang.NumberFormatException -> L43
        L41:
            r0 = 0
            return r0
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L43
            throw r0
        L47:
            r0 = 0
        L48:
            r12 = r0
        L4a:
            r0 = r12
            r1 = r8
            int r1 = r1.length()
            if (r0 >= r1) goto L87
        L53:
            r0 = r8
            r1 = r12
            char r0 = r0.charAt(r1)     // Catch: java.lang.NumberFormatException -> L6f
            boolean r0 = java.lang.Character.isDigit(r0)     // Catch: java.lang.NumberFormatException -> L6f
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L69
            if (r1 != 0) goto L8e
            r1 = r11
        L69:
            if (r1 != 0) goto L7e
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.NumberFormatException -> L79
            throw r0     // Catch: java.lang.NumberFormatException -> L79
        L73:
            if (r0 != 0) goto L7f
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7d:
            r0 = 0
        L7e:
            return r0
        L7f:
            int r12 = r12 + 1
            r0 = r11
            if (r0 == 0) goto L4a
        L87:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L53
            r0 = 1
        L8e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_V.m160Vulcan_M(java.lang.Object[]):boolean");
    }
}
