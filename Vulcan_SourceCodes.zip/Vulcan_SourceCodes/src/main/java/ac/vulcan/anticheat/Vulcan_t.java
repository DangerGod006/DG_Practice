package ac.vulcan.anticheat;

import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_t.class */
public interface Vulcan_t {
    void Vulcan_T(Object[] objArr);

    boolean Vulcan_s(Object[] objArr);

    Plugin Vulcan_k(Object[] objArr);

    boolean Vulcan_I(Object[] objArr);

    boolean Vulcan_H(Object[] objArr);
}
