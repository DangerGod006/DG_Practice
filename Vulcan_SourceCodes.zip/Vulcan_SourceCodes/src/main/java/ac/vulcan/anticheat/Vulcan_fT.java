package ac.vulcan.anticheat;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.plugin.Plugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fT.class */
public class Vulcan_fT implements Vulcan_t {
    private final ScheduledTask Vulcan_G;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_fT(ScheduledTask scheduledTask) {
        this.Vulcan_G = scheduledTask;
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public void Vulcan_T(Object[] objArr) {
        this.Vulcan_G.cancel();
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_G.isCancelled();
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public Plugin Vulcan_k(Object[] objArr) {
        return this.Vulcan_G.getOwningPlugin();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0076 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.Vulcan_t
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_I(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r9 = r1
            r0 = r10
            long r0 = (long) r0
            r1 = 56
            long r0 = r0 << r1
            r1 = r8
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 8
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r9
            long r1 = (long) r1
            r2 = 40
            long r1 = r1 << r2
            r2 = 40
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r11 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_O0.Vulcan_k()
            r1 = r6
            io.papermc.paper.threadedregions.scheduler.ScheduledTask r1 = r1.Vulcan_G
            io.papermc.paper.threadedregions.scheduler.ScheduledTask$ExecutionState r1 = r1.getExecutionState()
            r14 = r1
            r13 = r0
            r0 = r14
            io.papermc.paper.threadedregions.scheduler.ScheduledTask$ExecutionState r1 = io.papermc.paper.threadedregions.scheduler.ScheduledTask.ExecutionState.RUNNING     // Catch: java.lang.RuntimeException -> L5b
            r2 = r13
            if (r2 == 0) goto L6b
            if (r0 == r1) goto L6e
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0     // Catch: java.lang.RuntimeException -> L67
        L5f:
            r0 = r14
            io.papermc.paper.threadedregions.scheduler.ScheduledTask$ExecutionState r1 = io.papermc.paper.threadedregions.scheduler.ScheduledTask.ExecutionState.CANCELLED_RUNNING     // Catch: java.lang.RuntimeException -> L67
            goto L6b
        L67:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6b:
            if (r0 != r1) goto L76
        L6e:
            r0 = 1
            goto L77
        L72:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L72
            throw r0
        L76:
            r0 = 0
        L77:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fT.Vulcan_I(java.lang.Object[]):boolean");
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_G.isRepeatingTask();
    }
}
