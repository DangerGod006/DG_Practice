package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_ft, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_ft.class */
public class C0013Vulcan_ft extends Number implements Comparable, Vulcan_Oi {
    private static final long serialVersionUID = 512176391864L;
    private int Vulcan_k;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5065909787756089258L, 5780256195102990986L, null).a(33189008533737L);

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    public C0013Vulcan_ft() {
    }

    public C0013Vulcan_ft(int i) {
        this.Vulcan_k = i;
    }

    public C0013Vulcan_ft(Number number) {
        this.Vulcan_k = number.intValue();
    }

    public C0013Vulcan_ft(String str) {
        this.Vulcan_k = Integer.parseInt(str);
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public Object Vulcan_f(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return new Integer(this.Vulcan_k);
    }

    public void Vulcan_x(Object[] objArr) {
        this.Vulcan_k = ((Integer) objArr[0]).intValue();
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        Vulcan_x(new Object[]{new Integer(((Number) objArr[0]).intValue())});
    }

    public void Vulcan_a(Object[] objArr) {
        this.Vulcan_k++;
    }

    public void Vulcan_w(Object[] objArr) {
        this.Vulcan_k--;
    }

    public void Vulcan_n(Object[] objArr) {
        this.Vulcan_k += ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_p(Object[] objArr) {
        this.Vulcan_k += ((Number) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public void m399Vulcan_f(Object[] objArr) {
        this.Vulcan_k -= ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Z(Object[] objArr) {
        this.Vulcan_k -= ((Number) objArr[0]).intValue();
    }

    @Override // java.lang.Number
    public int intValue() {
        return this.Vulcan_k;
    }

    @Override // java.lang.Number
    public long longValue() {
        return this.Vulcan_k;
    }

    @Override // java.lang.Number
    public float floatValue() {
        return this.Vulcan_k;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return this.Vulcan_k;
    }

    public Integer Vulcan_M(Object[] objArr) {
        return new Integer(intValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    public boolean equals(Object obj) {
        long j = a ^ 28722406686373L;
        NumberFormatException numberFormatExceptionVulcan_n = C0003Vulcan_On.Vulcan_n();
        try {
            try {
                try {
                    numberFormatExceptionVulcan_n = obj instanceof C0013Vulcan_ft;
                    try {
                        if (numberFormatExceptionVulcan_n == 0) {
                            return numberFormatExceptionVulcan_n;
                        }
                        if (numberFormatExceptionVulcan_n != 0) {
                            ?? r0 = this.Vulcan_k;
                            return numberFormatExceptionVulcan_n != 0 ? r0 == ((C0013Vulcan_ft) obj).intValue() : r0;
                        }
                        return false;
                    } catch (NumberFormatException unused) {
                        throw a(numberFormatExceptionVulcan_n);
                    }
                } catch (NumberFormatException unused2) {
                    throw a(numberFormatExceptionVulcan_n);
                }
            } catch (NumberFormatException unused3) {
                throw a(numberFormatExceptionVulcan_n);
            }
        } catch (NumberFormatException unused4) {
            throw a(numberFormatExceptionVulcan_n);
        }
    }

    public int hashCode() {
        return this.Vulcan_k;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NumberFormatException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.NumberFormatException, java.lang.Throwable] */
    @Override // java.lang.Comparable
    public int compareTo(Object obj) {
        long j = a ^ 57518998737723L;
        ?? Vulcan_n = C0003Vulcan_On.Vulcan_n();
        int i = ((C0013Vulcan_ft) obj).Vulcan_k;
        try {
            try {
                Vulcan_n = this.Vulcan_k;
                int i2 = i;
                ?? r0 = Vulcan_n;
                if (Vulcan_n != 0) {
                    if (Vulcan_n < i2) {
                        return -1;
                    }
                    try {
                        Vulcan_n = this.Vulcan_k;
                        if (Vulcan_n == 0) {
                            return Vulcan_n;
                        }
                        i2 = i;
                        r0 = Vulcan_n;
                    } catch (NumberFormatException unused) {
                        throw a(Vulcan_n);
                    }
                }
                return r0 == i2 ? 0 : 1;
            } catch (NumberFormatException unused2) {
                throw a(Vulcan_n);
            }
        } catch (NumberFormatException unused3) {
            Vulcan_n = a(Vulcan_n);
            throw Vulcan_n;
        }
    }

    public String toString() {
        return String.valueOf(this.Vulcan_k);
    }
}
