package ac.vulcan.anticheat;

import java.io.PrintWriter;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_Ow, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Ow.class */
public class C0006Vulcan_Ow extends Error implements Vulcan_OV {
    private static final long serialVersionUID = 1;
    protected C0034Vulcan_z Vulcan_b;
    private Throwable Vulcan_G;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-3336900517972115058L, -8876630725167060824L, null).a(42359452336708L);

    private static Vulcan_k5 a(Vulcan_k5 vulcan_k5) {
        return vulcan_k5;
    }

    public C0006Vulcan_Ow() {
        this.Vulcan_b = new C0034Vulcan_z(this);
        this.Vulcan_G = null;
    }

    public C0006Vulcan_Ow(String str) {
        super(str);
        this.Vulcan_b = new C0034Vulcan_z(this);
        this.Vulcan_G = null;
    }

    public C0006Vulcan_Ow(Throwable th) {
        this.Vulcan_b = new C0034Vulcan_z(this);
        this.Vulcan_G = null;
        this.Vulcan_G = th;
    }

    public C0006Vulcan_Ow(String str, Throwable th) {
        super(str);
        this.Vulcan_b = new C0034Vulcan_z(this);
        this.Vulcan_G = null;
        this.Vulcan_G = th;
    }

    @Override // java.lang.Throwable, ac.vulcan.anticheat.Vulcan_OV
    public Throwable getCause() {
        return this.Vulcan_G;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [ac.vulcan.anticheat.Vulcan_k5] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [ac.vulcan.anticheat.Vulcan_k5] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Error] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_k5] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.String] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // java.lang.Throwable, ac.vulcan.anticheat.Vulcan_OV
    public String getMessage() {
        long j = a ^ 107340447965144L;
        ?? Vulcan_J = Vulcan_k5.Vulcan_J();
        try {
            Vulcan_J = this;
            ?? r0 = Vulcan_J;
            if (Vulcan_J == 0) {
                try {
                    Vulcan_J = super.getMessage();
                    if (Vulcan_J != 0) {
                        return super.getMessage();
                    }
                    r0 = this.Vulcan_G;
                } catch (Vulcan_k5 unused) {
                    throw a(Vulcan_J);
                }
            }
            try {
                if (Vulcan_J == 0) {
                    if (r0 != 0) {
                        r0 = this.Vulcan_G;
                    } else {
                        return null;
                    }
                }
                return r0.toString();
            } catch (Vulcan_k5 unused2) {
                throw a(r0);
            }
        } catch (Vulcan_k5 unused3) {
            throw a(Vulcan_J);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 1, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0020: MOVE (r0v2 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:122)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public java.lang.String Vulcan_Q(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r1v3 ??, still in use, count: 1, list:
          (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) from 0x0020: MOVE (r0v2 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r1v3 ?? I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) A[TRY_ENTER] (LINE:122)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1123)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1134)
        	at jadx.core.utils.BlockUtils.replaceInsn(BlockUtils.java:1172)
        	at jadx.core.dex.visitors.ConstructorVisitor.removeAssignChain(ConstructorVisitor.java:243)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:93)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public java.lang.String[] Vulcan_o(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 68714559866092(0x3e7edaee84ec, double:3.39495033989377E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.String[] r0 = r0.Vulcan_J(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_o(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public java.lang.Throwable Vulcan_i(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 36253637605536(0x20f8f530f8a0, double:1.79116768776736E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r14
            r2 = r11
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Throwable r0 = r0.Vulcan_P(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_i(java.lang.Object[]):java.lang.Throwable");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public int Vulcan_K(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 102336041097419(0x5d12f76098cb, double:5.05607222376327E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.Vulcan_B(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_K(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x002d: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public java.lang.Throwable[] Vulcan_U(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r0 = r11
            r1 = r0; r2 = r0; 
            r2 = 27279943532035(0x18cf9b57fe03, double:1.34780829196676E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Throwable[] r0 = r0.Vulcan__(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_U(java.lang.Object[]):java.lang.Throwable[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public int Vulcan_y(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r0 = r13
            r1 = r0; r2 = r0; 
            r2 = 134018715317214(0x79e3a9eb73de, double:6.62140431380135E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r15
            r2 = 0
            r3 = r16
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.Vulcan_R(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_y(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.Vulcan_OV
    public int Vulcan_E(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r0 = r15
            r1 = r0; r2 = r0; 
            r2 = 41580866914693(0x25d14ccd4985, double:2.05436778668467E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r14
            r2 = r13
            r3 = r17
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            int r0 = r0.Vulcan_R(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.Vulcan_E(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0027: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0027: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.lang.Throwable
    public void printStackTrace() {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0006Vulcan_Ow.a
            r1 = 67877936387719(0x3dbc10495687, double:3.35361564797694E-310)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 114936844844080(0x6888d1cefc30, double:5.67863464788455E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r12
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_c(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.printStackTrace():void");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.lang.Throwable, ac.vulcan.anticheat.Vulcan_OV
    public void printStackTrace(java.io.PrintStream r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.C0006Vulcan_Ow.a
            r1 = 111912027148518(0x65c88c9fd0e6, double:5.52918879705357E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 57332754295907(0x3424d2742c63, double:2.8326144279065E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.printStackTrace(java.io.PrintStream):void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x002a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x002a: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.lang.Throwable, ac.vulcan.anticheat.Vulcan_OV
    public void printStackTrace(java.io.PrintWriter r11) {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.C0006Vulcan_Ow.a
            r1 = 119917153414910(0x6d106354eefe, double:5.92469458493814E-310)
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 82436822811137(0x4af9d18a4201, double:4.0729202103285E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r10
            ac.vulcan.anticheat.Vulcan_z r0 = r0.Vulcan_b
            r1 = r11
            r2 = r14
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_d(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0006Vulcan_Ow.printStackTrace(java.io.PrintWriter):void");
    }

    @Override // ac.vulcan.anticheat.Vulcan_OV
    public final void Vulcan_G(Object[] objArr) {
        super.printStackTrace((PrintWriter) objArr[0]);
    }
}
