package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kF.class */
final class Vulcan_kF extends Vulcan_kH {
    private final char Vulcan_V;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_kF(char c) {
        this.Vulcan_V = c;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [char, int] */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    @Override // ac.vulcan.anticheat.Vulcan_kH
    /* JADX INFO: renamed from: Vulcan_A */
    public int mo437Vulcan_A(Object[] objArr) {
        ?? r1;
        ?? r12;
        char[] cArr = (char[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        ((Integer) objArr[2]).intValue();
        ((Integer) objArr[3]).intValue();
        long jLongValue = ((Long) objArr[4]).longValue();
        ?? Vulcan_m = Vulcan_P.Vulcan_m();
        try {
            try {
                Vulcan_m = this.Vulcan_V;
                r1 = Vulcan_m;
                r12 = r1;
            } catch (RuntimeException unused) {
                Vulcan_m = a(Vulcan_m);
                throw Vulcan_m;
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_m);
        }
        if (jLongValue > 0) {
            if (r1 != 0) {
                return Vulcan_m;
            }
            r12 = cArr[iIntValue];
            throw a(Vulcan_m);
        }
        return Vulcan_m == r12 ? 1 : 0;
    }
}
