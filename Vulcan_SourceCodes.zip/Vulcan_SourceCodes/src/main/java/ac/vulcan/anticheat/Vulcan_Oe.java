package ac.vulcan.anticheat;

import java.util.Calendar;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Oe.class */
class Vulcan_Oe implements Iterator {
    private final Calendar Vulcan_S;
    private final Calendar Vulcan_W;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(4899155867237607333L, 6443448268131524229L, null).a(103251174893021L);

    private static NoSuchElementException a(NoSuchElementException noSuchElementException) {
        return noSuchElementException;
    }

    Vulcan_Oe(Calendar calendar, Calendar calendar2) {
        this.Vulcan_S = calendar2;
        this.Vulcan_W = calendar;
        this.Vulcan_W.add(5, -1);
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.Vulcan_W.before(this.Vulcan_S);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.NoSuchElementException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    @Override // java.util.Iterator
    public Object next() {
        long j = a ^ 52929801910149L;
        ?? Vulcan_Y = Vulcan_G.Vulcan_Y();
        try {
            try {
                Calendar calendar = this.Vulcan_W;
                if (Vulcan_Y != 0) {
                    return calendar;
                }
                Vulcan_Y = calendar.equals(this.Vulcan_S);
                if (Vulcan_Y != 0) {
                    throw new NoSuchElementException();
                }
                this.Vulcan_W.add(5, 1);
                return this.Vulcan_W.clone();
            } catch (NoSuchElementException unused) {
                throw a(Vulcan_Y);
            }
        } catch (NoSuchElementException unused2) {
            throw a(Vulcan_Y);
        }
    }

    @Override // java.util.Iterator
    public void remove() {
        throw new UnsupportedOperationException();
    }
}
