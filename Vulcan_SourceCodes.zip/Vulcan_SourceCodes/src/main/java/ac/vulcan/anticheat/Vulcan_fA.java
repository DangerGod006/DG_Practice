package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fA.class */
public class Vulcan_fA {
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(3826711420340489150L, 3014175811901933046L, null).a(8947277384839L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0038: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_D(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 38640030692778(0x2324954db5aa, double:1.9090711719553E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r12
            r1 = r9
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fA.b
            r3 = 1
            r2 = r2[r3]
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_m(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_D(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_M(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 138135774168916(0x7da23dc00754, double:6.8248140478546E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r14
            r1 = r9
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_D(r0)
            r0 = r14
            r1 = r12
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_D(r0)
            r0 = r9
            java.util.Iterator r0 = r0.iterator()
            r16 = r0
        L77:
            r0 = r16
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto L9a
            r0 = r12
            r1 = r16
            java.lang.Object r1 = r1.next()
            boolean r0 = r0.isInstance(r1)
            if (r0 != 0) goto L77
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = r0
            r2 = r13
            r1.<init>(r2)
            throw r0
        L9a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_M(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0037: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_o(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 216
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_o(java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0086, code lost:
    
        if (r4 >= r2) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0089, code lost:
    
        r11 = "D0#ECDBy<'\u0011PA\u000eq*4\u0004L\u0005M\u007f62\u0004\\K]063\tY\u0005K|=+\u0000[Q\u000eq,f\f[AKhbf!D0#ECDBy<'\u0011PA\u000eu 6\u0017PV]y7(E\\V\u000ev9*\u0016P".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0092, code lost:
    
        ac.vulcan.anticheat.Vulcan_fA.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00aa, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00b9, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00e0, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00e5, code lost:
    
        r7 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00ea, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00ef, code lost:
    
        r7 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00f4, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00f9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00fe, code lost:
    
        r7 = 2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0107, code lost:
    
        if (r2 != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0127, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x009a, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00aa, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ad, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b1, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00b9, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e0, code lost:
    
        r7 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00ff, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0107, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x010a, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00e5, code lost:
    
        r7 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ea, code lost:
    
        r7 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ef, code lost:
    
        r7 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00f4, code lost:
    
        r7 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f9, code lost:
    
        r7 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00fe, code lost:
    
        r7 = 2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x010f, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0114, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0118, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "D0#ECDBy<'\u0011PA\u000eq*4\u0004L\u0005M\u007f62\u0004\\K]063\tY\u0005K|=+\u0000[Q\u000eq,f\f[AKhbf!D0#ECDBy<'\u0011PA\u000eu 6\u0017PV]y7(E\\V\u000ev9*\u0016P".length();
        r11 = '4';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0066, code lost:
    
        r10 = r10 + 1;
        "D0#ECDBy<'\u0011PA\u000eq*4\u0004L\u0005M\u007f62\u0004\\K]063\tY\u0005K|=+\u0000[Q\u000eq,f\f[AKhbf!D0#ECDBy<'\u0011PA\u000eu 6\u0017PV]y7(E\\V\u000ev9*\u0016P".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0076, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00ad, B:28:0x010f], limit reached: 54 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v17 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0114 -> B:15:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x0114 -> B:34:0x00ad). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.m186clinit():void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_L(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        String str = (String) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        Object obj = objArr[3];
        long j = a ^ jLongValue;
        IllegalArgumentException illegalArgumentException = zBooleanValue;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(new StringBuffer().append(str).append(obj).toString());
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_O(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        long jLongValue = ((Long) objArr[1]).longValue();
        String str = (String) objArr[2];
        long jLongValue2 = ((Long) objArr[3]).longValue();
        long j = a ^ jLongValue;
        IllegalArgumentException illegalArgumentException = zBooleanValue;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(new StringBuffer().append(str).append(jLongValue2).toString());
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_q(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        long jLongValue = ((Long) objArr[1]).longValue();
        String str = (String) objArr[2];
        double dDoubleValue = ((Double) objArr[3]).doubleValue();
        long j = a ^ jLongValue;
        IllegalArgumentException illegalArgumentException = zBooleanValue;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(new StringBuffer().append(str).append(dDoubleValue).toString());
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_Z(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        String str = (String) objArr[2];
        long jLongValue = ((((long) iIntValue) << 32) | ((((Long) objArr[3]).longValue() << 32) >>> 32)) ^ a;
        IllegalArgumentException illegalArgumentException = zBooleanValue;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(str);
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_A(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        long j = a ^ jLongValue;
        IllegalArgumentException illegalArgumentException = zBooleanValue;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(b[9]);
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Vulcan_m(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object obj = objArr[1];
        String str = (String) objArr[2];
        long j = a ^ jLongValue;
        IllegalArgumentException illegalArgumentException = obj;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException(str);
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004a A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_p(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r9
            r1 = r10
            if (r1 != 0) goto L39
            if (r0 == 0) goto L3d
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L37:
            r0 = r9
        L39:
            int r0 = r0.length     // Catch: java.lang.IllegalArgumentException -> L46
            if (r0 != 0) goto L4a
        L3d:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L46
            r1 = r0
            r2 = r8
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L46
            throw r0     // Catch: java.lang.IllegalArgumentException -> L46
        L46:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L46
            throw r0
        L4a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_p(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0041: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0041: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_F(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 68704400018115(0x3e7c7d5b8ac3, double:3.39444837670853E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fA.b
            r3 = 2
            r2 = r2[r3]
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_p(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_F(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004d A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan__(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L37
            if (r0 == 0) goto L3f
            goto L36
        L32:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L36:
            r0 = r6
        L37:
            int r0 = r0.size()     // Catch: java.lang.IllegalArgumentException -> L49
            if (r0 != 0) goto L4d
        L3f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L49
            r1 = r0
            r2 = r9
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0     // Catch: java.lang.IllegalArgumentException -> L49
        L49:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L49
            throw r0
        L4d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan__(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003c: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003c: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_h(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 53597567358459(0x30bf27f695fb, double:2.6480716732477E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_fA.b
            r2 = 5
            r1 = r1[r2]
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan__(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_h(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004b A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_B(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Map r1 = (java.util.Map) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r7 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r6
            r1 = r10
            if (r1 != 0) goto L36
            if (r0 == 0) goto L3e
            goto L35
        L31:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L35:
            r0 = r6
        L36:
            int r0 = r0.size()     // Catch: java.lang.IllegalArgumentException -> L47
            if (r0 != 0) goto L4b
        L3e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L47
            r1 = r0
            r2 = r7
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L47
            throw r0     // Catch: java.lang.IllegalArgumentException -> L47
        L47:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L47
            throw r0
        L4b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_B(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0042: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0042: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_U(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Map r1 = (java.util.Map) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 125181303953330(0x71da0b2797b2, double:6.18477817849514E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r10
            r1 = r13
            java.lang.String[] r2 = ac.vulcan.anticheat.Vulcan_fA.b
            r3 = 7
            r2 = r2[r3]
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_B(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_U(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x004c A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_R(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r10 = r0
            r0 = r9
            r1 = r10
            if (r1 != 0) goto L39
            if (r0 == 0) goto L3f
            goto L37
        L33:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L37:
            r0 = r9
        L39:
            int r0 = r0.length()     // Catch: java.lang.IllegalArgumentException -> L48
            if (r0 != 0) goto L4c
        L3f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L48
            r1 = r0
            r2 = r8
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L48
            throw r0     // Catch: java.lang.IllegalArgumentException -> L48
        L48:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L48
            throw r0
        L4c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_R(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v1 ??, still in use, count: 2, list:
          (r5v1 ?? I:??[OBJECT, ARRAY][]) from 0x003c: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
          (r5v1 ?? I:??[OBJECT, ARRAY]) from 0x003c: APUT (r5v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r5v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_l(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 3329954128384(0x30750bba200, double:1.645215937062E-311)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r11
            java.lang.String[] r1 = ac.vulcan.anticheat.Vulcan_fA.b
            r2 = 4
            r1 = r1[r2]
            r2 = r14
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_R(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_l(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x007b -> B:5:0x0056). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_N(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 96251248869018(0x578a3d7f7e9a, double:4.7554435435498E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r14
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            Vulcan_D(r1)
            r1 = 0
            r17 = r1
            r16 = r0
        L4f:
            r0 = r17
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L78
        L56:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L73
            r0 = r10
            r1 = r17
            r0 = r0[r1]     // Catch: java.lang.IllegalArgumentException -> L6c
            if (r0 != 0) goto L70
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L6c
            r1 = r0
            r2 = r11
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L6c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L6c
        L6c:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L6c
            throw r0
        L70:
            int r17 = r17 + 1
        L73:
            r0 = r16
            if (r0 == 0) goto L4f
        L78:
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L56
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_N(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x008b -> B:5:0x004f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_J(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 88333376185002(0x5056b78262aa, double:4.3642486554181E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            Vulcan_D(r1)
            r1 = 0
            r16 = r1
            r15 = r0
        L48:
            r0 = r16
            r1 = r10
            int r1 = r1.length
            if (r0 >= r1) goto L88
        L4f:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L83
            r0 = r10
            r1 = r16
            r0 = r0[r1]     // Catch: java.lang.IllegalArgumentException -> L7c
            if (r0 != 0) goto L80
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L7c
            r1 = r0
            java.lang.StringBuffer r2 = new java.lang.StringBuffer     // Catch: java.lang.IllegalArgumentException -> L7c
            r3 = r2
            r3.<init>()     // Catch: java.lang.IllegalArgumentException -> L7c
            java.lang.String[] r3 = ac.vulcan.anticheat.Vulcan_fA.b     // Catch: java.lang.IllegalArgumentException -> L7c
            r4 = 8
            r3 = r3[r4]     // Catch: java.lang.IllegalArgumentException -> L7c
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IllegalArgumentException -> L7c
            r3 = r16
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IllegalArgumentException -> L7c
            java.lang.String r2 = r2.toString()     // Catch: java.lang.IllegalArgumentException -> L7c
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L7c
            throw r0     // Catch: java.lang.IllegalArgumentException -> L7c
        L7c:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L7c
            throw r0
        L80:
            int r16 = r16 + 1
        L83:
            r0 = r15
            if (r0 == 0) goto L48
        L88:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L4f
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_J(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_H(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 35130867915208(0x1ff38ae719c8, double:1.7356954945491E-310)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r14
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            Vulcan_D(r1)
            r1 = r10
            java.util.Iterator r1 = r1.iterator()
            r17 = r1
            r16 = r0
        L55:
            r0 = r17
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto L7e
            r0 = r17
            java.lang.Object r0 = r0.next()
        L66:
            if (r0 != 0) goto L55
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r1 = r0
            r2 = r13
            r1.<init>(r2)
            r1 = r11
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L66
            r1 = r16
            if (r1 != 0) goto L66
            throw r0
        L7e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_H(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0098 -> B:5:0x005a). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x003f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static void Vulcan_j(java.lang.Object[] r9) {
        /*
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fA.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 100876221909280(0x5bbf135f8920, double:4.98394757276333E-310)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_fX.Vulcan_k()
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            Vulcan_D(r1)
            r1 = 0
            r16 = r1
            r15 = r0
            r0 = r10
            java.util.Iterator r0 = r0.iterator()
            r17 = r0
        L50:
            r0 = r17
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto L95
        L5a:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L90
            r0 = r17
            java.lang.Object r0 = r0.next()     // Catch: java.lang.IllegalArgumentException -> L89
            if (r0 != 0) goto L8d
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L89
            r1 = r0
            java.lang.StringBuffer r2 = new java.lang.StringBuffer     // Catch: java.lang.IllegalArgumentException -> L89
            r3 = r2
            r3.<init>()     // Catch: java.lang.IllegalArgumentException -> L89
            java.lang.String[] r3 = ac.vulcan.anticheat.Vulcan_fA.b     // Catch: java.lang.IllegalArgumentException -> L89
            r4 = 3
            r3 = r3[r4]     // Catch: java.lang.IllegalArgumentException -> L89
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IllegalArgumentException -> L89
            r3 = r16
            java.lang.StringBuffer r2 = r2.append(r3)     // Catch: java.lang.IllegalArgumentException -> L89
            java.lang.String r2 = r2.toString()     // Catch: java.lang.IllegalArgumentException -> L89
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L89
            throw r0     // Catch: java.lang.IllegalArgumentException -> L89
        L89:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L89
            throw r0
        L8d:
            int r16 = r16 + 1
        L90:
            r0 = r15
            if (r0 == 0) goto L50
        L95:
            r0 = r11
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5a
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fA.Vulcan_j(java.lang.Object[]):void");
    }
}
