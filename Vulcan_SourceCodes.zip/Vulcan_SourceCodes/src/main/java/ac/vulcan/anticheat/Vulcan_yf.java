package ac.vulcan.anticheat;

import java.io.Writer;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_yf.class */
class Vulcan_yf extends Writer {
    private final Vulcan_P Vulcan_C;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6901211946058802640L, 6500773859694757042L, null).a(148867963413364L);

    Vulcan_yf(Vulcan_P vulcan_P) {
        this.Vulcan_C = vulcan_P;
    }

    @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    @Override // java.io.Writer, java.io.Flushable
    public void flush() {
    }

    /* JADX WARN: Type inference failed for: r3v2, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x003a: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x003a: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.io.Writer
    public void write(int r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yf.a
            r1 = 21766592302846(0x13cbee008efe, double:1.07541254838687E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 56520613724598(0x3367bb1a81b6, double:2.7924893523187E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_C
            r1 = r10
            char r1 = (char) r1
            r2 = r13
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_JA(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yf.write(int):void");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.io.Writer
    public void write(char[] r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yf.a
            r1 = 38756986065771(0x233fd063136b, double:1.91484953514453E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 47221357662582(0x2af2943fd176, double:2.3330450571064E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_C
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_b6(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yf.write(char[]):void");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x004d: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.io.Writer
    public void write(char[] r12, int r13, int r14) {
        /*
            r11 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yf.a
            r1 = 102537929125113(0x5d41f8d76cf9, double:5.0660468176423E-310)
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 136470717169657(0x7c1e909e7ff9, double:6.74254930168447E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_C
            r1 = r17
            r2 = r12
            r3 = r13
            r4 = r14
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_K(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yf.write(char[], int, int):void");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_P, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x002f: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.io.Writer
    public void write(java.lang.String r10) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yf.a
            r1 = 22030565211664(0x140964037e10, double:1.08845454295485E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 48763147644797(0x2c598e17ef7d, double:2.40921960343787E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_C
            r1 = r13
            r2 = r10
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_i(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yf.write(java.lang.String):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x002e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x002e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // java.io.Writer
    public void write(java.lang.String r13, int r14, int r15) {
        /*
            r12 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_yf.a
            r1 = 66949224849656(0x3ce3d4c3e0f8, double:3.3077312013916E-310)
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 58879031284666(0x358cd7be93ba, double:2.90901066181655E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_C
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r18
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            ac.vulcan.anticheat.Vulcan_P r0 = r0.Vulcan_O9(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_yf.write(java.lang.String, int, int):void");
    }
}
