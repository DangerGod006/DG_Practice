package ac.vulcan.anticheat;

import java.util.Random;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fH.class */
public final class Vulcan_fH extends Random {
    private static final long serialVersionUID = 1;
    private static final Random Vulcan_O;
    private boolean Vulcan_V;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-6407255837230314490L, 7168038889207948096L, null).a(97719842818212L);
    private static final String b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0027: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // java.util.Random
    public long nextLong() {
        /*
            r10 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_fH.a
            r1 = 136155035068852(0x7bd5107fe9b4, double:6.726952533583E-310)
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 120951171951551(0x6e0123a3abbf, double:5.97578188854987E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            long r0 = Vulcan_S(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fH.nextLong():long");
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0072, code lost:
    
        r8 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0077, code lost:
    
        r8 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007c, code lost:
    
        r8 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0081, code lost:
    
        r8 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0083, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008b, code lost:
    
        if (r3 != 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008e, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0093, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0097, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009b, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = "&c\u000f;@\u0007>\u001cf\u0011:\u0012A3\u00013\u0011;JS\u0015\u001dg_3GT(Sq\u001a~BH/\u001ag\u0016(W".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 125;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 14;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0097 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -6407255837230314490(0xa714dac35cd6cc06, double:-2.019028413407862E-120)
            r1 = 7168038889207948096(0x6379fd644f6ce340, double:1.5693531743878348E171)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 97719842818212(0x58e02c84c8a4, double:4.8280017253485E-310)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_fH.a = r0
            r0 = 125(0x7d, float:1.75E-43)
            java.lang.String r1 = "&c\u000f;@\u0007>\u001cf\u0011:\u0012A3\u00013\u0011;JS\u0015\u001dg_3GT(Sq\u001a~BH/\u001ag\u0016(W"
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.Vulcan_fH.b = r2
            goto Laa
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L93
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L72;
                case 4: goto L77;
                case 5: goto L7c;
                default: goto L81;
            }
        L64:
            r8 = 14
            goto L83
        L69:
            r8 = 110(0x6e, float:1.54E-43)
            goto L83
        L6e:
            r8 = 2
            goto L83
        L72:
            r8 = 35
            goto L83
        L77:
            r8 = 79
            goto L83
        L7c:
            r8 = 90
            goto L83
        L81:
            r8 = 33
        L83:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L93
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L93:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9b:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Laa:
            java.util.Random r2 = new java.util.Random
            r3 = r2
            r3.<init>()
            ac.vulcan.anticheat.Vulcan_fH.Vulcan_O = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fH.m189clinit():void");
    }

    public Vulcan_fH() {
        this.Vulcan_V = false;
        this.Vulcan_V = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    @Override // java.util.Random
    public synchronized void setSeed(long j) {
        ?? unsupportedOperationException = a ^ 4659556047593L;
        try {
            if (this.Vulcan_V) {
                unsupportedOperationException = new UnsupportedOperationException();
                throw unsupportedOperationException;
            }
        } catch (UnsupportedOperationException unused) {
            throw a(unsupportedOperationException);
        }
    }

    @Override // java.util.Random
    public synchronized double nextGaussian() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Random
    public void nextBytes(byte[] bArr) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Random
    public int nextInt() {
        return nextInt(Integer.MAX_VALUE);
    }

    @Override // java.util.Random
    public int nextInt(int i) {
        return Vulcan_O.nextInt(i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [long] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v29, types: [long] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [long] */
    /* JADX WARN: Type inference failed for: r0v33, types: [long] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [int, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r23v0, types: [long] */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r5v6, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x00c0 -> B:28:0x00a6). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x008c: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: UnsupportedOperationException -> 0x00a2]
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x008c: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY]) A[Catch: UnsupportedOperationException -> 0x00a2]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public static long Vulcan_S(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 209
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fH.Vulcan_S(java.lang.Object[]):long");
    }

    @Override // java.util.Random
    public boolean nextBoolean() {
        return Vulcan_O.nextBoolean();
    }

    @Override // java.util.Random
    public float nextFloat() {
        return Vulcan_O.nextFloat();
    }

    @Override // java.util.Random
    public double nextDouble() {
        return Vulcan_O.nextDouble();
    }

    private static long Vulcan_Y(Object[] objArr) {
        return Vulcan_O.nextLong() & Long.MAX_VALUE;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:23:0x0061
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static int Vulcan_a(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_fH.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            int r0 = ac.vulcan.anticheat.Vulcan_OA.Vulcan_Q()
            r1 = r7
            r12 = r1
            r11 = r0
            r0 = 0
            r14 = r0
        L27:
            r0 = r7
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L4f
            r0 = 64
            r1 = r14
            int r0 = r0 - r1
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L5e
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L65
            r1 = r11
            if (r1 != 0) goto L65
            goto L4a
        L46:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4b
        L4a:
            return r0
        L4b:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4b
            throw r0
        L4f:
            r0 = r9
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L82
            r0 = r12
            r1 = r11
            if (r1 != 0) goto L80
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L5e:
            goto L65
        L61:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L65:
            r1 = r9
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L70
            if (r0 != 0) goto L75
            r0 = r14
        L70:
            return r0
        L71:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L71
            throw r0
        L75:
            int r14 = r14 + 1
            r0 = r7
            r1 = 1
            long r0 = r0 << r1
            r7 = r0
            r0 = r12
            r1 = 1
            long r0 = r0 >> r1
        L80:
            r12 = r0
        L82:
            goto L27
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_fH.Vulcan_a(java.lang.Object[]):int");
    }
}
