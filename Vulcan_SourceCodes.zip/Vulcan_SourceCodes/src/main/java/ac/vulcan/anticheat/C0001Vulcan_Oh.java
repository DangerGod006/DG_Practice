package ac.vulcan.anticheat;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_Oh, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_Oh.class */
class C0001Vulcan_Oh implements Vulcan_fu {
    static final C0001Vulcan_Oh Vulcan_f = new C0001Vulcan_Oh();

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    C0001Vulcan_Oh() {
    }

    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public int Vulcan_r(Object[] objArr) {
        ((Long) objArr[0]).longValue();
        return 2;
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0053: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0053: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // ac.vulcan.anticheat.InterfaceC0031Vulcan_n
    public void Vulcan_g(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Calendar r1 = (java.util.Calendar) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r0 = r12
            r1 = r0; r2 = r0; 
            r2 = 110766544763656(0x64bdd88dbb08, double:5.4725944476259E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r10
            r1 = r14
            r2 = r15
            r3 = 2
            int r2 = r2.get(r3)
            r3 = 1
            int r2 = r2 + r3
            r3 = r16
            r4 = r3; r3 = r2; r2 = r4; 
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_j(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0001Vulcan_Oh.Vulcan_g(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.RuntimeException, java.lang.String[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // ac.vulcan.anticheat.Vulcan_fu
    public final void Vulcan_j(Object[] objArr) {
        StringBuffer stringBuffer = (StringBuffer) objArr[0];
        ((Long) objArr[1]).longValue();
        int iIntValue = ((Integer) objArr[2]).intValue();
        ?? Vulcan_Y = Vulcan_G.Vulcan_Y();
        try {
            try {
                if (Vulcan_Y == 0) {
                    if (iIntValue < 10) {
                        stringBuffer.append((char) (iIntValue + 48));
                        if (Vulcan_Y == 0) {
                            return;
                        }
                    }
                    stringBuffer.append((char) ((iIntValue / 10) + 48));
                }
                stringBuffer.append((char) ((iIntValue % 10) + 48));
            } catch (RuntimeException unused) {
                throw a(Vulcan_Y);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_Y);
        }
    }
}
