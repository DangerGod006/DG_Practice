package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: renamed from: ac.vulcan.anticheat.Vulcan_z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_z.class */
public class C0034Vulcan_z implements Serializable {
    private static final long serialVersionUID = 1;
    private static final transient String Vulcan_H;
    private Throwable Vulcan_E;
    public static boolean Vulcan_v;
    public static boolean Vulcan_g;
    public static boolean Vulcan_R;
    static Class Vulcan_N;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-7265161322260567524L, -5220113802295724330L, null).a(278219627471877L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.Throwable[] Vulcan__(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 18032598020535(0x10668a9971b7, double:8.909287187211E-311)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r8
            java.lang.Throwable r0 = r0.Vulcan_E
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Throwable[] r0 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_O(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan__(java.lang.Object[]):java.lang.Throwable[]");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0078: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int Vulcan_R(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 398
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_R(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0048: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_d(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 528
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_d(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0090: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    protected void Vulcan_C(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 280
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_C(java.lang.Object[]):void");
    }

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0087, code lost:
    
        if (r4 >= r2) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x008a, code lost:
    
        r11 = "\u0001SZ'\rnX'O\u001fn\u0010~\\-\u001bHf\r:V O\u001fh\u0018:[:NQc\r \u0019p\u0001SZ'0\u007fJ!Z]k\u001b:P8KSb\u0013\u007fW!ZKn\u0011t\u0019%ZLt\u001b~\u0019!T\u001fs\u0016\u007f\u0019\u001b^Ls\u001fxU0\u007fZk\u001b}X!^\u0017I\u001biM4YSbW:Z:ULs\foZ!TM'\u0013oJ!\u001bZ\u007f\n\u007fW1\u001bUf\b{\u00179ZQ`PNQ'THf\u001cv\\".charAt(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0093, code lost:
    
        ac.vulcan.anticheat.C0034Vulcan_z.b = r0;
        ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_H = ac.vulcan.anticheat.C0034Vulcan_z.b[4];
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00b5, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00b8, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00bc, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00c4, code lost:
    
        switch(r7) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00ec, code lost:
    
        r7 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00f1, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00f6, code lost:
    
        r7 = 27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00fb, code lost:
    
        r7 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0100, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0105, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x010a, code lost:
    
        r7 = 29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x010c, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0114, code lost:
    
        if (r2 != 0) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0117, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x011c, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0121, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0125, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0134, code lost:
    
        ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_v = true;
        ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_g = true;
        ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_R = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0140, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00a5, code lost:
    
        r1 = r1.toCharArray();
        r2 = r1.length;
        r17 = 0;
        r2 = r0;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b5, code lost:
    
        if (r2 > 1) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00b8, code lost:
    
        r3 = r2;
        r4 = r1;
        r5 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00bc, code lost:
    
        r7 = r5;
        r6 = r4;
        r5 = r3;
        r6 = r6[r7];
        r7 = r17 % 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00c4, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00ec, code lost:
    
        r7 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x010c, code lost:
    
        r6[r7] = (char) (r6 ^ (r5 ^ r7));
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0114, code lost:
    
        if (r2 != null) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0117, code lost:
    
        r5 = r2;
        r4 = r1;
        r3 = r5 == true ? 1 : 0;
        r5 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00f1, code lost:
    
        r7 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00f6, code lost:
    
        r7 = 27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00fb, code lost:
    
        r7 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x0100, code lost:
    
        r7 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0105, code lost:
    
        r7 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x010a, code lost:
    
        r7 = 29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x011c, code lost:
    
        r4 = r2;
        r2 = r0;
        r2 = r4;
        r1 = r1;
        r0 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0121, code lost:
    
        if (r2 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x003c, code lost:
    
        r4 = r13;
        r13 = r13 + 1;
        r0[r4] = r0;
        r2 = r10 + r11;
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0125, code lost:
    
        r0 = new java.lang.String(r1).intern();
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x004c, code lost:
    
        if (r2 >= r0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0058, code lost:
    
        r2 = "\u0001SZ'\rnX'O\u001fn\u0010~\\-\u001bHf\r:V O\u001fh\u0018:[:NQc\r \u0019p\u0001SZ'0\u007fJ!Z]k\u001b:P8KSb\u0013\u007fW!ZKn\u0011t\u0019%ZLt\u001b~\u0019!T\u001fs\u0016\u007f\u0019\u001b^Ls\u001fxU0\u007fZk\u001b}X!^\u0017I\u001biM4YSbW:Z:ULs\foZ!TM'\u0013oJ!\u001bZ\u007f\n\u007fW1\u001bUf\b{\u00179ZQ`PNQ'THf\u001cv\\".length();
        r11 = '#';
        r10 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0067, code lost:
    
        r10 = r10 + 1;
        "\u0001SZ'\rnX'O\u001fn\u0010~\\-\u001bHf\r:V O\u001fh\u0018:[:NQc\r \u0019p\u0001SZ'0\u007fJ!Z]k\u001b:P8KSb\u0013\u007fW!ZKn\u0011t\u0019%ZLt\u001b~\u0019!T\u001fs\u0016\u007f\u0019\u001b^Ls\u001fxU0\u007fZk\u001b}X!^\u0017I\u001biM4YSbW:Z:ULs\foZ!TM'\u0013oJ!\u001bZ\u007f\n\u007fW1\u001bUf\b{\u00179ZQ`PNQ'THf\u001cv\\".substring(r10, r10 + r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0077, code lost:
    
        r6 = r13;
        r13 = r13 + 1;
        r0[r6] = r1;
        r4 = r10 + r11;
        r10 = r4;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00b8, B:28:0x011c], limit reached: 55 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v19 */
    /* JADX WARN: Type inference failed for: r5v29 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0121 -> B:15:0x00b8). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:49:0x0121 -> B:35:0x00b8). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 321
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.m559clinit():void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:19:0x004f A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r6v0, types: [ac.vulcan.anticheat.Vulcan_OV] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public C0034Vulcan_z(ac.vulcan.anticheat.Vulcan_OV r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = 110679085319424(0x64a97b908500, double:5.46827337694596E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            r1 = r5
            r1.<init>()
            r9 = r0
            r0 = r5
            r1 = 0
            r0.Vulcan_E = r1     // Catch: java.lang.IllegalArgumentException -> L25
            r0 = r9
            if (r0 != 0) goto L38
            r0 = r6
            boolean r0 = r0 instanceof java.lang.Throwable     // Catch: java.lang.IllegalArgumentException -> L25 java.lang.IllegalArgumentException -> L34
            if (r0 == 0) goto L3d
            goto L29
        L25:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L34
            throw r0     // Catch: java.lang.IllegalArgumentException -> L34
        L29:
            r0 = r5
            r1 = r6
            java.lang.Throwable r1 = (java.lang.Throwable) r1     // Catch: java.lang.IllegalArgumentException -> L34
            r0.Vulcan_E = r1     // Catch: java.lang.IllegalArgumentException -> L34
            goto L38
        L34:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L38:
            r0 = r9
            if (r0 == 0) goto L4f
        L3d:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L4b
            r1 = r0
            java.lang.String[] r2 = ac.vulcan.anticheat.C0034Vulcan_z.b     // Catch: java.lang.IllegalArgumentException -> L4b
            r3 = 11
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L4b
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L4b
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4b
        L4b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4b
            throw r0
        L4f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.<init>(ac.vulcan.anticheat.Vulcan_OV):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [ac.vulcan.anticheat.Vulcan_OV] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.Object, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r3v6, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v5 ??, still in use, count: 2, list:
          (r5v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
          (r5v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r5v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r5v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String Vulcan_N(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_N(java.lang.Object[]):java.lang.String");
    }

    static Class Vulcan_y(Object[] objArr) {
        try {
            return Class.forName(me.frep.vulcan.spigot.Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public java.lang.String Vulcan_h(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_h(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.IllegalArgumentException, java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Throwable[]] */
    /* JADX WARN: Type inference failed for: r2v10, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18, types: [ac.vulcan.anticheat.Vulcan_OV] */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v26 */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r2v5, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v7, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v4, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x00f0 -> B:5:0x0055). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0037: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String[] Vulcan_J(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_J(java.lang.Object[]):java.lang.String[]");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v4, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.Throwable Vulcan_P(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 66077800868925(0x3c18efd92c3d, double:3.26467713620747E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            if (r0 != 0) goto L34
            r0 = r9
            java.lang.Throwable r0 = r0.Vulcan_E     // Catch: java.lang.IllegalArgumentException -> L30
            return r0
        L30:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L30
            throw r0
        L34:
            r0 = r9
            r1 = r14
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            java.lang.Throwable[] r0 = r0.Vulcan__(r1)
            r16 = r0
            r0 = r16
            r1 = r13
            r0 = r0[r1]
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_P(java.lang.Object[]):java.lang.Throwable");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v1 ??, still in use, count: 2, list:
          (r4v1 ?? I:??[OBJECT, ARRAY][]) from 0x0033: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
          (r4v1 ?? I:??[OBJECT, ARRAY]) from 0x0033: APUT (r4v1 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public int Vulcan_B(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 47339711079670(0x2b0e22a9a4f6, double:2.3388924928515E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            java.lang.Throwable r0 = r0.Vulcan_E
            r1 = r13
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            int r0 = ac.vulcan.anticheat.Vulcan_kB.m424Vulcan_w(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_B(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [ac.vulcan.anticheat.Vulcan_z, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0038: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0038: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public void Vulcan_c(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 21704458676190(0x13bd768ca7de, double:1.07234273934865E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r0 = r9
            r1 = r13
            java.io.PrintStream r2 = java.lang.System.err
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.Vulcan_c(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0029: PHI (r0v7 ?? I:java.io.PrintWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    public void Vulcan_K(
    /*  JADX ERROR: JadxRuntimeException in pass: ConstructorVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Null bind block in PHI insn: 0x0029: PHI (r0v7 ?? I:java.io.PrintWriter) =  binds: [] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.dex.instructions.PhiInsn.bindArg(PhiInsn.java:47)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:156)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r11v0 ??
        	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
        	at jadx.core.codegen.MethodGen.addMethodArguments(MethodGen.java:224)
        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:169)
        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:407)
        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:337)
        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:303)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
        	at java.base/java.util.ArrayList.forEach(ArrayList.java:1604)
        	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
        	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
        	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
        	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
        	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
        	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
        	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
        	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:299)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:288)
        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:272)
        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:159)
        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:103)
        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
        	at jadx.core.ProcessClass.process(ProcessClass.java:88)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v5 ??, still in use, count: 2, list:
          (r4v5 ?? I:??[OBJECT, ARRAY][]) from 0x009e: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
          (r4v5 ?? I:??[OBJECT, ARRAY]) from 0x009e: APUT (r4v5 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    protected java.lang.String[] m560Vulcan_R(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = ac.vulcan.anticheat.C0034Vulcan_z.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 11933330600623(0xada71ee72af, double:5.895848690234E-311)
            long r1 = r1 ^ r2
            r14 = r1
            java.lang.String r0 = ac.vulcan.anticheat.Vulcan_k5.Vulcan_J()
            java.io.StringWriter r1 = new java.io.StringWriter
            r2 = r1
            r2.<init>()
            r17 = r1
            java.io.PrintWriter r1 = new java.io.PrintWriter
            r2 = r1
            r3 = r17
            r4 = 1
            r2.<init>(r3, r4)
            r18 = r1
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 != 0) goto L7d
            boolean r0 = r0 instanceof ac.vulcan.anticheat.Vulcan_OV     // Catch: java.lang.IllegalArgumentException -> L4b java.lang.IllegalArgumentException -> L71
            if (r0 == 0) goto L75
            goto L4f
        L4b:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L71
            throw r0     // Catch: java.lang.IllegalArgumentException -> L71
        L4f:
            r0 = r11
            ac.vulcan.anticheat.Vulcan_OV r0 = (ac.vulcan.anticheat.Vulcan_OV) r0     // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r1 = r18
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r0.Vulcan_G(r1)     // Catch: java.lang.IllegalArgumentException -> L71 java.lang.IllegalArgumentException -> L79
            r0 = r16
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L8a
            if (r0 == 0) goto L82
            goto L75
        L71:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L79
            throw r0     // Catch: java.lang.IllegalArgumentException -> L79
        L75:
            r0 = r11
            goto L7d
        L79:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L7d:
            r1 = r18
            r0.printStackTrace(r1)
        L82:
            r0 = r17
            java.lang.StringBuffer r0 = r0.getBuffer()
            java.lang.String r0 = r0.toString()
        L8a:
            r1 = r14
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String[] r0 = ac.vulcan.anticheat.Vulcan_kB.Vulcan_C(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.C0034Vulcan_z.m560Vulcan_R(java.lang.Object[]):java.lang.String[]");
    }
}
