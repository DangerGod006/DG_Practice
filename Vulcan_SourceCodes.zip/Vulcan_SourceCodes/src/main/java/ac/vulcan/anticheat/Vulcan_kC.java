package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kC.class */
class Vulcan_kC {
    private Object Vulcan_L;
    private int Vulcan_z;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-1035978497409501321L, 8366168171205521379L, null).a(262251046334636L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0034: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String toString() {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_kC.a
            r1 = 62099270096717(0x387a9cef574d, double:3.06811159866045E-310)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 79457168017654(0x4844104648f6, double:3.92570570333587E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r9
            java.lang.Object r0 = r0.Vulcan_L
            java.lang.String r0 = r0.toString()
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = r9
            int r2 = r2.Vulcan_z
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            java.lang.Integer r5 = new java.lang.Integer
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r5.<init>(r6)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.String r0 = ac.vulcan.anticheat.C0027Vulcan_ku.Vulcan_jv(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kC.toString():java.lang.String");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    static boolean Vulcan_A(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Vulcan_kC[] vulcan_kCArr = (Vulcan_kC[]) objArr[1];
        Object obj = objArr[2];
        long j = a ^ jLongValue;
        String[] strArrVulcan_Y = Vulcan_G.Vulcan_Y();
        int length = vulcan_kCArr.length;
        int i = 0;
        while (i < length) {
            ?? Vulcan_U = (j > 0L ? 1 : (j == 0L ? 0 : -1));
            if (Vulcan_U > 0) {
                try {
                    Vulcan_U = vulcan_kCArr[i].Vulcan_U(new Object[0]);
                    if (Vulcan_U != obj) {
                        i++;
                    } else {
                        return true;
                    }
                } catch (RuntimeException unused) {
                    throw a(Vulcan_U);
                }
            }
            if (strArrVulcan_Y != null) {
                break;
            }
        }
        return j >= 0 ? false : false;
    }

    Vulcan_kC(Object obj) {
        this.Vulcan_L = obj;
        this.Vulcan_z = 1;
    }

    Vulcan_kC(Object obj, int i) {
        this.Vulcan_L = obj;
        this.Vulcan_z = i;
    }

    void Vulcan_D(Object[] objArr) {
        this.Vulcan_z++;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    int m435Vulcan_D(Object[] objArr) {
        return this.Vulcan_z;
    }

    Object Vulcan_U(Object[] objArr) {
        return this.Vulcan_L;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00ab A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [ac.vulcan.anticheat.Vulcan_kC] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Class] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v19, types: [ac.vulcan.anticheat.Vulcan_kC] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v43, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v6, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9, types: [ac.vulcan.anticheat.Vulcan_kC] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean equals(java.lang.Object r6) {
        /*
            Method dump skipped, instruction units count: 212
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_kC.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return this.Vulcan_L.hashCode();
    }
}
