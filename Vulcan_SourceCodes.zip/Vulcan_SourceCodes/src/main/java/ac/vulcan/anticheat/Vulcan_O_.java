package ac.vulcan.anticheat;

import java.lang.invoke.MethodHandles;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_O_.class */
public class Vulcan_O_ implements Vulcan_t {
    BukkitTask Vulcan_y;
    boolean Vulcan_v;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(8841132207589162339L, -3393408378235032249L, MethodHandles.lookup().lookupClass()).a(123353554648506L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.String[]] */
    public Vulcan_O_(BukkitTask bukkitTask) {
        long j = a ^ 13125490791570L;
        ?? Vulcan_b = Vulcan_OL.Vulcan_b();
        this.Vulcan_y = bukkitTask;
        try {
            this.Vulcan_v = false;
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_b = new String[3];
                Vulcan_OL.Vulcan_Q((String[]) Vulcan_b);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_b);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public Vulcan_O_(BukkitTask bukkitTask, boolean z) {
        long j = a ^ 65457465748130L;
        String[] strArrVulcan_b = Vulcan_OL.Vulcan_b();
        this.Vulcan_y = bukkitTask;
        this.Vulcan_v = z;
        ?? r0 = strArrVulcan_b;
        if (r0 == 0) {
            try {
                r0 = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
            } catch (RuntimeException unused) {
                throw a(r0);
            }
        }
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public void Vulcan_T(Object[] objArr) {
        this.Vulcan_y.cancel();
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_y.isCancelled();
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public Plugin Vulcan_k(Object[] objArr) {
        return this.Vulcan_y.getOwner();
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public boolean Vulcan_I(Object[] objArr) {
        ((Integer) objArr[0]).intValue();
        ((Integer) objArr[1]).intValue();
        ((Integer) objArr[2]).intValue();
        return Bukkit.getServer().getScheduler().isCurrentlyRunning(this.Vulcan_y.getTaskId());
    }

    @Override // ac.vulcan.anticheat.Vulcan_t
    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_v;
    }
}
