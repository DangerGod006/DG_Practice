package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_F.class */
public class Vulcan_F {
    private static volatile Vulcan_fV Vulcan_J;
    private final StringBuffer Vulcan_i;
    private final Object Vulcan_E;
    private final Vulcan_fV Vulcan_p;
    private static final long b = me.frep.vulcan.spigot.Vulcan_n.a(-1516890771317250146L, 7067413690870518620L, null).a(258267865038974L);
    private static final String c;

    private static IllegalArgumentException a(IllegalArgumentException illegalArgumentException) {
        return illegalArgumentException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0069, code lost:
    
        r8 = 86;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x006e, code lost:
    
        r8 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0073, code lost:
    
        r8 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0078, code lost:
    
        r8 = 98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x007d, code lost:
    
        r8 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0082, code lost:
    
        r8 = 76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0084, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x008c, code lost:
    
        if (r3 != 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008f, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0094, code lost:
    
        r5 = r3;
        r3 = r1;
        r3 = r5;
        r2 = r2;
        r1 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0098, code lost:
    
        if (r3 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x009c, code lost:
    
        r2 = new java.lang.String(r2).intern();
        ret r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0022, code lost:
    
        r1 = "$?9\u0016\u0010k4\u001c2|[\u0016l9P93BC}(P9)Z\u000f".toCharArray();
        r11 = 0;
        r3 = r1.length;
        r2 = 1;
        r1 = r1;
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0030, code lost:
    
        if (r1 > 1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0033, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0036, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x003d, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r8 = 113;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:6:0x0033). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = -1516890771317250146(0xeaf2ebe15c91279e, double:-1.5186946849377533E207)
            r1 = 7067413690870518620(0x62147f4e9d11d35c, double:2.950897778159663E164)
            r2 = 0
            me.frep.vulcan.spigot.Vulcan_i r0 = me.frep.vulcan.spigot.Vulcan_n.a(r0, r1, r2)
            r1 = 258267865038974(0xeae4ac5a407e, double:1.276012795405206E-309)
            long r0 = r0.a(r1)
            ac.vulcan.anticheat.Vulcan_F.b = r0
            r0 = 1
            java.lang.String r1 = "$?9\u0016\u0010k4\u001c2|[\u0016l9P93BC}(P9)Z\u000f"
            r2 = jsr -> L22
        L1c:
            ac.vulcan.anticheat.Vulcan_F.c = r2
            goto Lab
        L22:
            r10 = r2
            char[] r1 = r1.toCharArray()
            r2 = r1; r1 = r0; r0 = r2; 
            int r2 = r2.length
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r3 = 0
            r11 = r3
            r4 = r2; r3 = r1; r2 = r0; r1 = r4; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = 1
            if (r4 > r5) goto L94
        L33:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L36:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L64;
                case 1: goto L69;
                case 2: goto L6e;
                case 3: goto L73;
                case 4: goto L78;
                case 5: goto L7d;
                default: goto L82;
            }
        L64:
            r8 = 113(0x71, float:1.58E-43)
            goto L84
        L69:
            r8 = 86
            goto L84
        L6e:
            r8 = 93
            goto L84
        L73:
            r8 = 55
            goto L84
        L78:
            r8 = 98
            goto L84
        L7d:
            r8 = 30
            goto L84
        L82:
            r8 = 76
        L84:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L94
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L36
        L94:
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r11
            if (r4 > r5) goto L33
        L9c:
            java.lang.String r3 = new java.lang.String
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r3.<init>(r4)
            java.lang.String r2 = r2.intern()
            r3 = r1; r1 = r2; r2 = r3; 
            ret r10
        Lab:
            ac.vulcan.anticheat.Vulcan_fV r2 = ac.vulcan.anticheat.Vulcan_fV.Vulcan_w
            ac.vulcan.anticheat.Vulcan_F.Vulcan_J = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m9clinit():void");
    }

    public static Vulcan_fV Vulcan_K(Object[] objArr) {
        return Vulcan_J;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [int, java.lang.IllegalArgumentException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static void Vulcan_d(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Vulcan_fV vulcan_fV = (Vulcan_fV) objArr[1];
        long j = b ^ jLongValue;
        ?? Vulcan_F = Vulcan_fl.Vulcan_F();
        try {
            Vulcan_fV vulcan_fV2 = vulcan_fV;
            if (Vulcan_F != 0) {
                if (vulcan_fV2 == null) {
                    throw new IllegalArgumentException(c);
                }
                vulcan_fV2 = vulcan_fV;
            }
            Vulcan_J = vulcan_fV2;
        } catch (IllegalArgumentException unused) {
            throw a(Vulcan_F);
        }
    }

    public static String Vulcan_g(Object[] objArr) {
        return C0017Vulcan_g.Vulcan_F(new Object[]{objArr[0]});
    }

    public static String Vulcan_s(Object[] objArr) {
        return C0017Vulcan_g.Vulcan_v(new Object[]{objArr[0], (Vulcan_fV) objArr[1]});
    }

    public static String Vulcan_b(Object[] objArr) {
        return C0017Vulcan_g.Vulcan_R(new Object[]{objArr[0], (Vulcan_fV) objArr[1], new Boolean(((Boolean) objArr[2]).booleanValue()), new Boolean(false), null});
    }

    public static String Vulcan_f(Object[] objArr) {
        return C0017Vulcan_g.Vulcan_R(new Object[]{objArr[0], (Vulcan_fV) objArr[1], new Boolean(((Boolean) objArr[2]).booleanValue()), new Boolean(false), (Class) objArr[3]});
    }

    public Vulcan_F(Object obj) {
        this(obj, null, null);
    }

    public Vulcan_F(Object obj, Vulcan_fV vulcan_fV) {
        this(obj, vulcan_fV, null);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0028
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public Vulcan_F(java.lang.Object r10, ac.vulcan.anticheat.Vulcan_fV r11, java.lang.StringBuffer r12) {
        /*
            r9 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = 69090346636460(0x3ed6599194ac, double:3.4135166732338E-310)
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 116219305963494(0x69b36a72afe6, double:5.7419966460075E-310)
            long r1 = r1 ^ r2
            r15 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r1 = r9
            r1.<init>()
            r17 = r0
            r0 = r11
            r1 = r17
            if (r1 == 0) goto L3a
            if (r0 != 0) goto L3b
            goto L2c
        L28:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            throw r0     // Catch: java.lang.IllegalArgumentException -> L36
        L2c:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.IllegalArgumentException -> L36
            ac.vulcan.anticheat.Vulcan_fV r0 = Vulcan_K(r0)     // Catch: java.lang.IllegalArgumentException -> L36
            goto L3a
        L36:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L3a:
            r11 = r0
        L3b:
            r0 = r12
            r1 = r17
            if (r1 == 0) goto L5c
            if (r0 != 0) goto L5d
            goto L4b
        L47:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L58
            throw r0     // Catch: java.lang.IllegalArgumentException -> L58
        L4b:
            java.lang.StringBuffer r0 = new java.lang.StringBuffer     // Catch: java.lang.IllegalArgumentException -> L58
            r1 = r0
            r2 = 512(0x200, float:7.17E-43)
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L58
            goto L5c
        L58:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L5c:
            r12 = r0
        L5d:
            r0 = r9
            r1 = r12
            r0.Vulcan_i = r1
            r0 = r9
            r1 = r11
            r0.Vulcan_p = r1
            r0 = r9
            r1 = r10
            r0.Vulcan_E = r1
            r0 = r11
            r1 = r15
            r2 = r12
            r3 = r10
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_JB(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.<init>(java.lang.Object, ac.vulcan.anticheat.Vulcan_fV, java.lang.StringBuffer):void");
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_Y(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 128054555500314(0x7477064adf1a, double:6.32673566661764E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r16
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_e(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_Y(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_n(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 65248207060161(0x3b57c8343cc1, double:3.2236897561162E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = 0
            r4 = r13
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Vw(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_n(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_t(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 1794007231567(0x1a1b329ec4f, double:8.86357341508E-312)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r14
            r4 = r17
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.m209Vulcan_l(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_t(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_k(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 91307328112522(0x530b24db878a, double:4.5111814033952E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r17
            r4 = 0
            r5 = r18
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_x(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_k(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_e(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 47836427608644(0x2b81c9466244, double:2.36343355012027E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r14
            r4 = r17
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_bF(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_e(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_o(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 34286303227052(0x1f2ee6ecacac, double:1.69396845473823E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 0
            r4 = r15
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_d0(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_o(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Double] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0047: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0047: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m10Vulcan_b(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 42341012520248(0x26824902bd38, double:2.09192396963886E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r19
            r3 = 0
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Double r7 = new java.lang.Double
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_G(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m10Vulcan_b(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_S(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 64427138708713(0x3a989cb774e9, double:3.1831235895824E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = 0
            r4 = r13
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_S(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0045: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0045: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_p(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 23097077883436(0x1501b51f622c, double:1.14114727015254E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r16
            r4 = r17
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_JV(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_p(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_O(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 124012608516819(0x70c9ef7a72d3, double:6.127036951932E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r17
            r4 = 0
            r5 = r18
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Zh(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_O(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0057: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0057: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_B(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 125508364997489(0x722631831371, double:6.20093714109633E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = 0
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan__(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_B(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_H(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 59460302550219(0x36142e3634cb, double:2.937729278139E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = 0
            r4 = r13
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ld(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_H(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0049: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0049: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_I(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 120494290202069(0x6d96c35d6dd5, double:5.9532089308868E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r19
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 0
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_n(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_I(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_F(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 59055540406102(0x35b5f0820756, double:2.91773137112446E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r17
            r4 = 0
            r5 = r18
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ai(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_F(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m11Vulcan_K(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 78792594182965(0x47a954965335, double:3.8928713932514E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 0
            r4 = r15
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Kh(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m11Vulcan_K(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x0041: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x0041: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_x(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 134656777002251(0x7a78395c1d0b, double:6.6529287496518E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r15
            r4 = 0
            r5 = r18
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_a(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_x(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x005e: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x005e: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_J(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 12216827877342(0xb1c73af97de, double:6.0359149553503E-311)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = 0
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_VZ(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_J(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x0043: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_Q(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 68812296587216(0x3e959c7e87d0, double:3.39977917551823E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = 0
            r3 = r17
            r4 = 0
            r5 = r18
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Xl(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_Q(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v5 ??, still in use, count: 2, list:
          (r6v5 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
          (r6v5 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r6v5 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_Z(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 46138812952965(0x29f6878e7185, double:2.2795602419955E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r13
            r3 = r17
            r4 = r14
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Boolean r7 = new java.lang.Boolean
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_e(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_Z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_r(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 39195685408757(0x23a5f4e7cff5, double:1.9365241625668E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r13
            r4 = r16
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Vw(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_r(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v5 ??, still in use, count: 2, list:
          (r8v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
          (r8v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_w(java.lang.Object[] r15) {
        /*
            r14 = this;
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r19 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            boolean[] r1 = (boolean[]) r1
            r20 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 82625026318772(0x4b25a357e1b4, double:4.0822186990834E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r1 = r0; r2 = r0; 
            r2 = 137249187356231(0x7cd3d10ede47, double:6.78101083923425E-310)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r14
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r14
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r23
            r3 = r19
            r4 = r20
            r5 = r21
            r6 = r16
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Boolean r9 = new java.lang.Boolean
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 1
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 0
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            java.lang.Boolean r5 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r5)
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Vw(r1)
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_w(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_E(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 105656119702862(0x6017fb7bb54e, double:5.22010590180746E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r14
            r4 = r18
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.m209Vulcan_l(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_E(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_A(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 13043380976156(0xbdce616fa1c, double:6.444286445938E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r18
            r4 = 0
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_x(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_A(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v5 ??, still in use, count: 2, list:
          (r7v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
          (r7v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_V(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r15 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r18 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r18
            long r0 = r0 ^ r1
            r18 = r0
            r0 = r18
            r1 = r0; r1 = r0; 
            r2 = 65482534185338(0x3b8e5730697a, double:3.23526705436005E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r1 = r0; r2 = r0; 
            r2 = 15486864668420(0xe15d1113704, double:7.651527794459E-311)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r16
            r4 = r22
            r5 = r15
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Boolean r8 = new java.lang.Boolean
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 1
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 0
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            java.lang.Boolean r4 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r4)
            r5 = r20
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_x(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_V(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004e: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_G(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 32555929870036(0x1d9c04a29ed4, double:1.60847665172017E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r14
            r4 = r18
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Integer r6 = new java.lang.Integer
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_bF(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_G(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0060: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0060: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_D(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 14132002313563(0xcda5cfa555b, double:6.9821368500805E-311)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r13
            r4 = r16
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_d0(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_D(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v6, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v5 ??, still in use, count: 2, list:
          (r8v5 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
          (r8v5 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m12Vulcan_d(java.lang.Object[] r15) {
        /*
            r14 = this;
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r18 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            char[] r1 = (char[]) r1
            r20 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r18
            long r0 = r0 ^ r1
            r18 = r0
            r0 = r18
            r1 = r0; r1 = r0; 
            r2 = 72118805258599(0x419777c4e167, double:3.5631424097389E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r1 = r0; r2 = r0; 
            r2 = 85297949629501(0x4d93f9fcdc3d, double:4.21427865726335E-310)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r14
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r14
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r23
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r16
            r4 = r20
            r5 = r21
            r6 = r17
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Boolean r9 = new java.lang.Boolean
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 1
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 0
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            java.lang.Boolean r5 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r5)
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_d0(r1)
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m12Vulcan_d(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Double] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0050: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0050: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_i(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r19 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 14564914143544(0xd3f2888a138, double:7.1960237129524E-311)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r20
            r3 = r19
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Double r7 = new java.lang.Double
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_G(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_i(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x0059: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x0059: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m13Vulcan_f(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 20636587153307(0x12c4d472579b, double:1.0195828759858E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r13
            r4 = r16
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m13Vulcan_f(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v5 ??, still in use, count: 2, list:
          (r8v5 ?? I:??[OBJECT, ARRAY][]) from 0x006e: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
          (r8v5 ?? I:??[OBJECT, ARRAY]) from 0x006e: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_q(java.lang.Object[] r15) {
        /*
            r14 = this;
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            double[] r1 = (double[]) r1
            r20 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r19 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 95951425642165(0x57446ea41eb5, double:4.74063030792846E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r1 = r0; r2 = r0; 
            r2 = 79123368539915(0x47f65846770b, double:3.9092138178808E-310)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r14
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r14
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r21
            r3 = r18
            r4 = r20
            r5 = r23
            r6 = r19
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Boolean r9 = new java.lang.Boolean
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 1
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 0
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            java.lang.Boolean r5 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r5)
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_q(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_v(java.lang.Object[] r13) {
        /*
            r12 = this;
            r0 = r13
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 33353312551652(0x1e55ac58c2e4, double:1.6478725906777E-310)
            long r1 = r1 ^ r2
            r18 = r1
            r0 = r12
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r12
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r14
            r3 = r17
            r4 = r18
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            java.lang.Boolean r6 = new java.lang.Boolean
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_JV(r1)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_v(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_U(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 70582606128782(0x4031cb2a668e, double:3.4872440882175E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r16
            r4 = 0
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Zh(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_U(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v5 ??, still in use, count: 2, list:
          (r7v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
          (r7v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_u(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            float[] r1 = (float[]) r1
            r18 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 86502015249346(0x4eac51e42bc2, double:4.27376740307375E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r1 = r0; r2 = r0; 
            r2 = 73525444494903(0x42defa004637, double:3.6326396220139E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r19
            r3 = r18
            r4 = r22
            r5 = r17
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Boolean r8 = new java.lang.Boolean
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 1
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 0
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            java.lang.Boolean r4 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r4)
            r5 = r20
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Zh(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_u(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x008e: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x008e: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_a(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r15 = r1
            r0 = r13
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r16
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r15
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = ac.vulcan.anticheat.Vulcan_F.b
            long r0 = r0 ^ r1
            r18 = r0
            r0 = r18
            r1 = r0; r1 = r0; 
            r2 = 86577744217461(0x4ebdf3b08575, double:4.2775089112278E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r20
            r3 = r17
            r4 = r14
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan__(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_a(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v8 ??, still in use, count: 2, list:
          (r5v8 ?? I:??[OBJECT, ARRAY][]) from 0x005b: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
          (r5v8 ?? I:??[OBJECT, ARRAY]) from 0x005b: APUT (r5v8 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_W(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 55995235097543(0x32ed6818dbc7, double:2.76653219925E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r14
            r4 = r13
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ld(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_W(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v5 ??, still in use, count: 2, list:
          (r8v5 ?? I:??[OBJECT, ARRAY][]) from 0x006e: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
          (r8v5 ?? I:??[OBJECT, ARRAY]) from 0x006e: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_R(java.lang.Object[] r15) {
        /*
            r14 = this;
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r20 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            int[] r1 = (int[]) r1
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r18 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 119500821584182(0x6caf74055936, double:5.90412505945485E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r1 = r0; r2 = r0; 
            r2 = 2362389610443(0x2260964bfcb, double:1.167175548612E-311)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r14
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r14
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r21
            r3 = r20
            r4 = r19
            r5 = r23
            r6 = r18
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Boolean r9 = new java.lang.Boolean
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 1
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 0
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            java.lang.Boolean r5 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r5)
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r5 = new java.lang.Long
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r5.<init>(r6)
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ld(r1)
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_R(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 ??, still in use, count: 2, list:
          (r7v1 ?? I:??[OBJECT, ARRAY][]) from 0x0052: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
          (r7v1 ?? I:??[OBJECT, ARRAY]) from 0x0052: APUT (r7v1 ?? I:??[OBJECT, ARRAY][]), (3 ??[int, float, short, byte, char]), (r7v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_N(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 136731776301418(0x7c5b58f4b96a, double:6.7554473365381E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r20
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r19
            r4 = r15
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_n(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_N(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004a: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004a: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_M(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r18 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            r0 = r16
            r1 = r0; r1 = r0; 
            r2 = 16156266059406(0xeb1ac7fd68e, double:7.9822560250234E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r18
            r4 = 0
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ai(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_M(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v5 ??, still in use, count: 2, list:
          (r7v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
          (r7v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m14Vulcan_s(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            long[] r1 = (long[]) r1
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r16 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 115222149935386(0x68cb3f51311a, double:5.69273059230434E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r1 = r0; r2 = r0; 
            r2 = 116650145659926(0x6a17ba7ebc16, double:5.7632829552947E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r19
            r4 = r22
            r5 = r16
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Boolean r8 = new java.lang.Boolean
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 1
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 0
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            java.lang.Boolean r4 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r4)
            r5 = r20
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_ai(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m14Vulcan_s(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0062: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0062: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_X(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 136304275009018(0x7bf7cfe4adfa, double:6.73432596632534E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r14
            r4 = r13
            r5 = 0
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Kh(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_X(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r6v6, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v5, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v5 ??, still in use, count: 2, list:
          (r8v5 ?? I:??[OBJECT, ARRAY][]) from 0x0070: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
          (r8v5 ?? I:??[OBJECT, ARRAY]) from 0x0070: APUT (r8v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r8v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_m(java.lang.Object[] r15) {
        /*
            r14 = this;
            r0 = r15
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r17 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r20 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r18 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r16 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r18
            long r0 = r0 ^ r1
            r18 = r0
            r0 = r18
            r1 = r0; r1 = r0; 
            r2 = 93788563438539(0x554cda01fbcb, double:4.63377071677845E-310)
            long r1 = r1 ^ r2
            r21 = r1
            r1 = r0; r2 = r0; 
            r2 = 127609021993211(0x740f4a6d10fb, double:6.30472338662456E-310)
            long r1 = r1 ^ r2
            r23 = r1
            r0 = r14
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r14
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r21
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r17
            r4 = r20
            r5 = r23
            r6 = r16
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            java.lang.Boolean r9 = new java.lang.Boolean
            r10 = r9; r9 = r8; r8 = r10; 
            r11 = r9; r9 = r10; r10 = r11; 
            r9.<init>(r10)
            r9 = 1
            r10 = r8; r8 = r9; r9 = r10; 
            r7[r8] = r9
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 0
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            java.lang.Boolean r5 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r5)
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Kh(r1)
            r0 = r14
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_m(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_z(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r16 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 18200633329694(0x108daa48c81e, double:8.992307660755E-311)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r15
            r3 = r16
            r4 = 0
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_a(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_z(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v5 ??, still in use, count: 2, list:
          (r7v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
          (r7v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_T(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r19 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object[] r1 = (java.lang.Object[]) r1
            r18 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 132388116588804(0x786802a96904, double:6.54084203241537E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r1 = r0; r2 = r0; 
            r2 = 139678075246842(0x7f09560ed8fa, double:6.9010138456693E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r19
            r3 = r18
            r4 = r22
            r5 = r17
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Boolean r8 = new java.lang.Boolean
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 1
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 0
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            java.lang.Boolean r4 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r4)
            r5 = r20
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_a(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_T(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r5v1, types: [ac.vulcan.anticheat.Vulcan_fV, java.lang.Object[]] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v8 ??, still in use, count: 2, list:
          (r4v8 ?? I:??[OBJECT, ARRAY][]) from 0x0065: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
          (r4v8 ?? I:??[OBJECT, ARRAY]) from 0x0065: APUT (r4v8 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r4v8 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public ac.vulcan.anticheat.Vulcan_F m15Vulcan_g(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r13 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            r0 = r14
            r1 = r0; r1 = r0; 
            r2 = 137130541756300(0x7cb8313aaf8c, double:6.77514896773864E-310)
            long r1 = r1 ^ r2
            r17 = r1
            r0 = r11
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r17
            r3 = r2; r2 = r1; r1 = r3; 
            r3 = r16
            r4 = r13
            r5 = 4
            java.lang.Object[] r5 = new java.lang.Object[r5]
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            java.lang.Integer r7 = new java.lang.Integer
            r8 = r7; r7 = r6; r6 = r8; 
            r9 = r7; r7 = r8; r8 = r9; 
            r7.<init>(r8)
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_VZ(r1)
            r0 = r11
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.m15Vulcan_g(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r8v1 ??, still in use, count: 2, list:
          (r8v1 ?? I:??[OBJECT, ARRAY][]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
          (r8v1 ?? I:??[OBJECT, ARRAY]) from 0x004c: APUT (r8v1 ?? I:??[OBJECT, ARRAY][]), (4 ??[int, float, short, byte, char]), (r8v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_j(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r15 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 63203314195933(0x397bab175ddd, double:3.1226586247521E-310)
            long r1 = r1 ^ r2
            r19 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = r15
            r4 = 0
            r5 = r19
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Xl(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_j(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v5 ??, still in use, count: 2, list:
          (r7v5 ?? I:??[OBJECT, ARRAY][]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
          (r7v5 ?? I:??[OBJECT, ARRAY]) from 0x006c: APUT (r7v5 ?? I:??[OBJECT, ARRAY][]), (0 ??[int, short, byte, char]), (r7v5 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_h(java.lang.Object[] r14) {
        /*
            r13 = this;
            r0 = r14
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r16 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            short[] r1 = (short[]) r1
            r15 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r19 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r17 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r17
            long r0 = r0 ^ r1
            r17 = r0
            r0 = r17
            r1 = r0; r1 = r0; 
            r2 = 125943718153204(0x728b8e950bf4, double:6.22244644490107E-310)
            long r1 = r1 ^ r2
            r20 = r1
            r1 = r0; r2 = r0; 
            r2 = 67161068164647(0x3d15279c5627, double:3.31819765181543E-310)
            long r1 = r1 ^ r2
            r22 = r1
            r0 = r13
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r13
            java.lang.StringBuffer r1 = r1.Vulcan_i
            r2 = r16
            r3 = r15
            r4 = r20
            r5 = r19
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r7; 
            r8 = r6; r6 = r7; r7 = r8; 
            java.lang.Boolean r8 = new java.lang.Boolean
            r9 = r8; r8 = r7; r7 = r9; 
            r10 = r8; r8 = r9; r9 = r10; 
            r8.<init>(r9)
            r8 = 1
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            java.lang.Long r7 = new java.lang.Long
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r7.<init>(r8)
            r7 = 0
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            java.lang.Boolean r4 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r4)
            r5 = r22
            r6 = 5
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            java.lang.Long r8 = new java.lang.Long
            r9 = r8; r8 = r7; r7 = r6; r6 = r9; 
            r10 = r9; r9 = r8; r8 = r7; r7 = r10; 
            r8.<init>(r9)
            r8 = 4
            r9 = r7; r7 = r8; r8 = r9; 
            r6[r7] = r8
            r6 = r5; r5 = r4; r4 = r6; 
            r7 = r5; r5 = r6; r6 = r7; 
            r7 = 3
            r8 = r6; r6 = r7; r7 = r8; 
            r5[r6] = r7
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_Xl(r1)
            r0 = r13
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_h(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Long] */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r4v4 ??, still in use, count: 2, list:
          (r4v4 ?? I:??[OBJECT, ARRAY][]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
          (r4v4 ?? I:??[OBJECT, ARRAY]) from 0x0046: APUT (r4v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r4v4 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_P(java.lang.Object[] r10) {
        /*
            r9 = this;
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 30199584076797(0x1b77637b33fd, double:1.49205770110397E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r9
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.StringBuffer r0 = r0.Vulcan__(r1)
            r1 = r14
            r2 = r13
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r4 = new java.lang.Long
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            ac.vulcan.anticheat.C0016Vulcan_fy.Vulcan_D(r0)
            r0 = r9
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_P(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x004b: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0057]
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x004b: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0057]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_L(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r14 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 27149392074775(0x18b135ded817, double:1.3413581929621E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r14
            if (r0 == 0) goto L5b
            r0 = r10
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p     // Catch: java.lang.IllegalArgumentException -> L57
            r1 = r10
            java.lang.StringBuffer r1 = r1.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L57
            r2 = r15
            r3 = r14
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.IllegalArgumentException -> L57
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L57
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L57
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L57
            r4[r5] = r6     // Catch: java.lang.IllegalArgumentException -> L57
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L57
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L57
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L57
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L57
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L57
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L57
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L57
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L57
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L57
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L57
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L57
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L57
            r0.Vulcan_wC(r1)     // Catch: java.lang.IllegalArgumentException -> L57
            goto L5b
        L57:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L5b:
            r0 = r10
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_L(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r5v4 ??, still in use, count: 2, list:
          (r5v4 ?? I:??[OBJECT, ARRAY][]) from 0x0048: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0054]
          (r5v4 ?? I:??[OBJECT, ARRAY]) from 0x0048: APUT (r5v4 ?? I:??[OBJECT, ARRAY][]), (1 ??[boolean, int, float, short, byte, char]), (r5v4 ?? I:??[OBJECT, ARRAY]) A[Catch: IllegalArgumentException -> 0x0054]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public ac.vulcan.anticheat.Vulcan_F Vulcan_l(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r12 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 40741308973435(0x250dd33fc17b, double:2.0128881130378E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r12
            if (r0 == 0) goto L58
            r0 = r10
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p     // Catch: java.lang.IllegalArgumentException -> L54
            r1 = r10
            java.lang.StringBuffer r1 = r1.Vulcan_i     // Catch: java.lang.IllegalArgumentException -> L54
            r2 = r15
            r3 = r12
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.IllegalArgumentException -> L54
            r5 = r4; r4 = r3; r3 = r5;      // Catch: java.lang.IllegalArgumentException -> L54
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L54
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7;      // Catch: java.lang.IllegalArgumentException -> L54
            r4[r5] = r6     // Catch: java.lang.IllegalArgumentException -> L54
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.IllegalArgumentException -> L54
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.IllegalArgumentException -> L54
            java.lang.Long r5 = new java.lang.Long     // Catch: java.lang.IllegalArgumentException -> L54
            r6 = r5; r5 = r4; r4 = r3; r3 = r6;      // Catch: java.lang.IllegalArgumentException -> L54
            r7 = r6; r6 = r5; r5 = r4; r4 = r7;      // Catch: java.lang.IllegalArgumentException -> L54
            r5.<init>(r6)     // Catch: java.lang.IllegalArgumentException -> L54
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.IllegalArgumentException -> L54
            r3[r4] = r5     // Catch: java.lang.IllegalArgumentException -> L54
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.IllegalArgumentException -> L54
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.IllegalArgumentException -> L54
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.IllegalArgumentException -> L54
            r2[r3] = r4     // Catch: java.lang.IllegalArgumentException -> L54
            r0.Vulcan_h(r1)     // Catch: java.lang.IllegalArgumentException -> L54
            goto L58
        L54:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L58:
            r0 = r10
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.Vulcan_l(java.lang.Object[]):ac.vulcan.anticheat.Vulcan_F");
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public Object m16Vulcan_T(Object[] objArr) {
        return this.Vulcan_E;
    }

    public StringBuffer Vulcan__(Object[] objArr) {
        return this.Vulcan_i;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public Vulcan_fV m17Vulcan_n(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v20, types: [ac.vulcan.anticheat.Vulcan_F] */
    /* JADX WARN: Type inference failed for: r0v21, types: [ac.vulcan.anticheat.Vulcan_fV] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [ac.vulcan.anticheat.Vulcan_F] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Long] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r6v1 ??, still in use, count: 2, list:
          (r6v1 ?? I:??[OBJECT, ARRAY][]) from 0x0081: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
          (r6v1 ?? I:??[OBJECT, ARRAY]) from 0x0081: APUT (r6v1 ?? I:??[OBJECT, ARRAY][]), (2 ??[int, float, short, byte, char]), (r6v1 ?? I:??[OBJECT, ARRAY])
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:162)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:127)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:91)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:57)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    public java.lang.String toString() {
        /*
            r11 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_F.b
            r1 = 57009811526835(0x33d9a19094b3, double:2.81665893512935E-310)
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 27821503521794(0x194db2d5a402, double:1.37456491057697E-310)
            long r1 = r1 ^ r2
            r14 = r1
            int r0 = ac.vulcan.anticheat.Vulcan_fl.Vulcan_F()
            r16 = r0
            r0 = r11
            r1 = r16
            if (r1 == 0) goto L5b
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> L28 java.lang.IllegalArgumentException -> L4f
            java.lang.Object r0 = r0.m16Vulcan_T(r1)     // Catch: java.lang.IllegalArgumentException -> L28 java.lang.IllegalArgumentException -> L4f
            if (r0 != 0) goto L53
            goto L2c
        L28:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L4f
            throw r0     // Catch: java.lang.IllegalArgumentException -> L4f
        L2c:
            r0 = r11
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            java.lang.StringBuffer r0 = r0.Vulcan__(r1)     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            r1 = r11
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            ac.vulcan.anticheat.Vulcan_fV r1 = r1.m17Vulcan_n(r2)     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            java.lang.String r1 = r1.mo221Vulcan_D(r2)     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            java.lang.StringBuffer r0 = r0.append(r1)     // Catch: java.lang.IllegalArgumentException -> L4f java.lang.IllegalArgumentException -> L57
            r0 = r16
            if (r0 != 0) goto L8f
            goto L53
        L4f:
            java.lang.IllegalArgumentException r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L57
            throw r0     // Catch: java.lang.IllegalArgumentException -> L57
        L53:
            r0 = r11
            goto L5b
        L57:
            java.lang.IllegalArgumentException r0 = a(r0)
            throw r0
        L5b:
            ac.vulcan.anticheat.Vulcan_fV r0 = r0.Vulcan_p
            r1 = r11
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.StringBuffer r1 = r1.Vulcan__(r2)
            r2 = r11
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r2 = r2.m16Vulcan_T(r3)
            r3 = r14
            r4 = 3
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r5; r5 = r4; r4 = r3; r3 = r6; 
            java.lang.Long r6 = new java.lang.Long
            r7 = r6; r6 = r5; r5 = r4; r4 = r7; 
            r8 = r7; r7 = r6; r6 = r5; r5 = r8; 
            r6.<init>(r7)
            r6 = 2
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_J9(r1)
        L8f:
            r0 = r11
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.StringBuffer r0 = r0.Vulcan__(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_F.toString():java.lang.String");
    }
}
