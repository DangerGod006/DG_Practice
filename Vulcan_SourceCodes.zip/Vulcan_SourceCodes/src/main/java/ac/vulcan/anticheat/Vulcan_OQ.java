package ac.vulcan.anticheat;

import java.io.Serializable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_OQ.class */
public class Vulcan_OQ implements Vulcan_Oi, Serializable, Comparable {
    private static final long serialVersionUID = -4830728138360036487L;
    private boolean Vulcan_Y;
    private static final long a = me.frep.vulcan.spigot.Vulcan_n.a(-5855871101389965902L, -1211868086219647333L, null).a(159992862354554L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public java.lang.Object Vulcan_f(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r0 = r10
            r1 = r0; r2 = r0; 
            r2 = 100151344110063(0x5b164d4a19ef, double:4.9481338509607E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r8
            boolean r0 = r0.Vulcan_Y
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Boolean r0 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OQ.Vulcan_f(java.lang.Object[]):java.lang.Object");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0034: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.Boolean Vulcan_p(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = ac.vulcan.anticheat.Vulcan_OQ.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 91865972300953(0x538d36a55c99, double:4.53878209357044E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r8
            boolean r0 = r0.Vulcan_Y
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2; 
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Boolean r4 = new java.lang.Boolean
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r3 = new java.lang.Long
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r3.<init>(r4)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            java.lang.Boolean r0 = ac.vulcan.anticheat.Vulcan_kN.Vulcan_Z(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OQ.Vulcan_p(java.lang.Object[]):java.lang.Boolean");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_OQ() {
    }

    public Vulcan_OQ(boolean z) {
        this.Vulcan_Y = z;
    }

    public Vulcan_OQ(Boolean bool) {
        this.Vulcan_Y = bool.booleanValue();
    }

    public void Vulcan_Z(Object[] objArr) {
        this.Vulcan_Y = ((Boolean) objArr[0]).booleanValue();
    }

    @Override // ac.vulcan.anticheat.Vulcan_Oi
    public void Vulcan_J(Object[] objArr) {
        Vulcan_Z(new Object[]{new Boolean(((Boolean) objArr[0]).booleanValue())});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    public boolean Vulcan_o(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_w = C0003Vulcan_On.Vulcan_w();
        try {
            try {
                Vulcan_w = this.Vulcan_Y;
                return Vulcan_w == 0 ? Vulcan_w == 1 : Vulcan_w;
            } catch (RuntimeException unused) {
                Vulcan_w = a(Vulcan_w);
                throw Vulcan_w;
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_w);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_F(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_w = C0003Vulcan_On.Vulcan_w();
        try {
            Vulcan_w = this.Vulcan_Y;
            return Vulcan_w == 0 ? Vulcan_w == 0 : Vulcan_w;
        } catch (RuntimeException unused) {
            throw a(Vulcan_w);
        }
    }

    public boolean Vulcan_n(Object[] objArr) {
        return this.Vulcan_Y;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    public boolean equals(Object obj) {
        long j = a ^ 52475813281297L;
        ?? Vulcan_w = C0003Vulcan_On.Vulcan_w();
        try {
            try {
                try {
                    try {
                        Vulcan_w = obj instanceof Vulcan_OQ;
                        if (Vulcan_w != 0) {
                            return Vulcan_w;
                        }
                        if (Vulcan_w != 0) {
                            boolean z = this.Vulcan_Y;
                            return Vulcan_w == 0 ? z == ((Vulcan_OQ) obj).Vulcan_n(new Object[0]) : z;
                        }
                        return false;
                    } catch (RuntimeException unused) {
                        throw a(Vulcan_w);
                    }
                } catch (RuntimeException unused2) {
                    throw a(Vulcan_w);
                }
            } catch (RuntimeException unused3) {
                throw a(Vulcan_w);
            }
        } catch (RuntimeException unused4) {
            throw a(Vulcan_w);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    public int hashCode() {
        long j = a ^ 136957706490034L;
        ?? Vulcan_w = C0003Vulcan_On.Vulcan_w();
        try {
            try {
                Vulcan_w = this.Vulcan_Y;
                return Vulcan_w == 0 ? Vulcan_w != 0 ? Boolean.TRUE.hashCode() : Boolean.FALSE.hashCode() : Vulcan_w;
            } catch (RuntimeException unused) {
                throw a(Vulcan_w);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_w);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0040  */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // java.lang.Comparable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public int compareTo(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = ac.vulcan.anticheat.Vulcan_OQ.a
            r1 = 127124892331220(0x739e920cacd4, double:6.2808042032123E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_w()
            r1 = r6
            ac.vulcan.anticheat.Vulcan_OQ r1 = (ac.vulcan.anticheat.Vulcan_OQ) r1
            r10 = r1
            r9 = r0
            r0 = r10
            boolean r0 = r0.Vulcan_Y
            r11 = r0
            r0 = r5
            boolean r0 = r0.Vulcan_Y     // Catch: java.lang.RuntimeException -> L2b
            r1 = r9
            if (r1 != 0) goto L3b
            r1 = r11
            if (r0 != r1) goto L37
            goto L2f
        L2b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L2f:
            r0 = 0
            goto L4f
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0
        L37:
            r0 = r5
            boolean r0 = r0.Vulcan_Y
        L3b:
            r1 = r9
            if (r1 != 0) goto L4b
            if (r0 == 0) goto L4e
            goto L4a
        L46:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4a:
            r0 = 1
        L4b:
            goto L4f
        L4e:
            r0 = -1
        L4f:
            me.frep.vulcan.spigot.check.AbstractCheck[] r1 = me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_k()     // Catch: java.lang.RuntimeException -> L5d
            if (r1 == 0) goto L6d
            r1 = r9
            if (r1 == 0) goto L69
            goto L61
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L65
            throw r0     // Catch: java.lang.RuntimeException -> L65
        L61:
            r1 = 0
            goto L6a
        L65:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L65
            throw r0
        L69:
            r1 = 1
        L6a:
            ac.vulcan.anticheat.C0003Vulcan_On.Vulcan_m(r1)
        L6d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: ac.vulcan.anticheat.Vulcan_OQ.compareTo(java.lang.Object):int");
    }

    public String toString() {
        return String.valueOf(this.Vulcan_Y);
    }
}
