package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kj.class */
public class Vulcan_kj extends Vulcan_k5 {
    private static final long serialVersionUID = 1832101364842773720L;

    public Vulcan_kj(Throwable th) {
        super(th);
    }

    public Vulcan_kj(String str, Throwable th) {
        super(str, th);
    }
}
