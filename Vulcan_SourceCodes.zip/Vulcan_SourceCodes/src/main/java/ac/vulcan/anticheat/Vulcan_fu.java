package ac.vulcan.anticheat;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_fu.class */
interface Vulcan_fu extends InterfaceC0031Vulcan_n {
    void Vulcan_j(Object[] objArr);
}
