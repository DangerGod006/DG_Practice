package ac.vulcan.anticheat;

import java.util.Arrays;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:ac/vulcan/anticheat/Vulcan_kA.class */
final class Vulcan_kA extends Vulcan_kH {
    private final char[] Vulcan_x;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    Vulcan_kA(char[] cArr) {
        this.Vulcan_x = (char[]) cArr.clone();
        Arrays.sort(this.Vulcan_x);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    @Override // ac.vulcan.anticheat.Vulcan_kH
    /* JADX INFO: renamed from: Vulcan_A */
    public int mo437Vulcan_A(Object[] objArr) {
        char[] cArr = (char[]) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        ((Integer) objArr[2]).intValue();
        ((Integer) objArr[3]).intValue();
        ((Long) objArr[4]).longValue();
        ?? Vulcan_W = Vulcan_P.Vulcan_W();
        try {
            Vulcan_W = Arrays.binarySearch(this.Vulcan_x, cArr[iIntValue]);
            return Vulcan_W != 0 ? Vulcan_W >= 0 ? 1 : 0 : Vulcan_W;
        } catch (RuntimeException unused) {
            throw a(Vulcan_W);
        }
    }
}
