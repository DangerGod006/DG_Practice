package org.apache.commons.lang3;

import java.nio.charset.Charset;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:org/apache/commons/lang3/Charsets.class */
class Charsets {
    Charsets() {
    }

    static Charset toCharset(Charset charset) {
        return charset == null ? Charset.defaultCharset() : charset;
    }

    static Charset toCharset(String str) {
        return str == null ? Charset.defaultCharset() : Charset.forName(str);
    }

    static String toCharsetName(String str) {
        return str == null ? Charset.defaultCharset().name() : str;
    }
}
