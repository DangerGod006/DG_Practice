package org.apache.commons.lang3;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:org/apache/commons/lang3/ClassPathUtils.class */
public class ClassPathUtils {
    public static String toFullyQualifiedName(Class<?> cls, String str) {
        Validate.notNull(cls, "context", new Object[0]);
        Validate.notNull(str, "resourceName", new Object[0]);
        return toFullyQualifiedName(cls.getPackage(), str);
    }

    public static String toFullyQualifiedName(Package r4, String str) {
        Validate.notNull(r4, "context", new Object[0]);
        Validate.notNull(str, "resourceName", new Object[0]);
        return r4.getName() + "." + str;
    }

    public static String toFullyQualifiedPath(Class<?> cls, String str) {
        Validate.notNull(cls, "context", new Object[0]);
        Validate.notNull(str, "resourceName", new Object[0]);
        return toFullyQualifiedPath(cls.getPackage(), str);
    }

    public static String toFullyQualifiedPath(Package r5, String str) {
        Validate.notNull(r5, "context", new Object[0]);
        Validate.notNull(str, "resourceName", new Object[0]);
        return r5.getName().replace('.', '/') + "/" + str;
    }
}
