package org.apache.commons.lang3.builder;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:org/apache/commons/lang3/builder/Builder.class */
@FunctionalInterface
public interface Builder<T> {
    T build();
}
