package org.apache.commons.lang3;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:org/apache/commons/lang3/CharUtils.class */
public class CharUtils {
    private static final String[] CHAR_STRING_ARRAY = new String[128];
    private static final char[] HEX_DIGITS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    public static final char LF = '\n';
    public static final char CR = '\r';
    public static final char NUL = 0;

    static {
        char c = 0;
        while (true) {
            char c2 = c;
            if (c2 < CHAR_STRING_ARRAY.length) {
                CHAR_STRING_ARRAY[c2] = String.valueOf(c2);
                c = (char) (c2 + 1);
            } else {
                return;
            }
        }
    }

    @Deprecated
    public static Character toCharacterObject(char c) {
        return Character.valueOf(c);
    }

    public static Character toCharacterObject(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        return Character.valueOf(str.charAt(0));
    }

    public static char toChar(Character ch) {
        Validate.notNull(ch, "ch", new Object[0]);
        return ch.charValue();
    }

    public static char toChar(Character ch, char c) {
        if (ch == null) {
            return c;
        }
        return ch.charValue();
    }

    public static char toChar(String str) {
        Validate.notEmpty(str, "The String must not be empty", new Object[0]);
        return str.charAt(0);
    }

    public static char toChar(String str, char c) {
        if (StringUtils.isEmpty(str)) {
            return c;
        }
        return str.charAt(0);
    }

    public static int toIntValue(char c) {
        if (!isAsciiNumeric(c)) {
            throw new IllegalArgumentException("The character " + c + " is not in the range '0' - '9'");
        }
        return c - '0';
    }

    public static int toIntValue(char c, int i) {
        if (!isAsciiNumeric(c)) {
            return i;
        }
        return c - '0';
    }

    public static int toIntValue(Character ch) {
        Validate.notNull(ch, "ch", new Object[0]);
        return toIntValue(ch.charValue());
    }

    public static int toIntValue(Character ch, int i) {
        if (ch == null) {
            return i;
        }
        return toIntValue(ch.charValue(), i);
    }

    public static String toString(char c) {
        if (c < 128) {
            return CHAR_STRING_ARRAY[c];
        }
        return new String(new char[]{c});
    }

    public static String toString(Character ch) {
        if (ch == null) {
            return null;
        }
        return toString(ch.charValue());
    }

    public static String unicodeEscaped(char c) {
        return "\\u" + HEX_DIGITS[(c >> '\f') & 15] + HEX_DIGITS[(c >> '\b') & 15] + HEX_DIGITS[(c >> 4) & 15] + HEX_DIGITS[c & 15];
    }

    public static String unicodeEscaped(Character ch) {
        if (ch == null) {
            return null;
        }
        return unicodeEscaped(ch.charValue());
    }

    public static boolean isAscii(char c) {
        return c < 128;
    }

    public static boolean isAsciiPrintable(char c) {
        return c >= ' ' && c < 127;
    }

    public static boolean isAsciiControl(char c) {
        return c < ' ' || c == 127;
    }

    public static boolean isAsciiAlpha(char c) {
        return isAsciiAlphaUpper(c) || isAsciiAlphaLower(c);
    }

    public static boolean isAsciiAlphaUpper(char c) {
        return c >= 'A' && c <= 'Z';
    }

    public static boolean isAsciiAlphaLower(char c) {
        return c >= 'a' && c <= 'z';
    }

    public static boolean isAsciiNumeric(char c) {
        return c >= '0' && c <= '9';
    }

    public static boolean isAsciiAlphanumeric(char c) {
        return isAsciiAlpha(c) || isAsciiNumeric(c);
    }

    public static int compare(char c, char c2) {
        return c - c2;
    }
}
