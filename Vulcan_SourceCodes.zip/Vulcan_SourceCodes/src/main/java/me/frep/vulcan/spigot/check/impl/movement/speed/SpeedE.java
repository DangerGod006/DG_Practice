package me.frep.vulcan.spigot.check.impl.movement.speed;

import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/speed/SpeedE.class */
@CheckInfo(name = "Speed", type = 'E', complexType = "Prediction", description = "Invalid friction.")
public class SpeedE extends AbstractCheck {
    private static int Vulcan_a;
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x09ae: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 2517
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.speed.SpeedE.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_A(int i) {
        Vulcan_a = i;
    }

    public static int Vulcan_L() {
        return Vulcan_a;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_m() {
        return Vulcan_L() == 0 ? 56 : 0;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0078, code lost:
    
        if (r0 >= r15) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x007b, code lost:
    
        r12 = r13.charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0084, code lost:
    
        me.frep.vulcan.spigot.check.impl.movement.speed.SpeedE.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x009c, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x009f, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a3, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ab, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00d0, code lost:
    
        r8 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d5, code lost:
    
        r8 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00da, code lost:
    
        r8 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00de, code lost:
    
        r8 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e3, code lost:
    
        r8 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00e8, code lost:
    
        r8 = 117;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00ed, code lost:
    
        r8 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ef, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00f7, code lost:
    
        if (r4 != 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00fa, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00ff, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0104, code lost:
    
        if (r4 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0108, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0116, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0128, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x002d, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x003d, code lost:
    
        if (r0 >= r15) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0049, code lost:
    
        r13 = "\u001c?J|\u0006X\u0003y'\u0010]";
        r15 = "\u001c?J|\u0006X\u0003y'\u0010]".length();
        r12 = 4;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0068, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x009f, B:28:0x00ff], limit reached: 38 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v24 */
    /* JADX WARN: Type inference failed for: r2v5, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0104 -> B:15:0x009f). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.speed.SpeedE.m1225clinit():void");
    }

    public SpeedE(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
