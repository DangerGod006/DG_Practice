package me.frep.vulcan.spigot.check.impl.player.scaffold;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/scaffold/ScaffoldK.class */
@CheckInfo(name = "Scaffold", type = 'K', complexType = "Limit", description = "Bridging too quickly.")
public class ScaffoldK extends AbstractCheck {
    private int Vulcan_E;
    private final Map Vulcan_w;
    private int Vulcan_v;
    private static final long b = Vulcan_n.a(2663634172223918587L, -7500057672302918158L, MethodHandles.lookup().lookupClass()).a(201124991639629L);
    private static final String d;

    static {
        long j = b ^ 132194871473414L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        d = b(cipher.doFinal("\u0006Ø\u008cÃ*r½Ó".getBytes(CharEncoding.ISO_8859_1))).intern();
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public ScaffoldK(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 33940600956821L;
        ?? Vulcan_B = ScaffoldN.Vulcan_B();
        this.Vulcan_w = new HashMap();
        try {
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_B = new AbstractCheck[1];
                ScaffoldN.Vulcan_h((AbstractCheck[]) Vulcan_B);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_B);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0079 A[PHI: r0 r1
  0x0079: PHI (r0v13 ??) = (r0v20 ??), (r0v21 ??), (r0v22 ??) binds: [B:6:0x0058, B:8:0x005d, B:13:0x006a] A[DONT_GENERATE, DONT_INLINE]
  0x0079: PHI (r1v14 com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action) = 
  (r1v13 com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action)
  (r1v13 com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action)
  (r1v17 com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action)
 binds: [B:6:0x0058, B:8:0x005d, B:13:0x006a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldK] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v6, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldK] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r0 = r10
            r1 = r0; r2 = r0; 
            r2 = 130930509284752(0x7714a27f0590, double:6.46882666300943E-310)
            long r1 = r1 ^ r2
            r13 = r1
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldN.Vulcan_B()
            r15 = r0
            r0 = r8
            r1 = r13
            r2 = r12
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            boolean r0 = r0.Vulcan_J(r1)
            if (r0 == 0) goto L8f
            com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction r0 = new com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction
            r1 = r0
            r2 = r12
            com.github.retrooper.packetevents.event.PacketReceiveEvent r2 = (com.github.retrooper.packetevents.event.PacketReceiveEvent) r2
            r1.<init>(r2)
            r16 = r0
            r0 = r16
            com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action r0 = r0.getAction()     // Catch: java.lang.RuntimeException -> L66
            com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action r1 = com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction.Action.START_SNEAKING     // Catch: java.lang.RuntimeException -> L66
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L79
            r2 = r15
            if (r2 != 0) goto L79
            if (r0 == r1) goto L7c
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L75
            throw r0     // Catch: java.lang.RuntimeException -> L75
        L6a:
            r0 = r16
            com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action r0 = r0.getAction()     // Catch: java.lang.RuntimeException -> L75
            com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action r1 = com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction.Action.STOP_SNEAKING     // Catch: java.lang.RuntimeException -> L75
            goto L79
        L75:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L79:
            if (r0 != r1) goto L8f
        L7c:
            r0 = r8
            r1 = r8
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L8b
            int r1 = r1.Vulcan_S(r2)     // Catch: java.lang.RuntimeException -> L8b
            r0.Vulcan_E = r1     // Catch: java.lang.RuntimeException -> L8b
            goto L8f
        L8b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldK.Vulcan_T(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:49:0x00e6
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 626
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldK.Vulcan_a(java.lang.Object[]):void");
    }
}
