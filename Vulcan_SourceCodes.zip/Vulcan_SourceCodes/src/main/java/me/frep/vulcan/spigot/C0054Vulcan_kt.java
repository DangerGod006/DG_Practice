package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_kt, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kt.class */
public class C0054Vulcan_kt implements Listener {
    private static boolean Vulcan_y;
    private static final long a = Vulcan_n.a(-4468679638690033405L, 4962111437168676092L, MethodHandles.lookup().lookupClass()).a(184333012365189L);
    private static final String[] b;

    public static void Vulcan_t(boolean z) {
        Vulcan_y = z;
    }

    public static boolean Vulcan_t() {
        return Vulcan_y;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_O() {
        return !Vulcan_t();
    }

    static {
        int i;
        long j = a ^ 130095485371922L;
        Vulcan_t(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "\u001am±<\u008f=Û\u0089ÉÔ^JµYô\u0004\u00102Àtk\u0084F¶\fÛé\u001fß\u0086¢ô\u0098";
        int length = "\u001am±<\u008f=Û\u0089ÉÔ^JµYô\u0004\u00102Àtk\u0084F¶\fÛé\u001fß\u0086¢ô\u0098".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u001am±<\u008f=Û\u0089ÉÔ^JµYô\u0004\u0010»\u0018+iúù\u0016S\u0000Îeåò-\u0014\u000f";
                        length = "\u001am±<\u008f=Û\u0089ÉÔ^JµYô\u0004\u0010»\u0018+iúù\u0016S\u0000Îeåò-\u0014\u000f".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v16, types: [me.frep.vulcan.spigot.Vulcan_fI] */
    /* JADX WARN: Type inference failed for: r0v19, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v24, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v26, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v35, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v38, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v44, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v48, types: [me.frep.vulcan.spigot.Vulcan_fI] */
    /* JADX WARN: Type inference failed for: r0v52, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v53, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v55, types: [me.frep.vulcan.spigot.Vulcan_OB] */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v5, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v15, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v19, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v23, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v27, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v31, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r3v31, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler
    public void Vulcan_g(PlayerJoinEvent playerJoinEvent) throws Exception {
        long j = (a ^ 42635955127656L) ^ 14308276548991L;
        ?? Vulcan_t = Vulcan_t();
        ?? player = playerJoinEvent.getPlayer();
        try {
            try {
                try {
                    Vulcan_t = player.hasPermission(b[3]);
                    try {
                        if (Vulcan_t == 0) {
                            if (Vulcan_t != 0) {
                                Vulcan_t = Vulcan_fe.Vulcan_J;
                                if (Vulcan_t == 0) {
                                    if (Vulcan_t != 0) {
                                        ?? Vulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
                                        ?? r3 = new Object[2];
                                        player[1] = Long.valueOf(j);
                                        r3[0] = r3;
                                        Vulcan_e.Vulcan_V(r3);
                                    }
                                    Vulcan_t = Vulcan_fe.Vulcan_sY;
                                }
                            } else {
                                Vulcan_t = Vulcan_fe.Vulcan_sY;
                            }
                        }
                        if (Vulcan_t != 0) {
                            C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
                            if (c0042Vulcan_OzVulcan_L == null) {
                                return;
                            } else {
                                Vulcan_fe.Vulcan_tC.forEach((v2) -> {
                                    lambda$onJoin$0(r1, r2, v2);
                                });
                            }
                        }
                        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L2 = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
                        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L2;
                        ?? A = c0042Vulcan_Oz;
                        if (Vulcan_t == 0) {
                            if (c0042Vulcan_Oz == null) {
                                return;
                            }
                            ?? r2 = new Object[1];
                            c0042Vulcan_OzVulcan_L2.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getX());
                            r2.Vulcan_J2(r2);
                            ?? r22 = new Object[1];
                            c0042Vulcan_OzVulcan_L2.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getY());
                            r22.Vulcan_Jc(r22);
                            ?? r23 = new Object[1];
                            c0042Vulcan_OzVulcan_L2.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getZ());
                            r23.Vulcan_J0(r23);
                            ?? r24 = new Object[1];
                            c0042Vulcan_OzVulcan_L2.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getX());
                            r24.Vulcan_Jy(r24);
                            ?? r25 = new Object[1];
                            c0042Vulcan_OzVulcan_L2.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getY());
                            r25.Vulcan_Jp(r25);
                            A = c0042Vulcan_OzVulcan_L2;
                        }
                        try {
                            try {
                                ?? r26 = new Object[1];
                                A.m639Vulcan_M(new Object[0])[0] = Double.valueOf(player.getLocation().getZ());
                                r26.Vulcan_JU(r26);
                                A = AbstractCheck.Vulcan_k();
                                if (A != 0) {
                                    Vulcan_t(Vulcan_t == 0);
                                }
                            } catch (RuntimeException unused) {
                                A = a((RuntimeException) A);
                                throw A;
                            }
                        } catch (RuntimeException unused2) {
                            throw a((RuntimeException) A);
                        }
                    } catch (RuntimeException unused3) {
                        throw a((RuntimeException) Vulcan_t);
                    }
                } catch (RuntimeException unused4) {
                    throw a((RuntimeException) Vulcan_t);
                }
            } catch (RuntimeException unused5) {
                throw a((RuntimeException) Vulcan_t);
            }
        } catch (RuntimeException unused6) {
            throw a((RuntimeException) Vulcan_t);
        }
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private static void lambda$onJoin$0(Player player, C0042Vulcan_Oz c0042Vulcan_Oz, String str) {
        long j = (a ^ 53973554999790L) ^ 74262429077602L;
        String[] strArr = b;
        Object[] objArr = new Object[2];
        str.replaceAll(strArr[1], c0042Vulcan_Oz.getClientBrand()).replaceAll(strArr[2], player.getName())[1] = Long.valueOf(j);
        objArr[0] = objArr;
        player.sendMessage(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler
    public void Vulcan_R(PlayerQuitEvent playerQuitEvent) {
        long j = a ^ 78643984289038L;
        boolean zVulcan_t = Vulcan_t();
        Player player = playerQuitEvent.getPlayer();
        Vulcan_r.INSTANCE.Vulcan_e().Vulcan_X(new Object[0]).remove(player);
        Vulcan_r.INSTANCE.Vulcan_e().Vulcan_R(new Object[0]).remove(player);
        Vulcan_r.INSTANCE.Vulcan_M().remove(player.getUniqueId());
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        ?? Vulcan_O = c0042Vulcan_Oz;
        if (!zVulcan_t) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                Vulcan_O = c0042Vulcan_OzVulcan_L;
            }
        }
        try {
            Vulcan_O = Vulcan_O.m639Vulcan_M(new Object[0]).Vulcan_O(new Object[0]);
            if (Vulcan_O != 0) {
                Vulcan_r.INSTANCE.Vulcan_e().Vulcan_A(new Object[]{Vulcan_fe.Vulcan_y.replaceAll(b[2], player.getName())});
                Vulcan_fe.Vulcan_s0.forEach((v1) -> {
                    lambda$onQuit$1(r1, v1);
                });
            }
            ?? r0 = zVulcan_t;
            if (r0 != 0) {
                try {
                    r0 = new AbstractCheck[2];
                    AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) r0);
                }
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_O);
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String] */
    private static void lambda$onQuit$1(Player player, String str) {
        long j = a ^ 133423220175752L;
        long j2 = j ^ 12941281890820L;
        long j3 = j ^ 99250672120558L;
        Object[] objArr = new Object[2];
        str.replaceAll(b[0], player.getName())[1] = Long.valueOf(j2);
        objArr[0] = objArr;
        ?? Vulcan_X = Vulcan_ym.Vulcan_X(objArr);
        Object[] objArr2 = new Object[2];
        Vulcan_X[1] = Long.valueOf(j3);
        objArr2[0] = objArr2;
        Vulcan_OM.Vulcan_u(objArr2);
    }
}
