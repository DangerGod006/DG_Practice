package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Entity;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Ox, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Ox.class */
public final class C0041Vulcan_Ox {
    private static final long a = Vulcan_n.a(-4139062990803830201L, -5979837049621094911L, MethodHandles.lookup().lookupClass()).a(234372548983000L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 77129688719189L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[5];
        int i3 = 0;
        String str = "³\u0019ï#^nm¿\u0010QÛhRWHî¿\u008f\u008eÖ\u0093\u009dµì¢\b¨¢ã }EñÐ";
        int length = "³\u0019ï#^nm¿\u0010QÛhRWHî¿\u008f\u008eÖ\u0093\u009dµì¢\b¨¢ã }EñÐ".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u009a\u0018à*»è\u008be\u0082½F!¡.wydr\u0082È^\u0082V½i¥Ë¥Xq\u0011ø\f/å\f\u0084 Av¥¹_¶Ü\u0093û\u0018¸\u0010ÚK3\u0001È§\b1 )Ó!Òfw";
                        length = "\u009a\u0018à*»è\u008be\u0082½F!¡.wydr\u0082È^\u0082V½i¥Ë¥Xq\u0011ø\f/å\f\u0084 Av¥¹_¶Ü\u0093û\u0018¸\u0010ÚK3\u0001È§\b1 )Ó!Òfw".length();
                        cCharAt = '8';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private C0041Vulcan_Ox() {
        throw new UnsupportedOperationException(b[3]);
    }

    public static boolean Vulcan_R(Object[] objArr) {
        return ((Entity) objArr[0]).getType().toString().equals(b[2]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_C(Object[] objArr) {
        Entity entity = (Entity) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = entity.getType().toString().contains(b[4]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = entity.getType().toString().contains(b[0]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_H(Object[] objArr) {
        return ((Entity) objArr[0]).getType().toString().equals(b[1]);
    }
}
