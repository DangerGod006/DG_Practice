package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_t;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Of, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Of.class */
public class RunnableC0035Vulcan_Of implements Runnable {
    private static Vulcan_t Vulcan_s;
    static final boolean Vulcan_A;
    private static int[] Vulcan_h;
    private static final long a = Vulcan_n.a(-8152875131423341797L, -4508500836679469270L, MethodHandles.lookup().lookupClass()).a(262435090536853L);
    private static final String[] b;
    private int Vulcan_b = 0;
    private int Vulcan_y = 0;
    private long Vulcan_W = Long.MAX_VALUE;
    private long Vulcan_S = Long.MAX_VALUE;
    private long Vulcan_c = Long.MAX_VALUE;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x021d: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // java.lang.Runnable
    public void run() {
        /*
            Method dump skipped, instruction units count: 561
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.RunnableC0035Vulcan_Of.run():void");
    }

    public static void Vulcan_t(int[] iArr) {
        Vulcan_h = iArr;
    }

    public static int[] Vulcan_g() {
        return Vulcan_h;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    static {
        int i;
        long j = a ^ 95732411650280L;
        Vulcan_t(new int[3]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "_'ñ\u001cA§\t\u001eô\u0005\u000f¬ÌËà¡Û?Ä\u00adäè\u0096\u00830G\u009dGû³g\u008bm\u001fç\u0094\u0004¢\u0093+\u0010ø©_\bY©|0fCBe¹\u0015Ù´";
        int length = "_'ñ\u001cA§\t\u001eô\u0005\u000f¬ÌËà¡Û?Ä\u00adäè\u0096\u00830G\u009dGû³g\u008bm\u001fç\u0094\u0004¢\u0093+\u0010ø©_\bY©|0fCBe¹\u0015Ù´".length();
        char cCharAt = '(';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            ?? DesiredAssertionStatus = strArr;
                            b = DesiredAssertionStatus;
                            try {
                                DesiredAssertionStatus = RunnableC0035Vulcan_Of.class.desiredAssertionStatus();
                                Vulcan_A = DesiredAssertionStatus == 0;
                                return;
                            } catch (RuntimeException unused) {
                                throw a((RuntimeException) DesiredAssertionStatus);
                            }
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Éí¬á\u001c;+ßvú\u0082\u0090ºM5\u0087\u0018VÕ\u007f\u001a\u0006\u0007cÏâYû?\\\u0018w{v«îêñ\u0010ï\u0010M0½¯\u009f\u0081\r\u008aw,N Ù®9¢";
                        length = "Éí¬á\u001c;+ßvú\u0082\u0090ºM5\u0087\u0018VÕ\u007f\u001a\u0006\u0007cÏâYû?\\\u0018w{v«îêñ\u0010ï\u0010M0½¯\u009f\u0081\r\u008aw,N Ù®9¢".length();
                        cCharAt = '(';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    public int Vulcan_P(Object[] objArr) {
        return this.Vulcan_b;
    }

    public int Vulcan_U(Object[] objArr) {
        return this.Vulcan_y;
    }

    public long Vulcan_x(Object[] objArr) {
        return this.Vulcan_W;
    }

    public long Vulcan_g(Object[] objArr) {
        return this.Vulcan_S;
    }

    public long Vulcan_l(Object[] objArr) {
        return this.Vulcan_c;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [ac.vulcan.anticheat.Vulcan_H] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object[], long] */
    public void Vulcan_q(Object[] objArr) {
        Vulcan_t vulcan_tVulcan_w;
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        long j = jLongValue ^ 7972135673081L;
        ?? Vulcan_g = Vulcan_g();
        try {
            Vulcan_g = Vulcan_g;
            try {
                if (Vulcan_g != 0) {
                    try {
                        try {
                            Vulcan_g = Vulcan_A;
                            if (Vulcan_g != 0) {
                                ?? M1085Vulcan_j = Vulcan_r.m1085Vulcan_j();
                                ?? r2 = 0;
                                ?? r5 = new Object[4];
                                1[3] = Long.valueOf(j);
                                r2[2] = Long.valueOf((long) r5);
                                this[1] = Long.valueOf((long) r5);
                                r5[0] = r5;
                                vulcan_tVulcan_w = M1085Vulcan_j.Vulcan_w(r5);
                                Vulcan_s = vulcan_tVulcan_w;
                            } else if (jLongValue >= 0) {
                                vulcan_tVulcan_w = Vulcan_s;
                                if (Vulcan_g != 0) {
                                    if (vulcan_tVulcan_w != null) {
                                        throw new AssertionError(b[2]);
                                    }
                                    ?? M1085Vulcan_j2 = Vulcan_r.m1085Vulcan_j();
                                    ?? r22 = 0;
                                    ?? r52 = new Object[4];
                                    1[3] = Long.valueOf(j);
                                    r22[2] = Long.valueOf((long) r52);
                                    this[1] = Long.valueOf((long) r52);
                                    r52[0] = r52;
                                    vulcan_tVulcan_w = M1085Vulcan_j2.Vulcan_w(r52);
                                }
                                Vulcan_s = vulcan_tVulcan_w;
                            }
                        } catch (RuntimeException unused) {
                            throw a((RuntimeException) Vulcan_g);
                        }
                    } catch (RuntimeException unused2) {
                        throw a((RuntimeException) Vulcan_g);
                    }
                }
                ?? r0 = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
                if (r0 >= 0) {
                    try {
                        if (AbstractCheck.Vulcan_k() == null) {
                            return;
                        }
                        r0 = new int[5];
                        Vulcan_t(r0);
                    } catch (RuntimeException unused3) {
                        throw a((RuntimeException) r0);
                    }
                }
            } catch (RuntimeException unused4) {
                throw a((RuntimeException) Vulcan_g);
            }
        } catch (RuntimeException unused5) {
            throw a((RuntimeException) Vulcan_g);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_t] */
    public void Vulcan_p(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_g = Vulcan_g();
        try {
            Vulcan_g = Vulcan_s;
            ?? r0 = Vulcan_g;
            if (Vulcan_g != 0) {
                if (Vulcan_g == 0) {
                    return;
                } else {
                    r0 = Vulcan_s;
                }
            }
            r0.Vulcan_T(new Object[0]);
            Vulcan_s = null;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_g);
        }
    }

    private static void lambda$run$0(String str) {
        Vulcan_OM.Vulcan_Y(str.replaceAll(b[1], Integer.toString(Vulcan_f0.Vulcan__(new Object[0]))));
    }
}
