package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.CommandSender;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_k4.class */
public class Vulcan_k4 {
    private static boolean Vulcan_V;
    private static final long a = Vulcan_n.a(353493555519917820L, -386180041771814776L, MethodHandles.lookup().lookupClass()).a(221894856111987L);
    private static final String[] c;

    public static void Vulcan_b(boolean z) {
        Vulcan_V = z;
    }

    public static boolean Vulcan_W() {
        return Vulcan_V;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_Y() {
        return !Vulcan_W();
    }

    static {
        long j = a ^ 53559075329153L;
        Vulcan_b(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "J9àz.Ñ\u0091hyqÜß\u0005Ú70@\u0004ê\tó\u0002Üs3\t\u008caÇÆ\u009e\u008e\\à½â0®\u008d£§\u009b\u009e2\u0082äýM #.û\u0097q\u00139\u0098VKîU½m<êö·\u009b÷/ä:\u001d]¢ºàxï\u0088\u009c".length();
        char cCharAt = 16;
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("J9àz.Ñ\u0091hyqÜß\u0005Ú70@\u0004ê\tó\u0002Üs3\t\u008caÇÆ\u009e\u008e\\à½â0®\u008d£§\u009b\u009e2\u0082äýM #.û\u0097q\u00139\u0098VKîU½m<êö·\u009b÷/ä:\u001d]¢ºàxï\u0088\u009c".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                c = strArr;
                return;
            }
            cCharAt = "J9àz.Ñ\u0091hyqÜß\u0005Ú70@\u0004ê\tó\u0002Üs3\t\u008caÇÆ\u009e\u008e\\à½â0®\u008d£§\u009b\u009e2\u0082äýM #.û\u0097q\u00139\u0098VKîU½m<êö·\u009b÷/ä:\u001d]¢ºàxï\u0088\u009c".charAt(i3);
        }
    }

    private static RuntimeException b(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c2 = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c2 | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Object[]] */
    public void Vulcan_D(Object[] objArr) {
        CommandSender commandSender = (CommandSender) objArr[0];
        String str = (String) objArr[1];
        long jLongValue = (a ^ ((Long) objArr[2]).longValue()) ^ 74096830230175L;
        boolean zVulcan_W = Vulcan_W();
        String str2 = c[0];
        ?? r6 = new Object[2];
        Vulcan_fe.Vulcan_vP[1] = Long.valueOf(jLongValue);
        r6[0] = r6;
        ?? r4 = new Object[2];
        str.replaceAll(str2, Vulcan_ym.Vulcan_X(r6))[1] = Long.valueOf(jLongValue);
        r4[0] = r4;
        commandSender.sendMessage(Vulcan_ym.Vulcan_X(r4));
        ?? r0 = zVulcan_W;
        if (r0 != 0) {
            try {
                r0 = new AbstractCheck[4];
                AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
            } catch (RuntimeException unused) {
                throw b(r0);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void Vulcan_i(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object obj = (CommandSender) objArr[1];
        Object[] objArr2 = new Object[3];
        c[1][2] = Long.valueOf((a ^ jLongValue) ^ 61120854708086L);
        objArr2[1] = objArr2;
        objArr2[0] = obj;
        Vulcan_D(objArr2);
    }
}
