package me.frep.vulcan.spigot.check.impl.movement.jump;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/jump/JumpD.class */
public class JumpD {
}
