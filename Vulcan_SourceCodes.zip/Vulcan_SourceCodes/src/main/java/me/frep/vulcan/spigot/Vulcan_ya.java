package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ya.class */
public interface Vulcan_ya {
    String Vulcan_T();
}
