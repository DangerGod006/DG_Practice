package me.frep.vulcan.api.check;

import java.util.List;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/api/check/ICheckData.class */
public interface ICheckData {
    boolean isEnabled();

    boolean isPunishable();

    boolean isBroadcastPunishment();

    boolean isHotbarShuffle();

    boolean isRandomRotation();

    int getMaxViolations();

    int getAlertInterval();

    int getMinimumVlToNotify();

    int getMaxPing();

    int getMinimumVlToRandomlyRotate();

    int getMinimumVlToShuffleHotbar();

    double getMinimumTps();

    double getMaxBuffer();

    double getBufferDecay();

    double getBufferMultiple();

    List getPunishmentCommands();

    int getRandomRotationInterval();
}
