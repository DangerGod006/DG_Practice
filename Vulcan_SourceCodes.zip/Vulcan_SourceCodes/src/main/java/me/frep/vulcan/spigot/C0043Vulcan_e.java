package me.frep.vulcan.spigot;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_e.class */
public class C0043Vulcan_e {
    private static boolean Vulcan_W;
    private static final long a = Vulcan_n.a(97847784344655383L, 5417111428047701764L, MethodHandles.lookup().lookupClass()).a(207609610733790L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0168: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_f(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1664
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0043Vulcan_e.Vulcan_f(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x012c: INVOKE (r-1 I:java.lang.String), (r0 I:java.lang.String), (r1 I:java.lang.String) VIRTUAL call: java.lang.String.replaceAll(java.lang.String, java.lang.String):java.lang.String
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void lambda$handlePunishment$1(me.frep.vulcan.spigot.C0042Vulcan_Oz r9, me.frep.vulcan.spigot.check.AbstractCheck r10, int r11, java.lang.String r12) {
        /*
            Method dump skipped, instruction units count: 386
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0043Vulcan_e.lambda$handlePunishment$1(me.frep.vulcan.spigot.Vulcan_Oz, me.frep.vulcan.spigot.check.AbstractCheck, int, java.lang.String):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00be: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void lambda$handlePunishment$0(me.frep.vulcan.spigot.C0042Vulcan_Oz r10, me.frep.vulcan.spigot.check.AbstractCheck r11) {
        /*
            Method dump skipped, instruction units count: 1731
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0043Vulcan_e.lambda$handlePunishment$0(me.frep.vulcan.spigot.Vulcan_Oz, me.frep.vulcan.spigot.check.AbstractCheck):void");
    }

    public static void Vulcan_p(boolean z) {
        Vulcan_W = z;
    }

    public static boolean Vulcan_E() {
        return Vulcan_W;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_Z() {
        return !Vulcan_E();
    }

    static {
        int i;
        long j = a ^ 114712210376086L;
        Vulcan_p(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[61];
        int i3 = 0;
        String str = "`?\u008cÚëê\u0084Ôé\u0098\u0092zëc\u0000|\u0010\u0006ùü+å\fA^Oç¯%\u0016.6¤\u0010!^å$Ô<fFá8\u0011\r$\u0090H/\u00100\"W\u009c\u001c¢\u0086k\u001eD\nÛ¶uª?\u0010\nMÙ$Rñ\u008c <H´Å£\u0090#-\b-«uä\u0007î<Õ\u0010\u007f9ðò\u0087\u0004\u0006n¦;\u00031];ÞM\b5\u0005ÈÚ5+ÛÒ\u00100\"W\u009c\u001c¢\u0086kÜ\u0013Ý-Iï\u0017Á\u0010[ä\u0082PØ_\u0083\u001cÍa\u008dÿU\u0093öQ\u0010ÎÃÔ ð\u0004ó:ý;Á±4Â/¼\u0010ìd$_\u0087îYFH7 ¾#Z´±\u0010\nMÙ$Rñ\u008c <H´Å£\u0090#-\b\u0017`\u001dC\u0085Ô\u0084¡\b¡?¢«á]¹\u0016\u0010ÊªäÉÑ\u0010%\u0001µL÷ÉÍÔÐk\bfá\u0017\u0098\u0011ñ¥\u0092\u0010}*µñ\fÉ\u000fò\u0016\u009fLßH\tæ»\u0010ìd$_\u0087îYFH7 ¾#Z´±\u0010ä\u0082\u009bó®´1\u0082T\u0096òr\u009c@Ô{\u0010\u007f9ðò\u0087\u0004\u0006n¦;\u00031];ÞM\b8¾\"\u008f¤á¿ø\b>\u0085\u009f6\u0090ö¯\u0098\b-«uä\u0007î<Õ\bÓWkM¢f/\u008d\u0010\u0092¤d\u009c\u0086\u001aWáõÓÛÞ\u009bÌ»\u007f\u0010ÎÃÔ ð\u0004ó:ý;Á±4Â/¼\b¨Ðå²tQè\u0091\b¨Ðå²tQè\u0091\bËR\bl\u008a qI\u00100\"W\u009c\u001c¢\u0086kÜ\u0013Ý-Iï\u0017Á\u0018\u008e]ó\u0096\u0093\u0012X#XØªðÞ\u0018\u001bKozW\u0018Ï¹A{\u0018\nMÙ$Rñ\u008c _?©¡ÂüeGÈ*\u008c8óm¹ \u0010Ç\u0085\u0081¡¤;\u0085\u0087´Þ1aÖS\u008c=\u0010¬/~\u0086!æ%¡£±î0È{Pï\u0010O\u008e\bbÆ\u0004\u008c\u001dwÎæ¥Ñj`¦\bk\u0014#Ú~1\u0002ú\bjÓuåv{Uú\u0018\b\u000bJ~Ä¾\u0011<\u009fÕùù:\\\tðaÐë\u009b¥ëZ\u0002\bÄ\rÎæ±\u0088\u0088¸\u0010`?\u008cÚëê\u0084Ôô\u001f¹ûXKÆß\be\f\u0019þÎ\u0007Õ¤\u0010ÊªäÉÑ\u0010%\u0001µL÷ÉÍÔÐk\bËR\bl\u008a qI\u0010¬/~\u0086!æ%¡£±î0È{Pï\u0010[ä\u0082PØ_\u0083\u001cÍa\u008dÿU\u0093öQ\bÑ;\u009cdKµ\u0091=\u0010ÜXÞÚ§Ìk~\u0018HÜèÈÆÂH\u0010lj6ÓÃ\u009d\u0092\u0094kjÉ!G\u0097Ù0\b5\u0005ÈÚ5+ÛÒ\u0010Mþ>w À\u007fM\u0088ìG\b1\u0001³\u0091\bjÓuåv{Uú\bfá\u0017\u0098\u0011ñ¥\u0092\bk\u0014#Ú~1\u0002ú\u0018\nMÙ$Rñ\u008c _?©¡ÂüeGÈ*\u008c8óm¹ \u0010¯çÓËPF$Ö¼[áJ^Ù\u000bÏ\u0010Ç\u0085\u0081¡¤;\u0085\u0087´Þ1aÖS\u008c=\u0010~Ý\u009frñ\u009f¨o\u0099Ó/Ê\u0006Z\f±\u0010JØ\u0005\u0098ÞPêcÙùÉ\u001cüS\rô";
        int length = "`?\u008cÚëê\u0084Ôé\u0098\u0092zëc\u0000|\u0010\u0006ùü+å\fA^Oç¯%\u0016.6¤\u0010!^å$Ô<fFá8\u0011\r$\u0090H/\u00100\"W\u009c\u001c¢\u0086k\u001eD\nÛ¶uª?\u0010\nMÙ$Rñ\u008c <H´Å£\u0090#-\b-«uä\u0007î<Õ\u0010\u007f9ðò\u0087\u0004\u0006n¦;\u00031];ÞM\b5\u0005ÈÚ5+ÛÒ\u00100\"W\u009c\u001c¢\u0086kÜ\u0013Ý-Iï\u0017Á\u0010[ä\u0082PØ_\u0083\u001cÍa\u008dÿU\u0093öQ\u0010ÎÃÔ ð\u0004ó:ý;Á±4Â/¼\u0010ìd$_\u0087îYFH7 ¾#Z´±\u0010\nMÙ$Rñ\u008c <H´Å£\u0090#-\b\u0017`\u001dC\u0085Ô\u0084¡\b¡?¢«á]¹\u0016\u0010ÊªäÉÑ\u0010%\u0001µL÷ÉÍÔÐk\bfá\u0017\u0098\u0011ñ¥\u0092\u0010}*µñ\fÉ\u000fò\u0016\u009fLßH\tæ»\u0010ìd$_\u0087îYFH7 ¾#Z´±\u0010ä\u0082\u009bó®´1\u0082T\u0096òr\u009c@Ô{\u0010\u007f9ðò\u0087\u0004\u0006n¦;\u00031];ÞM\b8¾\"\u008f¤á¿ø\b>\u0085\u009f6\u0090ö¯\u0098\b-«uä\u0007î<Õ\bÓWkM¢f/\u008d\u0010\u0092¤d\u009c\u0086\u001aWáõÓÛÞ\u009bÌ»\u007f\u0010ÎÃÔ ð\u0004ó:ý;Á±4Â/¼\b¨Ðå²tQè\u0091\b¨Ðå²tQè\u0091\bËR\bl\u008a qI\u00100\"W\u009c\u001c¢\u0086kÜ\u0013Ý-Iï\u0017Á\u0018\u008e]ó\u0096\u0093\u0012X#XØªðÞ\u0018\u001bKozW\u0018Ï¹A{\u0018\nMÙ$Rñ\u008c _?©¡ÂüeGÈ*\u008c8óm¹ \u0010Ç\u0085\u0081¡¤;\u0085\u0087´Þ1aÖS\u008c=\u0010¬/~\u0086!æ%¡£±î0È{Pï\u0010O\u008e\bbÆ\u0004\u008c\u001dwÎæ¥Ñj`¦\bk\u0014#Ú~1\u0002ú\bjÓuåv{Uú\u0018\b\u000bJ~Ä¾\u0011<\u009fÕùù:\\\tðaÐë\u009b¥ëZ\u0002\bÄ\rÎæ±\u0088\u0088¸\u0010`?\u008cÚëê\u0084Ôô\u001f¹ûXKÆß\be\f\u0019þÎ\u0007Õ¤\u0010ÊªäÉÑ\u0010%\u0001µL÷ÉÍÔÐk\bËR\bl\u008a qI\u0010¬/~\u0086!æ%¡£±î0È{Pï\u0010[ä\u0082PØ_\u0083\u001cÍa\u008dÿU\u0093öQ\bÑ;\u009cdKµ\u0091=\u0010ÜXÞÚ§Ìk~\u0018HÜèÈÆÂH\u0010lj6ÓÃ\u009d\u0092\u0094kjÉ!G\u0097Ù0\b5\u0005ÈÚ5+ÛÒ\u0010Mþ>w À\u007fM\u0088ìG\b1\u0001³\u0091\bjÓuåv{Uú\bfá\u0017\u0098\u0011ñ¥\u0092\bk\u0014#Ú~1\u0002ú\u0018\nMÙ$Rñ\u008c _?©¡ÂüeGÈ*\u008c8óm¹ \u0010¯çÓËPF$Ö¼[áJ^Ù\u000bÏ\u0010Ç\u0085\u0081¡¤;\u0085\u0087´Þ1aÖS\u008c=\u0010~Ý\u009frñ\u009f¨o\u0099Ó/Ê\u0006Z\f±\u0010JØ\u0005\u0098ÞPêcÙùÉ\u001cüS\rô".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "0\"W\u009c\u001c¢\u0086k\u001eD\nÛ¶uª?\b>\u0085\u009f6\u0090ö¯\u0098";
                        length = "0\"W\u009c\u001c¢\u0086k\u001eD\nÛ¶uª?\b>\u0085\u009f6\u0090ö¯\u0098".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    static void Vulcan_P(Object[] objArr) throws Exception {
        int iIntValue = ((Integer) objArr[0]).intValue();
        C0043Vulcan_e c0043Vulcan_e = (C0043Vulcan_e) objArr[1];
        int iIntValue2 = ((Integer) objArr[2]).intValue();
        Object obj = (Player) objArr[3];
        Object[] objArr2 = new Object[3];
        ((String) objArr[4])[2] = Long.valueOf(((((((long) iIntValue) << 32) | ((((long) iIntValue2) << 48) >>> 32)) | ((((long) ((Integer) objArr[5]).intValue()) << 48) >>> 48)) ^ a) ^ 19051589289549L);
        objArr2[1] = objArr2;
        objArr2[0] = obj;
        c0043Vulcan_e.Vulcan_D(objArr2);
    }

    private static void lambda$handlePunishment$2(AbstractCheck abstractCheck) {
        abstractCheck.setVl(0);
    }

    public static String spigot() {
        return b[48];
    }

    public static String nonce() {
        return b[47];
    }

    public static String resource() {
        return b[38];
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5, types: [boolean] */
    private void Vulcan_D(Object[] objArr) throws Exception {
        Player player = (Player) objArr[0];
        String str = (String) objArr[1];
        ?? LongValue = a ^ ((Long) objArr[2]).longValue();
        try {
            LongValue = Vulcan_fe.Vulcan_tK;
            if (LongValue == 0) {
                return;
            }
            ByteArrayDataOutput byteArrayDataOutputNewDataOutput = ByteStreams.newDataOutput();
            String[] strArr = b;
            byteArrayDataOutputNewDataOutput.writeUTF(strArr[40]);
            byteArrayDataOutputNewDataOutput.writeUTF(str);
            player.sendPluginMessage(Vulcan_r.INSTANCE.m1084Vulcan_j(), strArr[58], byteArrayDataOutputNewDataOutput.toByteArray());
        } catch (RuntimeException unused) {
            throw a((Exception) LongValue);
        }
    }
}
