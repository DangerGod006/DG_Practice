package me.frep.vulcan.spigot;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_x.class */
final class Vulcan_x {
    public static final Vulcan_x NETHERITE;
    public static final Vulcan_x DIAMOND;
    public static final Vulcan_x GOLD;
    public static final Vulcan_x IRON;
    public static final Vulcan_x STONE;
    public static final Vulcan_x WOOD;
    private final int Vulcan_X;
    private static final Vulcan_x[] Vulcan_V;

    public static Vulcan_x[] values() {
        return (Vulcan_x[]) Vulcan_V.clone();
    }

    public static Vulcan_x valueOf(String str) {
        return (Vulcan_x) Enum.valueOf(Vulcan_x.class, str);
    }

    static int Vulcan_K(Vulcan_x vulcan_x) {
        return vulcan_x.Vulcan_I();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0075, code lost:
    
        if (r0 >= r16) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0078, code lost:
    
        r13 = r14.charAt(r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0097, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x009a, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009e, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a6, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00cc, code lost:
    
        r8 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d1, code lost:
    
        r8 = 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00d6, code lost:
    
        r8 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00db, code lost:
    
        r8 = 53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e0, code lost:
    
        r8 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00e5, code lost:
    
        r8 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00ea, code lost:
    
        r8 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ec, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r18 = r18 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00f4, code lost:
    
        if (r4 != 0) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00f7, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00fc, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0101, code lost:
    
        if (r4 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0105, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0113, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0124, code lost:
    
        me.frep.vulcan.spigot.Vulcan_x.NETHERITE = new me.frep.vulcan.spigot.Vulcan_x(r0[4], 0, 9);
        me.frep.vulcan.spigot.Vulcan_x.DIAMOND = new me.frep.vulcan.spigot.Vulcan_x(r0[2], 1, 8);
        me.frep.vulcan.spigot.Vulcan_x.GOLD = new me.frep.vulcan.spigot.Vulcan_x(r0[1], 2, 12);
        me.frep.vulcan.spigot.Vulcan_x.IRON = new me.frep.vulcan.spigot.Vulcan_x(r0[5], 3, 6);
        me.frep.vulcan.spigot.Vulcan_x.STONE = new me.frep.vulcan.spigot.Vulcan_x(r0[3], 4, 4);
        me.frep.vulcan.spigot.Vulcan_x.WOOD = new me.frep.vulcan.spigot.Vulcan_x(r0[0], 5, 2);
        me.frep.vulcan.spigot.Vulcan_x.Vulcan_V = new me.frep.vulcan.spigot.Vulcan_x[]{me.frep.vulcan.spigot.Vulcan_x.NETHERITE, me.frep.vulcan.spigot.Vulcan_x.DIAMOND, me.frep.vulcan.spigot.Vulcan_x.GOLD, me.frep.vulcan.spigot.Vulcan_x.IRON, me.frep.vulcan.spigot.Vulcan_x.STONE, me.frep.vulcan.spigot.Vulcan_x.WOOD};
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x01ae, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0028, code lost:
    
        r2 = r15;
        r15 = r15 + 1;
        r0[r2] = r3;
        r0 = r12 + r13;
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0039, code lost:
    
        if (r0 >= r16) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0045, code lost:
    
        r14 = "K\u0014V+bYVQ\u0014\u0004L\u0003M-";
        r16 = "K\u0014V+bYVQ\u0014\u0004L\u0003M-".length();
        r13 = '\t';
        r12 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0064, code lost:
    
        r2 = r15;
        r15 = r15 + 1;
        r0[r2] = r3;
        r0 = r12 + r13;
        r12 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x009a, B:28:0x00fc], limit reached: 39 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v18, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v22, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v24, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v26, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v28, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v40 */
    /* JADX WARN: Type inference failed for: r2v41 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v37 */
    /* JADX WARN: Type inference failed for: r3v38 */
    /* JADX WARN: Type inference failed for: r3v39 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v20 */
    /* JADX WARN: Type inference failed for: r4v21 */
    /* JADX WARN: Type inference failed for: r4v23 */
    /* JADX WARN: Type inference failed for: r4v24 */
    /* JADX WARN: Type inference failed for: r4v25 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0101 -> B:15:0x009a). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 431
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_x.m1089clinit():void");
    }

    private Vulcan_x(String str, int i, int i2) {
        this.Vulcan_X = i2;
    }

    private int Vulcan_I() {
        return this.Vulcan_X;
    }
}
