package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_j.class */
public class C0049Vulcan_j {
    private static int Vulcan_D;
    private static final long a = Vulcan_n.a(4124784765171554244L, -143273343898675841L, MethodHandles.lookup().lookupClass()).a(248026059912641L);
    private static final String[] b;

    public static void Vulcan_V(int i) {
        Vulcan_D = i;
    }

    public static int Vulcan_A() {
        return Vulcan_D;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_h() {
        return Vulcan_A() == 0 ? 15 : 0;
    }

    static {
        int i;
        long j = a ^ 122922754274968L;
        Vulcan_V(0);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[24];
        int i3 = 0;
        String str = "íXÅ£ÐË&}\u0096\u001a\u0010²\u001d\u008b\u0080u\u0010Ã]\u0089ñ\u008c\u0007\u0095à\u009eþ/uZZGe\bmñe\u0091Ç7\u0089÷\bèá'¿ó¼\u0086*\u0010Ã]\u0089ñ\u008c\u0007\u0095à\u009eþ/uZZGe\u0010Nqs\n¥Îýº÷5~\u009bº°È\f\u0010Nqs\n¥Îýº÷5~\u009bº°È\f\u0010y:D\u007fæ+\u0002/sm\u0084@9°Þ\u0010\u0010n\u0085V6ÁëwLrV¢\u0092å\u0090£\u009c\u0010Nqs\n¥Îýº=ûÑy¢ÀW\u000b\bèá'¿ó¼\u0086*\bmñe\u0091Ç7\u0089÷\u0010ÏÓy_\u008c01\u000b¥Ä¾\u009fþ¿\u00ade\u0010n\u0085V6ÁëwLrV¢\u0092å\u0090£\u009c\u0010Nqs\n¥Îýº=ûÑy¢ÀW\u000b\b4~\ný\u0017\nâ´\u0010=\u0083\u008d/³ð\u0012¼\u0085Ý\u0089û\u0017C¢\u0013\u0010\u0006\u009a\f\\\u0005i/\t\u0001 ýìû(=Â\u0010\u0006\u009a\f\\\u0005i/\t\u0001 ýìû(=Â\u0010ÏÓy_\u008c01\u000b¥Ä¾\u009fþ¿\u00ade\b[\u0017Ìé*\u0082½t\b4~\ný\u0017\nâ´";
        int length = "íXÅ£ÐË&}\u0096\u001a\u0010²\u001d\u008b\u0080u\u0010Ã]\u0089ñ\u008c\u0007\u0095à\u009eþ/uZZGe\bmñe\u0091Ç7\u0089÷\bèá'¿ó¼\u0086*\u0010Ã]\u0089ñ\u008c\u0007\u0095à\u009eþ/uZZGe\u0010Nqs\n¥Îýº÷5~\u009bº°È\f\u0010Nqs\n¥Îýº÷5~\u009bº°È\f\u0010y:D\u007fæ+\u0002/sm\u0084@9°Þ\u0010\u0010n\u0085V6ÁëwLrV¢\u0092å\u0090£\u009c\u0010Nqs\n¥Îýº=ûÑy¢ÀW\u000b\bèá'¿ó¼\u0086*\bmñe\u0091Ç7\u0089÷\u0010ÏÓy_\u008c01\u000b¥Ä¾\u009fþ¿\u00ade\u0010n\u0085V6ÁëwLrV¢\u0092å\u0090£\u009c\u0010Nqs\n¥Îýº=ûÑy¢ÀW\u000b\b4~\ný\u0017\nâ´\u0010=\u0083\u008d/³ð\u0012¼\u0085Ý\u0089û\u0017C¢\u0013\u0010\u0006\u009a\f\\\u0005i/\t\u0001 ýìû(=Â\u0010\u0006\u009a\f\\\u0005i/\t\u0001 ýìû(=Â\u0010ÏÓy_\u008c01\u000b¥Ä¾\u009fþ¿\u00ade\b[\u0017Ìé*\u0082½t\b4~\ný\u0017\nâ´".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "[\u0017Ìé*\u0082½t\u0010y:D\u007fæ+\u0002/sm\u0084@9°Þ\u0010";
                        length = "[\u0017Ìé*\u0082½t\u0010y:D\u007fæ+\u0002/sm\u0084@9°Þ\u0010".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public static void Vulcan_N(Object[] objArr) {
        Vulcan_r.INSTANCE.Vulcan_v().execute(C0049Vulcan_j::lambda$executeBanWave$4);
    }

    /* JADX WARN: Code restructure failed: missing block: B:50:0x0362, code lost:
    
        r0 = r11;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0342  */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v62, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v63, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v81, types: [me.frep.vulcan.spigot.Vulcan_OK] */
    /* JADX WARN: Type inference failed for: r0v83 */
    /* JADX WARN: Type inference failed for: r0v87 */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v92 */
    /* JADX WARN: Type inference failed for: r0v93 */
    /* JADX WARN: Type inference failed for: r0v94 */
    /* JADX WARN: Type inference failed for: r0v95 */
    /* JADX WARN: Type inference failed for: r0v96 */
    /* JADX WARN: Type inference failed for: r0v97 */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1, types: [int] */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4, types: [int] */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void lambda$executeBanWave$4() throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 921
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0049Vulcan_j.lambda$executeBanWave$4():void");
    }

    private static void lambda$null$1(String str) {
        Vulcan_fe.Vulcan_sN.forEach((v1) -> {
            lambda$null$0(r1, v1);
        });
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    private static void lambda$null$0(String str, String str2) {
        Object[] objArr = new Object[2];
        str2.replaceAll(b[8], str)[1] = Long.valueOf((a ^ 49279406450078L) ^ 140168554941306L);
        objArr[0] = objArr;
        Vulcan_OM.Vulcan_u(objArr);
    }

    private static void lambda$null$2(String str, String str2) {
        Vulcan_OM.Vulcan_Y(str2.replaceAll(b[13], str));
    }

    private static void lambda$null$3(int i, String str) {
        Vulcan_OM.Vulcan_Y(str.replaceAll(b[0], Integer.toString(i)));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v14, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21, types: [boolean, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    public static boolean Vulcan_a(Object[] objArr) throws Exception {
        int iIntValue = ((Integer) objArr[0]).intValue();
        Player player = (Player) objArr[1];
        long jLongValue = ((Long) objArr[2]).longValue();
        long j = ((((long) iIntValue) << 48) | ((jLongValue << 16) >>> 16)) ^ a;
        ?? Vulcan_A = Vulcan_A();
        String[] strArr = b;
        Vulcan_OK vulcan_OK = new Vulcan_OK(strArr[18]);
        try {
            try {
                Vulcan_A = vulcan_OK.Vulcan_B(new Object[0]).getConfigurationSection(strArr[9]);
                ?? configurationSection = Vulcan_A;
                if (Vulcan_A == 0) {
                    if (Vulcan_A == 0) {
                        return false;
                    }
                    configurationSection = vulcan_OK.Vulcan_B(new Object[0]).getConfigurationSection(b[14]);
                }
                ?? it = configurationSection.getKeys(false).iterator();
                try {
                    it = it.hasNext();
                    ?? r0 = it;
                    if (jLongValue >= 0) {
                        r0 = it;
                        if (Vulcan_A == 0) {
                            if (it != 0) {
                                return ((String) it.next()).equalsIgnoreCase(player.getUniqueId().toString());
                            }
                            r0 = 0;
                        }
                    }
                    if (jLongValue > 0) {
                        try {
                            if (AbstractCheck.Vulcan_k() != null) {
                                Vulcan_V(Vulcan_A + 1);
                            }
                        } catch (RuntimeException unused) {
                            throw a((Exception) r0);
                        }
                    }
                    return r0;
                } catch (RuntimeException unused2) {
                    throw a((Exception) it);
                }
            } catch (RuntimeException unused3) {
                Vulcan_A = a((Exception) Vulcan_A);
                throw Vulcan_A;
            }
        } catch (RuntimeException unused4) {
            throw a((Exception) Vulcan_A);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v11, types: [org.bukkit.configuration.ConfigurationSection] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v23, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception, java.lang.Throwable] */
    public static int Vulcan_p(Object[] objArr) throws Exception {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_A = Vulcan_A();
        String[] strArr = b;
        Vulcan_OK vulcan_OK = new Vulcan_OK(strArr[17]);
        int i = 0;
        try {
            try {
                Vulcan_A = vulcan_OK.Vulcan_B(new Object[0]).getConfigurationSection(strArr[14]);
                ?? configurationSection = Vulcan_A;
                if (Vulcan_A == 0) {
                    if (Vulcan_A == 0) {
                        return 0;
                    }
                    configurationSection = vulcan_OK.Vulcan_B(new Object[0]).getConfigurationSection(b[14]);
                }
                Iterator it = configurationSection.getKeys(false).iterator();
                loop0: while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    ?? next = it.next();
                    do {
                        i++;
                        if (Vulcan_A != 0) {
                            next = new AbstractCheck[5];
                        }
                    } while (jLongValue <= 0);
                    AbstractCheck.Vulcan_D((AbstractCheck[]) next);
                    break loop0;
                }
                return i;
            } catch (RuntimeException unused) {
                Vulcan_A = a((Exception) Vulcan_A);
                throw Vulcan_A;
            }
        } catch (RuntimeException unused2) {
            throw a((Exception) Vulcan_A);
        }
    }
}
