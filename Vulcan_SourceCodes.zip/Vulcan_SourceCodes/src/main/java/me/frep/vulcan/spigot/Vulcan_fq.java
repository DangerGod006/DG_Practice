package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fq.class */
public class Vulcan_fq implements Comparable {
    public static final Vulcan_fq Vulcan_Y;
    private final int Vulcan_h;
    private final int Vulcan_U;
    private final int Vulcan_t;
    private static final String Vulcan_J;
    private static String[] Vulcan_L;
    private static final long a = Vulcan_n.a(-6201831161508483782L, -5585043916001912715L, MethodHandles.lookup().lookupClass()).a(89069134082941L);

    public static void Vulcan_E(String[] strArr) {
        Vulcan_L = strArr;
    }

    public static String[] Vulcan_J() {
        return Vulcan_L;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x004e, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0055, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L12;
            case 1: goto L13;
            case 2: goto L14;
            case 3: goto L15;
            case 4: goto L16;
            case 5: goto L17;
            default: goto L18;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007c, code lost:
    
        r8 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0080, code lost:
    
        r8 = 100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0085, code lost:
    
        r8 = 17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x008a, code lost:
    
        r8 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x008f, code lost:
    
        r8 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0094, code lost:
    
        r8 = 10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0099, code lost:
    
        r8 = 72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x009b, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a3, code lost:
    
        if (r4 != 0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00a6, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00ab, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00af, code lost:
    
        if (r4 > r11) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00b3, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00c5, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fq.Vulcan_Y = new me.frep.vulcan.spigot.Vulcan_fq(0, 0, 0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00d2, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x002f, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J = -1;
        r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0048, code lost:
    
        if (r2 <= 1) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x004b, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:9:0x004b, B:22:0x00ab], limit reached: 28 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:23:0x00af -> B:9:0x004b). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 211
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fq.m827clinit():void");
    }

    public Vulcan_fq(int i, int i2, int i3) {
        this.Vulcan_h = i;
        this.Vulcan_U = i2;
        this.Vulcan_t = i3;
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [long] */
    /* JADX WARN: Type inference failed for: r1v8, types: [int] */
    /* JADX WARN: Type inference failed for: r2v10, types: [int] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], long, me.frep.vulcan.spigot.Vulcan_fq] */
    /* JADX WARN: Type inference failed for: r4v8, types: [int, java.lang.Object[], long] */
    /* JADX WARN: Type inference failed for: r5v12, types: [int, java.lang.Object[], long] */
    public Vulcan_fq(double d, double d2, double d3) {
        ?? r1 = (a ^ 104699793852952L) ^ 126109430713387L;
        r1[1] = Double.valueOf(d);
        this[0] = Long.valueOf((long) vulcan_fq);
        ?? Vulcan_Z = Vulcan_Ov.Vulcan_Z((Object[]) vulcan_fq);
        ?? r4 = new Object[2];
        r1[1] = Double.valueOf(d2);
        Vulcan_Z[0] = Long.valueOf((long) r4);
        ?? Vulcan_Z2 = Vulcan_Ov.Vulcan_Z((Object[]) r4);
        ?? r5 = new Object[2];
        r1[1] = Double.valueOf(d3);
        Vulcan_Z2[0] = Long.valueOf((long) r5);
        ?? vulcan_fq = new Vulcan_fq((int) r4, (int) r5, Vulcan_Ov.Vulcan_Z((Object[]) r5));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_fq.a
            r1 = 48502793448710(0x2c1cefc62d06, double:2.39635639703415E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = Vulcan_J()
            r9 = r0
            r0 = r5
            r1 = r9
            if (r1 != 0) goto L25
            r1 = r6
            if (r0 != r1) goto L24
            goto L1e
        L1a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0     // Catch: java.lang.RuntimeException -> L20
        L1e:
            r0 = 1
            return r0
        L20:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L20
            throw r0
        L24:
            r0 = r6
        L25:
            r1 = r9
            if (r1 != 0) goto L3e
            boolean r0 = r0 instanceof me.frep.vulcan.spigot.Vulcan_fq     // Catch: java.lang.RuntimeException -> L33 java.lang.RuntimeException -> L39
            if (r0 != 0) goto L3d
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0     // Catch: java.lang.RuntimeException -> L39
        L37:
            r0 = 0
            return r0
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0
        L3d:
            r0 = r6
        L3e:
            me.frep.vulcan.spigot.Vulcan_fq r0 = (me.frep.vulcan.spigot.Vulcan_fq) r0
            r10 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5f
            int r0 = r0.Vulcan_s(r1)     // Catch: java.lang.RuntimeException -> L5f
            r1 = r10
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L5f
            int r1 = r1.Vulcan_s(r2)     // Catch: java.lang.RuntimeException -> L5f
            r2 = r9
            if (r2 != 0) goto L7c
            if (r0 == r1) goto L6b
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0     // Catch: java.lang.RuntimeException -> L67
        L63:
            r0 = 0
            goto Lb8
        L67:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0
        L6b:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            int r0 = r0.Vulcan_y(r1)
            r1 = r10
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            int r1 = r1.Vulcan_y(r2)
        L7c:
            r2 = r9
            if (r2 != 0) goto Lb0
            if (r0 == r1) goto L93
            goto L8b
        L87:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L8f
            throw r0     // Catch: java.lang.RuntimeException -> L8f
        L8b:
            r0 = 0
            goto Lb8
        L8f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L8f
            throw r0
        L93:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> Lac
            int r0 = r0.Vulcan_L(r1)     // Catch: java.lang.RuntimeException -> Lac
            r1 = r9
            if (r1 != 0) goto Lb4
            r1 = r10
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> Lac
            int r1 = r1.Vulcan_L(r2)     // Catch: java.lang.RuntimeException -> Lac
            goto Lb0
        Lac:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb0:
            if (r0 != r1) goto Lb7
            r0 = 1
        Lb4:
            goto Lb8
        Lb7:
            r0 = 0
        Lb8:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fq.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return ((Vulcan_y(new Object[0]) + (Vulcan_L(new Object[0]) * 31)) * 31) + Vulcan_s(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    public int Vulcan_O(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_J2 = Vulcan_J();
        try {
            try {
                try {
                    try {
                        Vulcan_J2 = Vulcan_y(new Object[0]);
                        int iVulcan_y = vulcan_fq.Vulcan_y(new Object[0]);
                        ?? r0 = Vulcan_J2;
                        if (Vulcan_J2 == 0) {
                            if (Vulcan_J2 == iVulcan_y) {
                                int iVulcan_L = Vulcan_L(new Object[0]);
                                if (j < 0) {
                                    return iVulcan_L;
                                }
                                int iVulcan_L2 = vulcan_fq.Vulcan_L(new Object[0]);
                                if (Vulcan_J2 == 0) {
                                    if (iVulcan_L == iVulcan_L2) {
                                        return Vulcan_s(new Object[0]) - vulcan_fq.Vulcan_s(new Object[0]);
                                    }
                                    iVulcan_L = Vulcan_L(new Object[0]);
                                    iVulcan_L2 = vulcan_fq.Vulcan_L(new Object[0]);
                                }
                                return iVulcan_L - iVulcan_L2;
                            }
                            int iVulcan_y2 = Vulcan_y(new Object[0]);
                            iVulcan_y = vulcan_fq.Vulcan_y(new Object[0]);
                            r0 = iVulcan_y2;
                        }
                        return r0 - iVulcan_y;
                    } catch (RuntimeException unused) {
                        throw a(Vulcan_J2);
                    }
                } catch (RuntimeException unused2) {
                    throw a(Vulcan_J2);
                }
            } catch (RuntimeException unused3) {
                throw a(Vulcan_J2);
            }
        } catch (RuntimeException unused4) {
            throw a(Vulcan_J2);
        }
    }

    public int Vulcan_s(Object[] objArr) {
        return this.Vulcan_h;
    }

    public int Vulcan_y(Object[] objArr) {
        return this.Vulcan_U;
    }

    public int Vulcan_L(Object[] objArr) {
        return this.Vulcan_t;
    }

    public Vulcan_fq Vulcan_H(Object[] objArr) {
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[0];
        return new Vulcan_fq((Vulcan_y(new Object[0]) * vulcan_fq.Vulcan_L(new Object[0])) - (Vulcan_L(new Object[0]) * vulcan_fq.Vulcan_y(new Object[0])), (Vulcan_L(new Object[0]) * vulcan_fq.Vulcan_s(new Object[0])) - (Vulcan_s(new Object[0]) * vulcan_fq.Vulcan_L(new Object[0])), (Vulcan_s(new Object[0]) * vulcan_fq.Vulcan_y(new Object[0])) - (Vulcan_y(new Object[0]) * vulcan_fq.Vulcan_s(new Object[0])));
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public double m828Vulcan_s(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        double dVulcan_s = ((double) Vulcan_s(new Object[0])) - dDoubleValue;
        double dVulcan_y = ((double) Vulcan_y(new Object[0])) - dDoubleValue2;
        double dVulcan_L = ((double) Vulcan_L(new Object[0])) - dDoubleValue3;
        return (dVulcan_s * dVulcan_s) + (dVulcan_y * dVulcan_y) + (dVulcan_L * dVulcan_L);
    }

    public double Vulcan_G(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        double dVulcan_s = (((double) Vulcan_s(new Object[0])) + 0.5d) - dDoubleValue;
        double dVulcan_y = (((double) Vulcan_y(new Object[0])) + 0.5d) - dDoubleValue2;
        double dVulcan_L = (((double) Vulcan_L(new Object[0])) + 0.5d) - dDoubleValue3;
        return (dVulcan_s * dVulcan_s) + (dVulcan_y * dVulcan_y) + (dVulcan_L * dVulcan_L);
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [double] */
    /* JADX WARN: Type inference failed for: r2v4, types: [double] */
    /* JADX WARN: Type inference failed for: r4v3, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fq] */
    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public double m829Vulcan_O(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        ?? Vulcan_f = vulcan_Oa.Vulcan_f(new Object[0]);
        ?? r4 = new Object[3];
        vulcan_Oa.m606Vulcan_R(new Object[0])[2] = Double.valueOf(vulcan_Oa.Vulcan_t(new Object[0]));
        Vulcan_f[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.m828Vulcan_s(r4);
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fq] */
    @Override // java.lang.Comparable
    public int compareTo(Object obj) {
        long j = (a ^ 83899199745783L) ^ 14682944383924L;
        ?? r3 = new Object[2];
        r3[1] = (Vulcan_fq) obj;
        this[0] = Long.valueOf(j);
        return r3.Vulcan_O(r3);
    }
}
