package me.frep.vulcan.spigot;

import org.bukkit.entity.Entity;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_k8.class */
public class Vulcan_k8 {
    private Vulcan_fB Vulcan_H;
    public EnumC0045Vulcan_fc Vulcan_z;
    public Vulcan_kc Vulcan_e;
    public Vulcan_Oa Vulcan_w;
    public Entity Vulcan_I;
    private static final String[] a;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0072, code lost:
    
        if (r0 >= r15) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0075, code lost:
    
        r12 = r13.charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007e, code lost:
    
        me.frep.vulcan.spigot.Vulcan_k8.a = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0096, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0099, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009d, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a5, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00cc, code lost:
    
        r8 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d1, code lost:
    
        r8 = 34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00d6, code lost:
    
        r8 = 103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00db, code lost:
    
        r8 = 66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e0, code lost:
    
        r8 = 12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00e5, code lost:
    
        r8 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00ea, code lost:
    
        r8 = 102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ec, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00f4, code lost:
    
        if (r4 != 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00f7, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00fc, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0101, code lost:
    
        if (r4 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0105, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0113, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0124, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0027, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0037, code lost:
    
        if (r0 >= r15) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0043, code lost:
    
        r13 = "Rn65Ld6vs9\u0013Pg&'\u000b6' \u000bFt(jh1Z";
        r15 = "Rn65Ld6vs9\u0013Pg&'\u000b6' \u000bFt(jh1Z".length();
        r12 = 15;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0062, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x0099, B:28:0x00fc], limit reached: 38 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0101 -> B:15:0x0099). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 293
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_k8.m848clinit():void");
    }

    public Vulcan_k8(Vulcan_Oa vulcan_Oa, Vulcan_kc vulcan_kc, Vulcan_fB vulcan_fB) {
        this(EnumC0045Vulcan_fc.BLOCK, vulcan_Oa, vulcan_kc, vulcan_fB);
    }

    public Vulcan_k8(Vulcan_Oa vulcan_Oa, Vulcan_kc vulcan_kc) {
        this(EnumC0045Vulcan_fc.BLOCK, vulcan_Oa, vulcan_kc, Vulcan_fB.Vulcan_I);
    }

    public Vulcan_k8(Entity entity) {
        this(entity, new Vulcan_Oa(entity.getLocation().getX(), entity.getLocation().getY(), entity.getLocation().getZ()));
    }

    public Vulcan_k8(EnumC0045Vulcan_fc enumC0045Vulcan_fc, Vulcan_Oa vulcan_Oa, Vulcan_kc vulcan_kc, Vulcan_fB vulcan_fB) {
        this.Vulcan_z = enumC0045Vulcan_fc;
        this.Vulcan_H = vulcan_fB;
        this.Vulcan_e = vulcan_kc;
        this.Vulcan_w = new Vulcan_Oa(vulcan_Oa.Vulcan_v, vulcan_Oa.Vulcan_I, vulcan_Oa.Vulcan_h);
    }

    public Vulcan_k8(Entity entity, Vulcan_Oa vulcan_Oa) {
        this.Vulcan_z = EnumC0045Vulcan_fc.ENTITY;
        this.Vulcan_I = entity;
        this.Vulcan_w = vulcan_Oa;
    }

    public Vulcan_fB Vulcan_n(Object[] objArr) {
        return this.Vulcan_H;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String[] strArr = a;
        return sb.append(strArr[3]).append(this.Vulcan_z).append(strArr[4]).append(this.Vulcan_H).append(strArr[2]).append(this.Vulcan_e).append(strArr[1]).append(this.Vulcan_w).append(strArr[0]).append(this.Vulcan_I).append('}').toString();
    }
}
