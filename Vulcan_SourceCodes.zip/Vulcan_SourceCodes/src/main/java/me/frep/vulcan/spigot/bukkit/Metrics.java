package me.frep.vulcan.spigot.bukkit;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.zip.GZIPOutputStream;
import me.frep.vulcan.spigot.Vulcan_m;
import me.frep.vulcan.spigot.Vulcan_n;
import org.apache.commons.lang3.BooleanUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicePriority;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/bukkit/Metrics.class */
public class Metrics {
    public static final int B_STATS_VERSION = 1;
    private static final String URL = "https://bStats.org/submitData/bukkit";
    private boolean enabled;
    private static boolean logFailedRequests;
    private static boolean logSentData;
    private static boolean logResponseStatusText;
    private static String serverUUID;
    private final Plugin plugin;
    private final int pluginId;
    private static final long a;
    private final ThreadFactory threadFactory = Metrics::lambda$new$0;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, this.threadFactory);
    private final List charts = new ArrayList();

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x008e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public com.google.gson.JsonObject getPluginData() {
        /*
            r7 = this;
            long r0 = me.frep.vulcan.spigot.bukkit.Metrics.a
            r1 = 84867269244417(0x4d2fb36fb601, double:4.1930002190026E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 87782572528946(0x4fd6790d9532, double:4.337035339012E-310)
            long r1 = r1 ^ r2
            r10 = r1
            com.google.gson.JsonObject r0 = new com.google.gson.JsonObject
            r1 = r0
            r1.<init>()
            r12 = r0
            r0 = r7
            org.bukkit.plugin.Plugin r0 = r0.plugin
            org.bukkit.plugin.PluginDescriptionFile r0 = r0.getDescription()
            java.lang.String r0 = r0.getName()
            r13 = r0
            r0 = r7
            org.bukkit.plugin.Plugin r0 = r0.plugin
            org.bukkit.plugin.PluginDescriptionFile r0 = r0.getDescription()
            java.lang.String r0 = r0.getVersion()
            r14 = r0
            r0 = r12
            java.lang.String r1 = "pluginName"
            r2 = r13
            r0.addProperty(r1, r2)
            r0 = r12
            java.lang.String r1 = "id"
            r2 = r7
            int r2 = r2.pluginId
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.addProperty(r1, r2)
            r0 = r12
            java.lang.String r1 = "pluginVersion"
            r2 = r14
            r0.addProperty(r1, r2)
            com.google.gson.JsonArray r0 = new com.google.gson.JsonArray
            r1 = r0
            r1.<init>()
            r15 = r0
            r0 = r7
            java.util.List r0 = r0.charts
            java.util.Iterator r0 = r0.iterator()
            r16 = r0
        L6c:
            r0 = r16
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto Lb2
            r0 = r16
            java.lang.Object r0 = r0.next()
            me.frep.vulcan.spigot.bukkit.Vulcan_kX r0 = (me.frep.vulcan.spigot.bukkit.Vulcan_kX) r0
            r17 = r0
            r0 = r10
            r1 = r17
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            com.google.gson.JsonObject r0 = me.frep.vulcan.spigot.bukkit.Vulcan_kX.Vulcan_X(r0)
            r18 = r0
            r0 = r18
            if (r0 != 0) goto La8
            goto L6c
        La4:
            java.lang.Throwable r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> La4
            throw r0
        La8:
            r0 = r15
            r1 = r18
            r0.add(r1)
            goto L6c
        Lb2:
            r0 = r12
            java.lang.String r1 = "customCharts"
            r2 = r15
            r0.add(r1, r2)
            r0 = r12
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.bukkit.Metrics.getPluginData():com.google.gson.JsonObject");
    }

    private static Throwable a(Throwable th) {
        return th;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v21, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Throwable] */
    static {
        ?? A = Vulcan_n.a(-5916530595139766336L, 591246360878733899L, MethodHandles.lookup().lookupClass()).a(26640601252077L);
        a = A;
        try {
            if (System.getProperty("bstats.relocatecheck") != null) {
                A = System.getProperty("bstats.relocatecheck").equals(BooleanUtils.FALSE);
                if (A != 0) {
                    return;
                }
            }
            ?? Equals = "your.package";
            try {
                try {
                    if (!Metrics.class.getPackage().getName().equals("org.bstats.bukkit")) {
                        Equals = Metrics.class.getPackage().getName().equals(Equals);
                        if (Equals == 0) {
                            return;
                        }
                    }
                    throw new IllegalStateException("bStats Metrics class has not been relocated correctly!");
                } catch (IllegalArgumentException unused) {
                    throw a(Equals);
                }
            } catch (IllegalArgumentException unused2) {
                throw a(Equals);
            }
        } catch (IllegalArgumentException unused3) {
            throw a(A);
        }
    }

    private static Thread lambda$new$0(Runnable runnable) {
        return new Thread(runnable, "bStats-Metrics");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v37, types: [me.frep.vulcan.spigot.bukkit.Metrics] */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v55 */
    public Metrics(Plugin plugin, int i) throws Throwable {
        if (plugin == null) {
            throw new IllegalArgumentException("Plugin cannot be null!");
        }
        this.plugin = plugin;
        this.pluginId = i;
        File file = new File(new File(plugin.getDataFolder().getParentFile(), "bStats"), "config.yml");
        YamlConfiguration yamlConfigurationLoadConfiguration = YamlConfiguration.loadConfiguration(file);
        try {
            if (!yamlConfigurationLoadConfiguration.isSet("serverUuid")) {
                yamlConfigurationLoadConfiguration.addDefault("enabled", true);
                yamlConfigurationLoadConfiguration.addDefault("serverUuid", UUID.randomUUID().toString());
                yamlConfigurationLoadConfiguration.addDefault("logFailedRequests", false);
                yamlConfigurationLoadConfiguration.addDefault("logSentData", false);
                yamlConfigurationLoadConfiguration.addDefault("logResponseStatusText", false);
                yamlConfigurationLoadConfiguration.options().header("bStats collects some data for plugin authors like how many servers are using their plugins.\nTo honor their work, you should not disable it.\nThis has nearly no effect on the server performance!\nCheck out https://bStats.org/ to learn more :)").copyDefaults(true);
                try {
                    yamlConfigurationLoadConfiguration = yamlConfigurationLoadConfiguration;
                    yamlConfigurationLoadConfiguration.save(file);
                } catch (IOException e) {
                }
            }
            this.enabled = yamlConfigurationLoadConfiguration.getBoolean("enabled", true);
            serverUUID = yamlConfigurationLoadConfiguration.getString("serverUuid");
            logFailedRequests = yamlConfigurationLoadConfiguration.getBoolean("logFailedRequests", false);
            logSentData = yamlConfigurationLoadConfiguration.getBoolean("logSentData", false);
            logResponseStatusText = yamlConfigurationLoadConfiguration.getBoolean("logResponseStatusText", false);
            if (this.enabled) {
                boolean z = false;
                Iterator it = Bukkit.getServicesManager().getKnownServices().iterator();
                while (true) {
                    boolean zHasNext = it.hasNext();
                    ?? r0 = zHasNext;
                    if (zHasNext) {
                        Class cls = (Class) it.next();
                        try {
                            cls.getField(Vulcan_m.c(cls, "B_STATS_VERSION"));
                            r0 = 1;
                            z = true;
                        } catch (NoSuchFieldException e2) {
                        }
                    }
                    try {
                        Bukkit.getServicesManager().register(Metrics.class, this, plugin, ServicePriority.Normal);
                        if (!z) {
                            r0 = this;
                            r0.startSubmitting();
                            return;
                        }
                        return;
                    } catch (IOException unused) {
                        throw a(r0);
                    }
                }
            }
        } catch (NoSuchFieldException unused2) {
            throw a(yamlConfigurationLoadConfiguration);
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    public void addCustomChart(Vulcan_kX vulcan_kX) throws Throwable {
        ?? illegalArgumentException = vulcan_kX;
        if (illegalArgumentException == 0) {
            try {
                illegalArgumentException = new IllegalArgumentException("Chart cannot be null!");
                throw illegalArgumentException;
            } catch (IllegalArgumentException unused) {
                throw a(illegalArgumentException);
            }
        } else {
            this.charts.add(vulcan_kX);
        }
    }

    private void startSubmitting() {
        Runnable runnable = this::lambda$startSubmitting$1;
        long jRandom = (long) (60000.0d * (3.0d + (Math.random() * 3.0d)));
        long jRandom2 = (long) (60000.0d * Math.random() * 30.0d);
        this.scheduler.schedule(runnable, jRandom, TimeUnit.MILLISECONDS);
        this.scheduler.scheduleAtFixedRate(runnable, jRandom + jRandom2, 1800000L, TimeUnit.MILLISECONDS);
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Throwable, java.util.concurrent.ScheduledExecutorService] */
    private void lambda$startSubmitting$1() throws Throwable {
        ?? r0;
        try {
            if (!this.plugin.isEnabled()) {
                r0 = this.scheduler;
                r0.shutdown();
            } else {
                Bukkit.getScheduler().runTask(this.plugin, this::submitData);
            }
        } catch (IllegalArgumentException unused) {
            throw a(r0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.reflect.Method] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v5, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v50, types: [int] */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v2 */
    private JsonObject getServerData() throws Throwable {
        ?? r5;
        ?? onlineMode;
        ?? length;
        try {
            ?? method = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers", new Class[0]);
            try {
                if (method.getReturnType().equals(Collection.class)) {
                    method = ((Collection) method.invoke(Bukkit.getServer(), new Object[0])).size();
                    length = method;
                } else {
                    length = ((Player[]) method.invoke(Bukkit.getServer(), new Object[0])).length;
                }
                r5 = length;
                onlineMode = length;
            } catch (Exception unused) {
                throw a(method);
            }
        } catch (Exception e) {
            int size = Bukkit.getOnlinePlayers().size();
            r5 = size;
            onlineMode = size;
        }
        try {
            onlineMode = Bukkit.getOnlineMode();
            int i = onlineMode != 0 ? 1 : 0;
            String version = Bukkit.getVersion();
            String name = Bukkit.getName();
            String property = System.getProperty("java.version");
            String property2 = System.getProperty("os.name");
            String property3 = System.getProperty("os.arch");
            String property4 = System.getProperty("os.version");
            int iAvailableProcessors = Runtime.getRuntime().availableProcessors();
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("serverUUID", serverUUID);
            jsonObject.addProperty("playerAmount", Integer.valueOf(r5 == true ? 1 : 0));
            jsonObject.addProperty("onlineMode", Integer.valueOf(i));
            jsonObject.addProperty("bukkitVersion", version);
            jsonObject.addProperty("bukkitName", name);
            jsonObject.addProperty("javaVersion", property);
            jsonObject.addProperty("osName", property2);
            jsonObject.addProperty("osArch", property3);
            jsonObject.addProperty("osVersion", property4);
            jsonObject.addProperty("coreCount", Integer.valueOf(iAvailableProcessors));
            return jsonObject;
        } catch (Exception unused2) {
            throw a(onlineMode);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v34, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v36, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v44, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.reflect.Method] */
    private void submitData() throws Throwable {
        JsonObject serverData = getServerData();
        JsonArray jsonArray = new JsonArray();
        for (Class cls : Bukkit.getServicesManager().getKnownServices()) {
            try {
                cls.getField(Vulcan_m.c(cls, "B_STATS_VERSION"));
                for (RegisteredServiceProvider registeredServiceProvider : Bukkit.getServicesManager().getRegistrations(cls)) {
                    try {
                        Class service = registeredServiceProvider.getService();
                        Class<?>[] clsArr = new Class[0];
                        ?? Invoke = service.getMethod(Vulcan_m.b("getPluginData", service, clsArr), clsArr).invoke(registeredServiceProvider.getProvider(), new Object[0]);
                        try {
                            Invoke = Invoke instanceof JsonObject;
                            if (Invoke != 0) {
                                jsonArray.add((JsonObject) Invoke);
                            } else {
                                try {
                                    Class<?> cls2 = Class.forName("org.json.simple.JSONObject");
                                    Invoke = Invoke.getClass().isAssignableFrom(cls2);
                                    if (Invoke != 0) {
                                        ?? declaredMethod = cls2.getDeclaredMethod("toJSONString", new Class[0]);
                                        declaredMethod.setAccessible(true);
                                        jsonArray.add(new JsonParser().parse((String) declaredMethod.invoke(Invoke, new Object[0])).getAsJsonObject());
                                    }
                                } catch (ClassNotFoundException e) {
                                    try {
                                        Invoke = logFailedRequests;
                                        if (Invoke != 0) {
                                            this.plugin.getLogger().log(Level.SEVERE, "Encountered unexpected exception", (Throwable) e);
                                        }
                                    } catch (ClassNotFoundException unused) {
                                        throw a(Invoke);
                                    }
                                }
                            }
                        } catch (ClassNotFoundException unused2) {
                            throw a(Invoke);
                        }
                    } catch (IllegalAccessException | NoSuchMethodException | NullPointerException | InvocationTargetException e2) {
                    }
                }
            } catch (NoSuchFieldException e3) {
            }
        }
        serverData.add("plugins", jsonArray);
        new Thread(() -> {
            r2.lambda$submitData$2(r3);
        }).start();
    }

    private void lambda$submitData$2(JsonObject jsonObject) throws Throwable {
        Plugin logger;
        try {
            logger = this.plugin;
            sendData(logger, jsonObject);
        } catch (Exception e) {
            try {
                if (logFailedRequests) {
                    logger = this.plugin.getLogger();
                    logger.log(Level.WARNING, "Could not submit plugin stats of " + this.plugin.getName(), e);
                }
            } catch (Exception unused) {
                throw a(logger);
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:37:0x0108
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static void sendData(org.bukkit.plugin.Plugin r6, com.google.gson.JsonObject r7) throws java.io.IOException {
        /*
            Method dump skipped, instruction units count: 499
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.bukkit.Metrics.sendData(org.bukkit.plugin.Plugin, com.google.gson.JsonObject):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private static byte[] compress(String str) {
        if (str == null) {
            return null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
        Throwable th = null;
        try {
            gZIPOutputStream.write(str.getBytes(StandardCharsets.UTF_8));
            if (gZIPOutputStream != null) {
                if (0 != 0) {
                    try {
                        gZIPOutputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                } else {
                    gZIPOutputStream.close();
                }
            }
            return byteArrayOutputStream.toByteArray();
        } catch (Throwable th3) {
            if (gZIPOutputStream != null) {
                if (0 != 0) {
                    try {
                        gZIPOutputStream.close();
                    } catch (Throwable th4) {
                        th.addSuppressed(th4);
                        throw th3;
                    }
                } else {
                    gZIPOutputStream.close();
                }
            }
            throw th3;
        }
    }
}
