package me.frep.vulcan.spigot.check.impl.combat.reach;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0039Vulcan_Oo;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Location;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/reach/ReachA.class */
@CheckInfo(name = "Reach", type = 'A', complexType = "History", description = "Hit from too far away.")
public class ReachA extends AbstractCheck {
    private boolean Vulcan_I;
    private static final long b = Vulcan_n.a(-183650999251607748L, -8312681155402968789L, MethodHandles.lookup().lookupClass()).a(131037403407795L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0455: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 1515
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.reach.ReachA.Vulcan_T(java.lang.Object[]):void");
    }

    static {
        long j = b ^ 64853634820134L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = "\f\u00136¤é\u009aã~\b\"n \u0007WÅì_\u0010\u0011\u0090¦f#Ñ{\u009f\u0013ÂÛùëjO~".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = b(cipher.doFinal("\f\u00136¤é\u009aã~\b\"n \u0007WÅì_\u0010\u0011\u0090¦f#Ñ{\u009f\u0013ÂÛùëjO~".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                d = strArr;
                return;
            }
            cCharAt = "\f\u00136¤é\u009aã~\b\"n \u0007WÅì_\u0010\u0011\u0090¦f#Ñ{\u009f\u0013ÂÛùëjO~".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public ReachA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        this.Vulcan_I = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static boolean lambda$handle$0(int i, int i2, C0039Vulcan_Oo c0039Vulcan_Oo) {
        long j = b ^ 112898769584594L;
        ?? Vulcan_y = ReachB.Vulcan_y();
        try {
            try {
                Vulcan_y = Math.abs((i - ((Integer) c0039Vulcan_Oo.Vulcan_m(new Object[0])).intValue()) - i2);
                return Vulcan_y == 0 ? Vulcan_y < 3 : Vulcan_y;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_y);
            }
        } catch (RuntimeException unused2) {
            Vulcan_y = a((RuntimeException) Vulcan_y);
            throw Vulcan_y;
        }
    }

    private static double lambda$handle$1(Vector vector, C0039Vulcan_Oo c0039Vulcan_Oo) {
        return vector.distance(((Location) c0039Vulcan_Oo.Vulcan_C(new Object[0])).toVector().setY(0)) - 0.52d;
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
