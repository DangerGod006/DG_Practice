package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oq.class */
public class Vulcan_Oq {
    public static String spigot() {
        return "1815274";
    }

    public static String nonce() {
        return "1569903669";
    }

    public static String resource() {
        return "83626";
    }
}
