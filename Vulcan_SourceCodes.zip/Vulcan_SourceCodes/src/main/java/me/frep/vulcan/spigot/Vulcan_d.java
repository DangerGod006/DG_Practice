package me.frep.vulcan.spigot;

import org.bukkit.entity.Entity;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_d.class */
public class Vulcan_d {
    private Vulcan_fB Vulcan_u;
    public Vulcan_kO Vulcan_T;
    public Vulcan_kc Vulcan_p;
    public Vulcan_O Vulcan_o;
    public Entity Vulcan_F;
    private static final String[] a;

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0071, code lost:
    
        if (r0 >= r15) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0074, code lost:
    
        r12 = r13.charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007d, code lost:
    
        me.frep.vulcan.spigot.Vulcan_d.a = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0095, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0098, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009c, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a4, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00cc, code lost:
    
        r8 = 41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d1, code lost:
    
        r8 = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00d6, code lost:
    
        r8 = 41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00db, code lost:
    
        r8 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e0, code lost:
    
        r8 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00e5, code lost:
    
        r8 = 98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00ea, code lost:
    
        r8 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ec, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00f4, code lost:
    
        if (r4 != 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00f7, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00fc, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0101, code lost:
    
        if (r4 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0105, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0113, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0124, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0027, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0037, code lost:
    
        if (r0 >= r15) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0043, code lost:
    
        r13 = "/\u0005e3\u000fKLw\\F;FoQxzZ8V>";
        r15 = "/\u0005e3\u000fKLw\\F;FoQxzZ8V>".length();
        r12 = 4;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0061, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x0098, B:28:0x00fc], limit reached: 38 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0101 -> B:15:0x0098). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 293
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_d.m658clinit():void");
    }

    public Vulcan_d(Vulcan_O vulcan_O, Vulcan_kc vulcan_kc, Vulcan_fB vulcan_fB) {
        this(Vulcan_kO.BLOCK, vulcan_O, vulcan_kc, vulcan_fB);
    }

    public Vulcan_d(Vulcan_O vulcan_O, Vulcan_kc vulcan_kc) {
        this(Vulcan_kO.BLOCK, vulcan_O, vulcan_kc, Vulcan_fB.Vulcan_I);
    }

    public Vulcan_d(Entity entity) {
        this(entity, new Vulcan_O(entity.getLocation().getX(), entity.getLocation().getY(), entity.getLocation().getZ()));
    }

    public Vulcan_d(Vulcan_kO vulcan_kO, Vulcan_O vulcan_O, Vulcan_kc vulcan_kc, Vulcan_fB vulcan_fB) {
        this.Vulcan_T = vulcan_kO;
        this.Vulcan_u = vulcan_fB;
        this.Vulcan_p = vulcan_kc;
        this.Vulcan_o = new Vulcan_O(vulcan_O.Vulcan_p(new Object[0]), vulcan_O.Vulcan_s(new Object[0]), vulcan_O.Vulcan_Y(new Object[0]));
    }

    public Vulcan_d(Entity entity, Vulcan_O vulcan_O) {
        this.Vulcan_T = Vulcan_kO.ENTITY;
        this.Vulcan_F = entity;
        this.Vulcan_o = vulcan_O;
    }

    public Vulcan_fB Vulcan_r(Object[] objArr) {
        return this.Vulcan_u;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String[] strArr = a;
        return sb.append(strArr[4]).append(this.Vulcan_T).append(strArr[0]).append(this.Vulcan_u).append(strArr[3]).append(this.Vulcan_p).append(strArr[2]).append(this.Vulcan_o).append(strArr[1]).append(this.Vulcan_F).append('}').toString();
    }
}
