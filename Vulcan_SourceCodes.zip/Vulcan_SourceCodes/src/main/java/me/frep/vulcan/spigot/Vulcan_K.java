package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_K.class */
public class Vulcan_K {
    private final C0042Vulcan_Oz Vulcan_y;
    private final Deque Vulcan_G = new ConcurrentLinkedDeque();
    private final Deque Vulcan_J = new ConcurrentLinkedDeque();
    private short Vulcan_I = -32348;
    private short Vulcan_x = -69;
    private short Vulcan_B = -69;
    private long Vulcan_p = 0;
    private long Vulcan_K = -1;
    private long Vulcan_e = -1;
    private long Vulcan_o = System.currentTimeMillis();
    private long Vulcan_m = Long.MAX_VALUE;
    private int Vulcan_f = -42069;
    private static final long a = Vulcan_n.a(3521124871528123944L, -3688376149565672035L, MethodHandles.lookup().lookupClass()).a(182556131829976L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0144: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_G(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 1239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_K.Vulcan_G(java.lang.Object[]):void");
    }

    static {
        int i;
        long j = a ^ 16218697033833L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[19];
        int i3 = 0;
        String str = "\u0091zË\u0095\u0094m*f}Lìê\u0087~!w\b9\u0099*\u000bêÝÿ¯\b9\u0099*\u000bêÝÿ¯\bQÔaÜ/,µþ\u0018â]K\u001a9Q\\Õº\u001b&Ù¿dUMÚ\u0003N¥JxÃe\u0010Û\u0089o$\u0098a¨(%\u0088Ô\nU)Ì.\bÚÉÈCL\u008eþØ\u0010Û\u0089o$\u0098a¨(%\u0088Ô\nU)Ì.\u0018â]K\u001a9Q\\Õ#\u0016ëÒ]Zñ}§M\u0010o¶¡øÏ\bÚÉÈCL\u008eþØ\bÜø\u0087\u0086¨º\u0002\u0082\u0010\u0091zË\u0095\u0094m*f}Lìê\u0087~!w(»DY\u008c:nè6°\u008fQ\u0097!â¤&ýuû\u001c¶\u0089¦\u0081\u0003®hPpÞþ\u0081\u009fêFVÕL\u00956\bQÔaÜ/,µþ\u0010\u0007\u0092´Û Lõ]4Mõº6©\r\u0097\bÜø\u0087\u0086¨º\u0002\u0082\u0018»DY\u008c:nè6°Ö\tùV¤ÊÀ_¿Ùâ\u0002\u008aÓS";
        int length = "\u0091zË\u0095\u0094m*f}Lìê\u0087~!w\b9\u0099*\u000bêÝÿ¯\b9\u0099*\u000bêÝÿ¯\bQÔaÜ/,µþ\u0018â]K\u001a9Q\\Õº\u001b&Ù¿dUMÚ\u0003N¥JxÃe\u0010Û\u0089o$\u0098a¨(%\u0088Ô\nU)Ì.\bÚÉÈCL\u008eþØ\u0010Û\u0089o$\u0098a¨(%\u0088Ô\nU)Ì.\u0018â]K\u001a9Q\\Õ#\u0016ëÒ]Zñ}§M\u0010o¶¡øÏ\bÚÉÈCL\u008eþØ\bÜø\u0087\u0086¨º\u0002\u0082\u0010\u0091zË\u0095\u0094m*f}Lìê\u0087~!w(»DY\u008c:nè6°\u008fQ\u0097!â¤&ýuû\u001c¶\u0089¦\u0081\u0003®hPpÞþ\u0081\u009fêFVÕL\u00956\bQÔaÜ/,µþ\u0010\u0007\u0092´Û Lõ]4Mõº6©\r\u0097\bÜø\u0087\u0086¨º\u0002\u0082\u0018»DY\u008c:nè6°Ö\tùV¤ÊÀ_¿Ùâ\u0002\u008aÓS".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = ",8®f»6YK\u0018è\u009e9\u0003Å¸:\"a \u0001è\u0081X§\u0010lGR4Ò\u009cçß";
                        length = ",8®f»6YK\u0018è\u009e9\u0003Å¸:\"a \u0001è\u0081X§\u0010lGR4Ò\u009cçß".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [int, short] */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public void m583Vulcan_v(Object[] objArr) {
        this.Vulcan_I = ((Integer) objArr[0]).intValue();
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [int, short] */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public void m584Vulcan_l(Object[] objArr) {
        this.Vulcan_x = ((Integer) objArr[0]).intValue();
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [int, short] */
    public void Vulcan_D(Object[] objArr) {
        this.Vulcan_B = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Y(Object[] objArr) {
        this.Vulcan_p = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_K(Object[] objArr) {
        this.Vulcan_K = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_B(Object[] objArr) {
        this.Vulcan_e = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_A(Object[] objArr) {
        this.Vulcan_o = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_P(Object[] objArr) {
        this.Vulcan_m = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_a(Object[] objArr) {
        this.Vulcan_f = ((Integer) objArr[0]).intValue();
    }

    public C0042Vulcan_Oz Vulcan_p(Object[] objArr) {
        return this.Vulcan_y;
    }

    public Deque Vulcan_v(Object[] objArr) {
        return this.Vulcan_G;
    }

    public Deque Vulcan_j(Object[] objArr) {
        return this.Vulcan_J;
    }

    public short Vulcan_f(Object[] objArr) {
        return this.Vulcan_I;
    }

    public short Vulcan__(Object[] objArr) {
        return this.Vulcan_x;
    }

    public short Vulcan_n(Object[] objArr) {
        return this.Vulcan_B;
    }

    public long Vulcan_m(Object[] objArr) {
        return this.Vulcan_p;
    }

    public long Vulcan_l(Object[] objArr) {
        return this.Vulcan_K;
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public long m581Vulcan_o(Object[] objArr) {
        return this.Vulcan_e;
    }

    public long Vulcan_k(Object[] objArr) {
        return this.Vulcan_o;
    }

    public long Vulcan_H(Object[] objArr) {
        return this.Vulcan_m;
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public int m582Vulcan_v(Object[] objArr) {
        return this.Vulcan_f;
    }

    public Vulcan_K(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_y = c0042Vulcan_Oz;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public void Vulcan_o(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Runnable runnable = (Runnable) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        Vulcan_OU vulcan_OU = (Vulcan_OU) this.Vulcan_G.peekLast();
        try {
            Vulcan_OU vulcan_OU2 = vulcan_OU;
            if (Vulcan_T != 0) {
                if (vulcan_OU2 == null) {
                    runnable.run();
                    return;
                }
                vulcan_OU2 = vulcan_OU;
            }
            vulcan_OU2.Vulcan_p(new Object[0]).add(runnable);
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    public void Vulcan_h(Object[] objArr) {
        this.Vulcan_J.add((Runnable) objArr[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object, me.frep.vulcan.spigot.Vulcan_OU] */
    public void Vulcan_q(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            Vulcan_T = this.Vulcan_y.Vulcan_u(new Object[0]);
            if (Vulcan_T == 0) {
                return;
            }
            ?? vulcan_OU = new Vulcan_OU(iIntValue, System.currentTimeMillis());
            try {
                vulcan_OU = (j > 0L ? 1 : (j == 0L ? 0 : -1));
                if (vulcan_OU >= 0) {
                    try {
                        vulcan_OU = this.Vulcan_J.isEmpty();
                        if (Vulcan_T != 0) {
                            if (vulcan_OU == 0) {
                                Deque deque = this.Vulcan_J;
                                vulcan_OU.getClass();
                                deque.forEach(vulcan_OU::Vulcan_I);
                                this.Vulcan_J.clear();
                            }
                            this.Vulcan_G.add(vulcan_OU);
                        }
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) vulcan_OU);
                    }
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) vulcan_OU);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:91:0x0207, code lost:
    
        if (r0 > 0) goto L119;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0318 A[PHI: r0 r1
  0x0318: PHI (r0v75 ??) = (r0v124 ??), (r0v125 ??) binds: [B:98:0x02ce, B:115:0x0314] A[DONT_GENERATE, DONT_INLINE]
  0x0318: PHI (r1v41 ??) = (r1v102 ??), (r1v103 ??) binds: [B:98:0x02ce, B:115:0x0314] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:133:0x02ab A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:137:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x01cf  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x02d1  */
    /* JADX WARN: Type inference failed for: r0v100, types: [int] */
    /* JADX WARN: Type inference failed for: r0v108, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v109 */
    /* JADX WARN: Type inference failed for: r0v114, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v124 */
    /* JADX WARN: Type inference failed for: r0v125 */
    /* JADX WARN: Type inference failed for: r0v126 */
    /* JADX WARN: Type inference failed for: r0v127 */
    /* JADX WARN: Type inference failed for: r0v128 */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v131 */
    /* JADX WARN: Type inference failed for: r0v132 */
    /* JADX WARN: Type inference failed for: r0v133 */
    /* JADX WARN: Type inference failed for: r0v134 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException, me.frep.vulcan.spigot.Vulcan_OU] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v29, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v44, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v57, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v65, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v69, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v71, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v75, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v80, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v94, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v97, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v102 */
    /* JADX WARN: Type inference failed for: r1v103 */
    /* JADX WARN: Type inference failed for: r1v104 */
    /* JADX WARN: Type inference failed for: r1v105 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v35 */
    /* JADX WARN: Type inference failed for: r1v36 */
    /* JADX WARN: Type inference failed for: r1v40 */
    /* JADX WARN: Type inference failed for: r1v41, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v85 */
    /* JADX WARN: Type inference failed for: r2v56, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v83, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$ArrayArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_d(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 859
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_K.Vulcan_d(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$receivingPong$0() {
        long j = (a ^ 48247108832967L) ^ 130579424399154L;
        Player playerVulcan_e = this.Vulcan_y.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_sp[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$receivingPong$1() {
        long j = (a ^ 81756593368592L) ^ 25808245157861L;
        Player playerVulcan_e = this.Vulcan_y.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_Ml[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$handleFlying$2() {
        long j = (a ^ 44186180386869L) ^ 128696118297024L;
        Player playerVulcan_e = this.Vulcan_y.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_ME[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$handleFlying$3() {
        long j = (a ^ 82297706814802L) ^ 26366509112487L;
        Player playerVulcan_e = this.Vulcan_y.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_bf[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.String] */
    private void Vulcan_g(Object[] objArr) {
        long jLongValue = (a ^ ((Long) objArr[0]).longValue()) ^ 39210040809817L;
        StringBuilder sb = new StringBuilder();
        String[] strArr = b;
        Object[] objArr2 = new Object[2];
        sb.append(strArr[18]).append(this.Vulcan_G.size()).append(strArr[17]).append((String) this.Vulcan_G.stream().map(Vulcan_K::lambda$sendDebugMessage$4).collect(Collectors.joining(strArr[9]))).toString()[1] = Long.valueOf(jLongValue);
        objArr2[0] = objArr2;
        Vulcan_OM.Vulcan_X(objArr2);
        Object[] objArr3 = new Object[2];
        (strArr[12] + (System.currentTimeMillis() - this.Vulcan_o))[1] = Long.valueOf(jLongValue);
        objArr3[0] = objArr3;
        Vulcan_OM.Vulcan_X(objArr3);
        Object[] objArr4 = new Object[2];
        (strArr[16] + (System.currentTimeMillis() - this.Vulcan_y.getJoinTime()))[1] = Long.valueOf(jLongValue);
        objArr4[0] = objArr4;
        Vulcan_OM.Vulcan_X(objArr4);
        Object[] objArr5 = new Object[2];
        (strArr[8] + this.Vulcan_f)[1] = Long.valueOf(jLongValue);
        objArr5[0] = objArr5;
        Vulcan_OM.Vulcan_X(objArr5);
        Object[] objArr6 = new Object[2];
        (strArr[4] + ((String) this.Vulcan_y.Vulcan_R(new Object[0]).stream().map((v0) -> {
            return String.valueOf(v0);
        }).collect(Collectors.joining(strArr[6]))))[1] = Long.valueOf(jLongValue);
        objArr6[0] = objArr6;
        Vulcan_OM.Vulcan_X(objArr6);
        Object[] objArr7 = new Object[2];
        (strArr[14] + ((String) this.Vulcan_y.Vulcan_g(new Object[0]).stream().map((v0) -> {
            return String.valueOf(v0);
        }).collect(Collectors.joining(strArr[6]))))[1] = Long.valueOf(jLongValue);
        objArr7[0] = objArr7;
        Vulcan_OM.Vulcan_X(objArr7);
    }

    private static String lambda$sendDebugMessage$4(Vulcan_OU vulcan_OU) {
        return String.valueOf(vulcan_OU.Vulcan_G(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00ba A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Runnable, java.lang.RuntimeException, void] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Runnable] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_L(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_K.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_ka.Vulcan_T()
            r11 = r0
            r0 = r6
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_y     // Catch: java.lang.RuntimeException -> L38
            r1 = r11
            if (r1 == 0) goto L53
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L38 java.lang.RuntimeException -> L45
            boolean r0 = r0.Vulcan_u(r1)     // Catch: java.lang.RuntimeException -> L38 java.lang.RuntimeException -> L45
            if (r0 == 0) goto L63
            goto L3c
        L38:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L45
            throw r0     // Catch: java.lang.RuntimeException -> L45
        L3c:
            r0 = r6
            r1 = r11
            if (r1 == 0) goto L69
            goto L49
        L45:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4f
            throw r0     // Catch: java.lang.RuntimeException -> L4f
        L49:
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_y     // Catch: java.lang.RuntimeException -> L4f
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L53:
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L64
            com.github.retrooper.packetevents.protocol.player.User r0 = r0.Vulcan_V(r1)     // Catch: java.lang.RuntimeException -> L64
            com.github.retrooper.packetevents.protocol.ConnectionState r0 = r0.getEncoderState()     // Catch: java.lang.RuntimeException -> L64
            com.github.retrooper.packetevents.protocol.ConnectionState r1 = com.github.retrooper.packetevents.protocol.ConnectionState.PLAY     // Catch: java.lang.RuntimeException -> L64
            if (r0 == r1) goto L68
        L63:
            return
        L64:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L64
            throw r0
        L68:
            r0 = r6
        L69:
            void r0 = r0::lambda$sendConfirmation$5
            r12 = r0
            r0 = r11
            r1 = r8
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto La9
            if (r0 == 0) goto La1
            r0 = r10
            if (r0 == 0) goto Lac
            goto L87
        L83:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L9d
            throw r0     // Catch: java.lang.RuntimeException -> L9d
        L87:
            r0 = r6
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_y     // Catch: java.lang.RuntimeException -> L9d
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L9d
            com.github.retrooper.packetevents.protocol.player.User r0 = r0.Vulcan_V(r1)     // Catch: java.lang.RuntimeException -> L9d
            java.lang.Object r0 = r0.getChannel()     // Catch: java.lang.RuntimeException -> L9d
            r1 = r12
            com.github.retrooper.packetevents.netty.channel.ChannelHelper.runInEventLoop(r0, r1)     // Catch: java.lang.RuntimeException -> L9d
            goto La1
        L9d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        La1:
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto Lb3
            r0 = r11
        La9:
            if (r0 != 0) goto Lba
        Lac:
            r0 = r12
            r0.run()     // Catch: java.lang.RuntimeException -> Lb6
        Lb3:
            goto Lba
        Lb6:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lba:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_K.Vulcan_L(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [int, short] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v5, types: [int, java.lang.Object[]] */
    private void lambda$sendConfirmation$5() {
        long j = a ^ 22903271922237L;
        long j2 = j ^ 97482760040622L;
        ?? r2 = new Object[1];
        this[0] = Long.valueOf(j ^ 79244343945812L);
        ?? Vulcan_R = r2.Vulcan_R(r2);
        ?? r3 = new Object[2];
        Vulcan_R[1] = Long.valueOf(j2);
        r3[0] = Integer.valueOf((int) r3);
        Vulcan_t(r3);
        this.Vulcan_x = (short) Vulcan_R;
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0042  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_t(java.lang.Object[] r7) {
        /*
            r6 = this;
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_K.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_ka.Vulcan_T()
            r11 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_r(r0)
            if (r0 == 0) goto L42
            com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing r0 = new com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing
            r1 = r0
            r2 = r10
            r1.<init>(r2)
            r12 = r0
            r0 = r8
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L60
            r0 = r11
            if (r0 != 0) goto L50
        L42:
            com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation r0 = new com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation
            r1 = r0
            r2 = 0
            r3 = r10
            short r3 = (short) r3
            r4 = 0
            r1.<init>(r2, r3, r4)
            r12 = r0
        L50:
            r0 = r6
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_y
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            com.github.retrooper.packetevents.protocol.player.User r0 = r0.Vulcan_V(r1)
            r1 = r12
            r0.sendPacket(r1)
        L60:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_K.Vulcan_t(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [short] */
    public short Vulcan_R(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        this.Vulcan_I = (short) (this.Vulcan_I + 1);
        try {
            try {
                Vulcan_T = this.Vulcan_I;
                if (Vulcan_T == 0) {
                    return Vulcan_T;
                }
                if (Vulcan_T > -420) {
                    this.Vulcan_I = (short) -32348;
                }
                return this.Vulcan_I;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_T);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_T);
        }
    }
}
