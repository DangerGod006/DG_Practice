package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.block.BlockFace;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_O.class */
public class Vulcan_O {
    private final double Vulcan_x;
    private final double Vulcan_T;
    private final double Vulcan_z;
    private static String[] Vulcan_Z;
    private static final long a = Vulcan_n.a(3325479826782545986L, 9165027052000939550L, MethodHandles.lookup().lookupClass()).a(144632242352979L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public me.frep.vulcan.spigot.Vulcan_O Vulcan__(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_O.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r11
            double r0 = r0.Vulcan_x
            r1 = r11
            double r1 = r1.Vulcan_x
            double r0 = r0 * r1
            r1 = r11
            double r1 = r1.Vulcan_T
            r2 = r11
            double r2 = r2.Vulcan_T
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r11
            double r1 = r1.Vulcan_z
            r2 = r11
            double r2 = r2.Vulcan_z
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            r15 = r0
            r0 = r15
            r1 = 4547007122018943789(0x3f1a36e2eb1c432d, double:1.0E-4)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L5c
            me.frep.vulcan.spigot.Vulcan_O r0 = new me.frep.vulcan.spigot.Vulcan_O     // Catch: java.lang.RuntimeException -> L58
            r1 = r0
            r2 = 0
            r3 = 0
            r4 = 0
            r1.<init>(r2, r3, r4)     // Catch: java.lang.RuntimeException -> L58
            goto L78
        L58:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L58
            throw r0
        L5c:
            me.frep.vulcan.spigot.Vulcan_O r0 = new me.frep.vulcan.spigot.Vulcan_O
            r1 = r0
            r2 = r11
            double r2 = r2.Vulcan_x
            r3 = r15
            double r2 = r2 / r3
            r3 = r11
            double r3 = r3.Vulcan_T
            r4 = r15
            double r3 = r3 / r4
            r4 = r11
            double r4 = r4.Vulcan_z
            r5 = r15
            double r4 = r4 / r5
            r1.<init>(r2, r3, r4)
        L78:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan__(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_O");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public double Vulcan_v(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_O r1 = (me.frep.vulcan.spigot.Vulcan_O) r1
            r9 = r1
            r0 = r9
            double r0 = r0.Vulcan_x
            r1 = r7
            double r1 = r1.Vulcan_x
            double r0 = r0 - r1
            r10 = r0
            r0 = r9
            double r0 = r0.Vulcan_T
            r1 = r7
            double r1 = r1.Vulcan_T
            double r0 = r0 - r1
            r12 = r0
            r0 = r9
            double r0 = r0.Vulcan_z
            r1 = r7
            double r1 = r1.Vulcan_z
            double r0 = r0 - r1
            r14 = r0
            r0 = r10
            r1 = r10
            double r0 = r0 * r1
            r1 = r12
            r2 = r12
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r14
            r2 = r14
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_v(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public double Vulcan_u(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_O r1 = (me.frep.vulcan.spigot.Vulcan_O) r1
            r9 = r1
            r0 = r9
            double r0 = r0.Vulcan_x
            r1 = r7
            double r1 = r1.Vulcan_x
            double r0 = r0 - r1
            r10 = r0
            r0 = r9
            double r0 = r0.Vulcan_z
            r1 = r7
            double r1 = r1.Vulcan_z
            double r0 = r0 - r1
            r12 = r0
            r0 = r10
            r1 = r10
            double r0 = r0 * r1
            r1 = r12
            r2 = r12
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_u(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0023: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public double Vulcan_S(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r0 = r7
            double r0 = r0.Vulcan_x
            r1 = r7
            double r1 = r1.Vulcan_x
            double r0 = r0 * r1
            r1 = r7
            double r1 = r1.Vulcan_T
            r2 = r7
            double r2 = r2.Vulcan_T
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r7
            double r1 = r1.Vulcan_z
            r2 = r7
            double r2 = r2.Vulcan_z
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_S(java.lang.Object[]):double");
    }

    /*  JADX ERROR: Failed to decode insn: 0x004F: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public int Vulcan_V(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r0 = r12
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r11
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r10
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 32
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = me.frep.vulcan.spigot.Vulcan_O.a
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 122349360112669(0x6f46ae25e41d, double:6.0448615622329E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r8
            double r0 = r0.Vulcan_x
            r1 = r15
            // decode failed: arraycopy: source index -1 out of bounds for object array[8]
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_Z(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_V(java.lang.Object[]):int");
    }

    /*  JADX ERROR: Failed to decode insn: 0x0021: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public int Vulcan_E(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_O.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 139012748058936(0x7e6e6d77a138, double:6.86814231499047E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r8
            double r0 = r0.Vulcan_T
            r1 = r12
            // decode failed: arraycopy: source index -1 out of bounds for object array[8]
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_Z(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_E(java.lang.Object[]):int");
    }

    /*  JADX ERROR: Failed to decode insn: 0x004F: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public int Vulcan_Q(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r0 = r11
            long r0 = (long) r0
            r1 = 48
            long r0 = r0 << r1
            r1 = r12
            long r1 = (long) r1
            r2 = 32
            long r1 = r1 << r2
            r2 = 16
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            r1 = r10
            long r1 = (long) r1
            r2 = 48
            long r1 = r1 << r2
            r2 = 48
            long r1 = r1 >>> r2
            long r0 = r0 | r1
            long r1 = me.frep.vulcan.spigot.Vulcan_O.a
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r13
            r1 = r0; r1 = r0; 
            r2 = 91613457440180(0x53526b965db4, double:4.5263062017932E-310)
            long r1 = r1 ^ r2
            r15 = r1
            r0 = r8
            double r0 = r0.Vulcan_z
            r1 = r15
            // decode failed: arraycopy: source index -1 out of bounds for object array[8]
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_Z(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_Q(java.lang.Object[]):int");
    }

    public static void Vulcan_H(String[] strArr) {
        Vulcan_Z = strArr;
    }

    public static String[] Vulcan_A() {
        return Vulcan_Z;
    }

    static {
        long j = a ^ 117375290765439L;
        Vulcan_H(null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = "Oè7\u0082Óãx\u000f\u0010h\u0004\u0085\u0012\u009apkZ\t\bsu\u0015!\u009c\u0095\b^\u001f\u0098Øãè\u0016!".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("Oè7\u0082Óãx\u000f\u0010h\u0004\u0085\u0012\u009apkZ\t\bsu\u0015!\u009c\u0095\b^\u001f\u0098Øãè\u0016!".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                return;
            }
            cCharAt = "Oè7\u0082Óãx\u000f\u0010h\u0004\u0085\u0012\u009apkZ\t\bsu\u0015!\u009c\u0095\b^\u001f\u0098Øãè\u0016!".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public double Vulcan_p(Object[] objArr) {
        return this.Vulcan_x;
    }

    public double Vulcan_s(Object[] objArr) {
        return this.Vulcan_T;
    }

    public double Vulcan_Y(Object[] objArr) {
        return this.Vulcan_z;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_O(double r6, double r8, double r10) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_O.a
            r1 = 133456784383827(0x7960d439df53, double:6.59364123684915E-310)
            long r0 = r0 ^ r1
            r12 = r0
            java.lang.String[] r0 = Vulcan_A()
            r1 = r5
            r1.<init>()
            r14 = r0
            r0 = r6
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 != 0) goto L2d
            if (r0 != 0) goto L28
            goto L26
        L22:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L26:
            r0 = 0
            r6 = r0
        L28:
            r0 = r8
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L2d:
            r1 = r14
            if (r1 != 0) goto L50
            if (r0 != 0) goto L3e
            goto L3c
        L38:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3c:
            r0 = 0
            r8 = r0
        L3e:
            r0 = r10
            r1 = r14
            if (r1 != 0) goto L54
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            if (r0 != 0) goto L56
            r0 = 0
        L54:
            r10 = r0
        L56:
            r0 = r5
            r1 = r6
            r0.Vulcan_x = r1
            r0 = r5
            r1 = r8
            r0.Vulcan_T = r1
            r0 = r5
            r1 = r10
            r0.Vulcan_z = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.<init>(double, double, double):void");
    }

    public Vulcan_O(Vulcan_O vulcan_O) {
        this(vulcan_O.Vulcan_p(new Object[0]), vulcan_O.Vulcan_s(new Object[0]), vulcan_O.Vulcan_Y(new Object[0]));
    }

    public Vulcan_O(Vector vector) {
        this(vector.getX(), vector.getY(), vector.getZ());
    }

    public Vulcan_O Vulcan_j(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        return new Vulcan_O(vulcan_O.Vulcan_x - this.Vulcan_x, vulcan_O.Vulcan_T - this.Vulcan_T, vulcan_O.Vulcan_z - this.Vulcan_z);
    }

    public double Vulcan_r(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        return (this.Vulcan_x * vulcan_O.Vulcan_x) + (this.Vulcan_T * vulcan_O.Vulcan_T) + (this.Vulcan_z * vulcan_O.Vulcan_z);
    }

    public Vulcan_O Vulcan_y(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        return new Vulcan_O((this.Vulcan_T * vulcan_O.Vulcan_z) - (this.Vulcan_z * vulcan_O.Vulcan_T), (this.Vulcan_z * vulcan_O.Vulcan_x) - (this.Vulcan_x * vulcan_O.Vulcan_z), (this.Vulcan_x * vulcan_O.Vulcan_T) - (this.Vulcan_T * vulcan_O.Vulcan_x));
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [double] */
    /* JADX WARN: Type inference failed for: r2v2, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O] */
    public Vulcan_O Vulcan_b(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        ?? r1 = vulcan_O.Vulcan_x;
        ?? r4 = new Object[3];
        vulcan_O.Vulcan_T[2] = Double.valueOf(vulcan_O.Vulcan_z);
        r1[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_h(r4);
    }

    /* JADX WARN: Type inference failed for: r1v13, types: [double] */
    /* JADX WARN: Type inference failed for: r2v4, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O] */
    public Vulcan_O Vulcan_h(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        ?? r4 = new Object[3];
        (-((Double) objArr[1]).doubleValue())[2] = Double.valueOf(-((Double) objArr[2]).doubleValue());
        (-dDoubleValue)[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_G(r4);
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [double] */
    /* JADX WARN: Type inference failed for: r2v2, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O] */
    public Vulcan_O Vulcan_n(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        ?? r1 = vulcan_O.Vulcan_x;
        ?? r4 = new Object[3];
        vulcan_O.Vulcan_T[2] = Double.valueOf(vulcan_O.Vulcan_z);
        r1[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_G(r4);
    }

    public Vulcan_O Vulcan_G(Object[] objArr) {
        return new Vulcan_O(this.Vulcan_x + ((Double) objArr[0]).doubleValue(), this.Vulcan_T + ((Double) objArr[1]).doubleValue(), this.Vulcan_z + ((Double) objArr[2]).doubleValue());
    }

    public double Vulcan_J(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        double d = vulcan_O.Vulcan_x - this.Vulcan_x;
        double d2 = vulcan_O.Vulcan_T - this.Vulcan_T;
        double d3 = vulcan_O.Vulcan_z - this.Vulcan_z;
        return (d * d) + (d2 * d2) + (d3 * d3);
    }

    public double Vulcan_C(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        double d = vulcan_O.Vulcan_x - this.Vulcan_x;
        double d2 = vulcan_O.Vulcan_z - this.Vulcan_z;
        return (d * d) + (d2 * d2);
    }

    public double Vulcan_D(Object[] objArr) {
        return ((Vulcan_O) objArr[0]).Vulcan_T - this.Vulcan_T;
    }

    public double Vulcan_w(Object[] objArr) {
        return (this.Vulcan_x * this.Vulcan_x) + (this.Vulcan_T * this.Vulcan_T) + (this.Vulcan_z * this.Vulcan_z);
    }

    public double Vulcan_A(Object[] objArr) {
        return (this.Vulcan_x * this.Vulcan_x) + (this.Vulcan_z * this.Vulcan_z);
    }

    public Vulcan_O Vulcan_I(Object[] objArr) {
        BlockFace blockFace = (BlockFace) objArr[0];
        return new Vulcan_O(this.Vulcan_x + ((double) blockFace.getModX()), this.Vulcan_T + ((double) blockFace.getModY()), this.Vulcan_z + ((double) blockFace.getModZ()));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_O Vulcan_i(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_i(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_O");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_O Vulcan_m(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.Vulcan_m(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_O");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public me.frep.vulcan.spigot.Vulcan_O m586Vulcan_A(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O.m586Vulcan_A(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_O");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [double] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [me.frep.vulcan.spigot.Vulcan_O] */
    public Vulcan_O Vulcan_e(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        float fVulcan_Q = Vulcan_Ov.Vulcan_Q(new Object[]{Float.valueOf(fFloatValue)});
        Vulcan_A();
        float fVulcan_G = Vulcan_Ov.Vulcan_G(new Object[]{Float.valueOf(fFloatValue)});
        double d = this.Vulcan_x;
        double d2 = (this.Vulcan_T * ((double) fVulcan_Q)) + (this.Vulcan_z * ((double) fVulcan_G));
        ?? vulcan_O = (this.Vulcan_z * ((double) fVulcan_Q)) - (this.Vulcan_T * ((double) fVulcan_G));
        try {
            vulcan_O = new Vulcan_O(d, d2, vulcan_O);
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_H(new String[4]);
            }
            return vulcan_O;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) vulcan_O);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v16, types: [double] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [me.frep.vulcan.spigot.Vulcan_O] */
    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public Vulcan_O m587Vulcan_J(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        float fFloatValue = ((Float) objArr[1]).floatValue();
        long j = a ^ jLongValue;
        String[] strArrVulcan_A = Vulcan_A();
        float fVulcan_Q = Vulcan_Ov.Vulcan_Q(new Object[]{Float.valueOf(fFloatValue)});
        float fVulcan_G = Vulcan_Ov.Vulcan_G(new Object[]{Float.valueOf(fFloatValue)});
        double d = (this.Vulcan_x * ((double) fVulcan_Q)) + (this.Vulcan_z * ((double) fVulcan_G));
        double d2 = this.Vulcan_T;
        ?? vulcan_O = (this.Vulcan_z * ((double) fVulcan_Q)) - (this.Vulcan_x * ((double) fVulcan_G));
        try {
            vulcan_O = new Vulcan_O(d, d2, vulcan_O);
            if (strArrVulcan_A != null) {
                AbstractCheck.Vulcan_D(new AbstractCheck[3]);
            }
            return vulcan_O;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) vulcan_O);
        }
    }

    public Vector Vulcan_a(Object[] objArr) {
        return new Vector(this.Vulcan_x, this.Vulcan_T, this.Vulcan_z);
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O] */
    public Vulcan_O Vulcan_l(Object[] objArr) {
        ?? DoubleValue = ((Double) objArr[0]).doubleValue();
        ?? r4 = new Object[3];
        DoubleValue[2] = Double.valueOf((double) DoubleValue);
        DoubleValue[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.m588Vulcan_Q(r4);
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public Vulcan_O m588Vulcan_Q(Object[] objArr) {
        return new Vulcan_O(this.Vulcan_x * ((Double) objArr[0]).doubleValue(), this.Vulcan_T * ((Double) objArr[1]).doubleValue(), this.Vulcan_z * ((Double) objArr[2]).doubleValue());
    }

    public double Vulcan_N(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        return (this.Vulcan_x * vulcan_O.Vulcan_x) + (this.Vulcan_T * vulcan_O.Vulcan_T) + (this.Vulcan_z * vulcan_O.Vulcan_z);
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public float m589Vulcan_n(Object[] objArr) {
        Vulcan_O vulcan_O = (Vulcan_O) objArr[0];
        return (float) Math.acos(Vulcan_N(new Object[]{vulcan_O}) / (Vulcan_S(new Object[0]) * vulcan_O.Vulcan_S(new Object[0])));
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String[] strArr = b;
        return sb.append(strArr[1]).append(this.Vulcan_x).append(strArr[0]).append(this.Vulcan_T).append(strArr[2]).append(this.Vulcan_z).append('}').toString();
    }
}
