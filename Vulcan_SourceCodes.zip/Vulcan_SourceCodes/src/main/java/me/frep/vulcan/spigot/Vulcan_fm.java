package me.frep.vulcan.spigot;

import java.util.List;
import java.util.Map;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.Material;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fm.class */
public final class Vulcan_fm {
    public static final double Vulcan_y = 0.41999998688697815d;
    public static final List Vulcan_C;
    public static final Map Vulcan_v;
    public static final Map Vulcan_t;
    public static final Map Vulcan_r;
    public static final Map Vulcan_S;
    private static AbstractCheck[] Vulcan_w;
    private static final String[] a;

    public static void Vulcan_Y(AbstractCheck[] abstractCheckArr) {
        Vulcan_w = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_i() {
        return Vulcan_w;
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private Vulcan_fm() {
        throw new UnsupportedOperationException(a[97]);
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x09ed, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[7]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x09f0, code lost:
    
        r24 = 13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x09f7, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x0a05, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[170(0xaa, float:2.38E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x0a08, code lost:
    
        r24 = 14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x0a0f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x0a1c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[9]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x0a1f, code lost:
    
        r24 = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:108:0x0a26, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:109:0x0a33, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[90]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x007b, code lost:
    
        if (r0 >= r15) goto L526;
     */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x0a36, code lost:
    
        r24 = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x0a3d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:112:0x0a4b, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[149(0x95, float:2.09E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x0a4e, code lost:
    
        r24 = 17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0a55, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0a63, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[162(0xa2, float:2.27E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:116:0x0a66, code lost:
    
        r24 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0a6d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x0a7a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[8]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x0a7d, code lost:
    
        r24 = 19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x007e, code lost:
    
        r12 = r13.charAt(r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x0a84, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x0a91, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[54]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x0a94, code lost:
    
        r24 = 20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x0a9b, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:124:0x0aa8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[52]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x0aab, code lost:
    
        r24 = 21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x0ab2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:127:0x0ac0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[182(0xb6, float:2.55E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:128:0x0ac3, code lost:
    
        r24 = 22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:129:0x0aca, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0087, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.a = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:130:0x0ad7, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[47]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:131:0x0ada, code lost:
    
        r24 = 23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:132:0x0ae1, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:133:0x0aee, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[100]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:134:0x0af1, code lost:
    
        r24 = 24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:135:0x0af8, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:136:0x0b05, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[109(0x6d, float:1.53E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:137:0x0b08, code lost:
    
        r24 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:138:0x0b0f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x0b1c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[42]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:140:0x0b1f, code lost:
    
        r24 = 26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:141:0x0b26, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:142:0x0b33, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[81]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:0x0b36, code lost:
    
        r24 = 27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:144:0x0b3d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:145:0x0b4b, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[183(0xb7, float:2.56E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:146:0x0b4e, code lost:
    
        r24 = 28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:147:0x0b55, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x0b62, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[22]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:149:0x0b65, code lost:
    
        r24 = 29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x009f, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x0b6c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:151:0x0b7a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[179(0xb3, float:2.51E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:152:0x0b7d, code lost:
    
        r24 = 30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:153:0x0b84, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:154:0x0b91, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[93]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:155:0x0b94, code lost:
    
        r24 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:156:0x0b9b, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x0ba8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[33]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:158:0x0bab, code lost:
    
        r24 = 32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:159:0x0bb2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00a2, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:160:0x0bbf, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[58]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x0bc2, code lost:
    
        r24 = 33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:162:0x0bc9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:163:0x0bd6, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[113(0x71, float:1.58E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:164:0x0bd9, code lost:
    
        r24 = 34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:165:0x0be0, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:166:0x0bed, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[17]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:167:0x0bf0, code lost:
    
        r24 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:168:0x0bf7, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:169:0x0c05, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[184(0xb8, float:2.58E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a6, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:170:0x0c08, code lost:
    
        r24 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:171:0x0c0f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:172:0x0c1d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[175(0xaf, float:2.45E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:173:0x0c20, code lost:
    
        r24 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:174:0x0c27, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:175:0x0c35, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[173(0xad, float:2.42E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:176:0x0c38, code lost:
    
        r24 = 38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x0c3f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:178:0x0c4c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[107(0x6b, float:1.5E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:179:0x0c4f, code lost:
    
        r24 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ae, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:180:0x0c56, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:181:0x0c63, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[80]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:182:0x0c66, code lost:
    
        r24 = 40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:183:0x0c6d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:184:0x0c7a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[71]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:185:0x0c7d, code lost:
    
        r24 = 41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:186:0x0c84, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:187:0x0c92, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[129(0x81, float:1.81E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:188:0x0c95, code lost:
    
        r24 = 42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:189:0x0c9c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00d4, code lost:
    
        r8 = 104;
     */
    /* JADX WARN: Code restructure failed: missing block: B:190:0x0ca9, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[68]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:191:0x0cac, code lost:
    
        r24 = 43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:192:0x0cb3, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:193:0x0cc0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[69]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:194:0x0cc3, code lost:
    
        r24 = 44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:195:0x0cca, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:196:0x0cd7, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[46]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:197:0x0cda, code lost:
    
        r24 = 45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:198:0x0ce1, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:199:0x0cee, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[57]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d9, code lost:
    
        r8 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:200:0x0cf1, code lost:
    
        r24 = 46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:201:0x0cf8, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:202:0x0d05, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[62]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:203:0x0d08, code lost:
    
        r24 = 47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:204:0x0d0f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:205:0x0d1c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[72]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:206:0x0d1f, code lost:
    
        r24 = 48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:207:0x0d26, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:208:0x0d34, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[145(0x91, float:2.03E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:209:0x0d37, code lost:
    
        r24 = 49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00de, code lost:
    
        r8 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:210:0x0d3e, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:211:0x0d4b, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[48]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:212:0x0d4e, code lost:
    
        r24 = 50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:213:0x0d55, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:214:0x0d62, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[79]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:215:0x0d65, code lost:
    
        r24 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:216:0x0d6c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:217:0x0d79, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[23]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:218:0x0d7c, code lost:
    
        r24 = 52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:219:0x0d83, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00e3, code lost:
    
        r8 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:220:0x0d90, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[15]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:221:0x0d93, code lost:
    
        r24 = 53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:222:0x0d9a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:223:0x0da8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[174(0xae, float:2.44E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:224:0x0dab, code lost:
    
        r24 = 54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:225:0x0db2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:226:0x0dbf, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[103(0x67, float:1.44E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:227:0x0dc2, code lost:
    
        r24 = 55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:228:0x0dc9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:229:0x0dd5, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[3]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e8, code lost:
    
        r8 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:230:0x0dd8, code lost:
    
        r24 = 56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:231:0x0ddf, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:232:0x0dec, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[96]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:233:0x0def, code lost:
    
        r24 = 57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:234:0x0df6, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:235:0x0e03, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[124(0x7c, float:1.74E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:236:0x0e06, code lost:
    
        r24 = 58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:237:0x0e0d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:238:0x0e1a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[105(0x69, float:1.47E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:239:0x0e1d, code lost:
    
        r24 = 59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00ed, code lost:
    
        r8 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:240:0x0e24, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:241:0x0e32, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[152(0x98, float:2.13E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:242:0x0e35, code lost:
    
        r24 = 60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:243:0x0e3c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:244:0x0e4a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[131(0x83, float:1.84E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:245:0x0e4d, code lost:
    
        r24 = 61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:246:0x0e54, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:247:0x0e61, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[6]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:248:0x0e64, code lost:
    
        r24 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:249:0x0e6b, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00f2, code lost:
    
        r8 = 64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:250:0x0e79, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[139(0x8b, float:1.95E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:251:0x0e7c, code lost:
    
        r24 = 63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:252:0x0e83, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:253:0x0e90, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[73]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:254:0x0e93, code lost:
    
        r24 = 64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:255:0x0e9a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:256:0x0ea7, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[67]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:257:0x0eaa, code lost:
    
        r24 = 65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:258:0x0eb1, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:259:0x0ebf, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[166(0xa6, float:2.33E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00f4, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:260:0x0ec2, code lost:
    
        r24 = 66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:261:0x0ec9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:262:0x0ed7, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[177(0xb1, float:2.48E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:263:0x0eda, code lost:
    
        r24 = 67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:264:0x0ee1, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:265:0x0eef, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[176(0xb0, float:2.47E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:266:0x0ef2, code lost:
    
        r24 = 68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:267:0x0ef9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:268:0x0f07, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[138(0x8a, float:1.93E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:269:0x0f0a, code lost:
    
        r24 = 69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00fc, code lost:
    
        if (r4 != 0) goto L530;
     */
    /* JADX WARN: Code restructure failed: missing block: B:270:0x0f11, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:271:0x0f1e, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[74]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:272:0x0f21, code lost:
    
        r24 = 70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:273:0x0f28, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:274:0x0f35, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[34]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:275:0x0f38, code lost:
    
        r24 = 71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:276:0x0f3f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:277:0x0f4c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[125(0x7d, float:1.75E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:278:0x0f4f, code lost:
    
        r24 = 72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:279:0x0f56, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00ff, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:280:0x0f63, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[30]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:281:0x0f66, code lost:
    
        r24 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:282:0x0f6d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:283:0x0f7a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[53]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:284:0x0f7d, code lost:
    
        r24 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:285:0x0f84, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:286:0x0f92, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[159(0x9f, float:2.23E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:287:0x0f95, code lost:
    
        r24 = 75;
     */
    /* JADX WARN: Code restructure failed: missing block: B:288:0x0f9c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:289:0x0fa9, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[92]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0104, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:290:0x0fac, code lost:
    
        r24 = 76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:291:0x0fb3, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:292:0x0fc0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[40]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:293:0x0fc3, code lost:
    
        r24 = 77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:294:0x0fca, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:295:0x0fd7, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[98]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:296:0x0fda, code lost:
    
        r24 = 78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:297:0x0fe1, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:298:0x0fee, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[24]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:299:0x0ff1, code lost:
    
        r24 = 79;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0109, code lost:
    
        if (r4 > r17) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:300:0x0ff8, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:301:0x1006, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[160(0xa0, float:2.24E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:302:0x1009, code lost:
    
        r24 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:303:0x1010, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:304:0x101d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[49]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:305:0x1020, code lost:
    
        r24 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:306:0x1027, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:307:0x1034, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[70]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:308:0x1037, code lost:
    
        r24 = 82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:309:0x103e, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x010d, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:310:0x104c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[150(0x96, float:2.1E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:311:0x104f, code lost:
    
        r24 = 83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:312:0x1056, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:313:0x1063, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[44]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:314:0x1066, code lost:
    
        r24 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:315:0x106d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:316:0x107a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[118(0x76, float:1.65E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:317:0x107d, code lost:
    
        r24 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:318:0x1084, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:319:0x1091, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[106(0x6a, float:1.49E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x011b, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:320:0x1094, code lost:
    
        r24 = 86;
     */
    /* JADX WARN: Code restructure failed: missing block: B:321:0x109b, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:322:0x10a8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[43]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:323:0x10ab, code lost:
    
        r24 = 87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:324:0x10b2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:325:0x10c0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[135(0x87, float:1.89E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:326:0x10c3, code lost:
    
        r24 = 88;
     */
    /* JADX WARN: Code restructure failed: missing block: B:327:0x10ca, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:328:0x10d6, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[1]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:329:0x10d9, code lost:
    
        r24 = 89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x012c, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C = new java.util.ArrayList();
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v = new java.util.HashMap();
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t = new java.util.HashMap();
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r = new java.util.HashMap();
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S = new java.util.HashMap();
        r0 = (org.bukkit.Material[]) java.util.Arrays.stream(org.bukkit.Material.values()).filter((v0) -> { // java.util.function.Predicate.test(java.lang.Object):boolean
            return v0.isBlock();
        }).filter((v0) -> { // java.util.function.Predicate.test(java.lang.Object):boolean
            return v0.isSolid();
        }).toArray(me.frep.vulcan.spigot.Vulcan_fm::lambda$static$0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:330:0x10e0, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:331:0x10ed, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[20]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:332:0x10f0, code lost:
    
        r24 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:333:0x10f7, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:334:0x1104, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[116(0x74, float:1.63E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:335:0x1107, code lost:
    
        r24 = 91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:336:0x110e, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:337:0x111c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[134(0x86, float:1.88E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:338:0x111f, code lost:
    
        r24 = 92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:339:0x1126, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x018e, code lost:
    
        if (me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(new java.lang.Object[0]) == false) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:340:0x1132, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[0]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:341:0x1135, code lost:
    
        r24 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:342:0x113c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:343:0x1149, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[55]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:344:0x114c, code lost:
    
        r24 = 94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:345:0x1153, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:346:0x1160, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[104(0x68, float:1.46E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:347:0x1163, code lost:
    
        r24 = 95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:348:0x116a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:349:0x1177, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[94]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0191, code lost:
    
        r0 = new java.util.ArrayList();
        r1 = me.frep.vulcan.spigot.Vulcan_fm.a;
        r0.add(r1[126(0x7e, float:1.77E-43)]);
        r0.add(r1[181(0xb5, float:2.54E-43)]);
        r0.add(r1[167(0xa7, float:2.34E-43)]);
        r0.add(r1[50]);
        r0.add(r1[108(0x6c, float:1.51E-43)]);
        r0.add(r1[133(0x85, float:1.86E-43)]);
        r0.add(r1[13]);
        r0.add(r1[146(0x92, float:2.05E-43)]);
        r0.add(r1[21]);
        r0.add(r1[164(0xa4, float:2.3E-43)]);
        r0.add(r1[142(0x8e, float:1.99E-43)]);
        r0.add(r1[171(0xab, float:2.4E-43)]);
        r0.add(r1[158(0x9e, float:2.21E-43)]);
        r0.add(r1[31]);
        r0.add(r1[78]);
        r0.add(r1[38]);
        r0.add(r1[121(0x79, float:1.7E-43)]);
        r0.add(r1[45]);
        r0.add(r1[137(0x89, float:1.92E-43)]);
        r0.add(r1[99]);
        r0.add(r1[112(0x70, float:1.57E-43)]);
        r0.add(r1[161(0xa1, float:2.26E-43)]);
        r0.add(r1[32]);
        r0.add(r1[11]);
        r0.add(r1[148(0x94, float:2.07E-43)]);
        r0.add(r1[9]);
        r0.add(r1[91]);
        r0.add(r1[144(0x90, float:2.02E-43)]);
        r0.add(r1[25]);
        r0.add(r1[155(0x9b, float:2.17E-43)]);
        r0.add(r1[154(0x9a, float:2.16E-43)]);
        r0.add(r1[75]);
        r0.add(r1[132(0x84, float:1.85E-43)]);
        r0.add(r1[76]);
        r0.add(r1[123(0x7b, float:1.72E-43)]);
        r0.add(r1[5]);
        r0.add(r1[165(0xa5, float:2.31E-43)]);
        r0.add(r1[29]);
        r0.add(r1[19]);
        r0.add(r1[37]);
        r0 = r0.length;
        r22 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:350:0x117a, code lost:
    
        r24 = 96;
     */
    /* JADX WARN: Code restructure failed: missing block: B:351:0x1181, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:352:0x118d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[2]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:353:0x1190, code lost:
    
        r24 = 97;
     */
    /* JADX WARN: Code restructure failed: missing block: B:354:0x1197, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:355:0x11a3, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[4]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:356:0x11a6, code lost:
    
        r24 = 98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:357:0x11ad, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:358:0x11ba, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[117(0x75, float:1.64E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:359:0x11bd, code lost:
    
        r24 = 99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:360:0x11c4, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:361:0x11d2, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[143(0x8f, float:2.0E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:362:0x11d5, code lost:
    
        r24 = 100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:363:0x11dc, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:364:0x11ea, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[147(0x93, float:2.06E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:365:0x11ed, code lost:
    
        r24 = 101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:366:0x11f4, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:367:0x1202, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[140(0x8c, float:1.96E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:368:0x1205, code lost:
    
        r24 = 102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:369:0x120c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x039d, code lost:
    
        if (r22 >= r0) goto L531;
     */
    /* JADX WARN: Code restructure failed: missing block: B:370:0x1219, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[26]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:371:0x121c, code lost:
    
        r24 = 103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:372:0x1223, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:373:0x1230, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[56]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:374:0x1233, code lost:
    
        r24 = 104;
     */
    /* JADX WARN: Code restructure failed: missing block: B:375:0x123a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:376:0x1247, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[95]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:377:0x124a, code lost:
    
        r24 = 105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:378:0x1251, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:379:0x125f, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[168(0xa8, float:2.35E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x03a0, code lost:
    
        r0 = r0[r22];
     */
    /* JADX WARN: Code restructure failed: missing block: B:380:0x1262, code lost:
    
        r24 = 106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:381:0x1269, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:382:0x1276, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[63]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:383:0x1279, code lost:
    
        r24 = 107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:384:0x1280, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:385:0x128d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[16]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:386:0x1290, code lost:
    
        r24 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:387:0x1297, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:388:0x12a4, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[127(0x7f, float:1.78E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:389:0x12a7, code lost:
    
        r24 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x03a7, code lost:
    
        r0 = (r0.getHardness() > 0.5d ? 1 : (r0.getHardness() == 0.5d ? 0 : -1));
     */
    /* JADX WARN: Code restructure failed: missing block: B:390:0x12ae, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:391:0x12bc, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[180(0xb4, float:2.52E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:392:0x12bf, code lost:
    
        r24 = 110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:393:0x12c6, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:394:0x12d3, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[85]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:395:0x12d6, code lost:
    
        r24 = 111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:396:0x12dd, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:397:0x12eb, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[130(0x82, float:1.82E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:398:0x12ee, code lost:
    
        r24 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:399:0x12f5, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x03b1, code lost:
    
        if (r0 < 0) goto L533;
     */
    /* JADX WARN: Code restructure failed: missing block: B:400:0x1302, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[114(0x72, float:1.6E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:401:0x1305, code lost:
    
        r24 = 113;
     */
    /* JADX WARN: Code restructure failed: missing block: B:402:0x130c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:403:0x1319, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[36]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:404:0x131c, code lost:
    
        r24 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:405:0x1323, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:406:0x1330, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[59]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:407:0x1333, code lost:
    
        r24 = 115;
     */
    /* JADX WARN: Code restructure failed: missing block: B:408:0x133a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:409:0x1347, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[101(0x65, float:1.42E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:410:0x134a, code lost:
    
        r24 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:411:0x1351, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:412:0x135e, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[83]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:413:0x1361, code lost:
    
        r24 = 117;
     */
    /* JADX WARN: Code restructure failed: missing block: B:414:0x1368, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:415:0x1375, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[111(0x6f, float:1.56E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:416:0x1378, code lost:
    
        r24 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:417:0x137f, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:418:0x138c, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[51]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:419:0x138f, code lost:
    
        r24 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x03c0, code lost:
    
        if (r0.contains(r0.name()) == false) goto L48;
     */
    /* JADX WARN: Code restructure failed: missing block: B:420:0x1396, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:421:0x13a3, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[39]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:422:0x13a6, code lost:
    
        r24 = 120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:423:0x13ad, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:424:0x13bb, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[163(0xa3, float:2.28E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:425:0x13be, code lost:
    
        r24 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:426:0x13c5, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:427:0x13d2, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[60]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:428:0x13d5, code lost:
    
        r24 = 122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:429:0x13dc, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:430:0x13e9, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[87]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:431:0x13ec, code lost:
    
        r24 = 123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:432:0x13f3, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:433:0x1400, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[88]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:434:0x1403, code lost:
    
        r24 = 124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:435:0x140a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:436:0x1418, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[141(0x8d, float:1.98E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:437:0x141b, code lost:
    
        r24 = 125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:438:0x1422, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:439:0x142f, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[66]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x03c6, code lost:
    
        r0 = a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:440:0x1432, code lost:
    
        r24 = 126;
     */
    /* JADX WARN: Code restructure failed: missing block: B:441:0x1439, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:442:0x1446, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[27]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:443:0x1449, code lost:
    
        r24 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:444:0x1450, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:445:0x145d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[119(0x77, float:1.67E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:446:0x1460, code lost:
    
        r24 = 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:447:0x1468, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:448:0x1475, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[86]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:449:0x1478, code lost:
    
        r24 = 129;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x03c9, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:450:0x1480, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:451:0x148d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[64]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:452:0x1490, code lost:
    
        r24 = 130;
     */
    /* JADX WARN: Code restructure failed: missing block: B:453:0x1498, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:454:0x14a5, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[115(0x73, float:1.61E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:455:0x14a8, code lost:
    
        r24 = 131;
     */
    /* JADX WARN: Code restructure failed: missing block: B:456:0x14b0, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:457:0x14bd, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[120(0x78, float:1.68E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:458:0x14c0, code lost:
    
        r24 = 132;
     */
    /* JADX WARN: Code restructure failed: missing block: B:459:0x14c8, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:460:0x14d5, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[14]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:461:0x14d8, code lost:
    
        r24 = 133;
     */
    /* JADX WARN: Code restructure failed: missing block: B:462:0x14e0, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:463:0x14ee, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[136(0x88, float:1.9E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:464:0x14f1, code lost:
    
        r24 = 134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:465:0x14f9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:466:0x1506, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[35]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:467:0x1509, code lost:
    
        r24 = 135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:468:0x1511, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:469:0x151e, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[28]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:470:0x1521, code lost:
    
        r24 = 136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:471:0x1529, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:472:0x1536, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[102(0x66, float:1.43E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:473:0x1539, code lost:
    
        r24 = 137;
     */
    /* JADX WARN: Code restructure failed: missing block: B:474:0x1541, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:475:0x154e, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[84]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:476:0x1551, code lost:
    
        r24 = 138;
     */
    /* JADX WARN: Code restructure failed: missing block: B:477:0x1559, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:478:0x1566, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[77]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:479:0x1569, code lost:
    
        r24 = 139;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x03d0, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:480:0x1571, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:481:0x157f, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[157(0x9d, float:2.2E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:482:0x1582, code lost:
    
        r24 = 140;
     */
    /* JADX WARN: Code restructure failed: missing block: B:483:0x158a, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:484:0x1597, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[61]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:485:0x159a, code lost:
    
        r24 = 141;
     */
    /* JADX WARN: Code restructure failed: missing block: B:486:0x15a2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:487:0x15b0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[172(0xac, float:2.41E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:488:0x15b3, code lost:
    
        r24 = 142;
     */
    /* JADX WARN: Code restructure failed: missing block: B:489:0x15bb, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x03d1, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(r0.getHardness()));
     */
    /* JADX WARN: Code restructure failed: missing block: B:490:0x15c8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[18]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:491:0x15cb, code lost:
    
        r24 = 143;
     */
    /* JADX WARN: Code restructure failed: missing block: B:492:0x15d3, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:493:0x15de, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[122(0x7a, float:1.71E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:494:0x15e1, code lost:
    
        r24 = 144;
     */
    /* JADX WARN: Code restructure failed: missing block: B:495:0x15e6, code lost:
    
        r0 = r24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:496:0x15e8, code lost:
    
        switch(r0) {
            case 0: goto L497;
            case 1: goto L497;
            case 2: goto L497;
            case 3: goto L497;
            case 4: goto L497;
            case 5: goto L497;
            case 6: goto L497;
            case 7: goto L497;
            case 8: goto L497;
            case 9: goto L497;
            case 10: goto L500;
            case 11: goto L500;
            case 12: goto L500;
            case 13: goto L500;
            case 14: goto L500;
            case 15: goto L500;
            case 16: goto L500;
            case 17: goto L500;
            case 18: goto L500;
            case 19: goto L500;
            case 20: goto L500;
            case 21: goto L500;
            case 22: goto L500;
            case 23: goto L500;
            case 24: goto L500;
            case 25: goto L500;
            case 26: goto L500;
            case 27: goto L500;
            case 28: goto L500;
            case 29: goto L500;
            case 30: goto L501;
            case 31: goto L501;
            case 32: goto L501;
            case 33: goto L501;
            case 34: goto L501;
            case 35: goto L501;
            case 36: goto L501;
            case 37: goto L501;
            case 38: goto L501;
            case 39: goto L501;
            case 40: goto L501;
            case 41: goto L502;
            case 42: goto L502;
            case 43: goto L502;
            case 44: goto L502;
            case 45: goto L502;
            case 46: goto L502;
            case 47: goto L502;
            case 48: goto L502;
            case 49: goto L502;
            case 50: goto L502;
            case 51: goto L502;
            case 52: goto L502;
            case 53: goto L502;
            case 54: goto L502;
            case 55: goto L502;
            case 56: goto L502;
            case 57: goto L502;
            case 58: goto L502;
            case 59: goto L502;
            case 60: goto L502;
            case 61: goto L502;
            case 62: goto L502;
            case 63: goto L502;
            case 64: goto L502;
            case 65: goto L502;
            case 66: goto L502;
            case 67: goto L502;
            case 68: goto L502;
            case 69: goto L502;
            case 70: goto L502;
            case 71: goto L502;
            case 72: goto L502;
            case 73: goto L502;
            case 74: goto L502;
            case 75: goto L502;
            case 76: goto L502;
            case 77: goto L502;
            case 78: goto L502;
            case 79: goto L502;
            case 80: goto L502;
            case 81: goto L502;
            case 82: goto L502;
            case 83: goto L502;
            case 84: goto L502;
            case 85: goto L502;
            case 86: goto L502;
            case 87: goto L502;
            case 88: goto L502;
            case 89: goto L502;
            case 90: goto L502;
            case 91: goto L502;
            case 92: goto L502;
            case 93: goto L502;
            case 94: goto L503;
            case 95: goto L503;
            case 96: goto L503;
            case 97: goto L503;
            case 98: goto L503;
            case 99: goto L504;
            case 100: goto L504;
            case 101: goto L504;
            case 102: goto L504;
            case 103: goto L504;
            case 104: goto L504;
            case 105: goto L504;
            case 106: goto L504;
            case 107: goto L504;
            case 108: goto L505;
            case 109: goto L505;
            case 110: goto L505;
            case 111: goto L505;
            case 112: goto L506;
            case 113: goto L506;
            case 114: goto L506;
            case 115: goto L507;
            case 116: goto L508;
            case 117: goto L509;
            case 118: goto L509;
            case 119: goto L509;
            case 120: goto L510;
            case 121: goto L510;
            case 122: goto L510;
            case 123: goto L510;
            case 124: goto L510;
            case 125: goto L511;
            case 126: goto L512;
            case 127: goto L512;
            case 128: goto L512;
            case 129: goto L512;
            case 130: goto L512;
            case 131: goto L512;
            case 132: goto L512;
            case 133: goto L512;
            case 134: goto L512;
            case 135: goto L512;
            case 136: goto L512;
            case 137: goto L512;
            case 138: goto L512;
            case 139: goto L512;
            case 140: goto L512;
            case 141: goto L512;
            case 142: goto L513;
            case 143: goto L514;
            case 144: goto L514;
            default: goto L537;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:497:0x183c, code lost:
    
        r0 = me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(0.5f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:499:0x1852, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x03e4, code lost:
    
        r22 = r22 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0030, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:500:0x1853, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(3.0f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:501:0x1866, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(5.0f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:502:0x1879, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(2.0f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:503:0x188b, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(1.5f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:504:0x189e, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(0.8f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:505:0x18b1, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(0.7f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:506:0x18c4, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(1.0f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:507:0x18d6, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(22.5f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:508:0x18e9, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(50.0f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:509:0x18fc, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(3.5f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x03ea, code lost:
    
        r0.clear();
     */
    /* JADX WARN: Code restructure failed: missing block: B:510:0x190f, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(0.6f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:511:0x1922, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(0.65f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:512:0x1935, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(1.4f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:513:0x1948, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(1.8f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:514:0x195b, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_S.put(r0, java.lang.Float.valueOf(2.5f));
     */
    /* JADX WARN: Code restructure failed: missing block: B:515:0x196b, code lost:
    
        r21 = r21 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:516:0x1971, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(1, java.lang.Double.valueOf(0.41999998688697815d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(2, java.lang.Double.valueOf(0.33319999363422426d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(3, java.lang.Double.valueOf(0.24813599859094637d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(4, java.lang.Double.valueOf(0.164773281826065d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(5, java.lang.Double.valueOf(0.08307781780646906d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(6, java.lang.Double.valueOf(-0.07840000152587834d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(7, java.lang.Double.valueOf(-0.15523200451659847d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(8, java.lang.Double.valueOf(-0.23052736891296632d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(9, java.lang.Double.valueOf(-0.30431682745754074d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(10, java.lang.Double.valueOf(-0.37663049823865435d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_v.put(11, java.lang.Double.valueOf(-0.1040803780930446d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(1, java.lang.Double.valueOf(-0.07840000152587834d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(2, java.lang.Double.valueOf(-0.15523200451659847d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(3, java.lang.Double.valueOf(-0.23052736891296632d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(4, java.lang.Double.valueOf(-0.30431682745754074d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(5, java.lang.Double.valueOf(-0.37663049823865435d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(6, java.lang.Double.valueOf(-0.44749789698342113d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_t.put(7, java.lang.Double.valueOf(-0.5169479491049742d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(0, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(1, java.lang.Double.valueOf(0.0070422534d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(2, java.lang.Double.valueOf(0.014084507d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(3, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(4, java.lang.Double.valueOf(0.02112676d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(5, java.lang.Double.valueOf(0.028169014d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(6, java.lang.Double.valueOf(0.0281690166d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(7, java.lang.Double.valueOf(0.03521127d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(8, java.lang.Double.valueOf(0.04225352d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(9, java.lang.Double.valueOf(0.049295776d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(10, java.lang.Double.valueOf(0.0492957736d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(11, java.lang.Double.valueOf(0.056338027d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(12, java.lang.Double.valueOf(0.06338028d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(13, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(14, java.lang.Double.valueOf(0.07042254d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(15, java.lang.Double.valueOf(0.07746479d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(16, java.lang.Double.valueOf(0.08450704d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(17, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(18, java.lang.Double.valueOf(0.09154929d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(19, java.lang.Double.valueOf(0.09859155d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(20, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(21, java.lang.Double.valueOf(0.1056338d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(22, java.lang.Double.valueOf(0.112676054d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(23, java.lang.Double.valueOf(0.11971831d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(24, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(25, java.lang.Double.valueOf(0.12676056d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(26, java.lang.Double.valueOf(0.13380282d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(27, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(28, java.lang.Double.valueOf(0.14084508d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(29, java.lang.Double.valueOf(0.14788732d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(30, java.lang.Double.valueOf(0.15492958d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(31, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(32, java.lang.Double.valueOf(0.16197184d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(33, java.lang.Double.valueOf(0.16901408d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(34, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(35, java.lang.Double.valueOf(0.17605634d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(36, java.lang.Double.valueOf(0.18309858d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(37, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(38, java.lang.Double.valueOf(0.19014084d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(39, java.lang.Double.valueOf(0.1971831d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(40, java.lang.Double.valueOf(0.20422535d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(41, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(42, java.lang.Double.valueOf(0.2112676d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(43, java.lang.Double.valueOf(0.21830986d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(44, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(45, java.lang.Double.valueOf(0.22535211d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(46, java.lang.Double.valueOf(0.23239437d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(47, java.lang.Double.valueOf(0.23943663d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(48, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(49, java.lang.Double.valueOf(0.24647887d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(50, java.lang.Double.valueOf(0.2535211d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(51, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(52, java.lang.Double.valueOf(0.26056337d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(53, java.lang.Double.valueOf(0.26760563d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(54, java.lang.Double.valueOf(0.2746479d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(55, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(56, java.lang.Double.valueOf(0.28169015d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(57, java.lang.Double.valueOf(0.28873238d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(58, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(59, java.lang.Double.valueOf(0.29577464d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(60, java.lang.Double.valueOf(0.3028169d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(61, java.lang.Double.valueOf(0.30985916d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(62, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(63, java.lang.Double.valueOf(0.31690142d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(64, java.lang.Double.valueOf(0.32394367d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(65, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(66, java.lang.Double.valueOf(0.3309859d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(67, java.lang.Double.valueOf(0.33802816d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(68, java.lang.Double.valueOf(0.34507042d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(69, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(70, java.lang.Double.valueOf(0.35211268d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(71, java.lang.Double.valueOf(0.35915494d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(72, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(73, java.lang.Double.valueOf(0.36619717d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(74, java.lang.Double.valueOf(0.37323943d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(75, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(76, java.lang.Double.valueOf(0.3802817d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(77, java.lang.Double.valueOf(0.38732395d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(78, java.lang.Double.valueOf(0.3943662d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(79, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(80, java.lang.Double.valueOf(0.40140846d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(81, java.lang.Double.valueOf(0.4084507d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(82, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(83, java.lang.Double.valueOf(0.41549295d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(84, java.lang.Double.valueOf(0.4225352d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(85, java.lang.Double.valueOf(0.42957747d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(86, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(87, java.lang.Double.valueOf(0.43661973d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(88, java.lang.Double.valueOf(0.44366196d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(89, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(90, java.lang.Double.valueOf(0.45070422d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(91, java.lang.Double.valueOf(0.45774648d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(92, java.lang.Double.valueOf(0.46478873d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(93, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(94, java.lang.Double.valueOf(0.471831d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(95, java.lang.Double.valueOf(0.47887325d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(96, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(97, java.lang.Double.valueOf(0.48591548d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(98, java.lang.Double.valueOf(0.49295774d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(99, java.lang.Double.valueOf(0.5d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(100, java.lang.Double.valueOf(0.5d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(101, java.lang.Double.valueOf(0.5070422d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(102, java.lang.Double.valueOf(0.5140845d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(103, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(104, java.lang.Double.valueOf(0.52112675d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(105, java.lang.Double.valueOf(0.52816904d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(106, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(107, java.lang.Double.valueOf(0.53521127d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(108, java.lang.Double.valueOf(0.5422535d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(109, java.lang.Double.valueOf(0.5492958d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(110, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(111, java.lang.Double.valueOf(0.556338d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(112, java.lang.Double.valueOf(0.5633803d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(113, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(114, java.lang.Double.valueOf(0.57042253d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(115, java.lang.Double.valueOf(0.57746476d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(116, java.lang.Double.valueOf(0.58450705d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(117, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(118, java.lang.Double.valueOf(0.5915493d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(119, java.lang.Double.valueOf(0.59859157d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(120, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(121, java.lang.Double.valueOf(0.6056338d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(122, java.lang.Double.valueOf(0.6126761d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(123, java.lang.Double.valueOf(0.6197183d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(124, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(125, java.lang.Double.valueOf(0.62676054d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(126, java.lang.Double.valueOf(0.63380283d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(127, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(128, java.lang.Double.valueOf(0.64084506d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(129, java.lang.Double.valueOf(0.64788735d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(130, java.lang.Double.valueOf(0.6549296d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(131, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(132, java.lang.Double.valueOf(0.6619718d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(133, java.lang.Double.valueOf(0.6690141d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(134, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(135, java.lang.Double.valueOf(0.6760563d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(136, java.lang.Double.valueOf(0.6830986d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(137, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(138, java.lang.Double.valueOf(0.69014084d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(139, java.lang.Double.valueOf(0.6971831d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(140, java.lang.Double.valueOf(0.70422536d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(141, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(142, java.lang.Double.valueOf(0.7112676d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(143, java.lang.Double.valueOf(0.7183099d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(144, java.lang.Double.valueOf(0.7253521d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(145, java.lang.Double.valueOf(0.7253521d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(146, java.lang.Double.valueOf(0.73239434d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(147, java.lang.Double.valueOf(0.7394366d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(148, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(149, java.lang.Double.valueOf(0.74647886d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(150, java.lang.Double.valueOf(0.75352114d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(151, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(152, java.lang.Double.valueOf(0.7605634d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(153, java.lang.Double.valueOf(0.76760566d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(154, java.lang.Double.valueOf(0.7746479d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(155, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(156, java.lang.Double.valueOf(0.7816901d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(157, java.lang.Double.valueOf(0.7887324d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(158, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(159, java.lang.Double.valueOf(0.79577464d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(160, java.lang.Double.valueOf(0.8028169d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(161, java.lang.Double.valueOf(0.80985916d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(162, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(163, java.lang.Double.valueOf(0.8169014d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(164, java.lang.Double.valueOf(0.8239437d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(165, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(166, java.lang.Double.valueOf(0.8309859d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(167, java.lang.Double.valueOf(0.8380282d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(168, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(169, java.lang.Double.valueOf(0.8450704d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(170, java.lang.Double.valueOf(0.85211265d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(171, java.lang.Double.valueOf(0.85915494d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(172, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(173, java.lang.Double.valueOf(0.86619717d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(174, java.lang.Double.valueOf(0.87323946d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(175, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(176, java.lang.Double.valueOf(0.8802817d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(177, java.lang.Double.valueOf(0.8873239d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(178, java.lang.Double.valueOf(0.8943662d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(179, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(180, java.lang.Double.valueOf(0.90140843d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(181, java.lang.Double.valueOf(0.9084507d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(182, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(183, java.lang.Double.valueOf(0.91549295d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(184, java.lang.Double.valueOf(0.92253524d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(185, java.lang.Double.valueOf(0.92957747d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(186, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(187, java.lang.Double.valueOf(0.9366197d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(188, java.lang.Double.valueOf(0.943662d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(189, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(190, java.lang.Double.valueOf(0.9507042d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(191, java.lang.Double.valueOf(0.9577465d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(192, java.lang.Double.valueOf(0.96478873d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(193, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(194, java.lang.Double.valueOf(0.97183096d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(195, java.lang.Double.valueOf(0.97887325d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(196, java.lang.Double.valueOf(0.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(197, java.lang.Double.valueOf(0.9859155d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(198, java.lang.Double.valueOf(0.9929578d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(199, java.lang.Double.valueOf(1.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_r.put(200, java.lang.Double.valueOf(1.0d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.05999999821185753d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.051999998867515274d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.06159999881982969d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.06927999889612124d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.07542399904870933d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.08033919924402255d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.08427135945886732d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.0874170876776148d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.08993367029011523d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.0519469373041872d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.05647059355944606d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.03812980539822064d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.035014067535591664d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.04453032983624894d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.019999999105927202d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.07159953051526458d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.020820931761605266d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(0.0010261658043049238d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.023717291273619878d));
        me.frep.vulcan.spigot.Vulcan_fm.Vulcan_C.add(java.lang.Double.valueOf(-0.010724939925282229d));
     */
    /* JADX WARN: Code restructure failed: missing block: B:517:0x2b82, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x03f4, code lost:
    
        r0 = r0.length;
        r21 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0404, code lost:
    
        if (r21 >= r0) goto L535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0407, code lost:
    
        r0 = r0[r21];
        r0 = r0.name();
        r0 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0418, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x041d, code lost:
    
        switch(r0.hashCode()) {
            case -2143360393: goto L114;
            case -2124166951: goto L72;
            case -2119094147: goto L462;
            case -2118056882: goto L348;
            case -2072565711: goto L465;
            case -2010201205: goto L450;
            case -2002544804: goto L483;
            case -1994298340: goto L252;
            case -1987017078: goto L405;
            case -1982939579: goto L312;
            case -1962419392: goto L273;
            case -1951261276: goto L276;
            case -1918333928: goto L282;
            case -1842617470: goto L195;
            case -1842435366: goto L420;
            case -1738300588: goto L213;
            case -1722057187: goto L99;
            case -1651248210: goto L414;
            case -1554941502: goto L441;
            case -1474647453: goto L126;
            case -1337278289: goto L324;
            case -1324132210: goto L315;
            case -1289040810: goto L375;
            case -1277884088: goto L192;
            case -1266861419: goto L411;
            case -1239476237: goto L366;
            case -1200901687: goto L381;
            case -1176197063: goto L261;
            case -1132566471: goto L210;
            case -1093107010: goto L264;
            case -1047079230: goto L336;
            case -1013052939: goto L327;
            case -961482712: goto L237;
            case -900915975: goto L243;
            case -866289145: goto L129;
            case -837297303: goto L351;
            case -782280417: goto L255;
            case -741581175: goto L342;
            case -557177022: goto L318;
            case -539340890: goto L279;
            case -519277571: goto L96;
            case -452271318: goto L330;
            case -422086008: goto L288;
            case -418140412: goto L492;
            case -415523425: goto L489;
            case -400732458: goto L216;
            case -391389077: goto L393;
            case -387424896: goto L90;
            case -333218805: goto L108;
            case -328086150: goto L285;
            case -278780510: goto L165;
            case -269198261: goto L447;
            case -203278415: goto L480;
            case -179106457: goto L321;
            case -173863409: goto L201;
            case -170109641: goto L132;
            case -163486694: goto L111;
            case -123382247: goto L477;
            case -111024586: goto L177;
            case -72701037: goto L144;
            case -65762406: goto L246;
            case -35571309: goto L294;
            case -19295470: goto L402;
            case 75556: goto L219;
            case 2071137: goto L423;
            case 2098567: goto L57;
            case 2537604: goto L81;
            case 2545085: goto L399;
            case 2670253: goto L225;
            case 2670261: goto L372;
            case 38285172: goto L105;
            case 43464726: goto L360;
            case 56553991: goto L438;
            case 62437548: goto L159;
            case 63467553: goto L267;
            case 66779153: goto L207;
            case 68077974: goto L426;
            case 72612311: goto L222;
            case 73118215: goto L66;
            case 73829118: goto L432;
            case 77737729: goto L387;
            case 79233093: goto L354;
            case 104950264: goto L333;
            case 136312843: goto L453;
            case 155515457: goto L369;
            case 166209980: goto L309;
            case 190832590: goto L138;
            case 197168635: goto L231;
            case 199983749: goto L486;
            case 212343096: goto L417;
            case 327294614: goto L468;
            case 367435514: goto L174;
            case 380854351: goto L297;
            case 453665019: goto L204;
            case 473639627: goto L123;
            case 478520881: goto L93;
            case 478964413: goto L258;
            case 479695913: goto L240;
            case 492332526: goto L63;
            case 534551745: goto L345;
            case 553521315: goto L75;
            case 707614322: goto L168;
            case 730697741: goto L228;
            case 752809692: goto L300;
            case 760322528: goto L378;
            case 868145122: goto L270;
            case 905696727: goto L69;
            case 942687056: goto L84;
            case 1007337992: goto L363;
            case 1083812258: goto L189;
            case 1131234006: goto L147;
            case 1134498395: goto L408;
            case 1156583859: goto L87;
            case 1171939996: goto L306;
            case 1210134772: goto L459;
            case 1224225185: goto L78;
            case 1341913960: goto L198;
            case 1379814896: goto L102;
            case 1432894430: goto L471;
            case 1433121601: goto L396;
            case 1461129901: goto L390;
            case 1478351150: goto L435;
            case 1538313714: goto L150;
            case 1545081517: goto L339;
            case 1552065406: goto L444;
            case 1593989766: goto L171;
            case 1665394475: goto L456;
            case 1726268540: goto L186;
            case 1753058479: goto L249;
            case 1790904261: goto L162;
            case 1797596357: goto L153;
            case 1802791650: goto L180;
            case 1817755422: goto L117;
            case 1841275752: goto L120;
            case 1902490268: goto L384;
            case 1919650200: goto L291;
            case 1920426094: goto L357;
            case 1950793198: goto L183;
            case 1955250244: goto L135;
            case 1992813683: goto L156;
            case 2085943460: goto L474;
            case 2090790125: goto L234;
            case 2110246428: goto L303;
            case 2110419719: goto L429;
            case 2136719412: goto L141;
            default: goto L495;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x08b0, code lost:
    
        r0 = r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[128(0x80, float:1.8E-43)]);
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x08bc, code lost:
    
        if (r0 == 0) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0040, code lost:
    
        if (r0 >= r15) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x08c5, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x08c6, code lost:
    
        r24 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x08cc, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x08d9, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[110(0x6e, float:1.54E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x08dc, code lost:
    
        r24 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x08e2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x08f0, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[178(0xb2, float:2.5E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x08f3, code lost:
    
        r24 = 2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x08f9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x0907, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[156(0x9c, float:2.19E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x090a, code lost:
    
        r24 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0910, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x091d, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[89]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x0920, code lost:
    
        r24 = 4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x0926, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x0934, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[169(0xa9, float:2.37E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x0937, code lost:
    
        r24 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x093d, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x094b, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[151(0x97, float:2.12E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x004c, code lost:
    
        r13 = "\u0010\u001e-\u00117\u001d6\u0010\u0010>\u0013\r\u0019\u00128\n%\u000e0\u0003\u001d1\u0017'\t";
        r15 = "\u0010\u001e-\u00117\u001d6\u0010\u0010>\u0013\r\u0019\u00128\n%\u000e0\u0003\u001d1\u0017'\t".length();
        r12 = 11;
        r11 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x094e, code lost:
    
        r24 = 6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x0955, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x0962, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[41]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x0965, code lost:
    
        r24 = 7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x096c, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x097a, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[153(0x99, float:2.14E-43)]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:86:0x097d, code lost:
    
        r24 = 8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x0984, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x0991, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[12]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x0994, code lost:
    
        r24 = 9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x099b, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x09a8, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[65]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x09ab, code lost:
    
        r24 = 10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x09b2, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x09bf, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[10]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x09c2, code lost:
    
        r24 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x09c9, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x09d6, code lost:
    
        if (r0.equals(me.frep.vulcan.spigot.Vulcan_fm.a[82]) == false) goto L495;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x09d9, code lost:
    
        r24 = 12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x09e0, code lost:
    
        r24 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x006b, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = r3;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00a2, B:28:0x0104], limit reached: 553 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v1075, types: [java.lang.Object, org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v1076, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v1078, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v1079, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v1083, types: [int] */
    /* JADX WARN: Type inference failed for: r0v21, types: [org.bukkit.Material[]] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.Object, org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v507, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v73, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v5, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v681 */
    /* JADX WARN: Type inference failed for: r2v682 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v20 */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0109 -> B:15:0x00a2). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 11139
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fm.m825clinit():void");
    }

    private static Material[] lambda$static$0(int i) {
        return new Material[i];
    }
}
