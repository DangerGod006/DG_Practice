package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import com.github.retrooper.packetevents.wrapper.PacketWrapper;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerPositionAndLook;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation;
import java.lang.invoke.MethodHandles;
import java.util.concurrent.ThreadLocalRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_fb, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fb.class */
public final class C0044Vulcan_fb {
    private static int[] Vulcan_t;
    private static final long a = Vulcan_n.a(3203642946471376212L, -4855620331715938476L, MethodHandles.lookup().lookupClass()).a(12150127476633L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a1: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_D(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 266
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_D(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a1: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static boolean Vulcan_U(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 266
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_U(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: JadxRuntimeException: Failed to decode insn: 0x00F7: MOVE_MULTI in method: me.frep.vulcan.spigot.Vulcan_fb.Vulcan_W(java.lang.Object[]):boolean, file: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fb.class
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Failed to decode insn: 0x00F7: MOVE_MULTI
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:57)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	... 6 more
        Caused by: java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -3 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:304)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	... 9 more
        */
    public static boolean Vulcan_W(java.lang.Object[] r0) {
        /*
            Method dump skipped, instruction units count: 824
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_W(java.lang.Object[]):boolean");
    }

    public static void Vulcan_d(int[] iArr) {
        Vulcan_t = iArr;
    }

    public static int[] Vulcan_S() {
        return Vulcan_t;
    }

    static {
        int i;
        long j = a ^ 64545661909753L;
        Vulcan_d(new int[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "-ç{ôîÊ\u00968\b±¨Ý&887 ";
        int length = "-ç{ôîÊ\u00968\b±¨Ý&887 ".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "-ç{ôîÊ\u009688\"\u001a\u0004Å\\C%z2Âá¥Îmfî·rj4dl\u0011µ\u0001*\u0096\u0080ÙÃ`ï0Rè7lì\u008e\u000b\u0002\u0007#\u009c\nÊ\u0003/\u0088tþà\u00917\u0088\u0007";
                        length = "-ç{ôîÊ\u009688\"\u001a\u0004Å\\C%z2Âá¥Îmfî·rj4dl\u0011µ\u0001*\u0096\u0080ÙÃ`ï0Rè7lì\u008e\u000b\u0002\u0007#\u009c\nÊ\u0003/\u0088tþà\u00917\u0088\u0007".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private C0044Vulcan_fb() {
        throw new UnsupportedOperationException(b[3]);
    }

    public static int Vulcan_x(Object[] objArr) {
        try {
            return PacketEvents.getAPI().getPlayerManager().getPing((Player) objArr[0]);
        } catch (Exception e) {
            return 0;
        }
    }

    public static void Vulcan_J(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        PacketEvents.getAPI().getProtocolManager().sendPacket(c0042Vulcan_Oz.Vulcan_V(new Object[0]).getChannel(), (PacketWrapper) objArr[1]);
    }

    public static boolean Vulcan_h(Object[] objArr) {
        return ((C0042Vulcan_Oz) objArr[0]).Vulcan_V(new Object[0]).getClientVersion().isNewerThanOrEquals(ClientVersion.V_1_17);
    }

    public static boolean Vulcan_B(Object[] objArr) {
        return ((C0042Vulcan_Oz) objArr[0]).Vulcan_V(new Object[0]).getClientVersion().isNewerThan(ClientVersion.V_1_9);
    }

    public static boolean Vulcan_R(Object[] objArr) {
        return ((C0042Vulcan_Oz) objArr[0]).Vulcan_V(new Object[0]).getClientVersion().isNewerThanOrEquals(ClientVersion.V_1_13);
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [int, short] */
    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public static void m677Vulcan_h(Object[] objArr) {
        Vulcan_J(new Object[]{(C0042Vulcan_Oz) objArr[0], new WrapperPlayServerWindowConfirmation(0, (short) ((Integer) objArr[1]).intValue(), false)});
    }

    public static void Vulcan_P(Object[] objArr) {
        Vulcan_J(new Object[]{(C0042Vulcan_Oz) objArr[0], new WrapperPlayServerPing(((Integer) objArr[1]).intValue())});
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:35:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_o(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_Oz r1 = (me.frep.vulcan.spigot.C0042Vulcan_Oz) r1
            r8 = r1
            long r0 = me.frep.vulcan.spigot.C0044Vulcan_fb.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r11 = r0
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L2b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L2b
            if (r0 != 0) goto L2f
            r0 = 0
            return r0
        L2b:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L2b
            throw r0
        L2f:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.UnsupportedOperationException -> L47
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r0)     // Catch: java.lang.UnsupportedOperationException -> L47
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L61
            if (r1 == 0) goto L5f
            if (r0 == 0) goto L72
            goto L4b
        L47:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L5b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L5b
        L4b:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L5b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L5b
            boolean r0 = r0.isSwimming()     // Catch: java.lang.UnsupportedOperationException -> L5b
            goto L5f
        L5b:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5f:
            r1 = r11
        L61:
            if (r1 == 0) goto L6f
            if (r0 == 0) goto L72
            goto L6e
        L6a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L6e:
            r0 = 1
        L6f:
            goto L73
        L72:
            r0 = 0
        L73:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_o(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_i(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_i(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_F(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_F(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v34, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public static boolean m678Vulcan_x(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (j >= 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(16)).isSolid();
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zIsSolid = ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(19)).isSolid();
                                    if (Vulcan_q == 0) {
                                        return zIsSolid;
                                    }
                                    if (!zIsSolid) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v34, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_j(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (j > 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(16)).isSolid();
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zIsSolid = ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(19)).isSolid();
                                    if (Vulcan_q == 0) {
                                        return zIsSolid;
                                    }
                                    if (!zIsSolid) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan__(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            Vulcan_q = c0042Vulcan_Oz.Vulcan_e(new Object[0]);
            try {
                if (Vulcan_q == 0) {
                    return false;
                }
                try {
                    Vulcan_q = Vulcan_OM.Vulcan_I(new Object[0]);
                    ?? r1 = Vulcan_q;
                    ?? HasPotionEffect = Vulcan_q;
                    ?? r0 = Vulcan_q;
                    ?? r12 = r1;
                    if (j > 0) {
                        if (r1 != 0) {
                            if (Vulcan_q != 0) {
                                HasPotionEffect = c0042Vulcan_Oz.Vulcan_e(new Object[0]).hasPotionEffect(PotionEffectType.DOLPHINS_GRACE);
                            }
                            return false;
                        }
                        r12 = Vulcan_q;
                        r0 = HasPotionEffect;
                    }
                    if (r12 == 0) {
                        return r0;
                    }
                    if (r0 != 0) {
                        return true;
                    }
                    return false;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v36, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_S(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (jLongValue > 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = C0046Vulcan_ff.Vulcan_aq(new Object[]{(Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(16)});
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zVulcan_aq = C0046Vulcan_ff.Vulcan_aq(new Object[]{(Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(19)});
                                    if (Vulcan_q == 0) {
                                        return zVulcan_aq;
                                    }
                                    if (!zVulcan_aq) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static double Vulcan_N(Object[] objArr) {
        return Math.abs(180.0f - Math.abs(((Player) objArr[0]).getLocation().getYaw() - ((Player) objArr[1]).getLocation().getYaw()));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v36, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_s(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (jLongValue >= 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = C0046Vulcan_ff.Vulcan_aq(new Object[]{(Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(16)});
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zVulcan_aq = C0046Vulcan_ff.Vulcan_aq(new Object[]{(Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(19)});
                                    if (Vulcan_q == 0) {
                                        return zVulcan_aq;
                                    }
                                    if (!zVulcan_aq) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_y(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_y(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_C(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 258
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_C(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_q(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 258
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_q(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List m679Vulcan_R(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.m679Vulcan_R(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_k(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 408
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_k(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_e(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 408
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_e(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_V(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 258
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_V(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0055  */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_O(java.lang.Object[] r5) {
        /*
            Method dump skipped, instruction units count: 258
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_O(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:35:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_m(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_Oz r1 = (me.frep.vulcan.spigot.C0042Vulcan_Oz) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.C0044Vulcan_fb.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r11 = r0
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L2b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L2b
            if (r0 != 0) goto L2f
            r0 = 0
            return r0
        L2b:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L2b
            throw r0
        L2f:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.UnsupportedOperationException -> L47
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r0)     // Catch: java.lang.UnsupportedOperationException -> L47
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L61
            if (r1 == 0) goto L5f
            if (r0 == 0) goto L72
            goto L4b
        L47:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L5b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L5b
        L4b:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L5b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L5b
            boolean r0 = r0.isRiptiding()     // Catch: java.lang.UnsupportedOperationException -> L5b
            goto L5f
        L5b:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5f:
            r1 = r11
        L61:
            if (r1 == 0) goto L6f
            if (r0 == 0) goto L72
            goto L6e
        L6a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L6e:
            r0 = 1
        L6f:
            goto L73
        L72:
            r0 = 0
        L73:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_m(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:35:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m680Vulcan_q(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_Oz r1 = (me.frep.vulcan.spigot.C0042Vulcan_Oz) r1
            r8 = r1
            long r0 = me.frep.vulcan.spigot.C0044Vulcan_fb.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r11 = r0
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L2b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L2b
            if (r0 != 0) goto L2f
            r0 = 0
            return r0
        L2b:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L2b
            throw r0
        L2f:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.UnsupportedOperationException -> L47
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.UnsupportedOperationException -> L47
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L61
            if (r1 == 0) goto L5f
            if (r0 == 0) goto L72
            goto L4b
        L47:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L5b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L5b
        L4b:
            r0 = r8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.UnsupportedOperationException -> L5b
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.UnsupportedOperationException -> L5b
            boolean r0 = r0.isGliding()     // Catch: java.lang.UnsupportedOperationException -> L5b
            goto L5f
        L5b:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5f:
            r1 = r11
        L61:
            if (r1 == 0) goto L6f
            if (r0 == 0) goto L72
            goto L6e
        L6a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L6e:
            r0 = 1
        L6f:
            goto L73
        L72:
            r0 = 0
        L73:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.m680Vulcan_q(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [int] */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    public static int Vulcan_G(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Player player = (Player) objArr[1];
        PotionEffectType potionEffectType = (PotionEffectType) objArr[2];
        long j = a ^ jLongValue;
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        int id = potionEffectType.getId();
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            ?? A = id;
            if (abstractCheckArrVulcan_q == null) {
                return A;
            }
            try {
                try {
                    try {
                        int id2 = potionEffect.getType().getId();
                        if (abstractCheckArrVulcan_q != null) {
                            if (A == id2) {
                                A = potionEffect.getAmplifier();
                                id2 = 1;
                            } else if (abstractCheckArrVulcan_q == null) {
                                break;
                            }
                        }
                        return A + id2;
                    } catch (UnsupportedOperationException unused) {
                        A = a((UnsupportedOperationException) A);
                        throw A;
                    }
                } catch (UnsupportedOperationException unused2) {
                    throw a((UnsupportedOperationException) A);
                }
            } catch (UnsupportedOperationException unused3) {
                throw a((UnsupportedOperationException) A);
            }
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v34, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v44, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v47, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v38 */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_g(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = a ^ jLongValue;
        long j2 = j ^ 116421488076045L;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (j >= 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        ?? r2 = new Object[2];
                                        ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(13))[1] = Long.valueOf(j2);
                                        r2[0] = r2;
                                        A = C0046Vulcan_ff.Vulcan_aV(r2);
                                    }
                                    r1 = Vulcan_q;
                                }
                                try {
                                    try {
                                        if (r1 == 0) {
                                            return A;
                                        }
                                        if (A == 0) {
                                            ?? r22 = new Object[2];
                                            c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m890Vulcan_C(new Object[0])[1] = Long.valueOf(j2);
                                            r22[0] = r22;
                                            boolean zVulcan_aV = C0046Vulcan_ff.Vulcan_aV(r22);
                                            if (Vulcan_q == 0) {
                                                return zVulcan_aV;
                                            }
                                            if (!zVulcan_aV) {
                                                ?? r23 = new Object[2];
                                                c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m891Vulcan_M(new Object[0])[1] = Long.valueOf(j2);
                                                r23[0] = r23;
                                                boolean zVulcan_aV2 = C0046Vulcan_ff.Vulcan_aV(r23);
                                                if (Vulcan_q == 0) {
                                                    return zVulcan_aV2;
                                                }
                                                if (!zVulcan_aV2) {
                                                    return false;
                                                }
                                            }
                                        }
                                        return true;
                                    } catch (UnsupportedOperationException unused) {
                                        throw a((UnsupportedOperationException) A);
                                    }
                                } catch (UnsupportedOperationException unused2) {
                                    throw a((UnsupportedOperationException) A);
                                }
                            } catch (UnsupportedOperationException unused3) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused4) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused5) {
                        A = a((UnsupportedOperationException) A);
                        throw A;
                    }
                } catch (UnsupportedOperationException unused6) {
                    throw a((UnsupportedOperationException) A);
                }
            } catch (UnsupportedOperationException unused7) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused8) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v34, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v44, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v47, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v38 */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public static boolean m681Vulcan_G(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 84059377468472L;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (jLongValue >= 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        ?? r2 = new Object[2];
                                        ((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(13))[1] = Long.valueOf(j);
                                        r2[0] = r2;
                                        A = C0046Vulcan_ff.Vulcan_aV(r2);
                                    }
                                    r1 = Vulcan_q;
                                }
                                try {
                                    try {
                                        if (r1 == 0) {
                                            return A;
                                        }
                                        if (A == 0) {
                                            ?? r22 = new Object[2];
                                            c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m880Vulcan_Y(new Object[0])[1] = Long.valueOf(j);
                                            r22[0] = r22;
                                            boolean zVulcan_aV = C0046Vulcan_ff.Vulcan_aV(r22);
                                            if (Vulcan_q == 0) {
                                                return zVulcan_aV;
                                            }
                                            if (!zVulcan_aV) {
                                                ?? r23 = new Object[2];
                                                c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m881Vulcan_H(new Object[0])[1] = Long.valueOf(j);
                                                r23[0] = r23;
                                                boolean zVulcan_aV2 = C0046Vulcan_ff.Vulcan_aV(r23);
                                                if (Vulcan_q == 0) {
                                                    return zVulcan_aV2;
                                                }
                                                if (!zVulcan_aV2) {
                                                    return false;
                                                }
                                            }
                                        }
                                        return true;
                                    } catch (UnsupportedOperationException unused) {
                                        throw a((UnsupportedOperationException) A);
                                    }
                                } catch (UnsupportedOperationException unused2) {
                                    throw a((UnsupportedOperationException) A);
                                }
                            } catch (UnsupportedOperationException unused3) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused4) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused5) {
                        A = a((UnsupportedOperationException) A);
                        throw A;
                    }
                } catch (UnsupportedOperationException unused6) {
                    throw a((UnsupportedOperationException) A);
                }
            } catch (UnsupportedOperationException unused7) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused8) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v34, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_d(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (jLongValue > 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = C0046Vulcan_ff.Vulcan_a1((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(16));
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zVulcan_a1 = C0046Vulcan_ff.Vulcan_a1((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m886Vulcan_D(new Object[0]).get(19));
                                    if (Vulcan_q == 0) {
                                        return zVulcan_a1;
                                    }
                                    if (!zVulcan_a1) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v34, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_A(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                Vulcan_q = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                ?? A = Vulcan_q;
                if (Vulcan_q != 0) {
                    if (Vulcan_q == 0) {
                        return false;
                    }
                    A = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]);
                }
                try {
                    try {
                        A = A.isEmpty();
                        ?? r1 = Vulcan_q;
                        try {
                            try {
                                if (jLongValue >= 0) {
                                    if (r1 != 0) {
                                        if (A != 0) {
                                            return false;
                                        }
                                        A = C0046Vulcan_ff.Vulcan_a1((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(16));
                                    }
                                    r1 = Vulcan_q;
                                }
                                if (r1 == 0) {
                                    return A;
                                }
                                if (A == 0) {
                                    boolean zVulcan_a1 = C0046Vulcan_ff.Vulcan_a1((Material) c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_c(new Object[0]).get(19));
                                    if (Vulcan_q == 0) {
                                        return zVulcan_a1;
                                    }
                                    if (!zVulcan_a1) {
                                        return false;
                                    }
                                }
                                return true;
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) A);
                            }
                        } catch (UnsupportedOperationException unused2) {
                            throw a((UnsupportedOperationException) A);
                        }
                    } catch (UnsupportedOperationException unused3) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused4) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused5) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused6) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v28, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v37, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v40, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v45 */
    /* JADX WARN: Type inference failed for: r2v15, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_M(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 268
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_M(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v28, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v37, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v40, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v45 */
    /* JADX WARN: Type inference failed for: r2v15, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_w(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 268
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_w(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.potion.PotionEffect] */
    public static int Vulcan_L(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        LivingEntity livingEntity = (LivingEntity) objArr[1];
        long j = a ^ jLongValue;
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        for (?? A : livingEntity.getActivePotionEffects()) {
            try {
                try {
                    try {
                        A = A.getType().toString().toLowerCase().contains(b[1]);
                        AbstractCheck[] abstractCheckArr = abstractCheckArrVulcan_q;
                        if (j >= 0) {
                            if (abstractCheckArr == null) {
                                return A;
                            }
                            abstractCheckArr = abstractCheckArrVulcan_q;
                        }
                        if (abstractCheckArr == null) {
                            return A;
                        }
                        if (A != 0) {
                            return A.getAmplifier() + 1;
                        }
                        if (abstractCheckArrVulcan_q == null) {
                            break;
                        }
                    } catch (UnsupportedOperationException unused) {
                        throw a((UnsupportedOperationException) A);
                    }
                } catch (UnsupportedOperationException unused2) {
                    throw a((UnsupportedOperationException) A);
                }
            } catch (UnsupportedOperationException unused3) {
                A = a((UnsupportedOperationException) A);
                throw A;
            }
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_t(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_t(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_T(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_T(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:55:0x011b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static boolean Vulcan_I(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_I(java.lang.Object[]):boolean");
    }

    public static void Vulcan_Z(Object[] objArr) {
        Vulcan_J(new Object[]{Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{(Player) objArr[0]}), new WrapperPlayServerHeldItemChange(ThreadLocalRandom.current().nextInt(8))});
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException, me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public static float m682Vulcan_e(Object[] objArr) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[0];
        float fFloatValue = ((Float) objArr[1]).floatValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        float fM739Vulcan_b = fFloatValue + (c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m739Vulcan_b(new Object[0]) * 0.0675f) + ((c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m990Vulcan_L(new Object[0]) - 0.2f) * 3.5f);
        try {
            if (Vulcan_q == 0) {
                return fM739Vulcan_b;
            }
            if (fM739Vulcan_b < fFloatValue) {
                return fFloatValue + (c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m739Vulcan_b(new Object[0]) * 0.0675f);
            }
            return fFloatValue;
        } catch (UnsupportedOperationException unused) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v41, types: [com.github.retrooper.packetevents.wrapper.PacketWrapper, com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerPositionAndLook] */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public static void m683Vulcan_o(Object[] objArr) {
        ?? wrapperPlayServerPlayerPositionAndLook;
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            Vulcan_q = c0042Vulcan_Oz.Vulcan_e(new Object[0]);
            ?? Vulcan_e = Vulcan_q;
            if (Vulcan_q != 0) {
                if (Vulcan_q == 0) {
                    return;
                } else {
                    Vulcan_e = c0042Vulcan_Oz.Vulcan_e(new Object[0]);
                }
            }
            Location location = new Location(Vulcan_e.getWorld(), c0042Vulcan_Oz.Vulcan_e(new Object[0]).getLocation().getX(), c0042Vulcan_Oz.Vulcan_e(new Object[0]).getLocation().getY(), c0042Vulcan_Oz.Vulcan_e(new Object[0]).getLocation().getZ(), ((float) ThreadLocalRandom.current().nextDouble(360.0d)) - 180.0f, ((float) ThreadLocalRandom.current().nextDouble(180.0d)) - 90.0f);
            if (j >= 0) {
                if (Vulcan_r.INSTANCE.Vulcan_n()) {
                    wrapperPlayServerPlayerPositionAndLook = new WrapperPlayServerPlayerPositionAndLook(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch(), (byte) 0, 69, false);
                    try {
                        c0042Vulcan_Oz.Vulcan_V(new Object[0]).sendPacket((PacketWrapper) wrapperPlayServerPlayerPositionAndLook);
                        ?? r0 = Vulcan_q;
                        wrapperPlayServerPlayerPositionAndLook = r0;
                        if (j >= 0) {
                            if (r0 != 0) {
                                return;
                            }
                            wrapperPlayServerPlayerPositionAndLook = new Object[]{() -> {
                                lambda$rotateRandomly$0(r0, r1);
                            }};
                        }
                        Vulcan_fU.Vulcan_B(wrapperPlayServerPlayerPositionAndLook);
                    } catch (UnsupportedOperationException unused) {
                        throw a((UnsupportedOperationException) wrapperPlayServerPlayerPositionAndLook);
                    }
                } else {
                    wrapperPlayServerPlayerPositionAndLook = new Object[]{() -> {
                        lambda$rotateRandomly$0(r0, r1);
                    }};
                    Vulcan_fU.Vulcan_B(wrapperPlayServerPlayerPositionAndLook);
                }
            }
        } catch (UnsupportedOperationException unused2) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    private static void lambda$rotateRandomly$0(C0042Vulcan_Oz c0042Vulcan_Oz, Location location) {
        c0042Vulcan_Oz.Vulcan_e(new Object[0]).teleport(location, PlayerTeleportEvent.TeleportCause.UNKNOWN);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v39, types: [com.github.retrooper.packetevents.wrapper.PacketWrapper, com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerPositionAndLook] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public static void m684Vulcan_B(Object[] objArr) {
        ?? wrapperPlayServerPlayerPositionAndLook;
        Player player = (Player) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        Player playerVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
        Player playerVulcan_e = playerVulcan_L;
        if (abstractCheckArrVulcan_q != null) {
            if (playerVulcan_e == null) {
                return;
            } else {
                playerVulcan_e = playerVulcan_L;
            }
        }
        try {
            playerVulcan_e = playerVulcan_e.Vulcan_e(new Object[0]);
            if (abstractCheckArrVulcan_q != null) {
                if (playerVulcan_e == null) {
                    return;
                } else {
                    playerVulcan_e = player;
                }
            }
            Location location = new Location(playerVulcan_e.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), ((float) ThreadLocalRandom.current().nextDouble(360.0d)) - 180.0f, ((float) ThreadLocalRandom.current().nextDouble(180.0d)) - 90.0f);
            if (jLongValue >= 0) {
                if (Vulcan_r.INSTANCE.Vulcan_n()) {
                    wrapperPlayServerPlayerPositionAndLook = new WrapperPlayServerPlayerPositionAndLook(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch(), (byte) 0, 69, false);
                    try {
                        playerVulcan_L.Vulcan_V(new Object[0]).sendPacket((PacketWrapper) wrapperPlayServerPlayerPositionAndLook);
                        AbstractCheck[] abstractCheckArr = abstractCheckArrVulcan_q;
                        wrapperPlayServerPlayerPositionAndLook = abstractCheckArr;
                        if (jLongValue >= 0) {
                            if (abstractCheckArr != null) {
                                return;
                            }
                            wrapperPlayServerPlayerPositionAndLook = new Object[]{() -> {
                                lambda$rotateRandomly$1(r0, r1);
                            }};
                        }
                    } catch (UnsupportedOperationException unused) {
                        throw a((UnsupportedOperationException) wrapperPlayServerPlayerPositionAndLook);
                    }
                } else {
                    wrapperPlayServerPlayerPositionAndLook = new Object[]{() -> {
                        lambda$rotateRandomly$1(r0, r1);
                    }};
                }
                Vulcan_fU.Vulcan_B(wrapperPlayServerPlayerPositionAndLook);
            }
        } catch (UnsupportedOperationException unused2) {
            throw a((UnsupportedOperationException) playerVulcan_e);
        }
    }

    private static void lambda$rotateRandomly$1(Player player, Location location) {
        player.teleport(location, PlayerTeleportEvent.TeleportCause.UNKNOWN);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0170  */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v34 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_l(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 424
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_l(java.lang.Object[]):boolean");
    }
}
