package me.frep.vulcan.spigot.check.impl.player.badpackets;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPacketsL.class */
public class BadPacketsL {
}
