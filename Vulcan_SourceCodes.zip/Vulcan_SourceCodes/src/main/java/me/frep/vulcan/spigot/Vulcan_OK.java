package me.frep.vulcan.spigot;

import java.io.File;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OK.class */
public class Vulcan_OK {
    private final File Vulcan__;
    private final FileConfiguration Vulcan_B;
    private static boolean Vulcan_n;
    private static final long a = Vulcan_n.a(3474588879750947246L, 304000455695932402L, MethodHandles.lookup().lookupClass()).a(120859158763421L);
    private static final String b;

    public static void Vulcan_z(boolean z) {
        Vulcan_n = z;
    }

    public static boolean Vulcan_Q() {
        return Vulcan_n;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_D() {
        return !Vulcan_Q();
    }

    static {
        long j = a ^ 55937047164619L;
        Vulcan_z(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        b = a(cipher.doFinal("*Û\u0015\u0099[Íã\u0010".getBytes(CharEncoding.ISO_8859_1))).intern();
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public Vulcan_OK(String str) {
        long j = a ^ 59054129076158L;
        ?? Vulcan_D = Vulcan_D();
        try {
            this.Vulcan__ = new File(Vulcan_r.INSTANCE.m1084Vulcan_j().getDataFolder() + File.separator, str + b);
            this.Vulcan_B = YamlConfiguration.loadConfiguration(this.Vulcan__);
            if (Vulcan_D == 0) {
                Vulcan_D = new AbstractCheck[2];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_D);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_D);
        }
    }

    public FileConfiguration Vulcan_B(Object[] objArr) {
        return this.Vulcan_B;
    }

    public void Vulcan_T(Object[] objArr) {
        try {
            Vulcan_B(new Object[0]).save(this.Vulcan__);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
