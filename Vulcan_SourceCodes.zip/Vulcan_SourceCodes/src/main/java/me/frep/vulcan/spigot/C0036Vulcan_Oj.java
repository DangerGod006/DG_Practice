package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.LinkedList;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Oj, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oj.class */
public final class C0036Vulcan_Oj extends LinkedList {
    private final int Vulcan_x;
    private static AbstractCheck[] Vulcan_d;
    private static final long a = Vulcan_n.a(-6321459837575034002L, 209858149826706589L, MethodHandles.lookup().lookupClass()).a(1419863174203L);

    public static void Vulcan_G(AbstractCheck[] abstractCheckArr) {
        Vulcan_d = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_M() {
        return Vulcan_d;
    }

    static {
        if (Vulcan_M() != null) {
            Vulcan_G(new AbstractCheck[3]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public int Vulcan_r(Object[] objArr) {
        return this.Vulcan_x;
    }

    public C0036Vulcan_Oj(int i) {
        this.Vulcan_x = i;
    }

    public C0036Vulcan_Oj(Collection collection, int i) {
        super(collection);
        this.Vulcan_x = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    @Override // java.util.LinkedList, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List, java.util.Deque, java.util.Queue
    public boolean add(Object obj) {
        long j = a ^ 59039252160963L;
        ?? Vulcan_M = Vulcan_M();
        try {
            try {
                Vulcan_M = size();
                if (Vulcan_M != 0) {
                    return Vulcan_M;
                }
                if (Vulcan_M >= Vulcan_r(new Object[0])) {
                    removeFirst();
                }
                return super.add(obj);
            } catch (RuntimeException unused) {
                throw a(Vulcan_M);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_M);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean, int] */
    public boolean Vulcan_n(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_M = Vulcan_M();
        try {
            try {
                Vulcan_M = size();
                return Vulcan_M == 0 ? Vulcan_M >= Vulcan_r(new Object[0]) : Vulcan_M;
            } catch (RuntimeException unused) {
                throw a(Vulcan_M);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_M);
        }
    }
}
