package me.frep.vulcan.spigot.check.impl.movement.flight;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.Vulcan_y;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/flight/FlightF.class */
@CheckInfo(name = "Flight", type = 'F', complexType = "Prediction", description = "Invalid Y-Axis movement.")
public class FlightF extends AbstractCheck {
    private static String[] Vulcan_x;
    private static final long b = Vulcan_n.a(8916543768647906644L, -6635759070765658142L, MethodHandles.lookup().lookupClass()).a(181878908604288L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0905: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 2348
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.flight.FlightF.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_C(String[] strArr) {
        Vulcan_x = strArr;
    }

    public static String[] Vulcan_m() {
        return Vulcan_x;
    }

    static {
        int i;
        long j = b ^ 128716165450479L;
        Vulcan_C((String[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[9];
        int i3 = 0;
        String str = "}\u0093a\u009d½¢>e\bY\u001ecýî`G»\bi¢\u0087|\u0010O½O\b\u001b\u008d\u0080\u008bã¨É#\b\u0085\u0010]3\u0090L:b\bdÃº\u0084Ì'\u0086ì\bÌ\u0090$ôuîKé";
        int length = "}\u0093a\u009d½¢>e\bY\u001ecýî`G»\bi¢\u0087|\u0010O½O\b\u001b\u008d\u0080\u008bã¨É#\b\u0085\u0010]3\u0090L:b\bdÃº\u0084Ì'\u0086ì\bÌ\u0090$ôuîKé".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "uÉ\b\u0016íÃ°V\bÎÄ]´\u008a\u009f\u001b<";
                        length = "uÉ\b\u0016íÃ°V\bÎÄ]´\u008a\u009f\u001b<".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public FlightF(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.Vulcan_y] */
    /* JADX WARN: Type inference failed for: r0v16, types: [double] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [double] */
    /* JADX WARN: Type inference failed for: r0v22, types: [double] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_y] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r17v0, types: [double] */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2 */
    /* JADX WARN: Type inference failed for: r17v3 */
    /* JADX WARN: Type inference failed for: r1v10, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r4v1, types: [int, java.lang.Object[]] */
    private double Vulcan_P(Object[] objArr) {
        long jLongValue = (b ^ ((Long) objArr[0]).longValue()) ^ 32436472384601L;
        ?? Vulcan_m = Vulcan_m();
        ?? M639Vulcan_M = this.Vulcan_b.m639Vulcan_M(new Object[0]);
        ?? r4 = new Object[2];
        1[1] = Long.valueOf(jLongValue);
        r4[0] = Integer.valueOf((int) r4);
        Vulcan_y vulcan_yVulcan_Q = M639Vulcan_M.Vulcan_Q(r4);
        try {
            Vulcan_m = vulcan_yVulcan_Q;
            ?? r0 = Vulcan_m;
            if (Vulcan_m == 0) {
                try {
                    Vulcan_m = Vulcan_m.Vulcan_a(new Object[0]);
                    if (Vulcan_m == 0) {
                        r0 = vulcan_yVulcan_Q;
                    } else {
                        return 0.0d;
                    }
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) Vulcan_m);
                }
            }
            ?? Vulcan_K = (r0.Vulcan_K(new Object[0]) - this.Vulcan_b.m637Vulcan_r(new Object[0]).m710Vulcan_l(new Object[0])) * 0.9800000190734863d;
            ?? r17 = Vulcan_K;
            try {
                Vulcan_K = Math.abs((double) r17);
                ?? r172 = r17;
                if (Vulcan_K < (this.Vulcan_b.Vulcan_n(new Object[0]) ? 0.005d : 0.003d)) {
                    r172 = 0;
                }
                return r172;
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) Vulcan_K);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) Vulcan_m);
        }
    }
}
