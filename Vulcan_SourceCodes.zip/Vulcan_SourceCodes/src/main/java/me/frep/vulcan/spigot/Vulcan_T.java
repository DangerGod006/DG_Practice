package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_T.class */
public class Vulcan_T {
    private Object Vulcan_j;
    private Object Vulcan_I;

    public Vulcan_T(Object obj, Object obj2) {
        this.Vulcan_j = obj;
        this.Vulcan_I = obj2;
    }

    public Object Vulcan_X(Object[] objArr) {
        return this.Vulcan_j;
    }

    public Object Vulcan_S() {
        return this.Vulcan_I;
    }
}
