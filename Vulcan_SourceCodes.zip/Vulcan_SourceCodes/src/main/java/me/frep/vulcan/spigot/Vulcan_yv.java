package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.function.Function;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_yv.class */
public class Vulcan_yv {
    private final C0042Vulcan_Oz Vulcan_O;
    private static String Vulcan_a;
    private static final long a = Vulcan_n.a(6443796615697620495L, -8600852856877858363L, MethodHandles.lookup().lookupClass()).a(65517007104095L);

    public static void Vulcan_G(String str) {
        Vulcan_a = str;
    }

    public static String Vulcan_S() {
        return Vulcan_a;
    }

    static {
        if (Vulcan_S() == null) {
            Vulcan_G("bzacab");
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_yv(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_O = c0042Vulcan_Oz;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    public boolean Vulcan_r(Object[] objArr) {
        Vulcan_yU vulcan_yU = (Vulcan_yU) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_S = Vulcan_S();
        try {
            Vulcan_S = ((Boolean) vulcan_yU.Vulcan_n().apply(this.Vulcan_O)).booleanValue();
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_G("nKYuUb");
            }
            return Vulcan_S;
        } catch (RuntimeException unused) {
            throw a(Vulcan_S);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0099 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r1v6, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v0, types: [me.frep.vulcan.spigot.Vulcan_yv] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_L(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_yU[] r1 = (me.frep.vulcan.spigot.Vulcan_yU[]) r1
            r12 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_yv.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 9381728595377(0x8885a99adb1, double:4.635189797582E-311)
            long r1 = r1 ^ r2
            r13 = r1
            java.lang.String r0 = Vulcan_S()
            r1 = r12
            r16 = r1
            r15 = r0
            r0 = r16
            int r0 = r0.length
            r17 = r0
            r0 = 0
            r18 = r0
        L34:
            r0 = r18
            r1 = r17
            if (r0 >= r1) goto L98
            r0 = r16
            r1 = r18
            r0 = r0[r1]
            r19 = r0
            r0 = r15
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L88
            if (r0 == 0) goto L86
            r0 = r8
            r1 = r19
            r2 = r13
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            java.lang.Long r4 = java.lang.Long.valueOf(r4)     // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
            boolean r0 = r0.Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L6f java.lang.RuntimeException -> L79
        L67:
            r1 = r15
            if (r1 == 0) goto L99
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L79
            throw r0     // Catch: java.lang.RuntimeException -> L79
        L73:
            if (r0 == 0) goto L83
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7f
            throw r0     // Catch: java.lang.RuntimeException -> L7f
        L7d:
            r0 = 1
            return r0
        L7f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7f
            throw r0
        L83:
            int r18 = r18 + 1
        L86:
            r0 = r15
        L88:
            if (r0 != 0) goto L34
            r0 = 4
            r1 = r10
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 < 0) goto L67
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = new me.frep.vulcan.spigot.check.AbstractCheck[r0]
            me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_D(r0)
        L98:
            r0 = 0
        L99:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yv.Vulcan_L(java.lang.Object[]):boolean");
    }

    public boolean Vulcan_J(Object[] objArr) {
        return ((Boolean) ((Function) objArr[0]).apply(this.Vulcan_O)).booleanValue();
    }
}
