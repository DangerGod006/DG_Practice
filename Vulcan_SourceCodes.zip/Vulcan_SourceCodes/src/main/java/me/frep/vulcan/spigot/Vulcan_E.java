package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_E.class */
class Vulcan_E {
    private String Vulcan_d;
    private String Vulcan_x;
    private String Vulcan_c;
    final Vulcan_kZ Vulcan_t;

    static String Vulcan_H(Object[] objArr) {
        return ((Vulcan_E) objArr[0]).Vulcan_o(new Object[0]);
    }

    static String Vulcan_J(Object[] objArr) {
        return ((Vulcan_E) objArr[0]).Vulcan_O(new Object[0]);
    }

    static String Vulcan_Y(Object[] objArr) {
        return ((Vulcan_E) objArr[0]).Vulcan_n(new Object[0]);
    }

    Vulcan_E(Vulcan_kZ vulcan_kZ, String str, String str2, String str3, Vulcan_fs vulcan_fs) {
        this(vulcan_kZ, str, str2, str3);
    }

    private Vulcan_E(Vulcan_kZ vulcan_kZ, String str, String str2, String str3) {
        this.Vulcan_t = vulcan_kZ;
        this.Vulcan_d = str;
        this.Vulcan_x = str2;
        this.Vulcan_c = str3;
    }

    private String Vulcan_o(Object[] objArr) {
        return this.Vulcan_d;
    }

    private String Vulcan_O(Object[] objArr) {
        return this.Vulcan_x;
    }

    private String Vulcan_n(Object[] objArr) {
        return this.Vulcan_c;
    }
}
