package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_ff, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ff.class */
public final class C0046Vulcan_ff {
    private static int Vulcan_p;
    private static final long a = Vulcan_n.a(-5981838829597321436L, 7212765515223221361L, MethodHandles.lookup().lookupClass()).a(94724625509842L);
    private static final String[] b;

    public static void Vulcan_V(int i) {
        Vulcan_p = i;
    }

    public static int Vulcan_w() {
        return Vulcan_p;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_r() {
        return Vulcan_w() == 0 ? 121 : 0;
    }

    static {
        int i;
        long j = a ^ 14078711711726L;
        Vulcan_V(0);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[143];
        int i3 = 0;
        String str = "¬\u0090w\u001dÝ!\u0088ac.íå!e\u0010C\bÜ5÷yÏÙ\u00ad,\bu\u0098®ùçJ÷Â\b\u000eu¬ø\u008cí¯õ\bþ\u0080çÏ=\u0012àV\u0010\u0097þ\u0093õÍ\u0088Ëâ\u009dñÂ\u0000W¡Y(\b)\u0014ö%\"uö¤\u0010ìè@-v¯yÛïn\u008c\u0016ªQ³3\b\u0083~H\u000e\u008d\u0082W¤\u0010²¡\u0083\u00038ÆAø»û¯iÈ\u0004´@\bÈ\u0080Ù:rb}Á\b\u001aÍEq\u008b»±ñ\b45\u009fL\u007f)\u0000²\u0010êÅ*¨S««íÃ¸\u0087ãl\u0087R\u0094\bÆ&)l\u0016\u0085\u00010\bÀ\u000f\"´ôªÝ\u000b\b»=ëywþé«\u0010\u0083¾c]ûgÞg\u0001à\u0011Ã\u0083x2°\b \u008e\u009e-ýâ7\u0001\b²\u0081\u0005Ì\fV¡\u0019\b\u008b3ÿó½¾\u0082(\u0010BÓO\u0007Sº¹ÿ\u0088\r7\u0093\u0019\u008c¥í\u0010·§î\u0090Y¼\u0096-Oã¾ô;\u0000J°\b\u001b\u0089Ú\u0084ðÈ~h\b\u0088©ø\u0084´9Z+\u0010Ò\u0088É? ~\u0080Ò\u0099ìè=\nA\bå\u00106\u00158\u0017ÀZ\\\u0087x³\u008c\u009eíÏ¹É\u0010Ñ!\u0091õÝät*¨8õíã\u0091¢1\u0010\n·H|m÷ïÙs\u0099\u0097!Cý4¹\b\u001aÍEq\u008b»±ñ\bÒ\u0085¸Y\u00ad6@}\b6\u0012\t\u009c\u0090öW\u0086\bð\u0003°dgCéä\b\u0015Ú¡4Á¹\tí\u0010Ñ!\u0091õÝät*¨8õíã\u0091¢1\u0010r\u001dwÖÿ\u008fu¦M\u001c'~^¢¨q\u0010U\u0082N¦ËÌâá \u0012ò(ÌÚo\u0014\b4ÑÓ!¹½fr\b\u0015Ú¡4Á¹\tí\b¯Â§\u0015\u0080}Z\u0015\bXcf¶àr\u0085 \bÏ(NþS¡\u0011î\u0010Ü©&\u0090\u0095=£çü³ð¤êb\"0\b°·Á£°\u0017Dg\bÆ&)l\u0016\u0085\u00010\b\u000eÜ\u0093ø\n§Ð\u0013\u0010\u0006\u0086>'©\u0088¿\u001f\u0000\r×v@Ð\n\u0011\u0010BÚ×G2\u0017C\u0085\tØx\\¾Ð´V\b´(\u00002<hß¦\u0010£V\u0081\f%2f\u0085\fîVüªCy1\b \u008e\u009e-ýâ7\u0001\b\u0088©ø\u0084´9Z+\b¨\r=j\rV¶\u0001\u0010Y»)X\u008c¢ÊO× ÁÆïVoÍ\bihÊ\u008f\u0087\u0098`I\u0010(\u001bÆTs5Gà\u0010\u0098\u0011U¡\u000b}\u000f\u0010ß\u0003Ò\u0010%,*O\u009fz¤Åî\u0086åa\b\u00132\\æ\u0089\t<\u0001\b¦þM7Ýî\u009f/\b\u0088·\u0011¼|ú'r\bGÆ3\u00adÊJ\u0087\u00ad\b¥\u001cý5\u0083 \u0003\u0096\b¼Ã-)Õ<7«\bþ\u0080çÏ=\u0012àV\bª{!u\u009c\u0006àD\b}1¯Ìtkª\u008a\u0010\u0091ÀPÉ\u007fÏË\u0019¿o0à  a³\b\u000eÜ\u0093ø\n§Ð\u0013\bòÔ\u0085òæe\u0095U\u0018\u0005P\u0088\u001b>:4¶¥ü\u0019[\u0007ca<^góCm×Þ*\u0010Y/¢<\u0011\u001e\u008al¾üõá¬ÿ\u0001ö\b\u0097EK\u000f\u000f\u00019\u0095\b\bU¡\u009a´\u008a\u009e¼\u0010\u0000Z\u008c¸\"¨LS¨\rÖ¥\u0089mßE\b]ÁõÒÕ\r^ô\bPaØÇ>»öb\bÂR¨S^\u001cïx\u0010\u0012PËaar\u008a.'[\u0085ª\u0089c\u00adü\b\\\u0015³G\u008ah\u001bí\u0010\u008e{áHÛLÔ\r^Ý\u00018À©Js\bð\u0003°dgCéä\b\u0002L<t\u0006*Ï\u001c\b¼NÛ\u009f\u0001x\u000bÁ\u0010-\u007fc\u0097ù\u0093\u0098×z\u0017_2xøÎ&\u0018~×Ý\u0098G\u0081wS\u0015n:¾\r'\\Þö{6_Û\"ød\báÆ\u0006\u0088À\u001d\u0001\u0096\u0010\u0000Iõ³ïÞ\u0004\u001eÅ)áxXðüÔ\b¥\u001cý5\u0083 \u0003\u0096\u0010ñ!\u000b\b\u0010Ú`À\u0012T6ñHTO*\bª{!u\u009c\u0006àD\bù(<Ä.ýéÑ\u0010r\u001dwÖÿ\u008fu¦M\u001c'~^¢¨q\b\u000e\u0011Tª\u0001a×+\byÉ\u009c²[HK\u0017\u0010\u001a{Ñ;E\u0082iÑ\u001b\u009c\u008fÞ\u0000ÅÄI\u0010Y»)X\u008c¢ÊO× ÁÆïVoÍ\bf\u008dWØ³ãÝó\b\u009fÂÇ\b±p+\u0094\bPaØÇ>»öb\b\u000eu¬ø\u008cí¯õ\bó\u008a\u0007\u0001\u0092\u000b;Û\u0010³ÃõÂ\u0017¬\u0090bþlîq\r\u0092Ý\u001e\bÄ©©:.îÞ\u0003\b#\u00ad§F.Ld\u0005\b²\u0081\u0005Ì\fV¡\u0019\u0010\u009aÀ\u0090¤ïÄ\"øn\u0012rq\u009f\u0088r¹\u0018\u0005P\u0088\u001b>:4¶¥ü\u0019[\u0007ca<^góCm×Þ*\b\u0092)¾QÃÑc0\b\u0088·\u0011¼|ú'r\b\u001b\u0089Ú\u0084ðÈ~h\u0010Z2ÖuÂ\tGðÒgá/3-#\u0092\b\u0092ùÊ\u0093\u008d\u0088E\u009a\u00106\u00158\u0017ÀZ\\\u0087x³\u008c\u009eíÏ¹É\bF\u0096\u0007³á\u0092Õ²\u0010áC\u0093·\u0095\u001c\u0086\u0097\u0012¦3_\u008b¶|²\u00102û\u008cç®8\u0083%7¶NþÆgt\u0007\b\u001b\u0091\u001c§\u001aÛ\\Ü\u0010_\r¡ãù\txû\n\u0012\u0010Ií\u0096\u0010\n\bÜ5÷yÏÙ\u00ad,\u0010\u001a{Ñ;E\u0082iÑ\u001b\u009c\u008fÞ\u0000ÅÄI\u0010F9Auê\"\u0089·Cft~\u00193×c\b*åzÔ\u0089¸¤\u008c\b¶²\tíÑLY,\báÆ\u0006\u0088À\u001d\u0001\u0096\bê ËEºä\u0016\u00878®{\u0085·jñõö°¨ÐáÊü²GÍ²kì\u009c\u0014kyÄN\u001fV¬(Ê\u009fØ2T§\t\tÆØ\u0083\u001bÞ#ëi\u0016å\u0013(é^'\u0012\u008au\b\u0002L<t\u0006*Ï\u001c\b;a\u0016ã\u0090\u0019<\u0013\b\u0084Sïê¡E\u001d\u001d\bW4o*x/NÏ\u0018¸Ö\fåu_<y3\u0014s}Î\u0081½V\u0011XF\u00889²<¦\u0018Y/¢<\u0011\u001e\u008al¨Ñ\u009eê\u0000,ëÂ)!\u0013yï\u009em\u008c\u0010\u0018\u0001ë©Aä`dõ1 \u008bÛ¬\u001f+\u0010U\u0082N¦ËÌâá \u0012ò(ÌÚo\u0014\b\u0095ÔB'4\u001eÒÉ\bW4o*x/NÏ\b\u0081\u0007¸W#\u0001ô¶\bÏ(NþS¡\u0011î\bµ\"\u0012À\u0010:\u001bI\b\u0084Sïê¡E\u001d\u001d\b2%\r\u000bÀÈyÌ";
        int length = "¬\u0090w\u001dÝ!\u0088ac.íå!e\u0010C\bÜ5÷yÏÙ\u00ad,\bu\u0098®ùçJ÷Â\b\u000eu¬ø\u008cí¯õ\bþ\u0080çÏ=\u0012àV\u0010\u0097þ\u0093õÍ\u0088Ëâ\u009dñÂ\u0000W¡Y(\b)\u0014ö%\"uö¤\u0010ìè@-v¯yÛïn\u008c\u0016ªQ³3\b\u0083~H\u000e\u008d\u0082W¤\u0010²¡\u0083\u00038ÆAø»û¯iÈ\u0004´@\bÈ\u0080Ù:rb}Á\b\u001aÍEq\u008b»±ñ\b45\u009fL\u007f)\u0000²\u0010êÅ*¨S««íÃ¸\u0087ãl\u0087R\u0094\bÆ&)l\u0016\u0085\u00010\bÀ\u000f\"´ôªÝ\u000b\b»=ëywþé«\u0010\u0083¾c]ûgÞg\u0001à\u0011Ã\u0083x2°\b \u008e\u009e-ýâ7\u0001\b²\u0081\u0005Ì\fV¡\u0019\b\u008b3ÿó½¾\u0082(\u0010BÓO\u0007Sº¹ÿ\u0088\r7\u0093\u0019\u008c¥í\u0010·§î\u0090Y¼\u0096-Oã¾ô;\u0000J°\b\u001b\u0089Ú\u0084ðÈ~h\b\u0088©ø\u0084´9Z+\u0010Ò\u0088É? ~\u0080Ò\u0099ìè=\nA\bå\u00106\u00158\u0017ÀZ\\\u0087x³\u008c\u009eíÏ¹É\u0010Ñ!\u0091õÝät*¨8õíã\u0091¢1\u0010\n·H|m÷ïÙs\u0099\u0097!Cý4¹\b\u001aÍEq\u008b»±ñ\bÒ\u0085¸Y\u00ad6@}\b6\u0012\t\u009c\u0090öW\u0086\bð\u0003°dgCéä\b\u0015Ú¡4Á¹\tí\u0010Ñ!\u0091õÝät*¨8õíã\u0091¢1\u0010r\u001dwÖÿ\u008fu¦M\u001c'~^¢¨q\u0010U\u0082N¦ËÌâá \u0012ò(ÌÚo\u0014\b4ÑÓ!¹½fr\b\u0015Ú¡4Á¹\tí\b¯Â§\u0015\u0080}Z\u0015\bXcf¶àr\u0085 \bÏ(NþS¡\u0011î\u0010Ü©&\u0090\u0095=£çü³ð¤êb\"0\b°·Á£°\u0017Dg\bÆ&)l\u0016\u0085\u00010\b\u000eÜ\u0093ø\n§Ð\u0013\u0010\u0006\u0086>'©\u0088¿\u001f\u0000\r×v@Ð\n\u0011\u0010BÚ×G2\u0017C\u0085\tØx\\¾Ð´V\b´(\u00002<hß¦\u0010£V\u0081\f%2f\u0085\fîVüªCy1\b \u008e\u009e-ýâ7\u0001\b\u0088©ø\u0084´9Z+\b¨\r=j\rV¶\u0001\u0010Y»)X\u008c¢ÊO× ÁÆïVoÍ\bihÊ\u008f\u0087\u0098`I\u0010(\u001bÆTs5Gà\u0010\u0098\u0011U¡\u000b}\u000f\u0010ß\u0003Ò\u0010%,*O\u009fz¤Åî\u0086åa\b\u00132\\æ\u0089\t<\u0001\b¦þM7Ýî\u009f/\b\u0088·\u0011¼|ú'r\bGÆ3\u00adÊJ\u0087\u00ad\b¥\u001cý5\u0083 \u0003\u0096\b¼Ã-)Õ<7«\bþ\u0080çÏ=\u0012àV\bª{!u\u009c\u0006àD\b}1¯Ìtkª\u008a\u0010\u0091ÀPÉ\u007fÏË\u0019¿o0à  a³\b\u000eÜ\u0093ø\n§Ð\u0013\bòÔ\u0085òæe\u0095U\u0018\u0005P\u0088\u001b>:4¶¥ü\u0019[\u0007ca<^góCm×Þ*\u0010Y/¢<\u0011\u001e\u008al¾üõá¬ÿ\u0001ö\b\u0097EK\u000f\u000f\u00019\u0095\b\bU¡\u009a´\u008a\u009e¼\u0010\u0000Z\u008c¸\"¨LS¨\rÖ¥\u0089mßE\b]ÁõÒÕ\r^ô\bPaØÇ>»öb\bÂR¨S^\u001cïx\u0010\u0012PËaar\u008a.'[\u0085ª\u0089c\u00adü\b\\\u0015³G\u008ah\u001bí\u0010\u008e{áHÛLÔ\r^Ý\u00018À©Js\bð\u0003°dgCéä\b\u0002L<t\u0006*Ï\u001c\b¼NÛ\u009f\u0001x\u000bÁ\u0010-\u007fc\u0097ù\u0093\u0098×z\u0017_2xøÎ&\u0018~×Ý\u0098G\u0081wS\u0015n:¾\r'\\Þö{6_Û\"ød\báÆ\u0006\u0088À\u001d\u0001\u0096\u0010\u0000Iõ³ïÞ\u0004\u001eÅ)áxXðüÔ\b¥\u001cý5\u0083 \u0003\u0096\u0010ñ!\u000b\b\u0010Ú`À\u0012T6ñHTO*\bª{!u\u009c\u0006àD\bù(<Ä.ýéÑ\u0010r\u001dwÖÿ\u008fu¦M\u001c'~^¢¨q\b\u000e\u0011Tª\u0001a×+\byÉ\u009c²[HK\u0017\u0010\u001a{Ñ;E\u0082iÑ\u001b\u009c\u008fÞ\u0000ÅÄI\u0010Y»)X\u008c¢ÊO× ÁÆïVoÍ\bf\u008dWØ³ãÝó\b\u009fÂÇ\b±p+\u0094\bPaØÇ>»öb\b\u000eu¬ø\u008cí¯õ\bó\u008a\u0007\u0001\u0092\u000b;Û\u0010³ÃõÂ\u0017¬\u0090bþlîq\r\u0092Ý\u001e\bÄ©©:.îÞ\u0003\b#\u00ad§F.Ld\u0005\b²\u0081\u0005Ì\fV¡\u0019\u0010\u009aÀ\u0090¤ïÄ\"øn\u0012rq\u009f\u0088r¹\u0018\u0005P\u0088\u001b>:4¶¥ü\u0019[\u0007ca<^góCm×Þ*\b\u0092)¾QÃÑc0\b\u0088·\u0011¼|ú'r\b\u001b\u0089Ú\u0084ðÈ~h\u0010Z2ÖuÂ\tGðÒgá/3-#\u0092\b\u0092ùÊ\u0093\u008d\u0088E\u009a\u00106\u00158\u0017ÀZ\\\u0087x³\u008c\u009eíÏ¹É\bF\u0096\u0007³á\u0092Õ²\u0010áC\u0093·\u0095\u001c\u0086\u0097\u0012¦3_\u008b¶|²\u00102û\u008cç®8\u0083%7¶NþÆgt\u0007\b\u001b\u0091\u001c§\u001aÛ\\Ü\u0010_\r¡ãù\txû\n\u0012\u0010Ií\u0096\u0010\n\bÜ5÷yÏÙ\u00ad,\u0010\u001a{Ñ;E\u0082iÑ\u001b\u009c\u008fÞ\u0000ÅÄI\u0010F9Auê\"\u0089·Cft~\u00193×c\b*åzÔ\u0089¸¤\u008c\b¶²\tíÑLY,\báÆ\u0006\u0088À\u001d\u0001\u0096\bê ËEºä\u0016\u00878®{\u0085·jñõö°¨ÐáÊü²GÍ²kì\u009c\u0014kyÄN\u001fV¬(Ê\u009fØ2T§\t\tÆØ\u0083\u001bÞ#ëi\u0016å\u0013(é^'\u0012\u008au\b\u0002L<t\u0006*Ï\u001c\b;a\u0016ã\u0090\u0019<\u0013\b\u0084Sïê¡E\u001d\u001d\bW4o*x/NÏ\u0018¸Ö\fåu_<y3\u0014s}Î\u0081½V\u0011XF\u00889²<¦\u0018Y/¢<\u0011\u001e\u008al¨Ñ\u009eê\u0000,ëÂ)!\u0013yï\u009em\u008c\u0010\u0018\u0001ë©Aä`dõ1 \u008bÛ¬\u001f+\u0010U\u0082N¦ËÌâá \u0012ò(ÌÚo\u0014\b\u0095ÔB'4\u001eÒÉ\bW4o*x/NÏ\b\u0081\u0007¸W#\u0001ô¶\bÏ(NþS¡\u0011î\bµ\"\u0012À\u0010:\u001bI\b\u0084Sïê¡E\u001d\u001d\b2%\r\u000bÀÈyÌ".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Ä©©:.îÞ\u0003\b\u008e**\u0098Ë÷°\u001f";
                        length = "Ä©©:.îÞ\u0003\b\u008e**\u0098Ë÷°\u001f".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private C0046Vulcan_ff() {
        throw new UnsupportedOperationException(b[125]);
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x006a, code lost:
    
        if (r0 <= (r1 + r1)) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x006d, code lost:
    
        r18 = r1 - r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0073, code lost:
    
        r0 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x007b, code lost:
    
        if (r0 > ((r1 + r1) + 1)) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x007e, code lost:
    
        r0 = r1 - r1;
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0083, code lost:
    
        if (r1 == null) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0086, code lost:
    
        r19 = r0 == true ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x008d, code lost:
    
        if (r19 > (r1 + r1)) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0090, code lost:
    
        r0 = r1.isChunkLoaded(r17 >> 4, (r19 == true ? 1 : 0) >> 4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00a1, code lost:
    
        if (r0 == null) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00a4, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00aa, code lost:
    
        if (r0 < 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00ad, code lost:
    
        if (r1 == null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00b0, code lost:
    
        if (r0 == 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00ba, code lost:
    
        r1.add(r1.getBlockAt(r17, r18, r19 == true ? 1 : 0).getType());
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00da, code lost:
    
        if (r0 < 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00dd, code lost:
    
        if (r0 != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00e3, code lost:
    
        r0 = a((java.lang.UnsupportedOperationException) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00e6, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e7, code lost:
    
        r1.add(org.bukkit.Material.SPONGE);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00f7, code lost:
    
        throw a((java.lang.UnsupportedOperationException) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00f9, code lost:
    
        r19 = r19 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00fe, code lost:
    
        if (r0 != null) goto L71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0101, code lost:
    
        r18 = r18 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x010a, code lost:
    
        if (r0 <= 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x010d, code lost:
    
        if (r0 != null) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0110, code lost:
    
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0117, code lost:
    
        if (r0 <= 0) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x011a, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011c, code lost:
    
        if (r0 != null) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0123, code lost:
    
        if (r0 < 0) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0128, code lost:
    
        return r1;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:13:0x006d, B:50:0x011f], limit reached: 66 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v21, types: [int] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:47:0x0117 -> B:17:0x007e). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x0123 -> B:13:0x006d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_E(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_E(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x006b, code lost:
    
        if (r0 <= (r1 + r1)) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x006e, code lost:
    
        r18 = r1 - r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0075, code lost:
    
        r0 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x007e, code lost:
    
        if (r0 > ((r1 + r1) + 1)) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0081, code lost:
    
        r0 = r1 - r1;
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0087, code lost:
    
        if (r1 == null) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x008a, code lost:
    
        r19 = r0 == true ? 1 : 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0092, code lost:
    
        if (r19 > (r1 + r1)) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0095, code lost:
    
        r0 = r1.isChunkLoaded(r17 >> 4, (r19 == true ? 1 : 0) >> 4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00a5, code lost:
    
        if (r0 == null) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00a8, code lost:
    
        r1 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ad, code lost:
    
        if (r0 < 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00b0, code lost:
    
        if (r1 == null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00b3, code lost:
    
        if (r0 == 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00bd, code lost:
    
        r1.add(r1.getBlockAt(r17, r18, r19 == true ? 1 : 0).getType());
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00db, code lost:
    
        if (r0 < 0) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00de, code lost:
    
        if (r0 != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00e4, code lost:
    
        r0 = a((java.lang.UnsupportedOperationException) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00e7, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00e8, code lost:
    
        r1.add(org.bukkit.Material.SPONGE);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00f8, code lost:
    
        throw a((java.lang.UnsupportedOperationException) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00fa, code lost:
    
        r19 = r19 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00ff, code lost:
    
        if (r0 != null) goto L71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0102, code lost:
    
        r18 = r18 + 1;
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x010a, code lost:
    
        if (r0 <= 0) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x010d, code lost:
    
        if (r0 != null) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0110, code lost:
    
        r17 = r17 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0116, code lost:
    
        if (r0 < 0) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0119, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x011b, code lost:
    
        if (r0 != null) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0121, code lost:
    
        if (r0 <= 0) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0126, code lost:
    
        return r1;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:13:0x006e, B:50:0x011e], limit reached: 66 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v21, types: [int] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:47:0x0116 -> B:17:0x0081). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x0121 -> B:13:0x006e). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.List Vulcan_f(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_f(java.lang.Object[]):java.util.List");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.util.List Vulcan_l(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_l(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [org.bukkit.World] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException, me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v6, types: [org.bukkit.World] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static Material Vulcan_T(Object[] objArr) {
        World world = (World) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        int iIntValue = ((Integer) objArr[2]).intValue();
        int iIntValue2 = ((Integer) objArr[3]).intValue();
        int iIntValue3 = ((Integer) objArr[4]).intValue();
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            World world2 = world;
            ?? A = world2;
            if (Vulcan_q != 0) {
                if (world2 == null) {
                    return Material.SPONGE;
                }
                A = world;
            }
            try {
                try {
                    int i = iIntValue >> 4;
                    int i2 = iIntValue3;
                    int i3 = 4;
                    ?? r0 = A;
                    if (j > 0) {
                        i2 >>= 4;
                        ?? r02 = A;
                        if (Vulcan_q != 0) {
                            A = A.isChunkLoaded(i, i2);
                            if (A != 0) {
                                r02 = world;
                                i = iIntValue;
                                i2 = iIntValue2;
                            } else {
                                return Material.SPONGE;
                            }
                        }
                        i3 = iIntValue3;
                        r0 = r02;
                    }
                    return r0.getBlockAt(i, i2, i3).getType();
                } catch (UnsupportedOperationException unused) {
                    A = a((UnsupportedOperationException) A);
                    throw A;
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) A);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_aQ(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[37]);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0092 A[EXC_TOP_SPLITTER, PHI: r0 r10
  0x0092: PHI (r0v28 ??) = (r0v41 ??), (r0v42 ??) binds: [B:5:0x001e, B:31:0x008f] A[DONT_GENERATE, DONT_INLINE]
  0x0092: PHI (r10v3 char) = (r10v0 char), (r10v2 char) binds: [B:5:0x001e, B:31:0x008f] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:61:0x006b A[EXC_TOP_SPLITTER, PHI: r0 r10
  0x006b: PHI (r0v19 ??) = (r0v43 ??), (r0v44 ??) binds: [B:5:0x001e, B:19:0x0068] A[DONT_GENERATE, DONT_INLINE]
  0x006b: PHI (r10v1 char) = (r10v0 char), (r10v6 char) binds: [B:5:0x001e, B:19:0x0068] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v34, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_x(org.bukkit.Material r5) {
        /*
            Method dump skipped, instruction units count: 224
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_x(org.bukkit.Material):boolean");
    }

    public static boolean Vulcan_al(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[120]);
    }

    public static boolean Vulcan_as(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[101]);
    }

    public static boolean Vulcan_a6(Material material) {
        return material.isSolid();
    }

    public static boolean Vulcan_aw(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[139]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_av(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[22]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEquals = material.toString().equals(b[127]);
                        if (Vulcan_q == 0) {
                            return zEquals;
                        }
                        if (!zEquals) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_Z(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[35]);
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public static boolean m690Vulcan_f(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[142]);
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public static boolean m691Vulcan_T(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[25]);
    }

    public static boolean Vulcan_aG(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[86]);
    }

    public static boolean Vulcan_aI(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[58]);
    }

    public static boolean Vulcan_aS(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[71]);
    }

    public static boolean Vulcan_v(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[56]);
    }

    public static boolean Vulcan_s(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[3]);
    }

    public static boolean Vulcan_X(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[76]);
    }

    public static boolean Vulcan_n(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[4]);
    }

    public static boolean Vulcan_aD(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[62]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003f  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_ab(org.bukkit.Material r5) {
        /*
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = 79961390248801(0x48b97642f361, double:3.9506175915638E-310)
            long r0 = r0 ^ r1
            r6 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r8 = r0
            r0 = r5
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L23
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L23
            r2 = 121(0x79, float:1.7E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L23
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L23
            r1 = r8
            if (r1 == 0) goto L3b
            if (r0 == 0) goto L4d
            goto L27
        L23:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L37
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L37
        L27:
            r0 = r5
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L37
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L37
            r2 = 63
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L37
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L37
            goto L3b
        L37:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L3b:
            r1 = r8
            if (r1 == 0) goto L4a
            if (r0 != 0) goto L4d
            goto L49
        L45:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L49:
            r0 = 1
        L4a:
            goto L4e
        L4d:
            r0 = 0
        L4e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_ab(org.bukkit.Material):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_af(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 123(0x7b, float:1.72E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 85
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 == 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_af(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_a8(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[4]);
    }

    public static boolean Vulcan_ar(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[46]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_aX(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 124(0x7c, float:1.74E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 16
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 == 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_aX(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_aK(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[0]);
    }

    public static boolean Vulcan_aP(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[60]);
    }

    public static boolean Vulcan_aU(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[79]);
    }

    public static boolean Vulcan_aa(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[132]);
    }

    public static boolean Vulcan__(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[97]);
    }

    public static boolean Vulcan_m(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[40]);
    }

    public static boolean Vulcan_k(Object[] objArr) {
        return ((Material) objArr[0]).toString().equalsIgnoreCase(b[103]);
    }

    public static boolean Vulcan_a9(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[9]);
    }

    public static boolean Vulcan_aR(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[2]);
    }

    public static boolean Vulcan_S(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[115]);
    }

    public static boolean Vulcan_ak(Object[] objArr) {
        return ((Material) objArr[0]).toString().equalsIgnoreCase(b[69]);
    }

    public static boolean Vulcan_h(Material material) {
        return material.toString().contains(b[10]);
    }

    public static boolean Vulcan_az(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[75]);
    }

    public static boolean Vulcan_a0(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[20]);
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static boolean m692Vulcan_l(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[44]);
    }

    public static boolean Vulcan_B(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[14]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_KG(Object[] objArr) {
        Block block = (Block) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    try {
                        try {
                            Vulcan_q = block.getType().toString().contains(b[59]);
                            if (Vulcan_q == 0) {
                                return Vulcan_q;
                            }
                            if (Vulcan_q == 0) {
                                boolean zContains = block.getType().toString().contains(b[18]);
                                if (Vulcan_q == 0) {
                                    return zContains;
                                }
                                if (!zContains) {
                                    boolean zEqualsIgnoreCase = block.getType().toString().equalsIgnoreCase(b[27]);
                                    if (Vulcan_q == 0) {
                                        return zEqualsIgnoreCase;
                                    }
                                    if (!zEqualsIgnoreCase) {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused) {
                            throw a((UnsupportedOperationException) Vulcan_q);
                        }
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_aE(Object[] objArr) {
        Material material = (Material) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[108]);
                    try {
                        try {
                            if (Vulcan_q == 0) {
                                return Vulcan_q;
                            }
                            if (Vulcan_q == 0) {
                                boolean zContains = material.toString().contains(b[50]);
                                if (Vulcan_q == 0) {
                                    return zContains;
                                }
                                if (!zContains) {
                                    boolean zEquals = material.toString().equals(b[34]);
                                    if (Vulcan_q == 0) {
                                        return zEquals;
                                    }
                                    if (!zEquals) {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused) {
                            throw a((UnsupportedOperationException) Vulcan_q);
                        }
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_D(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[90]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_b(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Block block = (Block) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    try {
                        try {
                            Vulcan_q = block.getType().toString().contains(b[99]);
                            if (Vulcan_q == 0) {
                                return Vulcan_q;
                            }
                            if (Vulcan_q == 0) {
                                boolean zContains = block.getType().toString().contains(b[118]);
                                if (Vulcan_q == 0) {
                                    return zContains;
                                }
                                if (!zContains) {
                                    boolean zContains2 = block.getType().toString().contains(b[89]);
                                    if (Vulcan_q == 0) {
                                        return zContains2;
                                    }
                                    if (!zContains2) {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused) {
                            throw a((UnsupportedOperationException) Vulcan_q);
                        }
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_a1(Material material) {
        long j = a ^ 74577976847975L;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    try {
                        Vulcan_q = material.toString().contains(b[99]);
                        if (Vulcan_q == 0) {
                            return Vulcan_q;
                        }
                        if (Vulcan_q == 0) {
                            try {
                                boolean zContains = material.toString().contains(b[1]);
                                if (Vulcan_q == 0) {
                                    return zContains;
                                }
                                if (!zContains) {
                                    boolean zContains2 = material.toString().contains(b[64]);
                                    if (Vulcan_q == 0) {
                                        return zContains2;
                                    }
                                    if (!zContains2) {
                                        return false;
                                    }
                                }
                            } catch (UnsupportedOperationException unused) {
                                throw a((UnsupportedOperationException) Vulcan_q);
                            }
                        }
                        return true;
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_L(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[134]);
    }

    public static boolean Vulcan_z(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[77]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_p(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            org.bukkit.block.Block r1 = (org.bukkit.block.Block) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r8
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.UnsupportedOperationException -> L3b
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L3b
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L3b
            r2 = 48
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L3b
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L3b
            r1 = r9
            if (r1 == 0) goto L58
            if (r0 == 0) goto L6b
            goto L3f
        L3b:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L54
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L54
        L3f:
            r0 = r8
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.UnsupportedOperationException -> L54
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L54
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L54
            r2 = 116(0x74, float:1.63E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L54
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L54
            goto L58
        L54:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L58:
            r1 = r9
            if (r1 == 0) goto L68
            if (r0 == 0) goto L6b
            goto L67
        L63:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L67:
            r0 = 1
        L68:
            goto L6c
        L6b:
            r0 = 0
        L6c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_p(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_j(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[7]);
    }

    public static boolean Vulcan_G(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[135]);
    }

    public static boolean Vulcan_Q(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[129]);
    }

    public static boolean Vulcan_Ks(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[109]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_aL(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[23]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEquals = material.toString().equals(b[52]);
                        if (Vulcan_q == 0) {
                            return zEquals;
                        }
                        if (!zEquals) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_KR(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[61]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_o(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[87]);
                    try {
                        try {
                            if (Vulcan_q == 0) {
                                return Vulcan_q;
                            }
                            if (Vulcan_q == 0) {
                                boolean zEquals = material.toString().equals(b[21]);
                                if (Vulcan_q == 0) {
                                    return zEquals;
                                }
                                if (!zEquals) {
                                    boolean zEquals2 = material.toString().equals(b[88]);
                                    if (Vulcan_q == 0) {
                                        return zEquals2;
                                    }
                                    if (!zEquals2) {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused) {
                            throw a((UnsupportedOperationException) Vulcan_q);
                        }
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_d(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[43]);
    }

    public static boolean Vulcan_i(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[65]);
    }

    public static boolean Vulcan_G(Material material) {
        return material.toString().equals(b[105]);
    }

    public static boolean Vulcan_KK(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[82]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_h(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Block block = (Block) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = block.getType().toString().equals(b[36]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = block.getType().toString().contains(b[36]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_aY(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[133]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_r(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 100
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4f
            if (r0 == 0) goto L62
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4b
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4b
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4b
            r2 = 128(0x80, float:1.8E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4b
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4b
            goto L4f
        L4b:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4f:
            r1 = r9
            if (r1 == 0) goto L5f
            if (r0 != 0) goto L62
            goto L5e
        L5a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5e:
            r0 = 1
        L5f:
            goto L63
        L62:
            r0 = 0
        L63:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_r(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_Kj(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[72]);
    }

    public static boolean Vulcan_au(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[73]);
    }

    public static boolean Vulcan_V(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[106]);
    }

    public static boolean Vulcan_P(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[107]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_y(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[117]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEquals = material.toString().equals(b[5]);
                        if (Vulcan_q == 0) {
                            return zEquals;
                        }
                        if (!zEquals) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_I(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 111(0x6f, float:1.56E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 92
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.equals(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 != 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_I(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_g(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[85]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_aN(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[130]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEquals = material.toString().equals(b[84]);
                        if (Vulcan_q == 0) {
                            return zEquals;
                        }
                        if (!zEquals) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_F(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[32]);
    }

    public static boolean Vulcan_ah(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[80]);
    }

    public static boolean Vulcan_w(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[70]);
    }

    public static boolean Vulcan_c(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[131]);
    }

    public static boolean Vulcan_u(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[126]);
    }

    public static boolean Vulcan_q(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[81]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_K3(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Block block = (Block) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = block.getType().toString().contains(b[19]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = block.getType().toString().contains(b[41]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_l(Material material) {
        long j = a ^ 3039424112735L;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().contains(b[104]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = material.toString().contains(b[137]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_a4(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 31
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 98
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 == 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_a4(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_C(Object[] objArr) {
        Block block = (Block) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = block.getType().toString().contains(b[24]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = block.getType().toString().contains(b[141]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_aJ(Object[] objArr) {
        Material material = (Material) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().contains(b[51]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = material.toString().contains(b[102]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_Kd(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[54]);
    }

    public static boolean Vulcan_M(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[110]);
    }

    public static boolean Vulcan_Kz(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[89]);
    }

    public static boolean Vulcan_aq(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[66]);
    }

    public static boolean Vulcan_K(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().equals(b[27]);
    }

    public static boolean Vulcan_aW(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[27]);
    }

    public static boolean Vulcan_x(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[26]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_t(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[112]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEquals = material.toString().equals(b[28]);
                        if (Vulcan_q == 0) {
                            return zEquals;
                        }
                        if (!zEquals) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_A(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[8]);
    }

    public static boolean Vulcan_aH(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[114]);
    }

    public static boolean Vulcan_R(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[95]);
    }

    public static boolean Vulcan_W(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[29]);
    }

    public static boolean Vulcan_aF(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[11]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_aV(Object[] objArr) {
        Material material = (Material) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[15]);
                    try {
                        try {
                            if (Vulcan_q == 0) {
                                return Vulcan_q;
                            }
                            if (Vulcan_q == 0) {
                                Vulcan_q = material.toString().equals(b[47]);
                                if (Vulcan_q == 0) {
                                    return Vulcan_q;
                                }
                                try {
                                    try {
                                        if (Vulcan_q == 0) {
                                            boolean zEquals = material.toString().equals(b[91]);
                                            if (Vulcan_q == 0) {
                                                return zEquals;
                                            }
                                            if (!zEquals) {
                                                boolean zEquals2 = material.toString().equals(b[53]);
                                                if (Vulcan_q == 0) {
                                                    return zEquals2;
                                                }
                                                if (!zEquals2) {
                                                    return false;
                                                }
                                            }
                                        }
                                    } catch (UnsupportedOperationException unused) {
                                        throw a((UnsupportedOperationException) Vulcan_q);
                                    }
                                } catch (UnsupportedOperationException unused2) {
                                    throw a((UnsupportedOperationException) Vulcan_q);
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused3) {
                            throw a((UnsupportedOperationException) Vulcan_q);
                        }
                    } catch (UnsupportedOperationException unused4) {
                        throw a((UnsupportedOperationException) Vulcan_q);
                    }
                } catch (UnsupportedOperationException unused5) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused6) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused7) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_K_(Object[] objArr) {
        Block block = (Block) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = block.getType().toString().contains(b[93]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zContains = block.getType().toString().contains(b[6]);
                        if (Vulcan_q == 0) {
                            return zContains;
                        }
                        if (!zContains) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_Y(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[33]);
    }

    public static boolean Vulcan_aM(Object[] objArr) {
        return ((Material) objArr[0]).toString().equals(b[38]);
    }

    public static boolean Vulcan_Kk(Object[] objArr) {
        return ((Block) objArr[0]).getType().toString().contains(b[140]);
    }

    public static boolean Vulcan_N(Object[] objArr) {
        return ((Material) objArr[0]).toString().equalsIgnoreCase(b[94]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_a(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().equals(b[119]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEqualsIgnoreCase = material.toString().equalsIgnoreCase(b[83]);
                        if (Vulcan_q == 0) {
                            return zEqualsIgnoreCase;
                        }
                        if (!zEqualsIgnoreCase) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.UnsupportedOperationException] */
    public static boolean Vulcan_ag(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Material material = (Material) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        try {
            try {
                try {
                    Vulcan_q = material.toString().contains(b[45]);
                    if (Vulcan_q == 0) {
                        return Vulcan_q;
                    }
                    if (Vulcan_q == 0) {
                        boolean zEqualsIgnoreCase = material.toString().equalsIgnoreCase(b[67]);
                        if (Vulcan_q == 0) {
                            return zEqualsIgnoreCase;
                        }
                        if (!zEqualsIgnoreCase) {
                            return false;
                        }
                    }
                    return true;
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) Vulcan_q);
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused3) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    public static boolean Vulcan_aC(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[17]);
    }

    public static boolean Vulcan_e(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[68]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m693Vulcan_E(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L37
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L37
            r2 = 138(0x8a, float:1.93E-43)
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L37
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L37
            r1 = r9
            if (r1 == 0) goto L4f
            if (r0 == 0) goto L62
            goto L3b
        L37:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4b
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4b
        L3b:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4b
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4b
            r2 = 30
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4b
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4b
            goto L4f
        L4b:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4f:
            r1 = r9
            if (r1 == 0) goto L5f
            if (r0 != 0) goto L62
            goto L5e
        L5a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5e:
            r0 = 1
        L5f:
            goto L63
        L62:
            r0 = 0
        L63:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.m693Vulcan_E(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_O(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[74]);
    }

    public static boolean Vulcan_ai(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[136]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_H(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r8 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r8
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 13
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r8
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 96
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 == 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_H(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_an(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[42]);
    }

    public static boolean Vulcan_ad(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[39]);
    }

    public static boolean Vulcan_aB(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[57]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean Vulcan_J(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            org.bukkit.Material r1 = (org.bukkit.Material) r1
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = me.frep.vulcan.spigot.C0046Vulcan_ff.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L36
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L36
            r2 = 78
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L36
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L36
            r1 = r9
            if (r1 == 0) goto L4e
            if (r0 == 0) goto L61
            goto L3a
        L36:
            java.lang.UnsupportedOperationException r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4a
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4a
        L3a:
            r0 = r6
            java.lang.String r0 = r0.toString()     // Catch: java.lang.UnsupportedOperationException -> L4a
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0046Vulcan_ff.b     // Catch: java.lang.UnsupportedOperationException -> L4a
            r2 = 12
            r1 = r1[r2]     // Catch: java.lang.UnsupportedOperationException -> L4a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.UnsupportedOperationException -> L4a
            goto L4e
        L4a:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L4e:
            r1 = r9
            if (r1 == 0) goto L5e
            if (r0 == 0) goto L61
            goto L5d
        L59:
            java.lang.UnsupportedOperationException r0 = a(r0)
            throw r0
        L5d:
            r0 = 1
        L5e:
            goto L62
        L61:
            r0 = 0
        L62:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_J(java.lang.Object[]):boolean");
    }

    public static boolean Vulcan_U(Object[] objArr) {
        return ((Material) objArr[0]).toString().contains(b[122]);
    }
}
