package me.frep.vulcan.spigot;

import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fh.class */
public final class Vulcan_fh {
    private final Set Vulcan_r = new HashSet();
    private Object Vulcan_l;

    public Vulcan_fh(Object obj) {
        this.Vulcan_l = obj;
    }

    public Object Vulcan_r(Object[] objArr) {
        return this.Vulcan_l;
    }

    public void Vulcan_v(Object[] objArr) {
        Object obj = objArr[0];
        Object obj2 = this.Vulcan_l;
        this.Vulcan_l = obj;
        this.Vulcan_r.forEach((v2) -> {
            lambda$set$0(r1, r2, v2);
        });
    }

    private static void lambda$set$0(Object obj, Object obj2, Vulcan_kk vulcan_kk) {
        vulcan_kk.Vulcan_I(new Object[]{obj, obj2});
    }

    public Vulcan_kk Vulcan_Y(Object[] objArr) {
        Vulcan_kk vulcan_kk = (Vulcan_kk) objArr[0];
        this.Vulcan_r.add(vulcan_kk);
        return vulcan_kk;
    }

    public void Vulcan_a(Object[] objArr) {
        this.Vulcan_r.remove((Vulcan_kk) objArr[0]);
    }
}
