package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_i.class */
public interface Vulcan_i {
    void a(Vulcan_i vulcan_i);

    int[] b();

    long a(long j);

    void b(long j);

    boolean b(Vulcan_i vulcan_i);
}
