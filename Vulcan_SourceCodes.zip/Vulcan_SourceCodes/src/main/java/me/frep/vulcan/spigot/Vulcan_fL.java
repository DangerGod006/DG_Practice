package me.frep.vulcan.spigot;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterators;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Found several "values" enum fields: [] */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fL.class */
public final class Vulcan_fL implements Predicate, Iterable {
    public static final Vulcan_fL HORIZONTAL;
    public static final Vulcan_fL VERTICAL;
    private static final Vulcan_fL[] Vulcan_q;
    private static final String Vulcan_G;
    private static final Vulcan_fL[] Vulcan_d;
    private static final long a = Vulcan_n.a(-4132423415364036762L, -4924613584132326646L, MethodHandles.lookup().lookupClass()).a(198684550236588L);
    private static final String[] b;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public static Vulcan_fL[] values() {
        return (Vulcan_fL[]) Vulcan_d.clone();
    }

    public static Vulcan_fL valueOf(String str) {
        return (Vulcan_fL) Enum.valueOf(Vulcan_fL.class, str);
    }

    static {
        int i;
        long j = a ^ 65971402223405L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[6];
        int i3 = 0;
        String str = "Pð\u0085\\%ú\u000b{Ìõ\u00ad*;#\u0017\u0000\u0010\"\u009eyÉÓX\u0088êy\"L\u008f\u0091*ZÕ\u0010\u009aºên,ªS\u0094xýZèm\u0014gÊ\u0010Pð\u0085\\%ú\u000b{Ìõ\u00ad*;#\u0017\u0000";
        int length = "Pð\u0085\\%ú\u000b{Ìõ\u00ad*;#\u0017\u0000\u0010\"\u009eyÉÓX\u0088êy\"L\u008f\u0091*ZÕ\u0010\u009aºên,ªS\u0094xýZèm\u0014gÊ\u0010Pð\u0085\\%ú\u000b{Ìõ\u00ad*;#\u0017\u0000".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            Vulcan_G = b[1];
                            String[] strArr2 = b;
                            HORIZONTAL = new Vulcan_fL(strArr2[5], 0, strArr2[2], 0);
                            VERTICAL = new Vulcan_fL(strArr2[3], 1, strArr2[0], 1);
                            Vulcan_d = new Vulcan_fL[]{HORIZONTAL, VERTICAL};
                            Vulcan_q = new Vulcan_fL[]{HORIZONTAL, VERTICAL};
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "lÆ»?Më\u0091M\u008a3\u0087Ò·ÁÄ9C\u008c\u000730w9©º Å¸Þ¨\u0087Ç»F®Z¬Â½\t)å\u0083²\u0091{i\u0004\u0010\u009aºên,ªS\u0094xýZèm\u0014gÊ";
                        length = "lÆ»?Më\u0091M\u008a3\u0087Ò·ÁÄ9C\u008c\u000730w9©º Å¸Þ¨\u0087Ç»F®Z¬Â½\t)å\u0083²\u0091{i\u0004\u0010\u009aºên,ªS\u0094xýZèm\u0014gÊ".length();
                        cCharAt = '0';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private Vulcan_fL(String str, int i, String str2, int i2) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    public Vulcan_kc[] Vulcan_I() {
        long j = a ^ 10263917045128L;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            Vulcan_J = Vulcan_kT.Vulcan_u[ordinal()];
            int i = Vulcan_J;
            if (Vulcan_J == 0) {
                switch (Vulcan_J) {
                    case 1:
                        i = 4;
                        break;
                    case 2:
                        return new Vulcan_kc[]{Vulcan_kc.UP, Vulcan_kc.DOWN};
                    default:
                        throw new Error(b[4]);
                }
            }
            Vulcan_kc[] vulcan_kcArr = new Vulcan_kc[i];
            vulcan_kcArr[0] = Vulcan_kc.NORTH;
            vulcan_kcArr[1] = Vulcan_kc.EAST;
            vulcan_kcArr[2] = Vulcan_kc.SOUTH;
            vulcan_kcArr[3] = Vulcan_kc.WEST;
            return vulcan_kcArr;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    public Vulcan_kc Vulcan_q(Random random) {
        Vulcan_kc[] vulcan_kcArrVulcan_I = Vulcan_I();
        return vulcan_kcArrVulcan_I[random.nextInt(vulcan_kcArrVulcan_I.length)];
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0028  */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fL] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_o(me.frep.vulcan.spigot.Vulcan_kc r6) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_fL.a
            r1 = 77920842740337(0x46de5c26f271, double:3.8498011492999E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L1e
            if (r0 == 0) goto L30
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L1d:
            r0 = r6
        L1e:
            me.frep.vulcan.spigot.Vulcan_fo r0 = r0.Vulcan_h()     // Catch: java.lang.RuntimeException -> L2c
            me.frep.vulcan.spigot.Vulcan_fL r0 = r0.Vulcan_l()     // Catch: java.lang.RuntimeException -> L2c
            r1 = r5
            if (r0 != r1) goto L30
            r0 = 1
            goto L31
        L2c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2c
            throw r0
        L30:
            r0 = 0
        L31:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fL.Vulcan_o(me.frep.vulcan.spigot.Vulcan_kc):boolean");
    }

    @Override // java.lang.Iterable
    public Iterator iterator() {
        return Iterators.forArray(Vulcan_I());
    }

    public boolean apply(Object obj) {
        return Vulcan_o((Vulcan_kc) obj);
    }
}
