package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.player.DiggingAction;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction;
import org.bukkit.entity.EntityType;
import org.bukkit.event.entity.EntityDamageEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_O2.class */
/* synthetic */ class Vulcan_O2 {
    static final int[] Vulcan_d;
    static final int[] Vulcan_T;
    static final int[] Vulcan_i;
    static final int[] Vulcan_v = new int[EntityDamageEvent.DamageCause.values().length];

    static {
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.ENTITY_ATTACK.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.FIRE.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.FIRE_TICK.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.FALL.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.MAGIC.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.POISON.ordinal()] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.CONTACT.ordinal()] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.PROJECTILE.ordinal()] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            Vulcan_v[EntityDamageEvent.DamageCause.LAVA.ordinal()] = 9;
        } catch (NoSuchFieldError e9) {
        }
        Vulcan_i = new int[EntityType.values().length];
        try {
            Vulcan_i[EntityType.ENDER_DRAGON.ordinal()] = 1;
        } catch (NoSuchFieldError e10) {
        }
        try {
            Vulcan_i[EntityType.IRON_GOLEM.ordinal()] = 2;
        } catch (NoSuchFieldError e11) {
        }
        try {
            Vulcan_i[EntityType.FIREBALL.ordinal()] = 3;
        } catch (NoSuchFieldError e12) {
        }
        try {
            Vulcan_i[EntityType.SMALL_FIREBALL.ordinal()] = 4;
        } catch (NoSuchFieldError e13) {
        }
        try {
            Vulcan_i[EntityType.DRAGON_FIREBALL.ordinal()] = 5;
        } catch (NoSuchFieldError e14) {
        }
        try {
            Vulcan_i[EntityType.WITHER.ordinal()] = 6;
        } catch (NoSuchFieldError e15) {
        }
        try {
            Vulcan_i[EntityType.WITHER_SKULL.ordinal()] = 7;
        } catch (NoSuchFieldError e16) {
        }
        try {
            Vulcan_i[EntityType.ENDER_CRYSTAL.ordinal()] = 8;
        } catch (NoSuchFieldError e17) {
        }
        Vulcan_T = new int[DiggingAction.values().length];
        try {
            Vulcan_T[DiggingAction.START_DIGGING.ordinal()] = 1;
        } catch (NoSuchFieldError e18) {
        }
        try {
            Vulcan_T[DiggingAction.FINISHED_DIGGING.ordinal()] = 2;
        } catch (NoSuchFieldError e19) {
        }
        try {
            Vulcan_T[DiggingAction.CANCELLED_DIGGING.ordinal()] = 3;
        } catch (NoSuchFieldError e20) {
        }
        try {
            Vulcan_T[DiggingAction.RELEASE_USE_ITEM.ordinal()] = 4;
        } catch (NoSuchFieldError e21) {
        }
        try {
            Vulcan_T[DiggingAction.DROP_ITEM.ordinal()] = 5;
        } catch (NoSuchFieldError e22) {
        }
        try {
            Vulcan_T[DiggingAction.DROP_ITEM_STACK.ordinal()] = 6;
        } catch (NoSuchFieldError e23) {
        }
        Vulcan_d = new int[WrapperPlayClientEntityAction.Action.values().length];
        try {
            Vulcan_d[WrapperPlayClientEntityAction.Action.START_SPRINTING.ordinal()] = 1;
        } catch (NoSuchFieldError e24) {
        }
        try {
            Vulcan_d[WrapperPlayClientEntityAction.Action.STOP_SPRINTING.ordinal()] = 2;
        } catch (NoSuchFieldError e25) {
        }
        try {
            Vulcan_d[WrapperPlayClientEntityAction.Action.START_SNEAKING.ordinal()] = 3;
        } catch (NoSuchFieldError e26) {
        }
        try {
            Vulcan_d[WrapperPlayClientEntityAction.Action.STOP_SNEAKING.ordinal()] = 4;
        } catch (NoSuchFieldError e27) {
        }
        try {
            Vulcan_d[WrapperPlayClientEntityAction.Action.START_FLYING_WITH_ELYTRA.ordinal()] = 5;
        } catch (NoSuchFieldError e28) {
        }
    }
}
