package me.frep.vulcan.spigot.check.impl.player.badpackets;

import com.github.retrooper.packetevents.protocol.player.DiggingAction;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPackets8.class */
@CheckInfo(name = "Bad Packets", type = '8', complexType = "Nuker", description = "Invalid Block Dig packets.")
public class BadPackets8 extends AbstractCheck {
    private int Vulcan_j;
    private int Vulcan_U;
    private boolean Vulcan_n;
    private long Vulcan_d;
    private static String Vulcan_Z;
    private static final long b = Vulcan_n.a(8454702653723763247L, -894537753750174678L, MethodHandles.lookup().lookupClass()).a(263047327042109L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x02e4: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 787
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets8.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_y(String str) {
        Vulcan_Z = str;
    }

    public static String Vulcan_n() {
        return Vulcan_Z;
    }

    static {
        long j = b ^ 4362214166983L;
        Vulcan_y((String) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "ÖÖy\u008bÛó\u009có\bÅÞÿ|h±ý\u000b".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = b(cipher.doFinal("ÖÖy\u008bÛó\u009có\bÅÞÿ|h±ý\u000b".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                d = strArr;
                return;
            }
            cCharAt = "ÖÖy\u008bÛó\u009có\bÅÞÿ|h±ý\u000b".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    public BadPackets8(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 65820918614761L;
        ?? Vulcan_n = Vulcan_n();
        try {
            this.Vulcan_j = 0;
            this.Vulcan_U = -1;
            this.Vulcan_n = false;
            this.Vulcan_d = -1L;
            if (Vulcan_n != 0) {
                Vulcan_n = new AbstractCheck[1];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_n);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_n);
        }
    }

    /* JADX INFO: renamed from: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets8$1, reason: invalid class name */
    /* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPackets8$1.class */
    /* synthetic */ class AnonymousClass1 {
        static final int[] Vulcan_J = new int[DiggingAction.values().length];

        static {
            try {
                Vulcan_J[DiggingAction.DROP_ITEM.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                Vulcan_J[DiggingAction.DROP_ITEM_STACK.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                Vulcan_J[DiggingAction.RELEASE_USE_ITEM.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                Vulcan_J[DiggingAction.SWAP_ITEM_WITH_OFFHAND.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                Vulcan_J[DiggingAction.CANCELLED_DIGGING.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
