package me.frep.vulcan.spigot.bukkit;

import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles;
import java.util.logging.Level;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.Vulcan_n;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Bukkit;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/bukkit/Vulcan_kX.class */
public abstract class Vulcan_kX {
    final String Vulcan_X;
    private static boolean Vulcan_G;
    private static final long a = Vulcan_n.a(-610821831299734289L, 1013842809638922072L, MethodHandles.lookup().lookupClass()).a(133874183515971L);
    private static final String[] b;

    protected abstract JsonObject Vulcan_q(Object[] objArr);

    public static void Vulcan_Q(boolean z) {
        Vulcan_G = z;
    }

    public static boolean Vulcan_A() {
        return Vulcan_G;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_L() {
        return !Vulcan_A();
    }

    static {
        int i;
        long j = a ^ 48651560946897L;
        Vulcan_Q(true);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "\f\u0017\u0096¦&^\u007fP\bV\u0003§\u00823å\u001a?";
        int length = "\f\u0017\u0096¦&^\u007fP\bV\u0003§\u00823å\u001a?".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u0098\u008e\u0015G+F¥¡êÿ#ú\u0084²©À¼Ç3E\u0092³PGÔ§Z\u0004\u0088Æ\u009eº{\u0083Þr£\u0083¡IOI\u001eË\u0093R\u0091ø(£\u001eÖ³nÜ/¶\u0098£]\u0007\"\u008d4Þ_ÿi½»¢\u0010\u0012\u0001\u0002Ò«Tª¤¤}\u0015Ç7f\u0082³\u0091";
                        length = "\u0098\u008e\u0015G+F¥¡êÿ#ú\u0084²©À¼Ç3E\u0092³PGÔ§Z\u0004\u0088Æ\u009eº{\u0083Þr£\u0083¡IOI\u001eË\u0093R\u0091ø(£\u001eÖ³nÜ/¶\u0098£]\u0007\"\u008d4Þ_ÿi½»¢\u0010\u0012\u0001\u0002Ò«Tª¤¤}\u0015Ç7f\u0082³\u0091".length();
                        cCharAt = '0';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Throwable a(Throwable th) {
        return th;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [me.frep.vulcan.spigot.bukkit.Vulcan_kX] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[], me.frep.vulcan.spigot.bukkit.Vulcan_kX] */
    static JsonObject Vulcan_X(Object[] objArr) {
        ?? r2 = new Object[1];
        ((Vulcan_kX) objArr[1])[0] = Long.valueOf((a ^ ((Long) objArr[0]).longValue()) ^ 129544722907481L);
        return r2.Vulcan_b(r2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0039  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    Vulcan_kX(java.lang.String r6) throws java.lang.Throwable {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.bukkit.Vulcan_kX.a
            r1 = 85562838267433(0x4dd1a694b629, double:4.22736589486094E-310)
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = Vulcan_L()
            r1 = r5
            r1.<init>()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L22
            if (r0 == 0) goto L28
            goto L21
        L1d:
            java.lang.Throwable r0 = a(r0)
            throw r0
        L21:
            r0 = r6
        L22:
            boolean r0 = r0.isEmpty()     // Catch: java.lang.IllegalArgumentException -> L35
            if (r0 == 0) goto L39
        L28:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch: java.lang.IllegalArgumentException -> L35
            r1 = r0
            java.lang.String[] r2 = me.frep.vulcan.spigot.bukkit.Vulcan_kX.b     // Catch: java.lang.IllegalArgumentException -> L35
            r3 = 3
            r2 = r2[r3]     // Catch: java.lang.IllegalArgumentException -> L35
            r1.<init>(r2)     // Catch: java.lang.IllegalArgumentException -> L35
            throw r0     // Catch: java.lang.IllegalArgumentException -> L35
        L35:
            java.lang.Throwable r0 = a(r0)     // Catch: java.lang.IllegalArgumentException -> L35
            throw r0
        L39:
            r0 = r5
            r1 = r6
            r0.Vulcan_X = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.bukkit.Vulcan_kX.<init>(java.lang.String):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.logging.Logger] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.Object[], me.frep.vulcan.spigot.bukkit.Vulcan_kX] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private JsonObject Vulcan_b(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        long j = jLongValue ^ 68498841126132L;
        boolean zVulcan_L = Vulcan_L();
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty(b[0], this.Vulcan_X);
        try {
            ?? r2 = new Object[1];
            this[0] = Long.valueOf(j);
            JsonObject jsonObjectVulcan_q = r2.Vulcan_q(r2);
            JsonObject jsonObject2 = jsonObjectVulcan_q;
            if (!zVulcan_L) {
                if (jsonObject2 == null) {
                    return null;
                }
                jsonObject2 = jsonObject;
            }
            jsonObject2.add(b[1], jsonObjectVulcan_q);
            return jsonObject;
        } catch (Throwable th) {
            ?? logger = (jLongValue > 0L ? 1 : (jLongValue == 0L ? 0 : -1));
            if (logger > 0) {
                if (Metrics.logFailedRequests) {
                    logger = Bukkit.getLogger();
                    logger.log(Level.WARNING, b[2] + this.Vulcan_X, th);
                } else {
                    return null;
                }
            }
            return null;
        }
    }
}
