package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.event.PacketListener;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.event.UserConnectEvent;
import com.github.retrooper.packetevents.event.UserDisconnectEvent;
import com.github.retrooper.packetevents.protocol.ConnectionState;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kP.class */
public class Vulcan_kP implements PacketListener {
    private static int[] Vulcan_B;
    private static final long a = Vulcan_n.a(6835205166752372561L, -7541764054212880603L, MethodHandles.lookup().lookupClass()).a(246704336456792L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x007e: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_M(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            byte[] r1 = (byte[]) r1
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.util.UUID r1 = (java.util.UUID) r1
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_kP.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            r0 = r11
            r1 = r0; r1 = r0; 
            r2 = 44509734693574(0x287b3aeceac6, double:2.1990730817603E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r13
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.Exception -> L49
            boolean r1 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r1)     // Catch: java.lang.Exception -> L49
            if (r1 == 0) goto L4d
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_kP.b     // Catch: java.lang.Exception -> L49
            r2 = 3
            r1 = r1[r2]     // Catch: java.lang.Exception -> L49
            goto L56
        L49:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.Exception -> L49
            throw r0
        L4d:
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_kP.b
            r17 = r1
            r1 = r17
            r2 = 0
            r1 = r1[r2]
        L56:
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto La9
            java.lang.String r0 = new java.lang.String     // Catch: java.lang.Exception -> La7
            r1 = r0
            r2 = r9
            java.lang.String[] r3 = me.frep.vulcan.spigot.Vulcan_kP.b     // Catch: java.lang.Exception -> La7
            r17 = r3
            r3 = r17
            r4 = 4
            r3 = r3[r4]     // Catch: java.lang.Exception -> La7
            r1.<init>(r2, r3)     // Catch: java.lang.Exception -> La7
            r1 = 1
            java.lang.String r0 = r0.substring(r1)     // Catch: java.lang.Exception -> La7
            r1 = r14
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.Exception -> La7
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.Exception -> La7
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.Exception -> La7
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.Exception -> La7
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.Exception -> La7
            r1[r2] = r3     // Catch: java.lang.Exception -> La7
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1;      // Catch: java.lang.Exception -> La7
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.Exception -> La7
            java.lang.Long r1 = java.lang.Long.valueOf(r1)     // Catch: java.lang.Exception -> La7
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.Exception -> La7
            r0[r1] = r2     // Catch: java.lang.Exception -> La7
            me.frep.vulcan.spigot.Vulcan_fN.Vulcan_O(r-1)     // Catch: java.lang.Exception -> La7
            r0 = r17
            r1 = 2
            r0 = r0[r1]     // Catch: java.lang.Exception -> La7
            java.lang.String r1 = ""
            r-1.replace(r0, r1)     // Catch: java.lang.Exception -> La7
            r16 = r-1
            me.frep.vulcan.spigot.Vulcan_r r-1 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE     // Catch: java.lang.Exception -> La7
            r-1.Vulcan_M()     // Catch: java.lang.Exception -> La7
            r0 = r10
            r1 = r16
            r-1.put(r0, r1)     // Catch: java.lang.Exception -> La7
            goto La9
        La7:
            r16 = move-exception
        La9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kP.Vulcan_M(java.lang.Object[]):void");
    }

    public static void Vulcan_O(int[] iArr) {
        Vulcan_B = iArr;
    }

    public static int[] Vulcan_x() {
        return Vulcan_B;
    }

    static {
        int i;
        long j = a ^ 82173226665946L;
        Vulcan_O(new int[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[6];
        int i3 = 0;
        String str = "aß\u008fä×\\ð\u0011U\u0082C\u0006\u0093,\u0084\u0015\b{¢Ç%é\u0013½\u0012\u0010¶iZ\u009dØ-\u009e\u0093ð]A?Æ\u0011\u0094h\u0010s¶/\u001e\n{×\u009cõaiÕI\u0082Ì·";
        int length = "aß\u008fä×\\ð\u0011U\u0082C\u0006\u0093,\u0084\u0015\b{¢Ç%é\u0013½\u0012\u0010¶iZ\u009dØ-\u009e\u0093ð]A?Æ\u0011\u0094h\u0010s¶/\u001e\n{×\u009cõaiÕI\u0082Ì·".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Õ=F6\u0017Aä<\b{¢Ç%é\u0013½\u0012";
                        length = "Õ=F6\u0017Aä<\b{¢Ç%é\u0013½\u0012".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:83:0x0153
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void onPacketReceive(com.github.retrooper.packetevents.event.PacketReceiveEvent r11) {
        /*
            Method dump skipped, instruction units count: 610
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kP.onPacketReceive(com.github.retrooper.packetevents.event.PacketReceiveEvent):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void onPacketSend(com.github.retrooper.packetevents.event.PacketSendEvent r7) {
        /*
            Method dump skipped, instruction units count: 461
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kP.onPacketSend(com.github.retrooper.packetevents.event.PacketSendEvent):void");
    }

    /* JADX WARN: Type inference failed for: r1v5, types: [com.github.retrooper.packetevents.protocol.player.User] */
    private static void lambda$onPacketSend$0(PacketSendEvent packetSendEvent) {
        long j = (a ^ 108004516509435L) ^ 51502242731884L;
        Vulcan_fG vulcan_fGM1081Vulcan__ = Vulcan_r.INSTANCE.m1081Vulcan__();
        Object[] objArr = new Object[2];
        packetSendEvent.getUser()[1] = Long.valueOf(j);
        objArr[0] = objArr;
        vulcan_fGM1081Vulcan__.Vulcan_d(objArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.UUID] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [com.github.retrooper.packetevents.protocol.player.User] */
    /* JADX WARN: Type inference failed for: r0v9, types: [com.github.retrooper.packetevents.protocol.player.User] */
    public void onUserDisconnect(UserDisconnectEvent userDisconnectEvent) throws Exception {
        long j = a ^ 50156840481548L;
        ?? Vulcan_x = Vulcan_x();
        try {
            try {
                Vulcan_x = userDisconnectEvent.getUser();
                ?? uuid = Vulcan_x;
                if (Vulcan_x != 0) {
                    if (Vulcan_x == 0) {
                        return;
                    } else {
                        uuid = userDisconnectEvent.getUser();
                    }
                }
                try {
                    uuid = uuid.getUUID();
                    if (uuid == 0) {
                        return;
                    }
                    Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_T(new Object[]{userDisconnectEvent.getUser().getUUID()});
                } catch (RuntimeException unused) {
                    throw a((Exception) uuid);
                }
            } catch (RuntimeException unused2) {
                throw a((Exception) Vulcan_x);
            }
        } catch (RuntimeException unused3) {
            throw a((Exception) Vulcan_x);
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: com.github.retrooper.packetevents.event.UserConnectEvent */
    public void onUserConnect(UserConnectEvent userConnectEvent) throws Exception {
        long j = a ^ 133938971826019L;
        UserConnectEvent userConnectEventA = userConnectEvent;
        if (Vulcan_x() != null) {
            try {
                try {
                    userConnectEventA = userConnectEventA.getUser().getConnectionState();
                    if (userConnectEventA == ConnectionState.PLAY) {
                        userConnectEventA = userConnectEvent;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    userConnectEventA = a((Exception) userConnectEventA);
                    throw userConnectEventA;
                }
            } catch (RuntimeException unused2) {
                throw a((Exception) userConnectEventA);
            }
        }
        userConnectEventA.setCancelled(true);
    }
}
