package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.ArrayDeque;
import org.bukkit.util.Vector;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_ko, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ko.class */
public class C0052Vulcan_ko {
    private final C0042Vulcan_Oz Vulcan_G;
    private float Vulcan_M;
    private float Vulcan_F;
    private float Vulcan_D;
    private float Vulcan_v;
    private float Vulcan_E;
    private float Vulcan_u;
    private float Vulcan_t;
    private float Vulcan_o;
    private float Vulcan_T;
    private float Vulcan_i;
    private float Vulcan_m;
    private float Vulcan_d;
    private float Vulcan_A;
    private float Vulcan_R;
    private float Vulcan_B;
    private float Vulcan_g;
    private float Vulcan_x;
    private float Vulcan_y;
    private boolean Vulcan_p;
    private boolean Vulcan_S;
    private boolean Vulcan_f;
    private double Vulcan_O;
    private double Vulcan_b;
    private final ArrayDeque Vulcan_P = new ArrayDeque();
    private int Vulcan_e;
    private int Vulcan_H;
    private int Vulcan_q;
    private int Vulcan_Q;
    private int Vulcan_s;
    private int Vulcan_w;
    private static boolean Vulcan_C;
    private static final long a = Vulcan_n.a(-3076934733973036679L, 5012993519789140357L, MethodHandles.lookup().lookupClass()).a(226348684167520L);

    public static void Vulcan_N(boolean z) {
        Vulcan_C = z;
    }

    public static boolean Vulcan_Z() {
        return Vulcan_C;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan__() {
        return !Vulcan_Z();
    }

    static {
        if (Vulcan__()) {
            Vulcan_N(true);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0042Vulcan_Oz Vulcan_e(Object[] objArr) {
        return this.Vulcan_G;
    }

    public float Vulcan_F(Object[] objArr) {
        return this.Vulcan_M;
    }

    public float Vulcan_M(Object[] objArr) {
        return this.Vulcan_F;
    }

    public float Vulcan_t(Object[] objArr) {
        return this.Vulcan_D;
    }

    public float Vulcan_a(Object[] objArr) {
        return this.Vulcan_v;
    }

    public float Vulcan_w(Object[] objArr) {
        return this.Vulcan_E;
    }

    public float Vulcan_n(Object[] objArr) {
        return this.Vulcan_u;
    }

    public float Vulcan_q(Object[] objArr) {
        return this.Vulcan_t;
    }

    public float Vulcan_h(Object[] objArr) {
        return this.Vulcan_o;
    }

    public float Vulcan_A(Object[] objArr) {
        return this.Vulcan_T;
    }

    public float Vulcan_y(Object[] objArr) {
        return this.Vulcan_i;
    }

    public float Vulcan_N(Object[] objArr) {
        return this.Vulcan_m;
    }

    public float Vulcan_u(Object[] objArr) {
        return this.Vulcan_d;
    }

    public float Vulcan_l(Object[] objArr) {
        return this.Vulcan_A;
    }

    public float Vulcan_E(Object[] objArr) {
        return this.Vulcan_R;
    }

    public float Vulcan_b(Object[] objArr) {
        return this.Vulcan_B;
    }

    public float Vulcan_T(Object[] objArr) {
        return this.Vulcan_g;
    }

    public float Vulcan_s(Object[] objArr) {
        return this.Vulcan_x;
    }

    public float Vulcan_W(Object[] objArr) {
        return this.Vulcan_y;
    }

    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public boolean m1058Vulcan_n(Object[] objArr) {
        return this.Vulcan_S;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public boolean m1059Vulcan_M(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public double m1060Vulcan_a(Object[] objArr) {
        return this.Vulcan_O;
    }

    public double Vulcan_V(Object[] objArr) {
        return this.Vulcan_b;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public ArrayDeque m1061Vulcan_F(Object[] objArr) {
        return this.Vulcan_P;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public int m1062Vulcan_n(Object[] objArr) {
        return this.Vulcan_e;
    }

    public int Vulcan_Y(Object[] objArr) {
        return this.Vulcan_H;
    }

    public int Vulcan_j(Object[] objArr) {
        return this.Vulcan_q;
    }

    public int Vulcan_p(Object[] objArr) {
        return this.Vulcan_Q;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public int m1063Vulcan_R(Object[] objArr) {
        return this.Vulcan_s;
    }

    public int Vulcan_P(Object[] objArr) {
        return this.Vulcan_w;
    }

    public C0052Vulcan_ko(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_G = c0042Vulcan_Oz;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:19:0x01bf  */
    /* JADX WARN: Removed duplicated region for block: B:27:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v45, types: [float] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v48, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v49, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v59, types: [int] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v62, types: [me.frep.vulcan.spigot.Vulcan_ko] */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v71 */
    /* JADX WARN: Type inference failed for: r1v91 */
    /* JADX WARN: Type inference failed for: r2v26, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ko] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_G(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 467
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0052Vulcan_ko.Vulcan_G(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_r(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = me.frep.vulcan.spigot.C0052Vulcan_ko.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_ka.Vulcan_T()
            r9 = r0
            r0 = r5
            int r0 = r0.Vulcan_e     // Catch: java.lang.RuntimeException -> L26
            r1 = r9
            if (r1 == 0) goto L35
            if (r0 <= 0) goto L52
            goto L2a
        L26:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L31
            throw r0     // Catch: java.lang.RuntimeException -> L31
        L2a:
            r0 = r5
            int r0 = r0.Vulcan_e     // Catch: java.lang.RuntimeException -> L31
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L35:
            r1 = r9
            if (r1 == 0) goto L4f
            r1 = 200(0xc8, float:2.8E-43)
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0052Vulcan_ko.Vulcan_r(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:27:0x00ae
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void Vulcan_C(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 426
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0052Vulcan_ko.Vulcan_C(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00f5 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v13, types: [double] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [int] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [me.frep.vulcan.spigot.Vulcan_ko] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_ko] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r1v14, types: [double] */
    /* JADX WARN: Type inference failed for: r1v37, types: [java.util.ArrayDeque] */
    /* JADX WARN: Type inference failed for: r1v9, types: [long] */
    /* JADX WARN: Type inference failed for: r2v24, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ko] */
    /* JADX WARN: Type inference failed for: r3v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v2, types: [double, java.lang.Object[], long] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void Vulcan_R(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 285
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0052Vulcan_ko.Vulcan_R(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_c(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = me.frep.vulcan.spigot.C0052Vulcan_ko.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_ka.Vulcan_T()
            r9 = r0
            r0 = r5
            int r0 = r0.Vulcan_e     // Catch: java.lang.RuntimeException -> L26
            r1 = r9
            if (r1 == 0) goto L35
            if (r0 < 0) goto L51
            goto L2a
        L26:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L31
            throw r0     // Catch: java.lang.RuntimeException -> L31
        L2a:
            r0 = r5
            int r0 = r0.Vulcan_e     // Catch: java.lang.RuntimeException -> L31
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L35:
            r1 = r9
            if (r1 == 0) goto L4e
            r1 = 50
            if (r0 >= r1) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4a
            throw r0     // Catch: java.lang.RuntimeException -> L4a
        L46:
            r0 = 1
            goto L4e
        L4a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4e:
            goto L52
        L51:
            r0 = 0
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0052Vulcan_ko.Vulcan_c(java.lang.Object[]):boolean");
    }

    public float Vulcan_d(Object[] objArr) {
        return new Vector(this.Vulcan_G.m639Vulcan_M(new Object[0]).m898Vulcan_b(new Object[0]), 0.0d, this.Vulcan_G.m639Vulcan_M(new Object[0]).m900Vulcan_a(new Object[0])).angle(new Vector((-Math.sin((this.Vulcan_M * 3.1415927f) / 180.0f)) * 1.0d * 0.5d, 0.0d, Math.cos((this.Vulcan_M * 3.1415927f) / 180.0f) * 1.0d * 0.5d));
    }
}
