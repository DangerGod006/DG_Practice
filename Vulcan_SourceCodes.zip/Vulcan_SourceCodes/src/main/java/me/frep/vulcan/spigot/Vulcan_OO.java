package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OO.class */
public final class Vulcan_OO extends HashMap {
    private final int Vulcan_Z;
    private final Deque Vulcan_i = new LinkedList();
    private static final long a = Vulcan_n.a(-5431726222064160885L, 1826440875182319091L, MethodHandles.lookup().lookupClass()).a(103306186610948L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_OO(int i) {
        this.Vulcan_Z = i;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public int m598Vulcan_I(Object[] objArr) {
        return this.Vulcan_Z;
    }

    @Override // java.util.HashMap, java.util.Map
    public boolean remove(Object obj, Object obj2) {
        this.Vulcan_i.remove(obj);
        return super.remove(obj, obj2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_OO] */
    @Override // java.util.HashMap, java.util.Map
    public Object putIfAbsent(Object obj, Object obj2) {
        long j = (a ^ 86679586413300L) ^ 76553960551119L;
        ?? Vulcan_M = C0036Vulcan_Oj.Vulcan_M();
        try {
            try {
                try {
                    Vulcan_M = this.Vulcan_i.contains(obj);
                    try {
                        if (Vulcan_M == 0) {
                            if (Vulcan_M != 0) {
                                Object obj3 = get(obj);
                                if (Vulcan_M != 0) {
                                    return obj3;
                                }
                                if (!obj3.equals(obj2)) {
                                    ?? r2 = new Object[1];
                                    this[0] = Long.valueOf(j);
                                    r2.Vulcan_I(r2);
                                }
                            } else {
                                ?? r22 = new Object[1];
                                this[0] = Long.valueOf(j);
                                r22.Vulcan_I(r22);
                            }
                        }
                        return super.putIfAbsent(obj, obj2);
                    } catch (RuntimeException unused) {
                        throw a(Vulcan_M);
                    }
                } catch (RuntimeException unused2) {
                    throw a(Vulcan_M);
                }
            } catch (RuntimeException unused3) {
                throw a(Vulcan_M);
            }
        } catch (RuntimeException unused4) {
            throw a(Vulcan_M);
        }
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_OO] */
    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public Object put(Object obj, Object obj2) {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 16742361816622L) ^ 4739780425237L);
        r2.Vulcan_I(r2);
        this.Vulcan_i.addLast(obj);
        return super.put(obj, obj2);
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public void putAll(Map map) {
        map.forEach(this::put);
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public void clear() {
        this.Vulcan_i.clear();
        super.clear();
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public Object remove(Object obj) {
        this.Vulcan_i.remove(obj);
        return super.remove(obj);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    private boolean Vulcan_I(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_M = C0036Vulcan_Oj.Vulcan_M();
        try {
            Vulcan_M = this.Vulcan_i.size();
            if (Vulcan_M != 0) {
                return Vulcan_M;
            }
            if (Vulcan_M >= this.Vulcan_Z) {
                remove(this.Vulcan_i.removeFirst());
                return true;
            }
            return false;
        } catch (RuntimeException unused) {
            throw a(Vulcan_M);
        }
    }
}
