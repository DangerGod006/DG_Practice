package me.frep.vulcan.spigot;

import com.google.common.base.Predicate;
import java.lang.invoke.MethodHandles;
import java.util.Map;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Found several "values" enum fields: [] */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fo.class */
public final class Vulcan_fo implements Predicate, Vulcan_ya {
    public static final Vulcan_fo X;
    public static final Vulcan_fo Y;
    public static final Vulcan_fo Z;
    private static final Map Vulcan_V;
    private final String Vulcan_B;
    private final Vulcan_fL Vulcan_W;
    private static final Vulcan_fo[] Vulcan_A;
    private static final String Vulcan_a;
    private static final Vulcan_fo[] Vulcan_b;
    private static final long a = Vulcan_n.a(-5318647883906349703L, -3142671931848987870L, MethodHandles.lookup().lookupClass()).a(172568912710306L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public static Vulcan_fo[] values() {
        return (Vulcan_fo[]) Vulcan_b.clone();
    }

    public static Vulcan_fo valueOf(String str) {
        return (Vulcan_fo) Enum.valueOf(Vulcan_fo.class, str);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0075, code lost:
    
        r8 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x007a, code lost:
    
        r8 = 85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x007f, code lost:
    
        r8 = 91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0084, code lost:
    
        r8 = 59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0089, code lost:
    
        r8 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x008e, code lost:
    
        r8 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0090, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0098, code lost:
    
        if (r4 != 0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x009b, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00a0, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00a4, code lost:
    
        if (r4 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00a8, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00ba, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fo.X = new me.frep.vulcan.spigot.Vulcan_fo("X", 0, "X", 0, "x", me.frep.vulcan.spigot.Vulcan_fL.HORIZONTAL);
        me.frep.vulcan.spigot.Vulcan_fo.Y = new me.frep.vulcan.spigot.Vulcan_fo("Y", 1, "Y", 1, "y", me.frep.vulcan.spigot.Vulcan_fL.VERTICAL);
        me.frep.vulcan.spigot.Vulcan_fo.Z = new me.frep.vulcan.spigot.Vulcan_fo("Z", 2, "Z", 2, "z", me.frep.vulcan.spigot.Vulcan_fL.HORIZONTAL);
        me.frep.vulcan.spigot.Vulcan_fo.Vulcan_b = new me.frep.vulcan.spigot.Vulcan_fo[]{me.frep.vulcan.spigot.Vulcan_fo.X, me.frep.vulcan.spigot.Vulcan_fo.Y, me.frep.vulcan.spigot.Vulcan_fo.Z};
        me.frep.vulcan.spigot.Vulcan_fo.Vulcan_V = com.google.common.collect.Maps.newHashMap();
        me.frep.vulcan.spigot.Vulcan_fo.Vulcan_A = new me.frep.vulcan.spigot.Vulcan_fo[]{me.frep.vulcan.spigot.Vulcan_fo.X, me.frep.vulcan.spigot.Vulcan_fo.Y, me.frep.vulcan.spigot.Vulcan_fo.Z};
        r0 = values();
        r0 = r0.length;
        r14 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x013c, code lost:
    
        if (r14 >= r0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x013f, code lost:
    
        r0 = r0[r14];
        me.frep.vulcan.spigot.Vulcan_fo.Vulcan_V.put(r0.Vulcan_K().toLowerCase(), r0);
        r14 = r14 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x015d, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0022, code lost:
    
        me.frep.vulcan.spigot.Vulcan_fo.Vulcan_a = -1;
        r0 = me.frep.vulcan.spigot.Vulcan_fo.Vulcan_a;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x003b, code lost:
    
        if (r2 <= 1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x003e, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0041, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0048, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0070, code lost:
    
        r8 = 15;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x003e, B:19:0x00a0], limit reached: 29 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v24 */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v14 */
    /* JADX WARN: Type inference failed for: r6v16 */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x00a4 -> B:6:0x003e). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 350
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fo.m826clinit():void");
    }

    private Vulcan_fo(String str, int i, String str2, int i2, String str3, Vulcan_fL vulcan_fL) {
        this.Vulcan_B = str3;
        this.Vulcan_W = vulcan_fL;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static me.frep.vulcan.spigot.Vulcan_fo Vulcan_j(java.lang.String r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_fo.a
            r1 = 33579046303604(0x1e8a3b207774, double:1.6590253198723E-310)
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r8 = r0
            r0 = r5
            r1 = r8
            if (r1 != 0) goto L2f
            if (r0 != 0) goto L23
            goto L1b
        L17:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L1f
            throw r0     // Catch: java.lang.RuntimeException -> L1f
        L1b:
            r0 = 0
            goto L32
        L1f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L1f
            throw r0
        L23:
            java.util.Map r0 = me.frep.vulcan.spigot.Vulcan_fo.Vulcan_V
            r1 = r5
            java.lang.String r1 = r1.toLowerCase()
            java.lang.Object r0 = r0.get(r1)
        L2f:
            me.frep.vulcan.spigot.Vulcan_fo r0 = (me.frep.vulcan.spigot.Vulcan_fo) r0
        L32:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fo.Vulcan_j(java.lang.String):me.frep.vulcan.spigot.Vulcan_fo");
    }

    public String Vulcan_K() {
        return this.Vulcan_B;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_fL] */
    public boolean Vulcan_j() {
        ?? r0 = a ^ 136483157491753L;
        try {
            r0 = this.Vulcan_W;
            return r0 == Vulcan_fL.VERTICAL;
        } catch (RuntimeException unused) {
            throw a(r0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_fL] */
    public boolean Vulcan_O() {
        ?? r0 = a ^ 85395882711080L;
        try {
            r0 = this.Vulcan_W;
            return r0 == Vulcan_fL.HORIZONTAL;
        } catch (RuntimeException unused) {
            throw a(r0);
        }
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.Vulcan_B;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0025  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_fo] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_t(me.frep.vulcan.spigot.Vulcan_kc r6) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_fo.a
            r1 = 82513656895545(0x4b0bb5355839, double:4.07671631848205E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 != 0) goto L1e
            if (r0 == 0) goto L2d
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L1d:
            r0 = r6
        L1e:
            me.frep.vulcan.spigot.Vulcan_fo r0 = r0.Vulcan_h()     // Catch: java.lang.RuntimeException -> L29
            r1 = r5
            if (r0 != r1) goto L2d
            r0 = 1
            goto L2e
        L29:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L29
            throw r0
        L2d:
            r0 = 0
        L2e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fo.Vulcan_t(me.frep.vulcan.spigot.Vulcan_kc):boolean");
    }

    public Vulcan_fL Vulcan_l() {
        return this.Vulcan_W;
    }

    @Override // me.frep.vulcan.spigot.Vulcan_ya
    public String Vulcan_T() {
        return this.Vulcan_B;
    }

    public boolean apply(Object obj) {
        return Vulcan_t((Vulcan_kc) obj);
    }
}
