package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OE.class */
class Vulcan_OE {
    private String Vulcan_s;
    private String Vulcan_q;
    private boolean Vulcan_n;
    final Vulcan_kZ Vulcan_a;

    static String Vulcan_b(Object[] objArr) {
        return ((Vulcan_OE) objArr[0]).Vulcan_f(new Object[0]);
    }

    static String Vulcan_t(Object[] objArr) {
        return ((Vulcan_OE) objArr[0]).Vulcan_T(new Object[0]);
    }

    static boolean Vulcan_S(Object[] objArr) {
        return ((Vulcan_OE) objArr[0]).Vulcan_s(new Object[0]);
    }

    Vulcan_OE(Vulcan_kZ vulcan_kZ, String str, String str2, boolean z, Vulcan_fs vulcan_fs) {
        this(vulcan_kZ, str, str2, z);
    }

    private Vulcan_OE(Vulcan_kZ vulcan_kZ, String str, String str2, boolean z) {
        this.Vulcan_a = vulcan_kZ;
        this.Vulcan_s = str;
        this.Vulcan_q = str2;
        this.Vulcan_n = z;
    }

    private String Vulcan_f(Object[] objArr) {
        return this.Vulcan_s;
    }

    private String Vulcan_T(Object[] objArr) {
        return this.Vulcan_q;
    }

    private boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_n;
    }
}
