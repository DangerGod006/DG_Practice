package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_O8;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityVelocity;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerExplosion;
import java.lang.invoke.MethodHandles;
import java.util.LinkedList;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_q.class */
public class Vulcan_q {
    private final C0042Vulcan_Oz Vulcan_h;
    private final LinkedList Vulcan_J = new LinkedList();
    private final LinkedList Vulcan_t = new LinkedList();
    private boolean Vulcan_R = false;
    private boolean Vulcan_X = false;
    private double Vulcan_y = 0.0d;
    private double Vulcan_f = 0.0d;
    private double Vulcan_k = 0.0d;
    private double Vulcan_S = 0.0d;
    private double Vulcan_s = 0.0d;
    private double Vulcan_r = 0.0d;
    private double Vulcan_B = 0.0d;
    private double Vulcan_P = 0.0d;
    private double Vulcan_l = 0.0d;
    private double Vulcan_e = 0.0d;
    private double Vulcan_Q = 0.0d;
    private double Vulcan_A = 0.0d;
    private double Vulcan__ = 0.0d;
    private double Vulcan_Z = 0.0d;
    private double Vulcan_i = 0.0d;
    private int Vulcan_p = 0;
    private int Vulcan_q = 0;
    private int Vulcan_o = 0;
    private int Vulcan_K = Vulcan_O8.Vulcan_z;
    private static String Vulcan_x;
    private static final long a = Vulcan_n.a(8053647112663157015L, 3727217993992937645L, MethodHandles.lookup().lookupClass()).a(256190339133591L);

    public static void Vulcan_l(String str) {
        Vulcan_x = str;
    }

    public static String Vulcan_W() {
        return Vulcan_x;
    }

    static {
        if (Vulcan_W() == null) {
            Vulcan_l("w8UWBb");
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0042Vulcan_Oz Vulcan_T(Object[] objArr) {
        return this.Vulcan_h;
    }

    public LinkedList Vulcan_K(Object[] objArr) {
        return this.Vulcan_J;
    }

    public LinkedList Vulcan_I(Object[] objArr) {
        return this.Vulcan_t;
    }

    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_R;
    }

    public boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_X;
    }

    public double Vulcan_r(Object[] objArr) {
        return this.Vulcan_y;
    }

    public double Vulcan_M(Object[] objArr) {
        return this.Vulcan_f;
    }

    public double Vulcan_e(Object[] objArr) {
        return this.Vulcan_k;
    }

    public double Vulcan_D(Object[] objArr) {
        return this.Vulcan_S;
    }

    public double Vulcan_l(Object[] objArr) {
        return this.Vulcan_s;
    }

    public double Vulcan_i(Object[] objArr) {
        return this.Vulcan_r;
    }

    public double Vulcan_Z(Object[] objArr) {
        return this.Vulcan_B;
    }

    public double Vulcan_y(Object[] objArr) {
        return this.Vulcan_P;
    }

    public double Vulcan_m(Object[] objArr) {
        return this.Vulcan_l;
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public double m1073Vulcan_b(Object[] objArr) {
        return this.Vulcan_e;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public double m1074Vulcan_T(Object[] objArr) {
        return this.Vulcan_Q;
    }

    public double Vulcan_q(Object[] objArr) {
        return this.Vulcan_A;
    }

    public double Vulcan_t(Object[] objArr) {
        return this.Vulcan__;
    }

    public double Vulcan_g(Object[] objArr) {
        return this.Vulcan_Z;
    }

    public double Vulcan_o(Object[] objArr) {
        return this.Vulcan_i;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public int m1075Vulcan_H(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public int m1076Vulcan_t(Object[] objArr) {
        return this.Vulcan_q;
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public int m1077Vulcan_o(Object[] objArr) {
        return this.Vulcan_o;
    }

    public int Vulcan_Q(Object[] objArr) {
        return this.Vulcan_K;
    }

    public Vulcan_q(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_h = c0042Vulcan_Oz;
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_v(Object[] objArr) {
        WrapperPlayServerEntityVelocity wrapperPlayServerEntityVelocity = (WrapperPlayServerEntityVelocity) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        PacketSendEvent packetSendEvent = (PacketSendEvent) objArr[2];
        long j = (a ^ jLongValue) ^ 68288244118655L;
        ?? M640Vulcan_O = this.Vulcan_h.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleVelocity$0(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_o(r3);
        this.Vulcan_h.m640Vulcan_O(new Object[0]).Vulcan_h(new Object[]{this::lambda$handleVelocity$1});
        packetSendEvent.getTasksAfterSend().add(this::lambda$handleVelocity$2);
    }

    private void lambda$handleVelocity$0(WrapperPlayServerEntityVelocity wrapperPlayServerEntityVelocity) {
        this.Vulcan_i = wrapperPlayServerEntityVelocity.getVelocity().getY();
        this.Vulcan_o = 0;
        this.Vulcan_J.add(wrapperPlayServerEntityVelocity.getVelocity());
    }

    private void lambda$handleVelocity$1() {
        Vulcan_ka vulcan_kaM639Vulcan_M = this.Vulcan_h.m639Vulcan_M(new Object[0]);
        LinkedList linkedList = this.Vulcan_J;
        linkedList.getClass();
        vulcan_kaM639Vulcan_M.Vulcan_t(new Object[]{linkedList::poll});
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    private void lambda$handleVelocity$2() {
        long j = (a ^ 140713232732600L) ^ 120876604036015L;
        ?? M640Vulcan_O = this.Vulcan_h.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = false;
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_L(r3);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:7:0x0045
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_a(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 257
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_q.Vulcan_a(java.lang.Object[]):void");
    }

    private void lambda$handleExplosion$3(WrapperPlayServerExplosion wrapperPlayServerExplosion) {
        this.Vulcan_t.add(wrapperPlayServerExplosion.getKnockback());
    }

    private void lambda$handleExplosion$4() {
        Vulcan_ka vulcan_kaM639Vulcan_M = this.Vulcan_h.m639Vulcan_M(new Object[0]);
        LinkedList linkedList = this.Vulcan_t;
        linkedList.getClass();
        vulcan_kaM639Vulcan_M.Vulcan_t(new Object[]{linkedList::poll});
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    private void lambda$handleExplosion$5() {
        long j = (a ^ 48882851886818L) ^ 68586069472501L;
        ?? M640Vulcan_O = this.Vulcan_h.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = false;
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_L(r3);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:77:0x01e2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_E(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 678
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_q.Vulcan_E(java.lang.Object[]):void");
    }

    public void Vulcan_b(Object[] objArr) {
    }
}
