package me.frep.vulcan.spigot.check.impl.movement.step;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/step/StepC.class */
@CheckInfo(name = "Step", type = 'C', complexType = "Motion", description = "Reverse step.")
public class StepC extends AbstractCheck {
    int Vulcan_G;
    private static boolean Vulcan_M;
    private static final long b = Vulcan_n.a(-8404725599102366309L, 7675152791838004082L, MethodHandles.lookup().lookupClass()).a(214726489504624L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0504: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 6002
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.step.StepC.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_r(boolean z) {
        Vulcan_M = z;
    }

    public static boolean Vulcan_O() {
        return Vulcan_M;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_H() {
        return !Vulcan_O();
    }

    static {
        int i;
        long j = b ^ 89343147158469L;
        Vulcan_r(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[7];
        int i3 = 0;
        String str = "\u0013æÔkoT\tv\b7ÁZc\u0016\u0083Z6\b7ÁZc\u0016\u0083Z6\u0010 °¡\u001aêð\u0019\u0016Æ\u0098¹\u000bü\u001cr_\u0010 °¡\u001aêð\u0019\u0016Æ\u0098¹\u000bü\u001cr_";
        int length = "\u0013æÔkoT\tv\b7ÁZc\u0016\u0083Z6\b7ÁZc\u0016\u0083Z6\u0010 °¡\u001aêð\u0019\u0016Æ\u0098¹\u000bü\u001cr_\u0010 °¡\u001aêð\u0019\u0016Æ\u0098¹\u000bü\u001cr_".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "¥b\tô)}\u0006(\u009aòoJ\r\u0081)à\u0010¥b\tô)}\u0006(\u009aòoJ\r\u0081)à";
                        length = "¥b\tô)}\u0006(\u009aòoJ\r\u0081)à\u0010¥b\tô)}\u0006(\u009aòoJ\r\u0081)à".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public StepC(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 88396485880213L;
        boolean zVulcan_O = Vulcan_O();
        this.Vulcan_G = 0;
        ?? r0 = zVulcan_O;
        if (r0 != 0) {
            try {
                r0 = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
            } catch (RuntimeException unused) {
                throw a((RuntimeException) r0);
            }
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
