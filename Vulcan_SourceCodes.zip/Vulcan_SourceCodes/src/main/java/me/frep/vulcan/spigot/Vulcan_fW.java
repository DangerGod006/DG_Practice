package me.frep.vulcan.spigot;

import com.gmail.nossr50.datatypes.skills.SuperAbilityType;
import com.gmail.nossr50.events.skills.abilities.McMMOPlayerAbilityActivateEvent;
import com.gmail.nossr50.events.skills.abilities.McMMOPlayerAbilityDeactivateEvent;
import java.lang.invoke.MethodHandles;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fW.class */
public class Vulcan_fW implements Listener {
    private static AbstractCheck[] Vulcan_Y;
    private static final long a = Vulcan_n.a(-6914176182111602567L, 1068669962468860808L, MethodHandles.lookup().lookupClass()).a(158830552794355L);

    public static void Vulcan_A(AbstractCheck[] abstractCheckArr) {
        Vulcan_Y = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_N() {
        return Vulcan_Y;
    }

    static {
        if (Vulcan_N() == null) {
            Vulcan_A(new AbstractCheck[4]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    @EventHandler
    public void Vulcan_m(McMMOPlayerAbilityActivateEvent mcMMOPlayerAbilityActivateEvent) {
        long j = a ^ 2215609600356L;
        Vulcan_N();
        SuperAbilityType superAbilityTypeVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{mcMMOPlayerAbilityActivateEvent.getPlayer()});
        try {
            superAbilityTypeVulcan_L = superAbilityTypeVulcan_L;
            ?? r0 = superAbilityTypeVulcan_L;
            if (superAbilityTypeVulcan_L != null) {
                try {
                    superAbilityTypeVulcan_L = mcMMOPlayerAbilityActivateEvent.getAbility();
                    if (superAbilityTypeVulcan_L != SuperAbilityType.BERSERK) {
                        r0 = superAbilityTypeVulcan_L;
                    } else {
                        C0047Vulcan_fi c0047Vulcan_fiM637Vulcan_r = superAbilityTypeVulcan_L.m637Vulcan_r(new Object[0]);
                        c0047Vulcan_fiM637Vulcan_r.m821Vulcan_t(new Object[]{true});
                        r0 = c0047Vulcan_fiM637Vulcan_r;
                    }
                } catch (RuntimeException unused) {
                    throw a(superAbilityTypeVulcan_L);
                }
            }
            try {
                if (AbstractCheck.Vulcan_k() != null) {
                    r0 = new AbstractCheck[5];
                    Vulcan_A(r0);
                }
            } catch (RuntimeException unused2) {
                throw a(r0);
            }
        } catch (RuntimeException unused3) {
            throw a(superAbilityTypeVulcan_L);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    @EventHandler
    public void Vulcan_q(McMMOPlayerAbilityDeactivateEvent mcMMOPlayerAbilityDeactivateEvent) {
        long j = a ^ 28640006918154L;
        AbstractCheck[] abstractCheckArrVulcan_N = Vulcan_N();
        SuperAbilityType superAbilityTypeVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{mcMMOPlayerAbilityDeactivateEvent.getPlayer()});
        try {
            superAbilityTypeVulcan_L = superAbilityTypeVulcan_L;
            if (superAbilityTypeVulcan_L != null) {
                try {
                    superAbilityTypeVulcan_L = mcMMOPlayerAbilityDeactivateEvent.getAbility();
                    if (superAbilityTypeVulcan_L == SuperAbilityType.BERSERK) {
                        superAbilityTypeVulcan_L.m637Vulcan_r(new Object[0]).m821Vulcan_t(new Object[]{false});
                    }
                } catch (RuntimeException unused) {
                    throw a(superAbilityTypeVulcan_L);
                }
            }
            ?? r0 = abstractCheckArrVulcan_N;
            if (r0 == 0) {
                try {
                    r0 = new AbstractCheck[5];
                    AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
                } catch (RuntimeException unused2) {
                    throw a(r0);
                }
            }
        } catch (RuntimeException unused3) {
            throw a(superAbilityTypeVulcan_L);
        }
    }
}
