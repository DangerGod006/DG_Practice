package me.frep.vulcan.api.data;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/api/data/IPlayerData.class */
public interface IPlayerData {
    int getTotalViolations();

    int getCombatViolations();

    int getMovementViolations();

    int getPlayerViolations();

    int getAutoClickerViolations();

    int getTimerViolations();

    int getScaffoldViolations();

    long getJoinTime();

    int getJoinTicks();

    String getClientBrand();

    long getLastClientBrandAlert();
}
