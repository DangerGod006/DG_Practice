package me.frep.vulcan.spigot.check.data;

import java.lang.invoke.MethodHandles;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.api.check.ICheckData;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/data/CheckData.class */
public class CheckData implements ICheckData {
    private boolean Vulcan_i;
    private boolean Vulcan_X;
    private boolean Vulcan_t;
    private boolean Vulcan_V;
    private boolean Vulcan_P;
    private boolean Vulcan_k;
    private boolean Vulcan_s;
    private boolean Vulcan_f;
    private int Vulcan_m;
    private int Vulcan_d;
    private int Vulcan_F;
    private int Vulcan_q;
    private int Vulcan_c;
    private int Vulcan_x;
    private int Vulcan_Z;
    private int Vulcan_e;
    private double Vulcan_r;
    private double Vulcan_g;
    private double Vulcan_y;
    private double Vulcan_T;
    private List Vulcan_b;
    private String Vulcan_U;
    private static AbstractCheck[] Vulcan_W;
    private static final long a = Vulcan_n.a(6299717888332500450L, -4099091981832783328L, MethodHandles.lookup().lookupClass()).a(239125660328965L);
    private static final String[] b;

    public static void Vulcan_Y(AbstractCheck[] abstractCheckArr) {
        Vulcan_W = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_o() {
        return Vulcan_W;
    }

    static {
        int i;
        long j = a ^ 68952681669396L;
        Vulcan_Y(new AbstractCheck[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = ">eû×\u0090¤¯YDIö<|\u0001÷\u0000\u0018  ½øþá\u0006\u0094JãKÇzÁµ\u0016H\u001f(\u0002êô\u001f!";
        int length = ">eû×\u0090¤¯YDIö<|\u0001÷\u0000\u0018  ½øþá\u0006\u0094JãKÇzÁµ\u0016H\u001f(\u0002êô\u001f!".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "k(@¶§\u0090T\u008c¢VN\u0019¯|Q\u009c\u00104õ\u00ad0´\u0016(Ñå7A\u0007MßÛ[";
                        length = "k(@¶§\u0090T\u008c¢VN\u0019¯|Q\u009c\u00104õ\u00ad0´\u0016(Ñå7A\u0007MßÛ[".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_i = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_O(Object[] objArr) {
        this.Vulcan_X = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_P(Object[] objArr) {
        this.Vulcan_t = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_d(Object[] objArr) {
        this.Vulcan_V = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_x(Object[] objArr) {
        this.Vulcan_P = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K(Object[] objArr) {
        this.Vulcan_k = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_H(Object[] objArr) {
        this.Vulcan_s = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_J(Object[] objArr) {
        this.Vulcan_f = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_h(Object[] objArr) {
        this.Vulcan_m = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public void m1124Vulcan_l(Object[] objArr) {
        this.Vulcan_d = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_t(Object[] objArr) {
        this.Vulcan_F = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_G(Object[] objArr) {
        this.Vulcan_q = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U(Object[] objArr) {
        this.Vulcan_c = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_n(Object[] objArr) {
        this.Vulcan_x = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_V(Object[] objArr) {
        this.Vulcan_Z = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_w(Object[] objArr) {
        this.Vulcan_e = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Y(Object[] objArr) {
        this.Vulcan_r = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_S(Object[] objArr) {
        this.Vulcan_g = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_F(Object[] objArr) {
        this.Vulcan_y = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_u(Object[] objArr) {
        this.Vulcan_T = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan__(Object[] objArr) {
        this.Vulcan_b = (List) objArr[0];
    }

    public void Vulcan_z(Object[] objArr) {
        this.Vulcan_U = (String) objArr[0];
    }

    public boolean Vulcan_y(Object[] objArr) {
        return this.Vulcan_k;
    }

    public boolean Vulcan_L(Object[] objArr) {
        return this.Vulcan_s;
    }

    public boolean Vulcan_i(Object[] objArr) {
        return this.Vulcan_f;
    }

    public int Vulcan_g(Object[] objArr) {
        return this.Vulcan_q;
    }

    public int Vulcan_B(Object[] objArr) {
        return this.Vulcan_c;
    }

    public int Vulcan_E(Object[] objArr) {
        return this.Vulcan_x;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public int m1123Vulcan_L(Object[] objArr) {
        return this.Vulcan_e;
    }

    public String Vulcan_l(Object[] objArr) {
        return this.Vulcan_U;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public CheckData(String str) {
        long j = a ^ 93988461212683L;
        ?? Vulcan_o = Vulcan_o();
        try {
            this.Vulcan_U = str;
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_o = new AbstractCheck[1];
                Vulcan_Y((AbstractCheck[]) Vulcan_o);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_o);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    public String toString() {
        long j = a ^ 125215331079107L;
        ?? Vulcan_o = Vulcan_o();
        try {
            Vulcan_o = b[3] + this.Vulcan_U + b[2] + this.Vulcan_i + b[0] + this.Vulcan_X + b[1] + this.Vulcan_t + "}";
            if (Vulcan_o == 0) {
                AbstractCheck.Vulcan_D(new AbstractCheck[5]);
            }
            return Vulcan_o;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_o);
        }
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public boolean isEnabled() {
        return this.Vulcan_i;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public boolean isPunishable() {
        return this.Vulcan_X;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public boolean isBroadcastPunishment() {
        return this.Vulcan_t;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public boolean isHotbarShuffle() {
        return this.Vulcan_V;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public boolean isRandomRotation() {
        return this.Vulcan_P;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getMaxViolations() {
        return this.Vulcan_m;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getAlertInterval() {
        return this.Vulcan_d;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getMinimumVlToNotify() {
        return this.Vulcan_F;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getMaxPing() {
        return this.Vulcan_q;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getMinimumVlToRandomlyRotate() {
        return this.Vulcan_c;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getMinimumVlToShuffleHotbar() {
        return this.Vulcan_x;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public double getMinimumTps() {
        return this.Vulcan_r;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public double getMaxBuffer() {
        return this.Vulcan_g;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public double getBufferDecay() {
        return this.Vulcan_y;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public double getBufferMultiple() {
        return this.Vulcan_T;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public List getPunishmentCommands() {
        return this.Vulcan_b;
    }

    @Override // me.frep.vulcan.api.check.ICheckData
    public int getRandomRotationInterval() {
        return this.Vulcan_Z;
    }
}
