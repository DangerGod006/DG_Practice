package me.frep.vulcan.spigot;

import org.bukkit.entity.Entity;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fB.class */
public class Vulcan_fB extends Vulcan_fq {
    public static final Vulcan_fB Vulcan_I = null;
    private static final int Vulcan_E = 0;
    private static final int Vulcan_H = 0;
    private static final int Vulcan_e = 0;
    private static final int Vulcan_f = 0;
    private static final int Vulcan_Q = 0;
    private static final long Vulcan_a = 0;
    private static final long Vulcan_y = 0;
    private static final long Vulcan_d = 0;
    private static final String Vulcan_K = null;
    private static final String[] b = null;

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public Vulcan_fB(int i, int i2, int i3) {
        super(i, i2, i3);
    }

    public Vulcan_fB(double d, double d2, double d3) {
        super(d, d2, d3);
    }

    public Vulcan_fB(Entity entity) {
        this(entity.getLocation().getX(), entity.getLocation().getY(), entity.getLocation().getZ());
    }

    public Vulcan_fB(Vulcan_Oa vulcan_Oa) {
        this(vulcan_Oa.Vulcan_v, vulcan_Oa.Vulcan_I, vulcan_Oa.Vulcan_h);
    }

    public Vulcan_fB(Vulcan_fq vulcan_fq) {
        this(vulcan_fq.Vulcan_s(new Object[0]), vulcan_fq.Vulcan_y(new Object[0]), vulcan_fq.Vulcan_L(new Object[0]));
    }

    public Vulcan_fB Vulcan_I(Object[] objArr) {
        return new Vulcan_fB(((double) Vulcan_s(new Object[0])) + ((Double) objArr[0]).doubleValue(), ((double) Vulcan_y(new Object[0])) + ((Double) objArr[1]).doubleValue(), ((double) Vulcan_L(new Object[0])) + ((Double) objArr[2]).doubleValue());
    }

    public Vulcan_fB Vulcan_g(Object[] objArr) {
        return new Vulcan_fB(Vulcan_s(new Object[0]) + ((Integer) objArr[0]).intValue(), Vulcan_y(new Object[0]) + ((Integer) objArr[1]).intValue(), Vulcan_L(new Object[0]) + ((Integer) objArr[2]).intValue());
    }

    public Vulcan_fB Vulcan_N(Object[] objArr) {
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[0];
        return new Vulcan_fB(Vulcan_s(new Object[0]) + vulcan_fq.Vulcan_s(new Object[0]), Vulcan_y(new Object[0]) + vulcan_fq.Vulcan_y(new Object[0]), Vulcan_L(new Object[0]) + vulcan_fq.Vulcan_L(new Object[0]));
    }

    public Vulcan_fB Vulcan_n(Object[] objArr) {
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[0];
        return new Vulcan_fB(Vulcan_s(new Object[0]) - vulcan_fq.Vulcan_s(new Object[0]), Vulcan_y(new Object[0]) - vulcan_fq.Vulcan_y(new Object[0]), Vulcan_L(new Object[0]) - vulcan_fq.Vulcan_L(new Object[0]));
    }

    public Vulcan_fB Vulcan_x(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        return new Vulcan_fB(Vulcan_s(new Object[0]) * iIntValue, Vulcan_y(new Object[0]) * iIntValue, Vulcan_L(new Object[0]) * iIntValue);
    }

    public Vulcan_fB Vulcan_k(Object[] objArr) {
        return Vulcan_e(new Object[]{1});
    }

    public static String spigot() {
        return b[1];
    }

    public static String nonce() {
        return b[2];
    }

    public static String resource() {
        return b[0];
    }

    public Vulcan_fB Vulcan_e(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.UP, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    public Vulcan_fB Vulcan_m(Object[] objArr) {
        return Vulcan_U(new Object[]{1});
    }

    public Vulcan_fB Vulcan_U(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.DOWN, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    public Vulcan_fB Vulcan_G(Object[] objArr) {
        return Vulcan_u(new Object[]{1});
    }

    public Vulcan_fB Vulcan_u(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.NORTH, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    public Vulcan_fB Vulcan__(Object[] objArr) {
        return Vulcan_S(new Object[]{1});
    }

    public Vulcan_fB Vulcan_S(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.SOUTH, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    public Vulcan_fB Vulcan_s(Object[] objArr) {
        return Vulcan_i(new Object[]{1});
    }

    public Vulcan_fB Vulcan_i(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.WEST, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    @Override // me.frep.vulcan.spigot.Vulcan_fq
    public Vulcan_fB Vulcan_H(Object[] objArr) {
        return Vulcan_F(new Object[]{1});
    }

    public Vulcan_fB Vulcan_F(Object[] objArr) {
        return Vulcan_E(new Object[]{Vulcan_kc.EAST, Integer.valueOf(((Integer) objArr[0]).intValue())});
    }

    public Vulcan_fB Vulcan_V(Object[] objArr) {
        return Vulcan_E(new Object[]{(Vulcan_kc) objArr[0], 1});
    }

    public Vulcan_fB Vulcan_E(Object[] objArr) {
        Vulcan_kc vulcan_kc = (Vulcan_kc) objArr[0];
        int iIntValue = ((Integer) objArr[1]).intValue();
        return new Vulcan_fB(Vulcan_s(new Object[0]) + (vulcan_kc.Vulcan_q() * iIntValue), Vulcan_y(new Object[0]) + (vulcan_kc.Vulcan_F() * iIntValue), Vulcan_L(new Object[0]) + (vulcan_kc.m1053Vulcan_G() * iIntValue));
    }

    public Vulcan_fB Vulcan_f(Object[] objArr) {
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[0];
        return new Vulcan_fB((Vulcan_y(new Object[0]) * vulcan_fq.Vulcan_L(new Object[0])) - (Vulcan_L(new Object[0]) * vulcan_fq.Vulcan_y(new Object[0])), (Vulcan_L(new Object[0]) * vulcan_fq.Vulcan_s(new Object[0])) - (Vulcan_s(new Object[0]) * vulcan_fq.Vulcan_L(new Object[0])), (Vulcan_s(new Object[0]) * vulcan_fq.Vulcan_y(new Object[0])) - (Vulcan_y(new Object[0]) * vulcan_fq.Vulcan_s(new Object[0])));
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public long m665Vulcan_g(Object[] objArr) {
        return ((((long) Vulcan_s(new Object[0])) & Vulcan_a) << Vulcan_Q) | ((((long) Vulcan_y(new Object[0])) & Vulcan_y) << Vulcan_f) | ((((long) Vulcan_L(new Object[0])) & Vulcan_d) << 0);
    }

    public static Vulcan_fB Vulcan_Q(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        return new Vulcan_fB((int) ((jLongValue << ((64 - Vulcan_Q) - Vulcan_E)) >> (64 - Vulcan_E)), (int) ((jLongValue << ((64 - Vulcan_f) - Vulcan_e)) >> (64 - Vulcan_e)), (int) ((jLongValue << (64 - Vulcan_H)) >> (64 - Vulcan_H)));
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public static Iterable m666Vulcan_f(Object[] objArr) {
        Vulcan_fB vulcan_fB = (Vulcan_fB) objArr[0];
        Vulcan_fB vulcan_fB2 = (Vulcan_fB) objArr[1];
        return new Vulcan_k_(new Vulcan_fB(Math.min(vulcan_fB.Vulcan_s(new Object[0]), vulcan_fB2.Vulcan_s(new Object[0])), Math.min(vulcan_fB.Vulcan_y(new Object[0]), vulcan_fB2.Vulcan_y(new Object[0])), Math.min(vulcan_fB.Vulcan_L(new Object[0]), vulcan_fB2.Vulcan_L(new Object[0]))), new Vulcan_fB(Math.max(vulcan_fB.Vulcan_s(new Object[0]), vulcan_fB2.Vulcan_s(new Object[0])), Math.max(vulcan_fB.Vulcan_y(new Object[0]), vulcan_fB2.Vulcan_y(new Object[0])), Math.max(vulcan_fB.Vulcan_L(new Object[0]), vulcan_fB2.Vulcan_L(new Object[0]))));
    }

    public static Iterable Vulcan_K(Object[] objArr) {
        Vulcan_fB vulcan_fB = (Vulcan_fB) objArr[0];
        Vulcan_fB vulcan_fB2 = (Vulcan_fB) objArr[1];
        return new C0048Vulcan_fw(new Vulcan_fB(Math.min(vulcan_fB.Vulcan_s(new Object[0]), vulcan_fB2.Vulcan_s(new Object[0])), Math.min(vulcan_fB.Vulcan_y(new Object[0]), vulcan_fB2.Vulcan_y(new Object[0])), Math.min(vulcan_fB.Vulcan_L(new Object[0]), vulcan_fB2.Vulcan_L(new Object[0]))), new Vulcan_fB(Math.max(vulcan_fB.Vulcan_s(new Object[0]), vulcan_fB2.Vulcan_s(new Object[0])), Math.max(vulcan_fB.Vulcan_y(new Object[0]), vulcan_fB2.Vulcan_y(new Object[0])), Math.max(vulcan_fB.Vulcan_L(new Object[0]), vulcan_fB2.Vulcan_L(new Object[0]))));
    }

    @Override // me.frep.vulcan.spigot.Vulcan_fq
    public Vulcan_fq Vulcan_H(Object[] objArr) {
        return Vulcan_f(new Object[]{(Vulcan_fq) objArr[0]});
    }
}
