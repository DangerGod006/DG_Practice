package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Oo, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oo.class */
public final class C0039Vulcan_Oo {
    private Object Vulcan_B;
    private Object Vulcan_a;
    private static final long a = Vulcan_n.a(4564273050164564917L, 6948044493387257670L, MethodHandles.lookup().lookupClass()).a(122905508632096L);
    private static final String[] b;

    static {
        long j = a ^ 37370900761713L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "\u009bz\u0093Ñ¡}`ä\bp\u0001ì«þþ°k".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("\u009bz\u0093Ñ¡}`ä\bp\u0001ì«þþ°k".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                return;
            }
            cCharAt = "\u009bz\u0093Ñ¡}`ä\bp\u0001ì«þþ°k".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_f(Object[] objArr) {
        this.Vulcan_B = objArr[0];
    }

    public void Vulcan_J(Object[] objArr) {
        this.Vulcan_a = objArr[0];
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            Method dump skipped, instruction units count: 247
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0039Vulcan_Oo.equals(java.lang.Object):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [int] */
    /* JADX WARN: Type inference failed for: r0v21, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.Object] */
    public int hashCode() {
        int iHashCode;
        int iHashCode2;
        long j = a ^ 117161501365478L;
        AbstractCheck[] abstractCheckArrVulcan_M = C0036Vulcan_Oj.Vulcan_M();
        ?? Vulcan_C = Vulcan_C(new Object[0]);
        try {
            try {
                Vulcan_C = 1 * 59;
                ?? r1 = Vulcan_C;
                ?? r12 = r1;
                if (abstractCheckArrVulcan_M != null) {
                    iHashCode = r12.hashCode();
                } else if (r1 == 0) {
                    iHashCode = 43;
                } else {
                    r12 = Vulcan_C;
                    iHashCode = r12.hashCode();
                }
                int i = Vulcan_C + iHashCode;
                ?? Vulcan_m = Vulcan_m(new Object[0]);
                try {
                    try {
                        Vulcan_m = i * 59;
                        ?? r13 = Vulcan_m;
                        ?? r14 = r13;
                        if (abstractCheckArrVulcan_M != null) {
                            iHashCode2 = r14.hashCode();
                        } else if (r13 == 0) {
                            iHashCode2 = 43;
                        } else {
                            r14 = Vulcan_m;
                            iHashCode2 = r14.hashCode();
                        }
                        ?? r0 = Vulcan_m + iHashCode2;
                        if (abstractCheckArrVulcan_M != null) {
                            try {
                                AbstractCheck.Vulcan_D(new AbstractCheck[1]);
                            } catch (RuntimeException unused) {
                                throw a((RuntimeException) r0);
                            }
                        }
                        return r0;
                    } catch (RuntimeException unused2) {
                        throw a((RuntimeException) Vulcan_m);
                    }
                } catch (RuntimeException unused3) {
                    Vulcan_m = a((RuntimeException) Vulcan_m);
                    throw Vulcan_m;
                }
            } catch (RuntimeException unused4) {
                throw a((RuntimeException) Vulcan_C);
            }
        } catch (RuntimeException unused5) {
            Vulcan_C = a((RuntimeException) Vulcan_C);
            throw Vulcan_C;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    public String toString() {
        long j = a ^ 137180220344614L;
        ?? Vulcan_M = C0036Vulcan_Oj.Vulcan_M();
        try {
            Vulcan_M = b[0] + Vulcan_C(new Object[0]) + b[1] + Vulcan_m(new Object[0]) + ")";
            if (AbstractCheck.Vulcan_k() != null) {
                C0036Vulcan_Oj.Vulcan_G(new AbstractCheck[4]);
            }
            return Vulcan_M;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_M);
        }
    }

    public C0039Vulcan_Oo(Object obj, Object obj2) {
        this.Vulcan_B = obj;
        this.Vulcan_a = obj2;
    }

    public Object Vulcan_C(Object[] objArr) {
        return this.Vulcan_B;
    }

    public Object Vulcan_m(Object[] objArr) {
        return this.Vulcan_a;
    }
}
