package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.packettype.PacketType;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_f8.class */
/* synthetic */ class Vulcan_f8 {
    static final int[] Vulcan_m = new int[PacketType.Play.Server.values().length];

    static {
        try {
            Vulcan_m[PacketType.Play.Server.JOIN_GAME.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.PING.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.WINDOW_CONFIRMATION.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_VELOCITY.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.EXPLOSION.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.PLAYER_POSITION_AND_LOOK.ordinal()] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_METADATA.ordinal()] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.UPDATE_ATTRIBUTES.ordinal()] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.PLAYER_ABILITIES.ordinal()] = 9;
        } catch (NoSuchFieldError e9) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.HELD_ITEM_CHANGE.ordinal()] = 10;
        } catch (NoSuchFieldError e10) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_EFFECT.ordinal()] = 11;
        } catch (NoSuchFieldError e11) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.REMOVE_ENTITY_EFFECT.ordinal()] = 12;
        } catch (NoSuchFieldError e12) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.CHANGE_GAME_STATE.ordinal()] = 13;
        } catch (NoSuchFieldError e13) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_RELATIVE_MOVE.ordinal()] = 14;
        } catch (NoSuchFieldError e14) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_RELATIVE_MOVE_AND_ROTATION.ordinal()] = 15;
        } catch (NoSuchFieldError e15) {
        }
        try {
            Vulcan_m[PacketType.Play.Server.ENTITY_ANIMATION.ordinal()] = 16;
        } catch (NoSuchFieldError e16) {
        }
    }
}
