package me.frep.vulcan.spigot.check.impl.player.invalid;

import java.lang.invoke.MethodHandles;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/invalid/InvalidA.class */
@CheckInfo(name = "Invalid", type = 'A', complexType = "Invalid", description = "Possible transaction disabler. Do not ban for this check.")
public class InvalidA extends AbstractCheck {
    private int Vulcan_B;
    private static final long b = Vulcan_n.a(-6540607720966383552L, -6688100392253521100L, MethodHandles.lookup().lookupClass()).a(244479760586229L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public InvalidA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 39547477406479L;
        ?? Vulcan_Z = InvalidJ.Vulcan_Z();
        try {
            this.Vulcan_B = 0;
            if (Vulcan_Z != 0) {
                Vulcan_Z = new AbstractCheck[5];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_Z);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_Z);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00f1 A[PHI: r0
  0x00f1: PHI (r0v50 ??) = (r0v10 ??), (r0v28 ??), (r0v29 ??), (r0v33 ??) binds: [B:14:0x005c, B:52:0x00ea, B:21:0x0076, B:33:0x00a4] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v26, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v41, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v45, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v46, types: [int] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v50, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r1v37 */
    /* JADX WARN: Type inference failed for: r2v15, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 293
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA.Vulcan_T(java.lang.Object[]):void");
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
