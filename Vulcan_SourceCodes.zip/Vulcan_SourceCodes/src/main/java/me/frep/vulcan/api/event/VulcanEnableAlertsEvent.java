package me.frep.vulcan.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/api/event/VulcanEnableAlertsEvent.class */
public class VulcanEnableAlertsEvent extends Event implements Cancellable {
    private boolean cancelled;
    private final Player player;
    private final long timestamp = System.currentTimeMillis();
    private static final HandlerList handlers = new HandlerList();

    public Player getPlayer() {
        return this.player;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public VulcanEnableAlertsEvent(Player player) {
        this.player = player;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean z) {
        this.cancelled = z;
    }
}
