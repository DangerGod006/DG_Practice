package me.frep.vulcan.spigot.check.impl.player.invalid;

import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/invalid/InvalidB.class */
@CheckInfo(name = "Invalid", type = 'B', complexType = "Invalid", description = "Spamming ghost block setbacks. Do not ban for this check.")
public class InvalidB extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public InvalidB(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:19:0x007b  */
    /* JADX WARN: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidB] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.invalid.InvalidB] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v0, types: [me.frep.vulcan.spigot.check.impl.player.invalid.InvalidB] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r12 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r0 = r10
            r1 = r0; r2 = r0; 
            r2 = 108218722128643(0x626ca27d9303, double:5.34671528406024E-310)
            long r1 = r1 ^ r2
            r13 = r1
            r1 = r0; r2 = r0; 
            r2 = 62660962465647(0x38fd6468b76f, double:3.0958628889624E-310)
            long r1 = r1 ^ r2
            r15 = r1
            java.lang.String r0 = me.frep.vulcan.spigot.check.impl.player.invalid.InvalidJ.Vulcan_Z()
            r17 = r0
            r0 = r8
            r1 = r12
            r2 = r15
            r3 = 2
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L4e
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L4e
            r5 = r4; r4 = r3; r3 = r2; r2 = r5;      // Catch: java.lang.RuntimeException -> L4e
            java.lang.Long r4 = java.lang.Long.valueOf(r4)     // Catch: java.lang.RuntimeException -> L4e
            r5 = 1
            r6 = r4; r4 = r5; r5 = r6;      // Catch: java.lang.RuntimeException -> L4e
            r3[r4] = r5     // Catch: java.lang.RuntimeException -> L4e
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L4e
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L4e
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L4e
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L4e
            boolean r0 = r0.Vulcan_G(r1)     // Catch: java.lang.RuntimeException -> L4e
            r1 = r17
            if (r1 != 0) goto L77
            if (r0 == 0) goto L95
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5b
            throw r0     // Catch: java.lang.RuntimeException -> L5b
        L52:
            r0 = r8
            r1 = r17
            if (r1 != 0) goto L83
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L73
            throw r0     // Catch: java.lang.RuntimeException -> L73
        L5f:
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_b     // Catch: java.lang.RuntimeException -> L73
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L73
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L73
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L73
            int r0 = r0.m986Vulcan_k(r1)     // Catch: java.lang.RuntimeException -> L73
            goto L77
        L73:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L77:
            r1 = 5
            if (r0 <= r1) goto L95
            r0 = r8
            goto L83
        L7f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L83:
            r1 = r13
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_K(r1)
        L95:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.invalid.InvalidB.Vulcan_T(java.lang.Object[]):void");
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
