package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import java.lang.invoke.MethodHandles;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_yU.class */
public final class Vulcan_yU {
    public static final Vulcan_yU TPS;
    public static final Vulcan_yU CHUNK;
    public static final Vulcan_yU JOINED;
    public static final Vulcan_yU CAKE;
    public static final Vulcan_yU BAMBOO;
    public static final Vulcan_yU HAPPY_GHAST;
    public static final Vulcan_yU PACKET_EXPLOSION;
    public static final Vulcan_yU ENTITY_CRAM_FIX;
    public static final Vulcan_yU AROUND_SLIME;
    public static final Vulcan_yU SIGN;
    public static final Vulcan_yU PRESSURE_PLATE;
    public static final Vulcan_yU SWIMMING;
    public static final Vulcan_yU SWIMMING_JESUS;
    public static final Vulcan_yU COLLIDING_HORIZONTALLY;
    public static final Vulcan_yU DRIPSTONE;
    public static final Vulcan_yU HIGH_FLY_SPEED;
    public static final Vulcan_yU GLITCHED_BLOCKS_ABOVE;
    public static final Vulcan_yU PROJECTILE_DAMAGE;
    public static final Vulcan_yU CHEST;
    public static final Vulcan_yU ATTACK_DAMAGE;
    public static final Vulcan_yU SKULL;
    public static final Vulcan_yU EXPLOSION;
    public static final Vulcan_yU STAIRS;
    public static final Vulcan_yU HIGH_LEVITATION;
    public static final Vulcan_yU FENCE_GATE;
    public static final Vulcan_yU POWDER_SNOW;
    public static final Vulcan_yU DRAGON_DAMAGE;
    public static final Vulcan_yU JUMP_BOOST_RAN_OUT;
    public static final Vulcan_yU LAGGED_NEAR_GROUND;
    public static final Vulcan_yU SNOW;
    public static final Vulcan_yU NETHERITE_ARMOR;
    public static final Vulcan_yU FAST_ZERO;
    public static final Vulcan_yU JOINED_CHUNK_LOAD;
    public static final Vulcan_yU NEAR_SOLID;
    public static final Vulcan_yU CAMPFIRE;
    public static final Vulcan_yU CANCELLED_MOVE;
    public static final Vulcan_yU CARPET;
    public static final Vulcan_yU FLOWER_POT;
    public static final Vulcan_yU EMPTIED_BUCKET;
    public static final Vulcan_yU END_ROD;
    public static final Vulcan_yU HOPPER;
    public static final Vulcan_yU CHAIN;
    public static final Vulcan_yU DOOR;
    public static final Vulcan_yU PICKED_UP_ITEM;
    public static final Vulcan_yU ANVIL;
    public static final Vulcan_yU LAGGED_NEAR_GROUND_MODERN;
    public static final Vulcan_yU FULLY_SUBMERGED;
    public static final Vulcan_yU RESPAWN;
    public static final Vulcan_yU ICE;
    public static final Vulcan_yU BED;
    public static final Vulcan_yU SLAB;
    public static final Vulcan_yU HIGH_JUMP_BOOST;
    public static final Vulcan_yU LILY_PAD;
    public static final Vulcan_yU HIGH_SPEED;
    public static final Vulcan_yU WALL;
    public static final Vulcan_yU SWEET_BERRIES;
    public static final Vulcan_yU CONDUIT;
    public static final Vulcan_yU PLACED_WEB;
    public static final Vulcan_yU PISTON;
    public static final Vulcan_yU CHORUS_FRUIT;
    public static final Vulcan_yU ENDER_PEARL;
    public static final Vulcan_yU NEAR_GROUND;
    public static final Vulcan_yU SLEEPING;
    public static final Vulcan_yU SOUL_SPEED;
    public static final Vulcan_yU TRAPDOOR;
    public static final Vulcan_yU FISHING_ROD;
    public static final Vulcan_yU PLUGIN_LOAD;
    public static final Vulcan_yU RIPTIDE;
    public static final Vulcan_yU FIREWORK;
    public static final Vulcan_yU SPECTATOR;
    public static final Vulcan_yU CAULDRON;
    public static final Vulcan_yU ENTITY_COLLISION;
    public static final Vulcan_yU DEATH;
    public static final Vulcan_yU DEPTH_STRIDER;
    public static final Vulcan_yU LEVITATION;
    public static final Vulcan_yU FROZEN;
    public static final Vulcan_yU DIGGING;
    public static final Vulcan_yU BLOCK_BREAK;
    public static final Vulcan_yU PLACING;
    public static final Vulcan_yU SERVER_POSITION;
    public static final Vulcan_yU SERVER_POSITION_FAST;
    public static final Vulcan_yU CANCELLED_PLACE;
    public static final Vulcan_yU BLOCK_PLACE;
    public static final Vulcan_yU BLOCK_PLACE_FAST;
    public static final Vulcan_yU SWIMMING_ON_OLD_VERSION;
    public static final Vulcan_yU FULLY_STUCK;
    public static final Vulcan_yU PLACED_CLIMBABLE;
    public static final Vulcan_yU PARTIALLY_STUCK;
    public static final Vulcan_yU NOT_MOVING;
    public static final Vulcan_yU PLACED_SLIME;
    public static final Vulcan_yU FIREBALL;
    public static final Vulcan_yU WORLD_CHANGE;
    public static final Vulcan_yU FALL_DAMAGE;
    public static final Vulcan_yU ILLEGAL_BLOCK;
    public static final Vulcan_yU HONEY;
    public static final Vulcan_yU SCAFFOLDING;
    public static final Vulcan_yU HALF_BLOCK;
    public static final Vulcan_yU SHULKER;
    public static final Vulcan_yU GLIDING;
    public static final Vulcan_yU ELYTRA;
    public static final Vulcan_yU VELOCITY;
    public static final Vulcan_yU DEAD;
    public static final Vulcan_yU WEB;
    public static final Vulcan_yU SOUL_SAND;
    public static final Vulcan_yU CINEMATIC;
    public static final Vulcan_yU FAST;
    public static final Vulcan_yU LENIENT_SCAFFOLDING;
    public static final Vulcan_yU WINDOW_CLICK;
    public static final Vulcan_yU DROPPED_ITEM;
    public static final Vulcan_yU CANCELLED_BREAK;
    public static final Vulcan_yU MYTHIC_MOB;
    public static final Vulcan_yU CREATIVE;
    public static final Vulcan_yU AUTOCLICKER_NON_DIG;
    public static final Vulcan_yU AUTOCLICKER;
    public static final Vulcan_yU COLLIDING_VERTICALLY;
    public static final Vulcan_yU SLOW_FALLING;
    public static final Vulcan_yU BUBBLE_COLUMN;
    public static final Vulcan_yU FENCE;
    public static final Vulcan_yU JUMP_BOOST;
    public static final Vulcan_yU FLIGHT;
    public static final Vulcan_yU COMBO_MODE;
    public static final Vulcan_yU DOLPHINS_GRACE;
    public static final Vulcan_yU TELEPORT;
    public static final Vulcan_yU SERVER_VERSION;
    public static final Vulcan_yU KELP;
    public static final Vulcan_yU CLIENT_VERSION;
    public static final Vulcan_yU SLIME;
    public static final Vulcan_yU BOAT;
    public static final Vulcan_yU SEA_PICKLE;
    public static final Vulcan_yU SEAGRASS;
    public static final Vulcan_yU TURTLE_EGG;
    public static final Vulcan_yU SHULKER_BOX;
    public static final Vulcan_yU WATERLOGGED;
    public static final Vulcan_yU CLIMBABLE;
    public static final Vulcan_yU LIQUID;
    public static final Vulcan_yU GLASS_PANE;
    public static final Vulcan_yU FARMLAND;
    public static final Vulcan_yU VEHICLE;
    public static final Vulcan_yU VOID;
    private final Function Vulcan_Z;
    private static final Vulcan_yU[] Vulcan_y;
    private static int[] Vulcan_Y;
    private static final long a = Vulcan_n.a(-6267291020182990484L, 845575622367396574L, MethodHandles.lookup().lookupClass()).a(18006566270499L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005d: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.Boolean lambda$static$121(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 7132722007548(0x67cb75c8dfc, double:3.5240329052653E-311)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 106936849899569(0x61422cf3a031, double:5.2833823809859E-310)
            long r1 = r1 ^ r2
            r10 = r1
            int[] r0 = m1096Vulcan_n()
            r12 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L27
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L27
            r1 = r12
            if (r1 == 0) goto L41
            if (r0 == 0) goto L83
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3d
            throw r0     // Catch: java.lang.RuntimeException -> L3d
        L2b:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3d
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3d
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3d
            int r0 = r0.m941Vulcan_S(r1)     // Catch: java.lang.RuntimeException -> L3d
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r1 = r12
            if (r1 == 0) goto L80
            r1 = 50
            if (r0 < r1) goto L7f
            goto L52
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L71
            throw r0     // Catch: java.lang.RuntimeException -> L71
        L52:
            r0 = r10
            r1 = r7
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r1[r2] = r3     // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            boolean r0 = me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan__(r0)     // Catch: java.lang.RuntimeException -> L71 java.lang.RuntimeException -> L7b
            r1 = r12
            if (r1 == 0) goto L80
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7b
            throw r0     // Catch: java.lang.RuntimeException -> L7b
        L75:
            if (r0 == 0) goto L83
            goto L7f
        L7b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7f:
            r0 = 1
        L80:
            goto L84
        L83:
            r0 = 0
        L84:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$121(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0060: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.Boolean lambda$static$113(me.frep.vulcan.spigot.C0042Vulcan_Oz r8) {
        /*
            Method dump skipped, instruction units count: 674
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$113(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0060: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.Boolean lambda$static$112(me.frep.vulcan.spigot.C0042Vulcan_Oz r8) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$112(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x001b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.Boolean lambda$static$30(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 103403918814421(0x5e0b99d96cd5, double:5.10883239315627E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 102020698915296(0x5cc98b84c1e0, double:5.0404922498761E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r0 = r10
            r1 = r7
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            boolean r0 = me.frep.vulcan.spigot.C0044Vulcan_fb.Vulcan_l(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$30(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x001a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static java.lang.Boolean lambda$static$0(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 73986156633005(0x434a3e959bad, double:3.6554018260197E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 40175702083080(0x248a22738608, double:1.98494341968024E-310)
            long r1 = r1 ^ r2
            r10 = r1
            int[] r0 = m1096Vulcan_n()
            r12 = r0
            r0 = r10
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L35
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.RuntimeException -> L35
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L35
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch: java.lang.RuntimeException -> L35
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L35
            r1[r2] = r3     // Catch: java.lang.RuntimeException -> L35
            double r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q(r0)     // Catch: java.lang.RuntimeException -> L35
            r1 = 4626111610983809024(0x4033400000000000, double:19.25)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            if (r1 == 0) goto L3a
            if (r0 >= 0) goto L3d
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L39:
            r0 = 1
        L3a:
            goto L3e
        L3d:
            r0 = 0
        L3e:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$0(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    public static void Vulcan_o(int[] iArr) {
        Vulcan_Y = iArr;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public static int[] m1096Vulcan_n() {
        return Vulcan_Y;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public static Vulcan_yU[] values() {
        return (Vulcan_yU[]) Vulcan_y.clone();
    }

    public static Vulcan_yU valueOf(String str) {
        return (Vulcan_yU) Enum.valueOf(Vulcan_yU.class, str);
    }

    static {
        int i;
        long j = a ^ 74933883782601L;
        Vulcan_o(new int[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[139];
        int i3 = 0;
        String str = "÷MÊT\u008f:¼Í\u0013Sôn\r\u0015\u009bf\u0018¬°MÂ¸\u007f\u0003²:ÓL\u0002gFJß©°OÐôóXG\bjYí\u009aàQ²¹\u0010GöÇã\\t'²\u0012\u0011\"#rèÅå\u0018Ö0÷;TIæ\u00adÔV/Þz´Ä\u0087\u0000Âßÿ\u0085í}Æ\u0010ØmÌò\u001a;øJs\u0093Ê\u000f¿Û\u0084\n\u0010¬ÓO\u00820ï¾*\r\u0013\u0096\u0095²Ñ\u0090»\u0018³ÏiÈ\u0099y\b?\u0084\u0012=Ó\u008a\u001b\u0003\u0091[HZ*\u0097íd¥\u0010\u000b½\u0091ï(5ÂnÖ%åä\u0004üñI\bòk\u0089´ÞÕT\\\u0010&86q\u009b\u0099-¤\\\u007fV3\u0005¼TÓ\u0010F\u0007è\u0002mzãìÛ\u0093³<j©]º\u0010Þ%\u0099h;ù^¥M«íËù+Ý\u000f\u0010lKP0°(´\u0007\u0017dd¾m\u0096$\u0011\u0010îm\u0001\u0080ýn\u0096ì{\u0094}è\u0092\u001d$ä\b\u0012û\u0000mÈ%b\u0083\u0010>gb\u007f}»æ¸*¢î\u008e\u001cZ¦¨\b/e\u001e-¤Klá\bl9âù\u0000´\u0013}\u0010nõF9IT¿\u0002\u00968èµ87Òç\bþü]D\u0002¦-ð\b±\u008cäm\u0004b·Ò\b2Æp\\øÁ\u0015¦\u0018\u001cÕZ$\u0098ênW~\u000e)Ú[&¥Nj\u0095ø\u008c0\u000e\u0019l\b\u0001Ie4\u000btéÄ\u0010:\u009a\r°\u009a;\u0087A#Åé\u009d\fS\u001d\u0004\u0010$ÿ²AFyà´\u009a¾ríå¡QW\u0010U\u0013Ly¼í£aêEö\u009e\u0097,\u0005\u0090\b\u0095Ã6Y\r\u001dP\u0000\u0010>ýc»¦ð¤oØ\u0099L´ ÜÏ\u0018\u0018Ó´Ä\u001fr÷ Wr\u0083:Óm\u0090Ø!\u0082\t/¸\u0085ë3ª\b\u0006A\"ª®-¹Ä\u0010ô\u0086\u0002êè¥*Ø\u0000[ù7\u00021IÏ\u0010ÅæÒ\u0095ÀQ\"5#´Û\u0013D(øÄ\u0018$ÿ²AFyà´ä×8§c\u0090\u0004ïü]\u0096â\u0003ÐÑ&\u0010S\u0019\t\u001a>àÐiOJÜ\u009dyQöA\u0010Z\u0091\u009býæÒÀ=\u0086¼ç¦.åN%\u0010\u001aÆdD\u0084\\\u001ao'¸^}1¸«Ù\u0010Ã\u009e\u0095.ÅÌc\u0098¸zyF\u008e\u0010Ë\u0019 -È \u0001\n\u009b«ÞI\u0019\u009c k\u0011\u001bC\u001b\u008bñ\u009c5Ñ[\u0000§;;\u0080÷(\u0011Ó\bÀrCk{ô\u009f\u008d\u0010({ßà³y×¦®=\u001c\u0011Ü\u008fB{\u0010¼Üº\u0098qB¼ïN¶»\b¤<©\u0000\bP\u008b\u001aë¡:\u0016©\u0010\u0090¤Ã\u0018l\u0004>°·±'f\u001dWù5\u0018 \u001bò\u0087ö6WH\rH¬N%Ú\u000bu\u007f\u009a66¸Ö\u0094\u001a\u0010W =5<Cé¼E\u0004JY6\u0017,\u001d\u0010{©lÒÆ\u0086\\Ðîöâ\u0010\u009b\u0097¨ð\u001051\u0082Ëûýî\u001f¥Â¦ù·\u001coq\böøF®& [D\b@\u009fÞÅÓ©&\u0097\u0010v\rÉÕ,-kü0Qï½dÞ\u009ao\u0010Õ\u0080\u008b7¥ÛÀµ\u008e!L\u009c¡vQ8\b\u00192\u0088\u0004aH\u0011\u000f\u0010\u0014=|éLÓznè¢\u0017_»\u0014îÂ\u0010\u000f1\u0088\u0002é¯A\u008f³=ªJÇ\u009cÖ\u007f\u0010ÓÑÎÝ3A\u0096\u007fOªÙ¼Ë\u008d·Æ\u00108«$À\u008aù\tÝ\u000b\u009b\u0090\u009b\u0092°Ç\u000b\u0010Å¢\u0003§Ö/7«EÑ4l\u0098&|\u008d\u0010dPóêÐWö\u008c\u000bÁ¨\u008fVr\u0093+\u00107câ û\u008f&ÌÃ;5Ì\u0018Ð\u0087\u008c\u0010È\u0016+\\\u0012}¶úd%ÔýF\u0085YÊ\u0018{©lÒÆ\u0086\\Ð¬Ã\u0013Ý\u0093ò\u0013zØ\u0000\fg\u0015ÜL3\b4±À\"Ú×'j\u0010¨ø8þÒª*[F\u0094\u009aø\u0090;\r\u0006\u0018-È \u0001\n\u009b«ÞI\u0019\u009c k\u0011\u001bC\u000e\u0083îe\b\u0011CÈ\u0010`U.Û\u0088îí\u001bLK¨\u0011ä~ê\\\u0018²Ö/Ç]ÇûØµK=¦\u0006\u0000\u00175G»$É\u00adY\u0006\u0007\u0010\u0083%\u00ad¨%ì¢ªE$\u0005uâ\u001c\u008a#\u0010^á\u0096<FªÀ'.ô #¦\u0095\fH\u0010Ö0÷;TIæ\u00adæI²wí\u0096°'\u001094½qã/5¿VÚgFKÔÓ|\u0010¸ß©£Ð\u008c\u0019K\u0095ÒÖ\u0011\u000eÀTl\bÞ{\u00822Þ!Ã\\\bre\u0019<'\u0003\u001c\b\u0018\n½£alÐ\u001f\u0088-{\u0015msÃS\u0015|ý\u00869\u000be%Ô\u0010ç\u0019£fúáM½\u009d5\u0007)\u0082/\u008aþ\u0010.\u0016ü\u001bñÈjq(\u008d\u0083\u0085\nQ\r6\bí\u001dðõ\u0018«T\u00ad\b\nJõ½\nor[\u0010L JÅ8\u0004\u0096Éí\u0004\u001fùJ\u0086e\u0092\u0010S\u0089KRõ\\+äb&¡\u0080IÞLB\b\u001cçØ6Àøò\u0090\u0010,`ê|\u0095cú),¬³ rÞc;\u0010[\u0089\u0000°\u001fM\u0081\t\u008f ¡\u0084&\u0003\u009aO\u0010ÃæY_cÜiæå%sNâFN|\u00107câ û\u008f&ÌÎPîÚ\u0083U\r\u009f\u0018÷MÊT\u008f:¼Í·W\u0017JD¸7:hêðþ\nktÐ\b\u007f½%¤\u0085\u001c\u008d\u0000\bÆ:\u0010ïx\u0097Q\u0006\u0018\n½£alÐ\u001f\u0088Î\u0095\u008bz³2¬|\u008bÙJo\u001f¶1\u000f\u00107 ô\u00adR\u0091Ai\u0018\u009eVT1\u00073\u0001\b\u0090ûù\u001a\u0092égÿ\u0010 Ë'¥³Ë\f´ÇO¡n \u0001rì\u0010´ÁËÊ\u0085\u0006±P>\u0089Ã6L<\u0005L\bN.Úã\u000býÞb\u0010ÕX@@È)!qÊð?\u0018r\u0004\tø\u0010q²^7j:ÿ\u0096Øw¶MæEGP\u0010\u0099¤M²¦?eÆêK3^(\u0019\u008aZ\bZÈu&\u0082\\3{\u0010#ã\u0092öÇ\u008b%³¸±\u0099\u008b²\u0016!\u001d\u0010P`*Ä8\u0084\u001fº\\cc\u0010Ø\u000fa\u0087\u0010Ôø\\f´\u0099\u0091\u0099C\u0081\rÁ|Ñ0²\u0010mÙJ\u008c ðZ$ÏôÀ\u00138\u0085`Ö\u0010Ú\u0084¦\u000fÕµ«>\u0083¬!W à4ù\u0010q\u001c¦èåHdÞåÅåGÐç\u001b\u0012\u0010fùºµ:3´ØÝk=èÒÈ<À\bI1õ\u008eÚ\u007fw\u009d\b1mnáj\u0004»z\bFA2Õé\u0007£\u008d\u0010wÖ&ÅQÃ²\u008a5c<¯\rèn\u008f\u0010\b~\u009f.\u0099ÞõWÀ\u0095¨ZDKÕÒ\bèó0ÿ\u0088ó§Í\u0010N\u0001â\u0085Z©\u001ed7VüG\u0087áò\u007f\bÓõ\u0003\u008aQìáI\u0010¡\u0083å³ôÇ÷\u0085iç®Mé\u0098Ùx\u0018úS>\u008b\u0000\r]\u0006'`§\r\"#^QÝ¦BÅ\u009eZL\u0097\u0010÷MÊT\u008f:¼ÍÄ§\u008dL\u0093\u0002t7\u0010\u001cÕZ$\u0098ênWQD,ï\u0013;:B\bg\u009331Å1Òd\u0010u©ÚzÜ\u009fººBw\u0080ß°»\u001fÏ\u0010Àè\u0098VçèøÇ¹Ó\u0006\u000blì\tô\u0010@NÑÒ\u008fï2K\u0093\u00ad\u0080¨Ñ¢´+\u0010i0\u0094;rHF3]!ü\"w~©»\bÉáô;.\u0004$¦\u0010n\u0081$\u008e#ê\u008f·óym\u0085Z?Äß\bç?ÇZ\u0002Dz®\u0010\u0006]8î\u00832ä©hûJýe\u0007´\u000e\u0018\u000b½\u0091ï(5Ânÿò\u0016Û.Bl>n\u0006\u0084y©Wýª\bàêCF5Å\u009dG\u00107câ û\u008f&Ì¢zRÙàÈ+Ï\u0010\u0085²ô\rVê\f1?\u000b\u0007Iã¡Y/\b7W²ôÎ®5ä\bSa<$\\\u009c°û\b\u0016i\\¬i\u001b*é\bþÞ\u001fÂ¾hî<\b\u001fÔ[\tñy-¨";
        int length = "÷MÊT\u008f:¼Í\u0013Sôn\r\u0015\u009bf\u0018¬°MÂ¸\u007f\u0003²:ÓL\u0002gFJß©°OÐôóXG\bjYí\u009aàQ²¹\u0010GöÇã\\t'²\u0012\u0011\"#rèÅå\u0018Ö0÷;TIæ\u00adÔV/Þz´Ä\u0087\u0000Âßÿ\u0085í}Æ\u0010ØmÌò\u001a;øJs\u0093Ê\u000f¿Û\u0084\n\u0010¬ÓO\u00820ï¾*\r\u0013\u0096\u0095²Ñ\u0090»\u0018³ÏiÈ\u0099y\b?\u0084\u0012=Ó\u008a\u001b\u0003\u0091[HZ*\u0097íd¥\u0010\u000b½\u0091ï(5ÂnÖ%åä\u0004üñI\bòk\u0089´ÞÕT\\\u0010&86q\u009b\u0099-¤\\\u007fV3\u0005¼TÓ\u0010F\u0007è\u0002mzãìÛ\u0093³<j©]º\u0010Þ%\u0099h;ù^¥M«íËù+Ý\u000f\u0010lKP0°(´\u0007\u0017dd¾m\u0096$\u0011\u0010îm\u0001\u0080ýn\u0096ì{\u0094}è\u0092\u001d$ä\b\u0012û\u0000mÈ%b\u0083\u0010>gb\u007f}»æ¸*¢î\u008e\u001cZ¦¨\b/e\u001e-¤Klá\bl9âù\u0000´\u0013}\u0010nõF9IT¿\u0002\u00968èµ87Òç\bþü]D\u0002¦-ð\b±\u008cäm\u0004b·Ò\b2Æp\\øÁ\u0015¦\u0018\u001cÕZ$\u0098ênW~\u000e)Ú[&¥Nj\u0095ø\u008c0\u000e\u0019l\b\u0001Ie4\u000btéÄ\u0010:\u009a\r°\u009a;\u0087A#Åé\u009d\fS\u001d\u0004\u0010$ÿ²AFyà´\u009a¾ríå¡QW\u0010U\u0013Ly¼í£aêEö\u009e\u0097,\u0005\u0090\b\u0095Ã6Y\r\u001dP\u0000\u0010>ýc»¦ð¤oØ\u0099L´ ÜÏ\u0018\u0018Ó´Ä\u001fr÷ Wr\u0083:Óm\u0090Ø!\u0082\t/¸\u0085ë3ª\b\u0006A\"ª®-¹Ä\u0010ô\u0086\u0002êè¥*Ø\u0000[ù7\u00021IÏ\u0010ÅæÒ\u0095ÀQ\"5#´Û\u0013D(øÄ\u0018$ÿ²AFyà´ä×8§c\u0090\u0004ïü]\u0096â\u0003ÐÑ&\u0010S\u0019\t\u001a>àÐiOJÜ\u009dyQöA\u0010Z\u0091\u009býæÒÀ=\u0086¼ç¦.åN%\u0010\u001aÆdD\u0084\\\u001ao'¸^}1¸«Ù\u0010Ã\u009e\u0095.ÅÌc\u0098¸zyF\u008e\u0010Ë\u0019 -È \u0001\n\u009b«ÞI\u0019\u009c k\u0011\u001bC\u001b\u008bñ\u009c5Ñ[\u0000§;;\u0080÷(\u0011Ó\bÀrCk{ô\u009f\u008d\u0010({ßà³y×¦®=\u001c\u0011Ü\u008fB{\u0010¼Üº\u0098qB¼ïN¶»\b¤<©\u0000\bP\u008b\u001aë¡:\u0016©\u0010\u0090¤Ã\u0018l\u0004>°·±'f\u001dWù5\u0018 \u001bò\u0087ö6WH\rH¬N%Ú\u000bu\u007f\u009a66¸Ö\u0094\u001a\u0010W =5<Cé¼E\u0004JY6\u0017,\u001d\u0010{©lÒÆ\u0086\\Ðîöâ\u0010\u009b\u0097¨ð\u001051\u0082Ëûýî\u001f¥Â¦ù·\u001coq\böøF®& [D\b@\u009fÞÅÓ©&\u0097\u0010v\rÉÕ,-kü0Qï½dÞ\u009ao\u0010Õ\u0080\u008b7¥ÛÀµ\u008e!L\u009c¡vQ8\b\u00192\u0088\u0004aH\u0011\u000f\u0010\u0014=|éLÓznè¢\u0017_»\u0014îÂ\u0010\u000f1\u0088\u0002é¯A\u008f³=ªJÇ\u009cÖ\u007f\u0010ÓÑÎÝ3A\u0096\u007fOªÙ¼Ë\u008d·Æ\u00108«$À\u008aù\tÝ\u000b\u009b\u0090\u009b\u0092°Ç\u000b\u0010Å¢\u0003§Ö/7«EÑ4l\u0098&|\u008d\u0010dPóêÐWö\u008c\u000bÁ¨\u008fVr\u0093+\u00107câ û\u008f&ÌÃ;5Ì\u0018Ð\u0087\u008c\u0010È\u0016+\\\u0012}¶úd%ÔýF\u0085YÊ\u0018{©lÒÆ\u0086\\Ð¬Ã\u0013Ý\u0093ò\u0013zØ\u0000\fg\u0015ÜL3\b4±À\"Ú×'j\u0010¨ø8þÒª*[F\u0094\u009aø\u0090;\r\u0006\u0018-È \u0001\n\u009b«ÞI\u0019\u009c k\u0011\u001bC\u000e\u0083îe\b\u0011CÈ\u0010`U.Û\u0088îí\u001bLK¨\u0011ä~ê\\\u0018²Ö/Ç]ÇûØµK=¦\u0006\u0000\u00175G»$É\u00adY\u0006\u0007\u0010\u0083%\u00ad¨%ì¢ªE$\u0005uâ\u001c\u008a#\u0010^á\u0096<FªÀ'.ô #¦\u0095\fH\u0010Ö0÷;TIæ\u00adæI²wí\u0096°'\u001094½qã/5¿VÚgFKÔÓ|\u0010¸ß©£Ð\u008c\u0019K\u0095ÒÖ\u0011\u000eÀTl\bÞ{\u00822Þ!Ã\\\bre\u0019<'\u0003\u001c\b\u0018\n½£alÐ\u001f\u0088-{\u0015msÃS\u0015|ý\u00869\u000be%Ô\u0010ç\u0019£fúáM½\u009d5\u0007)\u0082/\u008aþ\u0010.\u0016ü\u001bñÈjq(\u008d\u0083\u0085\nQ\r6\bí\u001dðõ\u0018«T\u00ad\b\nJõ½\nor[\u0010L JÅ8\u0004\u0096Éí\u0004\u001fùJ\u0086e\u0092\u0010S\u0089KRõ\\+äb&¡\u0080IÞLB\b\u001cçØ6Àøò\u0090\u0010,`ê|\u0095cú),¬³ rÞc;\u0010[\u0089\u0000°\u001fM\u0081\t\u008f ¡\u0084&\u0003\u009aO\u0010ÃæY_cÜiæå%sNâFN|\u00107câ û\u008f&ÌÎPîÚ\u0083U\r\u009f\u0018÷MÊT\u008f:¼Í·W\u0017JD¸7:hêðþ\nktÐ\b\u007f½%¤\u0085\u001c\u008d\u0000\bÆ:\u0010ïx\u0097Q\u0006\u0018\n½£alÐ\u001f\u0088Î\u0095\u008bz³2¬|\u008bÙJo\u001f¶1\u000f\u00107 ô\u00adR\u0091Ai\u0018\u009eVT1\u00073\u0001\b\u0090ûù\u001a\u0092égÿ\u0010 Ë'¥³Ë\f´ÇO¡n \u0001rì\u0010´ÁËÊ\u0085\u0006±P>\u0089Ã6L<\u0005L\bN.Úã\u000býÞb\u0010ÕX@@È)!qÊð?\u0018r\u0004\tø\u0010q²^7j:ÿ\u0096Øw¶MæEGP\u0010\u0099¤M²¦?eÆêK3^(\u0019\u008aZ\bZÈu&\u0082\\3{\u0010#ã\u0092öÇ\u008b%³¸±\u0099\u008b²\u0016!\u001d\u0010P`*Ä8\u0084\u001fº\\cc\u0010Ø\u000fa\u0087\u0010Ôø\\f´\u0099\u0091\u0099C\u0081\rÁ|Ñ0²\u0010mÙJ\u008c ðZ$ÏôÀ\u00138\u0085`Ö\u0010Ú\u0084¦\u000fÕµ«>\u0083¬!W à4ù\u0010q\u001c¦èåHdÞåÅåGÐç\u001b\u0012\u0010fùºµ:3´ØÝk=èÒÈ<À\bI1õ\u008eÚ\u007fw\u009d\b1mnáj\u0004»z\bFA2Õé\u0007£\u008d\u0010wÖ&ÅQÃ²\u008a5c<¯\rèn\u008f\u0010\b~\u009f.\u0099ÞõWÀ\u0095¨ZDKÕÒ\bèó0ÿ\u0088ó§Í\u0010N\u0001â\u0085Z©\u001ed7VüG\u0087áò\u007f\bÓõ\u0003\u008aQìáI\u0010¡\u0083å³ôÇ÷\u0085iç®Mé\u0098Ùx\u0018úS>\u008b\u0000\r]\u0006'`§\r\"#^QÝ¦BÅ\u009eZL\u0097\u0010÷MÊT\u008f:¼ÍÄ§\u008dL\u0093\u0002t7\u0010\u001cÕZ$\u0098ênWQD,ï\u0013;:B\bg\u009331Å1Òd\u0010u©ÚzÜ\u009fººBw\u0080ß°»\u001fÏ\u0010Àè\u0098VçèøÇ¹Ó\u0006\u000blì\tô\u0010@NÑÒ\u008fï2K\u0093\u00ad\u0080¨Ñ¢´+\u0010i0\u0094;rHF3]!ü\"w~©»\bÉáô;.\u0004$¦\u0010n\u0081$\u008e#ê\u008f·óym\u0085Z?Äß\bç?ÇZ\u0002Dz®\u0010\u0006]8î\u00832ä©hûJýe\u0007´\u000e\u0018\u000b½\u0091ï(5Ânÿò\u0016Û.Bl>n\u0006\u0084y©Wýª\bàêCF5Å\u009dG\u00107câ û\u008f&Ì¢zRÙàÈ+Ï\u0010\u0085²ô\rVê\f1?\u000b\u0007Iã¡Y/\b7W²ôÎ®5ä\bSa<$\\\u009c°û\b\u0016i\\¬i\u001b*é\bþÞ\u001fÂ¾hî<\b\u001fÔ[\tñy-¨".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b = -1;
            while (true) {
                String str2 = strSubstring;
                byte b2 = b;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b2) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            TPS = new Vulcan_yU(strArr[88], 0, Vulcan_yU::lambda$static$0);
                            CHUNK = new Vulcan_yU(strArr[135], 1, Vulcan_yU::lambda$static$1);
                            JOINED = new Vulcan_yU(strArr[63], 2, Vulcan_yU::lambda$static$2);
                            CAKE = new Vulcan_yU(strArr[17], 3, Vulcan_yU::lambda$static$3);
                            BAMBOO = new Vulcan_yU(strArr[137], 4, Vulcan_yU::lambda$static$4);
                            HAPPY_GHAST = new Vulcan_yU(strArr[57], 5, Vulcan_yU::lambda$static$5);
                            PACKET_EXPLOSION = new Vulcan_yU(strArr[30], 6, Vulcan_yU::lambda$static$6);
                            ENTITY_CRAM_FIX = new Vulcan_yU(strArr[26], 7, Vulcan_yU::lambda$static$7);
                            AROUND_SLIME = new Vulcan_yU(strArr[127], 8, Vulcan_yU::lambda$static$8);
                            SIGN = new Vulcan_yU(strArr[138], 9, Vulcan_yU::lambda$static$9);
                            PRESSURE_PLATE = new Vulcan_yU(strArr[5], 10, Vulcan_yU::lambda$static$10);
                            SWIMMING = new Vulcan_yU(strArr[117], 11, Vulcan_yU::lambda$static$11);
                            SWIMMING_JESUS = new Vulcan_yU(strArr[0], 12, Vulcan_yU::lambda$static$12);
                            COLLIDING_HORIZONTALLY = new Vulcan_yU(strArr[90], 13, Vulcan_yU::lambda$static$13);
                            DRIPSTONE = new Vulcan_yU(strArr[123], 14, Vulcan_yU::lambda$static$14);
                            HIGH_FLY_SPEED = new Vulcan_yU(strArr[56], 15, Vulcan_yU::lambda$static$15);
                            GLITCHED_BLOCKS_ABOVE = new Vulcan_yU(strArr[45], 16, Vulcan_yU::lambda$static$16);
                            PROJECTILE_DAMAGE = new Vulcan_yU(strArr[1], 17, Vulcan_yU::lambda$static$17);
                            CHEST = new Vulcan_yU(strArr[9], 18, Vulcan_yU::lambda$static$18);
                            ATTACK_DAMAGE = new Vulcan_yU(strArr[35], 19, Vulcan_yU::lambda$static$19);
                            SKULL = new Vulcan_yU(strArr[119], 20, Vulcan_yU::lambda$static$20);
                            EXPLOSION = new Vulcan_yU(strArr[80], 21, Vulcan_yU::lambda$static$21);
                            STAIRS = new Vulcan_yU(strArr[53], 22, Vulcan_yU::lambda$static$22);
                            HIGH_LEVITATION = new Vulcan_yU(strArr[6], 23, Vulcan_yU::lambda$static$23);
                            FENCE_GATE = new Vulcan_yU(strArr[131], 24, Vulcan_yU::lambda$static$24);
                            POWDER_SNOW = new Vulcan_yU(strArr[101], 25, Vulcan_yU::lambda$static$25);
                            DRAGON_DAMAGE = new Vulcan_yU(strArr[48], 26, Vulcan_yU::lambda$static$26);
                            JUMP_BOOST_RAN_OUT = new Vulcan_yU(strArr[128], 27, Vulcan_yU::lambda$static$27);
                            LAGGED_NEAR_GROUND = new Vulcan_yU(strArr[65], 28, Vulcan_yU::lambda$static$28);
                            SNOW = new Vulcan_yU(strArr[31], 29, Vulcan_yU::lambda$static$29);
                            NETHERITE_ARMOR = new Vulcan_yU(strArr[13], 30, Vulcan_yU::lambda$static$30);
                            FAST_ZERO = new Vulcan_yU(strArr[41], 31, Vulcan_yU::lambda$static$31);
                            JOINED_CHUNK_LOAD = new Vulcan_yU(strArr[7], 32, Vulcan_yU::lambda$static$32);
                            NEAR_SOLID = new Vulcan_yU(strArr[12], 33, Vulcan_yU::lambda$static$33);
                            CAMPFIRE = new Vulcan_yU(strArr[84], 34, Vulcan_yU::lambda$static$34);
                            CANCELLED_MOVE = new Vulcan_yU(strArr[60], 35, Vulcan_yU::lambda$static$35);
                            CARPET = new Vulcan_yU(strArr[18], 36, Vulcan_yU::lambda$static$36);
                            FLOWER_POT = new Vulcan_yU(strArr[37], 37, Vulcan_yU::lambda$static$37);
                            EMPTIED_BUCKET = new Vulcan_yU(strArr[64], 38, Vulcan_yU::lambda$static$38);
                            END_ROD = new Vulcan_yU(strArr[2], 39, Vulcan_yU::lambda$static$39);
                            HOPPER = new Vulcan_yU(strArr[79], 40, Vulcan_yU::lambda$static$40);
                            CHAIN = new Vulcan_yU(strArr[107], 41, Vulcan_yU::lambda$static$41);
                            DOOR = new Vulcan_yU(strArr[28], 42, Vulcan_yU::lambda$static$42);
                            PICKED_UP_ITEM = new Vulcan_yU(strArr[85], 43, Vulcan_yU::lambda$static$43);
                            ANVIL = new Vulcan_yU(strArr[74], 44, Vulcan_yU::lambda$static$44);
                            LAGGED_NEAR_GROUND_MODERN = new Vulcan_yU(strArr[39], 45, Vulcan_yU::lambda$static$45);
                            FULLY_SUBMERGED = new Vulcan_yU(strArr[66], 46, Vulcan_yU::lambda$static$46);
                            RESPAWN = new Vulcan_yU(strArr[108], 47, Vulcan_yU::lambda$static$47);
                            ICE = new Vulcan_yU(strArr[49], 48, Vulcan_yU::lambda$static$48);
                            BED = new Vulcan_yU(strArr[92], 49, Vulcan_yU::lambda$static$49);
                            SLAB = new Vulcan_yU(strArr[129], 50, Vulcan_yU::lambda$static$50);
                            HIGH_JUMP_BOOST = new Vulcan_yU(strArr[33], 51, Vulcan_yU::lambda$static$51);
                            LILY_PAD = new Vulcan_yU(strArr[83], 52, Vulcan_yU::lambda$static$52);
                            HIGH_SPEED = new Vulcan_yU(strArr[55], 53, Vulcan_yU::lambda$static$53);
                            WALL = new Vulcan_yU(strArr[99], 54, Vulcan_yU::lambda$static$54);
                            SWEET_BERRIES = new Vulcan_yU(strArr[16], 55, Vulcan_yU::lambda$static$55);
                            CONDUIT = new Vulcan_yU(strArr[124], 56, Vulcan_yU::lambda$static$56);
                            PLACED_WEB = new Vulcan_yU(strArr[94], 57, Vulcan_yU::lambda$static$57);
                            PISTON = new Vulcan_yU(strArr[89], 58, Vulcan_yU::lambda$static$58);
                            CHORUS_FRUIT = new Vulcan_yU(strArr[27], 59, Vulcan_yU::lambda$static$59);
                            ENDER_PEARL = new Vulcan_yU(strArr[19], 60, Vulcan_yU::lambda$static$60);
                            NEAR_GROUND = new Vulcan_yU(strArr[98], 61, Vulcan_yU::lambda$static$61);
                            SLEEPING = new Vulcan_yU(strArr[29], 62, Vulcan_yU::lambda$static$62);
                            SOUL_SPEED = new Vulcan_yU(strArr[100], 63, Vulcan_yU::lambda$static$63);
                            TRAPDOOR = new Vulcan_yU(strArr[113], 64, Vulcan_yU::lambda$static$64);
                            FISHING_ROD = new Vulcan_yU(strArr[68], 65, Vulcan_yU::lambda$static$65);
                            PLUGIN_LOAD = new Vulcan_yU(strArr[51], 66, Vulcan_yU::lambda$static$66);
                            RIPTIDE = new Vulcan_yU(strArr[112], 67, Vulcan_yU::lambda$static$67);
                            FIREWORK = new Vulcan_yU(strArr[11], 68, Vulcan_yU::lambda$static$68);
                            SPECTATOR = new Vulcan_yU(strArr[14], 69, Vulcan_yU::lambda$static$69);
                            CAULDRON = new Vulcan_yU(strArr[71], 70, Vulcan_yU::lambda$static$70);
                            ENTITY_COLLISION = new Vulcan_yU(strArr[34], 71, Vulcan_yU::lambda$static$71);
                            DEATH = new Vulcan_yU(strArr[50], 72, Vulcan_yU::lambda$static$72);
                            DEPTH_STRIDER = new Vulcan_yU(strArr[93], 73, Vulcan_yU::lambda$static$73);
                            LEVITATION = new Vulcan_yU(strArr[110], 74, Vulcan_yU::lambda$static$74);
                            FROZEN = new Vulcan_yU(strArr[132], 75, Vulcan_yU::lambda$static$75);
                            DIGGING = new Vulcan_yU(strArr[95], 76, Vulcan_yU::lambda$static$76);
                            BLOCK_BREAK = new Vulcan_yU(strArr[58], 77, Vulcan_yU::lambda$static$77);
                            PLACING = new Vulcan_yU(strArr[109], 78, Vulcan_yU::lambda$static$78);
                            SERVER_POSITION = new Vulcan_yU(strArr[70], 79, Vulcan_yU::lambda$static$79);
                            SERVER_POSITION_FAST = new Vulcan_yU(strArr[4], 80, Vulcan_yU::lambda$static$80);
                            CANCELLED_PLACE = new Vulcan_yU(strArr[86], 81, Vulcan_yU::lambda$static$81);
                            BLOCK_PLACE = new Vulcan_yU(strArr[118], 82, Vulcan_yU::lambda$static$82);
                            BLOCK_PLACE_FAST = new Vulcan_yU(strArr[23], 83, Vulcan_yU::lambda$static$83);
                            SWIMMING_ON_OLD_VERSION = new Vulcan_yU(strArr[87], 84, Vulcan_yU::lambda$static$84);
                            FULLY_STUCK = new Vulcan_yU(strArr[81], 85, Vulcan_yU::lambda$static$85);
                            PLACED_CLIMBABLE = new Vulcan_yU(strArr[116], 86, Vulcan_yU::lambda$static$86);
                            PARTIALLY_STUCK = new Vulcan_yU(strArr[61], 87, Vulcan_yU::lambda$static$87);
                            NOT_MOVING = new Vulcan_yU(strArr[125], 88, Vulcan_yU::lambda$static$88);
                            PLACED_SLIME = new Vulcan_yU(strArr[72], 89, Vulcan_yU::lambda$static$89);
                            FIREBALL = new Vulcan_yU(strArr[46], 90, Vulcan_yU::lambda$static$90);
                            WORLD_CHANGE = new Vulcan_yU(strArr[102], 91, Vulcan_yU::lambda$static$91);
                            FALL_DAMAGE = new Vulcan_yU(strArr[59], 92, Vulcan_yU::lambda$static$92);
                            ILLEGAL_BLOCK = new Vulcan_yU(strArr[52], 93, Vulcan_yU::lambda$static$93);
                            HONEY = new Vulcan_yU(strArr[24], 94, Vulcan_yU::lambda$static$94);
                            SCAFFOLDING = new Vulcan_yU(strArr[25], 95, Vulcan_yU::lambda$static$95);
                            HALF_BLOCK = new Vulcan_yU(strArr[96], 96, Vulcan_yU::lambda$static$96);
                            SHULKER = new Vulcan_yU(strArr[126], 97, Vulcan_yU::lambda$static$97);
                            GLIDING = new Vulcan_yU(strArr[20], 98, Vulcan_yU::lambda$static$98);
                            ELYTRA = new Vulcan_yU(strArr[22], 99, Vulcan_yU::lambda$static$99);
                            VELOCITY = new Vulcan_yU(strArr[77], 100, Vulcan_yU::lambda$static$100);
                            DEAD = new Vulcan_yU(strArr[78], 101, Vulcan_yU::lambda$static$101);
                            WEB = new Vulcan_yU(strArr[134], 102, Vulcan_yU::lambda$static$102);
                            SOUL_SAND = new Vulcan_yU(strArr[69], 103, Vulcan_yU::lambda$static$103);
                            CINEMATIC = new Vulcan_yU(strArr[115], 104, Vulcan_yU::lambda$static$104);
                            FAST = new Vulcan_yU(strArr[114], 105, Vulcan_yU::lambda$static$105);
                            LENIENT_SCAFFOLDING = new Vulcan_yU(strArr[67], 106, Vulcan_yU::lambda$static$106);
                            WINDOW_CLICK = new Vulcan_yU(strArr[120], 107, Vulcan_yU::lambda$static$107);
                            DROPPED_ITEM = new Vulcan_yU(strArr[103], 108, Vulcan_yU::lambda$static$108);
                            CANCELLED_BREAK = new Vulcan_yU(strArr[130], 109, Vulcan_yU::lambda$static$109);
                            MYTHIC_MOB = new Vulcan_yU(strArr[97], 110, Vulcan_yU::lambda$static$110);
                            CREATIVE = new Vulcan_yU(strArr[111], 111, Vulcan_yU::lambda$static$111);
                            AUTOCLICKER_NON_DIG = new Vulcan_yU(strArr[62], 112, Vulcan_yU::lambda$static$112);
                            AUTOCLICKER = new Vulcan_yU(strArr[47], 113, Vulcan_yU::lambda$static$113);
                            COLLIDING_VERTICALLY = new Vulcan_yU(strArr[75], 114, Vulcan_yU::lambda$static$114);
                            SLOW_FALLING = new Vulcan_yU(strArr[104], 115, Vulcan_yU::lambda$static$115);
                            BUBBLE_COLUMN = new Vulcan_yU(strArr[3], 116, Vulcan_yU::lambda$static$116);
                            FENCE = new Vulcan_yU(strArr[82], 117, Vulcan_yU::lambda$static$117);
                            JUMP_BOOST = new Vulcan_yU(strArr[8], 118, Vulcan_yU::lambda$static$118);
                            FLIGHT = new Vulcan_yU(strArr[40], 119, Vulcan_yU::lambda$static$119);
                            COMBO_MODE = new Vulcan_yU(strArr[76], 120, Vulcan_yU::lambda$static$120);
                            DOLPHINS_GRACE = new Vulcan_yU(strArr[44], 121, Vulcan_yU::lambda$static$121);
                            TELEPORT = new Vulcan_yU(strArr[42], 122, Vulcan_yU::lambda$static$122);
                            SERVER_VERSION = new Vulcan_yU(strArr[105], 123, Vulcan_yU::lambda$static$123);
                            KELP = new Vulcan_yU(strArr[136], 124, Vulcan_yU::lambda$static$124);
                            CLIENT_VERSION = new Vulcan_yU(strArr[121], 125, Vulcan_yU::lambda$static$125);
                            SLIME = new Vulcan_yU(strArr[73], 126, Vulcan_yU::lambda$static$126);
                            BOAT = new Vulcan_yU(strArr[43], 127, Vulcan_yU::lambda$static$127);
                            SEA_PICKLE = new Vulcan_yU(strArr[10], 128, Vulcan_yU::lambda$static$128);
                            SEAGRASS = new Vulcan_yU(strArr[106], 129, Vulcan_yU::lambda$static$129);
                            TURTLE_EGG = new Vulcan_yU(strArr[91], 130, Vulcan_yU::lambda$static$130);
                            SHULKER_BOX = new Vulcan_yU(strArr[54], 131, Vulcan_yU::lambda$static$131);
                            WATERLOGGED = new Vulcan_yU(strArr[38], 132, Vulcan_yU::lambda$static$132);
                            CLIMBABLE = new Vulcan_yU(strArr[122], 133, Vulcan_yU::lambda$static$133);
                            LIQUID = new Vulcan_yU(strArr[21], 134, Vulcan_yU::lambda$static$134);
                            GLASS_PANE = new Vulcan_yU(strArr[36], 135, Vulcan_yU::lambda$static$135);
                            FARMLAND = new Vulcan_yU(strArr[32], 136, Vulcan_yU::lambda$static$136);
                            VEHICLE = new Vulcan_yU(strArr[133], 137, Vulcan_yU::lambda$static$137);
                            VOID = new Vulcan_yU(strArr[15], 138, Vulcan_yU::lambda$static$138);
                            Vulcan_y = new Vulcan_yU[]{TPS, CHUNK, JOINED, CAKE, BAMBOO, HAPPY_GHAST, PACKET_EXPLOSION, ENTITY_CRAM_FIX, AROUND_SLIME, SIGN, PRESSURE_PLATE, SWIMMING, SWIMMING_JESUS, COLLIDING_HORIZONTALLY, DRIPSTONE, HIGH_FLY_SPEED, GLITCHED_BLOCKS_ABOVE, PROJECTILE_DAMAGE, CHEST, ATTACK_DAMAGE, SKULL, EXPLOSION, STAIRS, HIGH_LEVITATION, FENCE_GATE, POWDER_SNOW, DRAGON_DAMAGE, JUMP_BOOST_RAN_OUT, LAGGED_NEAR_GROUND, SNOW, NETHERITE_ARMOR, FAST_ZERO, JOINED_CHUNK_LOAD, NEAR_SOLID, CAMPFIRE, CANCELLED_MOVE, CARPET, FLOWER_POT, EMPTIED_BUCKET, END_ROD, HOPPER, CHAIN, DOOR, PICKED_UP_ITEM, ANVIL, LAGGED_NEAR_GROUND_MODERN, FULLY_SUBMERGED, RESPAWN, ICE, BED, SLAB, HIGH_JUMP_BOOST, LILY_PAD, HIGH_SPEED, WALL, SWEET_BERRIES, CONDUIT, PLACED_WEB, PISTON, CHORUS_FRUIT, ENDER_PEARL, NEAR_GROUND, SLEEPING, SOUL_SPEED, TRAPDOOR, FISHING_ROD, PLUGIN_LOAD, RIPTIDE, FIREWORK, SPECTATOR, CAULDRON, ENTITY_COLLISION, DEATH, DEPTH_STRIDER, LEVITATION, FROZEN, DIGGING, BLOCK_BREAK, PLACING, SERVER_POSITION, SERVER_POSITION_FAST, CANCELLED_PLACE, BLOCK_PLACE, BLOCK_PLACE_FAST, SWIMMING_ON_OLD_VERSION, FULLY_STUCK, PLACED_CLIMBABLE, PARTIALLY_STUCK, NOT_MOVING, PLACED_SLIME, FIREBALL, WORLD_CHANGE, FALL_DAMAGE, ILLEGAL_BLOCK, HONEY, SCAFFOLDING, HALF_BLOCK, SHULKER, GLIDING, ELYTRA, VELOCITY, DEAD, WEB, SOUL_SAND, CINEMATIC, FAST, LENIENT_SCAFFOLDING, WINDOW_CLICK, DROPPED_ITEM, CANCELLED_BREAK, MYTHIC_MOB, CREATIVE, AUTOCLICKER_NON_DIG, AUTOCLICKER, COLLIDING_VERTICALLY, SLOW_FALLING, BUBBLE_COLUMN, FENCE, JUMP_BOOST, FLIGHT, COMBO_MODE, DOLPHINS_GRACE, TELEPORT, SERVER_VERSION, KELP, CLIENT_VERSION, SLIME, BOAT, SEA_PICKLE, SEAGRASS, TURTLE_EGG, SHULKER_BOX, WATERLOGGED, CLIMBABLE, LIQUID, GLASS_PANE, FARMLAND, VEHICLE, VOID};
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "6'ó\rU¥[\u001a\b\u009e%\\\u0097\u0004ÄS\u008a";
                        length = "6'ó\rU¥[\u001a\b\u009e%\\\u0097\u0004ÄS\u008a".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0067  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$1(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 136967059633623(0x7c9220ef75d7, double:6.76707187768625E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L1e
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L1e
            r1 = r8
            if (r1 == 0) goto L31
            if (r0 == 0) goto L75
            goto L22
        L1e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2d
            throw r0     // Catch: java.lang.RuntimeException -> L2d
        L22:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2d
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L2d
            goto L31
        L2d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L31:
            org.bukkit.World r0 = r0.getWorld()     // Catch: java.lang.RuntimeException -> L6d
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L6d
            me.frep.vulcan.spigot.Vulcan_ka r1 = r1.m639Vulcan_M(r2)     // Catch: java.lang.RuntimeException -> L6d
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L6d
            double r1 = r1.m892Vulcan_q(r2)     // Catch: java.lang.RuntimeException -> L6d
            int r1 = org.bukkit.util.NumberConversions.floor(r1)     // Catch: java.lang.RuntimeException -> L6d
            r2 = 4
            int r1 = r1 >> r2
            r2 = r5
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L6d
            me.frep.vulcan.spigot.Vulcan_ka r2 = r2.m639Vulcan_M(r3)     // Catch: java.lang.RuntimeException -> L6d
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch: java.lang.RuntimeException -> L6d
            double r2 = r2.m894Vulcan_t(r3)     // Catch: java.lang.RuntimeException -> L6d
            int r2 = org.bukkit.util.NumberConversions.floor(r2)     // Catch: java.lang.RuntimeException -> L6d
            r3 = 4
            int r2 = r2 >> r3
            boolean r0 = r0.isChunkLoaded(r1, r2)     // Catch: java.lang.RuntimeException -> L6d
            r1 = r8
            if (r1 == 0) goto L72
            if (r0 != 0) goto L75
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L71:
            r0 = 1
        L72:
            goto L76
        L75:
            r0 = 0
        L76:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$1(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v19, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$2(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 23895929971837L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = ((System.currentTimeMillis() - c0042Vulcan_Oz.getJoinTime()) > Vulcan_fe.Vulcan_M ? 1 : ((System.currentTimeMillis() - c0042Vulcan_Oz.getJoinTime()) == Vulcan_fe.Vulcan_M ? 0 : -1));
                    try {
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n >= 0) {
                                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m717Vulcan_N(new Object[0]);
                                if (M1096Vulcan_n != 0) {
                                    M1096Vulcan_n = M1096Vulcan_n < Vulcan_fe.Vulcan_MR ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) M1096Vulcan_n);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$3(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_S(new Object[0]));
    }

    private static Boolean lambda$static$4(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m870Vulcan_l(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$5(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 62838842727921L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aL(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM985Vulcan_G = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m985Vulcan_G(new Object[0]);
                                r0 = iM985Vulcan_G;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM985Vulcan_G < 25 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$6(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 61474044337621L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.Vulcan_X(new Object[0]).m1076Vulcan_t(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 16 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0037 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$7(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 79153969375407(0x47fd783a28af, double:3.91072570003587E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            boolean r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_X     // Catch: java.lang.RuntimeException -> L19
            r1 = r8
            if (r1 == 0) goto L33
            if (r0 == 0) goto L4f
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2f
            throw r0     // Catch: java.lang.RuntimeException -> L2f
        L1d:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L2f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            int r0 = r0.m981Vulcan_b(r1)     // Catch: java.lang.RuntimeException -> L2f
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L33:
            r1 = r8
            if (r1 == 0) goto L4c
            int r1 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_bi     // Catch: java.lang.RuntimeException -> L40 java.lang.RuntimeException -> L48
            if (r0 >= r1) goto L4f
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L48
            throw r0     // Catch: java.lang.RuntimeException -> L48
        L44:
            r0 = 1
            goto L4c
        L48:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4c:
            goto L50
        L4f:
            r0 = 0
        L50:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$7(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$8(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 106622129514527L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xi(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 20 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$9(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m869Vulcan_aJ(new Object[0]));
    }

    private static Boolean lambda$static$10(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m871Vulcan_r(new Object[0]));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$11(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 92181148639154(0x53d6989e9fb2, double:4.55435387367916E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.Vulcan_xT(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 40
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$11(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$12(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 46252322843564(0x2a10f545ebac, double:2.28516837573633E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L51
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.Vulcan_xT(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4e
            r1 = 5
            if (r0 >= r1) goto L51
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4a
            throw r0     // Catch: java.lang.RuntimeException -> L4a
        L46:
            r0 = 1
            goto L4e
        L4a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4e:
            goto L52
        L51:
            r0 = 0
        L52:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$12(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$13(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aK(new Object[0]));
    }

    private static Boolean lambda$static$14(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m867Vulcan_ao(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$15(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 39719514942750L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xU(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 100 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0052  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.util.List] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$16(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 100190824686934(0x5b1f7e83e556, double:4.9500844506317E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            java.util.List r0 = r0.m885Vulcan_F(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = r8
            if (r1 == 0) goto L3f
            if (r0 == 0) goto L60
            goto L29
        L25:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3b
            throw r0     // Catch: java.lang.RuntimeException -> L3b
        L29:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3b
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            java.util.List r0 = r0.m885Vulcan_F(r1)     // Catch: java.lang.RuntimeException -> L3b
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            java.util.stream.Stream r0 = r0.stream()     // Catch: java.lang.RuntimeException -> L58
            java.lang.Boolean r1 = me.frep.vulcan.spigot.C0046Vulcan_ff::Vulcan_x     // Catch: java.lang.RuntimeException -> L58
            boolean r0 = r0.allMatch(r1)     // Catch: java.lang.RuntimeException -> L58
            r1 = r8
            if (r1 == 0) goto L5d
            if (r0 != 0) goto L60
            goto L5c
        L58:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5c:
            r0 = 1
        L5d:
            goto L61
        L60:
            r0 = 0
        L61:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$16(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$17(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 20922590023096L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m731Vulcan_D(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 20 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$18(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_x(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$19(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 38522392763014L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sb(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 80 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$20(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_C(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$21(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 80922791636807L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.Vulcan_X(new Object[0]).m1076Vulcan_t(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 50 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$22(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_w(new Object[0]));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$23(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 97108378079908(0x5851ce6152a4, double:4.79779135326457E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.Vulcan_sp(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 10
            if (r0 <= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$23(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$24(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_ac(new Object[0]));
    }

    private static Boolean lambda$static$25(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_PO(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$26(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 107140427035613L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m722Vulcan_t(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 60 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$27(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 21603092446724(0x13a5dca6be04, double:1.0673345821859E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            int r0 = r0.Vulcan_xC(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = r8
            if (r1 == 0) goto L3f
            if (r0 <= 0) goto L5a
            goto L29
        L25:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3b
            throw r0     // Catch: java.lang.RuntimeException -> L3b
        L29:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3b
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            int r0 = r0.Vulcan_xC(r1)     // Catch: java.lang.RuntimeException -> L3b
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r1 = r8
            if (r1 == 0) goto L57
            r1 = 30
            if (r0 >= r1) goto L5a
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L53
            throw r0     // Catch: java.lang.RuntimeException -> L53
        L4f:
            r0 = 1
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L57:
            goto L5b
        L5a:
            r0 = 0
        L5b:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$27(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x008a A[PHI: r0
  0x008a: PHI (r0v16 ??) = (r0v15 ??), (r0v23 ??), (r0v27 ??) binds: [B:4:0x0037, B:18:0x0074, B:10:0x0060] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x008f  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v27, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$28(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 28806438952522(0x1a33058f9e4a, double:1.4232271865464E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 112802836471498(0x6697f4ff5eca, double:5.5732006254015E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r1 = r0; r2 = r0; 
            r2 = 128843289516289(0x752eaa80d901, double:6.3657043047176E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int[] r0 = m1096Vulcan_n()
            r14 = r0
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L40
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L40
            r1 = r10
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L40
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L40
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L40
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.RuntimeException -> L40
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L40
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L40
            boolean r0 = r0.Vulcan_PN(r1)     // Catch: java.lang.RuntimeException -> L40
            r1 = r14
            if (r1 == 0) goto L8a
            if (r0 != 0) goto L74
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L66
            throw r0     // Catch: java.lang.RuntimeException -> L66
        L44:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r1 = r12
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            boolean r0 = r0.Vulcan_a(r1)     // Catch: java.lang.RuntimeException -> L66 java.lang.RuntimeException -> L70
            r1 = r14
            if (r1 == 0) goto L8a
            goto L6a
        L66:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L70
            throw r0     // Catch: java.lang.RuntimeException -> L70
        L6a:
            if (r0 != 0) goto L9d
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L86
            throw r0     // Catch: java.lang.RuntimeException -> L86
        L74:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L86
            me.frep.vulcan.spigot.Vulcan_k r0 = r0.Vulcan_W(r1)     // Catch: java.lang.RuntimeException -> L86
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L86
            boolean r0 = r0.Vulcan_O(r1)     // Catch: java.lang.RuntimeException -> L86
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8a:
            r1 = r14
            if (r1 == 0) goto L9a
            if (r0 == 0) goto L9d
            goto L99
        L95:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L99:
            r0 = 1
        L9a:
            goto L9e
        L9d:
            r0 = 0
        L9e:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$28(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$29(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_az(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0045  */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$31(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 7125504754287(0x67b092e026f, double:3.5204671083717E-311)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            double r0 = r0.m899Vulcan_B(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r8
            if (r1 == 0) goto L41
            if (r0 != 0) goto L53
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3d
            throw r0     // Catch: java.lang.RuntimeException -> L3d
        L2b:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3d
            me.frep.vulcan.spigot.Vulcan_k r0 = r0.Vulcan_W(r1)     // Catch: java.lang.RuntimeException -> L3d
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3d
            boolean r0 = r0.Vulcan_O(r1)     // Catch: java.lang.RuntimeException -> L3d
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r1 = r8
            if (r1 == 0) goto L50
            if (r0 == 0) goto L53
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            r0 = 1
        L50:
            goto L54
        L53:
            r0 = 0
        L54:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$31(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:16:0x004a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$32(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 38768077749975(0x23426580bed7, double:1.9153975371565E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            long r0 = java.lang.System.currentTimeMillis()     // Catch: java.lang.RuntimeException -> L22
            r1 = r5
            long r1 = r1.getJoinTime()     // Catch: java.lang.RuntimeException -> L22
            long r0 = r0 - r1
            r1 = 30000(0x7530, double:1.4822E-319)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r8
            if (r1 == 0) goto L40
            if (r0 >= 0) goto L7a
            goto L26
        L22:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3c
            throw r0     // Catch: java.lang.RuntimeException -> L3c
        L26:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3c
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3c
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3c
            double r0 = r0.m899Vulcan_B(r1)     // Catch: java.lang.RuntimeException -> L3c
            r1 = -4636005456307814400(0xbfa99999a0000000, double:-0.05000000074505806)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L40
        L3c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L40:
            r1 = r8
            if (r1 == 0) goto L68
            if (r0 >= 0) goto L7a
            goto L4e
        L4a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L64
            throw r0     // Catch: java.lang.RuntimeException -> L64
        L4e:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L64
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L64
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L64
            double r0 = r0.m899Vulcan_B(r1)     // Catch: java.lang.RuntimeException -> L64
            r1 = -4631501856680443904(0xbfb99999a0000000, double:-0.10000000149011612)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L68
        L64:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L68:
            r1 = r8
            if (r1 == 0) goto L77
            if (r0 <= 0) goto L7a
            goto L76
        L72:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L76:
            r0 = 1
        L77:
            goto L7b
        L7a:
            r0 = 0
        L7b:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$32(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$33(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_a2(new Object[0]));
    }

    private static Boolean lambda$static$34(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_a7(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$35(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 5215087549303L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sT(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 5 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$36(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_u(new Object[0]));
    }

    private static Boolean lambda$static$37(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_Y(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$38(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 79910300870695L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m732Vulcan_W(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 15 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$39(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_K(new Object[0]));
    }

    private static Boolean lambda$static$40(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_af(new Object[0]));
    }

    private static Boolean lambda$static$41(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_Px(new Object[0]));
    }

    private static Boolean lambda$static$42(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aX(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static Boolean lambda$static$43(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 115484271237093L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sB(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 30 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$44(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aU(new Object[0]));
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:16:0x0057
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$45(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 52215999076061(0x2f7d7c1396dd, double:2.579813130676E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 128824400035453(0x752a449a3e7d, double:6.3647710403627E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r1 = r0; r2 = r0; 
            r2 = 70784602919318(0x4060d31cd196, double:3.4972240556949E-310)
            long r1 = r1 ^ r2
            r12 = r1
            int[] r0 = m1096Vulcan_n()
            r14 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L2e
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r0)     // Catch: java.lang.RuntimeException -> L2e
            r1 = r14
            if (r1 == 0) goto L4c
            if (r0 == 0) goto Lbe
            goto L32
        L2e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L48
            throw r0     // Catch: java.lang.RuntimeException -> L48
        L32:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L48
            me.frep.vulcan.spigot.Vulcan_k r0 = r0.Vulcan_W(r1)     // Catch: java.lang.RuntimeException -> L48
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L48
            long r0 = r0.Vulcan_D(r1)     // Catch: java.lang.RuntimeException -> L48
            r1 = 10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L4c
        L48:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4c:
            r1 = r14
            if (r1 == 0) goto L7b
            if (r0 >= 0) goto Lbe
            goto L5b
        L57:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L77
            throw r0     // Catch: java.lang.RuntimeException -> L77
        L5b:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L77
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L77
            r1 = r10
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L77
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L77
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L77
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.RuntimeException -> L77
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L77
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L77
            boolean r0 = r0.Vulcan_a6(r1)     // Catch: java.lang.RuntimeException -> L77
            goto L7b
        L77:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7b:
            r1 = r14
            if (r1 == 0) goto Lbb
            if (r0 != 0) goto Lba
            goto L8a
        L86:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> Lac
            throw r0     // Catch: java.lang.RuntimeException -> Lac
        L8a:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r1 = r12
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            boolean r0 = r0.Vulcan_a(r1)     // Catch: java.lang.RuntimeException -> Lac java.lang.RuntimeException -> Lb6
            r1 = r14
            if (r1 == 0) goto Lbb
            goto Lb0
        Lac:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> Lb6
            throw r0     // Catch: java.lang.RuntimeException -> Lb6
        Lb0:
            if (r0 != 0) goto Lbe
            goto Lba
        Lb6:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lba:
            r0 = 1
        Lbb:
            goto Lbf
        Lbe:
            r0 = 0
        Lbf:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$45(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$46(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan__(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static Boolean lambda$static$47(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 134082045608326L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m724Vulcan_g(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 20 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$48(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 99017141242463L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m955Vulcan_O(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n >= 20) {
                            boolean zVulcan_s = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_s(new Object[0]);
                            r0 = zVulcan_s;
                            if (M1096Vulcan_n != 0) {
                                r0 = zVulcan_s ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$49(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 134083414784824L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_R(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM952Vulcan__ = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m952Vulcan__(new Object[0]);
                                r0 = iM952Vulcan__;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM952Vulcan__ < 30 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    private static Boolean lambda$static$50(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_J(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$51(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 52223122131064L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sx(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n > 2 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$52(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aG(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$53(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 8293298085616L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m739Vulcan_b(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n > 5 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$54(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_N(new Object[0]));
    }

    private static Boolean lambda$static$55(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_U(new Object[0]));
    }

    private static Boolean lambda$static$56(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m863Vulcan_aR(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$57(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 85923923208196L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m742Vulcan_U(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$58(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 65862526257684L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_Pk(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM956Vulcan_o = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m956Vulcan_o(new Object[0]);
                                r0 = iM956Vulcan_o;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM956Vulcan_o < 20 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$59(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 2955560834827L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_x(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$60(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 53252123379952L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan__(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 5 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_ka] */
    private static Boolean lambda$static$61(C0042Vulcan_Oz c0042Vulcan_Oz) {
        ?? r2 = new Object[1];
        c0042Vulcan_Oz.m639Vulcan_M(new Object[0])[0] = Long.valueOf((a ^ 77602023323428L) ^ 63981330397092L);
        return Boolean.valueOf(r2.Vulcan_PN(r2));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003a  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0065  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$62(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 85515470188579(0x4dc69f393023, double:4.2250256008138E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L1e
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L1e
            r1 = r8
            if (r1 == 0) goto L31
            if (r0 == 0) goto L44
            goto L22
        L1e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2d
            throw r0     // Catch: java.lang.RuntimeException -> L2d
        L22:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2d
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L2d
            goto L31
        L2d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L31:
            boolean r0 = r0.isSleeping()     // Catch: java.lang.RuntimeException -> L40
            r1 = r8
            if (r1 == 0) goto Lb4
            if (r0 != 0) goto Lac
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L68
            throw r0     // Catch: java.lang.RuntimeException -> L68
        L44:
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            me.frep.vulcan.spigot.Vulcan_Of r0 = r0.Vulcan_N()     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            int r0 = r0.Vulcan_P(r1)     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            me.frep.vulcan.spigot.Vulcan_fi r1 = r1.m637Vulcan_r(r2)     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            int r1 = r1.Vulcan_s6(r2)     // Catch: java.lang.RuntimeException -> L68 java.lang.RuntimeException -> L74
            int r0 = r0 - r1
            r1 = r8
            if (r1 == 0) goto Lb4
            goto L6c
        L68:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L74
            throw r0     // Catch: java.lang.RuntimeException -> L74
        L6c:
            r1 = 40
            if (r0 < r1) goto Lac
            goto L78
        L74:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L9c
            throw r0     // Catch: java.lang.RuntimeException -> L9c
        L78:
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            me.frep.vulcan.spigot.Vulcan_Of r0 = r0.Vulcan_N()     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            int r0 = r0.Vulcan_P(r1)     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            me.frep.vulcan.spigot.Vulcan_fi r1 = r1.m637Vulcan_r(r2)     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            int r1 = r1.Vulcan_sw(r2)     // Catch: java.lang.RuntimeException -> L9c java.lang.RuntimeException -> La8
            int r0 = r0 - r1
            r1 = r8
            if (r1 == 0) goto Lb4
            goto La0
        L9c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> La8
            throw r0     // Catch: java.lang.RuntimeException -> La8
        La0:
            r1 = 40
            if (r0 >= r1) goto Lb7
            goto Lac
        La8:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> Lb0
            throw r0     // Catch: java.lang.RuntimeException -> Lb0
        Lac:
            r0 = 1
            goto Lb4
        Lb0:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lb4:
            goto Lb8
        Lb7:
            r0 = 0
        Lb8:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$62(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$63(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 54089392625798(0x3131ab089886, double:2.67237107008256E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_f(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m951Vulcan_D(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 60
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$63(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$64(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 60260642281831L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m935Vulcan_U(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n >= 20) {
                            boolean zVulcan_aF = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aF(new Object[0]);
                            r0 = zVulcan_aF;
                            if (M1096Vulcan_n != 0) {
                                r0 = zVulcan_aF ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$65(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 17871467324203(0x10410676232b, double:8.829678045663E-311)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m972Vulcan_N(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 100
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$65(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    private static Boolean lambda$static$66(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 101553282477605L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            M1096Vulcan_n = ((System.currentTimeMillis() - Vulcan_r.INSTANCE.Vulcan_I()) > 10000L ? 1 : ((System.currentTimeMillis() - Vulcan_r.INSTANCE.Vulcan_I()) == 10000L ? 0 : -1));
            ?? r0 = M1096Vulcan_n;
            if (M1096Vulcan_n != 0) {
                r0 = M1096Vulcan_n < 0 ? 1 : 0;
            }
            return Boolean.valueOf((boolean) r0);
        } catch (RuntimeException unused) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$67(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 134810546889146(0x7a9c06c261ba, double:6.66052599149976E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m939Vulcan_y(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 80
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$67(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$68(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 117834324236022(0x6b2b7109d6f6, double:5.8217891505937E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L53
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m954Vulcan_p(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L50
            r1 = 150(0x96, float:2.1E-43)
            if (r0 >= r1) goto L53
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0     // Catch: java.lang.RuntimeException -> L4c
        L48:
            r0 = 1
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            goto L54
        L53:
            r0 = 0
        L54:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$68(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0067 A[PHI: r0
  0x0067: PHI (r0v18 ??) = (r0v35 ??), (r0v36 ??), (r0v37 ??) binds: [B:6:0x001f, B:24:0x0058, B:15:0x003c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0084 A[EXC_TOP_SPLITTER, PHI: r0
  0x0084: PHI (r0v20 ??) = (r0v18 ??), (r0v25 ??) binds: [B:28:0x0068, B:33:0x0075] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [org.bukkit.GameMode] */
    /* JADX WARN: Type inference failed for: r0v25, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$69(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 112550952325767(0x665d4f885287, double:5.56075589508774E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L25
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_a(r0)     // Catch: java.lang.RuntimeException -> L25
            if (r0 == 0) goto L97
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25 java.lang.RuntimeException -> L2f
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L25 java.lang.RuntimeException -> L2f
            r1 = r8
            if (r1 == 0) goto L67
            goto L29
        L25:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2f
            throw r0     // Catch: java.lang.RuntimeException -> L2f
        L29:
            if (r0 == 0) goto L58
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L42
            throw r0     // Catch: java.lang.RuntimeException -> L42
        L33:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L42 java.lang.RuntimeException -> L54
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L42 java.lang.RuntimeException -> L54
            r1 = r8
            if (r1 == 0) goto L67
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L54
            throw r0     // Catch: java.lang.RuntimeException -> L54
        L46:
            org.bukkit.GameMode r0 = r0.getGameMode()     // Catch: java.lang.RuntimeException -> L54 java.lang.RuntimeException -> L63
            org.bukkit.GameMode r1 = org.bukkit.GameMode.SPECTATOR     // Catch: java.lang.RuntimeException -> L54 java.lang.RuntimeException -> L63
            if (r0 == r1) goto L8f
            goto L58
        L54:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L63
            throw r0     // Catch: java.lang.RuntimeException -> L63
        L58:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L63
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L63
            goto L67
        L63:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L67:
            r1 = r8
            if (r1 == 0) goto L84
            if (r0 == 0) goto L97
            goto L75
        L71:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L80
            throw r0     // Catch: java.lang.RuntimeException -> L80
        L75:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L80
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L80
            goto L84
        L80:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L84:
            org.bukkit.GameMode r0 = r0.getGameMode()     // Catch: java.lang.RuntimeException -> L93
            org.bukkit.GameMode r1 = org.bukkit.GameMode.SPECTATOR     // Catch: java.lang.RuntimeException -> L93
            if (r0 != r1) goto L97
        L8f:
            r0 = 1
            goto L98
        L93:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L93
            throw r0
        L97:
            r0 = 0
        L98:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$69(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$70(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_ax(new Object[0]));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$71(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 123489258142305(0x7050155d7a61, double:6.10118000785343E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            boolean r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_H     // Catch: java.lang.RuntimeException -> L19
            r1 = r8
            if (r1 == 0) goto L33
            if (r0 == 0) goto L4e
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2f
            throw r0     // Catch: java.lang.RuntimeException -> L2f
        L1d:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L2f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            int r0 = r0.Vulcan_xh(r1)     // Catch: java.lang.RuntimeException -> L2f
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L33:
            r1 = r8
            if (r1 == 0) goto L4b
            r1 = 8
            if (r0 >= r1) goto L4e
            goto L43
        L3f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L47
            throw r0     // Catch: java.lang.RuntimeException -> L47
        L43:
            r0 = 1
            goto L4b
        L47:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4b:
            goto L4f
        L4e:
            r0 = 0
        L4f:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$71(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$72(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 12609943135477L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sU(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$73(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 108437604103012(0x629f98df7364, double:5.3575294904632E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            boolean r0 = r0.Vulcan_m(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = r8
            if (r1 == 0) goto L3f
            if (r0 == 0) goto L5a
            goto L29
        L25:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3b
            throw r0     // Catch: java.lang.RuntimeException -> L3b
        L29:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3b
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b
            int r0 = r0.m947Vulcan_f(r1)     // Catch: java.lang.RuntimeException -> L3b
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3f:
            r1 = r8
            if (r1 == 0) goto L57
            r1 = 30
            if (r0 >= r1) goto L5a
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L53
            throw r0     // Catch: java.lang.RuntimeException -> L53
        L4f:
            r0 = 1
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L57:
            goto L5b
        L5a:
            r0 = 0
        L5b:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$73(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$74(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 13595645468442(0xc5d7b9e5f1a, double:6.7171413589944E-311)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m942Vulcan_v(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 75
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$74(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$75(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_O(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0091  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v28, types: [int] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$76(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 23156595392821(0x150f90a48135, double:1.14408782582385E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L25
            boolean r0 = r0.Vulcan_R(r1)     // Catch: java.lang.RuntimeException -> L25
            r1 = r8
            if (r1 == 0) goto L99
            if (r0 != 0) goto L91
            goto L29
        L25:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0     // Catch: java.lang.RuntimeException -> L4d
        L29:
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            me.frep.vulcan.spigot.Vulcan_Of r0 = r0.Vulcan_N()     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            int r0 = r0.Vulcan_P(r1)     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            me.frep.vulcan.spigot.Vulcan_fi r1 = r1.m637Vulcan_r(r2)     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            int r1 = r1.m716Vulcan_L(r2)     // Catch: java.lang.RuntimeException -> L4d java.lang.RuntimeException -> L59
            int r0 = r0 - r1
            r1 = r8
            if (r1 == 0) goto L99
            goto L51
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L59
            throw r0     // Catch: java.lang.RuntimeException -> L59
        L51:
            r1 = 20
            if (r0 < r1) goto L91
            goto L5d
        L59:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L81
            throw r0     // Catch: java.lang.RuntimeException -> L81
        L5d:
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            me.frep.vulcan.spigot.Vulcan_Of r0 = r0.Vulcan_N()     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            int r0 = r0.Vulcan_P(r1)     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            r1 = r5
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            me.frep.vulcan.spigot.Vulcan_fi r1 = r1.m637Vulcan_r(r2)     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            int r1 = r1.m714Vulcan_H(r2)     // Catch: java.lang.RuntimeException -> L81 java.lang.RuntimeException -> L8d
            int r0 = r0 - r1
            r1 = r8
            if (r1 == 0) goto L99
            goto L85
        L81:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L8d
            throw r0     // Catch: java.lang.RuntimeException -> L8d
        L85:
            r1 = 20
            if (r0 >= r1) goto L9c
            goto L91
        L8d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L95
            throw r0     // Catch: java.lang.RuntimeException -> L95
        L91:
            r0 = 1
            goto L99
        L95:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L99:
            goto L9d
        L9c:
            r0 = 0
        L9d:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$76(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$77(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 51979928798096L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m744Vulcan_B(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$78(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 91131524633224L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m733Vulcan_c(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 10 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$79(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 117044436200189L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m720Vulcan_K(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 8 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$80(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 115351246561056L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m720Vulcan_K(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 5 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$81(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 54711385169546L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m734Vulcan_q(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 40 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$82(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 46154401295818L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m733Vulcan_c(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 30 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$83(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 78542471196760L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m733Vulcan_c(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 15 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:17:0x004d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$84(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 56430930719339(0x3352d994726b, double:2.7880584231273E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            int r0 = r0.m947Vulcan_f(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = r8
            if (r1 == 0) goto L43
            r1 = 60
            if (r0 >= r1) goto L71
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3f
            throw r0     // Catch: java.lang.RuntimeException -> L3f
        L2b:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3f
            com.github.retrooper.packetevents.protocol.player.User r0 = r0.Vulcan_V(r1)     // Catch: java.lang.RuntimeException -> L3f
            com.github.retrooper.packetevents.protocol.player.ClientVersion r0 = r0.getClientVersion()     // Catch: java.lang.RuntimeException -> L3f
            com.github.retrooper.packetevents.protocol.player.ClientVersion r1 = com.github.retrooper.packetevents.protocol.player.ClientVersion.V_1_13     // Catch: java.lang.RuntimeException -> L3f
            boolean r0 = r0.isNewerThanOrEquals(r1)     // Catch: java.lang.RuntimeException -> L3f
            goto L43
        L3f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L43:
            r1 = r8
            if (r1 == 0) goto L5f
            if (r0 == 0) goto L71
            goto L51
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5b
            throw r0     // Catch: java.lang.RuntimeException -> L5b
        L51:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L5b
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_t(r0)     // Catch: java.lang.RuntimeException -> L5b
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5f:
            r1 = r8
            if (r1 == 0) goto L6e
            if (r0 == 0) goto L71
            goto L6d
        L69:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6d:
            r0 = 1
        L6e:
            goto L72
        L71:
            r0 = 0
        L72:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$84(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$85(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_au(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$86(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 6004643531117L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_z(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 30 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$87(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aI(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    private static Boolean lambda$static$88(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 1756399673794L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_ay(new Object[0]);
            ?? r0 = M1096Vulcan_n;
            if (M1096Vulcan_n != 0) {
                r0 = M1096Vulcan_n == 0 ? 1 : 0;
            }
            return Boolean.valueOf((boolean) r0);
        } catch (RuntimeException unused) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$89(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 30369969700066L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_a(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 120 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$90(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 111916855566851L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sV(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$91(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 14513002372149L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m735Vulcan_y(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 40 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$92(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 19715939595077L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m728Vulcan_s(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 40 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0125  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v36, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v41, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v44, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v50, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v53, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$93(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            Method dump skipped, instruction units count: 302
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$93(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003b  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v18, types: [int] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$94(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 103856992069310(0x5e75171ea6be, double:5.1312171861853E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L76
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            boolean r0 = r0.Vulcan_B(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L73
            if (r0 != 0) goto L6b
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5b
            throw r0     // Catch: java.lang.RuntimeException -> L5b
        L45:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            int r0 = r0.m948Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            r1 = r8
            if (r1 == 0) goto L73
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0     // Catch: java.lang.RuntimeException -> L67
        L5f:
            r1 = 30
            if (r0 >= r1) goto L76
            goto L6b
        L67:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6f
            throw r0     // Catch: java.lang.RuntimeException -> L6f
        L6b:
            r0 = 1
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L73:
            goto L77
        L76:
            r0 = 0
        L77:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$94(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003b  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v18, types: [int] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$95(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 36521566708638(0x21375702a39e, double:1.80440514430374E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L76
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            boolean r0 = r0.Vulcan_P7(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L73
            if (r0 != 0) goto L6b
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5b
            throw r0     // Catch: java.lang.RuntimeException -> L5b
        L45:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            int r0 = r0.Vulcan_xa(r1)     // Catch: java.lang.RuntimeException -> L5b java.lang.RuntimeException -> L67
            r1 = r8
            if (r1 == 0) goto L73
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L67
            throw r0     // Catch: java.lang.RuntimeException -> L67
        L5f:
            r1 = 30
            if (r0 >= r1) goto L76
            goto L6b
        L67:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6f
            throw r0     // Catch: java.lang.RuntimeException -> L6f
        L6b:
            r0 = 1
            goto L73
        L6f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L73:
            goto L77
        L76:
            r0 = 0
        L77:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$95(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$96(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 51173719861604L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_w(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n == 0) {
                            boolean zVulcan_J = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_J(new Object[0]);
                            r0 = zVulcan_J;
                            if (M1096Vulcan_n != 0) {
                                r0 = zVulcan_J ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$97(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 63292332029403L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_P5(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM984Vulcan_a = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m984Vulcan_a(new Object[0]);
                                r0 = iM984Vulcan_a;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM984Vulcan_a < 40 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$98(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 77063435370648(0x4616bab0c098, double:3.80743959671444E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m755Vulcan_C(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 10
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$98(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$99(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 47544479631069L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_g(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iVulcan_xR = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xR(new Object[0]);
                                r0 = iVulcan_xR;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iVulcan_xR < 100 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$100(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 130818194003142L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.Vulcan_X(new Object[0]).m1075Vulcan_H(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 40 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003a  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$101(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 91189828889045(0x52efc95ba9d5, double:4.5053761704219E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L1e
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L1e
            r1 = r8
            if (r1 == 0) goto L31
            if (r0 == 0) goto L48
            goto L22
        L1e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2d
            throw r0     // Catch: java.lang.RuntimeException -> L2d
        L22:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2d
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L2d
            goto L31
        L2d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L31:
            boolean r0 = r0.isDead()     // Catch: java.lang.RuntimeException -> L40
            r1 = r8
            if (r1 == 0) goto L45
            if (r0 == 0) goto L48
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L44:
            r0 = 1
        L45:
            goto L49
        L48:
            r0 = 0
        L49:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$101(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0049  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$102(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 53130683640041(0x3052738668e9, double:2.6250045526604E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27
            int r0 = r0.m946Vulcan_q(r1)     // Catch: java.lang.RuntimeException -> L27
            r1 = r8
            if (r1 == 0) goto L45
            r1 = 25
            if (r0 >= r1) goto L57
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L41
            throw r0     // Catch: java.lang.RuntimeException -> L41
        L2b:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L41
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L41
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L41
            double r0 = r0.m899Vulcan_B(r1)     // Catch: java.lang.RuntimeException -> L41
            r1 = 4591870180066957722(0x3fb999999999999a, double:0.1)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L45:
            r1 = r8
            if (r1 == 0) goto L54
            if (r0 >= 0) goto L57
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L53:
            r0 = 1
        L54:
            goto L58
        L57:
            r0 = 0
        L58:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$102(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$103(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aw(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$104(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 25024981783409(0x16c295265371, double:1.23639837869854E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            boolean r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_z     // Catch: java.lang.RuntimeException -> L19
            r1 = r8
            if (r1 == 0) goto L33
            if (r0 == 0) goto L45
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2f
            throw r0     // Catch: java.lang.RuntimeException -> L2f
        L1d:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            me.frep.vulcan.spigot.Vulcan_ko r0 = r0.Vulcan_z(r1)     // Catch: java.lang.RuntimeException -> L2f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L2f
            boolean r0 = r0.m1059Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L2f
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L33:
            r1 = r8
            if (r1 == 0) goto L42
            if (r0 == 0) goto L45
            goto L41
        L3d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L41:
            r0 = 1
        L42:
            goto L46
        L45:
            r0 = 0
        L46:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$104(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    private static Boolean lambda$static$105(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.Vulcan_W(new Object[0]).Vulcan_O(new Object[0]));
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:25:0x005d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$106(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 47137450235538(0x2adf0afa1692, double:2.32889947939307E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            boolean r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_Mn     // Catch: java.lang.RuntimeException -> L19
            r1 = r8
            if (r1 == 0) goto L2b
            if (r0 == 0) goto L8b
            goto L1d
        L19:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L27
            throw r0     // Catch: java.lang.RuntimeException -> L27
        L1d:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L27
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L27
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L2b:
            r1 = r8
            if (r1 == 0) goto L53
            if (r0 == 0) goto L8b
            goto L39
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4f
            throw r0     // Catch: java.lang.RuntimeException -> L4f
        L39:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L4f
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L4f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L4f
            double r0 = r0.m765Vulcan_T(r1)     // Catch: java.lang.RuntimeException -> L4f
            r1 = 4613937818241073152(0x4008000000000000, double:3.0)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L53
        L4f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L53:
            r1 = r8
            if (r1 == 0) goto L79
            if (r0 >= 0) goto L8b
            goto L61
        L5d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L75
            throw r0     // Catch: java.lang.RuntimeException -> L75
        L61:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L75
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L75
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L75
            double r0 = r0.m765Vulcan_T(r1)     // Catch: java.lang.RuntimeException -> L75
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L79
        L75:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L79:
            r1 = r8
            if (r1 == 0) goto L88
            if (r0 <= 0) goto L8b
            goto L87
        L83:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L87:
            r0 = 1
        L88:
            goto L8c
        L8b:
            r0 = 0
        L8c:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$106(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static Boolean lambda$static$107(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 8404505716573L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sY(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 15 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static Boolean lambda$static$108(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 126100331187857L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m715Vulcan_E(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 15 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static Boolean lambda$static$109(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 42969647978236L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m721Vulcan_Y(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 40 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$110(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 24628037217908L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_sf(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 50 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0064  */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$111(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 126664069482130(0x733346de0692, double:6.2580365293569E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = r8
            if (r1 == 0) goto L48
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L1e java.lang.RuntimeException -> L39
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L1e java.lang.RuntimeException -> L39
            if (r0 == 0) goto L47
            goto L22
        L1e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L39
            throw r0     // Catch: java.lang.RuntimeException -> L39
        L22:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L39 java.lang.RuntimeException -> L43
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L39 java.lang.RuntimeException -> L43
            org.bukkit.GameMode r0 = r0.getGameMode()     // Catch: java.lang.RuntimeException -> L39 java.lang.RuntimeException -> L43
            org.bukkit.GameMode r1 = org.bukkit.GameMode.CREATIVE     // Catch: java.lang.RuntimeException -> L39 java.lang.RuntimeException -> L43
            r2 = r8
            if (r2 == 0) goto L59
            goto L3d
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L43
            throw r0     // Catch: java.lang.RuntimeException -> L43
        L3d:
            if (r0 == r1) goto L5c
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L47:
            r0 = r5
        L48:
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            org.bukkit.GameMode r0 = r0.m774Vulcan_H(r1)
            org.bukkit.GameMode r1 = org.bukkit.GameMode.CREATIVE
        L59:
            if (r0 != r1) goto L64
        L5c:
            r0 = 1
            goto L65
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L60
            throw r0
        L64:
            r0 = 0
        L65:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$111(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$114(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 16806220203460L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m949Vulcan_g(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 20 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$115(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 9020448578818(0x8343ca21d02, double:4.4566937528715E-311)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m944Vulcan_h(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 40
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$115(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$116(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 137693781175655(0x7d3b54ea2d67, double:6.80297669248733E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m943Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 40
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$116(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$117(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 93412119046539L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_g(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM950Vulcan_t = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m950Vulcan_t(new Object[0]);
                                r0 = iM950Vulcan_t;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM950Vulcan_t < 7 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$118(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 59843712619425L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xC(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n >= 40) {
                            boolean zVulcan_O = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_O(new Object[0]);
                            r0 = zVulcan_O;
                            if (M1096Vulcan_n != 0) {
                                r0 = zVulcan_O ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0057 A[Catch: RuntimeException -> 0x0060, RuntimeException -> 0x0068, TRY_ENTER, TryCatch #3 {RuntimeException -> 0x0060, blocks: (B:20:0x0045, B:22:0x0057), top: B:35:0x0045, outer: #1 }] */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$119(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 88050754504359(0x5014e9f1c6a7, double:4.3502852891005E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = r8
            if (r1 == 0) goto L45
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L1e java.lang.RuntimeException -> L36
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L1e java.lang.RuntimeException -> L36
            if (r0 == 0) goto L44
            goto L22
        L1e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L36
            throw r0     // Catch: java.lang.RuntimeException -> L36
        L22:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L36 java.lang.RuntimeException -> L40
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L36 java.lang.RuntimeException -> L40
            boolean r0 = r0.getAllowFlight()     // Catch: java.lang.RuntimeException -> L36 java.lang.RuntimeException -> L40
            r1 = r8
            if (r1 == 0) goto L6c
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L40
            throw r0     // Catch: java.lang.RuntimeException -> L40
        L3a:
            if (r0 != 0) goto L64
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L44:
            r0 = r5
        L45:
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L60
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L60
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L60
            int r0 = r0.Vulcan_xA(r1)     // Catch: java.lang.RuntimeException -> L60
            r1 = r8
            if (r1 == 0) goto L6c
            int r1 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_bm     // Catch: java.lang.RuntimeException -> L60 java.lang.RuntimeException -> L68
            if (r0 >= r1) goto L6f
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L68
            throw r0     // Catch: java.lang.RuntimeException -> L68
        L64:
            r0 = 1
            goto L6c
        L68:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L6c:
            goto L70
        L6f:
            r0 = 0
        L70:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$119(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x003e  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0057 A[EXC_TOP_SPLITTER, PHI: r0
  0x0057: PHI (r0v10 ??) = (r0v31 ??), (r0v32 ??) binds: [B:14:0x003b, B:19:0x0048] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v27, types: [int] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$120(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 136057622058614(0x7bbe623b5676, double:6.72213969140134E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = r5
            r1 = r8
            if (r1 == 0) goto L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27 java.lang.RuntimeException -> L2f
            me.frep.vulcan.spigot.Vulcan_fi r0 = r0.m637Vulcan_r(r1)     // Catch: java.lang.RuntimeException -> L27 java.lang.RuntimeException -> L2f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L27 java.lang.RuntimeException -> L2f
            int r0 = r0.Vulcan_sb(r1)     // Catch: java.lang.RuntimeException -> L27 java.lang.RuntimeException -> L2f
            r1 = 25
            if (r0 >= r1) goto L77
            goto L2b
        L27:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L2f
            throw r0     // Catch: java.lang.RuntimeException -> L2f
        L2b:
            r0 = r5
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L33:
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L44
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L44
            r1 = r8
            if (r1 == 0) goto L57
            if (r0 == 0) goto L77
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L53
            throw r0     // Catch: java.lang.RuntimeException -> L53
        L48:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L53
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L53
            goto L57
        L53:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L57:
            int r0 = r0.getMaximumNoDamageTicks()     // Catch: java.lang.RuntimeException -> L68
            r1 = r8
            if (r1 == 0) goto L74
            r1 = 15
            if (r0 >= r1) goto L77
            goto L6c
        L68:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L70
            throw r0     // Catch: java.lang.RuntimeException -> L70
        L6c:
            r0 = 1
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L74:
            goto L78
        L77:
            r0 = 0
        L78:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$120(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$122(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 107574647056183L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_s3(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n >= 10) {
                            boolean zM697Vulcan_c = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m697Vulcan_c(new Object[0]);
                            r0 = zM697Vulcan_c;
                            if (M1096Vulcan_n != 0) {
                                r0 = zM697Vulcan_c ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$123(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(Vulcan_OM.Vulcan_M(new Object[0]));
    }

    private static Boolean lambda$static$124(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_A(new Object[0]));
    }

    private static Boolean lambda$static$125(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.Vulcan_V(new Object[0]).getClientVersion().isNewerThanOrEquals(ClientVersion.V_1_9));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$126(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 60585812016043L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_T(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iVulcan_xq = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xq(new Object[0]);
                                r0 = iVulcan_xq;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iVulcan_xq < 65 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    private static Boolean lambda$static$127(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aY(new Object[0]));
    }

    private static Boolean lambda$static$128(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aq(new Object[0]));
    }

    private static Boolean lambda$static$129(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_k(new Object[0]));
    }

    private static Boolean lambda$static$130(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m862Vulcan_F(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$131(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 23500553788355L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    try {
                        M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aB(new Object[0]);
                        ?? r0 = M1096Vulcan_n;
                        if (M1096Vulcan_n != 0) {
                            if (M1096Vulcan_n == 0) {
                                int iM966Vulcan_V = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m966Vulcan_V(new Object[0]);
                                r0 = iM966Vulcan_V;
                                if (M1096Vulcan_n != 0) {
                                    r0 = iM966Vulcan_V < 60 ? 1 : 0;
                                }
                            }
                        }
                        return Boolean.valueOf((boolean) r0);
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M1096Vulcan_n);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused4) {
            M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
            throw M1096Vulcan_n;
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.Boolean lambda$static$132(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 22126366113445(0x141fb2313ea5, double:1.0931877363959E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_I(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L37
            if (r0 == 0) goto L52
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L33
            throw r0     // Catch: java.lang.RuntimeException -> L33
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L33
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L33
            int r0 = r0.m975Vulcan_j(r1)     // Catch: java.lang.RuntimeException -> L33
            goto L37
        L33:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L37:
            r1 = r8
            if (r1 == 0) goto L4f
            r1 = 30
            if (r0 >= r1) goto L52
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4b
            throw r0     // Catch: java.lang.RuntimeException -> L4b
        L47:
            r0 = 1
            goto L4f
        L4b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4f:
            goto L53
        L52:
            r0 = 0
        L53:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$132(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    private static Boolean lambda$static$133(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 74782327020594L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                try {
                    M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aE(new Object[0]);
                    ?? r0 = M1096Vulcan_n;
                    if (M1096Vulcan_n != 0) {
                        if (M1096Vulcan_n == 0) {
                            boolean zVulcan_aT = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_aT(new Object[0]);
                            r0 = zVulcan_aT;
                            if (M1096Vulcan_n != 0) {
                                r0 = zVulcan_aT ? 1 : 0;
                            }
                        }
                    }
                    return Boolean.valueOf((boolean) r0);
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) M1096Vulcan_n);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) M1096Vulcan_n);
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$134(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 118567406269123L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m947Vulcan_f(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    private static Boolean lambda$static$135(C0042Vulcan_Oz c0042Vulcan_Oz) {
        return Boolean.valueOf(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m864Vulcan_t(new Object[0]));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$136(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 19388696666649L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m968Vulcan_H(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 20 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static Boolean lambda$static$137(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 118579262137195L;
        ?? M1096Vulcan_n = m1096Vulcan_n();
        try {
            try {
                M1096Vulcan_n = c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_xw(new Object[0]);
                ?? r0 = M1096Vulcan_n;
                if (M1096Vulcan_n != 0) {
                    r0 = M1096Vulcan_n < 25 ? 1 : 0;
                }
                return Boolean.valueOf((boolean) r0);
            } catch (RuntimeException unused) {
                M1096Vulcan_n = a((RuntimeException) M1096Vulcan_n);
                throw M1096Vulcan_n;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) M1096Vulcan_n);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x006a  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.Boolean lambda$static$138(me.frep.vulcan.spigot.C0042Vulcan_Oz r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_yU.a
            r1 = 85663803270326(0x4de9289064b6, double:4.2323542287971E-310)
            long r0 = r0 ^ r1
            r6 = r0
            int[] r0 = m1096Vulcan_n()
            r8 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L1d
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_V(r0)     // Catch: java.lang.RuntimeException -> L1d
            r1 = r8
            if (r1 == 0) goto L66
            if (r0 == 0) goto L55
            goto L21
        L1d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3b
            throw r0     // Catch: java.lang.RuntimeException -> L3b
        L21:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b java.lang.RuntimeException -> L45
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L3b java.lang.RuntimeException -> L45
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3b java.lang.RuntimeException -> L45
            double r0 = r0.m893Vulcan__(r1)     // Catch: java.lang.RuntimeException -> L3b java.lang.RuntimeException -> L45
            r1 = -4588745807825469440(0xc051800000000000, double:-70.0)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r8
            if (r1 == 0) goto L52
            goto L3f
        L3b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L45
            throw r0     // Catch: java.lang.RuntimeException -> L45
        L3f:
            if (r0 >= 0) goto L51
            goto L49
        L45:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0     // Catch: java.lang.RuntimeException -> L4d
        L49:
            r0 = 1
            goto L79
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0
        L51:
            r0 = 0
        L52:
            goto L79
        L55:
            r0 = r5
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            double r0 = r0.m893Vulcan__(r1)
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L66:
            r1 = r8
            if (r1 == 0) goto L75
            if (r0 >= 0) goto L78
            goto L74
        L70:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L74:
            r0 = 1
        L75:
            goto L79
        L78:
            r0 = 0
        L79:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yU.lambda$static$138(me.frep.vulcan.spigot.Vulcan_Oz):java.lang.Boolean");
    }

    public Function Vulcan_n() {
        return this.Vulcan_Z;
    }

    private Vulcan_yU(String str, int i, Function function) {
        this.Vulcan_Z = function;
    }
}
