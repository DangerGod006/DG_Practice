package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.List;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OU.class */
public class Vulcan_OU {
    private final int Vulcan_Z;
    private final long Vulcan_M;
    private final List Vulcan_L;
    private static String Vulcan_S;
    private static final long a = Vulcan_n.a(6920022046360562881L, 1341127292784631820L, MethodHandles.lookup().lookupClass()).a(20719525813110L);

    public static void Vulcan_L(String str) {
        Vulcan_S = str;
    }

    public static String Vulcan_I() {
        return Vulcan_S;
    }

    static {
        if (Vulcan_I() != null) {
            Vulcan_L("RtUvbc");
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public int Vulcan_G(Object[] objArr) {
        return this.Vulcan_Z;
    }

    public long Vulcan_w(Object[] objArr) {
        return this.Vulcan_M;
    }

    public List Vulcan_p(Object[] objArr) {
        return this.Vulcan_L;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public Vulcan_OU(int i, long j) {
        long j2 = a ^ 86760668094387L;
        ?? Vulcan_I = Vulcan_I();
        this.Vulcan_Z = i;
        try {
            this.Vulcan_M = j;
            this.Vulcan_L = new ArrayList();
            if (Vulcan_I != 0) {
                Vulcan_I = new AbstractCheck[1];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_I);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_I);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5 */
    public boolean Vulcan_I(Runnable runnable) {
        long j = a ^ 32602123668833L;
        ?? Vulcan_I = Vulcan_I();
        this.Vulcan_L.add(runnable);
        try {
            Vulcan_I = 1;
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_L("NtW1k");
            }
            return true;
        } catch (RuntimeException unused) {
            throw a(Vulcan_I);
        }
    }

    public void Vulcan_H(Object[] objArr) {
        this.Vulcan_L.forEach((v0) -> {
            v0.run();
        });
    }
}
