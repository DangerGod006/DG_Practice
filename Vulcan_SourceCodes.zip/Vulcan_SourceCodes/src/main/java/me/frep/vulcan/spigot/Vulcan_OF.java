package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.UniversalRunnable;
import java.lang.invoke.MethodHandles;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OF.class */
class Vulcan_OF extends UniversalRunnable {
    final List Vulcan_b;
    final C0042Vulcan_Oz Vulcan_X;
    final int Vulcan_U;
    final AbstractCheck Vulcan_I;
    final C0043Vulcan_e Vulcan_J;
    private static final long b = Vulcan_n.a(-5430401720511989274L, 2088505469795796705L, MethodHandles.lookup().lookupClass()).a(68816523037872L);
    private static final String[] c;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x02f1: MOVE (r34 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r-1 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY])
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void lambda$run$0(me.frep.vulcan.spigot.C0042Vulcan_Oz r13, int r14, me.frep.vulcan.spigot.check.AbstractCheck r15, java.lang.String r16) {
        /*
            Method dump skipped, instruction units count: 1755
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OF.lambda$run$0(me.frep.vulcan.spigot.Vulcan_Oz, int, me.frep.vulcan.spigot.check.AbstractCheck, java.lang.String):void");
    }

    static {
        int i;
        long j = b ^ 6238112479812L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[34];
        int i3 = 0;
        String str = "¦üªmÞÜÀ°\r5Df_¾ýë\u0010ú~÷À^\u0013c\u001e[9øwF&\u0004µ\u0018<D´9>NÀ¦âqËù`\u001b\u0083t\u0015ð\u0085ï£´ôe\u0010\u0019Ì(\u009dOÎGìq\u0091ëcÇÄÓZ\b\u008bo\u0012\u008f\u0099\u0088\u001f¬\bÆ\n\u0007\b\u0012\u0015es\b?s\u0083ÃãÇã\u0015\u0010\u0011Ð\u00020\tsµß\u008cü\u007f·4QÓC\u0010\u0011Ð\u00020\tsµß\u008cü\u007f·4QÓC\u0010Q\u0018\u0097¬dÉn|\u008d&ä)iGËB\bÙ0R\u0080+ø\u0084m\bú\u001c$´\rQù&\bÙ0R\u0080+ø\u0084m\u0010\u0003/Òt[\u001aðaÜI\u0090×l &â\bú\u001c$´\rQù&\u0010vX\u0088\u0098Ê!\u0097>\u0080Áwª\u0019\u001fÕó\u0010\u0019Ì(\u009dOÎGìq\u0091ëcÇÄÓZ\b\b*\u0010Ç\u0000ôo8\b?s\u0083ÃãÇã\u0015\bØF+,¶q}n\bÆ\n\u0007\b\u0012\u0015es\u0010½\u0017iÃ§\u000bÁ½\u0012È\u001aÇ\u0080ú\u008c\u0005\u0010<D´9>NÀ¦øºt.Õ\u0013¹?\u0010¦üªmÞÜÀ°\r5Df_¾ýë\b\b*\u0010Ç\u0000ôo8\bØF+,¶q}n\u0010ú~÷À^\u0013c\u001e[9øwF&\u0004µ\u0010\u0003/Òt[\u001aðaÜI\u0090×l &â\u0010Q\u0018\u0097¬dÉn|\u008d&ä)iGËB\b\u008bo\u0012\u008f\u0099\u0088\u001f¬\u0010vX\u0088\u0098Ê!\u0097>\u0080Áwª\u0019\u001fÕó\u0010<D´9>NÀ¦øºt.Õ\u0013¹?";
        int length = "¦üªmÞÜÀ°\r5Df_¾ýë\u0010ú~÷À^\u0013c\u001e[9øwF&\u0004µ\u0018<D´9>NÀ¦âqËù`\u001b\u0083t\u0015ð\u0085ï£´ôe\u0010\u0019Ì(\u009dOÎGìq\u0091ëcÇÄÓZ\b\u008bo\u0012\u008f\u0099\u0088\u001f¬\bÆ\n\u0007\b\u0012\u0015es\b?s\u0083ÃãÇã\u0015\u0010\u0011Ð\u00020\tsµß\u008cü\u007f·4QÓC\u0010\u0011Ð\u00020\tsµß\u008cü\u007f·4QÓC\u0010Q\u0018\u0097¬dÉn|\u008d&ä)iGËB\bÙ0R\u0080+ø\u0084m\bú\u001c$´\rQù&\bÙ0R\u0080+ø\u0084m\u0010\u0003/Òt[\u001aðaÜI\u0090×l &â\bú\u001c$´\rQù&\u0010vX\u0088\u0098Ê!\u0097>\u0080Áwª\u0019\u001fÕó\u0010\u0019Ì(\u009dOÎGìq\u0091ëcÇÄÓZ\b\b*\u0010Ç\u0000ôo8\b?s\u0083ÃãÇã\u0015\bØF+,¶q}n\bÆ\n\u0007\b\u0012\u0015es\u0010½\u0017iÃ§\u000bÁ½\u0012È\u001aÇ\u0080ú\u008c\u0005\u0010<D´9>NÀ¦øºt.Õ\u0013¹?\u0010¦üªmÞÜÀ°\r5Df_¾ýë\b\b*\u0010Ç\u0000ôo8\bØF+,¶q}n\u0010ú~÷À^\u0013c\u001e[9øwF&\u0004µ\u0010\u0003/Òt[\u001aðaÜI\u0090×l &â\u0010Q\u0018\u0097¬dÉn|\u008d&ä)iGËB\b\u008bo\u0012\u008f\u0099\u0088\u001f¬\u0010vX\u0088\u0098Ê!\u0097>\u0080Áwª\u0019\u001fÕó\u0010<D´9>NÀ¦øºt.Õ\u0013¹?".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            c = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "<D´9>NÀ¦âqËù`\u001b\u0083t\u0015ð\u0085ï£´ôe\u0010½\u0017iÃ§\u000bÁ½\u0012È\u001aÇ\u0080ú\u008c\u0005";
                        length = "<D´9>NÀ¦âqËù`\u001b\u0083t\u0015ð\u0085ï£´ôe\u0010½\u0017iÃ§\u000bÁ½\u0012È\u001aÇ\u0080ú\u008c\u0005".length();
                        cCharAt = 24;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c2 = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c2 | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    Vulcan_OF(C0043Vulcan_e c0043Vulcan_e, List list, C0042Vulcan_Oz c0042Vulcan_Oz, int i, AbstractCheck abstractCheck) {
        long j = b ^ 115862959025319L;
        boolean zVulcan_E = C0043Vulcan_e.Vulcan_E();
        this.Vulcan_J = c0043Vulcan_e;
        this.Vulcan_b = list;
        this.Vulcan_X = c0042Vulcan_Oz;
        this.Vulcan_U = i;
        this.Vulcan_I = abstractCheck;
        if (zVulcan_E) {
            AbstractCheck.Vulcan_D(new AbstractCheck[4]);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    @Override // java.lang.Runnable
    public void run() {
        long j = b ^ 24033968881259L;
        ?? Vulcan_Z = C0043Vulcan_e.Vulcan_Z();
        List list = this.Vulcan_b;
        C0042Vulcan_Oz c0042Vulcan_Oz = this.Vulcan_X;
        int i = this.Vulcan_U;
        AbstractCheck abstractCheck = this.Vulcan_I;
        list.forEach((v4) -> {
            lambda$run$0(r3, r4, r5, v4);
        });
        try {
            try {
                Vulcan_Z = AbstractCheck.Vulcan_k();
                if (Vulcan_Z != 0) {
                    C0043Vulcan_e.Vulcan_p(Vulcan_Z == 0);
                }
            } catch (RuntimeException unused) {
                Vulcan_Z = a((RuntimeException) Vulcan_Z);
                throw Vulcan_Z;
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_Z);
        }
    }
}
