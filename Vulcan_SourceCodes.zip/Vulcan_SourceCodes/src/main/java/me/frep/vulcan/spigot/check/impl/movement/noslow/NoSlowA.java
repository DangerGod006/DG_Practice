package me.frep.vulcan.spigot.check.impl.movement.noslow;

import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/noslow/NoSlowA.class */
@CheckInfo(name = "No Slow", type = 'A', complexType = "Packet", description = "Placing while digging")
public class NoSlowA extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public NoSlowA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 343
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.noslow.NoSlowA.Vulcan_T(java.lang.Object[]):void");
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
