package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.manager.server.ServerVersion;
import io.github.retrooper.packetevents.util.SpigotReflectionUtil;
import java.lang.invoke.MethodHandles;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OM.class */
public final class Vulcan_OM {
    private static final boolean Vulcan_j;
    private static final boolean Vulcan_k;
    private static final boolean Vulcan_z;
    private static final boolean Vulcan_R;
    private static final boolean Vulcan_I;
    private static final boolean Vulcan_e;
    private static final boolean Vulcan_L;
    private static final boolean Vulcan_C;
    private static final boolean Vulcan_f;
    private static final boolean Vulcan_V;
    private static final boolean Vulcan_O;
    private static final boolean Vulcan_H;
    private static final boolean Vulcan_X;
    private static final boolean Vulcan_h;
    private static final boolean Vulcan_G;
    private static final boolean Vulcan_E;
    private static final boolean Vulcan_d;
    private static final boolean Vulcan_J;
    private static final boolean Vulcan_N;
    private static AbstractCheck[] Vulcan_n;
    private static final long a = Vulcan_n.a(7000295920717906956L, 5623165264497418269L, MethodHandles.lookup().lookupClass()).a(223860223995533L);
    private static final String[] b;

    public static void Vulcan_P(AbstractCheck[] abstractCheckArr) {
        Vulcan_n = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_q() {
        return Vulcan_n;
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_OM() {
        throw new UnsupportedOperationException(b[0]);
    }

    static {
        long j = a ^ 9454878095662L;
        Vulcan_P(new AbstractCheck[2]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = "&ÞÜ³¨W¬Û¦A^\u0086àrK§òÌvÖRîÀäàó±¹Ì\u0083pB!Xe\u008f\u000fQ¢Aß'\u0091)!ÝzKÇÿûâ=©\u008f¢\u0010\u0087\u0090_\u0001Ç\u008b_±}V8\u0001es\\\u009b8þ~ ì?!°`.oôåOù®þ\u001b\\Âiv\u001fÙ\u001d\u0085.Ø soB\u0011q\u0085\u0080Ù\u008a\u00ad\u0093/\u0084\u008fÿ~3ÆvKÂÞ9Â3öÃª".length();
        char cCharAt = '8';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("&ÞÜ³¨W¬Û¦A^\u0086àrK§òÌvÖRîÀäàó±¹Ì\u0083pB!Xe\u008f\u000fQ¢Aß'\u0091)!ÝzKÇÿûâ=©\u008f¢\u0010\u0087\u0090_\u0001Ç\u008b_±}V8\u0001es\\\u009b8þ~ ì?!°`.oôåOù®þ\u001b\\Âiv\u001fÙ\u001d\u0085.Ø soB\u0011q\u0085\u0080Ù\u008a\u00ad\u0093/\u0084\u008fÿ~3ÆvKÂÞ9Â3öÃª".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                Vulcan_j = Vulcan_G(new Object[0]).isNewerThan(ServerVersion.V_1_7_10);
                Vulcan_k = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_8);
                Vulcan_z = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_9);
                Vulcan_R = Vulcan_G(new Object[0]).isOlderThan(ServerVersion.V_1_13);
                Vulcan_I = Vulcan_G(new Object[0]).isOlderThan(ServerVersion.V_1_8);
                Vulcan_e = Vulcan_G(new Object[0]).isOlderThan(ServerVersion.V_1_9);
                Vulcan_L = Vulcan_G(new Object[0]).isNewerThan(ServerVersion.V_1_13);
                Vulcan_C = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_16);
                Vulcan_f = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_12);
                Vulcan_V = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_11);
                Vulcan_O = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_17);
                Vulcan_H = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_14);
                Vulcan_X = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_18);
                Vulcan_h = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_19);
                Vulcan_G = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_20);
                Vulcan_E = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_20_2);
                Vulcan_d = Vulcan_G(new Object[0]).isOlderThan(ServerVersion.V_1_21);
                Vulcan_J = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_12_2);
                Vulcan_N = Vulcan_G(new Object[0]).isNewerThanOrEquals(ServerVersion.V_1_21_2);
                return;
            }
            cCharAt = "&ÞÜ³¨W¬Û¦A^\u0086àrK§òÌvÖRîÀäàó±¹Ì\u0083pB!Xe\u008f\u000fQ¢Aß'\u0091)!ÝzKÇÿûâ=©\u008f¢\u0010\u0087\u0090_\u0001Ç\u008b_±}V8\u0001es\\\u009b8þ~ ì?!°`.oôåOù®þ\u001b\\Âiv\u001fÙ\u001d\u0085.Ø soB\u0011q\u0085\u0080Ù\u008a\u00ad\u0093/\u0084\u008fÿ~3ÆvKÂÞ9Â3öÃª".charAt(i3);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [boolean] */
    public static double Vulcan_q(Object[] objArr) {
        ?? LongValue = a ^ ((Long) objArr[0]).longValue();
        try {
            LongValue = Vulcan_r.INSTANCE.Vulcan_n();
            if (LongValue != 0) {
                return 20.0d;
            }
            return Math.min(20.0d, SpigotReflectionUtil.getTPS());
        } catch (UnsupportedOperationException unused) {
            throw a((UnsupportedOperationException) LongValue);
        }
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    public static void Vulcan_k(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        ?? r1 = (String) objArr[1];
        long j = (a ^ jLongValue) ^ 85892982815479L;
        Logger loggerVulcan_x = Vulcan_r.INSTANCE.Vulcan_x();
        Level level = Level.INFO;
        Object[] objArr2 = new Object[2];
        r1[1] = Long.valueOf(j);
        objArr2[0] = objArr2;
        loggerVulcan_x.log(level, Vulcan_ym.Vulcan_X(objArr2));
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.String] */
    public static void Vulcan_X(Object[] objArr) {
        ?? r1 = (String) objArr[0];
        long jLongValue = (a ^ ((Long) objArr[1]).longValue()) ^ 27332890494806L;
        Logger loggerVulcan_x = Vulcan_r.INSTANCE.Vulcan_x();
        Level level = Level.INFO;
        Object[] objArr2 = new Object[2];
        r1[1] = Long.valueOf(jLongValue);
        objArr2[0] = objArr2;
        loggerVulcan_x.log(level, Vulcan_ym.Vulcan_X(objArr2));
    }

    public static ServerVersion Vulcan_G(Object[] objArr) {
        return PacketEvents.getAPI().getServerManager().getVersion();
    }

    public static boolean Vulcan_Y(Object[] objArr) {
        try {
            Class.forName(b[2]);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static boolean Vulcan_r(Object[] objArr) {
        return Vulcan_O;
    }

    public static boolean Vulcan_D(Object[] objArr) {
        return Vulcan_h;
    }

    public static boolean Vulcan_B(Object[] objArr) {
        return Vulcan_H;
    }

    public static boolean Vulcan_l(Object[] objArr) {
        return Vulcan_V;
    }

    public static boolean Vulcan_b(Object[] objArr) {
        return Vulcan_j;
    }

    public static boolean Vulcan_i(Object[] objArr) {
        return Vulcan_e;
    }

    public static boolean Vulcan_a(Object[] objArr) {
        return Vulcan_k;
    }

    public static boolean Vulcan_I(Object[] objArr) {
        return Vulcan_L;
    }

    public static boolean Vulcan_f(Object[] objArr) {
        return Vulcan_C;
    }

    public static boolean Vulcan_M(Object[] objArr) {
        return Vulcan_z;
    }

    public static boolean Vulcan_t(Object[] objArr) {
        return Vulcan_R;
    }

    public static boolean Vulcan_Q(Object[] objArr) {
        return Vulcan_I;
    }

    public static boolean Vulcan_V(Object[] objArr) {
        return Vulcan_X;
    }

    public static boolean Vulcan_N(Object[] objArr) {
        return Vulcan_d;
    }

    public static boolean Vulcan_K(Object[] objArr) {
        return Vulcan_G;
    }

    public static boolean Vulcan_d(Object[] objArr) {
        return Vulcan_E;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v6, types: [long] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    public static void Vulcan_x(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        Object obj = objArr[1];
        ?? IntValue = (((((long) iIntValue) << 32) | ((((long) ((Integer) objArr[2]).intValue()) << 48) >>> 32)) | ((((long) ((Integer) objArr[3]).intValue()) << 48) >>> 48)) ^ a;
        try {
            if (Vulcan_fe.Vulcan_W) {
                IntValue = b[1] + obj;
                Vulcan_Y((String) IntValue);
            }
        } catch (UnsupportedOperationException unused) {
            throw a((UnsupportedOperationException) IntValue);
        }
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.String] */
    public static void Vulcan_u(Object[] objArr) {
        ?? r1 = (String) objArr[0];
        long jLongValue = (a ^ ((Long) objArr[1]).longValue()) ^ 68595383534342L;
        ConsoleCommandSender consoleSender = Bukkit.getConsoleSender();
        Object[] objArr2 = new Object[2];
        r1[1] = Long.valueOf(jLongValue);
        objArr2[0] = objArr2;
        Bukkit.dispatchCommand(consoleSender, Vulcan_ym.Vulcan_X(objArr2));
    }

    public static void Vulcan_Y(String str) {
        Object[] objArr = new Object[2];
        str[1] = Long.valueOf((a ^ 138007722016268L) ^ 52248440596185L);
        objArr[0] = objArr;
        Bukkit.broadcastMessage(Vulcan_ym.Vulcan_X(objArr));
    }

    public static boolean Vulcan_S(Object[] objArr) {
        return Vulcan_f;
    }

    public static boolean Vulcan_n(Object[] objArr) {
        return Vulcan_G(new Object[0]).isOlderThan(ServerVersion.V_1_17);
    }

    public static boolean Vulcan_C(Object[] objArr) {
        return Vulcan_J;
    }

    public static boolean Vulcan_j(Object[] objArr) {
        return Vulcan_N;
    }
}
