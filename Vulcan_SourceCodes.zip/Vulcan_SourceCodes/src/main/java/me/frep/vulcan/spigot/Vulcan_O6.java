package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.Effect;
import org.bukkit.World;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_O6.class */
public class Vulcan_O6 {
    Vector Vulcan_u;
    Vector Vulcan_v;
    private static boolean Vulcan_I;
    private static final long a = Vulcan_n.a(-3507661284112909471L, -7207161267445042111L, MethodHandles.lookup().lookupClass()).a(183307611929728L);

    public static void Vulcan_U(boolean z) {
        Vulcan_I = z;
    }

    public static boolean Vulcan_t() {
        return Vulcan_I;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_W() {
        return !Vulcan_t();
    }

    static {
        if (Vulcan_t()) {
            Vulcan_U(true);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public Vulcan_O6(Vector vector, Vector vector2) {
        this.Vulcan_u = vector;
        this.Vulcan_v = vector2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v16, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23, types: [int, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v30, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v35, types: [int] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v39, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v28 */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_j(Object[] objArr) {
        Vector vector = (Vector) objArr[0];
        Vector vector2 = (Vector) objArr[1];
        Vector vector3 = (Vector) objArr[2];
        long jLongValue = a ^ ((Long) objArr[3]).longValue();
        ?? Vulcan_t = Vulcan_t();
        try {
            try {
                try {
                    Vulcan_t = (vector.getX() > vector2.getX() ? 1 : (vector.getX() == vector2.getX() ? 0 : -1));
                    if (Vulcan_t != 0) {
                        return Vulcan_t;
                    }
                    if (Vulcan_t >= 0) {
                        ?? r0 = (vector.getX() > vector3.getX() ? 1 : (vector.getX() == vector3.getX() ? 0 : -1));
                        ?? r1 = Vulcan_t;
                        try {
                            try {
                                if (jLongValue > 0) {
                                    if (r1 == 0) {
                                        if (r0 <= 0) {
                                            r0 = (vector.getY() > vector2.getY() ? 1 : (vector.getY() == vector2.getY() ? 0 : -1));
                                        }
                                    }
                                    r1 = Vulcan_t;
                                }
                                if (r1 != 0) {
                                    return r0;
                                }
                                if (r0 >= 0) {
                                    ?? r02 = (vector.getY() > vector3.getY() ? 1 : (vector.getY() == vector3.getY() ? 0 : -1));
                                    ?? r12 = Vulcan_t;
                                    try {
                                        try {
                                            if (jLongValue > 0) {
                                                if (r12 == 0) {
                                                    if (r02 <= 0) {
                                                        r02 = (vector.getZ() > vector2.getZ() ? 1 : (vector.getZ() == vector2.getZ() ? 0 : -1));
                                                    }
                                                }
                                                r12 = Vulcan_t;
                                            }
                                            if (r12 != 0) {
                                                return r02;
                                            }
                                            if (r02 >= 0) {
                                                ?? r03 = (vector.getZ() > vector3.getZ() ? 1 : (vector.getZ() == vector3.getZ() ? 0 : -1));
                                                if (Vulcan_t != 0) {
                                                    return r03;
                                                }
                                                if (r03 <= 0) {
                                                    return true;
                                                }
                                            }
                                            return false;
                                        } catch (RuntimeException unused) {
                                            throw a(r02);
                                        }
                                    } catch (RuntimeException unused2) {
                                        throw a(r02);
                                    }
                                }
                                return false;
                            } catch (RuntimeException unused3) {
                                throw a(r0);
                            }
                        } catch (RuntimeException unused4) {
                            throw a(r0);
                        }
                    }
                    return false;
                } catch (RuntimeException unused5) {
                    throw a(Vulcan_t);
                }
            } catch (RuntimeException unused6) {
                throw a(Vulcan_t);
            }
        } catch (RuntimeException unused7) {
            throw a(Vulcan_t);
        }
    }

    public Vector Vulcan_X(Object[] objArr) {
        return this.Vulcan_u.clone().add(this.Vulcan_v.clone().multiply(((Double) objArr[0]).doubleValue()));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19, types: [int] */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v26 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v28 */
    public boolean Vulcan_s(Object[] objArr) {
        ?? r1;
        ?? r0;
        long jLongValue = ((Long) objArr[0]).longValue();
        Vector vector = (Vector) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_t = Vulcan_t();
        double x = (vector.getX() - this.Vulcan_u.getX()) / this.Vulcan_v.getX();
        try {
            try {
                try {
                    try {
                        Vulcan_t = (vector.getBlockY() > (this.Vulcan_u.getY() + (x * this.Vulcan_v.getY())) ? 1 : (vector.getBlockY() == (this.Vulcan_u.getY() + (x * this.Vulcan_v.getY())) ? 0 : -1));
                        ?? r02 = Vulcan_t;
                        if (Vulcan_t != 0) {
                            r1 = Vulcan_t;
                            r0 = r02;
                        } else if (Vulcan_t == 0) {
                            int i = (vector.getBlockZ() > (this.Vulcan_u.getZ() + (x * this.Vulcan_v.getZ())) ? 1 : (vector.getBlockZ() == (this.Vulcan_u.getZ() + (x * this.Vulcan_v.getZ())) ? 0 : -1));
                            ?? r12 = Vulcan_t;
                            r0 = i;
                            r1 = r12;
                            r02 = i;
                            if (j >= 0) {
                                if (r12 == 0) {
                                    if (i == 0) {
                                        return true;
                                    }
                                    r02 = 0;
                                }
                                r1 = Vulcan_t;
                                r0 = r02;
                            }
                        } else {
                            r02 = 0;
                            r1 = Vulcan_t;
                            r0 = r02;
                        }
                        int i2 = r1;
                        if (j <= 0) {
                            try {
                                AbstractCheck.Vulcan_D(new AbstractCheck[i2]);
                            } catch (RuntimeException unused) {
                                throw a(r0);
                            }
                        } else if (r1 != 0) {
                            i2 = 5;
                            AbstractCheck.Vulcan_D(new AbstractCheck[i2]);
                        }
                        return r0;
                    } catch (RuntimeException unused2) {
                        throw a(Vulcan_t);
                    }
                } catch (RuntimeException unused3) {
                    throw a(Vulcan_t);
                }
            } catch (RuntimeException unused4) {
                throw a(Vulcan_t);
            }
        } catch (RuntimeException unused5) {
            Vulcan_t = a(Vulcan_t);
            throw Vulcan_t;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0075 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:16:? A[LOOP:0: B:3:0x003b->B:16:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:11:0x0072 -> B:8:0x0069). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.util.List Vulcan_l(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r14 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_O6.a
            r1 = r14
            long r0 = r0 ^ r1
            r14 = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r1 = r0
            r1.<init>()
            r17 = r0
            boolean r0 = Vulcan_t()
            r1 = 0
            r18 = r1
            r16 = r0
        L3b:
            r0 = r18
            r1 = r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L6e
            r0 = r17
            r1 = r16
            if (r1 != 0) goto L77
            r1 = r8
            r2 = r18
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r4 = java.lang.Double.valueOf(r4)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            org.bukkit.util.Vector r1 = r1.Vulcan_X(r2)
            boolean r0 = r0.add(r1)
            r0 = r18
            r1 = r12
            double r0 = r0 + r1
            r18 = r0
        L69:
            r0 = r16
            if (r0 == 0) goto L3b
        L6e:
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L69
            r0 = r17
        L77:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O6.Vulcan_l(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0081 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:16:? A[LOOP:0: B:3:0x0046->B:16:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:11:0x007e -> B:8:0x0075). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.util.List Vulcan_b(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r14 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r16 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_O6.a
            r1 = r16
            long r0 = r0 ^ r1
            r16 = r0
            boolean r0 = Vulcan_W()
            java.util.ArrayList r1 = new java.util.ArrayList
            r2 = r1
            r2.<init>()
            r19 = r1
            r18 = r0
            r0 = r10
            r20 = r0
        L46:
            r0 = r20
            r1 = r12
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L7a
            r0 = r19
            r1 = r18
            if (r1 == 0) goto L83
            r1 = r8
            r2 = r20
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Double r4 = java.lang.Double.valueOf(r4)
            r5 = 0
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            org.bukkit.util.Vector r1 = r1.Vulcan_X(r2)
            boolean r0 = r0.add(r1)
            r0 = r20
            r1 = r14
            double r0 = r0 + r1
            r20 = r0
        L75:
            r0 = r18
            if (r0 != 0) goto L46
        L7a:
            r0 = r16
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L75
            r0 = r19
        L83:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_O6.Vulcan_b(java.lang.Object[]):java.util.List");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r1v10, types: [double] */
    /* JADX WARN: Type inference failed for: r1v14, types: [double] */
    /* JADX WARN: Type inference failed for: r5v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    public List Vulcan_Z(Object[] objArr) {
        World world = (World) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? DoubleValue = ((Double) objArr[2]).doubleValue();
        ?? DoubleValue2 = ((Double) objArr[3]).doubleValue();
        long j = (a ^ jLongValue) ^ 121335783908177L;
        ?? Vulcan_t = Vulcan_t();
        ArrayList arrayList = new ArrayList();
        ?? r5 = new Object[3];
        DoubleValue2[2] = Long.valueOf(j);
        DoubleValue[1] = Double.valueOf((double) r5);
        this[0] = Double.valueOf((double) r5);
        r5.Vulcan_l(r5).stream().filter((v1) -> {
            return lambda$getBlocks$0(r2, v1);
        }).forEach((v2) -> {
            lambda$getBlocks$1(r2, r3, v2);
        });
        try {
            try {
                Vulcan_t = arrayList;
                if (AbstractCheck.Vulcan_k() != null) {
                    Vulcan_U(Vulcan_t == 0);
                }
                return Vulcan_t;
            } catch (RuntimeException unused) {
                throw a(Vulcan_t);
            }
        } catch (RuntimeException unused2) {
            Vulcan_t = a(Vulcan_t);
            throw Vulcan_t;
        }
    }

    private static void lambda$getBlocks$1(List list, World world, Vector vector) {
        list.add(vector.toLocation(world).getBlock());
    }

    private static boolean lambda$getBlocks$0(World world, Vector vector) {
        return vector.toLocation(world).getBlock().getType().isSolid();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [org.bukkit.util.Vector] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r1v13, types: [double] */
    /* JADX WARN: Type inference failed for: r1v17, types: [double] */
    /* JADX WARN: Type inference failed for: r1v9, types: [org.bukkit.util.Vector] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public Vector m592Vulcan_l(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Vector vector = (Vector) objArr[1];
        ?? r1 = (Vector) objArr[2];
        ?? DoubleValue = ((Double) objArr[3]).doubleValue();
        ?? DoubleValue2 = ((Double) objArr[4]).doubleValue();
        long j = a ^ jLongValue;
        long j2 = j ^ 23737128570368L;
        long j3 = j ^ 101552062351844L;
        boolean zVulcan_t = Vulcan_t();
        ?? r5 = new Object[3];
        DoubleValue2[2] = Long.valueOf(j2);
        DoubleValue[1] = Double.valueOf((double) r5);
        this[0] = Double.valueOf((double) r5);
        for (Vector vector2 : r5.Vulcan_l(r5)) {
            ?? A = vector2;
            if (zVulcan_t) {
                return A;
            }
            try {
                try {
                    ?? r4 = new Object[4];
                    r1[3] = Long.valueOf(j3);
                    r4[2] = r4;
                    r4[1] = vector;
                    r4[0] = A;
                    A = Vulcan_j(r4);
                    if (j > 0) {
                        if (A != 0) {
                            return vector2;
                        }
                        A = zVulcan_t;
                    }
                    if (A != 0) {
                        return null;
                    }
                } catch (RuntimeException unused) {
                    A = a(A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a(A);
            }
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [org.bukkit.util.Vector] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v17, types: [double] */
    /* JADX WARN: Type inference failed for: r1v5, types: [org.bukkit.util.Vector] */
    /* JADX WARN: Type inference failed for: r1v9, types: [double] */
    /* JADX WARN: Type inference failed for: r4v10, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    public boolean Vulcan_O(Object[] objArr) {
        Vector vector = (Vector) objArr[0];
        ?? r1 = (Vector) objArr[1];
        ?? DoubleValue = ((Double) objArr[2]).doubleValue();
        long jLongValue = ((Long) objArr[3]).longValue();
        ?? DoubleValue2 = ((Double) objArr[4]).doubleValue();
        long j = a ^ jLongValue;
        long j2 = j ^ 110490672814891L;
        long j3 = j ^ 50265223486671L;
        boolean zVulcan_W = Vulcan_W();
        ?? r5 = new Object[3];
        DoubleValue2[2] = Long.valueOf(j2);
        DoubleValue[1] = Double.valueOf((double) r5);
        this[0] = Double.valueOf((double) r5);
        for (?? A : r5.Vulcan_l(r5)) {
            try {
                try {
                    ?? r4 = new Object[4];
                    r1[3] = Long.valueOf(j3);
                    r4[2] = r4;
                    r4[1] = vector;
                    r4[0] = A;
                    A = Vulcan_j(r4);
                    boolean z = zVulcan_W;
                    if (j >= 0) {
                        if (!z) {
                            return A;
                        }
                        z = zVulcan_W;
                    }
                    if (!z) {
                        return A;
                    }
                    if (A != 0) {
                        return true;
                    }
                    if (!zVulcan_W) {
                        break;
                    }
                } catch (RuntimeException unused) {
                    A = a(A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a(A);
            }
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r1v10, types: [double] */
    /* JADX WARN: Type inference failed for: r1v6, types: [double] */
    /* JADX WARN: Type inference failed for: r5v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_O6] */
    public void Vulcan_G(Object[] objArr) {
        World world = (World) objArr[0];
        ?? DoubleValue = ((Double) objArr[1]).doubleValue();
        ?? DoubleValue2 = ((Double) objArr[2]).doubleValue();
        long jLongValue = (a ^ ((Long) objArr[3]).longValue()) ^ 81088990859751L;
        boolean zVulcan_t = Vulcan_t();
        ?? r5 = new Object[3];
        DoubleValue2[2] = Long.valueOf(jLongValue);
        DoubleValue[1] = Double.valueOf((double) r5);
        this[0] = Double.valueOf((double) r5);
        Iterator it = r5.Vulcan_l(r5).iterator();
        while (it.hasNext()) {
            world.playEffect(((Vector) it.next()).toLocation(world), Effect.ENDEREYE_LAUNCH, 5);
            if (zVulcan_t) {
                return;
            }
        }
    }
}
