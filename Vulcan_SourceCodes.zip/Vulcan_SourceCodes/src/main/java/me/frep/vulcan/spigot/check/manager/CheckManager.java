package me.frep.vulcan.spigot.check.manager;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimA;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimB;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimC;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimD;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimE;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimF;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimG;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimH;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimI;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimK;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimL;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimN;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimO;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimP;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimQ;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimS;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimU;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimW;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimX;
import me.frep.vulcan.spigot.check.impl.combat.aim.AimY;
import me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockA;
import me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockB;
import me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockC;
import me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockD;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerA;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerB;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerC;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerD;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerE;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerF;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerG;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerH;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerI;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerJ;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerK;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerL;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerM;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerN;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerO;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerP;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerQ;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerR;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerS;
import me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerT;
import me.frep.vulcan.spigot.check.impl.combat.criticals.CriticalsA;
import me.frep.vulcan.spigot.check.impl.combat.criticals.CriticalsB;
import me.frep.vulcan.spigot.check.impl.combat.fastbow.FastBowA;
import me.frep.vulcan.spigot.check.impl.combat.hitbox.HitboxA;
import me.frep.vulcan.spigot.check.impl.combat.hitbox.HitboxB;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraA;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraB;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraC;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraD;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraJ;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraK;
import me.frep.vulcan.spigot.check.impl.combat.killaura.KillAuraL;
import me.frep.vulcan.spigot.check.impl.combat.reach.ReachA;
import me.frep.vulcan.spigot.check.impl.combat.reach.ReachB;
import me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityA;
import me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityB;
import me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityC;
import me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityD;
import me.frep.vulcan.spigot.check.impl.movement.antilevitation.AntiLevitationA;
import me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyA;
import me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyB;
import me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyC;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraA;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraB;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraC;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraF;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraG;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraI;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraK;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraL;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraM;
import me.frep.vulcan.spigot.check.impl.movement.elytra.ElytraN;
import me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightA;
import me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightB;
import me.frep.vulcan.spigot.check.impl.movement.entityspeed.EntitySpeedA;
import me.frep.vulcan.spigot.check.impl.movement.fastclimb.FastClimbA;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightA;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightB;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightC;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightD;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightE;
import me.frep.vulcan.spigot.check.impl.movement.flight.FlightF;
import me.frep.vulcan.spigot.check.impl.movement.jesus.JesusA;
import me.frep.vulcan.spigot.check.impl.movement.jesus.JesusB;
import me.frep.vulcan.spigot.check.impl.movement.jesus.JesusC;
import me.frep.vulcan.spigot.check.impl.movement.jesus.JesusD;
import me.frep.vulcan.spigot.check.impl.movement.jesus.JesusE;
import me.frep.vulcan.spigot.check.impl.movement.jump.JumpA;
import me.frep.vulcan.spigot.check.impl.movement.jump.JumpB;
import me.frep.vulcan.spigot.check.impl.movement.jump.JumpC;
import me.frep.vulcan.spigot.check.impl.movement.motion.MotionA;
import me.frep.vulcan.spigot.check.impl.movement.motion.MotionB;
import me.frep.vulcan.spigot.check.impl.movement.motion.MotionC;
import me.frep.vulcan.spigot.check.impl.movement.motion.MotionE;
import me.frep.vulcan.spigot.check.impl.movement.nosaddle.NoSaddleA;
import me.frep.vulcan.spigot.check.impl.movement.noslow.NoSlowA;
import me.frep.vulcan.spigot.check.impl.movement.noslow.NoSlowB;
import me.frep.vulcan.spigot.check.impl.movement.noslow.NoSlowC;
import me.frep.vulcan.spigot.check.impl.movement.speed.SpeedA;
import me.frep.vulcan.spigot.check.impl.movement.speed.SpeedB;
import me.frep.vulcan.spigot.check.impl.movement.speed.SpeedC;
import me.frep.vulcan.spigot.check.impl.movement.speed.SpeedD;
import me.frep.vulcan.spigot.check.impl.movement.speed.SpeedE;
import me.frep.vulcan.spigot.check.impl.movement.sprint.SprintA;
import me.frep.vulcan.spigot.check.impl.movement.step.StepA;
import me.frep.vulcan.spigot.check.impl.movement.step.StepC;
import me.frep.vulcan.spigot.check.impl.movement.strafe.StrafeA;
import me.frep.vulcan.spigot.check.impl.movement.vclip.VClipA;
import me.frep.vulcan.spigot.check.impl.movement.wallclimb.WallClimbA;
import me.frep.vulcan.spigot.check.impl.player.airplace.AirPlaceA;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets5;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets6;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets8;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets9;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsA;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsB;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsC;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsD;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsE;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsF;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsG;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsH;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsI;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsJ;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsK;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsM;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsN;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsO;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsP;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsR;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsT;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsV;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsW;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsX;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsY;
import me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsZ;
import me.frep.vulcan.spigot.check.impl.player.baritone.BaritoneA;
import me.frep.vulcan.spigot.check.impl.player.baritone.BaritoneB;
import me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA;
import me.frep.vulcan.spigot.check.impl.player.fastplace.FastPlaceA;
import me.frep.vulcan.spigot.check.impl.player.ghosthand.GhostHandA;
import me.frep.vulcan.spigot.check.impl.player.groundspoof.GroundSpoofA;
import me.frep.vulcan.spigot.check.impl.player.groundspoof.GroundSpoofB;
import me.frep.vulcan.spigot.check.impl.player.groundspoof.GroundSpoofC;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableA;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableB;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableC;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableD;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableE;
import me.frep.vulcan.spigot.check.impl.player.improbable.ImprobableF;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidA;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidB;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidC;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidE;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidF;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidI;
import me.frep.vulcan.spigot.check.impl.player.invalid.InvalidJ;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldA;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldB;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldC;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldD;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldE;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldG;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldH;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldI;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldJ;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldK;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldM;
import me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldN;
import me.frep.vulcan.spigot.check.impl.player.timer.TimerA;
import me.frep.vulcan.spigot.check.impl.player.timer.TimerD;
import me.frep.vulcan.spigot.check.impl.player.tower.TowerA;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/manager/CheckManager.class */
public class CheckManager {
    public static final List Vulcan_C;
    public static final Class[] Vulcan_u;
    private static String[] Vulcan_O;
    private static final long a = Vulcan_n.a(-5697158894273023794L, 4311780922748406424L, MethodHandles.lookup().lookupClass()).a(249551695119463L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ce: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static java.util.List Vulcan_W(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 242
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.manager.CheckManager.Vulcan_W(java.lang.Object[]):java.util.List");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0085: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_Z(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 462
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.manager.CheckManager.Vulcan_Z(java.lang.Object[]):void");
    }

    public static void Vulcan_M(String[] strArr) {
        Vulcan_O = strArr;
    }

    public static String[] Vulcan_g() {
        return Vulcan_O;
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    static {
        int i;
        long j = a ^ 124012265165556L;
        Vulcan_M(new String[3]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[5];
        int i3 = 0;
        String str = "c xÊñVïÒ\u0087QÃy7öm¾p/AÃm¤R\u001cÚ\u0091P\njÈa \u0094Ðj$ÂI±Á\u0086\u001fG\u0088\u0015»OWmªø \u008aæ¹\u009c|<X&Ö\u008f\u0092h°Ê,n:ùVÕy\u008d®\rÃ\u0092f$§Þ±\u0016ÐÙ\u001b¤è\u001dS8O\n:mèQ|z\"D:Æ¸]è\u0094Êz\u0016\u0014E\u008eÁö\u009d]óÌl\u0018ï\u0010¢C\u0094á\u0018 3dÀú\u00136ÿ\u0085\u0086 ¶$âÌ2\n¬n\u007f]/\u008c)^ºñk\u001e pQ\u001d";
        int length = "c xÊñVïÒ\u0087QÃy7öm¾p/AÃm¤R\u001cÚ\u0091P\njÈa \u0094Ðj$ÂI±Á\u0086\u001fG\u0088\u0015»OWmªø \u008aæ¹\u009c|<X&Ö\u008f\u0092h°Ê,n:ùVÕy\u008d®\rÃ\u0092f$§Þ±\u0016ÐÙ\u001b¤è\u001dS8O\n:mèQ|z\"D:Æ¸]è\u0094Êz\u0016\u0014E\u008eÁö\u009d]óÌl\u0018ï\u0010¢C\u0094á\u0018 3dÀú\u00136ÿ\u0085\u0086 ¶$âÌ2\n¬n\u007f]/\u008c)^ºñk\u001e pQ\u001d".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            Vulcan_C = new ArrayList();
                            Vulcan_u = new Class[]{AimA.class, AimB.class, AimC.class, AimD.class, AimE.class, AimF.class, AimG.class, AimH.class, AimI.class, AimK.class, AimL.class, AimN.class, AimO.class, AimP.class, AimQ.class, AimS.class, AimU.class, AimW.class, AimX.class, AimY.class, AutoBlockA.class, AutoBlockB.class, AutoBlockC.class, AutoBlockD.class, AutoClickerA.class, AutoClickerB.class, AutoClickerC.class, AutoClickerD.class, AutoClickerE.class, AutoClickerF.class, AutoClickerG.class, AutoClickerH.class, AutoClickerI.class, AutoClickerJ.class, AutoClickerK.class, AutoClickerL.class, AutoClickerM.class, AutoClickerN.class, AutoClickerO.class, AutoClickerP.class, AutoClickerQ.class, AutoClickerR.class, AutoClickerS.class, AutoClickerT.class, FastBowA.class, HitboxA.class, HitboxB.class, KillAuraA.class, KillAuraB.class, KillAuraC.class, KillAuraD.class, KillAuraJ.class, KillAuraK.class, KillAuraL.class, ReachA.class, ReachB.class, VelocityA.class, VelocityB.class, VelocityC.class, VelocityD.class, BoatFlyA.class, BoatFlyB.class, BoatFlyC.class, AntiLevitationA.class, NoSaddleA.class, EntitySpeedA.class, EntityFlightA.class, EntityFlightB.class, GhostHandA.class, ElytraA.class, ElytraB.class, ElytraC.class, ElytraF.class, ElytraG.class, ElytraI.class, ElytraK.class, ElytraL.class, ElytraM.class, ElytraN.class, CriticalsA.class, CriticalsB.class, FastClimbA.class, FlightA.class, FlightB.class, FlightC.class, FlightD.class, FlightE.class, FlightF.class, JesusA.class, JesusB.class, JesusC.class, JesusD.class, JesusE.class, JumpA.class, JumpB.class, JumpC.class, MotionA.class, MotionB.class, MotionC.class, MotionE.class, NoSlowA.class, NoSlowB.class, NoSlowC.class, SpeedA.class, SpeedB.class, SpeedC.class, SpeedD.class, SpeedE.class, StepA.class, StepC.class, SprintA.class, StrafeA.class, WallClimbA.class, BaritoneA.class, BaritoneB.class, BadPackets5.class, BadPackets6.class, BadPackets7.class, BadPackets8.class, BadPackets9.class, BadPacketsA.class, BadPacketsB.class, BadPacketsC.class, BadPacketsD.class, BadPacketsE.class, BadPacketsF.class, BadPacketsG.class, BadPacketsH.class, BadPacketsI.class, BadPacketsJ.class, BadPacketsK.class, BadPacketsM.class, BadPacketsN.class, BadPacketsO.class, BadPacketsP.class, BadPacketsQ.class, BadPacketsR.class, BadPacketsT.class, BadPacketsV.class, BadPacketsW.class, BadPacketsX.class, BadPacketsY.class, BadPacketsZ.class, FastPlaceA.class, FastBreakA.class, GroundSpoofA.class, GroundSpoofB.class, GroundSpoofC.class, ImprobableA.class, ImprobableB.class, ImprobableC.class, ImprobableD.class, ImprobableE.class, ImprobableF.class, InvalidA.class, InvalidB.class, InvalidC.class, InvalidE.class, InvalidF.class, InvalidI.class, InvalidJ.class, VClipA.class, AirPlaceA.class, ScaffoldA.class, ScaffoldB.class, ScaffoldC.class, ScaffoldD.class, ScaffoldE.class, ScaffoldF.class, ScaffoldG.class, ScaffoldH.class, ScaffoldI.class, ScaffoldJ.class, ScaffoldK.class, ScaffoldM.class, ScaffoldN.class, TimerA.class, TimerD.class, TowerA.class};
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u0088~ðõÌ\u001a±\u008b*°Ü\u0092\u000e\u008bV1lÒ\u001bãß\u0093g¾×\níUjÚhá 3dÀú\u00136ÿ\u0085\u0086 ¶$âÌ2\nhÍÓ¬çÁ¦Ï#Tà\u009c»\u0084ï×";
                        length = "\u0088~ðõÌ\u001a±\u008b*°Ü\u0092\u000e\u008bV1lÒ\u001bãß\u0093g¾×\níUjÚhá 3dÀú\u00136ÿ\u0085\u0086 ¶$âÌ2\nhÍÓ¬çÁ¦Ï#Tà\u009c»\u0084ï×".length();
                        cCharAt = ' ';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static boolean Vulcan_X(java.lang.Object[] r8) {
        /*
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Class r1 = (java.lang.Class) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.check.manager.CheckManager.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String[] r0 = Vulcan_g()
            r12 = r0
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyB> r1 = me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyB.class
            r2 = r12
            if (r2 == 0) goto L3a
            if (r0 == r1) goto Lb9
            goto L30
        L2c:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L36
            throw r0     // Catch: java.lang.RuntimeException -> L36
        L30:
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyC> r1 = me.frep.vulcan.spigot.check.impl.movement.boatfly.BoatFlyC.class
            goto L3a
        L36:
            java.lang.Exception r0 = a(r0)
            throw r0
        L3a:
            r2 = r12
            r3 = r9
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L5b
            if (r2 == 0) goto L59
            if (r0 == r1) goto Lb9
            goto L4f
        L4b:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L55
            throw r0     // Catch: java.lang.RuntimeException -> L55
        L4f:
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightA> r1 = me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightA.class
            goto L59
        L55:
            java.lang.Exception r0 = a(r0)
            throw r0
        L59:
            r2 = r12
        L5b:
            r3 = r9
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L7a
            if (r2 == 0) goto L78
            if (r0 == r1) goto Lb9
            goto L6e
        L6a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L74
            throw r0     // Catch: java.lang.RuntimeException -> L74
        L6e:
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightB> r1 = me.frep.vulcan.spigot.check.impl.movement.entityflight.EntityFlightB.class
            goto L78
        L74:
            java.lang.Exception r0 = a(r0)
            throw r0
        L78:
            r2 = r12
        L7a:
            r3 = r9
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L9f
            if (r2 == 0) goto L97
            if (r0 == r1) goto Lb9
            goto L8d
        L89:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> L93
            throw r0     // Catch: java.lang.RuntimeException -> L93
        L8d:
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.entityspeed.EntitySpeedA> r1 = me.frep.vulcan.spigot.check.impl.movement.entityspeed.EntitySpeedA.class
            goto L97
        L93:
            java.lang.Exception r0 = a(r0)
            throw r0
        L97:
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto Lb6
            r2 = r12
        L9f:
            if (r2 == 0) goto Lb6
            if (r0 == r1) goto Lb9
            goto Lac
        La8:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> Lb2
            throw r0     // Catch: java.lang.RuntimeException -> Lb2
        Lac:
            r0 = r11
            java.lang.Class<me.frep.vulcan.spigot.check.impl.movement.nosaddle.NoSaddleA> r1 = me.frep.vulcan.spigot.check.impl.movement.nosaddle.NoSaddleA.class
            goto Lb6
        Lb2:
            java.lang.Exception r0 = a(r0)
            throw r0
        Lb6:
            if (r0 != r1) goto Lc1
        Lb9:
            r0 = 1
            goto Lc2
        Lbd:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.RuntimeException -> Lbd
            throw r0
        Lc1:
            r0 = 0
        Lc2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.manager.CheckManager.Vulcan_X(java.lang.Object[]):boolean");
    }
}
