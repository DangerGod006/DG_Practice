package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.packettype.PacketType;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kn.class */
/* synthetic */ class Vulcan_kn {
    static final int[] Vulcan_o = new int[PacketType.Play.Client.values().length];

    static {
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_FLYING.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_POSITION.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_ROTATION.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.CLIENT_TICK_END.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PONG.ordinal()] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.WINDOW_CONFIRMATION.ordinal()] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.ENTITY_ACTION.ordinal()] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_DIGGING.ordinal()] = 9;
        } catch (NoSuchFieldError e9) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.HELD_ITEM_CHANGE.ordinal()] = 10;
        } catch (NoSuchFieldError e10) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.VEHICLE_MOVE.ordinal()] = 11;
        } catch (NoSuchFieldError e11) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.CLIENT_STATUS.ordinal()] = 12;
        } catch (NoSuchFieldError e12) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.KEEP_ALIVE.ordinal()] = 13;
        } catch (NoSuchFieldError e13) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.PLAYER_BLOCK_PLACEMENT.ordinal()] = 14;
        } catch (NoSuchFieldError e14) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.ATTACK.ordinal()] = 15;
        } catch (NoSuchFieldError e15) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.INTERACT_ENTITY.ordinal()] = 16;
        } catch (NoSuchFieldError e16) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.CLICK_WINDOW.ordinal()] = 17;
        } catch (NoSuchFieldError e17) {
        }
        try {
            Vulcan_o[PacketType.Play.Client.ANIMATION.ordinal()] = 18;
        } catch (NoSuchFieldError e18) {
        }
    }
}
