package me.frep.vulcan.spigot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_f0.class */
public final class Vulcan_f0 {
    private static final String Vulcan_n;
    private static Vulcan_C Vulcan_r;
    private static File Vulcan_g;
    private static final long a = Vulcan_n.a(6555271343314620262L, -337642656575901869L, MethodHandles.lookup().lookupClass()).a(248000492794227L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00bc: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_N(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_f0.Vulcan_N(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00bb: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_E(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_f0.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 63665077209700(0x39e72e4fca64, double:3.14547274891433E-310)
            long r1 = r1 ^ r2
            r10 = r1
            me.frep.vulcan.spigot.Vulcan_C r0 = me.frep.vulcan.spigot.Vulcan_f0.Vulcan_r     // Catch: java.lang.Exception -> L26
            java.io.File r1 = me.frep.vulcan.spigot.Vulcan_f0.Vulcan_g     // Catch: java.lang.Exception -> L26
            r0.load(r1)     // Catch: java.lang.Exception -> L26
            goto Lc7
        L26:
            r12 = move-exception
            java.io.File r0 = new java.io.File
            r1 = r0
            me.frep.vulcan.spigot.Vulcan_r r2 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.VulcanPlugin r2 = r2.m1084Vulcan_j()
            java.io.File r2 = r2.getDataFolder()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r4 = r3
            r4.<init>()
            java.lang.String[] r4 = me.frep.vulcan.spigot.Vulcan_f0.b
            r14 = r4
            r4 = r14
            r5 = 3
            r4 = r4[r5]
            java.lang.StringBuilder r3 = r3.append(r4)
            java.util.Date r4 = new java.util.Date
            r5 = r4
            r5.<init>()
            long r4 = r4.getTime()
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.String r3 = r3.toString()
            r1.<init>(r2, r3)
            r13 = r0
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.VulcanPlugin r0 = r0.m1084Vulcan_j()
            java.util.logging.Logger r0 = r0.getLogger()
            java.util.logging.Level r1 = java.util.logging.Level.SEVERE
            r2 = r14
            r3 = 13
            r2 = r2[r3]
            r0.log(r1, r2)
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.VulcanPlugin r0 = r0.m1084Vulcan_j()
            java.util.logging.Logger r0 = r0.getLogger()
            java.util.logging.Level r1 = java.util.logging.Level.SEVERE
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r3 = r2
            r3.<init>()
            r3 = r14
            r4 = 4
            r3 = r3[r4]
            java.lang.StringBuilder r2 = r2.append(r3)
            r3 = r13
            java.lang.String r3 = r3.getName()
            java.lang.StringBuilder r2 = r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.log(r1, r2)
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.VulcanPlugin r0 = r0.m1084Vulcan_j()
            java.util.logging.Logger r0 = r0.getLogger()
            java.util.logging.Level r1 = java.util.logging.Level.SEVERE
            r2 = r14
            r3 = 6
            r2 = r2[r3]
            r0.log(r1, r2)
            java.io.File r0 = me.frep.vulcan.spigot.Vulcan_f0.Vulcan_g
            r1 = r13
            boolean r0 = r0.renameTo(r1)
            r0 = r10
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_z(r0)
        Lc7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_f0.Vulcan_E(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0134: INVOKE (r-1 I:me.frep.vulcan.spigot.Vulcan_C), (r0 I:java.lang.Object[]) VIRTUAL call: me.frep.vulcan.spigot.Vulcan_C.Vulcan_W(java.lang.Object[]):void
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_z(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 317
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_f0.Vulcan_z(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0040: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_Z(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Object r1 = (java.lang.Object) r1
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_f0.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 11375135731248(0xa587aecae30, double:5.620063781591E-311)
            long r1 = r1 ^ r2
            r12 = r1
            r1 = r0; r2 = r0; 
            r2 = 56033288784307(0x32f6444609b3, double:2.76841230118277E-310)
            long r1 = r1 ^ r2
            r14 = r1
            me.frep.vulcan.spigot.Vulcan_C r0 = me.frep.vulcan.spigot.Vulcan_f0.Vulcan_r
            r1 = r11
            r2 = r10
            r0.set(r1, r2)
            r0 = r14
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_N(r0)
            int[] r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_O()
            r1 = r12
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            Vulcan_E(r1)
            r16 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_k()     // Catch: java.lang.UnsupportedOperationException -> L72
            if (r0 == 0) goto L76
            r0 = 4
            int[] r0 = new int[r0]     // Catch: java.lang.UnsupportedOperationException -> L72
            me.frep.vulcan.spigot.Vulcan_fe.Vulcan_a(r0)     // Catch: java.lang.UnsupportedOperationException -> L72
            goto L76
        L72:
            java.lang.Exception r0 = a(r0)
            throw r0
        L76:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_f0.Vulcan_Z(java.lang.Object[]):void");
    }

    static {
        int i;
        long j = a ^ 85877551890323L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[14];
        int i3 = 0;
        String str = "Ì\u0094DT`<\u001fú¾½àì©4Ô\u001c8Ó5\u009cé,¤Rp\"9Ô«à:úÊsE\\I\u009dÂÛ´«¶\n\u0095\u0099§\u0083ªìË8\u00828«HD×Íß^j\u0015\u0014å*Ën\u0087²º&¸\bn?íÞntzU\u0010\u001dó\u0082o\u0014é?~\u0093/&R«\u000b÷¾8Ó5\u009cé,¤Rp\"9Ô«à:úÊsE\\I\u009dÂÛ´«¶\n\u0095\u0099§\u0083ªìË8\u00828«HD×Íß^j\u0015\u0014å*Ën\u0087²º&¸\bgÐ\u0081\u000f¸Zù¢8e¥=\u0086ý¬Äó\t/ÝÆ¼ÜÞ1-Q\u0091ÿ\u001f¬õ&^\u0007?,\u0091\u0099tØ\f\u0007(\u0086î\u0011\u0019\u009d@\u0004\u001fÛL¸æ\u001a¡\u0004\u001eG¶C\u0016ú8e¥=\u0086ý¬Äó\t/ÝÆ¼ÜÞ1-Q\u0091ÿ\u001f¬õ&^\u0007?,\u0091\u0099tØ\f\u0007(\u0086î\u0011\u0019\u009d@\u0004\u001fÛL¸æ\u001a¡\u0004\u001eG¶C\u0016ú\u0010\u0081+Üvú½Æ£\u0087\u0011l\u0091é\u0001PS\u0010\u001dó\u0082o\u0014é?~\u0093/&R«\u000b÷¾ @¦\u0006\u001e](÷\u001e\u0010yäaéµú³\u0018\u0097ÇaÎáÿO¼\u0092Ü5·p¨\u00028\u0082©Ù©Pp\u001d¨rÌùã1\u0084\u0090uJóÈ&Â÷ô\fÝ\u008dôG\u0017¹\u0001¬©[aêä¡V2C\u001b\u0092\u0088-XÒ\\»ÀàÌÁü\u0017\u0019";
        int length = "Ì\u0094DT`<\u001fú¾½àì©4Ô\u001c8Ó5\u009cé,¤Rp\"9Ô«à:úÊsE\\I\u009dÂÛ´«¶\n\u0095\u0099§\u0083ªìË8\u00828«HD×Íß^j\u0015\u0014å*Ën\u0087²º&¸\bn?íÞntzU\u0010\u001dó\u0082o\u0014é?~\u0093/&R«\u000b÷¾8Ó5\u009cé,¤Rp\"9Ô«à:úÊsE\\I\u009dÂÛ´«¶\n\u0095\u0099§\u0083ªìË8\u00828«HD×Íß^j\u0015\u0014å*Ën\u0087²º&¸\bgÐ\u0081\u000f¸Zù¢8e¥=\u0086ý¬Äó\t/ÝÆ¼ÜÞ1-Q\u0091ÿ\u001f¬õ&^\u0007?,\u0091\u0099tØ\f\u0007(\u0086î\u0011\u0019\u009d@\u0004\u001fÛL¸æ\u001a¡\u0004\u001eG¶C\u0016ú8e¥=\u0086ý¬Äó\t/ÝÆ¼ÜÞ1-Q\u0091ÿ\u001f¬õ&^\u0007?,\u0091\u0099tØ\f\u0007(\u0086î\u0011\u0019\u009d@\u0004\u001fÛL¸æ\u001a¡\u0004\u001eG¶C\u0016ú\u0010\u0081+Üvú½Æ£\u0087\u0011l\u0091é\u0001PS\u0010\u001dó\u0082o\u0014é?~\u0093/&R«\u000b÷¾ @¦\u0006\u001e](÷\u001e\u0010yäaéµú³\u0018\u0097ÇaÎáÿO¼\u0092Ü5·p¨\u00028\u0082©Ù©Pp\u001d¨rÌùã1\u0084\u0090uJóÈ&Â÷ô\fÝ\u008dôG\u0017¹\u0001¬©[aêä¡V2C\u001b\u0092\u0088-XÒ\\»ÀàÌÁü\u0017\u0019".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            Vulcan_n = b[5];
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Ì\u0094DT`<\u001fú¾½àì©4Ô\u001c @¦\u0006\u001e](÷\u001e\u0010yäaéµú³\u0018\u0097ÇaÎáÿO¼\u0092Ü5·p¨\u0002";
                        length = "Ì\u0094DT`<\u001fú¾½àì©4Ô\u001c @¦\u0006\u001e](÷\u001e\u0010yäaéµú³\u0018\u0097ÇaÎáÿO¼\u0092Ü5·p¨\u0002".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_f0() {
        throw new UnsupportedOperationException(b[11]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.io.OutputStream] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    private static void Vulcan_I(Object[] objArr) {
        InputStream inputStream = (InputStream) objArr[0];
        File file = (File) objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        int[] iArrVulcan_O = Vulcan_fe.Vulcan_O();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[1024];
            loop0: while (true) {
                ?? r0 = inputStream.read(bArr);
                if (r0 <= 0) {
                    break;
                }
                try {
                    r0 = fileOutputStream;
                    r0.write(bArr, 0, r0);
                    do {
                        int[] iArr = iArrVulcan_O;
                        if (jLongValue > 0) {
                            if (iArr != null) {
                                break loop0;
                            } else {
                                iArr = iArrVulcan_O;
                            }
                        }
                        if (iArr != null) {
                        }
                    } while (jLongValue <= 0);
                } catch (Exception unused) {
                    throw a((Exception) r0);
                }
            }
            fileOutputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int Vulcan_T(Object[] objArr) {
        return Vulcan_r.getInt((String) objArr[0]);
    }

    public static int Vulcan__(Object[] objArr) {
        return Vulcan_T(new Object[]{b[8]});
    }
}
