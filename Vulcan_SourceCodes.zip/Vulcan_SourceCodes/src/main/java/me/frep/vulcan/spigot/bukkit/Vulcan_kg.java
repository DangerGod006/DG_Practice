package me.frep.vulcan.spigot.bukkit;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Callable;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/bukkit/Vulcan_kg.class */
public class Vulcan_kg extends Vulcan_kX {
    private final Callable Vulcan_L;
    private static final String c;

    private static Exception a(Exception exc) {
        return exc;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0055, code lost:
    
        r8 = 87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x005a, code lost:
    
        r8 = 13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x005f, code lost:
    
        r8 = 34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0064, code lost:
    
        r8 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0069, code lost:
    
        r8 = 121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x006e, code lost:
    
        r8 = 71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0070, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0078, code lost:
    
        if (r4 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x007b, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0080, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0084, code lost:
    
        if (r4 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0088, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x009a, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0008, code lost:
    
        me.frep.vulcan.spigot.bukkit.Vulcan_kg.c = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001d, code lost:
    
        if (r2 <= 1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0020, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0023, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x002a, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0050, code lost:
    
        r8 = 20;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x0020, B:19:0x0080], limit reached: 24 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v2, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0084 -> B:6:0x0020). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 9
            java.lang.String r1 = "k?h^%\u0003"
            r2 = -1
            goto Le
        L8:
            me.frep.vulcan.spigot.bukkit.Vulcan_kg.c = r0
            goto L9a
        Le:
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            char[] r2 = r2.toCharArray()
            r3 = r2; r2 = r1; r1 = r3; 
            int r3 = r3.length
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r4 = 0
            r11 = r4
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = 1
            if (r5 > r6) goto L80
        L20:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L23:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L50;
                case 1: goto L55;
                case 2: goto L5a;
                case 3: goto L5f;
                case 4: goto L64;
                case 5: goto L69;
                default: goto L6e;
            }
        L50:
            r8 = 20
            goto L70
        L55:
            r8 = 87
            goto L70
        L5a:
            r8 = 13
            goto L70
        L5f:
            r8 = 34
            goto L70
        L64:
            r8 = 73
            goto L70
        L69:
            r8 = 121(0x79, float:1.7E-43)
            goto L70
        L6e:
            r8 = 71
        L70:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L80
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L23
        L80:
            r6 = r4; r5 = r3; r4 = r2; r3 = r6; r2 = r5; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r11
            if (r5 > r6) goto L20
        L88:
            java.lang.String r4 = new java.lang.String
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            java.lang.String r3 = r3.intern()
            r4 = r2; r2 = r3; r3 = r4; 
            r3 = r1; r1 = r2; r2 = r3; 
            goto L8
        L9a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.bukkit.Vulcan_kg.m1108clinit():void");
    }

    public Vulcan_kg(String str, Callable callable) {
        super(str);
        this.Vulcan_L = callable;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.util.Map$Entry] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v34, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v40, types: [int] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v45, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v54, types: [int] */
    /* JADX WARN: Type inference failed for: r0v55, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v57, types: [com.google.gson.JsonArray] */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.bukkit.Vulcan_kX
    protected JsonObject Vulcan_q(Object[] objArr) throws Exception {
        ?? A;
        boolean z;
        long jLongValue = ((Long) objArr[0]).longValue();
        JsonObject jsonObject = new JsonObject();
        boolean zVulcan_L = Vulcan_kX.Vulcan_L();
        JsonObject jsonObject2 = new JsonObject();
        Map map = (Map) this.Vulcan_L.call();
        Map map2 = map;
        ?? A2 = map2;
        if (jLongValue >= 0) {
            A2 = map2;
            if (!zVulcan_L) {
                if (map2 == null) {
                    return null;
                }
                A2 = map;
            }
        }
        try {
            try {
                A2 = A2.isEmpty();
                ?? r0 = A2;
                if (!zVulcan_L) {
                    if (A2 != 0) {
                        return null;
                    }
                    r0 = 1;
                }
                ?? r14 = r0;
                Iterator it = map.entrySet().iterator();
                loop0: while (true) {
                    boolean zHasNext = it.hasNext();
                    while (zHasNext) {
                        A = (Map.Entry) it.next();
                        try {
                            try {
                                try {
                                    A = ((int[]) A.getValue()).length;
                                    if (jLongValue <= 0 || zVulcan_L) {
                                        break loop0;
                                    }
                                    if (!zVulcan_L) {
                                        if (A == 0) {
                                            zHasNext = zVulcan_L;
                                            if (jLongValue > 0) {
                                                if (!zHasNext) {
                                                    continue;
                                                }
                                            }
                                        }
                                        A = 0;
                                    }
                                    r14 = A;
                                    JsonArray jsonArray = new JsonArray();
                                    ?? r02 = (int[]) A.getValue();
                                    int length = r02.length;
                                    int i = 0;
                                    while (i < length) {
                                        ?? r03 = r02[i];
                                        try {
                                            r03 = jsonArray;
                                            r03.add(new JsonPrimitive(Integer.valueOf((int) r03)));
                                            i++;
                                            do {
                                                z = zVulcan_L;
                                                if (jLongValue <= 0) {
                                                    break;
                                                }
                                                if (z) {
                                                    break;
                                                }
                                                if (zVulcan_L) {
                                                }
                                            } while (jLongValue < 0);
                                        } catch (Exception unused) {
                                            throw a((Exception) r03);
                                        }
                                    }
                                    jsonObject2.add((String) A.getKey(), jsonArray);
                                    z = zVulcan_L;
                                    if (z) {
                                        break;
                                    }
                                } catch (Exception unused2) {
                                    A = a((Exception) A);
                                    throw A;
                                }
                            } catch (Exception unused3) {
                                throw a((Exception) A);
                            }
                        } catch (Exception unused4) {
                            A = a((Exception) A);
                            throw A;
                        }
                    }
                    break loop0;
                }
                if (jLongValue > 0) {
                    A = r14;
                    if (A != 0) {
                        return null;
                    }
                    jsonObject.add(c, jsonObject2);
                }
                return jsonObject;
            } catch (Exception unused5) {
                throw a((Exception) A2);
            }
        } catch (Exception unused6) {
            A2 = a((Exception) A2);
            throw A2;
        }
    }
}
