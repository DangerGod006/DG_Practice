package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_yL.class */
public final class Vulcan_yL {
    private static final long a = Vulcan_n.a(-3925870843076758986L, -8830643191144240650L, MethodHandles.lookup().lookupClass()).a(92202180677325L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 95861398114803L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[29];
        int i3 = 0;
        String str = "×\u0001\u0084ä£\n\u001d½»\u0018°âÚ1_é\u0010\u0086\u008bú(úN>ï\u00adrnar¯¸\u0096\u0010×\u0001\u0084ä£\n\u001d½9¦\t\u0096À\u0090êi q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080ù9fÜ\u0093´\u0081G~\u001c0\u0001ÔvÕ\u0012\u0010s®õ? \u0003§t\u0010+Àõ%V\u0019Ü\u0010!¿\ft£àÜ§Ü)¸7;ÒV¨\u0010wÏ\u008eF£aß£Àç\u008e\u001fÛ\u0093]´\b\u009aé(\u008e¯n\u001fj\u0018 \u001f!\u001c¾\u0093P\u0010ä¢®ê¤$\u0010\u001c6®Ê¼Cz`\u0091\b\u009aé(\u008e¯n\u001fj\u0018q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080©1BÒÎÂL\u0097\u0018>>2\u0002\u009a\u0088Ð¯\u0088»\u0006\u0015jd±¬Z\u001ag\u008cÞ\u0092H88y\u0017\u008aöhDãºý¢\u0099Ì\u008fRíV`ìÎô04Øn±÷ëF\u0004SD\u0017¬bFnê\u0014\u0093\u008bk\u0006\u001f\u00992J\u007f\u0098Ñ\u0085¿·\u0011j¡¡(\u0098Àú1\u0080ñK\u0081æ6&ø\u008c\u0083u9*¤Í\u0092\"Xýí\u0091\u009c\"*0\u008aÎL½¯Ófí\u008fd\u0007\u0018\u0098Àú1\u0080ñK\u0081\u0094#B\u0093ÇZ5³®®®2äI\u000fÍ\u0018²KÙ\\YÐÞÞÜ\u008d\u008d\u001f¼:\u0096á\u0088\u000b\u009e«)McÊ\b\rT«_ý^¿o\u00182>9Â\u0015ñµô¾¬v\u0095\u000eù»v\u008eç8a 2×T\u001047e\"®uóÚÉø÷\u0013\u001aAU÷\u0010'\\é\u000fþ}¸ä¥¹\u007fpô\u009e\u008aÀ\b×<ã\u001fUÂ\u0001ø\bèá\rÚ3\\'a0q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080ØÝ\u0083ÏA\u009fÏZ{ab>TaËF[Ð¨\u0019Ñ\u0085GÃaIâN\u008c\u000e¼¬\u0018UJ<j°Õð\f\u0006v\u0011B\u0085Ð\u009fÊ8\u001f´½Éq«\u0082\bèá\rÚ3\\'a\bÅO³éx\u0006\nó \u0098Àú1\u0080ñK\u00812Éµ\u009dÊ\u0014\u001fã\b\u0093y»\u0083å\u0005ú\u0090§\u009c\u0085ûL»\u0007";
        int length = "×\u0001\u0084ä£\n\u001d½»\u0018°âÚ1_é\u0010\u0086\u008bú(úN>ï\u00adrnar¯¸\u0096\u0010×\u0001\u0084ä£\n\u001d½9¦\t\u0096À\u0090êi q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080ù9fÜ\u0093´\u0081G~\u001c0\u0001ÔvÕ\u0012\u0010s®õ? \u0003§t\u0010+Àõ%V\u0019Ü\u0010!¿\ft£àÜ§Ü)¸7;ÒV¨\u0010wÏ\u008eF£aß£Àç\u008e\u001fÛ\u0093]´\b\u009aé(\u008e¯n\u001fj\u0018 \u001f!\u001c¾\u0093P\u0010ä¢®ê¤$\u0010\u001c6®Ê¼Cz`\u0091\b\u009aé(\u008e¯n\u001fj\u0018q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080©1BÒÎÂL\u0097\u0018>>2\u0002\u009a\u0088Ð¯\u0088»\u0006\u0015jd±¬Z\u001ag\u008cÞ\u0092H88y\u0017\u008aöhDãºý¢\u0099Ì\u008fRíV`ìÎô04Øn±÷ëF\u0004SD\u0017¬bFnê\u0014\u0093\u008bk\u0006\u001f\u00992J\u007f\u0098Ñ\u0085¿·\u0011j¡¡(\u0098Àú1\u0080ñK\u0081æ6&ø\u008c\u0083u9*¤Í\u0092\"Xýí\u0091\u009c\"*0\u008aÎL½¯Ófí\u008fd\u0007\u0018\u0098Àú1\u0080ñK\u0081\u0094#B\u0093ÇZ5³®®®2äI\u000fÍ\u0018²KÙ\\YÐÞÞÜ\u008d\u008d\u001f¼:\u0096á\u0088\u000b\u009e«)McÊ\b\rT«_ý^¿o\u00182>9Â\u0015ñµô¾¬v\u0095\u000eù»v\u008eç8a 2×T\u001047e\"®uóÚÉø÷\u0013\u001aAU÷\u0010'\\é\u000fþ}¸ä¥¹\u007fpô\u009e\u008aÀ\b×<ã\u001fUÂ\u0001ø\bèá\rÚ3\\'a0q]\n¡¸Z§\u000f\u0094 Ý@ü¬\u0093\u0080ØÝ\u0083ÏA\u009fÏZ{ab>TaËF[Ð¨\u0019Ñ\u0085GÃaIâN\u008c\u000e¼¬\u0018UJ<j°Õð\f\u0006v\u0011B\u0085Ð\u009fÊ8\u001f´½Éq«\u0082\bèá\rÚ3\\'a\bÅO³éx\u0006\nó \u0098Àú1\u0080ñK\u00812Éµ\u009dÊ\u0014\u001fã\b\u0093y»\u0083å\u0005ú\u0090§\u009c\u0085ûL»\u0007".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "JÞ\u000e¸@%ÆWU:\u0082>4vr\u0004\u0010!¿\ft£àÜ§Ü)¸7;ÒV¨";
                        length = "JÞ\u000e¸@%ÆWU:\u0082>4vr\u0004\u0010!¿\ft£àÜ§Ü)¸7;ÒV¨".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_yL() {
        throw new UnsupportedOperationException(b[12]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v23, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    public static void Vulcan_K(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        Vulcan_fe.Vulcan_vu.clear();
        Vulcan_fe.Vulcan_T.clear();
        Vulcan_fe.Vulcan_vH.clear();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        Vulcan_fe.Vulcan_b7.clear();
        Vulcan_fe.Vulcan_MI.clear();
        Vulcan_fe.Vulcan_t3.clear();
        Vulcan_fe.Vulcan_D.clear();
        Vulcan_fe.Vulcan_MW.clear();
        try {
            Vulcan_fe.Vulcan_mG.clear();
            Vulcan_fe.Vulcan_s1.clear();
            Vulcan_fe.Vulcan_vm.clear();
            Vulcan_fe.Vulcan_tl.clear();
            Vulcan_fe.Vulcan_G.clear();
            Vulcan_fe.Vulcan_Mo.clear();
            Vulcan_fe.Vulcan_sG.clear();
            Vulcan_fe.Vulcan_vJ.clear();
            Vulcan_fe.Vulcan_MG.clear();
            Vulcan_fe.Vulcan_bN.clear();
            Vulcan_fe.Vulcan_vb.clear();
            Vulcan_fe.Vulcan_tn.clear();
            if (Vulcan_q == 0) {
                Vulcan_q = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_q);
            }
        } catch (UnsupportedOperationException unused) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0076, code lost:
    
        if (r0 == null) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00ae, code lost:
    
        if (r0 == 0) goto L61;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00d7 A[PHI: r0 r16
  0x00d7: PHI (r0v17 ??) = (r0v16 ??), (r0v28 ??) binds: [B:22:0x008f, B:39:0x00cd] A[DONT_GENERATE, DONT_INLINE]
  0x00d7: PHI (r16v2 java.lang.String) = (r16v1 java.lang.String), (r16v4 java.lang.String) binds: [B:22:0x008f, B:39:0x00cd] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00da  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v207, types: [int] */
    /* JADX WARN: Type inference failed for: r0v208, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v216 */
    /* JADX WARN: Type inference failed for: r0v217 */
    /* JADX WARN: Type inference failed for: r0v218 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v220, types: [java.lang.Object, me.frep.vulcan.spigot.check.data.CheckData] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v245, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v251 */
    /* JADX WARN: Type inference failed for: r0v252 */
    /* JADX WARN: Type inference failed for: r0v253, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v257, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v265 */
    /* JADX WARN: Type inference failed for: r0v266 */
    /* JADX WARN: Type inference failed for: r0v267 */
    /* JADX WARN: Type inference failed for: r0v268 */
    /* JADX WARN: Type inference failed for: r0v269 */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v270 */
    /* JADX WARN: Type inference failed for: r0v271 */
    /* JADX WARN: Type inference failed for: r0v272 */
    /* JADX WARN: Type inference failed for: r0v273 */
    /* JADX WARN: Type inference failed for: r0v274 */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r17v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v190, types: [java.lang.Object[], me.frep.vulcan.spigot.check.data.CheckData] */
    /* JADX WARN: Type inference failed for: r2v194, types: [java.lang.Object[], me.frep.vulcan.spigot.check.data.CheckData] */
    /* JADX WARN: Type inference failed for: r2v198, types: [java.lang.Object[], me.frep.vulcan.spigot.check.data.CheckData] */
    /* JADX WARN: Type inference failed for: r2v202, types: [java.lang.Object[], me.frep.vulcan.spigot.check.data.CheckData] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_X(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 1889
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yL.Vulcan_X(java.lang.Object[]):void");
    }
}
