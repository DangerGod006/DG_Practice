package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_H;
import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_r.class */
public final class Vulcan_r {
    public static final Vulcan_r INSTANCE;
    private VulcanPlugin Vulcan_J;
    private long Vulcan_T;
    private boolean Vulcan__;
    private boolean Vulcan_Y;
    private boolean Vulcan_Q;
    private boolean Vulcan_v;
    private boolean Vulcan_N;
    private boolean Vulcan_e;
    private boolean Vulcan_R;
    private boolean Vulcan_P;
    private boolean Vulcan_F;
    private boolean Vulcan_G;
    private boolean Vulcan_I;
    private boolean Vulcan_W;
    private static Vulcan_H Vulcan_K;
    private static final Vulcan_r[] Vulcan_Z;
    static final boolean Vulcan_y;
    private static int[] Vulcan_n;
    private static final long a = Vulcan_n.a(-8882391975413062298L, -907978999055128684L, MethodHandles.lookup().lookupClass()).a(42635748722773L);
    private static final String[] b;
    private final String Vulcan_h = Vulcan_Oq.spigot();
    private final String Vulcan_p = Vulcan_Oq.nonce();
    private final String Vulcan_c = Vulcan_Oq.resource();
    private final Logger Vulcan_M = Bukkit.getLogger();
    private final Map Vulcan_r = new HashMap();
    private final RunnableC0035Vulcan_Of Vulcan_w = new RunnableC0035Vulcan_Of();
    private final Vulcan_k1 Vulcan_X = new Vulcan_k1();
    private final PluginManager Vulcan_u = Bukkit.getServer().getPluginManager();
    private final Vulcan_fF Vulcan_E = new Vulcan_fF();
    private final Vulcan_v Vulcan_i = new Vulcan_v();
    private final Vulcan_fG Vulcan_l = new Vulcan_fG();
    private final Vulcan_fI Vulcan_j = new Vulcan_fI();
    private final Vulcan_OB Vulcan_g = new Vulcan_OB();
    private final C0043Vulcan_e Vulcan_q = new C0043Vulcan_e();
    private final ExecutorService Vulcan_H = Executors.newSingleThreadExecutor();
    private final ExecutorService Vulcan_a = Executors.newSingleThreadExecutor();
    private final ExecutorService Vulcan_O = Executors.newSingleThreadExecutor();
    private final ExecutorService Vulcan_b = Executors.newSingleThreadExecutor();
    private final Map Vulcan_m = new HashMap();
    private int Vulcan_V = 0;
    private int Vulcan_o = 0;
    private int Vulcan_D = 0;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00a1: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_B(me.frep.vulcan.spigot.VulcanPlugin r8) {
        /*
            Method dump skipped, instruction units count: 1500
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_r.Vulcan_B(me.frep.vulcan.spigot.VulcanPlugin):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_i() {
        /*
            r7 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_r.a
            r1 = 8249027046162(0x780a053ab12, double:4.075560875124E-311)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 38449785000674(0x22f849c6d2e2, double:1.8996717858815E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r1 = r0; r2 = r0; 
            r2 = 102956618345559(0x5da374a9ec57, double:5.08673281365293E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r1 = r0; r2 = r0; 
            r2 = 49734189524660(0x2d3ba4b326b4, double:2.4571954467892E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r1 = r0; r2 = r0; 
            r2 = 104048408621005(0x5ea1a86f6fcd, double:5.1406744204091E-310)
            long r1 = r1 ^ r2
            r16 = r1
            r0 = r14
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            me.frep.vulcan.spigot.Vulcan_fe.Vulcan_q(r0)
            r0 = r10
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            me.frep.vulcan.spigot.Vulcan_fe.Vulcan_b(r0)
            r0 = r12
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            me.frep.vulcan.spigot.Vulcan_yL.Vulcan_K(r0)
            r0 = r16
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            me.frep.vulcan.spigot.Vulcan_yL.Vulcan_X(r0)
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.VulcanPlugin r0 = r0.m1084Vulcan_j()
            r0.reloadConfig()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_r.Vulcan_i():void");
    }

    public static void Vulcan_l(int[] iArr) {
        Vulcan_n = iArr;
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public static int[] m1087Vulcan_A() {
        return Vulcan_n;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public static Vulcan_r[] values() {
        return (Vulcan_r[]) Vulcan_Z.clone();
    }

    public static Vulcan_r valueOf(String str) {
        return (Vulcan_r) Enum.valueOf(Vulcan_r.class, str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [boolean] */
    static {
        int i;
        long j = a ^ 397259919393L;
        Vulcan_l(null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[37];
        int i3 = 0;
        String str = "ò©àÛÀK\u0097yÁBC\u001d\u0087ñ:\u0003\u0010ù4]RÊ\u009dg¨rúèÏt6¦\u0097\b\u0014}ç\u0004V\u0094§_\b\u008fÀK\u0003[ó{F\u0010±7Ð\u009cã\u008cÖò\u008dØFß\u0004R´Æ(8IÙª£ò\u009fµ<\\¾3ä\u0004oÃøW\núçÔº\tà¿Ö¼£E\u009a%$Î¿\u0083\bÀrÿ \u0082Zs\u0006v\u0087¦\u009bâ4Mh \u00ad·Á°qï¦\u0094~P¡D\u0012Ð´\u0088\u0001³\u0083 8IÙª£ò\u009fµèZÓéáê\u0094{$¯c¤ ~\u0099\u001eÂ\u0093òÐ/²n@\u0010\f}ì\u000eq±7\u001f[\u000e8n\u000f¼ü<(%æÐÖ=Øz¾\u0015\u0097!ÅÊ\r=5\u0091kè\bjgFg|\u0013®Ì\u0083±-V\u0000ei=á*lo(Ï\u0007@W_`\u0019¬\u009aw\u008e½|\u008bÛù0¬ùÜØ1\u001b\u0007\u008dú\u0090\u00ad\u0011\u009cþ\u0082\u0011¦løTQj)\u0010ÛáÆ\u000e\u008eï©+zs\u0083Z\\\u0018pE\u0018±7Ð\u009cã\u008cÖòw0\u0019âúþÐ¾[ÂãÆ\u008bìkí ¶LaL¦\"8F\u001e÷ÞéLIä3\u0005«JÍ·\u008f8n\u0099,Çñäü\u0007¢\b\u0094ÏvWÊÝ3/\u0010·[\u0080©\u001d Ä,\u007fÚÀÒò3o£\u0010\u0096\u0086ëgY\u008d)\u0090\u000e)Çó\u008d\fmÇ\bqÂ±4ù{Oõ\bÛaÛ¡\u008f;í?0³coJÁ\u0005Î\u00178\u009d¸n8bø<\u0017M2\tÏ\u0083\u0017V°q\u0006ß¯ðÇDÞùô¨\u009aG¨\u001b\u001c¶»\u0084s\\_\u0003(\f}ì\u000eq±7\u001f¼ÈÕAìð ñ\u0084Ð·\u001c\u0019\u0018çîEY{\u0016Â\u0096¾ç|\u009e!j\u0099SÄ÷ \u0010PI\u009cc\u008c7i\u0095ò¼Ð3¶\u0090\u0018\u0000ônVM\u008aQïÛÆ2vÉY¦2\u0010e¸\u0015¬éÓ6/4\u0096@¯&e:Ù\b±>Ïj\u0095)\u008cX\u0010iã\u008f8~\u00803\u00814\u0017Ü7D\u0097Æ\u0093\b\u0094ÏvWÊÝ3/\b\u0081i ;²\u001eyá(Ï\u0007@W_`\u0019¬\u008dÍµÝúîÀ13djH-¿1k\u00adgãÔ6\u0006Tb\u008f\n¾'k!\u007f'\u0010\u0096\u0086ëgY\u008d)\u0090\u000e)Çó\u008d\fmÇ\bZ;\u009bù\\\u0099AÖ\u0010\u0003m\u008aY\u000bqÍv]K\u0016\u000b»\u0003\u0016\t(\u0096\u0086ëgY\u008d)\u0090Ñ[ìUoHI\"ÜBJ\tZCt¼tÊbßH^7³?#ËI\u007f»\u001cÂ\beÒ\u001bÍC@yl\beÙ\u008d\u009e\u009d¬Ýþ \u0010PI\u009cc\u008c7i%UANì×ìÿ¢A\u0098ô\u0081´ã\u0095²uN7BÁH\u000e";
        int length = "ò©àÛÀK\u0097yÁBC\u001d\u0087ñ:\u0003\u0010ù4]RÊ\u009dg¨rúèÏt6¦\u0097\b\u0014}ç\u0004V\u0094§_\b\u008fÀK\u0003[ó{F\u0010±7Ð\u009cã\u008cÖò\u008dØFß\u0004R´Æ(8IÙª£ò\u009fµ<\\¾3ä\u0004oÃøW\núçÔº\tà¿Ö¼£E\u009a%$Î¿\u0083\bÀrÿ \u0082Zs\u0006v\u0087¦\u009bâ4Mh \u00ad·Á°qï¦\u0094~P¡D\u0012Ð´\u0088\u0001³\u0083 8IÙª£ò\u009fµèZÓéáê\u0094{$¯c¤ ~\u0099\u001eÂ\u0093òÐ/²n@\u0010\f}ì\u000eq±7\u001f[\u000e8n\u000f¼ü<(%æÐÖ=Øz¾\u0015\u0097!ÅÊ\r=5\u0091kè\bjgFg|\u0013®Ì\u0083±-V\u0000ei=á*lo(Ï\u0007@W_`\u0019¬\u009aw\u008e½|\u008bÛù0¬ùÜØ1\u001b\u0007\u008dú\u0090\u00ad\u0011\u009cþ\u0082\u0011¦løTQj)\u0010ÛáÆ\u000e\u008eï©+zs\u0083Z\\\u0018pE\u0018±7Ð\u009cã\u008cÖòw0\u0019âúþÐ¾[ÂãÆ\u008bìkí ¶LaL¦\"8F\u001e÷ÞéLIä3\u0005«JÍ·\u008f8n\u0099,Çñäü\u0007¢\b\u0094ÏvWÊÝ3/\u0010·[\u0080©\u001d Ä,\u007fÚÀÒò3o£\u0010\u0096\u0086ëgY\u008d)\u0090\u000e)Çó\u008d\fmÇ\bqÂ±4ù{Oõ\bÛaÛ¡\u008f;í?0³coJÁ\u0005Î\u00178\u009d¸n8bø<\u0017M2\tÏ\u0083\u0017V°q\u0006ß¯ðÇDÞùô¨\u009aG¨\u001b\u001c¶»\u0084s\\_\u0003(\f}ì\u000eq±7\u001f¼ÈÕAìð ñ\u0084Ð·\u001c\u0019\u0018çîEY{\u0016Â\u0096¾ç|\u009e!j\u0099SÄ÷ \u0010PI\u009cc\u008c7i\u0095ò¼Ð3¶\u0090\u0018\u0000ônVM\u008aQïÛÆ2vÉY¦2\u0010e¸\u0015¬éÓ6/4\u0096@¯&e:Ù\b±>Ïj\u0095)\u008cX\u0010iã\u008f8~\u00803\u00814\u0017Ü7D\u0097Æ\u0093\b\u0094ÏvWÊÝ3/\b\u0081i ;²\u001eyá(Ï\u0007@W_`\u0019¬\u008dÍµÝúîÀ13djH-¿1k\u00adgãÔ6\u0006Tb\u008f\n¾'k!\u007f'\u0010\u0096\u0086ëgY\u008d)\u0090\u000e)Çó\u008d\fmÇ\bZ;\u009bù\\\u0099AÖ\u0010\u0003m\u008aY\u000bqÍv]K\u0016\u000b»\u0003\u0016\t(\u0096\u0086ëgY\u008d)\u0090Ñ[ìUoHI\"ÜBJ\tZCt¼tÊbßH^7³?#ËI\u007f»\u001cÂ\beÒ\u001bÍC@yl\beÙ\u008d\u009e\u009d¬Ýþ \u0010PI\u009cc\u008c7i%UANì×ìÿ¢A\u0098ô\u0081´ã\u0095²uN7BÁH\u000e".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            ?? DesiredAssertionStatus = strArr;
                            b = DesiredAssertionStatus;
                            try {
                                DesiredAssertionStatus = Vulcan_r.class.desiredAssertionStatus();
                                Vulcan_y = DesiredAssertionStatus == 0;
                                INSTANCE = new Vulcan_r(b[15], 0);
                                Vulcan_Z = new Vulcan_r[]{INSTANCE};
                                return;
                            } catch (RuntimeException unused) {
                                throw a((RuntimeException) DesiredAssertionStatus);
                            }
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "iã\u008f8~\u00803\u0081\u00ad\u0018\u0013Ýh\u0014Î&¦ød\u0098É\u009e\u0082¥\u001cC\u0002%ä\u008d²¥}<´\u0084\bUÉÈ\u0010Âý\u009e®pY&eYÉ£u~ý\u0099s";
                        length = "iã\u008f8~\u00803\u0081\u00ad\u0018\u0013Ýh\u0014Î&¦ød\u0098É\u009e\u0082¥\u001cC\u0002%ä\u008d²¥}<´\u0084\bUÉÈ\u0010Âý\u009e®pY&eYÉ£u~ý\u0099s".length();
                        cCharAt = '(';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private Vulcan_r(String str, int i) {
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public VulcanPlugin m1084Vulcan_j() {
        return this.Vulcan_J;
    }

    public long Vulcan_I() {
        return this.Vulcan_T;
    }

    public String Vulcan_r() {
        return this.Vulcan_h;
    }

    public String Vulcan_z() {
        return this.Vulcan_p;
    }

    public String Vulcan__() {
        return this.Vulcan_c;
    }

    public Logger Vulcan_x() {
        return this.Vulcan_M;
    }

    public void Vulcan_k(boolean z) {
        this.Vulcan__ = z;
    }

    public void Vulcan_g(boolean z) {
        this.Vulcan_Y = z;
    }

    public void Vulcan_a(boolean z) {
        this.Vulcan_Q = z;
    }

    public void Vulcan_t(boolean z) {
        this.Vulcan_v = z;
    }

    public void Vulcan_h(boolean z) {
        this.Vulcan_N = z;
    }

    public void Vulcan_L(boolean z) {
        this.Vulcan_e = z;
    }

    public void Vulcan_D(boolean z) {
        this.Vulcan_R = z;
    }

    public void Vulcan_f(boolean z) {
        this.Vulcan_P = z;
    }

    public void Vulcan_y(boolean z) {
        this.Vulcan_F = z;
    }

    public void Vulcan_o(boolean z) {
        this.Vulcan_G = z;
    }

    public void Vulcan_H(boolean z) {
        this.Vulcan_I = z;
    }

    public void Vulcan_I(boolean z) {
        this.Vulcan_W = z;
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public boolean m1079Vulcan_x() {
        return this.Vulcan__;
    }

    public boolean Vulcan_R() {
        return this.Vulcan_Y;
    }

    public boolean Vulcan_U() {
        return this.Vulcan_Q;
    }

    public boolean Vulcan_q() {
        return this.Vulcan_v;
    }

    public boolean Vulcan_P() {
        return this.Vulcan_N;
    }

    public boolean Vulcan_K() {
        return this.Vulcan_e;
    }

    public boolean Vulcan_k() {
        return this.Vulcan_R;
    }

    public boolean Vulcan_j() {
        return this.Vulcan_P;
    }

    public boolean Vulcan_c() {
        return this.Vulcan_F;
    }

    public boolean Vulcan_O() {
        return this.Vulcan_G;
    }

    public boolean Vulcan_n() {
        return this.Vulcan_I;
    }

    public boolean Vulcan_L() {
        return this.Vulcan_W;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public Map m1080Vulcan_r() {
        return this.Vulcan_r;
    }

    public RunnableC0035Vulcan_Of Vulcan_N() {
        return this.Vulcan_w;
    }

    public Vulcan_k1 Vulcan_B() {
        return this.Vulcan_X;
    }

    public PluginManager Vulcan_Q() {
        return this.Vulcan_u;
    }

    public Vulcan_fF Vulcan_E() {
        return this.Vulcan_E;
    }

    public Vulcan_v Vulcan_F() {
        return this.Vulcan_i;
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public Vulcan_fG m1081Vulcan__() {
        return this.Vulcan_l;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public Vulcan_fI m1082Vulcan_r() {
        return this.Vulcan_j;
    }

    public Vulcan_OB Vulcan_e() {
        return this.Vulcan_g;
    }

    public C0043Vulcan_e Vulcan_S() {
        return this.Vulcan_q;
    }

    public ExecutorService Vulcan_v() {
        return this.Vulcan_H;
    }

    public ExecutorService Vulcan_Y() {
        return this.Vulcan_a;
    }

    public ExecutorService Vulcan_W() {
        return this.Vulcan_O;
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public ExecutorService m1083Vulcan__() {
        return this.Vulcan_b;
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public static Vulcan_H m1085Vulcan_j() {
        return Vulcan_K;
    }

    public Map Vulcan_M() {
        return this.Vulcan_m;
    }

    public int Vulcan_o() {
        return this.Vulcan_V;
    }

    public int Vulcan_A() {
        return this.Vulcan_o;
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public int m1086Vulcan_e() {
        return this.Vulcan_D;
    }

    public void Vulcan_R(int i) {
        this.Vulcan_V = i;
    }

    public void Vulcan_f(int i) {
        this.Vulcan_o = i;
    }

    public void Vulcan_V(int i) {
        this.Vulcan_D = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19, types: [me.frep.vulcan.spigot.Vulcan_Of] */
    /* JADX WARN: Type inference failed for: r0v22, types: [me.frep.vulcan.spigot.Vulcan_k1] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_Of] */
    /* JADX WARN: Type inference failed for: r2v9, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_k1] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$ArrayArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public void Vulcan_e(VulcanPlugin vulcanPlugin) {
        long j = a ^ 68295315607692L;
        long j2 = j ^ 96675942106016L;
        long j3 = j ^ 98933632878146L;
        int[] iArrM1087Vulcan_A = m1087Vulcan_A();
        this.Vulcan_J = vulcanPlugin;
        ?? A = iArrM1087Vulcan_A;
        ?? r0 = A;
        if (A == 0) {
            try {
                try {
                    try {
                        A = Vulcan_y;
                        if (A == 0 && vulcanPlugin == null) {
                            throw new AssertionError(b[5]);
                        }
                        ?? r2 = new Object[1];
                        this.Vulcan_w[0] = Long.valueOf(j3);
                        r2.Vulcan_p(r2);
                        ?? r22 = new Object[1];
                        this.Vulcan_X[0] = Long.valueOf(j2);
                        r22.Vulcan_Z(r22);
                        this.Vulcan_H.shutdownNow();
                        this.Vulcan_O.shutdownNow();
                        this.Vulcan_a.shutdownNow();
                        Vulcan_H vulcan_H = Vulcan_K;
                        vulcan_H.mo32Vulcan_V(new Object[]{vulcanPlugin});
                        r0 = vulcan_H;
                    } catch (RuntimeException unused) {
                        A = a((RuntimeException) A);
                        throw A;
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) A);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) A);
            }
        }
        try {
            if (AbstractCheck.Vulcan_k() != null) {
                r0 = new int[2];
                Vulcan_l(r0);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) r0);
        }
    }

    public void Vulcan_R(String str) {
        Bukkit.getLogger().log(Level.INFO, b[36] + str);
    }
}
