package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBedLeaveEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.projectiles.ProjectileSource;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Om, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Om.class */
public class C0038Vulcan_Om implements Listener {
    public final UUID Vulcan_Y = UUID.fromString(b[4]);
    private static String[] Vulcan_N;
    private static final long a = Vulcan_n.a(4692221263035592559L, 3752493835522110807L, MethodHandles.lookup().lookupClass()).a(227954308283931L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0159: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_K(org.bukkit.event.block.BlockPlaceEvent r8) {
        /*
            Method dump skipped, instruction units count: 661
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_K(org.bukkit.event.block.BlockPlaceEvent):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0334: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_I(org.bukkit.event.player.PlayerInteractEvent r11) {
        /*
            Method dump skipped, instruction units count: 892
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_I(org.bukkit.event.player.PlayerInteractEvent):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00bd: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_Y(org.bukkit.event.entity.EntityDamageEvent r9) {
        /*
            Method dump skipped, instruction units count: 202
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_Y(org.bukkit.event.entity.EntityDamageEvent):void");
    }

    public static void Vulcan_W(String[] strArr) {
        Vulcan_N = strArr;
    }

    public static String[] Vulcan_G() {
        return Vulcan_N;
    }

    static {
        int i;
        long j = a ^ 75015242155247L;
        Vulcan_W((String[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[9];
        int i3 = 0;
        String str = "\b\u008f5·\u0000\u009d\u0015¦\u0010¢XûE~§Ä¡ªF4\u0083g\u00996M\bõgÑ\u0095ÁW\u007f\b\b\u001a0#¾\u0018~\u0087\u0085(©.[$ã$ºéqWè$P*¥Ò\u009b].\u0010ã\u009cp\u007fÑe?\u0004Â\\¿ö\"÷m^\u0095Ù³\u0089\bË5\u0019\u001b\u0001tDÎ\u0010Îü}´}ip\u0090l;\u0093\u0015¤=òé";
        int length = "\b\u008f5·\u0000\u009d\u0015¦\u0010¢XûE~§Ä¡ªF4\u0083g\u00996M\bõgÑ\u0095ÁW\u007f\b\b\u001a0#¾\u0018~\u0087\u0085(©.[$ã$ºéqWè$P*¥Ò\u009b].\u0010ã\u009cp\u007fÑe?\u0004Â\\¿ö\"÷m^\u0095Ù³\u0089\bË5\u0019\u001b\u0001tDÎ\u0010Îü}´}ip\u0090l;\u0093\u0015¤=òé".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "*)Qj?{\u0005\u0092\b£¡y±]L\u0087\u0012";
                        length = "*)Qj?{\u0005\u0092\b£¡y±]L\u0087\u0012".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Firework] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v29, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_A(EntitySpawnEvent entitySpawnEvent) {
        long j = a ^ 86507831889181L;
        ?? Vulcan_G = Vulcan_G();
        try {
            try {
                Entity entity = entitySpawnEvent.getEntity();
                if (Vulcan_G == 0) {
                    Vulcan_G = entity instanceof Firework;
                    if (Vulcan_G != 0) {
                        entity = entitySpawnEvent.getEntity();
                    } else {
                        return;
                    }
                }
                ?? r0 = (Firework) entity;
                try {
                    try {
                        ProjectileSource shooter = r0.getShooter();
                        if (Vulcan_G == 0) {
                            r0 = shooter instanceof Player;
                            if (r0 != 0) {
                                shooter = r0.getShooter();
                            } else {
                                return;
                            }
                        }
                        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{(Player) shooter});
                        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
                        if (Vulcan_G == 0) {
                            if (c0042Vulcan_Oz == null) {
                                return;
                            } else {
                                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
                            }
                        }
                        c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_U5(new Object[]{0});
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) r0);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) r0);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) Vulcan_G);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) Vulcan_G);
        }
    }

    private static void lambda$onPlace$0(BlockPlaceEvent blockPlaceEvent, AbstractCheck abstractCheck) {
        Object[] objArr = new Object[2];
        blockPlaceEvent[1] = Long.valueOf((a ^ 105925603471648L) ^ 18210978118126L);
        objArr[0] = objArr;
        abstractCheck.Vulcan_a(objArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v14, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v38, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v3, types: [long] */
    /* JADX WARN: Type inference failed for: r1v36, types: [double] */
    /* JADX WARN: Type inference failed for: r2v17, types: [double] */
    /* JADX WARN: Type inference failed for: r5v5, types: [double, java.lang.Object[], long, me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler(priority = EventPriority.LOWEST)
    public void Vulcan_I(BlockBreakEvent blockBreakEvent) {
        ?? Vulcan_O;
        ?? M637Vulcan_r;
        ?? r1 = (a ^ 46661176984637L) ^ 62976338621909L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{blockBreakEvent.getPlayer()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        ?? IsCancelled = c0042Vulcan_Oz;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                IsCancelled = c0042Vulcan_OzVulcan_L;
            }
        }
        try {
            try {
                ?? M637Vulcan_r2 = IsCancelled.m637Vulcan_r(new Object[0]);
                ?? M637Vulcan_r3 = M637Vulcan_r2;
                if (strArrVulcan_G == null) {
                    ?? x = blockBreakEvent.getBlock().getX();
                    ?? r5 = new Object[4];
                    blockBreakEvent.getBlock().getY()[3] = Double.valueOf(blockBreakEvent.getBlock().getZ());
                    r1[2] = Long.valueOf((long) r5);
                    x[1] = Double.valueOf((double) r5);
                    M637Vulcan_r2[0] = Double.valueOf((double) r5);
                    r5.Vulcan_tC(r5);
                    IsCancelled = blockBreakEvent.isCancelled();
                    if (IsCancelled == 0) {
                        Vulcan_O = IsCancelled;
                    } else {
                        M637Vulcan_r3 = c0042Vulcan_OzVulcan_L.m637Vulcan_r(new Object[0]);
                        M637Vulcan_r3.Vulcan_Dq(new Object[0]);
                        Vulcan_O = M637Vulcan_r3;
                    }
                } else {
                    M637Vulcan_r3.Vulcan_Dq(new Object[0]);
                    Vulcan_O = M637Vulcan_r3;
                }
                try {
                    Vulcan_O = c0042Vulcan_OzVulcan_L.m639Vulcan_M(new Object[0]).Vulcan_O(new Object[0]);
                    if (Vulcan_O == 0) {
                        M637Vulcan_r = Vulcan_O;
                    } else {
                        BlockBreakEvent blockBreakEvent2 = blockBreakEvent;
                        blockBreakEvent2.setCancelled(true);
                        M637Vulcan_r = blockBreakEvent2;
                    }
                    try {
                        if (blockBreakEvent.getBlock().getType().toString().equals(b[1])) {
                            M637Vulcan_r = c0042Vulcan_OzVulcan_L.m637Vulcan_r(new Object[0]);
                            M637Vulcan_r.Vulcan_X6(new Object[]{0});
                        }
                        c0042Vulcan_OzVulcan_L.m635Vulcan_B(new Object[0]).forEach((v1) -> {
                            lambda$onBreak$1(r1, v1);
                        });
                        c0042Vulcan_OzVulcan_L.m637Vulcan_r(new Object[0]).m792Vulcan_G(new Object[]{false});
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) M637Vulcan_r);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) Vulcan_O);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) IsCancelled);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) IsCancelled);
        }
    }

    private static void lambda$onBreak$1(BlockBreakEvent blockBreakEvent, AbstractCheck abstractCheck) {
        Object[] objArr = new Object[2];
        blockBreakEvent[1] = Long.valueOf((a ^ 38170533011682L) ^ 90649279440940L);
        objArr[0] = objArr;
        abstractCheck.Vulcan_a(objArr);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_G(PlayerPickupItemEvent playerPickupItemEvent) {
        long j = a ^ 140425143195893L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerPickupItemEvent.getPlayer()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_D0(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_U(PlayerItemConsumeEvent playerItemConsumeEvent) {
        long j = a ^ 129229794337249L;
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerItemConsumeEvent.getPlayer()});
        ?? M637Vulcan_r = c0042Vulcan_OzVulcan_L;
        if (M637Vulcan_r == 0) {
            return;
        }
        try {
            if (playerItemConsumeEvent.getItem().toString().contains(b[2])) {
                M637Vulcan_r = c0042Vulcan_OzVulcan_L.m637Vulcan_r(new Object[0]);
                M637Vulcan_r.Vulcan_D8(new Object[0]);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) M637Vulcan_r);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_a(PlayerBedEnterEvent playerBedEnterEvent) {
        long j = a ^ 81549284728800L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerBedEnterEvent.getPlayer()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_DB(new Object[0]);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_U(PlayerBedLeaveEvent playerBedLeaveEvent) {
        long j = a ^ 93996868445850L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerBedLeaveEvent.getPlayer()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_Di(new Object[0]);
    }

    private static void lambda$onInteract$2(PlayerInteractEvent playerInteractEvent, AbstractCheck abstractCheck) {
        Object[] objArr = new Object[2];
        playerInteractEvent[1] = Long.valueOf((a ^ 63796716401452L) ^ 82203518729186L);
        objArr[0] = objArr;
        abstractCheck.Vulcan_a(objArr);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_x(PlayerDeathEvent playerDeathEvent) {
        long j = a ^ 50742783188560L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerDeathEvent.getEntity()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_D(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.Vulcan_kw] */
    /* JADX WARN: Type inference failed for: r0v14, types: [me.frep.vulcan.spigot.Vulcan_kw] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_kw] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_kw] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_m(PlayerInteractEntityEvent playerInteractEntityEvent) {
        long j = a ^ 18809598314766L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerInteractEntityEvent.getPlayer()});
        ?? r0 = c0042Vulcan_OzVulcan_L;
        if (r0 == 0) {
            return;
        }
        try {
            try {
                switch (Vulcan_OX.Vulcan_S[playerInteractEntityEvent.getRightClicked().getType().ordinal()]) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        ?? r2 = new Object[1];
                        c0042Vulcan_OzVulcan_L.m638Vulcan_O(new Object[0])[0] = Long.valueOf(System.currentTimeMillis());
                        r2.Vulcan_l(r2);
                        r0 = strArrVulcan_G;
                        if (r0 != 0) {
                            break;
                        } else {
                            return;
                        }
                    case 5:
                        ?? r22 = new Object[1];
                        c0042Vulcan_OzVulcan_L.m638Vulcan_O(new Object[0])[0] = Long.valueOf(System.currentTimeMillis());
                        r22.Vulcan_V(r22);
                        return;
                    default:
                        return;
                }
            } catch (RuntimeException unused) {
                throw a((RuntimeException) r0);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) r0);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:170:0x02c3
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_H(org.bukkit.event.entity.ProjectileLaunchEvent r7) {
        /*
            Method dump skipped, instruction units count: 729
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_H(org.bukkit.event.entity.ProjectileLaunchEvent):void");
    }

    private static void lambda$onLaunch$3(ProjectileLaunchEvent projectileLaunchEvent, AbstractCheck abstractCheck) {
        Object[] objArr = new Object[2];
        projectileLaunchEvent[1] = Long.valueOf((a ^ 61847373820356L) ^ 80235855427850L);
        objArr[0] = objArr;
        abstractCheck.Vulcan_a(objArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:90:0x00c9 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v41, types: [int] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v48, types: [org.bukkit.World] */
    /* JADX WARN: Type inference failed for: r0v49, types: [org.bukkit.World] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException, java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v52, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v61, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v73, types: [org.bukkit.event.player.PlayerTeleportEvent$TeleportCause] */
    /* JADX WARN: Type inference failed for: r0v85 */
    /* JADX WARN: Type inference failed for: r0v86 */
    /* JADX WARN: Type inference failed for: r0v87 */
    /* JADX WARN: Type inference failed for: r0v88 */
    /* JADX WARN: Type inference failed for: r0v89 */
    /* JADX WARN: Type inference failed for: r0v90 */
    /* JADX WARN: Type inference failed for: r0v91 */
    /* JADX WARN: Type inference failed for: r0v92 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r20v0 */
    /* JADX WARN: Type inference failed for: r6v2, types: [int, java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR, ignoreCancelled = true)
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_g(org.bukkit.event.player.PlayerTeleportEvent r12) {
        /*
            Method dump skipped, instruction units count: 481
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_g(org.bukkit.event.player.PlayerTeleportEvent):void");
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_X(PlayerChangedWorldEvent playerChangedWorldEvent) {
        long j = a ^ 71090255075111L;
        String[] strArrVulcan_G = Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{playerChangedWorldEvent.getPlayer()});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_j(new Object[0]);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:14:0x004f
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_I(org.bukkit.event.player.PlayerFishEvent r7) {
        /*
            Method dump skipped, instruction units count: 264
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_I(org.bukkit.event.player.PlayerFishEvent):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler
    public void Vulcan_W(BlockDamageEvent blockDamageEvent) {
        long j = a ^ 25695685168554L;
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{blockDamageEvent.getPlayer()});
        ?? M637Vulcan_r = c0042Vulcan_OzVulcan_L;
        if (M637Vulcan_r == 0) {
            return;
        }
        try {
            if (blockDamageEvent.getInstaBreak()) {
                M637Vulcan_r = c0042Vulcan_OzVulcan_L.m637Vulcan_r(new Object[0]);
                M637Vulcan_r.m792Vulcan_G(new Object[]{true});
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) M637Vulcan_r);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_p(org.bukkit.event.entity.EntityDamageByEntityEvent r10) {
        /*
            Method dump skipped, instruction units count: 672
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_p(org.bukkit.event.entity.EntityDamageByEntityEvent):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:107:0x0272
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
    public void Vulcan_c(org.bukkit.event.player.PlayerMoveEvent r15) {
        /*
            Method dump skipped, instruction units count: 1718
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_c(org.bukkit.event.player.PlayerMoveEvent):void");
    }

    private static void lambda$onMove$4(Player player, Vulcan_ka vulcan_ka) {
        vulcan_ka.Vulcan__l(new Object[]{player.getNearbyEntities(1.5d, 2.0d, 1.5d)});
    }

    private static void lambda$onMove$5(PlayerMoveEvent playerMoveEvent, AbstractCheck abstractCheck) {
        Object[] objArr = new Object[2];
        playerMoveEvent[1] = Long.valueOf((a ^ 102201545626486L) ^ 48606375877560L);
        objArr[0] = objArr;
        abstractCheck.Vulcan_a(objArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:33:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @org.bukkit.event.EventHandler
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_P(org.bukkit.event.player.PlayerKickEvent r7) {
        /*
            r6 = this;
            long r0 = me.frep.vulcan.spigot.C0038Vulcan_Om.a
            r1 = 55826203787879(0x32c60d0bc267, double:2.75818094293235E-310)
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = Vulcan_G()
            r1 = r7
            org.bukkit.entity.Player r1 = r1.getPlayer()
            r11 = r1
            r10 = r0
            me.frep.vulcan.spigot.Vulcan_r r0 = me.frep.vulcan.spigot.Vulcan_r.INSTANCE
            me.frep.vulcan.spigot.Vulcan_fI r0 = r0.m1082Vulcan_r()
            r1 = r11
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_L(r1)
            r12 = r0
            r0 = r12
            r1 = r10
            if (r1 != 0) goto L3d
            if (r0 != 0) goto L3b
            goto L3a
        L36:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3a:
            return
        L3b:
            r0 = r12
        L3d:
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L56
            me.frep.vulcan.spigot.Vulcan_ka r0 = r0.m639Vulcan_M(r1)     // Catch: java.lang.RuntimeException -> L56
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L56
            boolean r0 = r0.Vulcan_O(r1)     // Catch: java.lang.RuntimeException -> L56
            r1 = r10
            if (r1 != 0) goto L7d
            if (r0 == 0) goto L85
            goto L5a
        L56:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L63
            throw r0     // Catch: java.lang.RuntimeException -> L63
        L5a:
            r0 = r7
            r1 = r10
            if (r1 != 0) goto L81
            goto L67
        L63:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L79
            throw r0     // Catch: java.lang.RuntimeException -> L79
        L67:
            java.lang.String r0 = r0.getReason()     // Catch: java.lang.RuntimeException -> L79
            java.lang.String r0 = r0.toLowerCase()     // Catch: java.lang.RuntimeException -> L79
            java.lang.String[] r1 = me.frep.vulcan.spigot.C0038Vulcan_Om.b     // Catch: java.lang.RuntimeException -> L79
            r2 = 6
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L79
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L79
            goto L7d
        L79:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L7d:
            if (r0 == 0) goto L85
            r0 = r7
        L81:
            r1 = 1
            r0.setCancelled(r1)
        L85:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0038Vulcan_Om.Vulcan_P(org.bukkit.event.player.PlayerKickEvent):void");
    }
}
