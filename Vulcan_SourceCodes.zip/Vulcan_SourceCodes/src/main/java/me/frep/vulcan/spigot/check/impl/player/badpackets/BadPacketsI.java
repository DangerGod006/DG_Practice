package me.frep.vulcan.spigot.check.impl.player.badpackets;

import com.github.retrooper.packetevents.event.PacketEvent;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_yU;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPacketsI.class */
@CheckInfo(name = "Bad Packets", type = 'I', complexType = "Entity Action", description = "Sent EntityAction while attacking.")
public class BadPacketsI extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public BadPacketsI(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v18, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r20v0 */
    /* JADX WARN: Type inference failed for: r2v24, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsI] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v13, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ?? r1 = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 86877937232409L;
        long j2 = jLongValue ^ 108218722128643L;
        long j3 = jLongValue ^ 83955508045016L;
        ?? Vulcan_n = BadPackets8.Vulcan_n();
        try {
            try {
                ?? r3 = new Object[2];
                r1[1] = Long.valueOf(j3);
                r3[0] = r3;
                Vulcan_n = Vulcan_B(r3);
                ?? Vulcan_Q = Vulcan_n;
                if (Vulcan_n == 0) {
                    if (Vulcan_n != 0) {
                        Vulcan_Q = this.Vulcan_b.m637Vulcan_r(new Object[0]).Vulcan_Q(new Object[0]);
                    } else {
                        return;
                    }
                }
                ?? r20 = Vulcan_Q;
                ?? r32 = new Object[2];
                new Vulcan_yU[]{Vulcan_yU.SERVER_VERSION, Vulcan_yU.CLIENT_VERSION, Vulcan_yU.FAST, Vulcan_yU.SPECTATOR, Vulcan_yU.DEATH}[1] = Long.valueOf(j);
                r32[0] = r32;
                boolean zVulcan_t = Vulcan_t((Object[]) r32);
                boolean z = r20 == true ? 1 : 0;
                if (Vulcan_n == 0) {
                    if (!z) {
                        return;
                    } else {
                        z = zVulcan_t;
                    }
                }
                if (!z) {
                    ?? r2 = new Object[1];
                    this[0] = Long.valueOf(j2);
                    r2.Vulcan_K(r2);
                }
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_n);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_n);
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
