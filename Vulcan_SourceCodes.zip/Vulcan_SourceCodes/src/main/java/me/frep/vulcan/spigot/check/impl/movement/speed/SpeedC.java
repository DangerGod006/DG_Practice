package me.frep.vulcan.spigot.check.impl.movement.speed;

import java.lang.invoke.MethodHandles;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/speed/SpeedC.class */
@CheckInfo(name = "Speed", type = 'C', complexType = "Air", description = "Moving too quickly in the air.")
public class SpeedC extends AbstractCheck {
    public final UUID Vulcan_L;
    private static final long b = Vulcan_n.a(8324615209046101680L, -407719375692887049L, MethodHandles.lookup().lookupClass()).a(93320145804809L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0a98: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 2751
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.speed.SpeedC.Vulcan_T(java.lang.Object[]):void");
    }

    static {
        int i;
        long j = b ^ 67154565545173L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[7];
        int i3 = 0;
        String str = "lé/ã\u009fâ\u0089\u0000\u0087/\u0093:V:,\u009f¢\u0017Ãô\u0003iå3iÆ¥\b\u009e¥¯¯j\u0095AlËí¯f\b\u0011Ê&)ÝÍb\u0013\b/Æ`Q(ÊZÔ\b¨\u0015\u0089áÍ\u0007ÿï\u0010\u0085ghürÃÓPÅD§tÍ¤ïå";
        int length = "lé/ã\u009fâ\u0089\u0000\u0087/\u0093:V:,\u009f¢\u0017Ãô\u0003iå3iÆ¥\b\u009e¥¯¯j\u0095AlËí¯f\b\u0011Ê&)ÝÍb\u0013\b/Æ`Q(ÊZÔ\b¨\u0015\u0089áÍ\u0007ÿï\u0010\u0085ghürÃÓPÅD§tÍ¤ïå".length();
        char cCharAt = '(';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "ðÑ¹½-\u0000±,\bÇ¤]2!\r¤.";
                        length = "ðÑ¹½-\u0000±,\bÇ¤]2!\r¤.".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [int] */
    public SpeedC(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 138382724865828L;
        ?? Vulcan_m = SpeedE.Vulcan_m();
        try {
            this.Vulcan_L = UUID.fromString(d[0]);
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_m++;
                SpeedE.Vulcan_A((int) Vulcan_m);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_m);
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
