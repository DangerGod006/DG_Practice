package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kk.class */
@FunctionalInterface
public interface Vulcan_kk {
    void Vulcan_I(Object[] objArr);
}
