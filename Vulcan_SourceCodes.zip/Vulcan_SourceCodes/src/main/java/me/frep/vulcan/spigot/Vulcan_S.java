package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.TabCompleter;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_S.class */
public class Vulcan_S implements TabCompleter {
    private static boolean Vulcan_G;
    private static final long a = Vulcan_n.a(-9179701596379505081L, 2983630770312659327L, MethodHandles.lookup().lookupClass()).a(66476606047210L);
    private static final String[] b;

    public static void Vulcan_Y(boolean z) {
        Vulcan_G = z;
    }

    public static boolean Vulcan_f() {
        return Vulcan_G;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_Y() {
        return !Vulcan_f();
    }

    static {
        int i;
        long j = a ^ 72415986053950L;
        Vulcan_Y(true);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[16];
        int i3 = 0;
        String str = "\u0000Ò\nåzûÊX\b4Æ?ù\u001f|Ö½\b\u0017s\u000fm\u009c¶Ï¡\u0010\u0016&¶U.]ÝÅ\u0090r,M\u0014\u0007±Ï\bØ\nøüÕý\n?\b{Ôz\u0005\u0095N/1\u0010Å\u0095ãßýÛ(\u009a]é4\u008e\u009eÉJ%\u0010\u0016&¶U.]ÝÅ\u0090r,M\u0014\u0007±Ï\u0010©\u0001}\u0082?C÷ãÓfÀù¹\r\u0007ö\b[¦É¸×ª\u0003\u009e\u0010GÇñü¸f³)\u008dH8Ì$>s#\bKÄ\u0016\u0015Î· \u009c\bÄj\u009c²\u0086ëT\u000e\b7\u008czM\u0091\u001c\u009fæ";
        int length = "\u0000Ò\nåzûÊX\b4Æ?ù\u001f|Ö½\b\u0017s\u000fm\u009c¶Ï¡\u0010\u0016&¶U.]ÝÅ\u0090r,M\u0014\u0007±Ï\bØ\nøüÕý\n?\b{Ôz\u0005\u0095N/1\u0010Å\u0095ãßýÛ(\u009a]é4\u008e\u009eÉJ%\u0010\u0016&¶U.]ÝÅ\u0090r,M\u0014\u0007±Ï\u0010©\u0001}\u0082?C÷ãÓfÀù¹\r\u0007ö\b[¦É¸×ª\u0003\u009e\u0010GÇñü¸f³)\u008dH8Ì$>s#\bKÄ\u0016\u0015Î· \u009c\bÄj\u009c²\u0086ëT\u000e\b7\u008czM\u0091\u001c\u009fæ".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u009f\u0017§\u009bã Jé\b+È\u001a\u0081\u009e5®û";
                        length = "\u009f\u0017§\u009bã Jé\b+È\u001a\u0081\u009e5®û".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x015d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0136 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    @javax.annotation.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.util.List onTabComplete(@org.jetbrains.annotations.NotNull org.bukkit.command.CommandSender r6, @org.jetbrains.annotations.NotNull org.bukkit.command.Command r7, @org.jetbrains.annotations.NotNull java.lang.String r8, java.lang.String[] r9) {
        /*
            Method dump skipped, instruction units count: 364
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_S.onTabComplete(org.bukkit.command.CommandSender, org.bukkit.command.Command, java.lang.String, java.lang.String[]):java.util.List");
    }
}
