package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_O8;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientClientStatus;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEffect;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerPositionAndLook;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRemoveEntityEffect;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes;
import java.lang.invoke.MethodHandles;
import java.util.LinkedList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_fi, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fi.class */
public class C0047Vulcan_fi {
    private final C0042Vulcan_Oz Vulcan_L3;
    private boolean Vulcan_tf;
    private boolean Vulcan_tM;
    private boolean Vulcan_y;
    private boolean Vulcan_w;
    private boolean Vulcan_n;
    private boolean Vulcan_t9;
    private boolean Vulcan_t6;
    private boolean Vulcan_ti;
    private boolean Vulcan_LC;
    private boolean Vulcan_F;
    private boolean Vulcan_LF;
    private boolean Vulcan_Lz;
    private boolean Vulcan_tu;
    private boolean Vulcan_D;
    private boolean Vulcan_L0;
    private boolean Vulcan__;
    private boolean Vulcan_LD;
    private boolean Vulcan_tn;
    private boolean Vulcan_U;
    private boolean Vulcan_t2;
    private boolean Vulcan_Lh;
    private boolean Vulcan_L4;
    private boolean Vulcan_tX;
    private boolean Vulcan_tA;
    private boolean Vulcan_p;
    private boolean Vulcan_r;
    private boolean Vulcan_h;
    private boolean Vulcan_tm;
    private boolean Vulcan_tw;
    private boolean Vulcan_Lb;
    private boolean Vulcan_LA;
    private boolean Vulcan_s;
    private boolean Vulcan_tG;
    private boolean Vulcan_LI;
    private boolean Vulcan_G;
    private boolean Vulcan_Lk;
    private int Vulcan_L;
    private int Vulcan_tV;
    private int Vulcan_j;
    private int Vulcan_tk;
    private int Vulcan_S;
    private int Vulcan_Lw;
    private int Vulcan_LZ;
    private int Vulcan_LP;
    private int Vulcan_d;
    private int Vulcan_tR;
    private int Vulcan_t4;
    private int Vulcan_T;
    private int Vulcan_tI;
    private int Vulcan_t7;
    private int Vulcan_Li;
    private int Vulcan_tN;
    private int Vulcan_ty;
    private int Vulcan_N;
    private int Vulcan_LX;
    private int Vulcan_t3;
    private int Vulcan_c;
    private int Vulcan_LM;
    private int Vulcan_L5;
    private int Vulcan_k;
    private int Vulcan_t1;
    private int Vulcan_P;
    private int Vulcan_M;
    private int Vulcan_L_;
    private int Vulcan_ta;
    private int Vulcan_t5;
    private int Vulcan_t;
    private int Vulcan_tT;
    private int Vulcan_LR;
    private int Vulcan_Q;
    private int Vulcan_to;
    private int Vulcan_R;
    private double Vulcan_u;
    private double Vulcan_Z;
    private double Vulcan_tj;
    private double Vulcan_LL;
    private double Vulcan_i;
    private double Vulcan_tl;
    private double Vulcan_LO;
    private double Vulcan_Ln;
    private double Vulcan_C;
    private double Vulcan_Lj;
    private double Vulcan_J;
    private double Vulcan_f;
    private double Vulcan_v;
    private double Vulcan_tb;
    private long Vulcan_o;
    private long Vulcan_I;
    private long Vulcan_tp;
    private ItemStack Vulcan_b;
    private ItemStack Vulcan_tL;
    private ItemStack Vulcan_tz;
    private ItemStack Vulcan_tJ;
    private ItemStack Vulcan_tU;
    private ItemStack Vulcan_tK;
    private long Vulcan_tc;
    private long Vulcan_m;
    private static String Vulcan_t0;
    private static final long a = Vulcan_n.a(418305377874428382L, 495546932148776613L, MethodHandles.lookup().lookupClass()).a(13831486027584L);
    private static final String[] b;
    private boolean Vulcan_Ld = false;
    private double Vulcan_K = 0.1d;
    private double Vulcan_V = 0.6d;
    private double Vulcan_Lq = 0.42d;
    private double Vulcan_ts = 0.08d;
    private double Vulcan_tY = 0.42d;
    private double Vulcan_tt = 0.08d;
    private double Vulcan_LJ = 3.0d;
    final LinkedList Vulcan_tx = new LinkedList();
    private int Vulcan_l = 0;
    private int Vulcan_te = 100;
    private int Vulcan_q = 100;
    private int Vulcan_tW = 100;
    private int Vulcan_tB = 100;
    private int Vulcan_Lf = 100;
    private int Vulcan_tS = 100;
    private int Vulcan_LY = 100;
    private int Vulcan_tr = 100;
    private int Vulcan_Y = 150;
    private int Vulcan_B = 100;
    private int Vulcan_LW = 100;
    private int Vulcan_t8 = 100;
    private int Vulcan_La = 100;
    private int Vulcan_tZ = 100;
    private int Vulcan_LH = 100;
    private int Vulcan_tH = 100;
    private int Vulcan_tC = 0;
    private int Vulcan_LV = 0;
    private int Vulcan_tE = 0;
    private int Vulcan_LG = 0;
    private int Vulcan_tq = 0;
    private int Vulcan_X = 100;
    private int Vulcan_W = 100;
    private int Vulcan_e = 100;
    private int Vulcan_tg = 100;
    private int Vulcan_E = 100;
    private int Vulcan_Lo = 100;
    private int Vulcan_LT = 100;
    private int Vulcan_g = 0;
    private int Vulcan_Lc = 0;
    private int Vulcan_LE = 100;
    private int Vulcan_td = 500;
    private int Vulcan_x = Vulcan_O8.Vulcan_z;
    private int Vulcan_th = Vulcan_O8.Vulcan_z;
    private int Vulcan_tP = 100;
    private int Vulcan_t_ = 100;
    private int Vulcan_O = 100;
    private int Vulcan_tQ = 100;
    private int Vulcan_L9 = 100;
    private int Vulcan_z = 100;
    private int Vulcan_tO = 100;
    private int Vulcan_LN = 0;
    private int Vulcan_Le = 0;
    private int Vulcan_tD = 0;
    private int Vulcan_tF = 100;
    private int Vulcan_a = 0;
    private int Vulcan_Ls = 0;
    private int Vulcan_tv = 100;
    private int Vulcan_L8 = 100;
    private GameMode Vulcan_H = GameMode.SURVIVAL;
    final C0036Vulcan_Oj Vulcan_A = new C0036Vulcan_Oj(15);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x06d4: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_l5(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 2476
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_l5(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0157: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void lambda$handleMetaData$6(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata r10) {
        /*
            Method dump skipped, instruction units count: 461
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.lambda$handleMetaData$6(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata):void");
    }

    public static void Vulcan_t(String str) {
        Vulcan_t0 = str;
    }

    public static String Vulcan_q() {
        return Vulcan_t0;
    }

    static {
        long j = a ^ 7096178470165L;
        Vulcan_t((String) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = "\u0086r/à\u008e\u0086ê,\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("\u0086r/à\u008e\u0086ê,\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                return;
            }
            cCharAt = "\u0086r/à\u008e\u0086ê,\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ\u0010\u009eÀ\u0001x]yóX¤\u0011øT\u0017¡ñÌ".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_yo(Object[] objArr) {
        this.Vulcan_tf = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yw(Object[] objArr) {
        this.Vulcan_tM = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_y7(Object[] objArr) {
        this.Vulcan_y = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_y1(Object[] objArr) {
        this.Vulcan_w = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yH(Object[] objArr) {
        this.Vulcan_n = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_ya(Object[] objArr) {
        this.Vulcan_t9 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yQ(Object[] objArr) {
        this.Vulcan_t6 = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public void m784Vulcan_y(Object[] objArr) {
        this.Vulcan_ti = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yq(Object[] objArr) {
        this.Vulcan_LC = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_y3(Object[] objArr) {
        this.Vulcan_F = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public void m785Vulcan_o(Object[] objArr) {
        this.Vulcan_LF = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_y9(Object[] objArr) {
        this.Vulcan_Lz = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yz(Object[] objArr) {
        this.Vulcan_tu = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yG(Object[] objArr) {
        this.Vulcan_D = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public void m786Vulcan_a(Object[] objArr) {
        this.Vulcan_L0 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yi(Object[] objArr) {
        this.Vulcan__ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_y8(Object[] objArr) {
        this.Vulcan_LD = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yn(Object[] objArr) {
        this.Vulcan_tn = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yI(Object[] objArr) {
        this.Vulcan_U = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yP(Object[] objArr) {
        this.Vulcan_t2 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yY(Object[] objArr) {
        this.Vulcan_Lh = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public void m787Vulcan_z(Object[] objArr) {
        this.Vulcan_L4 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yL(Object[] objArr) {
        this.Vulcan_tX = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public void m788Vulcan_i(Object[] objArr) {
        this.Vulcan_tA = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yO(Object[] objArr) {
        this.Vulcan_p = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yk(Object[] objArr) {
        this.Vulcan_r = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public void m789Vulcan_L(Object[] objArr) {
        this.Vulcan_h = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yM(Object[] objArr) {
        this.Vulcan_tm = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yd(Object[] objArr) {
        this.Vulcan_tw = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yF(Object[] objArr) {
        this.Vulcan_Lb = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_yr(Object[] objArr) {
        this.Vulcan_LA = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public void m790Vulcan_b(Object[] objArr) {
        this.Vulcan_s = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_ys(Object[] objArr) {
        this.Vulcan_tG = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public void m791Vulcan_g(Object[] objArr) {
        this.Vulcan_LI = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_ye(Object[] objArr) {
        this.Vulcan_G = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public void m792Vulcan_G(Object[] objArr) {
        this.Vulcan_Ld = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ey(Object[] objArr) {
        this.Vulcan_K = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_E3(Object[] objArr) {
        this.Vulcan_V = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public void m793Vulcan_E(Object[] objArr) {
        this.Vulcan_Lq = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EA(Object[] objArr) {
        this.Vulcan_ts = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_E5(Object[] objArr) {
        this.Vulcan_tY = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EE(Object[] objArr) {
        this.Vulcan_tt = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EL(Object[] objArr) {
        this.Vulcan_LJ = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_XT(Object[] objArr) {
        this.Vulcan_L = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XE(Object[] objArr) {
        this.Vulcan_tV = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XM(Object[] objArr) {
        this.Vulcan_j = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public void m794Vulcan_d(Object[] objArr) {
        this.Vulcan_tk = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XN(Object[] objArr) {
        this.Vulcan_l = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xc(Object[] objArr) {
        this.Vulcan_S = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XL(Object[] objArr) {
        this.Vulcan_Lw = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XU(Object[] objArr) {
        this.Vulcan_LZ = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public void m795Vulcan_T(Object[] objArr) {
        this.Vulcan_LP = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X9(Object[] objArr) {
        this.Vulcan_d = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public void m796Vulcan_I(Object[] objArr) {
        this.Vulcan_te = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XW(Object[] objArr) {
        this.Vulcan_tR = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xd(Object[] objArr) {
        this.Vulcan_t4 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xh(Object[] objArr) {
        this.Vulcan_T = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X5(Object[] objArr) {
        this.Vulcan_tI = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xi(Object[] objArr) {
        this.Vulcan_t7 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XS(Object[] objArr) {
        this.Vulcan_Li = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XQ(Object[] objArr) {
        this.Vulcan_q = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public void m797Vulcan__(Object[] objArr) {
        this.Vulcan_tN = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public void m798Vulcan_O(Object[] objArr) {
        this.Vulcan_ty = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XK(Object[] objArr) {
        this.Vulcan_N = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xw(Object[] objArr) {
        this.Vulcan_LX = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xg(Object[] objArr) {
        this.Vulcan_t3 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XB(Object[] objArr) {
        this.Vulcan_tW = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xo(Object[] objArr) {
        this.Vulcan_tB = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xp(Object[] objArr) {
        this.Vulcan_Lf = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xa(Object[] objArr) {
        this.Vulcan_c = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public void m799Vulcan_U(Object[] objArr) {
        this.Vulcan_LM = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XX(Object[] objArr) {
        this.Vulcan_L5 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xl(Object[] objArr) {
        this.Vulcan_k = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xr(Object[] objArr) {
        this.Vulcan_t1 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xm(Object[] objArr) {
        this.Vulcan_P = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public void m800Vulcan_k(Object[] objArr) {
        this.Vulcan_tS = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public void m801Vulcan_Z(Object[] objArr) {
        this.Vulcan_LY = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XF(Object[] objArr) {
        this.Vulcan_tr = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public void m802Vulcan_v(Object[] objArr) {
        this.Vulcan_Y = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X3(Object[] objArr) {
        this.Vulcan_B = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xf(Object[] objArr) {
        this.Vulcan_LW = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public void m803Vulcan_A(Object[] objArr) {
        this.Vulcan_M = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public void m804Vulcan_Q(Object[] objArr) {
        this.Vulcan_t8 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X2(Object[] objArr) {
        this.Vulcan_La = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xj(Object[] objArr) {
        this.Vulcan_tZ = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public void m805Vulcan_r(Object[] objArr) {
        this.Vulcan_L_ = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public void m806Vulcan_M(Object[] objArr) {
        this.Vulcan_ta = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XD(Object[] objArr) {
        this.Vulcan_t5 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XG(Object[] objArr) {
        this.Vulcan_t = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XY(Object[] objArr) {
        this.Vulcan_tT = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X1(Object[] objArr) {
        this.Vulcan_LR = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public void m807Vulcan_s(Object[] objArr) {
        this.Vulcan_LH = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XA(Object[] objArr) {
        this.Vulcan_tH = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xt(Object[] objArr) {
        this.Vulcan_tC = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public void m808Vulcan_P(Object[] objArr) {
        this.Vulcan_LV = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XH(Object[] objArr) {
        this.Vulcan_tE = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XO(Object[] objArr) {
        this.Vulcan_LG = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X8(Object[] objArr) {
        this.Vulcan_tq = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public void m809Vulcan_R(Object[] objArr) {
        this.Vulcan_X = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xz(Object[] objArr) {
        this.Vulcan_W = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xk(Object[] objArr) {
        this.Vulcan_e = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X_(Object[] objArr) {
        this.Vulcan_tg = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xv(Object[] objArr) {
        this.Vulcan_E = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X0(Object[] objArr) {
        this.Vulcan_Lo = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XJ(Object[] objArr) {
        this.Vulcan_LT = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X7(Object[] objArr) {
        this.Vulcan_g = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public void m810Vulcan_H(Object[] objArr) {
        this.Vulcan_Q = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public void m811Vulcan_X(Object[] objArr) {
        this.Vulcan_Lc = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public void m812Vulcan_S(Object[] objArr) {
        this.Vulcan_LE = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public void m813Vulcan_x(Object[] objArr) {
        this.Vulcan_td = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xn(Object[] objArr) {
        this.Vulcan_x = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public void m814Vulcan_p(Object[] objArr) {
        this.Vulcan_th = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X4(Object[] objArr) {
        this.Vulcan_tP = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xy(Object[] objArr) {
        this.Vulcan_t_ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XR(Object[] objArr) {
        this.Vulcan_O = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xs(Object[] objArr) {
        this.Vulcan_tQ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X6(Object[] objArr) {
        this.Vulcan_L9 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xb(Object[] objArr) {
        this.Vulcan_z = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xq(Object[] objArr) {
        this.Vulcan_tO = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XI(Object[] objArr) {
        this.Vulcan_LN = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XV(Object[] objArr) {
        this.Vulcan_Le = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public void m815Vulcan_J(Object[] objArr) {
        this.Vulcan_tD = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XC(Object[] objArr) {
        this.Vulcan_tF = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XZ(Object[] objArr) {
        this.Vulcan_a = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_XP(Object[] objArr) {
        this.Vulcan_to = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xx(Object[] objArr) {
        this.Vulcan_R = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public void m816Vulcan_m(Object[] objArr) {
        this.Vulcan_Ls = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xe(Object[] objArr) {
        this.Vulcan_tv = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Xu(Object[] objArr) {
        this.Vulcan_L8 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_ET(Object[] objArr) {
        this.Vulcan_u = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public void m817Vulcan_e(Object[] objArr) {
        this.Vulcan_Z = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EG(Object[] objArr) {
        this.Vulcan_tj = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ee(Object[] objArr) {
        this.Vulcan_LL = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EK(Object[] objArr) {
        this.Vulcan_i = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EW(Object[] objArr) {
        this.Vulcan_tl = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_En(Object[] objArr) {
        this.Vulcan_LO = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Eh(Object[] objArr) {
        this.Vulcan_Ln = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ex(Object[] objArr) {
        this.Vulcan_C = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public void m818Vulcan_N(Object[] objArr) {
        this.Vulcan_Lj = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ej(Object[] objArr) {
        this.Vulcan_J = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_EI(Object[] objArr) {
        this.Vulcan_f = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ek(Object[] objArr) {
        this.Vulcan_v = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Eu(Object[] objArr) {
        this.Vulcan_tb = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Rk(Object[] objArr) {
        this.Vulcan_o = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_Ra(Object[] objArr) {
        this.Vulcan_I = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_Rd(Object[] objArr) {
        this.Vulcan_tp = ((Long) objArr[0]).longValue();
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public void m819Vulcan_F(Object[] objArr) {
        this.Vulcan_H = (GameMode) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public void m820Vulcan_n(Object[] objArr) {
        this.Vulcan_b = (ItemStack) objArr[0];
    }

    public void Vulcan_ng(Object[] objArr) {
        this.Vulcan_tL = (ItemStack) objArr[0];
    }

    public void Vulcan_ne(Object[] objArr) {
        this.Vulcan_tz = (ItemStack) objArr[0];
    }

    public void Vulcan_nX(Object[] objArr) {
        this.Vulcan_tJ = (ItemStack) objArr[0];
    }

    public void Vulcan_nS(Object[] objArr) {
        this.Vulcan_tU = (ItemStack) objArr[0];
    }

    public void Vulcan_nT(Object[] objArr) {
        this.Vulcan_tK = (ItemStack) objArr[0];
    }

    public void Vulcan_RE(Object[] objArr) {
        this.Vulcan_tc = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_RB(Object[] objArr) {
        this.Vulcan_m = ((Long) objArr[0]).longValue();
    }

    public C0042Vulcan_Oz Vulcan_p(Object[] objArr) {
        return this.Vulcan_L3;
    }

    public boolean Vulcan_b(Object[] objArr) {
        return this.Vulcan_tf;
    }

    public boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_tM;
    }

    public boolean Vulcan_Q(Object[] objArr) {
        return this.Vulcan_y;
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public boolean m695Vulcan_q(Object[] objArr) {
        return this.Vulcan_w;
    }

    public boolean Vulcan_R(Object[] objArr) {
        return this.Vulcan_n;
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public boolean m696Vulcan_Y(Object[] objArr) {
        return this.Vulcan_t9;
    }

    public boolean Vulcan_o(Object[] objArr) {
        return this.Vulcan_t6;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public boolean m697Vulcan_c(Object[] objArr) {
        return this.Vulcan_ti;
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public boolean m698Vulcan_j(Object[] objArr) {
        return this.Vulcan_LC;
    }

    public boolean Vulcan_X(Object[] objArr) {
        return this.Vulcan_F;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public boolean m699Vulcan_h(Object[] objArr) {
        return this.Vulcan_LF;
    }

    public boolean Vulcan_I(Object[] objArr) {
        return this.Vulcan_Lz;
    }

    public boolean Vulcan_N(Object[] objArr) {
        return this.Vulcan_tu;
    }

    public boolean Vulcan_v(Object[] objArr) {
        return this.Vulcan_D;
    }

    public boolean Vulcan_y(Object[] objArr) {
        return this.Vulcan_L0;
    }

    public boolean Vulcan_S(Object[] objArr) {
        return this.Vulcan__;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public boolean m700Vulcan_C(Object[] objArr) {
        return this.Vulcan_LD;
    }

    public boolean Vulcan_m(Object[] objArr) {
        return this.Vulcan_tn;
    }

    public boolean Vulcan_g(Object[] objArr) {
        return this.Vulcan_U;
    }

    public boolean Vulcan_i(Object[] objArr) {
        return this.Vulcan_t2;
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public boolean m701Vulcan_W(Object[] objArr) {
        return this.Vulcan_Lh;
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public boolean m702Vulcan_p(Object[] objArr) {
        return this.Vulcan_L4;
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public boolean m703Vulcan_V(Object[] objArr) {
        return this.Vulcan_tX;
    }

    public boolean Vulcan_Z(Object[] objArr) {
        return this.Vulcan_tA;
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public boolean m704Vulcan_w(Object[] objArr) {
        return this.Vulcan_p;
    }

    public boolean Vulcan_E(Object[] objArr) {
        return this.Vulcan_r;
    }

    public boolean Vulcan_A(Object[] objArr) {
        return this.Vulcan_h;
    }

    public boolean Vulcan_O(Object[] objArr) {
        return this.Vulcan_tm;
    }

    public boolean Vulcan_J(Object[] objArr) {
        return this.Vulcan_tw;
    }

    public boolean Vulcan_r(Object[] objArr) {
        return this.Vulcan_Lb;
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public boolean m705Vulcan_f(Object[] objArr) {
        return this.Vulcan_LA;
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public boolean m706Vulcan_l(Object[] objArr) {
        return this.Vulcan_s;
    }

    public boolean Vulcan_L(Object[] objArr) {
        return this.Vulcan_tG;
    }

    public boolean Vulcan_t(Object[] objArr) {
        return this.Vulcan_LI;
    }

    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_G;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public boolean m707Vulcan_u(Object[] objArr) {
        return this.Vulcan_Ld;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public double m708Vulcan_C(Object[] objArr) {
        return this.Vulcan_K;
    }

    public double Vulcan_P(Object[] objArr) {
        return this.Vulcan_V;
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public double m709Vulcan_W(Object[] objArr) {
        return this.Vulcan_Lq;
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public double m710Vulcan_l(Object[] objArr) {
        return this.Vulcan_ts;
    }

    public double Vulcan_U(Object[] objArr) {
        return this.Vulcan_tY;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public double m711Vulcan_H(Object[] objArr) {
        return this.Vulcan_tt;
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public double m712Vulcan_b(Object[] objArr) {
        return this.Vulcan_LJ;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public LinkedList m713Vulcan_Q(Object[] objArr) {
        return this.Vulcan_tx;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public void m821Vulcan_t(Object[] objArr) {
        this.Vulcan_Lk = ((Boolean) objArr[0]).booleanValue();
    }

    public boolean Vulcan_d(Object[] objArr) {
        return this.Vulcan_Lk;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public int m714Vulcan_H(Object[] objArr) {
        return this.Vulcan_L;
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public int m715Vulcan_E(Object[] objArr) {
        return this.Vulcan_tV;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public int m716Vulcan_L(Object[] objArr) {
        return this.Vulcan_j;
    }

    public int Vulcan_sR(Object[] objArr) {
        return this.Vulcan_tk;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public int m717Vulcan_N(Object[] objArr) {
        return this.Vulcan_l;
    }

    public int Vulcan_sY(Object[] objArr) {
        return this.Vulcan_S;
    }

    public int Vulcan_sO(Object[] objArr) {
        return this.Vulcan_Lw;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public int m718Vulcan_h(Object[] objArr) {
        return this.Vulcan_LZ;
    }

    public int Vulcan_st(Object[] objArr) {
        return this.Vulcan_LP;
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public int m719Vulcan_Z(Object[] objArr) {
        return this.Vulcan_d;
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public int m720Vulcan_K(Object[] objArr) {
        return this.Vulcan_te;
    }

    public int Vulcan_s6(Object[] objArr) {
        return this.Vulcan_tR;
    }

    public int Vulcan_sw(Object[] objArr) {
        return this.Vulcan_t4;
    }

    public int Vulcan_sB(Object[] objArr) {
        return this.Vulcan_T;
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public int m721Vulcan_Y(Object[] objArr) {
        return this.Vulcan_tI;
    }

    public int Vulcan_s0(Object[] objArr) {
        return this.Vulcan_t7;
    }

    public int Vulcan_sc(Object[] objArr) {
        return this.Vulcan_Li;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public int m722Vulcan_t(Object[] objArr) {
        return this.Vulcan_q;
    }

    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public int m723Vulcan_d(Object[] objArr) {
        return this.Vulcan_tN;
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public int m724Vulcan_g(Object[] objArr) {
        return this.Vulcan_ty;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public int m725Vulcan_Q(Object[] objArr) {
        return this.Vulcan_N;
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public int m726Vulcan_m(Object[] objArr) {
        return this.Vulcan_LX;
    }

    public int Vulcan_sH(Object[] objArr) {
        return this.Vulcan_t3;
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public int m727Vulcan_p(Object[] objArr) {
        return this.Vulcan_tW;
    }

    public int Vulcan_sb(Object[] objArr) {
        return this.Vulcan_tB;
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public int m728Vulcan_s(Object[] objArr) {
        return this.Vulcan_Lf;
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public int m729Vulcan_w(Object[] objArr) {
        return this.Vulcan_c;
    }

    public int Vulcan_sr(Object[] objArr) {
        return this.Vulcan_LM;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public int m730Vulcan_O(Object[] objArr) {
        return this.Vulcan_L5;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public int m731Vulcan_D(Object[] objArr) {
        return this.Vulcan_k;
    }

    public int Vulcan_F(Object[] objArr) {
        return this.Vulcan_t1;
    }

    public int Vulcan_T(Object[] objArr) {
        return this.Vulcan_P;
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public int m732Vulcan_W(Object[] objArr) {
        return this.Vulcan_tS;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public int m733Vulcan_c(Object[] objArr) {
        return this.Vulcan_LY;
    }

    public int Vulcan_z(Object[] objArr) {
        return this.Vulcan_tr;
    }

    public int Vulcan_a(Object[] objArr) {
        return this.Vulcan_Y;
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public int m734Vulcan_q(Object[] objArr) {
        return this.Vulcan_B;
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public int m735Vulcan_y(Object[] objArr) {
        return this.Vulcan_LW;
    }

    public int Vulcan_sM(Object[] objArr) {
        return this.Vulcan_M;
    }

    public int Vulcan_s3(Object[] objArr) {
        return this.Vulcan_t8;
    }

    public int Vulcan_sU(Object[] objArr) {
        return this.Vulcan_La;
    }

    public int Vulcan_sd(Object[] objArr) {
        return this.Vulcan_tZ;
    }

    public int Vulcan_sA(Object[] objArr) {
        return this.Vulcan_L_;
    }

    public int Vulcan_k(Object[] objArr) {
        return this.Vulcan_ta;
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public int m736Vulcan_P(Object[] objArr) {
        return this.Vulcan_t5;
    }

    public int Vulcan_s2(Object[] objArr) {
        return this.Vulcan_t;
    }

    public int Vulcan_G(Object[] objArr) {
        return this.Vulcan_tT;
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public int m737Vulcan_f(Object[] objArr) {
        return this.Vulcan_LR;
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public int m738Vulcan_v(Object[] objArr) {
        return this.Vulcan_LH;
    }

    public int Vulcan_sV(Object[] objArr) {
        return this.Vulcan_tH;
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public int m739Vulcan_b(Object[] objArr) {
        return this.Vulcan_tC;
    }

    public int Vulcan_sx(Object[] objArr) {
        return this.Vulcan_LV;
    }

    public int Vulcan_sp(Object[] objArr) {
        return this.Vulcan_tE;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public int m740Vulcan_u(Object[] objArr) {
        return this.Vulcan_LG;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public int m741Vulcan_M(Object[] objArr) {
        return this.Vulcan_tq;
    }

    public int Vulcan_x(Object[] objArr) {
        return this.Vulcan_X;
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public int m742Vulcan_U(Object[] objArr) {
        return this.Vulcan_W;
    }

    public int Vulcan__(Object[] objArr) {
        return this.Vulcan_e;
    }

    public int Vulcan_e(Object[] objArr) {
        return this.Vulcan_tg;
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public int m743Vulcan_l(Object[] objArr) {
        return this.Vulcan_E;
    }

    public int Vulcan_sC(Object[] objArr) {
        return this.Vulcan_Lo;
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public int m744Vulcan_B(Object[] objArr) {
        return this.Vulcan_LT;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public int m745Vulcan_R(Object[] objArr) {
        return this.Vulcan_g;
    }

    public int Vulcan_sg(Object[] objArr) {
        return this.Vulcan_Q;
    }

    public int Vulcan_sW(Object[] objArr) {
        return this.Vulcan_Lc;
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public int m746Vulcan_S(Object[] objArr) {
        return this.Vulcan_LE;
    }

    public int Vulcan_sf(Object[] objArr) {
        return this.Vulcan_td;
    }

    public int Vulcan_sT(Object[] objArr) {
        return this.Vulcan_x;
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public int m747Vulcan_X(Object[] objArr) {
        return this.Vulcan_th;
    }

    public int Vulcan_sG(Object[] objArr) {
        return this.Vulcan_tP;
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public int m748Vulcan_i(Object[] objArr) {
        return this.Vulcan_t_;
    }

    public int Vulcan_sj(Object[] objArr) {
        return this.Vulcan_O;
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public int m749Vulcan_j(Object[] objArr) {
        return this.Vulcan_tQ;
    }

    public int Vulcan_se(Object[] objArr) {
        return this.Vulcan_L9;
    }

    public int Vulcan_sD(Object[] objArr) {
        return this.Vulcan_z;
    }

    public int Vulcan_sN(Object[] objArr) {
        return this.Vulcan_tO;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public int m750Vulcan_r(Object[] objArr) {
        return this.Vulcan_LN;
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public int m751Vulcan_V(Object[] objArr) {
        return this.Vulcan_Le;
    }

    public int Vulcan_s7(Object[] objArr) {
        return this.Vulcan_tD;
    }

    public int Vulcan_sa(Object[] objArr) {
        return this.Vulcan_tF;
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public int m752Vulcan_o(Object[] objArr) {
        return this.Vulcan_a;
    }

    public int Vulcan_n(Object[] objArr) {
        return this.Vulcan_to;
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public int m753Vulcan_A(Object[] objArr) {
        return this.Vulcan_R;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public int m754Vulcan_I(Object[] objArr) {
        return this.Vulcan_Ls;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public int m755Vulcan_C(Object[] objArr) {
        return this.Vulcan_tv;
    }

    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public int m756Vulcan_J(Object[] objArr) {
        return this.Vulcan_L8;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public double m757Vulcan_N(Object[] objArr) {
        return this.Vulcan_u;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public double m758Vulcan_D(Object[] objArr) {
        return this.Vulcan_Z;
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public double m759Vulcan_q(Object[] objArr) {
        return this.Vulcan_tj;
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public double m760Vulcan_G(Object[] objArr) {
        return this.Vulcan_LL;
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public double m761Vulcan_m(Object[] objArr) {
        return this.Vulcan_i;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public double m762Vulcan_n(Object[] objArr) {
        return this.Vulcan_tl;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public double m763Vulcan_c(Object[] objArr) {
        return this.Vulcan_LO;
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public double m764Vulcan_z(Object[] objArr) {
        return this.Vulcan_Ln;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public double m765Vulcan_T(Object[] objArr) {
        return this.Vulcan_C;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public double m766Vulcan_M(Object[] objArr) {
        return this.Vulcan_Lj;
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public double m767Vulcan_a(Object[] objArr) {
        return this.Vulcan_J;
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public double m768Vulcan_s(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public double m769Vulcan_E(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public double m770Vulcan_B(Object[] objArr) {
        return this.Vulcan_tb;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public long m771Vulcan_I(Object[] objArr) {
        return this.Vulcan_o;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public long m772Vulcan_D(Object[] objArr) {
        return this.Vulcan_I;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public long m773Vulcan_n(Object[] objArr) {
        return this.Vulcan_tp;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public GameMode m774Vulcan_H(Object[] objArr) {
        return this.Vulcan_H;
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public ItemStack m775Vulcan_v(Object[] objArr) {
        return this.Vulcan_b;
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public ItemStack m776Vulcan_w(Object[] objArr) {
        return this.Vulcan_tL;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public ItemStack m777Vulcan_t(Object[] objArr) {
        return this.Vulcan_tz;
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public ItemStack m778Vulcan_Z(Object[] objArr) {
        return this.Vulcan_tJ;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public ItemStack m779Vulcan_N(Object[] objArr) {
        return this.Vulcan_tU;
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public ItemStack m780Vulcan_a(Object[] objArr) {
        return this.Vulcan_tK;
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public long m781Vulcan_U(Object[] objArr) {
        return this.Vulcan_tc;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public long m782Vulcan_Q(Object[] objArr) {
        return this.Vulcan_m;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public C0036Vulcan_Oj m783Vulcan_L(Object[] objArr) {
        return this.Vulcan_A;
    }

    public C0047Vulcan_fi(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_L3 = c0042Vulcan_Oz;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:63:0x012a
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_i0(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 441
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_i0(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_c(Object[] objArr) {
        WrapperPlayServerUpdateAttributes wrapperPlayServerUpdateAttributes = (WrapperPlayServerUpdateAttributes) objArr[0];
        long jLongValue = (a ^ ((Long) objArr[1]).longValue()) ^ 105010154421286L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleUpdateAttributes$0(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(jLongValue);
        r3.Vulcan_o(r3);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:41:0x00f3
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void lambda$handleUpdateAttributes$0(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes r9) {
        /*
            Method dump skipped, instruction units count: 439
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.lambda$handleUpdateAttributes$0(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity$InteractAction] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    public void Vulcan_PG(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayClientInteractEntity wrapperPlayClientInteractEntity = (WrapperPlayClientInteractEntity) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        if (Vulcan_T != 0) {
            try {
                try {
                    Vulcan_T = wrapperPlayClientInteractEntity.getAction();
                    if (Vulcan_T == WrapperPlayClientInteractEntity.InteractAction.ATTACK) {
                        this.Vulcan_n = false;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) Vulcan_T);
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) Vulcan_T);
            }
        }
        this.Vulcan_tj = 1000.0d;
    }

    public void Vulcan_D0(Object[] objArr) {
        this.Vulcan_T = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_Df(Object[] objArr) {
        this.Vulcan_L = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x007b  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:43:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_Uw(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 268
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_Uw(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00d8  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v47, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_zn(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 327
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_zn(java.lang.Object[]):void");
    }

    public void Vulcan_Dq(Object[] objArr) {
        this.Vulcan_tI = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    public void Vulcan_V(Object[] objArr) {
        WrapperPlayClientClientStatus wrapperPlayClientClientStatus = (WrapperPlayClientClientStatus) objArr[0];
        ?? LongValue = a ^ ((Long) objArr[1]).longValue();
        try {
            if (wrapperPlayClientClientStatus.getAction() == WrapperPlayClientClientStatus.Action.PERFORM_RESPAWN) {
                LongValue = this;
                LongValue.Vulcan_ty = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) LongValue);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00a7 A[Catch: RuntimeException -> 0x00b9, RuntimeException -> 0x00e2, TRY_ENTER, TryCatch #6 {RuntimeException -> 0x00b9, blocks: (B:29:0x008c, B:31:0x00a7), top: B:52:0x008c, outer: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00e6 A[Catch: RuntimeException -> 0x00ed, TRY_LEAVE, TryCatch #3 {RuntimeException -> 0x00ed, blocks: (B:37:0x00bd, B:42:0x00e6, B:40:0x00e2, B:41:0x00e5, B:31:0x00a7, B:35:0x00b9, B:36:0x00bc, B:29:0x008c), top: B:52:0x008c, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x008c A[EXC_TOP_SPLITTER, PHI: r0
  0x008c: PHI (r0v13 ??) = (r0v57 ??), (r0v58 ??), (r0v59 ??) binds: [B:14:0x005c, B:16:0x0061, B:26:0x0082] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v13, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v35, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v45, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v49, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$ArrayArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_DV(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 265
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_DV(java.lang.Object[]):void");
    }

    public void Vulcan_h(Object[] objArr) {
        this.Vulcan_S = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0079 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:59:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [double] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v24, types: [double] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v30, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v31, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v35, types: [int] */
    /* JADX WARN: Type inference failed for: r0v39, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r14v0, types: [double] */
    /* JADX WARN: Type inference failed for: r1v18, types: [double] */
    /* JADX WARN: Type inference failed for: r3v3, types: [double, java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_Dr(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 269
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_Dr(java.lang.Object[]):void");
    }

    public void Vulcan_Dv(Object[] objArr) {
        this.Vulcan_LY = 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v13, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    public void Vulcan_C(Object[] objArr) {
        int amount;
        int heldItemSlot;
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            try {
                Vulcan_T = this;
                Player playerVulcan_e = this.Vulcan_L3.Vulcan_e(new Object[0]);
                if (Vulcan_T == 0) {
                    amount = playerVulcan_e.getItemInHand().getAmount();
                } else if (playerVulcan_e == null) {
                    amount = 0;
                } else {
                    playerVulcan_e = this.Vulcan_L3.Vulcan_e(new Object[0]);
                    amount = playerVulcan_e.getItemInHand().getAmount();
                }
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_T);
            }
        } catch (RuntimeException unused2) {
            Vulcan_T = a((RuntimeException) Vulcan_T);
            throw Vulcan_T;
        }
        try {
            try {
                Vulcan_T.Vulcan_Lw = amount;
                Vulcan_T = this;
                Player playerVulcan_e2 = this.Vulcan_L3.Vulcan_e(new Object[0]);
                if (Vulcan_T == 0) {
                    heldItemSlot = playerVulcan_e2.getInventory().getHeldItemSlot();
                } else if (playerVulcan_e2 == null) {
                    heldItemSlot = 0;
                } else {
                    playerVulcan_e2 = this.Vulcan_L3.Vulcan_e(new Object[0]);
                    heldItemSlot = playerVulcan_e2.getInventory().getHeldItemSlot();
                }
                try {
                    try {
                        try {
                            try {
                                Vulcan_T.Vulcan_LP = heldItemSlot;
                                C0047Vulcan_fi c0047Vulcan_fi = this;
                                if (Vulcan_T != 0) {
                                    Vulcan_T = c0047Vulcan_fi.Vulcan_Lw;
                                    if (Vulcan_T != this.Vulcan_LZ) {
                                        c0047Vulcan_fi = this;
                                        c0047Vulcan_fi.Vulcan_d = this.Vulcan_LP;
                                        c0047Vulcan_fi = this;
                                    } else {
                                        if (jLongValue < 0) {
                                            return;
                                        }
                                        c0047Vulcan_fi = this;
                                        if (Vulcan_T != 0) {
                                            if (jLongValue >= 0) {
                                                if (c0047Vulcan_fi.Vulcan_LP == this.Vulcan_d) {
                                                    this.Vulcan_B = 0;
                                                }
                                                c0047Vulcan_fi = this;
                                            }
                                            c0047Vulcan_fi.Vulcan_d = this.Vulcan_LP;
                                            c0047Vulcan_fi = this;
                                        }
                                    }
                                }
                                c0047Vulcan_fi.Vulcan_LZ = this.Vulcan_Lw;
                            } catch (RuntimeException unused3) {
                                throw a((RuntimeException) Vulcan_T);
                            }
                        } catch (RuntimeException unused4) {
                            throw a((RuntimeException) Vulcan_T);
                        }
                    } catch (RuntimeException unused5) {
                        throw a((RuntimeException) Vulcan_T);
                    }
                } catch (RuntimeException unused6) {
                    throw a((RuntimeException) Vulcan_T);
                }
            } catch (RuntimeException unused7) {
                Vulcan_T = a((RuntimeException) Vulcan_T);
                throw Vulcan_T;
            }
        } catch (RuntimeException unused8) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v15, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    public void Vulcan_tC(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        long jLongValue = ((Long) objArr[2]).longValue();
        double dDoubleValue3 = ((Double) objArr[3]).doubleValue();
        long j = a ^ jLongValue;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            Vulcan_T = this;
            ?? r0 = Vulcan_T;
            if (Vulcan_T != 0) {
                try {
                    Vulcan_T = Vulcan_T.Vulcan_n;
                    if (Vulcan_T != 0) {
                        this.Vulcan_n = false;
                    }
                    this.Vulcan_LT = 0;
                    this.Vulcan_LL = dDoubleValue;
                    this.Vulcan_i = dDoubleValue2;
                    r0 = this;
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) Vulcan_T);
                }
            }
            r0.Vulcan_tl = dDoubleValue3;
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    public void Vulcan_u(Object[] objArr) {
        this.Vulcan_t8 = 0;
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_l(Object[] objArr) {
        WrapperPlayServerPlayerPositionAndLook wrapperPlayServerPlayerPositionAndLook = (WrapperPlayServerPlayerPositionAndLook) objArr[0];
        PacketSendEvent packetSendEvent = (PacketSendEvent) objArr[1];
        long jLongValue = (a ^ ((Long) objArr[2]).longValue()) ^ 78470059911216L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleServerPosition$1(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(jLongValue);
        r3.Vulcan_o(r3);
        Vulcan_K vulcan_KM640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        LinkedList linkedList = this.Vulcan_tx;
        linkedList.getClass();
        vulcan_KM640Vulcan_O.Vulcan_h(new Object[]{linkedList::poll});
        packetSendEvent.getTasksAfterSend().add(this::lambda$handleServerPosition$2);
    }

    private void lambda$handleServerPosition$1(WrapperPlayServerPlayerPositionAndLook wrapperPlayServerPlayerPositionAndLook) {
        this.Vulcan_tx.add(new Vector(wrapperPlayServerPlayerPositionAndLook.getX(), wrapperPlayServerPlayerPositionAndLook.getY(), wrapperPlayServerPlayerPositionAndLook.getZ()));
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    private void lambda$handleServerPosition$2() {
        long j = (a ^ 119594112283396L) ^ 129915143938448L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = false;
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_L(r3);
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_kR(Object[] objArr) {
        WrapperPlayServerEntityEffect wrapperPlayServerEntityEffect = (WrapperPlayServerEntityEffect) objArr[0];
        long jLongValue = (a ^ ((Long) objArr[1]).longValue()) ^ 139745271306255L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleEntityEffect$3(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(jLongValue);
        r3.Vulcan_o(r3);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:57:0x00f1
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void lambda$handleEntityEffect$3(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEffect r6) {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.lambda$handleEntityEffect$3(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEffect):void");
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_Yp(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayServerRemoveEntityEffect wrapperPlayServerRemoveEntityEffect = (WrapperPlayServerRemoveEntityEffect) objArr[1];
        long j = (a ^ jLongValue) ^ 2186221044857L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleRemoveEntityEffect$4(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_o(r3);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:57:0x00f8
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void lambda$handleRemoveEntityEffect$4(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRemoveEntityEffect r7) {
        /*
            Method dump skipped, instruction units count: 331
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.lambda$handleRemoveEntityEffect$4(com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRemoveEntityEffect):void");
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_q(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayServerChangeGameState wrapperPlayServerChangeGameState = (WrapperPlayServerChangeGameState) objArr[1];
        long j = (a ^ jLongValue) ^ 76448295526025L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleGameStateChange$5(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_o(r3);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v20, types: [com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState$Reason] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v28, types: [com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState$Reason] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31, types: [com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState] */
    /* JADX WARN: Type inference failed for: r0v32, types: [com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState$Reason] */
    /* JADX WARN: Type inference failed for: r0v33, types: [com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerChangeGameState] */
    /* JADX WARN: Type inference failed for: r0v35, types: [int] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private void lambda$handleGameStateChange$5(WrapperPlayServerChangeGameState wrapperPlayServerChangeGameState) {
        ?? r0;
        long j = a ^ 35710671231017L;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            try {
                try {
                    Vulcan_T = wrapperPlayServerChangeGameState.getReason();
                    WrapperPlayServerChangeGameState.Reason reason = WrapperPlayServerChangeGameState.Reason.CHANGE_GAME_MODE;
                    try {
                        try {
                            if (Vulcan_T != 0) {
                                if (Vulcan_T == reason) {
                                    Vulcan_T = wrapperPlayServerChangeGameState;
                                    r0 = Vulcan_T;
                                    if (Vulcan_T != 0) {
                                        try {
                                            Vulcan_T = (int) Vulcan_T.getValue();
                                            try {
                                                try {
                                                    switch (Vulcan_T) {
                                                        case 0:
                                                            this.Vulcan_H = GameMode.SURVIVAL;
                                                            if (Vulcan_T == 0) {
                                                                break;
                                                            }
                                                        case 1:
                                                            this.Vulcan_H = GameMode.CREATIVE;
                                                            if (Vulcan_T == 0) {
                                                                break;
                                                            }
                                                        case 2:
                                                            this.Vulcan_H = GameMode.ADVENTURE;
                                                            if (Vulcan_T == 0) {
                                                                break;
                                                            }
                                                        case 3:
                                                            if (Vulcan_OM.Vulcan_b(new Object[0])) {
                                                                this.Vulcan_H = GameMode.SPECTATOR;
                                                            }
                                                            break;
                                                    }
                                                    r0 = wrapperPlayServerChangeGameState;
                                                } catch (RuntimeException unused) {
                                                    throw a((RuntimeException) Vulcan_T);
                                                }
                                            } catch (RuntimeException unused2) {
                                                throw a((RuntimeException) Vulcan_T);
                                            }
                                        } catch (RuntimeException unused3) {
                                            throw a((RuntimeException) Vulcan_T);
                                        }
                                    }
                                    Vulcan_T = r0.getReason();
                                    reason = WrapperPlayServerChangeGameState.Reason.BEGIN_RAINING;
                                } else {
                                    r0 = wrapperPlayServerChangeGameState;
                                    Vulcan_T = r0.getReason();
                                    reason = WrapperPlayServerChangeGameState.Reason.BEGIN_RAINING;
                                }
                            }
                            try {
                                if (Vulcan_T != 0) {
                                    if (Vulcan_T == reason) {
                                        this.Vulcan_LA = true;
                                    }
                                    Vulcan_T = wrapperPlayServerChangeGameState.getReason();
                                    reason = WrapperPlayServerChangeGameState.Reason.END_RAINING;
                                }
                                if (Vulcan_T == reason) {
                                    try {
                                        Vulcan_T = this;
                                        Vulcan_T.Vulcan_LA = false;
                                    } catch (RuntimeException unused4) {
                                        throw a((RuntimeException) Vulcan_T);
                                    }
                                }
                            } catch (RuntimeException unused5) {
                                throw a((RuntimeException) Vulcan_T);
                            }
                        } catch (RuntimeException unused6) {
                            throw a((RuntimeException) Vulcan_T);
                        }
                    } catch (RuntimeException unused7) {
                        throw a((RuntimeException) Vulcan_T);
                    }
                } catch (RuntimeException unused8) {
                    throw a((RuntimeException) Vulcan_T);
                }
            } catch (RuntimeException unused9) {
                Vulcan_T = a((RuntimeException) Vulcan_T);
                throw Vulcan_T;
            }
        } catch (RuntimeException unused10) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    public void Vulcan_j(Object[] objArr) {
        this.Vulcan_LW = 0;
        this.Vulcan_L3.m639Vulcan_M(new Object[0]).Vulcan_US(new Object[]{0});
    }

    public void Vulcan_D(Object[] objArr) {
        this.Vulcan_La = 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x006d A[PHI: r0 r1
  0x006d: PHI (r0v8 ??) = (r0v52 ??), (r0v53 ??), (r0v47 ??) binds: [B:12:0x004f, B:14:0x0054, B:19:0x0061] A[DONT_GENERATE, DONT_INLINE]
  0x006d: PHI (r1v10 java.lang.RuntimeException) = (r1v9 java.lang.RuntimeException), (r1v9 java.lang.RuntimeException), (r1v23 java.lang.RuntimeException) binds: [B:12:0x004f, B:14:0x0054, B:19:0x0061] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00c6  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00d7  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0070 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:78:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:79:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:80:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:81:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:83:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:84:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_fi] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_pj(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 320
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0047Vulcan_fi.Vulcan_pj(java.lang.Object[]):void");
    }

    public void Vulcan_f(Object[] objArr) {
        this.Vulcan_e = 0;
    }

    public void Vulcan_DB(Object[] objArr) {
        this.Vulcan_tR = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_Di(Object[] objArr) {
        this.Vulcan_t4 = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_Dc(Object[] objArr) {
        this.Vulcan_Y = 0;
    }

    public void Vulcan_Dm(Object[] objArr) {
        this.Vulcan_B = 0;
    }

    public void Vulcan_Dn(Object[] objArr) {
        this.Vulcan_Lo = 0;
    }

    public void Vulcan_W(Object[] objArr) {
        this.Vulcan_tr = 0;
    }

    public void Vulcan_Y(Object[] objArr) {
        this.Vulcan_W = 0;
    }

    public void Vulcan_DF(Object[] objArr) {
        this.Vulcan_LX = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_B(Object[] objArr) {
        this.Vulcan_t3 = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_WZ(Object[] objArr) {
        this.Vulcan_Lc = 0;
    }

    public void Vulcan_K(Object[] objArr) {
        this.Vulcan_M = 0;
    }

    public void Vulcan_n4(Object[] objArr) {
        BlockPlaceEvent blockPlaceEvent = (BlockPlaceEvent) objArr[0];
        this.Vulcan_ta = blockPlaceEvent.getBlockPlaced().getX();
        this.Vulcan_t5 = blockPlaceEvent.getBlockPlaced().getY();
        this.Vulcan_t = blockPlaceEvent.getBlockPlaced().getZ();
    }

    public void Vulcan_D8(Object[] objArr) {
        this.Vulcan_X = 0;
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_w(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayServerEntityMetadata wrapperPlayServerEntityMetadata = (WrapperPlayServerEntityMetadata) objArr[1];
        long j = (a ^ jLongValue) ^ 30974505608590L;
        ?? M640Vulcan_O = this.Vulcan_L3.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleMetaData$6(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_o(r3);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [com.github.retrooper.packetevents.protocol.entity.data.EntityData] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    public static EntityData Vulcan_M(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        List<EntityData> list = (List) objArr[1];
        int iIntValue = ((Integer) objArr[2]).intValue();
        long j = a ^ jLongValue;
        String[] strArrVulcan_T = Vulcan_ka.Vulcan_T();
        for (EntityData entityData : list) {
            ?? A = entityData;
            if (strArrVulcan_T == null) {
                return A;
            }
            try {
                try {
                    A = A.getIndex();
                    if (A == iIntValue) {
                        return entityData;
                    }
                    if (strArrVulcan_T == null) {
                        return null;
                    }
                } catch (RuntimeException unused) {
                    A = a((RuntimeException) A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) A);
            }
        }
        return null;
    }
}
