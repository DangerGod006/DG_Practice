package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Og.class */
class Vulcan_Og {
    private String Vulcan_Y;
    final Vulcan_kZ Vulcan_V;

    static String Vulcan_D(Object[] objArr) {
        return ((Vulcan_Og) objArr[0]).Vulcan_m(new Object[0]);
    }

    Vulcan_Og(Vulcan_kZ vulcan_kZ, String str, Vulcan_fs vulcan_fs) {
        this(vulcan_kZ, str);
    }

    private Vulcan_Og(Vulcan_kZ vulcan_kZ, String str) {
        this.Vulcan_V = vulcan_kZ;
        this.Vulcan_Y = str;
    }

    private String Vulcan_m(Object[] objArr) {
        return this.Vulcan_Y;
    }
}
