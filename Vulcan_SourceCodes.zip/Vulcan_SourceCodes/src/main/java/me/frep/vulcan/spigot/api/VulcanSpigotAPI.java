package me.frep.vulcan.spigot.api;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import me.frep.vulcan.api.VulcanAPI;
import me.frep.vulcan.api.check.Check;
import me.frep.vulcan.api.data.IPlayerData;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.C0044Vulcan_fb;
import me.frep.vulcan.spigot.C0049Vulcan_j;
import me.frep.vulcan.spigot.Vulcan_OB;
import me.frep.vulcan.spigot.Vulcan_OM;
import me.frep.vulcan.spigot.Vulcan_fe;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.Vulcan_r;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.manager.CheckManager;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/api/VulcanSpigotAPI.class */
public class VulcanSpigotAPI implements VulcanAPI {
    private static final long a = Vulcan_n.a(-1833779209160150958L, -4249213018621190822L, MethodHandles.lookup().lookupClass()).a(179571618280209L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0015: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.api.VulcanAPI
    public double getTps() {
        /*
            r7 = this;
            long r0 = me.frep.vulcan.spigot.api.VulcanSpigotAPI.a
            r1 = 55230629891179(0x323b62134c6b, double:2.7287556827404E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 80420328239424(0x49245118f140, double:3.9732921410376E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r0 = r10
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            double r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.api.VulcanSpigotAPI.getTps():double");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public IPlayerData getPlayerData(Player player) {
        return Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getPing(Player player) {
        return C0044Vulcan_fb.Vulcan_x(new Object[]{player});
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public void executeBanWave() {
        C0049Vulcan_j.Vulcan_N(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public boolean isFrozen(Player player) {
        return ((C0042Vulcan_Oz) getPlayerData(player)).m639Vulcan_M(new Object[0]).Vulcan_O(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public double getKurtosis(Player player) {
        return ((C0042Vulcan_Oz) getPlayerData(player)).m638Vulcan_O(new Object[0]).Vulcan_h(new Object[0]);
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.api.VulcanAPI
    public void setFrozen(Player player, boolean z) {
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) getPlayerData(player);
        if (c0042Vulcan_Oz == null) {
            return;
        }
        c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m1049Vulcan_M(new Object[]{Boolean.valueOf(z)});
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getSensitivity(Player player) {
        return ((C0042Vulcan_Oz) getPlayerData(player)).Vulcan_z(new Object[0]).m1062Vulcan_n(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public double getCps(Player player) {
        return ((C0042Vulcan_Oz) getPlayerData(player)).m638Vulcan_O(new Object[0]).Vulcan_x(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getTransactionPing(Player player) {
        return (int) ((C0042Vulcan_Oz) getPlayerData(player)).m640Vulcan_O(new Object[0]).Vulcan_m(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getTotalViolations(Player player) {
        return getPlayerData(player).getTotalViolations();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getCombatViolations(Player player) {
        return getPlayerData(player).getCombatViolations();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getMovementViolations(Player player) {
        return getPlayerData(player).getMovementViolations();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getPlayerViolations(Player player) {
        return getPlayerData(player).getPlayerViolations();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getTicks() {
        return Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public int getJoinTicks(Player player) {
        return getPlayerData(player).getJoinTicks();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public String getVulcanVersion() {
        return Vulcan_r.INSTANCE.m1084Vulcan_j().getDescription().getVersion();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [me.frep.vulcan.api.check.Check, me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.api.VulcanAPI
    public Check getCheck(Player player, String str, char c) {
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
        if (c0042Vulcan_OzVulcan_L == null) {
            return null;
        }
        for (?? A : c0042Vulcan_OzVulcan_L.m635Vulcan_B(new Object[0])) {
            try {
                A = A.getName().equals(str);
                if (A != 0) {
                    try {
                        if (Character.toString(A.getType()).equals(Character.toString(c))) {
                            return A;
                        }
                    } catch (RuntimeException unused) {
                        throw a(A);
                    }
                }
            } catch (RuntimeException unused2) {
                A = a(A);
                throw A;
            }
        }
        return null;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getCheckData() {
        return Vulcan_fe.Vulcan_vu;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public boolean hasAlertsEnabled(Player player) {
        return Vulcan_r.INSTANCE.Vulcan_e().Vulcan_X(new Object[0]).contains(player);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Object, java.lang.reflect.Constructor] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    @Override // me.frep.vulcan.api.VulcanAPI
    public boolean isCheckEnabled(String str) {
        for (?? EqualsIgnoreCase : CheckManager.Vulcan_C) {
            try {
                EqualsIgnoreCase = EqualsIgnoreCase.getClass().getSimpleName().equalsIgnoreCase(str);
                if (EqualsIgnoreCase != 0) {
                    return true;
                }
            } catch (RuntimeException unused) {
                throw a(EqualsIgnoreCase);
            }
        }
        return false;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public String getServerVersion() {
        return Vulcan_OM.Vulcan_G(new Object[0]).toString();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Set getChecks() {
        return Vulcan_fe.Vulcan_T.keySet();
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getEnabledChecks() {
        return Vulcan_fe.Vulcan_T;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getMaxViolations() {
        return Vulcan_fe.Vulcan_vH;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getAlertIntervals() {
        return Vulcan_fe.Vulcan_b7;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getMinimumViolationsToNotify() {
        return Vulcan_fe.Vulcan_MI;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getPunishmentCommands() {
        return Vulcan_fe.Vulcan_t3;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getPunishableChecks() {
        return Vulcan_fe.Vulcan_D;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getBroadcastPunishments() {
        return Vulcan_fe.Vulcan_MW;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getMaximumPings() {
        return Vulcan_fe.Vulcan_P;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getMinimumTps() {
        return Vulcan_fe.Vulcan_bo;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getMaxBuffers() {
        return Vulcan_fe.Vulcan_s1;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getBufferDecays() {
        return Vulcan_fe.Vulcan_vm;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getBufferMultiples() {
        return Vulcan_fe.Vulcan_tl;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getHotbarShuffle() {
        return Vulcan_fe.Vulcan_G;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getHotbarShuffleMinimums() {
        return Vulcan_fe.Vulcan_Mo;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getHotbarShuffleIntervals() {
        return Vulcan_fe.Vulcan_sG;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getRandomRotation() {
        return Vulcan_fe.Vulcan_vJ;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getRandomRotationMinimums() {
        return Vulcan_fe.Vulcan_MG;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public Map getRandomRotationIntervals() {
        return Vulcan_fe.Vulcan_bN;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public List getChecks(Player player) {
        return (List) ((C0042Vulcan_Oz) getPlayerData(player)).m635Vulcan_B(new Object[0]).stream().map(VulcanSpigotAPI::lambda$getChecks$0).collect(Collectors.toList());
    }

    private static Check lambda$getChecks$0(AbstractCheck abstractCheck) {
        return abstractCheck;
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public void toggleAlerts(Player player) throws Exception {
        long j = (a ^ 14418406968872L) ^ 90993035031113L;
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        Object[] objArr = new Object[2];
        player[1] = Long.valueOf(j);
        objArr[0] = objArr;
        vulcan_OBVulcan_e.Vulcan_V(objArr);
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_OB] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_OB] */
    @Override // me.frep.vulcan.api.VulcanAPI
    public void toggleVerbose(Player player) throws Exception {
        long j = (a ^ 41695251099667L) ^ 26590970495366L;
        ?? Vulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        ?? r3 = new Object[2];
        r3[1] = player;
        Vulcan_e[0] = Long.valueOf(j);
        r3.Vulcan_e(r3);
    }

    @Override // me.frep.vulcan.api.VulcanAPI
    public void flag(Player player, String str, String str2, String str3) {
        long j = (a ^ 25689551137202L) ^ 109047803055380L;
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        Object[] objArr = new Object[5];
        objArr[4] = str3;
        objArr[3] = str2;
        str[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = player;
        vulcan_OBVulcan_e.Vulcan_L(objArr);
    }
}
