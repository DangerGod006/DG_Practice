package me.frep.vulcan.spigot;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.lang.invoke.MethodHandles;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.clip.placeholderapi.PlaceholderAPI;
import me.frep.vulcan.api.event.VulcanDisableAlertsEvent;
import me.frep.vulcan.api.event.VulcanEnableAlertsEvent;
import me.frep.vulcan.spigot.check.AbstractCheck;
import net.md_5.bungee.api.chat.TextComponent;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OB.class */
public class Vulcan_OB {
    private final Set Vulcan_I = new HashSet();
    private final Set Vulcan_d = new HashSet();
    private final DecimalFormat Vulcan_g = new DecimalFormat(b[47]);
    private static String[] Vulcan_M;
    private static final long a = Vulcan_n.a(5914294271740681798L, -2657764509343228357L, MethodHandles.lookup().lookupClass()).a(258619162433163L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x01c3: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_N(java.lang.Object[] r21) {
        /*
            Method dump skipped, instruction units count: 6643
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.Vulcan_N(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x02d8: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_L(java.lang.Object[] r15) {
        /*
            Method dump skipped, instruction units count: 2637
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.Vulcan_L(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0560: INVOKE (r-1 I:me.frep.vulcan.spigot.Vulcan_kZ), (r0 I:java.lang.Object[]) VIRTUAL call: me.frep.vulcan.spigot.Vulcan_kZ.Vulcan_G(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_kZ
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void lambda$handleAlert$10(me.frep.vulcan.spigot.check.AbstractCheck r12, int r13, me.frep.vulcan.spigot.C0042Vulcan_Oz r14, java.lang.String r15, java.lang.String r16, java.lang.String r17, java.lang.String r18, java.lang.String r19, java.lang.String r20, java.lang.String r21, java.lang.String r22, java.lang.String r23, java.lang.String r24, java.lang.String r25, java.lang.String r26, java.lang.String r27, java.lang.String r28, java.lang.String r29) {
        /*
            Method dump skipped, instruction units count: 2757
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.lambda$handleAlert$10(me.frep.vulcan.spigot.check.AbstractCheck, int, me.frep.vulcan.spigot.Vulcan_Oz, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0180: INVOKE (r-1 I:java.lang.String), (r0 I:java.lang.String), (r1 I:java.lang.String) VIRTUAL call: java.lang.String.replaceAll(java.lang.String, java.lang.String):java.lang.String
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void lambda$null$8(java.lang.String r9, java.lang.String r10, me.frep.vulcan.spigot.C0042Vulcan_Oz r11, java.lang.String r12, me.frep.vulcan.spigot.check.AbstractCheck r13, java.lang.String r14, java.lang.String r15, java.lang.String r16, java.lang.String r17, java.lang.String r18, java.lang.String r19, java.lang.String r20, java.lang.String r21, java.lang.String r22, java.lang.String r23) {
        /*
            Method dump skipped, instruction units count: 610
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.lambda$null$8(java.lang.String, java.lang.String, me.frep.vulcan.spigot.Vulcan_Oz, java.lang.String, me.frep.vulcan.spigot.check.AbstractCheck, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0029: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void lambda$handleAlert$2(me.frep.vulcan.spigot.check.AbstractCheck r9, me.frep.vulcan.spigot.C0042Vulcan_Oz r10, java.lang.String r11) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_OB.a
            r1 = 38110564485988(0x22a94ea88b64, double:1.8829120656144E-310)
            long r0 = r0 ^ r1
            r12 = r0
            r0 = r12
            r1 = r0; r1 = r0; 
            r2 = 122294768731933(0x6f39f83f871d, double:6.04216438965484E-310)
            long r1 = r1 ^ r2
            r14 = r1
            r0 = r14
            r1 = r9
            r2 = r10
            r3 = r11
            r4 = 4
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = 3
            r7 = r5; r5 = r6; r6 = r7; 
            r4[r5] = r6
            r4 = r3; r3 = r2; r2 = r4; 
            r5 = r3; r3 = r4; r4 = r5; 
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            me.frep.vulcan.spigot.Vulcan_fN.Vulcan_c(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.lambda$handleAlert$2(me.frep.vulcan.spigot.check.AbstractCheck, me.frep.vulcan.spigot.Vulcan_Oz, java.lang.String):void");
    }

    public static void Vulcan_b(String[] strArr) {
        Vulcan_M = strArr;
    }

    public static String[] Vulcan_Z() {
        return Vulcan_M;
    }

    static {
        int i;
        long j = a ^ 1149988241932L;
        Vulcan_b(new String[5]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[95];
        int i3 = 0;
        String str = "éðÞ\u0080\u0086o¡u\u0082\fý\u008dºÑu¸\b\tú\u009f¨¤f9\u0098\u0018ÿ¢\u0080?4tD\u001f\u00999¹²ïDýù\u0006Î\u0087¡3íxî\u0010\u0011\u00888løËã\u0082ä\u00ad?¾Ð\u00935Ä\bû\u0016r¹é\r\u009bÅ\u0010\u0001-<JgOwÉ\u008c\u0001´ÂE\u0004ªi\u0010Ó²\u0004¹Bà÷(C¥Ó\u00adßu\u0018\u001c\u0010\r\u0081¢ÐÓ¡ªÈØ\u0086ã3Õ?\u0003C\u0010\u0001-<JgOwÉ\u008c\u0001´ÂE\u0004ªi\buÆ\u0013Z\u0017¤¡\u0096\u00184î¤\u009anÙ_RÎ\u001f5è5Ù\u0017Tº^÷f\u001d\u0099v&\u0018ÿ¢\u0080?4tD\u001f\u00999¹²ïDýù\u0006Î\u0087¡3íxî\b\u0086?H\u0081\u0099vÏö\b°÷ëdé/\u001d\u00ad\bÍ\u0095\u0091+}¥\u0091µ\u00184î¤\u009anÙ_RÎ\u001f5è5Ù\u0017Tº^÷f\u001d\u0099v&\bú\u00967Î·\u008cëí\buÆ\u0013Z\u0017¤¡\u0096\u0010Ã@Û\u0097x\u001a)÷£}CI\u0000\u008cr/\bT\u009a\u0004\u008b\u00ad-\u0006ã\b¤ç°ö\u0006~Ö=\b\u0088Ú\u008fe£4ÿ\u0087\u0010éÓG\u0019b\u0098µ$\u0081Ù\u001fñÎ\rj\u0090\b\u0088Ú\u008fe£4ÿ\u0087\u0010ò,,Î\u0085bH\u00adì\u0081\u007f\u00038Ç¿5\bP\u009015CU\u0080v\u0010éðÞ\u0080\u0086o¡u\u0082\fý\u008dºÑu¸\b\u0086?H\u0081\u0099vÏö\u0010Üþâ\u008eßv\u009a\u0012±{³6Úx\u001b\u008b\bÊ>\u00ad!üÖ\u008e5\u0010ÇëÂòUÅ\ryÚÝÌo\u0015Ç\u008bH\bÍmÏ \u001bÆD\u000f\b6²]Â\u0016m\u0098«\u0010\u0082}â+ËF\u0006\u008c\u0001¼üäh\u0018\u001b[\b\u001f\u0088×O¤Á\u0090ý\u0018y°\b\u008b\u0088\u000eVl}î\u0084c\u000f\u0017N\u0007\u009dï}\u0097òs¯=\b\u001f\u0088×O¤Á\u0090ý\b\u001c\u0019WKÿçlá\b°÷ëdé/\u001d\u00ad\u0010éÓG\u0019b\u0098µ$\u0081Ù\u001fñÎ\rj\u0090\u0010\u001bÓ\u001bÆ\u009c_\u0007B\u009a<©Ã(\\=\u009e\b\u001c\u0019WKÿçlá\u0010\u0011\u00888løËã\u0082(ÂRÐT\u008fDÒ\u0010ÈKÔ\u0010L77-aRÁ¼\u0016\u0090ö±\u0018} 2\u0006\u001b\u008eósð`Å?¸`\u0091#\n@1\u009fSì¥²\u0018y°\b\u008b\u0088\u000eVl}î\u0084c\u000f\u0017N\u0007\u009dï}\u0097òs¯=\u0010ò,õë.¹\u0093\u0092\u0003²PÕGi#\u0081\bÙ+bÉR²(K\u0010õ\u008f[v¸Ë\u001e\u0016\f\u008eï«R=[Ã\bÓç\u001a\u0080³\u009ftÜ\u0010\r\u0081¢ÐÓ¡ªÈØ\u0086ã3Õ?\u0003C\bP\u009015CU\u0080v\bÍmÏ \u001bÆD\u000f\u0010ã\u001b©Q\u0081ùïµ#\rüÃp\u0084 <\u0010Ì\u0081\u0093AÊø¯Ú]f9\u0007\u0098~k<\u0010^|·\u007f\u0015A\u0003Ì.áY8½\u00072w\u0010ÈKÔ\u0010L77-aRÁ¼\u0016\u0090ö±\b=\u007f#Ù\u007f\u0098¦/\u0010Ê\u00061Ã\u0016;\u0006Æ>\u0011\u0003ÓG_1ê\b6²]Â\u0016m\u0098«\u0010\u0006¶PV«\u0087íÀËbêÎ\u0003s\u009cw\u0010{aà$µÂ\u0096äDø\u0010Â\u00836It\b\u0013X\u0007\u0080-\u0018|Î\b\tú\u009f¨¤f9\u0098\bßÕ\u001eWÑ\\ðä\u0010Ã@Û\u0097x\u001a)÷£}CI\u0000\u008cr/\u0010ãø>\u009f4E?\\Î$(;\u0004\u0018\u000b×\bT\u009a\u0004\u008b\u00ad-\u0006ã\u0010ò,,Î\u0085bH\u00adì\u0081\u007f\u00038Ç¿5\u0018éÓG\u0019b\u0098µ$0í¼®½ÏYYzµÔ^\u001a\u0012\u0085u\u0010\u0015\u00ad£\u0086Xí\u001c·yô\u0096\u0084\u0090ótÐ\b\u0080¡Ä6iå\u0084®\u0010{aà$µÂ\u0096ä\u001abÃæó8Tª\b\u0080¡Ä6iå\u0084®\u0010\u0015\u00ad£\u0086Xí\u001c·yô\u0096\u0084\u0090ótÐ\u0010ã\u001b©Q\u0081ùïµ#\rüÃp\u0084 <\u0010^|·\u007f\u0015A\u0003Ì-\u0014ø\u0011ÌNßD\u0010Ê\u00061Ã\u0016;\u0006Æ>\u0011\u0003ÓG_1ê\bæýáÑþ\u0090Z#\u0010\u0011\u00888løËã\u0082ä\u00ad?¾Ð\u00935Ä\u0018} 2\u0006\u001b\u008eósð`Å?¸`\u0091#\n@1\u009fSì¥²\u0010Ì\u0081\u0093AÊø¯Ú]f9\u0007\u0098~k<\bßÕ\u001eWÑ\\ðä\u0010ñ½\u007f@¼òi&Æ\u001dû\u0095_\u001e8R\u0010\u0082}â+ËF\u0006\u008c\u0001¼üäh\u0018\u001b[\b\u0013X\u0007\u0080-\u0018|Î\u0010\u0011\u00888løËã\u0082(ÂRÐT\u008fDÒ\b=\u007f#Ù\u007f\u0098¦/\u0010\u00ad\u000e\u0004\u000eÐ\u0014Y§=Âch£Áý\u0015\bÆ(6`\u008dg!\u0088\bÆ(6`\u008dg!\u0088\u0010.\bà\bæ>{²ô\u0086Çâ½%\u009e-\u0018éÓG\u0019b\u0098µ$0í¼®½ÏYYzµÔ^\u001a\u0012\u0085u";
        int length = "éðÞ\u0080\u0086o¡u\u0082\fý\u008dºÑu¸\b\tú\u009f¨¤f9\u0098\u0018ÿ¢\u0080?4tD\u001f\u00999¹²ïDýù\u0006Î\u0087¡3íxî\u0010\u0011\u00888løËã\u0082ä\u00ad?¾Ð\u00935Ä\bû\u0016r¹é\r\u009bÅ\u0010\u0001-<JgOwÉ\u008c\u0001´ÂE\u0004ªi\u0010Ó²\u0004¹Bà÷(C¥Ó\u00adßu\u0018\u001c\u0010\r\u0081¢ÐÓ¡ªÈØ\u0086ã3Õ?\u0003C\u0010\u0001-<JgOwÉ\u008c\u0001´ÂE\u0004ªi\buÆ\u0013Z\u0017¤¡\u0096\u00184î¤\u009anÙ_RÎ\u001f5è5Ù\u0017Tº^÷f\u001d\u0099v&\u0018ÿ¢\u0080?4tD\u001f\u00999¹²ïDýù\u0006Î\u0087¡3íxî\b\u0086?H\u0081\u0099vÏö\b°÷ëdé/\u001d\u00ad\bÍ\u0095\u0091+}¥\u0091µ\u00184î¤\u009anÙ_RÎ\u001f5è5Ù\u0017Tº^÷f\u001d\u0099v&\bú\u00967Î·\u008cëí\buÆ\u0013Z\u0017¤¡\u0096\u0010Ã@Û\u0097x\u001a)÷£}CI\u0000\u008cr/\bT\u009a\u0004\u008b\u00ad-\u0006ã\b¤ç°ö\u0006~Ö=\b\u0088Ú\u008fe£4ÿ\u0087\u0010éÓG\u0019b\u0098µ$\u0081Ù\u001fñÎ\rj\u0090\b\u0088Ú\u008fe£4ÿ\u0087\u0010ò,,Î\u0085bH\u00adì\u0081\u007f\u00038Ç¿5\bP\u009015CU\u0080v\u0010éðÞ\u0080\u0086o¡u\u0082\fý\u008dºÑu¸\b\u0086?H\u0081\u0099vÏö\u0010Üþâ\u008eßv\u009a\u0012±{³6Úx\u001b\u008b\bÊ>\u00ad!üÖ\u008e5\u0010ÇëÂòUÅ\ryÚÝÌo\u0015Ç\u008bH\bÍmÏ \u001bÆD\u000f\b6²]Â\u0016m\u0098«\u0010\u0082}â+ËF\u0006\u008c\u0001¼üäh\u0018\u001b[\b\u001f\u0088×O¤Á\u0090ý\u0018y°\b\u008b\u0088\u000eVl}î\u0084c\u000f\u0017N\u0007\u009dï}\u0097òs¯=\b\u001f\u0088×O¤Á\u0090ý\b\u001c\u0019WKÿçlá\b°÷ëdé/\u001d\u00ad\u0010éÓG\u0019b\u0098µ$\u0081Ù\u001fñÎ\rj\u0090\u0010\u001bÓ\u001bÆ\u009c_\u0007B\u009a<©Ã(\\=\u009e\b\u001c\u0019WKÿçlá\u0010\u0011\u00888løËã\u0082(ÂRÐT\u008fDÒ\u0010ÈKÔ\u0010L77-aRÁ¼\u0016\u0090ö±\u0018} 2\u0006\u001b\u008eósð`Å?¸`\u0091#\n@1\u009fSì¥²\u0018y°\b\u008b\u0088\u000eVl}î\u0084c\u000f\u0017N\u0007\u009dï}\u0097òs¯=\u0010ò,õë.¹\u0093\u0092\u0003²PÕGi#\u0081\bÙ+bÉR²(K\u0010õ\u008f[v¸Ë\u001e\u0016\f\u008eï«R=[Ã\bÓç\u001a\u0080³\u009ftÜ\u0010\r\u0081¢ÐÓ¡ªÈØ\u0086ã3Õ?\u0003C\bP\u009015CU\u0080v\bÍmÏ \u001bÆD\u000f\u0010ã\u001b©Q\u0081ùïµ#\rüÃp\u0084 <\u0010Ì\u0081\u0093AÊø¯Ú]f9\u0007\u0098~k<\u0010^|·\u007f\u0015A\u0003Ì.áY8½\u00072w\u0010ÈKÔ\u0010L77-aRÁ¼\u0016\u0090ö±\b=\u007f#Ù\u007f\u0098¦/\u0010Ê\u00061Ã\u0016;\u0006Æ>\u0011\u0003ÓG_1ê\b6²]Â\u0016m\u0098«\u0010\u0006¶PV«\u0087íÀËbêÎ\u0003s\u009cw\u0010{aà$µÂ\u0096äDø\u0010Â\u00836It\b\u0013X\u0007\u0080-\u0018|Î\b\tú\u009f¨¤f9\u0098\bßÕ\u001eWÑ\\ðä\u0010Ã@Û\u0097x\u001a)÷£}CI\u0000\u008cr/\u0010ãø>\u009f4E?\\Î$(;\u0004\u0018\u000b×\bT\u009a\u0004\u008b\u00ad-\u0006ã\u0010ò,,Î\u0085bH\u00adì\u0081\u007f\u00038Ç¿5\u0018éÓG\u0019b\u0098µ$0í¼®½ÏYYzµÔ^\u001a\u0012\u0085u\u0010\u0015\u00ad£\u0086Xí\u001c·yô\u0096\u0084\u0090ótÐ\b\u0080¡Ä6iå\u0084®\u0010{aà$µÂ\u0096ä\u001abÃæó8Tª\b\u0080¡Ä6iå\u0084®\u0010\u0015\u00ad£\u0086Xí\u001c·yô\u0096\u0084\u0090ótÐ\u0010ã\u001b©Q\u0081ùïµ#\rüÃp\u0084 <\u0010^|·\u007f\u0015A\u0003Ì-\u0014ø\u0011ÌNßD\u0010Ê\u00061Ã\u0016;\u0006Æ>\u0011\u0003ÓG_1ê\bæýáÑþ\u0090Z#\u0010\u0011\u00888løËã\u0082ä\u00ad?¾Ð\u00935Ä\u0018} 2\u0006\u001b\u008eósð`Å?¸`\u0091#\n@1\u009fSì¥²\u0010Ì\u0081\u0093AÊø¯Ú]f9\u0007\u0098~k<\bßÕ\u001eWÑ\\ðä\u0010ñ½\u007f@¼òi&Æ\u001dû\u0095_\u001e8R\u0010\u0082}â+ËF\u0006\u008c\u0001¼üäh\u0018\u001b[\b\u0013X\u0007\u0080-\u0018|Î\u0010\u0011\u00888løËã\u0082(ÂRÐT\u008fDÒ\b=\u007f#Ù\u007f\u0098¦/\u0010\u00ad\u000e\u0004\u000eÐ\u0014Y§=Âch£Áý\u0015\bÆ(6`\u008dg!\u0088\bÆ(6`\u008dg!\u0088\u0010.\bà\bæ>{²ô\u0086Çâ½%\u009e-\u0018éÓG\u0019b\u0098µ$0í¼®½ÏYYzµÔ^\u001a\u0012\u0085u".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Óç\u001a\u0080³\u009ftÜ\bú\u00967Î·\u008cëí";
                        length = "Óç\u001a\u0080³\u009ftÜ\bú\u00967Î·\u008cëí".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public Set Vulcan_X(Object[] objArr) {
        return this.Vulcan_I;
    }

    public Set Vulcan_R(Object[] objArr) {
        return this.Vulcan_d;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00c7  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:81:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [me.frep.vulcan.api.event.VulcanEnableAlertsEvent, org.bukkit.event.Event] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v23, types: [org.bukkit.plugin.PluginManager] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v42, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v54, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v60, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v62, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v66, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v71 */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r0v74 */
    /* JADX WARN: Type inference failed for: r0v75 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r1v23, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v28, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v4, types: [java.lang.Object[]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_V(java.lang.Object[] r9) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 389
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_OB.Vulcan_V(java.lang.Object[]):void");
    }

    private static void lambda$toggleAlerts$0(VulcanDisableAlertsEvent vulcanDisableAlertsEvent) {
        Bukkit.getPluginManager().callEvent(vulcanDisableAlertsEvent);
    }

    private static void lambda$toggleAlerts$1(VulcanEnableAlertsEvent vulcanEnableAlertsEvent) {
        Bukkit.getPluginManager().callEvent(vulcanEnableAlertsEvent);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v16, types: [int] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r1v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v8, types: [java.lang.Object[]] */
    public void Vulcan_e(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        Player player = (Player) objArr[1];
        long j = a ^ jLongValue;
        long j2 = j ^ 14681028003293L;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            try {
                try {
                    Vulcan_Z = this.Vulcan_d.contains(player);
                    if (Vulcan_Z != 0) {
                        if (Vulcan_Z != 0) {
                            this.Vulcan_d.remove(player);
                            ?? r3 = new Object[2];
                            Vulcan_fe.Vulcan_su[1] = Long.valueOf(j2);
                            r3[0] = r3;
                            player.sendMessage(Vulcan_ym.Vulcan_X(r3));
                            if (j > 0 && Vulcan_Z == 0) {
                            }
                        }
                        this.Vulcan_d.add(player);
                        ?? r32 = new Object[2];
                        Vulcan_fe.Vulcan_sR[1] = Long.valueOf(j2);
                        r32[0] = r32;
                        player.sendMessage(Vulcan_ym.Vulcan_X(r32));
                    } else {
                        ?? r322 = new Object[2];
                        Vulcan_fe.Vulcan_sR[1] = Long.valueOf(j2);
                        r322[0] = r322;
                        player.sendMessage(Vulcan_ym.Vulcan_X(r322));
                    }
                    ?? r0 = (j > 0L ? 1 : (j == 0L ? 0 : -1));
                    if (r0 > 0) {
                        try {
                            if (AbstractCheck.Vulcan_k() == null) {
                                return;
                            }
                            r0 = new String[3];
                            Vulcan_b(r0);
                        } catch (RuntimeException unused) {
                            throw a((Exception) r0);
                        }
                    }
                } catch (RuntimeException unused2) {
                    throw a((Exception) Vulcan_Z);
                }
            } catch (RuntimeException unused3) {
                throw a((Exception) Vulcan_Z);
            }
        } catch (RuntimeException unused4) {
            throw a((Exception) Vulcan_Z);
        }
    }

    private static void lambda$handleAlert$3(TextComponent textComponent, Player player) {
        player.spigot().sendMessage(textComponent);
    }

    private void lambda$handleAlert$5(TextComponent textComponent) {
        this.Vulcan_I.forEach((v1) -> {
            lambda$null$4(r1, v1);
        });
    }

    private static void lambda$null$4(TextComponent textComponent, Player player) {
        player.spigot().sendMessage(textComponent);
    }

    private static void lambda$handleAlert$7(C0042Vulcan_Oz c0042Vulcan_Oz, String str, String str2, AbstractCheck abstractCheck, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12) {
        Vulcan_fe.Vulcan_F.forEach((v14) -> {
            lambda$null$6(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, v14);
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Exception, org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v55, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v88, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v10, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r5v14, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object[], java.lang.String] */
    /* JADX WARN: Type inference failed for: r5v22, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r5v27, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r5v31, types: [java.lang.Object[]] */
    private static void lambda$null$6(C0042Vulcan_Oz c0042Vulcan_Oz, String str, String str2, AbstractCheck abstractCheck, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13) throws Exception {
        String name;
        long j = a ^ 41667321627878L;
        long j2 = j ^ 50702339778157L;
        long j3 = j ^ 140311070180999L;
        long j4 = j ^ 39196150091417L;
        long j5 = j ^ 45332206973144L;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            try {
                Vulcan_Z = c0042Vulcan_Oz.Vulcan_e(new Object[0]);
                ?? ReplaceAll = str13.replace(b[26], str).replaceAll(b[33], str2).replaceAll(b[22], c0042Vulcan_Oz.getClientBrand());
                ?? r2 = b[68];
                ?? r5 = new Object[2];
                r5[1] = abstractCheck.getCategory().toLowerCase();
                r2[0] = Long.valueOf(j4);
                String strReplaceAll = ReplaceAll.replaceAll(r5, Vulcan_fN.Vulcan_O(r5)).replaceAll(b[65], Vulcan_fe.Vulcan_b0).replaceAll(b[85], str3);
                String str14 = b[77];
                ?? r52 = new Object[1];
                abstractCheck[0] = Long.valueOf(j5);
                String strReplaceAll2 = strReplaceAll.replaceAll(str14, r52.Vulcan_i(r52).complexType());
                String str15 = b[16];
                ?? r53 = new Object[1];
                abstractCheck[0] = Long.valueOf(j5);
                String strReplaceAll3 = strReplaceAll2.replaceAll(str15, r53.Vulcan_i(r53).name()).replaceAll(b[64], str4);
                String str16 = b[8];
                ?? r54 = new Object[1];
                abstractCheck[0] = Long.valueOf(j5);
                String strReplaceAll4 = strReplaceAll3.replaceAll(str16, r54.Vulcan_i(r54).description()).replaceAll(b[34], str5).replaceAll(b[38], c0042Vulcan_Oz.Vulcan_e(new Object[0]).getUniqueId().toString());
                String str17 = b[42];
                Player playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                if (Vulcan_Z == 0) {
                    name = playerVulcan_M.getName();
                } else if (playerVulcan_M == null) {
                    name = b[67];
                } else {
                    playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                    name = playerVulcan_M.getName();
                }
                try {
                    try {
                        String strReplaceAll5 = strReplaceAll4.replaceAll(str17, name).replaceAll(b[63], str6).replaceAll(b[57], str7).replaceAll(b[71], str8).replaceAll(b[32], str9).replaceAll(b[15], Integer.toString(c0042Vulcan_Oz.getTotalViolations())).replaceAll(b[51], str10);
                        String str18 = b[43];
                        String strVulcan_X = str11;
                        if (Vulcan_Z != 0) {
                            strReplaceAll5 = strReplaceAll5.replaceAll(str18, strVulcan_X);
                            str18 = b[49];
                            ?? r55 = new Object[1];
                            abstractCheck[0] = Long.valueOf(j5);
                            if (r55.Vulcan_i(r55).experimental()) {
                                ?? r56 = new Object[2];
                                Vulcan_fe.Vulcan_sZ[1] = Long.valueOf(j2);
                                r56[0] = r56;
                                strVulcan_X = Vulcan_ym.Vulcan_X(r56);
                            } else {
                                strVulcan_X = "";
                            }
                        }
                        String strReplaceAll6 = strReplaceAll5.replaceAll(str18, strVulcan_X);
                        String[] strArr = b;
                        String strReplaceAll7 = strReplaceAll6.replaceAll(strArr[27], str12);
                        String str19 = strArr[17];
                        ?? r57 = new Object[1];
                        abstractCheck[0] = Long.valueOf(j5);
                        ?? placeholders = PlaceholderAPI.setPlaceholders((Player) Vulcan_Z, strReplaceAll7.replaceAll(str19, Character.toString(r57.Vulcan_i(r57).type())));
                        ?? r22 = new Object[2];
                        placeholders[1] = Long.valueOf(j3);
                        r22[0] = r22;
                        Vulcan_OM.Vulcan_u(r22);
                    } catch (RuntimeException unused) {
                        throw a((Exception) Vulcan_Z);
                    }
                } catch (RuntimeException unused2) {
                    throw a((Exception) Vulcan_Z);
                }
            } catch (RuntimeException unused3) {
                throw a((Exception) Vulcan_Z);
            }
        } catch (RuntimeException unused4) {
            throw a((Exception) Vulcan_Z);
        }
    }

    private static void lambda$handleAlert$9(String str, String str2, C0042Vulcan_Oz c0042Vulcan_Oz, String str3, AbstractCheck abstractCheck, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12) {
        Vulcan_fe.Vulcan_F.forEach((v14) -> {
            lambda$null$8(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, v14);
        });
    }

    private static void lambda$handleApiAlert$11(TextComponent textComponent, Player player) {
        player.spigot().sendMessage(textComponent);
    }

    private void lambda$handleApiAlert$13(TextComponent textComponent) {
        this.Vulcan_I.forEach((v1) -> {
            lambda$null$12(r1, v1);
        });
    }

    private static void lambda$null$12(TextComponent textComponent, Player player) {
        player.spigot().sendMessage(textComponent);
    }

    private static void lambda$handleApiAlert$15(C0042Vulcan_Oz c0042Vulcan_Oz, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12) {
        Vulcan_fe.Vulcan_F.forEach((v13) -> {
            lambda$null$14(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, v13);
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r2v35, types: [java.lang.Object[]] */
    private static void lambda$null$14(C0042Vulcan_Oz c0042Vulcan_Oz, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13) throws Exception {
        String name;
        long j = (a ^ 105263740445814L) ^ 6344828773911L;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            try {
                Vulcan_Z = c0042Vulcan_Oz.Vulcan_e(new Object[0]);
                String strReplaceAll = str13.replace(b[0], str).replaceAll(b[39], c0042Vulcan_Oz.getClientBrand()).replaceAll(b[18], Vulcan_fe.Vulcan_b0).replaceAll(b[62], str2).replaceAll(b[94], str3).replaceAll(b[82], str4).replaceAll(b[36], str5);
                String str14 = b[86];
                Player playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                if (Vulcan_Z == 0) {
                    name = playerVulcan_M.getName();
                } else if (playerVulcan_M == null) {
                    name = b[19];
                } else {
                    playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                    name = playerVulcan_M.getName();
                }
                String strReplaceAll2 = strReplaceAll.replaceAll(str14, name);
                String[] strArr = b;
                ?? placeholders = PlaceholderAPI.setPlaceholders((Player) Vulcan_Z, strReplaceAll2.replaceAll(strArr[1], str6).replaceAll(strArr[87], str7).replaceAll(strArr[73], str8).replaceAll(strArr[59], str9).replaceAll(strArr[10], Integer.toString(c0042Vulcan_Oz.getTotalViolations())).replaceAll(strArr[25], str10).replaceAll(strArr[56], str11).replaceAll(strArr[9], str12));
                ?? r2 = new Object[2];
                placeholders[1] = Long.valueOf(j);
                r2[0] = r2;
                Vulcan_OM.Vulcan_u(r2);
            } catch (RuntimeException unused) {
                throw a((Exception) Vulcan_Z);
            }
        } catch (RuntimeException unused2) {
            throw a((Exception) Vulcan_Z);
        }
    }

    private static void lambda$handleApiAlert$17(String str, C0042Vulcan_Oz c0042Vulcan_Oz, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12) {
        Vulcan_fe.Vulcan_F.forEach((v13) -> {
            lambda$null$16(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, v13);
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r2v42, types: [java.lang.Object[]] */
    private static void lambda$null$16(String str, C0042Vulcan_Oz c0042Vulcan_Oz, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13) throws Exception {
        String name;
        long j = (a ^ 73432777010708L) ^ 27147348356213L;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            try {
                Vulcan_Z = str13.replace(b[26], str).replaceAll(b[22], c0042Vulcan_Oz.getClientBrand()).replaceAll(b[65], Vulcan_fe.Vulcan_b0).replaceAll(b[85], str2);
                String str14 = b[42];
                Player playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                if (Vulcan_Z == 0) {
                    name = playerVulcan_M.getName();
                } else if (playerVulcan_M == null) {
                    name = b[67];
                } else {
                    playerVulcan_M = c0042Vulcan_Oz.m636Vulcan_T(new Object[0]).Vulcan_M(new Object[0]);
                    name = playerVulcan_M.getName();
                }
                String strReplaceAll = Vulcan_Z.replaceAll(str14, name);
                String[] strArr = b;
                ?? r2 = new Object[2];
                strReplaceAll.replaceAll(strArr[16], str3).replaceAll(strArr[64], str4).replaceAll(strArr[34], str5).replaceAll(strArr[63], str6).replaceAll(strArr[57], str7).replaceAll(strArr[71], str8).replaceAll(strArr[32], str9).replaceAll(strArr[15], Integer.toString(c0042Vulcan_Oz.getTotalViolations())).replaceAll(strArr[51], str10).replaceAll(strArr[43], str11).replaceAll(strArr[17], str12)[1] = Long.valueOf(j);
                r2[0] = r2;
                Vulcan_OM.Vulcan_u(r2);
            } catch (RuntimeException unused) {
                throw a((Exception) Vulcan_Z);
            }
        } catch (RuntimeException unused2) {
            throw a((Exception) Vulcan_Z);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v47, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v18, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v25, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v32, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v39, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v46, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v53, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v60, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v67, types: [java.lang.Object[]] */
    private String Vulcan_t(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long j = (a ^ jLongValue) ^ 81833422043566L;
        ?? Vulcan_X = iIntValue;
        try {
            switch (Vulcan_X) {
                case 1:
                    ?? r2 = new Object[2];
                    Vulcan_fe.Vulcan_bJ[1] = Long.valueOf(j);
                    r2[0] = r2;
                    Vulcan_X = Vulcan_ym.Vulcan_X(r2);
                    return Vulcan_X;
                case 2:
                    ?? r22 = new Object[2];
                    Vulcan_fe.Vulcan_t5[1] = Long.valueOf(j);
                    r22[0] = r22;
                    return Vulcan_ym.Vulcan_X(r22);
                case 3:
                    ?? r23 = new Object[2];
                    Vulcan_fe.Vulcan_tU[1] = Long.valueOf(j);
                    r23[0] = r23;
                    return Vulcan_ym.Vulcan_X(r23);
                case 4:
                    ?? r24 = new Object[2];
                    Vulcan_fe.Vulcan_sm[1] = Long.valueOf(j);
                    r24[0] = r24;
                    return Vulcan_ym.Vulcan_X(r24);
                case 5:
                    ?? r25 = new Object[2];
                    Vulcan_fe.Vulcan_tV[1] = Long.valueOf(j);
                    r25[0] = r25;
                    return Vulcan_ym.Vulcan_X(r25);
                case 6:
                    ?? r26 = new Object[2];
                    Vulcan_fe.Vulcan_sI[1] = Long.valueOf(j);
                    r26[0] = r26;
                    return Vulcan_ym.Vulcan_X(r26);
                case 7:
                    ?? r27 = new Object[2];
                    Vulcan_fe.Vulcan_MY[1] = Long.valueOf(j);
                    r27[0] = r27;
                    return Vulcan_ym.Vulcan_X(r27);
                case 8:
                    ?? r28 = new Object[2];
                    Vulcan_fe.Vulcan_K[1] = Long.valueOf(j);
                    r28[0] = r28;
                    return Vulcan_ym.Vulcan_X(r28);
                case 9:
                    ?? r29 = new Object[2];
                    Vulcan_fe.Vulcan_sw[1] = Long.valueOf(j);
                    r29[0] = r29;
                    return Vulcan_ym.Vulcan_X(r29);
                case 10:
                    ?? r210 = new Object[2];
                    Vulcan_fe.Vulcan_a[1] = Long.valueOf(j);
                    r210[0] = r210;
                    return Vulcan_ym.Vulcan_X(r210);
                default:
                    return "";
            }
        } catch (RuntimeException unused) {
            throw a((Exception) Vulcan_X);
        }
        throw a((Exception) Vulcan_X);
    }

    private boolean Vulcan_s(Object[] objArr) {
        AbstractCheck abstractCheck = (AbstractCheck) objArr[0];
        String str = abstractCheck.getName().toLowerCase() + ":" + String.valueOf(abstractCheck.getType()).toLowerCase();
        String[] strArr = b;
        return Arrays.asList(strArr[76], strArr[55]).contains(str);
    }

    public void Vulcan_A(Object[] objArr) {
        String str = (String) objArr[0];
        this.Vulcan_I.forEach((v1) -> {
            lambda$sendMessage$18(r1, v1);
        });
    }

    private static void lambda$sendMessage$18(String str, Player player) {
        Object[] objArr = new Object[2];
        str[1] = Long.valueOf((a ^ 97732132529081L) ^ 91377209622834L);
        objArr[0] = objArr;
        player.sendMessage(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v5, types: [boolean] */
    private void Vulcan_j(Object[] objArr) throws Exception {
        Player player = (Player) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        String str = (String) objArr[2];
        ?? r0 = a ^ jLongValue;
        try {
            r0 = Vulcan_fe.Vulcan_tK;
            if (r0 == 0) {
                return;
            }
            ByteArrayDataOutput byteArrayDataOutputNewDataOutput = ByteStreams.newDataOutput();
            String[] strArr = b;
            byteArrayDataOutputNewDataOutput.writeUTF(strArr[4]);
            byteArrayDataOutputNewDataOutput.writeUTF(str);
            player.sendPluginMessage(Vulcan_r.INSTANCE.m1084Vulcan_j(), strArr[88], byteArrayDataOutputNewDataOutput.toByteArray());
        } catch (RuntimeException unused) {
            throw a((Exception) r0);
        }
    }
}
