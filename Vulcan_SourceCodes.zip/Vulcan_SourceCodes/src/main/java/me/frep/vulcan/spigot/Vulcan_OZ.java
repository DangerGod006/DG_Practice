package me.frep.vulcan.spigot;

import java.util.List;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OZ.class */
public abstract class Vulcan_OZ implements List {
    protected final List Vulcan_Y;

    public Vulcan_OZ(List list) {
        this.Vulcan_Y = list;
    }

    public List Vulcan_l(Object[] objArr) {
        return this.Vulcan_Y;
    }
}
