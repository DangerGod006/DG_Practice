package me.frep.vulcan.spigot.check.impl.player.badpackets;

import com.github.retrooper.packetevents.event.PacketEvent;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_yU;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPacketsE.class */
@CheckInfo(name = "Bad Packets", type = 'E', complexType = "Interact", description = "Interacted with themselves.")
public class BadPacketsE extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public BadPacketsE(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsE] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [int] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsE] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsE] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r1v20, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v9, types: [java.lang.Object[]] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ?? r1 = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 86877937232409L;
        long j2 = jLongValue ^ 108218722128643L;
        long j3 = jLongValue ^ 83955508045016L;
        String strVulcan_n = BadPackets8.Vulcan_n();
        ?? A = this;
        ?? r0 = A;
        if (strVulcan_n == null) {
            try {
                try {
                    ?? r3 = new Object[2];
                    r1[1] = Long.valueOf(j3);
                    r3[0] = r3;
                    A = A.Vulcan_B(r3);
                    if (A != 0) {
                        r0 = this;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    A = a((RuntimeException) A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) A);
            }
        }
        WrapperPlayClientInteractEntity wrapperPlayClientInteractEntityVulcan_M = r0.Vulcan_b.Vulcan_M(new Object[0]);
        ?? r12 = new Vulcan_yU[1];
        r12[0] = Vulcan_yU.SPECTATOR;
        ?? r32 = new Object[2];
        r12[1] = Long.valueOf(j);
        r32[0] = r32;
        ?? Vulcan_t = Vulcan_t((Object[]) r32);
        try {
            try {
                Vulcan_t = wrapperPlayClientInteractEntityVulcan_M.getEntityId();
                ?? r02 = Vulcan_t;
                if (jLongValue > 0) {
                    r02 = Vulcan_t;
                    if (strVulcan_n == null) {
                        if (Vulcan_t != this.Vulcan_b.Vulcan_B(new Object[0])) {
                            return;
                        } else {
                            r02 = Vulcan_t;
                        }
                    }
                }
                if (r02 == 0) {
                    try {
                        Object[] objArr2 = new Object[1];
                        r02 = objArr2;
                        this[0] = Long.valueOf(j2);
                        r02.Vulcan_K(objArr2);
                    } catch (RuntimeException unused3) {
                        throw a((RuntimeException) r02);
                    }
                }
            } catch (RuntimeException unused4) {
                Vulcan_t = a((RuntimeException) Vulcan_t);
                throw Vulcan_t;
            }
        } catch (RuntimeException unused5) {
            throw a((RuntimeException) Vulcan_t);
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
