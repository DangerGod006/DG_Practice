package me.frep.vulcan.spigot.check.impl.player.scaffold;

import com.github.retrooper.packetevents.event.PacketEvent;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/scaffold/ScaffoldF.class */
@CheckInfo(name = "Scaffold", type = 'F', complexType = "Packet", description = "Invalid rotations")
public class ScaffoldF extends AbstractCheck {
    private long Vulcan_n;
    private long Vulcan_l;
    private long Vulcan_j;
    private long Vulcan_f;
    private boolean Vulcan__;
    private boolean Vulcan_X;
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0269: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 662
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF.Vulcan_a(java.lang.Object[]):void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x005d, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0061, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0069, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0090, code lost:
    
        r8 = 125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0095, code lost:
    
        r8 = 20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x009a, code lost:
    
        r8 = 62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009f, code lost:
    
        r8 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a4, code lost:
    
        r8 = 37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00a9, code lost:
    
        r8 = 118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ae, code lost:
    
        r8 = 72;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00b0, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00b8, code lost:
    
        if (r4 != 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00bb, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00c0, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00c5, code lost:
    
        if (r4 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00c9, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00db, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0026, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = -1;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0036, code lost:
    
        if (r0 >= r0) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0042, code lost:
    
        me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x005a, code lost:
    
        if (r2 <= 1) goto L10;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:10:0x005d, B:23:0x00c0], limit reached: 29 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00c5 -> B:10:0x005d). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 220
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF.m1279clinit():void");
    }

    public ScaffoldF(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF] */
    /* JADX WARN: Type inference failed for: r0v13, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction$Action] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldF] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        PacketEvent packetEvent = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue() ^ 130930509284752L;
        AbstractCheck[] abstractCheckArrVulcan_B = ScaffoldN.Vulcan_B();
        ?? A = this;
        ?? r0 = A;
        if (abstractCheckArrVulcan_B == null) {
            try {
                try {
                    ?? r3 = new Object[2];
                    r3[1] = packetEvent;
                    A[0] = Long.valueOf(jLongValue);
                    A = r3.Vulcan_J(r3);
                    if (A != 0) {
                        r0 = this;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    A = a((RuntimeException) A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) A);
            }
        }
        ?? M633Vulcan_c = r0.Vulcan_b.m633Vulcan_c(new Object[0]);
        try {
            M633Vulcan_c = abstractCheckArrVulcan_B;
            if (M633Vulcan_c == 0) {
                try {
                    try {
                        M633Vulcan_c = M633Vulcan_c.getAction();
                        if (M633Vulcan_c != WrapperPlayClientEntityAction.Action.START_SNEAKING && M633Vulcan_c.getAction() != WrapperPlayClientEntityAction.Action.STOP_SNEAKING) {
                            return;
                        }
                        this.Vulcan_f = System.currentTimeMillis() - this.Vulcan_j;
                        this.Vulcan_X = true;
                    } catch (RuntimeException unused3) {
                        throw a((RuntimeException) M633Vulcan_c);
                    }
                } catch (RuntimeException unused4) {
                    throw a((RuntimeException) M633Vulcan_c);
                }
            }
            this.Vulcan_j = System.currentTimeMillis();
        } catch (RuntimeException unused5) {
            throw a((RuntimeException) M633Vulcan_c);
        }
    }
}
