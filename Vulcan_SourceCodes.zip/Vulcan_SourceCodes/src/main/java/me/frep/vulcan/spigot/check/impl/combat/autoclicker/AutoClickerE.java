package me.frep.vulcan.spigot.check.impl.combat.autoclicker;

import com.google.common.collect.Lists;
import java.util.Deque;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/autoclicker/AutoClickerE.class */
@CheckInfo(name = "Auto Clicker", type = 'E', complexType = "Variance", description = "Too low variance.")
public class AutoClickerE extends AbstractCheck {
    private final Deque Vulcan_i;
    private static final String b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x011a: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 450
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerE.Vulcan_T(java.lang.Object[]):void");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0055, code lost:
    
        r8 = 81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x005a, code lost:
    
        r8 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x005f, code lost:
    
        r8 = 101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0064, code lost:
    
        r8 = 26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0069, code lost:
    
        r8 = 109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x006e, code lost:
    
        r8 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0070, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0078, code lost:
    
        if (r4 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x007b, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0080, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0084, code lost:
    
        if (r4 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0088, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x009a, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0007, code lost:
    
        me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerE.b = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001c, code lost:
    
        if (r2 <= 1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x001f, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0022, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0029, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0050, code lost:
    
        r8 = 57;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x001f, B:19:0x0080], limit reached: 24 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v2, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0084 -> B:6:0x001f). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 3
            java.lang.String r1 = "L3h\u000fx\u0000\u0014_o"
            r2 = -1
            goto Ld
        L7:
            me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerE.b = r0
            goto L9a
        Ld:
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            char[] r2 = r2.toCharArray()
            r3 = r2; r2 = r1; r1 = r3; 
            int r3 = r3.length
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r4 = 0
            r11 = r4
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = 1
            if (r5 > r6) goto L80
        L1f:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L22:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L50;
                case 1: goto L55;
                case 2: goto L5a;
                case 3: goto L5f;
                case 4: goto L64;
                case 5: goto L69;
                default: goto L6e;
            }
        L50:
            r8 = 57
            goto L70
        L55:
            r8 = 81
            goto L70
        L5a:
            r8 = 25
            goto L70
        L5f:
            r8 = 101(0x65, float:1.42E-43)
            goto L70
        L64:
            r8 = 26
            goto L70
        L69:
            r8 = 109(0x6d, float:1.53E-43)
            goto L70
        L6e:
            r8 = 116(0x74, float:1.63E-43)
        L70:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L80
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L22
        L80:
            r6 = r4; r5 = r3; r4 = r2; r3 = r6; r2 = r5; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r11
            if (r5 > r6) goto L1f
        L88:
            java.lang.String r4 = new java.lang.String
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            java.lang.String r3 = r3.intern()
            r4 = r2; r2 = r3; r3 = r4; 
            r3 = r1; r1 = r2; r2 = r3; 
            goto L7
        L9a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.autoclicker.AutoClickerE.m1151clinit():void");
    }

    public AutoClickerE(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        this.Vulcan_i = Lists.newLinkedList();
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
