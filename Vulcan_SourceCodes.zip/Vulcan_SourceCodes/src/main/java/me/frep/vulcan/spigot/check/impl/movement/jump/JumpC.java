package me.frep.vulcan.spigot.check.impl.movement.jump;

import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/jump/JumpC.class */
@CheckInfo(name = "Jump", type = 'C', complexType = "Motion", description = "Invalid jump motion.")
public class JumpC extends AbstractCheck {
    private static String Vulcan_L;
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x034a: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 2275
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.jump.JumpC.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_Q(String str) {
        Vulcan_L = str;
    }

    public static String Vulcan_u() {
        return Vulcan_L;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0064, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0068, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0070, code lost:
    
        switch((r17 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0098, code lost:
    
        r8 = 91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x009d, code lost:
    
        r8 = 25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00a2, code lost:
    
        r8 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a7, code lost:
    
        r8 = 18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00ac, code lost:
    
        r8 = 52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00b1, code lost:
    
        r8 = 80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00b6, code lost:
    
        r8 = 19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00b8, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r17 = r17 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00c0, code lost:
    
        if (r4 != 0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00c3, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00c8, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00cd, code lost:
    
        if (r4 > r17) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00d1, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00e3, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x002d, code lost:
    
        r2 = r14;
        r14 = r14 + 1;
        r0[r2] = -1;
        r0 = r11 + r12;
        r11 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x003d, code lost:
    
        if (r0 >= r1) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0049, code lost:
    
        me.frep.vulcan.spigot.check.impl.movement.jump.JumpC.b = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0061, code lost:
    
        if (r2 <= 1) goto L10;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:10:0x0064, B:23:0x00c8], limit reached: 29 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00cd -> B:10:0x0064). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 228
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.jump.JumpC.m1213clinit():void");
    }

    public JumpC(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
