package me.frep.vulcan.spigot.check.impl.combat.velocity;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/velocity/VelocityD.class */
@CheckInfo(name = "Velocity", type = 'D', complexType = "Horizontal", description = "Horizontal velocity modifications.", experimental = true)
public class VelocityD extends AbstractCheck {
    private static final float Vulcan_l = 0.02f;
    private static final float Vulcan_T = 0.6f;
    private boolean Vulcan_Z;
    private boolean Vulcan_p;
    private int Vulcan_o;
    private static int Vulcan_R;
    private static final long b = Vulcan_n.a(6512660651086158875L, -4042187362412712525L, MethodHandles.lookup().lookupClass()).a(103173063409866L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0a69: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 2838
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityD.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_m(int i) {
        Vulcan_R = i;
    }

    public static int Vulcan_a() {
        return Vulcan_R;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_b() {
        return Vulcan_a() == 0 ? 58 : 0;
    }

    static {
        long j = b ^ 69909581752332L;
        Vulcan_m(0);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = " Ñÿã\u0093\u009aaÓ\b\u009f\u0018\\\u009bmOï\u009e\u0010!WT\u0006è<À\n%:ým°\f|]".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = b(cipher.doFinal(" Ñÿã\u0093\u009aaÓ\b\u009f\u0018\\\u009bmOï\u009e\u0010!WT\u0006è<À\n%:ým°\f|]".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                d = strArr;
                return;
            }
            cCharAt = " Ñÿã\u0093\u009aaÓ\b\u009f\u0018\\\u009bmOï\u009e\u0010!WT\u0006è<À\n%:ým°\f|]".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [int] */
    public VelocityD(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 4636304972417L;
        ?? Vulcan_b = Vulcan_b();
        this.Vulcan_Z = false;
        this.Vulcan_p = false;
        try {
            this.Vulcan_o = 0;
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_b++;
                Vulcan_m((int) Vulcan_b);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_b);
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x006f, code lost:
    
        if (r0 != 0) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0082, code lost:
    
        if (r0 != 0) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0092, code lost:
    
        if (r0 != 0) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00a7, code lost:
    
        if (r0 != 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x00b7, code lost:
    
        if (r0 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00ca, code lost:
    
        if (r0 != 0) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00d8, code lost:
    
        if (r0 != 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00e9, code lost:
    
        if (r0 == 0) goto L43;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x007c A[PHI: r0 r12 r13
  0x007c: PHI (r0v33 int) = (r0v6 int), (r0v36 int) binds: [B:11:0x006c, B:13:0x0072] A[DONT_GENERATE, DONT_INLINE]
  0x007c: PHI (r12v17 float) = (r12v1 float), (r12v18 float) binds: [B:11:0x006c, B:13:0x0072] A[DONT_GENERATE, DONT_INLINE]
  0x007c: PHI (r13v15 float) = (r13v0 float), (r13v16 float) binds: [B:11:0x006c, B:13:0x0072] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x008c A[PHI: r0 r12 r13
  0x008c: PHI (r0v32 int) = (r0v26 int), (r0v33 int) binds: [B:17:0x0085, B:15:0x007f] A[DONT_GENERATE, DONT_INLINE]
  0x008c: PHI (r12v16 float) = (r12v10 float), (r12v17 float) binds: [B:17:0x0085, B:15:0x007f] A[DONT_GENERATE, DONT_INLINE]
  0x008c: PHI (r13v14 float) = (r13v8 float), (r13v15 float) binds: [B:17:0x0085, B:15:0x007f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00a1 A[PHI: r0 r12 r13
  0x00a1: PHI (r0v31 int) = (r0v24 int), (r0v32 int) binds: [B:21:0x0095, B:19:0x008f] A[DONT_GENERATE, DONT_INLINE]
  0x00a1: PHI (r12v15 float) = (r12v9 float), (r12v16 float) binds: [B:21:0x0095, B:19:0x008f] A[DONT_GENERATE, DONT_INLINE]
  0x00a1: PHI (r13v13 float) = (r13v7 float), (r13v14 float) binds: [B:21:0x0095, B:19:0x008f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00b1 A[PHI: r0 r12 r13
  0x00b1: PHI (r0v30 int) = (r0v21 int), (r0v31 int) binds: [B:25:0x00aa, B:23:0x00a4] A[DONT_GENERATE, DONT_INLINE]
  0x00b1: PHI (r12v14 float) = (r12v8 float), (r12v15 float) binds: [B:25:0x00aa, B:23:0x00a4] A[DONT_GENERATE, DONT_INLINE]
  0x00b1: PHI (r13v12 float) = (r13v6 float), (r13v13 float) binds: [B:25:0x00aa, B:23:0x00a4] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00c4 A[PHI: r0 r12 r13
  0x00c4: PHI (r0v29 int) = (r0v19 int), (r0v30 int) binds: [B:29:0x00ba, B:27:0x00b4] A[DONT_GENERATE, DONT_INLINE]
  0x00c4: PHI (r12v13 float) = (r12v7 float), (r12v14 float) binds: [B:29:0x00ba, B:27:0x00b4] A[DONT_GENERATE, DONT_INLINE]
  0x00c4: PHI (r13v11 float) = (r13v5 float), (r13v12 float) binds: [B:29:0x00ba, B:27:0x00b4] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00d2 A[PHI: r0 r12 r13
  0x00d2: PHI (r0v28 int) = (r0v16 int), (r0v29 int) binds: [B:33:0x00cd, B:31:0x00c7] A[DONT_GENERATE, DONT_INLINE]
  0x00d2: PHI (r12v12 float) = (r12v6 float), (r12v13 float) binds: [B:33:0x00cd, B:31:0x00c7] A[DONT_GENERATE, DONT_INLINE]
  0x00d2: PHI (r13v10 float) = (r13v4 float), (r13v11 float) binds: [B:33:0x00cd, B:31:0x00c7] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00e9 A[PHI: r0 r12 r13
  0x00e9: PHI (r0v27 int) = (r0v14 int), (r0v28 int) binds: [B:39:0x00e7, B:35:0x00d5] A[DONT_GENERATE, DONT_INLINE]
  0x00e9: PHI (r12v11 float) = (r12v5 float), (r12v12 float) binds: [B:39:0x00e7, B:35:0x00d5] A[DONT_GENERATE, DONT_INLINE]
  0x00e9: PHI (r13v9 float) = (r13v3 float), (r13v10 float) binds: [B:39:0x00e7, B:35:0x00d5] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r1v7, types: [int, java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private me.frep.vulcan.spigot.C0039Vulcan_Oo Vulcan_U(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 260
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityD.Vulcan_U(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_Oo");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [float] */
    public float Vulcan_F(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        C0042Vulcan_Oz c0042Vulcan_Oz = (C0042Vulcan_Oz) objArr[1];
        long j = b ^ jLongValue;
        ?? Vulcan_b = Vulcan_b();
        double dM708Vulcan_C = c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m708Vulcan_C(new Object[0]);
        try {
            Vulcan_b = (float) (dM708Vulcan_C + (((double) c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m739Vulcan_b(new Object[0])) * 0.2d * dM708Vulcan_C));
            if (Vulcan_b == 0) {
                AbstractCheck.Vulcan_D(new AbstractCheck[2]);
            }
            return Vulcan_b;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_b);
        }
    }
}
