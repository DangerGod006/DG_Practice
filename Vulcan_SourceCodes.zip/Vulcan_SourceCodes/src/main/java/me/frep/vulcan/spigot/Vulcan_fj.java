package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fj.class */
public class Vulcan_fj {
    public final double Vulcan_l;
    public final double Vulcan_X;
    public final double Vulcan_f;
    public final double Vulcan_u;
    public final double Vulcan_S;
    public final double Vulcan_e;
    private static final long a = Vulcan_n.a(3222000798740992302L, -577341814315823927L, MethodHandles.lookup().lookupClass()).a(194777326486537L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 132046103866929L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[7];
        int i3 = 0;
        String str = "»\u0080\u0018c1[²V\u0010\u0081\u0017.)øï¡X1cÛî-\u009f¸Â\b»\u0080\u0018c1[²V\u0018ÂBð\u009fU6ÖC¹\tA²\u0090ì¼\u008aFc\u007fÔÏ\u0005É\f\b\u0013&Í¬/%\u0087 ";
        int length = "»\u0080\u0018c1[²V\u0010\u0081\u0017.)øï¡X1cÛî-\u009f¸Â\b»\u0080\u0018c1[²V\u0018ÂBð\u009fU6ÖC¹\tA²\u0090ì¼\u008aFc\u007fÔÏ\u0005É\f\b\u0013&Í¬/%\u0087 ".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "¼ÔF[Ì©i\u009bn\u0096ù|¿?'Ó\b;\u0011q\u001cÃ\u001f@à";
                        length = "¼ÔF[Ì©i\u009bn\u0096ù|¿?'Ó\b;\u0011q\u001cÃ\u001f@à".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public Vulcan_fj(double d, double d2, double d3, double d4, double d5, double d6) {
        this.Vulcan_l = Math.min(d, d4);
        this.Vulcan_X = Math.min(d2, d5);
        this.Vulcan_f = Math.min(d3, d6);
        this.Vulcan_u = Math.max(d, d4);
        this.Vulcan_S = Math.max(d2, d5);
        this.Vulcan_e = Math.max(d3, d6);
    }

    public Vulcan_fj(Vulcan_fB vulcan_fB, Vulcan_fB vulcan_fB2) {
        this.Vulcan_l = vulcan_fB.Vulcan_s(new Object[0]);
        this.Vulcan_X = vulcan_fB.Vulcan_y(new Object[0]);
        this.Vulcan_f = vulcan_fB.Vulcan_L(new Object[0]);
        this.Vulcan_u = vulcan_fB2.Vulcan_s(new Object[0]);
        this.Vulcan_S = vulcan_fB2.Vulcan_y(new Object[0]);
        this.Vulcan_e = vulcan_fB2.Vulcan_L(new Object[0]);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_fj Vulcan_p(java.lang.Object[] r16) {
        /*
            Method dump skipped, instruction units count: 365
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_p(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_fj");
    }

    public Vulcan_fj Vulcan_c(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        return new Vulcan_fj(this.Vulcan_l - dDoubleValue, this.Vulcan_X - dDoubleValue2, this.Vulcan_f - dDoubleValue3, this.Vulcan_u + dDoubleValue, this.Vulcan_S + dDoubleValue2, this.Vulcan_e + dDoubleValue3);
    }

    public static String spigot() {
        return b[5];
    }

    public static String nonce() {
        return b[1];
    }

    public static String resource() {
        return b[3];
    }

    public Vulcan_fj Vulcan_F(Object[] objArr) {
        Vulcan_fj vulcan_fj = (Vulcan_fj) objArr[0];
        return new Vulcan_fj(Math.min(this.Vulcan_l, vulcan_fj.Vulcan_l), Math.min(this.Vulcan_X, vulcan_fj.Vulcan_X), Math.min(this.Vulcan_f, vulcan_fj.Vulcan_f), Math.max(this.Vulcan_u, vulcan_fj.Vulcan_u), Math.max(this.Vulcan_S, vulcan_fj.Vulcan_S), Math.max(this.Vulcan_e, vulcan_fj.Vulcan_e));
    }

    public static Vulcan_fj Vulcan_K(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        double dDoubleValue4 = ((Double) objArr[3]).doubleValue();
        double dDoubleValue5 = ((Double) objArr[4]).doubleValue();
        double dDoubleValue6 = ((Double) objArr[5]).doubleValue();
        return new Vulcan_fj(Math.min(dDoubleValue, dDoubleValue4), Math.min(dDoubleValue2, dDoubleValue5), Math.min(dDoubleValue3, dDoubleValue6), Math.max(dDoubleValue, dDoubleValue4), Math.max(dDoubleValue2, dDoubleValue5), Math.max(dDoubleValue3, dDoubleValue6));
    }

    public Vulcan_fj Vulcan_S(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        return new Vulcan_fj(this.Vulcan_l + dDoubleValue, this.Vulcan_X + dDoubleValue2, this.Vulcan_f + dDoubleValue3, this.Vulcan_u + dDoubleValue, this.Vulcan_S + dDoubleValue2, this.Vulcan_e + dDoubleValue3);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public double Vulcan_V(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 381
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_V(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public double Vulcan_v(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 372
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_v(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public double m823Vulcan_S(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 377
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.m823Vulcan_S(java.lang.Object[]):double");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:77:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [int] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m824Vulcan_v(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 233
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.m824Vulcan_v(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0070  */
    /* JADX WARN: Removed duplicated region for block: B:77:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [int] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_G(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 233
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_G(java.lang.Object[]):boolean");
    }

    public double Vulcan_f(Object[] objArr) {
        double d = this.Vulcan_u - this.Vulcan_l;
        double d2 = this.Vulcan_S - this.Vulcan_X;
        return ((d + d2) + (this.Vulcan_e - this.Vulcan_f)) / 3.0d;
    }

    public Vulcan_fj Vulcan_r(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        return new Vulcan_fj(this.Vulcan_l + dDoubleValue, this.Vulcan_X + dDoubleValue2, this.Vulcan_f + dDoubleValue3, this.Vulcan_u - dDoubleValue, this.Vulcan_S - dDoubleValue2, this.Vulcan_e - dDoubleValue3);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_k8 Vulcan__(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1418
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan__(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_k8");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_L(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_L(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_U(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_Oa r1 = (me.frep.vulcan.spigot.Vulcan_Oa) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_fj.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r12 = r0
            r0 = r9
            r1 = r12
            if (r1 != 0) goto L37
            if (r0 != 0) goto L36
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L32
            throw r0     // Catch: java.lang.RuntimeException -> L32
        L2e:
            r0 = 0
            goto Lc2
        L32:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L32
            throw r0
        L36:
            r0 = r9
        L37:
            double r0 = r0.Vulcan_v     // Catch: java.lang.RuntimeException -> L50
            r1 = r7
            double r1 = r1.Vulcan_l     // Catch: java.lang.RuntimeException -> L50
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L66
            if (r1 != 0) goto L64
            if (r0 < 0) goto Lc1
            goto L54
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L60
            throw r0     // Catch: java.lang.RuntimeException -> L60
        L54:
            r0 = r9
            double r0 = r0.Vulcan_v     // Catch: java.lang.RuntimeException -> L60
            r1 = r7
            double r1 = r1.Vulcan_u     // Catch: java.lang.RuntimeException -> L60
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L64:
            r1 = r12
        L66:
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L8b
            if (r1 != 0) goto L89
            if (r0 > 0) goto Lc1
            goto L79
        L75:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L85
            throw r0     // Catch: java.lang.RuntimeException -> L85
        L79:
            r0 = r9
            double r0 = r0.Vulcan_h     // Catch: java.lang.RuntimeException -> L85
            r1 = r7
            double r1 = r1.Vulcan_f     // Catch: java.lang.RuntimeException -> L85
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r1 = r12
        L8b:
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto Lb0
            if (r1 != 0) goto Lae
            if (r0 < 0) goto Lc1
            goto L9e
        L9a:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> Laa
            throw r0     // Catch: java.lang.RuntimeException -> Laa
        L9e:
            r0 = r9
            double r0 = r0.Vulcan_h     // Catch: java.lang.RuntimeException -> Laa
            r1 = r7
            double r1 = r1.Vulcan_e     // Catch: java.lang.RuntimeException -> Laa
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto Lae
        Laa:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lae:
            r1 = r12
        Lb0:
            if (r1 != 0) goto Lbe
            if (r0 > 0) goto Lc1
            goto Lbd
        Lb9:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lbd:
            r0 = 1
        Lbe:
            goto Lc2
        Lc1:
            r0 = 0
        Lc2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_U(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_g(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fj.Vulcan_g(java.lang.Object[]):boolean");
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String[] strArr = b;
        return sb.append(strArr[4]).append(this.Vulcan_l).append(strArr[2]).append(this.Vulcan_X).append(strArr[0]).append(this.Vulcan_f).append(strArr[6]).append(this.Vulcan_u).append(strArr[0]).append(this.Vulcan_S).append(strArr[0]).append(this.Vulcan_e).append("]").toString();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    public boolean Vulcan_z(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            try {
                try {
                    try {
                        Vulcan_J = Double.isNaN(this.Vulcan_l);
                        if (Vulcan_J != 0) {
                            return Vulcan_J;
                        }
                        if (Vulcan_J == 0) {
                            try {
                                Vulcan_J = Double.isNaN(this.Vulcan_X);
                                if (Vulcan_J != 0) {
                                    return Vulcan_J;
                                }
                                try {
                                    try {
                                        if (Vulcan_J == 0) {
                                            Vulcan_J = Double.isNaN(this.Vulcan_f);
                                            if (Vulcan_J != 0) {
                                                return Vulcan_J;
                                            }
                                            try {
                                                try {
                                                    try {
                                                        try {
                                                            if (Vulcan_J == 0) {
                                                                boolean zIsNaN = Double.isNaN(this.Vulcan_u);
                                                                if (Vulcan_J != 0) {
                                                                    return zIsNaN;
                                                                }
                                                                if (!zIsNaN) {
                                                                    boolean zIsNaN2 = Double.isNaN(this.Vulcan_S);
                                                                    if (Vulcan_J != 0) {
                                                                        return zIsNaN2;
                                                                    }
                                                                    if (!zIsNaN2) {
                                                                        boolean zIsNaN3 = Double.isNaN(this.Vulcan_e);
                                                                        if (Vulcan_J != 0) {
                                                                            return zIsNaN3;
                                                                        }
                                                                        if (!zIsNaN3) {
                                                                            return false;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        } catch (RuntimeException unused) {
                                                            throw a((RuntimeException) Vulcan_J);
                                                        }
                                                    } catch (RuntimeException unused2) {
                                                        throw a((RuntimeException) Vulcan_J);
                                                    }
                                                } catch (RuntimeException unused3) {
                                                    throw a((RuntimeException) Vulcan_J);
                                                }
                                            } catch (RuntimeException unused4) {
                                                throw a((RuntimeException) Vulcan_J);
                                            }
                                        }
                                    } catch (RuntimeException unused5) {
                                        throw a((RuntimeException) Vulcan_J);
                                    }
                                } catch (RuntimeException unused6) {
                                    throw a((RuntimeException) Vulcan_J);
                                }
                            } catch (RuntimeException unused7) {
                                throw a((RuntimeException) Vulcan_J);
                            }
                        }
                        return true;
                    } catch (RuntimeException unused8) {
                        throw a((RuntimeException) Vulcan_J);
                    }
                } catch (RuntimeException unused9) {
                    throw a((RuntimeException) Vulcan_J);
                }
            } catch (RuntimeException unused10) {
                throw a((RuntimeException) Vulcan_J);
            }
        } catch (RuntimeException unused11) {
            throw a((RuntimeException) Vulcan_J);
        }
    }
}
