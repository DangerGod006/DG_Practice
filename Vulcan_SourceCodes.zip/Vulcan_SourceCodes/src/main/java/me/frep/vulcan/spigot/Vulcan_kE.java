package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kE.class */
public class Vulcan_kE extends Vulcan_k4 implements CommandExecutor {
    private final ExecutorService Vulcan_i = Executors.newSingleThreadExecutor();
    private static final long b = Vulcan_n.a(-5892110267812845326L, 9195962351452143665L, MethodHandles.lookup().lookupClass()).a(138621604880530L);
    private static final String[] d;

    static {
        int i;
        long j = b ^ 26380951408483L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[9];
        int i3 = 0;
        String str = "Þ\u009fý\u0014\u0080û¦æc\u0085\rü*\r5\u000eIÜáaÏ¶g\u008f\bU&¹¯¶e\u0017\u0082\b\tn;&\u0017ö\u0003*\u0010Ø9\u001cþF\tíÁõ}\u001bÌ'SÈÕ\bßMw½2\u0092+h\u0018zGÍ/\u008f\u0014´§\u0081¼\u0094Ø\bD\t4ÎÖ2\u0082,ú(Þ\u0010 4\u0082¦\u00adèäüm¬uw\u0085*\u0080â";
        int length = "Þ\u009fý\u0014\u0080û¦æc\u0085\rü*\r5\u000eIÜáaÏ¶g\u008f\bU&¹¯¶e\u0017\u0082\b\tn;&\u0017ö\u0003*\u0010Ø9\u001cþF\tíÁõ}\u001bÌ'SÈÕ\bßMw½2\u0092+h\u0018zGÍ/\u008f\u0014´§\u0081¼\u0094Ø\bD\t4ÎÖ2\u0082,ú(Þ\u0010 4\u0082¦\u00adèäüm¬uw\u0085*\u0080â".length();
        char cCharAt = 24;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = " 4\u0082¦\u00adèäüm¬uw\u0085*\u0080â\b¤¨£ó,P\u0015Î";
                        length = " 4\u0082¦\u00adèäüm¬uw\u0085*\u0080â\b¤¨£ó,P\u0015Î".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r9v0, types: [me.frep.vulcan.spigot.Vulcan_kE] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public boolean onCommand(CommandSender commandSender, Command command, String str, String[] strArr) throws Exception {
        long j = (b ^ 9096665299602L) ^ 27479460409762L;
        ?? Vulcan__ = C0051Vulcan_ke.Vulcan__();
        try {
            try {
                Vulcan__ = commandSender.hasPermission(d[0]);
                ?? A = Vulcan__;
                if (Vulcan__ == 0) {
                    if (Vulcan__ == 0) {
                        ?? r4 = new Object[3];
                        Vulcan_fe.Vulcan_My[2] = Long.valueOf(j);
                        r4[1] = r4;
                        r4[0] = commandSender;
                        Vulcan_D(r4);
                        return true;
                    }
                    A = strArr.length;
                }
                try {
                    if (Vulcan__ == 0) {
                        if (A < 1) {
                            ?? r42 = new Object[3];
                            Vulcan_fe.Vulcan_sh[2] = Long.valueOf(j);
                            r42[1] = r42;
                            r42[0] = commandSender;
                            Vulcan_D(r42);
                            return true;
                        }
                        this.Vulcan_i.execute(() -> {
                            r1.lambda$onCommand$0(r2, r3);
                        });
                        A = 1;
                    }
                    try {
                        try {
                            if (AbstractCheck.Vulcan_k() != null) {
                                C0051Vulcan_ke.Vulcan_w(Vulcan__ == 0);
                            }
                            return A;
                        } catch (RuntimeException unused) {
                            A = a((Exception) A);
                            throw A;
                        }
                    } catch (RuntimeException unused2) {
                        throw a((Exception) A);
                    }
                } catch (RuntimeException unused3) {
                    throw a((Exception) A);
                }
            } catch (RuntimeException unused4) {
                throw a((Exception) Vulcan__);
            }
        } catch (RuntimeException unused5) {
            throw a((Exception) Vulcan__);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:107:0x010b A[EDGE_INSN: B:107:0x010b->B:44:0x010b BREAK  A[LOOP:0: B:15:0x009b->B:110:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:110:? A[LOOP:0: B:15:0x009b->B:110:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0202 A[Catch: FileNotFoundException -> 0x0295, TryCatch #4 {FileNotFoundException -> 0x0295, blocks: (B:14:0x0087, B:15:0x009b, B:17:0x00a3, B:20:0x00af, B:29:0x00d2, B:30:0x00e2, B:31:0x00e5, B:38:0x00f5, B:39:0x0101, B:40:0x0104, B:36:0x00f1, B:37:0x00f4, B:27:0x00ce, B:28:0x00d1, B:23:0x00c4, B:24:0x00c7, B:44:0x010b, B:45:0x011d, B:47:0x0127, B:48:0x0155, B:59:0x017f, B:64:0x018e, B:70:0x01ed, B:71:0x01f0, B:69:0x01bb, B:72:0x01f1, B:73:0x01f8, B:75:0x0202, B:76:0x020e, B:81:0x0261, B:82:0x0264, B:83:0x0265, B:67:0x01b7, B:68:0x01ba, B:62:0x018a, B:63:0x018d, B:53:0x016c, B:54:0x016f, B:55:0x0170), top: B:95:0x0087, inners: #0, #1, #5, #8, #9 }] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Exception, java.util.List] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v54, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v64, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v65, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v66, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v67, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v71, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v72, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v81 */
    /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v23, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v31, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r2v33, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v44, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v27, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v39, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v49, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r9v0, types: [me.frep.vulcan.spigot.Vulcan_kE] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void lambda$onCommand$0(java.lang.String[] r10, org.bukkit.command.CommandSender r11) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 669
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kE.lambda$onCommand$0(java.lang.String[], org.bukkit.command.CommandSender):void");
    }
}
