package me.frep.vulcan.spigot.check.impl.combat.autoblock;

import com.github.retrooper.packetevents.event.PacketEvent;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_yU;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/autoblock/AutoBlockA.class */
@CheckInfo(name = "Auto Block", type = 'A', complexType = "Sequence", description = "Attacked while sending BlockPlace packet.")
public class AutoBlockA extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public AutoBlockA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockA] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockA] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.impl.combat.autoblock.AutoBlockA] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r1v25, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v9, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ?? r1 = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 86877937232409L;
        long j2 = jLongValue ^ 108218722128643L;
        long j3 = jLongValue ^ 83955508045016L;
        String[] strArrVulcan_T = AutoBlockD.Vulcan_T();
        ?? A = this;
        ?? r0 = A;
        if (strArrVulcan_T == null) {
            try {
                try {
                    ?? r3 = new Object[2];
                    r1[1] = Long.valueOf(j3);
                    r3[0] = r3;
                    A = A.Vulcan_B(r3);
                    if (A != 0) {
                        r0 = this;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    A = a((RuntimeException) A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a((RuntimeException) A);
            }
        }
        if (r0.Vulcan_b.Vulcan_M(new Object[0]).getAction() == WrapperPlayClientInteractEntity.InteractAction.ATTACK) {
            boolean zM695Vulcan_q = this.Vulcan_b.m637Vulcan_r(new Object[0]).m695Vulcan_q(new Object[0]);
            ?? r12 = new Vulcan_yU[1];
            r12[0] = Vulcan_yU.CLIENT_VERSION;
            ?? r32 = new Object[2];
            r12[1] = Long.valueOf(j);
            r32[0] = r32;
            boolean zVulcan_t = Vulcan_t((Object[]) r32);
            boolean z = zM695Vulcan_q;
            ?? r02 = z;
            if (jLongValue >= 0) {
                r02 = z;
                if (strArrVulcan_T == null) {
                    if (!z) {
                        return;
                    } else {
                        r02 = zVulcan_t;
                    }
                }
            }
            if (r02 == 0) {
                try {
                    Object[] objArr2 = new Object[1];
                    r02 = objArr2;
                    this[0] = Long.valueOf(j2);
                    r02.Vulcan_K(objArr2);
                } catch (RuntimeException unused3) {
                    throw a((RuntimeException) r02);
                }
            }
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
