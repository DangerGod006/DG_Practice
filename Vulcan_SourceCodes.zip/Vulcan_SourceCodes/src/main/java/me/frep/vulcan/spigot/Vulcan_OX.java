package me.frep.vulcan.spigot;

import org.bukkit.entity.EntityType;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OX.class */
/* synthetic */ class Vulcan_OX {
    static final int[] Vulcan_S = new int[EntityType.values().length];

    static {
        try {
            Vulcan_S[EntityType.VILLAGER.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            Vulcan_S[EntityType.COW.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            Vulcan_S[EntityType.CHICKEN.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            Vulcan_S[EntityType.WOLF.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            Vulcan_S[EntityType.ITEM_FRAME.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
    }
}
