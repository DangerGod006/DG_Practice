package me.frep.vulcan.spigot;

import com.google.common.collect.Maps;
import java.lang.invoke.MethodHandles;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Found several "values" enum fields: [] */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kc.class */
public final class Vulcan_kc implements Vulcan_ya {
    public static final Vulcan_kc DOWN;
    public static final Vulcan_kc UP;
    public static final Vulcan_kc NORTH;
    public static final Vulcan_kc SOUTH;
    public static final Vulcan_kc WEST;
    public static final Vulcan_kc EAST;
    private final int Vulcan_U;
    private final int Vulcan_L;
    private final int Vulcan_F;
    private final String Vulcan_d;
    private final Vulcan_fo Vulcan_N;
    private final Vulcan_B Vulcan_o;
    private final Vulcan_fq Vulcan_x;
    private static final Vulcan_kc[] Vulcan_s;
    private static final Vulcan_kc[] Vulcan_p;
    private static final Map Vulcan_y;
    private static final String Vulcan_Q;
    private static final Vulcan_kc[] Vulcan_O;
    private static final long a = Vulcan_n.a(825050605539949925L, -2731662958814956343L, MethodHandles.lookup().lookupClass()).a(264984434854559L);
    private static final String[] b;

    /*  JADX ERROR: Failed to decode insn: 0x001C: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[8]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x2(JavaInsnsRegister.java:332)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public static me.frep.vulcan.spigot.Vulcan_kc Vulcan_O(double r8) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_kc.a
            r1 = 9593437523345(0x8b9a56f8d91, double:4.739787905809E-311)
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 108847222687671(0x62fef80b07b7, double:5.377767337521E-310)
            long r1 = r1 ^ r2
            r12 = r1
            r0 = r8
            r1 = 4636033603912859648(0x4056800000000000, double:90.0)
            double r0 = r0 / r1
            r1 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            double r0 = r0 + r1
            r1 = r12
            // decode failed: arraycopy: source index -1 out of bounds for object array[8]
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_Z(r-1)
            r0 = 3
            r-1 = r-1 & r0
            Vulcan_j(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kc.Vulcan_O(double):me.frep.vulcan.spigot.Vulcan_kc");
    }

    private static IllegalStateException a(IllegalStateException illegalStateException) {
        return illegalStateException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public static Vulcan_kc[] values() {
        return (Vulcan_kc[]) Vulcan_O.clone();
    }

    public static Vulcan_kc valueOf(String str) {
        return (Vulcan_kc) Enum.valueOf(Vulcan_kc.class, str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v37, types: [me.frep.vulcan.spigot.Vulcan_kc[]] */
    /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.Object, me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v46, types: [me.frep.vulcan.spigot.Vulcan_kc[]] */
    /* JADX WARN: Type inference failed for: r0v49, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v52, types: [me.frep.vulcan.spigot.Vulcan_kc[]] */
    static {
        int i;
        long j = a ^ 110031993031876L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[18];
        int i3 = 0;
        String str = "ÍÕ\u001fõûæâ¯(U=;]LQµÒ6ð\u0006\u0088~ëP÷ÛÈ\u0092Öv\u0099ßÊu\u0004\u0017{5\u009aT\u0087\u0093\u000e Ó±¿+\u0094\u0010w\u0097ÈHç\u0097Væ\u0087\u0083ìy\u001d%XÚ\ba>`\u0099\u0015\u0097o\u0014\b\u009b\u0083üÍîS\u000b\u0089\b\u0084x9o\u0087ô[/\b\u0013X\u0017\u0016¢\u0017Ó% U=;]LQµÒ\u0012\u0085\u008ce±\u0084ÿ\u0087+'eÏñ8\u000bù\u0082\u009a§§ýÌ.`(U=;]LQµÒ\\Sï#)w\u0085Ä¤ÄñI\b4Ò«ì¥¿7¾ª§ÍÀ¦\u0015mZ\b7\u0018(U=;]LQµÒ\u009c\u008b?\u0096[>î^\u001aq|ú\u0004ÛÕRç)¦I¹\u009b¨=\u0095¨\u000b\u0000w\u0094\u0007'\b¦\u001e{ÀkÒbx\bf¬f\u0098\"hå®\bï\u0092A¡¦\u0010\u000f¹(U=;]LQµÒ±´-lÑ\u000eâ¼£\u0004=,Ä;º¢\u009aéþcÜ°\u008d\u0094\u0014öB¸\u001e=\u000b±\bë8~Ø\u0013µqµ\bÜªN#Ò\u009c'\u008f";
        int length = "ÍÕ\u001fõûæâ¯(U=;]LQµÒ6ð\u0006\u0088~ëP÷ÛÈ\u0092Öv\u0099ßÊu\u0004\u0017{5\u009aT\u0087\u0093\u000e Ó±¿+\u0094\u0010w\u0097ÈHç\u0097Væ\u0087\u0083ìy\u001d%XÚ\ba>`\u0099\u0015\u0097o\u0014\b\u009b\u0083üÍîS\u000b\u0089\b\u0084x9o\u0087ô[/\b\u0013X\u0017\u0016¢\u0017Ó% U=;]LQµÒ\u0012\u0085\u008ce±\u0084ÿ\u0087+'eÏñ8\u000bù\u0082\u009a§§ýÌ.`(U=;]LQµÒ\\Sï#)w\u0085Ä¤ÄñI\b4Ò«ì¥¿7¾ª§ÍÀ¦\u0015mZ\b7\u0018(U=;]LQµÒ\u009c\u008b?\u0096[>î^\u001aq|ú\u0004ÛÕRç)¦I¹\u009b¨=\u0095¨\u000b\u0000w\u0094\u0007'\b¦\u001e{ÀkÒbx\bf¬f\u0098\"hå®\bï\u0092A¡¦\u0010\u000f¹(U=;]LQµÒ±´-lÑ\u000eâ¼£\u0004=,Ä;º¢\u009aéþcÜ°\u008d\u0094\u0014öB¸\u001e=\u000b±\bë8~Ø\u0013µqµ\bÜªN#Ò\u009c'\u008f".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            Vulcan_Q = b[2];
                            String[] strArr2 = b;
                            DOWN = new Vulcan_kc(strArr2[10], 0, 0, 1, -1, strArr2[14], Vulcan_B.NEGATIVE, Vulcan_fo.Y, new Vulcan_fq(0, -1, 0));
                            UP = new Vulcan_kc(strArr2[12], 1, 1, 0, -1, strArr2[5], Vulcan_B.POSITIVE, Vulcan_fo.Y, new Vulcan_fq(0, 1, 0));
                            NORTH = new Vulcan_kc(strArr2[4], 2, 2, 3, 2, strArr2[16], Vulcan_B.NEGATIVE, Vulcan_fo.Z, new Vulcan_fq(0, 0, -1));
                            SOUTH = new Vulcan_kc(strArr2[15], 3, 3, 2, 0, strArr2[6], Vulcan_B.POSITIVE, Vulcan_fo.Z, new Vulcan_fq(0, 0, 1));
                            WEST = new Vulcan_kc(strArr2[17], 4, 4, 5, 1, strArr2[11], Vulcan_B.NEGATIVE, Vulcan_fo.X, new Vulcan_fq(-1, 0, 0));
                            EAST = new Vulcan_kc(strArr2[0], 5, 5, 4, 3, strArr2[3], Vulcan_B.POSITIVE, Vulcan_fo.X, new Vulcan_fq(1, 0, 0));
                            Vulcan_O = new Vulcan_kc[]{DOWN, UP, NORTH, SOUTH, WEST, EAST};
                            Vulcan_s = new Vulcan_kc[6];
                            Vulcan_p = new Vulcan_kc[4];
                            Vulcan_y = Maps.newHashMap();
                            ?? Values = values();
                            int length2 = Values.length;
                            for (int i8 = 0; i8 < length2; i8++) {
                                ?? Vulcan_O2 = Values[i8];
                                try {
                                    Vulcan_s[((Vulcan_kc) Vulcan_O2).Vulcan_U] = Vulcan_O2;
                                    Vulcan_O2 = Vulcan_O2.Vulcan_h().Vulcan_O();
                                    if (Vulcan_O2 != 0) {
                                        Vulcan_p[((Vulcan_kc) Vulcan_O2).Vulcan_F] = Vulcan_O2;
                                    }
                                    Vulcan_y.put(Vulcan_O2.Vulcan_b().toLowerCase(), Vulcan_O2);
                                } catch (IllegalStateException unused) {
                                    throw a((IllegalStateException) Vulcan_O2);
                                }
                            }
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                        break;
                    default:
                        int i9 = i3;
                        i3++;
                        strArr[i9] = strIntern;
                        int i10 = i5 + cCharAt;
                        i4 = i10;
                        if (i10 < length) {
                        }
                        str = "ýÆ [¨Ó1\u0015\b\u0013\u0083R\u001bkÜl\r";
                        length = "ýÆ [¨Ó1\u0015\b\u0013\u0083R\u001bkÜl\r".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private Vulcan_kc(String str, int i, int i2, int i3, int i4, String str2, Vulcan_B vulcan_B, Vulcan_fo vulcan_fo, Vulcan_fq vulcan_fq) {
        this.Vulcan_U = i2;
        this.Vulcan_F = i4;
        this.Vulcan_L = i3;
        this.Vulcan_d = str2;
        this.Vulcan_N = vulcan_fo;
        this.Vulcan_o = vulcan_B;
        this.Vulcan_x = vulcan_fq;
    }

    public int Vulcan_P() {
        return this.Vulcan_U;
    }

    public int Vulcan_j() {
        return this.Vulcan_F;
    }

    public Vulcan_B Vulcan_D() {
        return this.Vulcan_o;
    }

    public Vulcan_kc Vulcan_w() {
        return Vulcan_C(this.Vulcan_L);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.IllegalStateException, me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.IllegalStateException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.IllegalStateException, me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.IllegalStateException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.IllegalStateException] */
    public Vulcan_kc Vulcan_g(Vulcan_fo vulcan_fo) {
        long j = a ^ 79793579837386L;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            try {
                try {
                    try {
                        try {
                            Vulcan_J = Vulcan_kT.Vulcan_d[vulcan_fo.ordinal()];
                            try {
                                try {
                                    switch (Vulcan_J) {
                                        case 1:
                                            if (Vulcan_J == 0) {
                                                if (this != WEST) {
                                                    if (Vulcan_J != 0) {
                                                        return this;
                                                    }
                                                    if (this != EAST) {
                                                        return Vulcan_G();
                                                    }
                                                }
                                                return this;
                                            }
                                            return this;
                                        case 2:
                                            Vulcan_J = this;
                                            if (Vulcan_J != 0) {
                                                return Vulcan_J;
                                            }
                                            try {
                                                try {
                                                    try {
                                                        if (Vulcan_J != UP) {
                                                            if (Vulcan_J != 0) {
                                                                return this;
                                                            }
                                                            if (this != DOWN) {
                                                                return Vulcan_o();
                                                            }
                                                        }
                                                        return this;
                                                    } catch (IllegalStateException unused) {
                                                        Vulcan_J = a((IllegalStateException) Vulcan_J);
                                                        throw Vulcan_J;
                                                    }
                                                } catch (IllegalStateException unused2) {
                                                    throw a((IllegalStateException) Vulcan_J);
                                                }
                                            } catch (IllegalStateException unused3) {
                                                throw a((IllegalStateException) Vulcan_J);
                                            }
                                        case 3:
                                            Vulcan_J = this;
                                            if (Vulcan_J != 0) {
                                                return Vulcan_J;
                                            }
                                            try {
                                                try {
                                                    try {
                                                        if (Vulcan_J != NORTH) {
                                                            if (Vulcan_J != 0) {
                                                                return this;
                                                            }
                                                            if (this != SOUTH) {
                                                                return Vulcan_l();
                                                            }
                                                        }
                                                        return this;
                                                    } catch (IllegalStateException unused4) {
                                                        Vulcan_J = a((IllegalStateException) Vulcan_J);
                                                        throw Vulcan_J;
                                                    }
                                                } catch (IllegalStateException unused5) {
                                                    throw a((IllegalStateException) Vulcan_J);
                                                }
                                            } catch (IllegalStateException unused6) {
                                                throw a((IllegalStateException) Vulcan_J);
                                            }
                                        default:
                                            throw new IllegalStateException(b[8] + vulcan_fo);
                                    }
                                } catch (IllegalStateException unused7) {
                                    throw a((IllegalStateException) Vulcan_J);
                                }
                            } catch (IllegalStateException unused8) {
                                throw a((IllegalStateException) Vulcan_J);
                            }
                        } catch (IllegalStateException unused9) {
                            throw a((IllegalStateException) Vulcan_J);
                        }
                    } catch (IllegalStateException unused10) {
                        throw a((IllegalStateException) Vulcan_J);
                    }
                } catch (IllegalStateException unused11) {
                    throw a((IllegalStateException) Vulcan_J);
                }
            } catch (IllegalStateException unused12) {
                throw a((IllegalStateException) Vulcan_J);
            }
        } catch (IllegalStateException unused13) {
            throw a((IllegalStateException) Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalStateException] */
    public Vulcan_kc Vulcan_o() {
        ?? r0 = a ^ 125238105266466L;
        try {
            switch (Vulcan_kT.Vulcan_B[ordinal()]) {
                case 1:
                    r0 = EAST;
                    return r0;
                case 2:
                    return SOUTH;
                case 3:
                    return WEST;
                case 4:
                    return NORTH;
                default:
                    throw new IllegalStateException(b[13] + this);
            }
        } catch (IllegalStateException unused) {
            throw a((IllegalStateException) r0);
        }
        throw a((IllegalStateException) r0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalStateException] */
    private Vulcan_kc Vulcan_G() {
        ?? r0 = a ^ 44060239755945L;
        try {
            switch (Vulcan_kT.Vulcan_B[ordinal()]) {
                case 1:
                    r0 = DOWN;
                    return r0;
                case 2:
                case 4:
                default:
                    throw new IllegalStateException(b[9] + this);
                case 3:
                    return UP;
                case 5:
                    return NORTH;
                case 6:
                    return SOUTH;
            }
        } catch (IllegalStateException unused) {
            throw a((IllegalStateException) r0);
        }
        throw a((IllegalStateException) r0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalStateException] */
    private Vulcan_kc Vulcan_l() {
        ?? r0 = a ^ 113027596448271L;
        try {
            switch (Vulcan_kT.Vulcan_B[ordinal()]) {
                case 2:
                    r0 = DOWN;
                    return r0;
                case 3:
                default:
                    throw new IllegalStateException(b[1] + this);
                case 4:
                    return UP;
                case 5:
                    return EAST;
                case 6:
                    return WEST;
            }
        } catch (IllegalStateException unused) {
            throw a((IllegalStateException) r0);
        }
        throw a((IllegalStateException) r0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [long] */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.IllegalStateException] */
    public Vulcan_kc Vulcan_e() {
        ?? r0 = a ^ 107163972700829L;
        try {
            switch (Vulcan_kT.Vulcan_B[ordinal()]) {
                case 1:
                    r0 = WEST;
                    return r0;
                case 2:
                    return NORTH;
                case 3:
                    return EAST;
                case 4:
                    return SOUTH;
                default:
                    throw new IllegalStateException(b[7] + this);
            }
        } catch (IllegalStateException unused) {
            throw a((IllegalStateException) r0);
        }
        throw a((IllegalStateException) r0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fo] */
    public int Vulcan_q() {
        long j = a ^ 62476804236454L;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            Vulcan_J = this;
            ?? r0 = Vulcan_J;
            if (Vulcan_J == 0) {
                try {
                    Vulcan_J = Vulcan_J.Vulcan_N;
                    if (Vulcan_J != Vulcan_fo.X) {
                        return 0;
                    }
                    r0 = this;
                } catch (IllegalStateException unused) {
                    throw a((IllegalStateException) Vulcan_J);
                }
            }
            return r0.Vulcan_o.Vulcan_r();
        } catch (IllegalStateException unused2) {
            throw a((IllegalStateException) Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fo] */
    public int Vulcan_F() {
        long j = a ^ 49692961564571L;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            Vulcan_J = this;
            ?? r0 = Vulcan_J;
            if (Vulcan_J == 0) {
                try {
                    Vulcan_J = Vulcan_J.Vulcan_N;
                    if (Vulcan_J != Vulcan_fo.Y) {
                        return 0;
                    }
                    r0 = this;
                } catch (IllegalStateException unused) {
                    throw a((IllegalStateException) Vulcan_J);
                }
            }
            return r0.Vulcan_o.Vulcan_r();
        } catch (IllegalStateException unused2) {
            throw a((IllegalStateException) Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.Vulcan_kc] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalStateException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_fo] */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public int m1053Vulcan_G() {
        long j = a ^ 131702895413191L;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            Vulcan_J = this;
            ?? r0 = Vulcan_J;
            if (Vulcan_J == 0) {
                try {
                    Vulcan_J = Vulcan_J.Vulcan_N;
                    if (Vulcan_J != Vulcan_fo.Z) {
                        return 0;
                    }
                    r0 = this;
                } catch (IllegalStateException unused) {
                    throw a((IllegalStateException) Vulcan_J);
                }
            }
            return r0.Vulcan_o.Vulcan_r();
        } catch (IllegalStateException unused2) {
            throw a((IllegalStateException) Vulcan_J);
        }
    }

    public String Vulcan_b() {
        return this.Vulcan_d;
    }

    public Vulcan_fo Vulcan_h() {
        return this.Vulcan_N;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static me.frep.vulcan.spigot.Vulcan_kc Vulcan_r(java.lang.String r5) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_kc.a
            r1 = 13559059301832(0xc54f6e9c5c8, double:6.6990653909594E-311)
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r8 = r0
            r0 = r5
            r1 = r8
            if (r1 != 0) goto L2f
            if (r0 != 0) goto L23
            goto L1b
        L17:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L1f
            throw r0     // Catch: java.lang.IllegalStateException -> L1f
        L1b:
            r0 = 0
            goto L32
        L1f:
            java.lang.IllegalStateException r0 = a(r0)     // Catch: java.lang.IllegalStateException -> L1f
            throw r0
        L23:
            java.util.Map r0 = me.frep.vulcan.spigot.Vulcan_kc.Vulcan_y
            r1 = r5
            java.lang.String r1 = r1.toLowerCase()
            java.lang.Object r0 = r0.get(r1)
        L2f:
            me.frep.vulcan.spigot.Vulcan_kc r0 = (me.frep.vulcan.spigot.Vulcan_kc) r0
        L32:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kc.Vulcan_r(java.lang.String):me.frep.vulcan.spigot.Vulcan_kc");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Vulcan_kc Vulcan_C(int i) {
        long j = (a ^ 132383123979717L) ^ 2869055623320L;
        Vulcan_kc[] vulcan_kcArr = Vulcan_s;
        Object[] objArr = new Object[2];
        objArr[1] = Integer.valueOf(i % Vulcan_s.length);
        vulcan_kcArr[0] = Long.valueOf(j);
        return objArr[Vulcan_Ov.Vulcan_F(objArr)];
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Vulcan_kc Vulcan_j(int i) {
        long j = (a ^ 52690925582172L) ^ 93556601018881L;
        Vulcan_kc[] vulcan_kcArr = Vulcan_p;
        Object[] objArr = new Object[2];
        objArr[1] = Integer.valueOf(i % Vulcan_p.length);
        vulcan_kcArr[0] = Long.valueOf(j);
        return objArr[Vulcan_Ov.Vulcan_F(objArr)];
    }

    public static Vulcan_kc Vulcan_l(Random random) {
        return values()[random.nextInt(values().length)];
    }

    public static Vulcan_kc Vulcan_g(float f, float f2, float f3) {
        long j = a ^ 12185962475586L;
        Vulcan_kc vulcan_kc = NORTH;
        float f4 = Float.MIN_VALUE;
        String[] strArrVulcan_J = Vulcan_fq.Vulcan_J();
        Vulcan_kc[] vulcan_kcArrValues = values();
        int length = vulcan_kcArrValues.length;
        int i = 0;
        while (i < length) {
            Vulcan_kc vulcan_kc2 = vulcan_kcArrValues[i];
            if (strArrVulcan_J != null) {
                return vulcan_kc2;
            }
            float fVulcan_s = (f * vulcan_kc2.Vulcan_x.Vulcan_s(new Object[0])) + (f2 * vulcan_kc2.Vulcan_x.Vulcan_y(new Object[0])) + (f3 * vulcan_kc2.Vulcan_x.Vulcan_L(new Object[0]));
            if (strArrVulcan_J == null) {
                if (fVulcan_s > f4) {
                    f4 = fVulcan_s;
                    vulcan_kc = vulcan_kc2;
                }
                i++;
            }
            if (strArrVulcan_J != null) {
                break;
            }
        }
        return vulcan_kc;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.Vulcan_d;
    }

    @Override // me.frep.vulcan.spigot.Vulcan_ya
    public String Vulcan_T() {
        return this.Vulcan_d;
    }

    public Vulcan_fq Vulcan_X() {
        return this.Vulcan_x;
    }
}
