package me.frep.vulcan.spigot.check.impl.player.fastbreak;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/fastbreak/FastBreakA.class */
@CheckInfo(name = "Fast Break", type = 'A', complexType = "Delay", description = "Breaking blocks too quickly.")
public class FastBreakA extends AbstractCheck {
    private long Vulcan_w;
    private static String[] Vulcan_r;
    private static final long b = Vulcan_n.a(986474822124748535L, 508309601312000841L, MethodHandles.lookup().lookupClass()).a(273366003013186L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00f8: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_V(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 316
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.Vulcan_V(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0261: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_X(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 648
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.Vulcan_X(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x006f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private boolean Vulcan_Q(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 734
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.Vulcan_Q(java.lang.Object[]):boolean");
    }

    public static void Vulcan_i(String[] strArr) {
        Vulcan_r = strArr;
    }

    public static String[] Vulcan_t() {
        return Vulcan_r;
    }

    static {
        int i;
        long j = b ^ 4497401348932L;
        Vulcan_i((String[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[17];
        int i3 = 0;
        String str = "Mó(¥ÇÃ\u009bò\u0010\u00adS\u009f\u0092¢}S½f\u000e\b²9ET&\bì\u009ft·\u0096W9O\u0010^ÕÁb\u001cDðíÞs\u001dì],°\u0002\u0010>ây»×ÜæÑJ#ô Vl\u009e>\u0018¹[`ÝrT\u0084tBËàõ\u0007N2\u008f\u0000¥ä\u0094. <û\b\t\rSÈèté<\b*\u00945à0/40\b\u0096JÒãæy\t7\u0010q\u001fRÈ,âz\u0006?»V3æFÅT\u0010µàÂ ,Ä\u0012\u007fhs0ºd&¡¢\b^Þ+jh\u0082\n/\b^\u000fÊ\u008d3ÃÏö\u0010T{Ý\u0004\u0006\u0087ù£\u0004X^OZÖ£ñ\b¢îºCÓÆ\u0091h";
        int length = "Mó(¥ÇÃ\u009bò\u0010\u00adS\u009f\u0092¢}S½f\u000e\b²9ET&\bì\u009ft·\u0096W9O\u0010^ÕÁb\u001cDðíÞs\u001dì],°\u0002\u0010>ây»×ÜæÑJ#ô Vl\u009e>\u0018¹[`ÝrT\u0084tBËàõ\u0007N2\u008f\u0000¥ä\u0094. <û\b\t\rSÈèté<\b*\u00945à0/40\b\u0096JÒãæy\t7\u0010q\u001fRÈ,âz\u0006?»V3æFÅT\u0010µàÂ ,Ä\u0012\u007fhs0ºd&¡¢\b^Þ+jh\u0082\n/\b^\u000fÊ\u008d3ÃÏö\u0010T{Ý\u0004\u0006\u0087ù£\u0004X^OZÖ£ñ\b¢îºCÓÆ\u0091h".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "ì\u009ft·\u0096W9O\bm]\u0014oø\u0000ºÝ";
                        length = "ì\u009ft·\u0096W9O\bm]\u0014oø\u0000ºÝ".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public FastBreakA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r3v9, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        PlayerInteractEvent playerInteractEvent = (Event) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 1867038331972L;
        long j2 = jLongValue ^ 139959038967261L;
        ?? Vulcan_t = Vulcan_t();
        try {
            Vulcan_t = this.Vulcan_b.Vulcan_e(new Object[0]);
            if (Vulcan_t == 0) {
                return;
            }
            try {
                try {
                    Vulcan_t = playerInteractEvent instanceof PlayerInteractEvent;
                    ?? r0 = Vulcan_t;
                    if (jLongValue > 0) {
                        r0 = Vulcan_t;
                        if (Vulcan_t == 0) {
                            if (Vulcan_t != 0) {
                                ?? r3 = new Object[2];
                                r3[1] = playerInteractEvent;
                                this[0] = Long.valueOf(j);
                                r3.Vulcan_V(r3);
                                return;
                            }
                            r0 = playerInteractEvent instanceof BlockBreakEvent;
                        }
                    }
                    if (r0 != 0) {
                        try {
                            Object[] objArr2 = new Object[2];
                            objArr2[1] = (BlockBreakEvent) playerInteractEvent;
                            r0 = objArr2;
                            this[0] = Long.valueOf(j2);
                            r0.Vulcan_X(objArr2);
                        } catch (RuntimeException unused) {
                            throw a((RuntimeException) r0);
                        }
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) Vulcan_t);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) Vulcan_t);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) Vulcan_t);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:19:0x0065
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_r(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            org.bukkit.entity.Player r1 = (org.bukkit.entity.Player) r1
            r9 = r1
            long r0 = me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.b
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            java.lang.String[] r0 = Vulcan_t()
            r12 = r0
            r0 = r9
            org.bukkit.inventory.PlayerInventory r0 = r0.getInventory()     // Catch: java.lang.RuntimeException -> L43
            org.bukkit.inventory.ItemStack r0 = r0.getItemInHand()     // Catch: java.lang.RuntimeException -> L43
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.RuntimeException -> L43
            java.lang.String r0 = r0.name()     // Catch: java.lang.RuntimeException -> L43
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.d     // Catch: java.lang.RuntimeException -> L43
            r2 = 15
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L43
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L43
            r1 = r12
            if (r1 != 0) goto L54
            if (r0 == 0) goto L4d
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0     // Catch: java.lang.RuntimeException -> L49
        L47:
            r0 = 1
            return r0
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0
        L4d:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)
        L54:
            r1 = r12
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L8b
            if (r1 != 0) goto L89
            if (r0 == 0) goto L9c
            goto L69
        L65:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L85
            throw r0     // Catch: java.lang.RuntimeException -> L85
        L69:
            r0 = r9
            org.bukkit.inventory.PlayerInventory r0 = r0.getInventory()     // Catch: java.lang.RuntimeException -> L85
            org.bukkit.inventory.ItemStack r0 = r0.getItemInOffHand()     // Catch: java.lang.RuntimeException -> L85
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.RuntimeException -> L85
            java.lang.String r0 = r0.name()     // Catch: java.lang.RuntimeException -> L85
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.d     // Catch: java.lang.RuntimeException -> L85
            r2 = 2
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L85
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L85
            goto L89
        L85:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L89:
            r1 = r12
        L8b:
            if (r1 != 0) goto L99
            if (r0 == 0) goto L9c
            goto L98
        L94:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L98:
            r0 = 1
        L99:
            goto L9d
        L9c:
            r0 = 0
        L9d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.Vulcan_r(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00dc  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v41, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean Vulcan_n(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 233
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.fastbreak.FastBreakA.Vulcan_n(java.lang.Object[]):boolean");
    }
}
