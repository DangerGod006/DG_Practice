package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fC.class */
class Vulcan_fC {
    private final HashMap Vulcan_T;
    final C0055Vulcan_ky Vulcan_R;
    private static final long a = Vulcan_n.a(-709447907680604854L, -3866615431805127176L, MethodHandles.lookup().lookupClass()).a(85882588816124L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private Vulcan_fC(C0055Vulcan_ky c0055Vulcan_ky) {
        this.Vulcan_R = c0055Vulcan_ky;
        this.Vulcan_T = new HashMap();
    }

    Vulcan_fC(C0055Vulcan_ky c0055Vulcan_ky, Vulcan_fs vulcan_fs) {
        this(c0055Vulcan_ky);
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    void Vulcan_D(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        Object obj = objArr[2];
        long j = a ^ jLongValue;
        ?? Vulcan_D = C0055Vulcan_ky.Vulcan_D();
        try {
            if (Vulcan_D != 0 && obj != null) {
                this.Vulcan_T.put(str, obj);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_D);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockSplitter
        jadx.core.utils.exceptions.JadxRuntimeException: Unexpected missing predecessor for block: B:8:0x0076
        	at jadx.core.dex.visitors.blocks.BlockSplitter.addTempConnectionsForExcHandlers(BlockSplitter.java:280)
        	at jadx.core.dex.visitors.blocks.BlockSplitter.visit(BlockSplitter.java:79)
        */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 519
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fC.toString():java.lang.String");
    }

    private String Vulcan_t(Object[] objArr) {
        return "\"" + ((String) objArr[0]) + "\"";
    }
}
