package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OJ.class */
class Vulcan_OJ {
    private String Vulcan_i;
    private String Vulcan_y;
    final Vulcan_kZ Vulcan_h;

    static String Vulcan_v(Object[] objArr) {
        return ((Vulcan_OJ) objArr[0]).Vulcan_e(new Object[0]);
    }

    static String Vulcan_F(Object[] objArr) {
        return ((Vulcan_OJ) objArr[0]).Vulcan_J(new Object[0]);
    }

    Vulcan_OJ(Vulcan_kZ vulcan_kZ, String str, String str2, Vulcan_fs vulcan_fs) {
        this(vulcan_kZ, str, str2);
    }

    private Vulcan_OJ(Vulcan_kZ vulcan_kZ, String str, String str2) {
        this.Vulcan_h = vulcan_kZ;
        this.Vulcan_i = str;
        this.Vulcan_y = str2;
    }

    private String Vulcan_e(Object[] objArr) {
        return this.Vulcan_i;
    }

    private String Vulcan_J(Object[] objArr) {
        return this.Vulcan_y;
    }
}
