package me.frep.vulcan.spigot;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_y8.class */
class Vulcan_y8 {
    private String Vulcan_Q;
    final Vulcan_kZ Vulcan_u;

    static String Vulcan_d(Object[] objArr) {
        return ((Vulcan_y8) objArr[0]).Vulcan_V(new Object[0]);
    }

    Vulcan_y8(Vulcan_kZ vulcan_kZ, String str, Vulcan_fs vulcan_fs) {
        this(vulcan_kZ, str);
    }

    private Vulcan_y8(Vulcan_kZ vulcan_kZ, String str) {
        this.Vulcan_u = vulcan_kZ;
        this.Vulcan_Q = str;
    }

    private String Vulcan_V(Object[] objArr) {
        return this.Vulcan_Q;
    }
}
