package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_O8;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerAbilities;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerTeleportEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ka.class */
public class Vulcan_ka {
    private final C0042Vulcan_Oz Vulcan_g6;
    private boolean Vulcan_T_;
    private boolean Vulcan_vl;
    private boolean Vulcan_Nb;
    private boolean Vulcan_H;
    private boolean Vulcan_NZ;
    private boolean Vulcan_vk;
    private boolean Vulcan_TC;
    private boolean Vulcan_NR;
    private boolean Vulcan_Y;
    private boolean Vulcan_g1;
    private boolean Vulcan_TI;
    private boolean Vulcan_TO;
    private boolean Vulcan_j;
    private boolean Vulcan_gD;
    private boolean Vulcan_vy;
    private boolean Vulcan_vW;
    private boolean Vulcan_g5;
    private boolean Vulcan_Nx;
    private boolean Vulcan_gu;
    private boolean Vulcan_v3;
    private boolean Vulcan_gv;
    private boolean Vulcan_No;
    private boolean Vulcan_vc;
    private boolean Vulcan_N9;
    private boolean Vulcan_Q;
    private boolean Vulcan_gL;
    private boolean Vulcan_To;
    private boolean Vulcan_c;
    private boolean Vulcan_gF;
    private boolean Vulcan_a;
    private boolean Vulcan_vJ;
    private boolean Vulcan_v2;
    private boolean Vulcan_vg;
    private boolean Vulcan_gW;
    private boolean Vulcan_gj;
    private boolean Vulcan_NK;
    private boolean Vulcan_Np;
    private boolean Vulcan_vr;
    private boolean Vulcan_gU;
    private boolean Vulcan_vK;
    private boolean Vulcan_vY;
    private boolean Vulcan_TH;
    private boolean Vulcan_vR;
    private boolean Vulcan_T4;
    private boolean Vulcan_e;
    private boolean Vulcan_F;
    private boolean Vulcan_TS;
    private boolean Vulcan_NQ;
    private boolean Vulcan_q;
    private boolean Vulcan_M;
    private boolean Vulcan_Nj;
    private boolean Vulcan__;
    private boolean Vulcan_Ta;
    private boolean Vulcan_gX;
    private boolean Vulcan_Tk;
    private boolean Vulcan_k;
    private boolean Vulcan_TF;
    private boolean Vulcan_Tj;
    private boolean Vulcan_B;
    private boolean Vulcan_N7;
    private boolean Vulcan_gk;
    private boolean Vulcan_g4;
    private boolean Vulcan_Nw;
    private boolean Vulcan_vd;
    private boolean Vulcan_go;
    private boolean Vulcan_Ns;
    private boolean Vulcan_g9;
    private boolean Vulcan_O;
    private boolean Vulcan_TJ;
    private boolean Vulcan_J;
    private boolean Vulcan_Tm;
    private boolean Vulcan_NB;
    private boolean Vulcan_d;
    private boolean Vulcan_gA;
    private boolean Vulcan_TT;
    private boolean Vulcan_vU;
    private boolean Vulcan_vb;
    private boolean Vulcan_T9;
    private boolean Vulcan_g2;
    private boolean Vulcan_vT;
    private boolean Vulcan_S;
    private boolean Vulcan_v6;
    private boolean Vulcan_vM;
    private boolean Vulcan_TG;
    private boolean Vulcan_Tl;
    private boolean Vulcan_gM;
    private boolean Vulcan_TZ;
    private boolean Vulcan_vP;
    private boolean Vulcan_TK;
    private boolean Vulcan_N4;
    private boolean Vulcan_NT;
    private boolean Vulcan_V;
    private boolean Vulcan_v5;
    private boolean Vulcan_T1;
    private boolean Vulcan_gr;
    private boolean Vulcan_T5;
    private boolean Vulcan_gf;
    private boolean Vulcan_gn;
    private boolean Vulcan_v0;
    private boolean Vulcan_NN;
    private boolean Vulcan_gq;
    private boolean Vulcan_g7;
    private boolean Vulcan_gK;
    private boolean Vulcan_vO;
    private boolean Vulcan_gx;
    private boolean Vulcan_gy;
    private boolean Vulcan_TD;
    private Location Vulcan_Tx;
    private Location Vulcan_vw;
    public boolean Vulcan_E;
    public List Vulcan_vD;
    private Material Vulcan_vv;
    private Material Vulcan_L;
    private Material Vulcan_vA;
    private List Vulcan_gB;
    private List Vulcan_gG;
    private List Vulcan_h;
    private List Vulcan_Nf;
    private List Vulcan_TW;
    public List Vulcan_TQ;
    public List Vulcan_vH;
    public List Vulcan_Nr;
    public Material Vulcan_NJ;
    public Material Vulcan_u;
    public Material Vulcan_va;
    private double Vulcan_vC;
    private double Vulcan_Tz;
    private double Vulcan_Te;
    private double Vulcan_Th;
    private double Vulcan_Tp;
    private double Vulcan_vf;
    private double Vulcan_v1;
    private double Vulcan_vF;
    private double Vulcan_TP;
    private double Vulcan_gc;
    private double Vulcan_Tf;
    private double Vulcan_g8;
    private double Vulcan_Ty;
    private double Vulcan_gP;
    private double Vulcan_ga;
    private double Vulcan_T7;
    private double Vulcan_t;
    private double Vulcan_x;
    private double Vulcan_Tv;
    private double Vulcan_Tr;
    private double Vulcan_vL;
    private double Vulcan_gb;
    private double Vulcan_gJ;
    private double Vulcan_Nk;
    private double Vulcan_gi;
    private double Vulcan_Ti;
    private double Vulcan_Tq;
    private double Vulcan_g3;
    private double Vulcan_TE;
    private double Vulcan_i;
    private double Vulcan_U;
    private double Vulcan_gC;
    private double Vulcan_Tn;
    private double Vulcan_gV;
    private double Vulcan_Z;
    private double Vulcan_g;
    private double Vulcan_X;
    private double Vulcan_ge;
    private double Vulcan_r;
    private double Vulcan_y;
    private double Vulcan_N6;
    private double Vulcan_Nh;
    private double Vulcan_v8;
    private double Vulcan_vt;
    private double Vulcan_gE;
    private double Vulcan_TB;
    private double Vulcan_vp;
    private int Vulcan_Td;
    private int Vulcan_vu;
    private int Vulcan_gZ;
    private int Vulcan_gw;
    private int Vulcan_v4;
    private int Vulcan_Tu;
    private int Vulcan_N8;
    private int Vulcan_P;
    private int Vulcan_Ni;
    private int Vulcan_gs;
    private int Vulcan_vo;
    private int Vulcan_l;
    private int Vulcan_b;
    private int Vulcan_f;
    private int Vulcan_Nm;
    private int Vulcan_gN;
    private int Vulcan_gQ;
    private int Vulcan_Ts;
    private int Vulcan_Tg;
    private int Vulcan_TX;
    private World Vulcan_vm;
    private Entity Vulcan_TU;
    private Entity Vulcan_R;
    private boolean Vulcan_gm;
    private boolean Vulcan_ve;
    private boolean Vulcan_T6;
    private boolean Vulcan_z;
    private boolean Vulcan_v9;
    private boolean Vulcan_vX;
    private boolean Vulcan_Tt;
    private boolean Vulcan_w;
    private boolean Vulcan_vn;
    private boolean Vulcan_NF;
    private boolean Vulcan_vZ;
    private boolean Vulcan_TY;
    private boolean Vulcan_Nu;
    private boolean Vulcan_v7;
    private boolean Vulcan_T8;
    private boolean Vulcan_TR;
    private boolean Vulcan_T3;
    private static String[] Vulcan_vQ;
    private static final long a = Vulcan_n.a(8788834652848703900L, -4882053135946480140L, MethodHandles.lookup().lookupClass()).a(100353320035196L);
    private static final String[] b;
    private final Map Vulcan_gT = new HashMap();
    private int Vulcan_gI = 100;
    private int Vulcan_G = 100;
    private int Vulcan_TL = 100;
    private int Vulcan_n = Vulcan_O8.Vulcan_z;
    private int Vulcan_vs = 100;
    private int Vulcan_Tc = 200;
    private int Vulcan_gl = 100;
    private int Vulcan_NG = 100;
    private int Vulcan_TA = 100;
    private int Vulcan_vS = 100;
    private int Vulcan_K = 100;
    private int Vulcan_vE = 100;
    private int Vulcan_gh = 100;
    private int Vulcan_TV = 100;
    private int Vulcan_gY = 100;
    private int Vulcan_gp = 100;
    private int Vulcan_s = 100;
    private int Vulcan_vx = 100;
    private int Vulcan_W = 100;
    private int Vulcan_p = 100;
    private int Vulcan_v = 200;
    private int Vulcan_vz = 100;
    private int Vulcan_gH = 100;
    private int Vulcan_g0 = 100;
    private int Vulcan_vB = 500;
    private int Vulcan_gd = 500;
    private int Vulcan_g_ = 500;
    private int Vulcan_N5 = 150;
    private int Vulcan_v_ = 150;
    private int Vulcan_m = 150;
    private int Vulcan_gS = 100;
    private int Vulcan_Tw = 500;
    private int Vulcan_vq = 100;
    private int Vulcan_NU = 100;
    private int Vulcan_o = 100;
    private int Vulcan_TM = 100;
    private int Vulcan_vj = 100;
    private int Vulcan_T2 = Vulcan_O8.Vulcan_z;
    private int Vulcan_vh = 100;
    private int Vulcan_gt = 200;
    private int Vulcan_Tb = 100;
    private int Vulcan_TN = Vulcan_O8.Vulcan_z;
    private int Vulcan_gz = Vulcan_O8.Vulcan_z;
    private int Vulcan_NV = Vulcan_O8.Vulcan_z;
    private int Vulcan_vG = Vulcan_O8.Vulcan_z;
    private int Vulcan_D = 0;
    private int Vulcan_gg = Vulcan_O8.Vulcan_z;
    private int Vulcan_T0 = 100;
    private int Vulcan_NP = Vulcan_O8.Vulcan_z;
    private int Vulcan_A = 100;
    private int Vulcan_N = 100;
    private int Vulcan_gO = 100;
    private int Vulcan_T = 100;
    private int Vulcan_vI = 100;
    private int Vulcan_I = 100;
    private int Vulcan_gR = Vulcan_O8.Vulcan_z;
    private int Vulcan_vi = 100;
    private int Vulcan_Nl = 0;
    private float Vulcan_vV = 0.2f;
    private float Vulcan_C = 0.2f;
    private List Vulcan_Ne = new ArrayList();
    private LinkedList Vulcan_vN = new LinkedList();

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0139: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_ah(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 763
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_ah(java.lang.Object[]):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: JadxRuntimeException: Failed to decode insn: 0x01FE: MOVE_MULTI in method: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_d(java.lang.Object[]):void, file: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ka.class
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:175)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Failed to decode insn: 0x01FE: MOVE_MULTI
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:57)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	... 6 more
        Caused by: java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -3 out of bounds for object array[13]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:304)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	... 9 more
        */
    private void Vulcan_d(java.lang.Object[] r1) {
        /*
            Method dump skipped, instruction units count: 979
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_d(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x06da: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_aj(java.lang.Object[] r49) {
        /*
            Method dump skipped, instruction units count: 2153
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_aj(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x01ab: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_ZB(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 1589
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_ZB(java.lang.Object[]):void");
    }

    /*  JADX ERROR: Failed to decode insn: 0x1341: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[9]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:313)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public void Vulcan_ag(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 5208
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_ag(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x005f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private void Vulcan_ao(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 1561
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_ao(java.lang.Object[]):void");
    }

    /*  JADX ERROR: Failed to decode insn: 0x01B0: MOVE_MULTI
        java.lang.ArrayIndexOutOfBoundsException: arraycopy: source index -1 out of bounds for object array[14]
        	at java.base/java.lang.System.arraycopy(Native Method)
        	at jadx.plugins.input.java.data.code.StackState.insert(StackState.java:52)
        	at jadx.plugins.input.java.data.code.CodeDecodeState.insert(CodeDecodeState.java:137)
        	at jadx.plugins.input.java.data.code.JavaInsnsRegister.dup2x1(JavaInsnsRegister.java:313)
        	at jadx.plugins.input.java.data.code.JavaInsnData.decode(JavaInsnData.java:46)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:50)
        	at jadx.plugins.input.java.data.code.JavaCodeReader.visitInstructions(JavaCodeReader.java:85)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:118)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public void Vulcan_aV(java.lang.Object[] r15) {
        /*
            Method dump skipped, instruction units count: 851
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_aV(java.lang.Object[]):void");
    }

    public static void Vulcan_H(String[] strArr) {
        Vulcan_vQ = strArr;
    }

    public static String[] Vulcan_T() {
        return Vulcan_vQ;
    }

    static {
        int i;
        long j = a ^ 64686796620484L;
        Vulcan_H(new String[4]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[18];
        int i3 = 0;
        String str = "ÊU¯\u009c\u008f\rP8 \u0005T\u008bQôØ\u0003d\u0017omYp©6=/\"ä\u0090\u0094\u00ad±´.¾6ÃdÂï\u0092\btH÷Ûv£Ìã\u0010üg\u00005dâVé4ÊxåîYÊu\b\u0003\rå\u00adW\u0096±%\bÜH<ÃÒI[\u0018\b\u0003\rå\u00adW\u0096±%\btH÷Ûv£Ìã\u0010\u0083Þð¦®é\u0006?\fZ¥U\u00adÿ÷±\b+÷\u001b¡ð5s\r\bÊU¯\u009c\u008f\rP8\b+÷\u001b¡ð5s\r\b92\u008c&\u0001°Ó\u0000\u0010\tî\u0006\u000b\u0090\u00196\u0017\u0093\u009f®\u0013Í\br¹\bÜH<ÃÒI[\u0018\u0010\tî\u0006\u000b\u0090\u00196\u0017\u0093\u009f®\u0013Í\br¹";
        int length = "ÊU¯\u009c\u008f\rP8 \u0005T\u008bQôØ\u0003d\u0017omYp©6=/\"ä\u0090\u0094\u00ad±´.¾6ÃdÂï\u0092\btH÷Ûv£Ìã\u0010üg\u00005dâVé4ÊxåîYÊu\b\u0003\rå\u00adW\u0096±%\bÜH<ÃÒI[\u0018\b\u0003\rå\u00adW\u0096±%\btH÷Ûv£Ìã\u0010\u0083Þð¦®é\u0006?\fZ¥U\u00adÿ÷±\b+÷\u001b¡ð5s\r\bÊU¯\u009c\u008f\rP8\b+÷\u001b¡ð5s\r\b92\u008c&\u0001°Ó\u0000\u0010\tî\u0006\u000b\u0090\u00196\u0017\u0093\u009f®\u0013Í\br¹\bÜH<ÃÒI[\u0018\u0010\tî\u0006\u000b\u0090\u00196\u0017\u0093\u009f®\u0013Í\br¹".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = ";|£LBãô\u00ad\u0010\u0083Þð¦®é\u0006?\fZ¥U\u00adÿ÷±";
                        length = ";|£LBãô\u00ad\u0010\u0083Þð¦®é\u0006?\fZ¥U\u00adÿ÷±".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_KY(Object[] objArr) {
        this.Vulcan_T_ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VR(Object[] objArr) {
        this.Vulcan_vl = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kw(Object[] objArr) {
        this.Vulcan_Nb = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K9(Object[] objArr) {
        this.Vulcan_H = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VO(Object[] objArr) {
        this.Vulcan_NZ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KM(Object[] objArr) {
        this.Vulcan_vk = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public void m1003Vulcan_X(Object[] objArr) {
        this.Vulcan_TC = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KU(Object[] objArr) {
        this.Vulcan_NR = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VD(Object[] objArr) {
        this.Vulcan_Y = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ko(Object[] objArr) {
        this.Vulcan_g1 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VZ(Object[] objArr) {
        this.Vulcan_TI = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vb(Object[] objArr) {
        this.Vulcan_TO = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KJ(Object[] objArr) {
        this.Vulcan_j = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public void m1004Vulcan_c(Object[] objArr) {
        this.Vulcan_gD = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_V9(Object[] objArr) {
        this.Vulcan_vy = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public void m1005Vulcan_v(Object[] objArr) {
        this.Vulcan_vW = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_V5(Object[] objArr) {
        this.Vulcan_g5 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K7(Object[] objArr) {
        this.Vulcan_Nx = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ks(Object[] objArr) {
        this.Vulcan_gu = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KD(Object[] objArr) {
        this.Vulcan_v3 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kp(Object[] objArr) {
        this.Vulcan_gv = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K3(Object[] objArr) {
        this.Vulcan_No = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_V2(Object[] objArr) {
        this.Vulcan_vc = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public void m1006Vulcan_O(Object[] objArr) {
        this.Vulcan_N9 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kl(Object[] objArr) {
        this.Vulcan_Q = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VP(Object[] objArr) {
        this.Vulcan_gL = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ke(Object[] objArr) {
        this.Vulcan_To = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KW(Object[] objArr) {
        this.Vulcan_c = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public void m1007Vulcan_V(Object[] objArr) {
        this.Vulcan_gF = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vm(Object[] objArr) {
        this.Vulcan_a = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VQ(Object[] objArr) {
        this.Vulcan_vJ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Va(Object[] objArr) {
        this.Vulcan_v2 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vr(Object[] objArr) {
        this.Vulcan_vg = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public void m1008Vulcan_E(Object[] objArr) {
        this.Vulcan_gW = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public void m1009Vulcan_B(Object[] objArr) {
        this.Vulcan_gj = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Km(Object[] objArr) {
        this.Vulcan_NK = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K0(Object[] objArr) {
        this.Vulcan_Np = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kf(Object[] objArr) {
        this.Vulcan_vr = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vo(Object[] objArr) {
        this.Vulcan_gU = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KA(Object[] objArr) {
        this.Vulcan_vK = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VM(Object[] objArr) {
        this.Vulcan_vY = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KC(Object[] objArr) {
        this.Vulcan_TH = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KP(Object[] objArr) {
        this.Vulcan_vR = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public void m1010Vulcan_y(Object[] objArr) {
        this.Vulcan_T4 = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public void m1011Vulcan_u(Object[] objArr) {
        this.Vulcan_e = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K1(Object[] objArr) {
        this.Vulcan_F = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public void m1012Vulcan_r(Object[] objArr) {
        this.Vulcan_TS = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public void m1013Vulcan_A(Object[] objArr) {
        this.Vulcan_NQ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VH(Object[] objArr) {
        this.Vulcan_q = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kt(Object[] objArr) {
        this.Vulcan_M = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kx(Object[] objArr) {
        this.Vulcan_Nj = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vd(Object[] objArr) {
        this.Vulcan__ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KS(Object[] objArr) {
        this.Vulcan_Ta = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public void m1014Vulcan_f(Object[] objArr) {
        this.Vulcan_gX = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KE(Object[] objArr) {
        this.Vulcan_Tk = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ki(Object[] objArr) {
        this.Vulcan_k = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K2(Object[] objArr) {
        this.Vulcan_TF = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K6(Object[] objArr) {
        this.Vulcan_Tj = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kk(Object[] objArr) {
        this.Vulcan_B = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public void m1015Vulcan_b(Object[] objArr) {
        this.Vulcan_N7 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ku(Object[] objArr) {
        this.Vulcan_gk = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public void m1016Vulcan_D(Object[] objArr) {
        this.Vulcan_g4 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vf(Object[] objArr) {
        this.Vulcan_Nw = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public void m1017Vulcan__(Object[] objArr) {
        this.Vulcan_vd = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vs(Object[] objArr) {
        this.Vulcan_go = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public void m1018Vulcan_h(Object[] objArr) {
        this.Vulcan_Ns = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VA(Object[] objArr) {
        this.Vulcan_g9 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VB(Object[] objArr) {
        this.Vulcan_O = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VI(Object[] objArr) {
        this.Vulcan_TJ = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public void m1019Vulcan_Q(Object[] objArr) {
        this.Vulcan_J = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_V1(Object[] objArr) {
        this.Vulcan_Tm = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KL(Object[] objArr) {
        this.Vulcan_NB = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kv(Object[] objArr) {
        this.Vulcan_d = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public void m1020Vulcan_z(Object[] objArr) {
        this.Vulcan_gA = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vi(Object[] objArr) {
        this.Vulcan_TT = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KV(Object[] objArr) {
        this.Vulcan_vU = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kq(Object[] objArr) {
        this.Vulcan_vb = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public void m1021Vulcan_L(Object[] objArr) {
        this.Vulcan_T9 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vn(Object[] objArr) {
        this.Vulcan_g2 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K5(Object[] objArr) {
        this.Vulcan_vT = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KN(Object[] objArr) {
        this.Vulcan_S = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ky(Object[] objArr) {
        this.Vulcan_v6 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VV(Object[] objArr) {
        this.Vulcan_vM = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KI(Object[] objArr) {
        this.Vulcan_TG = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ka(Object[] objArr) {
        this.Vulcan_Tl = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kh(Object[] objArr) {
        this.Vulcan_gM = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kd(Object[] objArr) {
        this.Vulcan_TZ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VX(Object[] objArr) {
        this.Vulcan_vP = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public void m1022Vulcan_g(Object[] objArr) {
        this.Vulcan_TK = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kb(Object[] objArr) {
        this.Vulcan_N4 = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public void m1023Vulcan_K(Object[] objArr) {
        this.Vulcan_NT = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KR(Object[] objArr) {
        this.Vulcan_V = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_V_(Object[] objArr) {
        this.Vulcan_v5 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kc(Object[] objArr) {
        this.Vulcan_T1 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K_(Object[] objArr) {
        this.Vulcan_gr = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kr(Object[] objArr) {
        this.Vulcan_T5 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kj(Object[] objArr) {
        this.Vulcan_gf = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VS(Object[] objArr) {
        this.Vulcan_gn = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KT(Object[] objArr) {
        this.Vulcan_v0 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kz(Object[] objArr) {
        this.Vulcan_NN = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VL(Object[] objArr) {
        this.Vulcan_gq = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vc(Object[] objArr) {
        this.Vulcan_g7 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KF(Object[] objArr) {
        this.Vulcan_gK = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KZ(Object[] objArr) {
        this.Vulcan_vO = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K4(Object[] objArr) {
        this.Vulcan_gx = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K8(Object[] objArr) {
        this.Vulcan_gy = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kg(Object[] objArr) {
        this.Vulcan_TD = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_xJ, reason: collision with other method in class */
    public void m1024Vulcan_xJ(Object[] objArr) {
        this.Vulcan_Tx = (Location) objArr[0];
    }

    public void Vulcan_xm(Object[] objArr) {
        this.Vulcan_vw = (Location) objArr[0];
    }

    public void Vulcan_S8(Object[] objArr) {
        this.Vulcan_vv = (Material) objArr[0];
    }

    public void Vulcan_Sv(Object[] objArr) {
        this.Vulcan_L = (Material) objArr[0];
    }

    public void Vulcan_Sp(Object[] objArr) {
        this.Vulcan_vA = (Material) objArr[0];
    }

    public void Vulcan__K(Object[] objArr) {
        this.Vulcan_gB = (List) objArr[0];
    }

    public void Vulcan__s(Object[] objArr) {
        this.Vulcan_gG = (List) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public void m1025Vulcan_s(Object[] objArr) {
        this.Vulcan_h = (List) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public void m1026Vulcan_p(Object[] objArr) {
        this.Vulcan_Nf = (List) objArr[0];
    }

    public void Vulcan__i(Object[] objArr) {
        this.Vulcan_TW = (List) objArr[0];
    }

    public void Vulcan_Jl(Object[] objArr) {
        this.Vulcan_vC = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JN(Object[] objArr) {
        this.Vulcan_Tz = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jv(Object[] objArr) {
        this.Vulcan_Te = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jg(Object[] objArr) {
        this.Vulcan_Th = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public void m1027Vulcan_J(Object[] objArr) {
        this.Vulcan_Tp = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J6(Object[] objArr) {
        this.Vulcan_vf = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jj(Object[] objArr) {
        this.Vulcan_v1 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ji(Object[] objArr) {
        this.Vulcan_vF = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public void m1028Vulcan_Z(Object[] objArr) {
        this.Vulcan_TP = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jt(Object[] objArr) {
        this.Vulcan_gc = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jo(Object[] objArr) {
        this.Vulcan_Tf = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J5(Object[] objArr) {
        this.Vulcan_g8 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JH(Object[] objArr) {
        this.Vulcan_Ty = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J8(Object[] objArr) {
        this.Vulcan_gP = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JF(Object[] objArr) {
        this.Vulcan_ga = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Je(Object[] objArr) {
        this.Vulcan_T7 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J4(Object[] objArr) {
        this.Vulcan_t = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JE(Object[] objArr) {
        this.Vulcan_x = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JT(Object[] objArr) {
        this.Vulcan_Tv = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J3(Object[] objArr) {
        this.Vulcan_Tr = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JI(Object[] objArr) {
        this.Vulcan_vL = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JS(Object[] objArr) {
        this.Vulcan_gb = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JQ(Object[] objArr) {
        this.Vulcan_gJ = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ja(Object[] objArr) {
        this.Vulcan_Nk = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JB(Object[] objArr) {
        this.Vulcan_gi = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jr(Object[] objArr) {
        this.Vulcan_Ti = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jd(Object[] objArr) {
        this.Vulcan_Tq = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J7(Object[] objArr) {
        this.Vulcan_g3 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JL(Object[] objArr) {
        this.Vulcan_TE = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JG(Object[] objArr) {
        this.Vulcan_i = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JM(Object[] objArr) {
        this.Vulcan_U = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jf(Object[] objArr) {
        this.Vulcan_gC = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J2(Object[] objArr) {
        this.Vulcan_Tn = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jc(Object[] objArr) {
        this.Vulcan_gV = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J0(Object[] objArr) {
        this.Vulcan_Z = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JK(Object[] objArr) {
        this.Vulcan_g = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JJ(Object[] objArr) {
        this.Vulcan_X = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Ju(Object[] objArr) {
        this.Vulcan_ge = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public void m1029Vulcan_x(Object[] objArr) {
        this.Vulcan_r = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jn(Object[] objArr) {
        this.Vulcan_y = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Js(Object[] objArr) {
        this.Vulcan_N6 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jb(Object[] objArr) {
        this.Vulcan_Nh = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jy(Object[] objArr) {
        this.Vulcan_v8 = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_Jp(Object[] objArr) {
        this.Vulcan_vt = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_JU(Object[] objArr) {
        this.Vulcan_gE = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J_(Object[] objArr) {
        this.Vulcan_TB = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_J9(Object[] objArr) {
        this.Vulcan_vp = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_UN(Object[] objArr) {
        this.Vulcan_gI = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UO(Object[] objArr) {
        this.Vulcan_G = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public void m1030Vulcan_w(Object[] objArr) {
        this.Vulcan_TL = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uw(Object[] objArr) {
        this.Vulcan_Td = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uz(Object[] objArr) {
        this.Vulcan_vu = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U3(Object[] objArr) {
        this.Vulcan_n = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uq(Object[] objArr) {
        this.Vulcan_vs = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UT(Object[] objArr) {
        this.Vulcan_Tc = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UV(Object[] objArr) {
        this.Vulcan_gl = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public void m1031Vulcan_C(Object[] objArr) {
        this.Vulcan_gZ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uh(Object[] objArr) {
        this.Vulcan_NG = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U2(Object[] objArr) {
        this.Vulcan_TA = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public void m1032Vulcan_R(Object[] objArr) {
        this.Vulcan_vS = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public void m1033Vulcan_n(Object[] objArr) {
        this.Vulcan_gw = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Up(Object[] objArr) {
        this.Vulcan_K = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_US(Object[] objArr) {
        this.Vulcan_v4 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UI(Object[] objArr) {
        this.Vulcan_Tu = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U0(Object[] objArr) {
        this.Vulcan_vE = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ud(Object[] objArr) {
        this.Vulcan_gh = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public void m1034Vulcan_T(Object[] objArr) {
        this.Vulcan_N8 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U7(Object[] objArr) {
        this.Vulcan_TV = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ue(Object[] objArr) {
        this.Vulcan_gY = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U1(Object[] objArr) {
        this.Vulcan_gp = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public void m1035Vulcan_N(Object[] objArr) {
        this.Vulcan_s = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uj(Object[] objArr) {
        this.Vulcan_vx = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UC(Object[] objArr) {
        this.Vulcan_W = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public void m1036Vulcan_W(Object[] objArr) {
        this.Vulcan_p = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ui(Object[] objArr) {
        this.Vulcan_P = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UH(Object[] objArr) {
        this.Vulcan_Ni = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U5(Object[] objArr) {
        this.Vulcan_v = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public void m1037Vulcan_e(Object[] objArr) {
        this.Vulcan_vz = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public void m1038Vulcan_o(Object[] objArr) {
        this.Vulcan_gH = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UE(Object[] objArr) {
        this.Vulcan_gs = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UL(Object[] objArr) {
        this.Vulcan_g0 = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public void m1039Vulcan_H(Object[] objArr) {
        this.Vulcan_vo = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U8(Object[] objArr) {
        this.Vulcan_vB = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ur(Object[] objArr) {
        this.Vulcan_gd = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ut(Object[] objArr) {
        this.Vulcan_g_ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U_(Object[] objArr) {
        this.Vulcan_N5 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UF(Object[] objArr) {
        this.Vulcan_v_ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UA(Object[] objArr) {
        this.Vulcan_m = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UK(Object[] objArr) {
        this.Vulcan_l = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uo(Object[] objArr) {
        this.Vulcan_b = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ub(Object[] objArr) {
        this.Vulcan_f = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UX(Object[] objArr) {
        this.Vulcan_Nm = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ul(Object[] objArr) {
        this.Vulcan_gS = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public void m1040Vulcan_i(Object[] objArr) {
        this.Vulcan_Tw = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public void m1041Vulcan_U(Object[] objArr) {
        this.Vulcan_gN = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UM(Object[] objArr) {
        this.Vulcan_gQ = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ux(Object[] objArr) {
        this.Vulcan_vq = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U9(Object[] objArr) {
        this.Vulcan_NU = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UJ(Object[] objArr) {
        this.Vulcan_Ts = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public void m1042Vulcan_q(Object[] objArr) {
        this.Vulcan_o = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ug(Object[] objArr) {
        this.Vulcan_Tg = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Us(Object[] objArr) {
        this.Vulcan_TX = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UP(Object[] objArr) {
        this.Vulcan_TM = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UZ(Object[] objArr) {
        this.Vulcan_vj = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uc(Object[] objArr) {
        this.Vulcan_T2 = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public void m1043Vulcan_G(Object[] objArr) {
        this.Vulcan_vh = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uv(Object[] objArr) {
        this.Vulcan_gt = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UU(Object[] objArr) {
        this.Vulcan_Tb = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Ua(Object[] objArr) {
        this.Vulcan_TN = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public void m1044Vulcan_k(Object[] objArr) {
        this.Vulcan_gz = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uk(Object[] objArr) {
        this.Vulcan_NV = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UY(Object[] objArr) {
        this.Vulcan_vG = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Un(Object[] objArr) {
        this.Vulcan_D = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public void m1045Vulcan_l(Object[] objArr) {
        this.Vulcan_gg = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UR(Object[] objArr) {
        this.Vulcan_T0 = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Um(Object[] objArr) {
        this.Vulcan_NP = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uf(Object[] objArr) {
        this.Vulcan_A = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UW(Object[] objArr) {
        this.Vulcan_N = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U4(Object[] objArr) {
        this.Vulcan_gO = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public void m1046Vulcan_P(Object[] objArr) {
        this.Vulcan_T = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_Uy(Object[] objArr) {
        this.Vulcan_vI = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public void m1047Vulcan_m(Object[] objArr) {
        this.Vulcan_I = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UB(Object[] objArr) {
        this.Vulcan_gR = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_U6(Object[] objArr) {
        this.Vulcan_vi = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_UQ(Object[] objArr) {
        this.Vulcan_Nl = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_MY(Object[] objArr) {
        this.Vulcan_vm = (World) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_xF, reason: collision with other method in class */
    public void m1048Vulcan_xF(Object[] objArr) {
        this.Vulcan_TU = (Entity) objArr[0];
    }

    public void Vulcan_x6(Object[] objArr) {
        this.Vulcan_R = (Entity) objArr[0];
    }

    public void Vulcan_v_(Object[] objArr) {
        this.Vulcan_vV = ((Float) objArr[0]).floatValue();
    }

    public void Vulcan_vJ(Object[] objArr) {
        this.Vulcan_C = ((Float) objArr[0]).floatValue();
    }

    public void Vulcan__H(Object[] objArr) {
        this.Vulcan_Ne = (List) objArr[0];
    }

    public void Vulcan_Rk(Object[] objArr) {
        this.Vulcan_vN = (LinkedList) objArr[0];
    }

    public void Vulcan_KO(Object[] objArr) {
        this.Vulcan_gm = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Ve(Object[] objArr) {
        this.Vulcan_ve = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KB(Object[] objArr) {
        this.Vulcan_T6 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vg(Object[] objArr) {
        this.Vulcan_z = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KK(Object[] objArr) {
        this.Vulcan_v9 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VN(Object[] objArr) {
        this.Vulcan_vX = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Kn(Object[] objArr) {
        this.Vulcan_Tt = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KX(Object[] objArr) {
        this.Vulcan_w = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KG(Object[] objArr) {
        this.Vulcan_vn = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VW(Object[] objArr) {
        this.Vulcan_NF = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KQ(Object[] objArr) {
        this.Vulcan_vZ = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_KH(Object[] objArr) {
        this.Vulcan_TY = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vp(Object[] objArr) {
        this.Vulcan_Nu = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VY(Object[] objArr) {
        this.Vulcan_v7 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VU(Object[] objArr) {
        this.Vulcan_T8 = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_Vw(Object[] objArr) {
        this.Vulcan_TR = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_VC(Object[] objArr) {
        this.Vulcan_T3 = ((Boolean) objArr[0]).booleanValue();
    }

    public C0042Vulcan_Oz Vulcan_r(Object[] objArr) {
        return this.Vulcan_g6;
    }

    public boolean Vulcan_g(Object[] objArr) {
        return this.Vulcan_T_;
    }

    public boolean Vulcan_at(Object[] objArr) {
        return this.Vulcan_vl;
    }

    public boolean Vulcan_T(Object[] objArr) {
        return this.Vulcan_Nb;
    }

    public boolean Vulcan_aw(Object[] objArr) {
        return this.Vulcan_H;
    }

    public boolean Vulcan_aT(Object[] objArr) {
        return this.Vulcan_NZ;
    }

    public boolean Vulcan_a4(Object[] objArr) {
        return this.Vulcan_vk;
    }

    public boolean Vulcan_aG(Object[] objArr) {
        return this.Vulcan_TC;
    }

    /* JADX INFO: renamed from: Vulcan_aV, reason: collision with other method in class */
    public boolean m861Vulcan_aV(Object[] objArr) {
        return this.Vulcan_NR;
    }

    public boolean Vulcan_aD(Object[] objArr) {
        return this.Vulcan_Y;
    }

    public boolean Vulcan_N(Object[] objArr) {
        return this.Vulcan_g1;
    }

    public boolean Vulcan_w(Object[] objArr) {
        return this.Vulcan_TI;
    }

    public boolean Vulcan_J(Object[] objArr) {
        return this.Vulcan_TO;
    }

    public boolean Vulcan_B(Object[] objArr) {
        return this.Vulcan_j;
    }

    public boolean Vulcan_P7(Object[] objArr) {
        return this.Vulcan_gD;
    }

    public boolean Vulcan_aF(Object[] objArr) {
        return this.Vulcan_vy;
    }

    public boolean Vulcan_C(Object[] objArr) {
        return this.Vulcan_vW;
    }

    public boolean Vulcan_D(Object[] objArr) {
        return this.Vulcan_g5;
    }

    public boolean Vulcan_a7(Object[] objArr) {
        return this.Vulcan_Nx;
    }

    public boolean Vulcan_U(Object[] objArr) {
        return this.Vulcan_gu;
    }

    public boolean Vulcan_aB(Object[] objArr) {
        return this.Vulcan_v3;
    }

    public boolean Vulcan_aH(Object[] objArr) {
        return this.Vulcan_gv;
    }

    public boolean Vulcan_az(Object[] objArr) {
        return this.Vulcan_No;
    }

    public boolean Vulcan_aU(Object[] objArr) {
        return this.Vulcan_vc;
    }

    public boolean Vulcan_K(Object[] objArr) {
        return this.Vulcan_N9;
    }

    public boolean Vulcan_Px(Object[] objArr) {
        return this.Vulcan_Q;
    }

    public boolean Vulcan_Pk(Object[] objArr) {
        return this.Vulcan_gL;
    }

    public boolean Vulcan_aX(Object[] objArr) {
        return this.Vulcan_To;
    }

    public boolean Vulcan_a8(Object[] objArr) {
        return this.Vulcan_c;
    }

    public boolean Vulcan_ax(Object[] objArr) {
        return this.Vulcan_gF;
    }

    public boolean Vulcan_e(Object[] objArr) {
        return this.Vulcan_a;
    }

    public boolean Vulcan_af(Object[] objArr) {
        return this.Vulcan_vJ;
    }

    public boolean Vulcan_ac(Object[] objArr) {
        return this.Vulcan_v2;
    }

    public boolean Vulcan_Y(Object[] objArr) {
        return this.Vulcan_vg;
    }

    public boolean Vulcan_aE(Object[] objArr) {
        return this.Vulcan_gW;
    }

    public boolean Vulcan_H(Object[] objArr) {
        return this.Vulcan_gj;
    }

    public boolean Vulcan_i(Object[] objArr) {
        return this.Vulcan_NK;
    }

    public boolean Vulcan__(Object[] objArr) {
        return this.Vulcan_Np;
    }

    public boolean Vulcan_aC(Object[] objArr) {
        return this.Vulcan_vr;
    }

    public boolean Vulcan_aM(Object[] objArr) {
        return this.Vulcan_gU;
    }

    public boolean Vulcan_A(Object[] objArr) {
        return this.Vulcan_vK;
    }

    public boolean Vulcan_au(Object[] objArr) {
        return this.Vulcan_vY;
    }

    public boolean Vulcan_aI(Object[] objArr) {
        return this.Vulcan_TH;
    }

    public boolean Vulcan_Pc(Object[] objArr) {
        return this.Vulcan_vR;
    }

    public boolean Vulcan_ab(Object[] objArr) {
        return this.Vulcan_T4;
    }

    public boolean Vulcan_a_(Object[] objArr) {
        return this.Vulcan_e;
    }

    public boolean Vulcan_P5(Object[] objArr) {
        return this.Vulcan_F;
    }

    public boolean Vulcan_aY(Object[] objArr) {
        return this.Vulcan_TS;
    }

    public boolean Vulcan_av(Object[] objArr) {
        return this.Vulcan_NQ;
    }

    public boolean Vulcan_R(Object[] objArr) {
        return this.Vulcan_q;
    }

    public boolean Vulcan_u(Object[] objArr) {
        return this.Vulcan_M;
    }

    public boolean Vulcan_m(Object[] objArr) {
        return this.Vulcan_Nj;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public boolean m862Vulcan_F(Object[] objArr) {
        return this.Vulcan__;
    }

    public boolean Vulcan_aq(Object[] objArr) {
        return this.Vulcan_Ta;
    }

    public boolean Vulcan_s(Object[] objArr) {
        return this.Vulcan_gX;
    }

    /* JADX INFO: renamed from: Vulcan_aR, reason: collision with other method in class */
    public boolean m863Vulcan_aR(Object[] objArr) {
        return this.Vulcan_Tk;
    }

    public boolean Vulcan_aK(Object[] objArr) {
        return this.Vulcan_k;
    }

    public boolean Vulcan_z(Object[] objArr) {
        return this.Vulcan_TF;
    }

    public boolean Vulcan_a2(Object[] objArr) {
        return this.Vulcan_Tj;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public boolean m864Vulcan_t(Object[] objArr) {
        return this.Vulcan_B;
    }

    public boolean Vulcan_ap(Object[] objArr) {
        return this.Vulcan_N7;
    }

    public boolean Vulcan_P4(Object[] objArr) {
        return this.Vulcan_gk;
    }

    public boolean Vulcan_aN(Object[] objArr) {
        return this.Vulcan_g4;
    }

    public boolean Vulcan_ai(Object[] objArr) {
        return this.Vulcan_Nw;
    }

    public boolean Vulcan_ay(Object[] objArr) {
        return this.Vulcan_vd;
    }

    public boolean Vulcan_aP(Object[] objArr) {
        return this.Vulcan_go;
    }

    public boolean Vulcan_a9(Object[] objArr) {
        return this.Vulcan_Ns;
    }

    /* JADX INFO: renamed from: Vulcan_ah, reason: collision with other method in class */
    public boolean m865Vulcan_ah(Object[] objArr) {
        return this.Vulcan_g9;
    }

    public boolean Vulcan_L(Object[] objArr) {
        return this.Vulcan_O;
    }

    public boolean Vulcan_al(Object[] objArr) {
        return this.Vulcan_TJ;
    }

    public boolean Vulcan_k(Object[] objArr) {
        return this.Vulcan_J;
    }

    public boolean Vulcan_x(Object[] objArr) {
        return this.Vulcan_Tm;
    }

    /* JADX INFO: renamed from: Vulcan_ag, reason: collision with other method in class */
    public boolean m866Vulcan_ag(Object[] objArr) {
        return this.Vulcan_NB;
    }

    public boolean Vulcan_S(Object[] objArr) {
        return this.Vulcan_d;
    }

    public boolean Vulcan_an(Object[] objArr) {
        return this.Vulcan_gA;
    }

    public boolean Vulcan_Pf(Object[] objArr) {
        return this.Vulcan_TT;
    }

    /* JADX INFO: renamed from: Vulcan_ao, reason: collision with other method in class */
    public boolean m867Vulcan_ao(Object[] objArr) {
        return this.Vulcan_vU;
    }

    public boolean Vulcan_PO(Object[] objArr) {
        return this.Vulcan_vb;
    }

    public boolean Vulcan_M(Object[] objArr) {
        return this.Vulcan_T9;
    }

    public boolean Vulcan_ae(Object[] objArr) {
        return this.Vulcan_g2;
    }

    public boolean Vulcan_a5(Object[] objArr) {
        return this.Vulcan_vT;
    }

    public boolean Vulcan_h(Object[] objArr) {
        return this.Vulcan_S;
    }

    public boolean Vulcan_a0(Object[] objArr) {
        return this.Vulcan_v6;
    }

    public boolean Vulcan_PR(Object[] objArr) {
        return this.Vulcan_vM;
    }

    public boolean Vulcan_G(Object[] objArr) {
        return this.Vulcan_TG;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public boolean m868Vulcan_Q(Object[] objArr) {
        return this.Vulcan_Tl;
    }

    public boolean Vulcan_p(Object[] objArr) {
        return this.Vulcan_gM;
    }

    /* JADX INFO: renamed from: Vulcan_aJ, reason: collision with other method in class */
    public boolean m869Vulcan_aJ(Object[] objArr) {
        return this.Vulcan_TZ;
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public boolean m870Vulcan_l(Object[] objArr) {
        return this.Vulcan_vP;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public boolean m871Vulcan_r(Object[] objArr) {
        return this.Vulcan_TK;
    }

    public boolean Vulcan_V(Object[] objArr) {
        return this.Vulcan_N4;
    }

    public boolean Vulcan_E(Object[] objArr) {
        return this.Vulcan_NT;
    }

    public boolean Vulcan_o(Object[] objArr) {
        return this.Vulcan_V;
    }

    public boolean Vulcan_aA(Object[] objArr) {
        return this.Vulcan_v5;
    }

    public boolean Vulcan_n(Object[] objArr) {
        return this.Vulcan_T1;
    }

    public boolean Vulcan_ad(Object[] objArr) {
        return this.Vulcan_gr;
    }

    public boolean Vulcan_aQ(Object[] objArr) {
        return this.Vulcan_T5;
    }

    public boolean Vulcan_y(Object[] objArr) {
        return this.Vulcan_gf;
    }

    public boolean Vulcan_a1(Object[] objArr) {
        return this.Vulcan_gn;
    }

    /* JADX INFO: renamed from: Vulcan_aj, reason: collision with other method in class */
    public boolean m872Vulcan_aj(Object[] objArr) {
        return this.Vulcan_v0;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public boolean m873Vulcan_I(Object[] objArr) {
        return this.Vulcan_NN;
    }

    public boolean Vulcan_Py(Object[] objArr) {
        return this.Vulcan_gq;
    }

    public boolean Vulcan_PP(Object[] objArr) {
        return this.Vulcan_g7;
    }

    public boolean Vulcan_b(Object[] objArr) {
        return this.Vulcan_gK;
    }

    public boolean Vulcan_aL(Object[] objArr) {
        return this.Vulcan_vO;
    }

    /* JADX INFO: renamed from: Vulcan_as, reason: collision with other method in class */
    public boolean m874Vulcan_as(Object[] objArr) {
        return this.Vulcan_gx;
    }

    public boolean Vulcan_q(Object[] objArr) {
        return this.Vulcan_gy;
    }

    /* JADX INFO: renamed from: Vulcan_a3, reason: collision with other method in class */
    public boolean m875Vulcan_a3(Object[] objArr) {
        return this.Vulcan_TD;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public Location m876Vulcan_N(Object[] objArr) {
        return this.Vulcan_Tx;
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public Location m877Vulcan_z(Object[] objArr) {
        return this.Vulcan_vw;
    }

    public Map Vulcan_X(Object[] objArr) {
        return this.Vulcan_gT;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public void m1049Vulcan_M(Object[] objArr) {
        this.Vulcan_E = ((Boolean) objArr[0]).booleanValue();
    }

    public boolean Vulcan_O(Object[] objArr) {
        return this.Vulcan_E;
    }

    public void Vulcan__l(Object[] objArr) {
        this.Vulcan_vD = (List) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public List m878Vulcan_N(Object[] objArr) {
        return this.Vulcan_vD;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public Material m879Vulcan_D(Object[] objArr) {
        return this.Vulcan_vv;
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public Material m880Vulcan_Y(Object[] objArr) {
        return this.Vulcan_L;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public Material m881Vulcan_H(Object[] objArr) {
        return this.Vulcan_vA;
    }

    public List Vulcan_c(Object[] objArr) {
        return this.Vulcan_gB;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public List m882Vulcan_O(Object[] objArr) {
        return this.Vulcan_gG;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public List m883Vulcan_u(Object[] objArr) {
        return this.Vulcan_h;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public List m884Vulcan_R(Object[] objArr) {
        return this.Vulcan_Nf;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public List m885Vulcan_F(Object[] objArr) {
        return this.Vulcan_TW;
    }

    public void Vulcan__N(Object[] objArr) {
        this.Vulcan_TQ = (List) objArr[0];
    }

    public void Vulcan__g(Object[] objArr) {
        this.Vulcan_vH = (List) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public void m1050Vulcan_Y(Object[] objArr) {
        this.Vulcan_Nr = (List) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public List m886Vulcan_D(Object[] objArr) {
        return this.Vulcan_TQ;
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public List m887Vulcan_e(Object[] objArr) {
        return this.Vulcan_vH;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public List m888Vulcan_h(Object[] objArr) {
        return this.Vulcan_Nr;
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public void m1051Vulcan_S(Object[] objArr) {
        this.Vulcan_NJ = (Material) objArr[0];
    }

    public void Vulcan_Sn(Object[] objArr) {
        this.Vulcan_u = (Material) objArr[0];
    }

    public void Vulcan_SV(Object[] objArr) {
        this.Vulcan_va = (Material) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public Material m889Vulcan_y(Object[] objArr) {
        return this.Vulcan_NJ;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public Material m890Vulcan_C(Object[] objArr) {
        return this.Vulcan_u;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public Material m891Vulcan_M(Object[] objArr) {
        return this.Vulcan_va;
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public double m892Vulcan_q(Object[] objArr) {
        return this.Vulcan_vC;
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public double m893Vulcan__(Object[] objArr) {
        return this.Vulcan_Tz;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public double m894Vulcan_t(Object[] objArr) {
        return this.Vulcan_Te;
    }

    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public double m895Vulcan_k(Object[] objArr) {
        return this.Vulcan_Th;
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public double m896Vulcan_s(Object[] objArr) {
        return this.Vulcan_Tp;
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public double m897Vulcan_i(Object[] objArr) {
        return this.Vulcan_vf;
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public double m898Vulcan_b(Object[] objArr) {
        return this.Vulcan_v1;
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public double m899Vulcan_B(Object[] objArr) {
        return this.Vulcan_vF;
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public double m900Vulcan_a(Object[] objArr) {
        return this.Vulcan_TP;
    }

    public double Vulcan_v(Object[] objArr) {
        return this.Vulcan_gc;
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public double m901Vulcan_A(Object[] objArr) {
        return this.Vulcan_Tf;
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public double m902Vulcan_j(Object[] objArr) {
        return this.Vulcan_g8;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public double m903Vulcan_T(Object[] objArr) {
        return this.Vulcan_Ty;
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public double m904Vulcan_z(Object[] objArr) {
        return this.Vulcan_gP;
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public double m905Vulcan_y(Object[] objArr) {
        return this.Vulcan_ga;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public double m906Vulcan_I(Object[] objArr) {
        return this.Vulcan_T7;
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public double m907Vulcan_X(Object[] objArr) {
        return this.Vulcan_t;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public double m908Vulcan_Q(Object[] objArr) {
        return this.Vulcan_x;
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public double m909Vulcan_x(Object[] objArr) {
        return this.Vulcan_Tv;
    }

    public double Vulcan_P(Object[] objArr) {
        return this.Vulcan_Tr;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public double m910Vulcan_F(Object[] objArr) {
        return this.Vulcan_vL;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public double m911Vulcan_c(Object[] objArr) {
        return this.Vulcan_gb;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public double m912Vulcan_h(Object[] objArr) {
        return this.Vulcan_gJ;
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public double m913Vulcan_K(Object[] objArr) {
        return this.Vulcan_Nk;
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public double m914Vulcan_m(Object[] objArr) {
        return this.Vulcan_gi;
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public double m915Vulcan_G(Object[] objArr) {
        return this.Vulcan_Ti;
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public double m916Vulcan_U(Object[] objArr) {
        return this.Vulcan_Tq;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public double m917Vulcan_O(Object[] objArr) {
        return this.Vulcan_g3;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public double m918Vulcan_r(Object[] objArr) {
        return this.Vulcan_TE;
    }

    public double Vulcan_f(Object[] objArr) {
        return this.Vulcan_i;
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public double m919Vulcan_p(Object[] objArr) {
        return this.Vulcan_U;
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public double m920Vulcan_V(Object[] objArr) {
        return this.Vulcan_gC;
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public double m921Vulcan_S(Object[] objArr) {
        return this.Vulcan_Tn;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public double m922Vulcan_D(Object[] objArr) {
        return this.Vulcan_gV;
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public double m923Vulcan_o(Object[] objArr) {
        return this.Vulcan_Z;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public double m924Vulcan_M(Object[] objArr) {
        return this.Vulcan_g;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public double m925Vulcan_u(Object[] objArr) {
        return this.Vulcan_X;
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public double m926Vulcan_g(Object[] objArr) {
        return this.Vulcan_ge;
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public double m927Vulcan_Y(Object[] objArr) {
        return this.Vulcan_r;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public double m928Vulcan_C(Object[] objArr) {
        return this.Vulcan_y;
    }

    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public double m929Vulcan_d(Object[] objArr) {
        return this.Vulcan_N6;
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public double m930Vulcan_E(Object[] objArr) {
        return this.Vulcan_Nh;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public double m931Vulcan_R(Object[] objArr) {
        return this.Vulcan_v8;
    }

    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public double m932Vulcan_J(Object[] objArr) {
        return this.Vulcan_vt;
    }

    public double Vulcan_Z(Object[] objArr) {
        return this.Vulcan_gE;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public double m933Vulcan_H(Object[] objArr) {
        return this.Vulcan_TB;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public double m934Vulcan_L(Object[] objArr) {
        return this.Vulcan_vp;
    }

    public int Vulcan_xw(Object[] objArr) {
        return this.Vulcan_gI;
    }

    public int Vulcan_xA(Object[] objArr) {
        return this.Vulcan_G;
    }

    /* JADX INFO: renamed from: Vulcan_U, reason: collision with other method in class */
    public int m935Vulcan_U(Object[] objArr) {
        return this.Vulcan_TL;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public int m936Vulcan_R(Object[] objArr) {
        return this.Vulcan_Td;
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public int m937Vulcan_P(Object[] objArr) {
        return this.Vulcan_vu;
    }

    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public int m938Vulcan_d(Object[] objArr) {
        return this.Vulcan_n;
    }

    public int Vulcan_xT(Object[] objArr) {
        return this.Vulcan_vs;
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public int m939Vulcan_y(Object[] objArr) {
        return this.Vulcan_Tc;
    }

    public int Vulcan_xW(Object[] objArr) {
        return this.Vulcan_gl;
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public int m940Vulcan_E(Object[] objArr) {
        return this.Vulcan_gZ;
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public int m941Vulcan_S(Object[] objArr) {
        return this.Vulcan_NG;
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public int m942Vulcan_v(Object[] objArr) {
        return this.Vulcan_TA;
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public int m943Vulcan_e(Object[] objArr) {
        return this.Vulcan_vS;
    }

    public int Vulcan_xK(Object[] objArr) {
        return this.Vulcan_gw;
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public int m944Vulcan_h(Object[] objArr) {
        return this.Vulcan_K;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public int m945Vulcan_M(Object[] objArr) {
        return this.Vulcan_v4;
    }

    public int Vulcan_xF(Object[] objArr) {
        return this.Vulcan_Tu;
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public int m946Vulcan_q(Object[] objArr) {
        return this.Vulcan_vE;
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public int m947Vulcan_f(Object[] objArr) {
        return this.Vulcan_gh;
    }

    public int Vulcan_xL(Object[] objArr) {
        return this.Vulcan_N8;
    }

    public int Vulcan_xC(Object[] objArr) {
        return this.Vulcan_TV;
    }

    public int Vulcan_xq(Object[] objArr) {
        return this.Vulcan_gY;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public int m948Vulcan_r(Object[] objArr) {
        return this.Vulcan_gp;
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public int m949Vulcan_g(Object[] objArr) {
        return this.Vulcan_s;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public int m950Vulcan_t(Object[] objArr) {
        return this.Vulcan_vx;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public int m951Vulcan_D(Object[] objArr) {
        return this.Vulcan_W;
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public int m952Vulcan__(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX INFO: renamed from: Vulcan_A, reason: collision with other method in class */
    public int m953Vulcan_A(Object[] objArr) {
        return this.Vulcan_P;
    }

    public int Vulcan_xJ(Object[] objArr) {
        return this.Vulcan_Ni;
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public int m954Vulcan_p(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public int m955Vulcan_O(Object[] objArr) {
        return this.Vulcan_vz;
    }

    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public int m956Vulcan_o(Object[] objArr) {
        return this.Vulcan_gH;
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public int m957Vulcan_K(Object[] objArr) {
        return this.Vulcan_gs;
    }

    public int Vulcan_xl(Object[] objArr) {
        return this.Vulcan_g0;
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public int m958Vulcan_l(Object[] objArr) {
        return this.Vulcan_vo;
    }

    public int Vulcan_xi(Object[] objArr) {
        return this.Vulcan_vB;
    }

    public int Vulcan_W(Object[] objArr) {
        return this.Vulcan_gd;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public int m959Vulcan_T(Object[] objArr) {
        return this.Vulcan_g_;
    }

    public int Vulcan_xg(Object[] objArr) {
        return this.Vulcan_N5;
    }

    /* JADX INFO: renamed from: Vulcan_s, reason: collision with other method in class */
    public int m960Vulcan_s(Object[] objArr) {
        return this.Vulcan_v_;
    }

    public int Vulcan_xE(Object[] objArr) {
        return this.Vulcan_m;
    }

    public int Vulcan_x1(Object[] objArr) {
        return this.Vulcan_l;
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public int m961Vulcan_w(Object[] objArr) {
        return this.Vulcan_b;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public int m962Vulcan_c(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public int m963Vulcan_i(Object[] objArr) {
        return this.Vulcan_Nm;
    }

    public int Vulcan_xa(Object[] objArr) {
        return this.Vulcan_gS;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public int m964Vulcan_F(Object[] objArr) {
        return this.Vulcan_Tw;
    }

    public int Vulcan_xo(Object[] objArr) {
        return this.Vulcan_gN;
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public int m965Vulcan_m(Object[] objArr) {
        return this.Vulcan_gQ;
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public int m966Vulcan_V(Object[] objArr) {
        return this.Vulcan_vq;
    }

    public int Vulcan_xR(Object[] objArr) {
        return this.Vulcan_NU;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public int m967Vulcan_C(Object[] objArr) {
        return this.Vulcan_Ts;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public int m968Vulcan_H(Object[] objArr) {
        return this.Vulcan_o;
    }

    /* JADX INFO: renamed from: Vulcan_J, reason: collision with other method in class */
    public int m969Vulcan_J(Object[] objArr) {
        return this.Vulcan_Tg;
    }

    /* JADX INFO: renamed from: Vulcan_n, reason: collision with other method in class */
    public int m970Vulcan_n(Object[] objArr) {
        return this.Vulcan_TX;
    }

    public int Vulcan_xh(Object[] objArr) {
        return this.Vulcan_TM;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public int m971Vulcan_L(Object[] objArr) {
        return this.Vulcan_vj;
    }

    /* JADX INFO: renamed from: Vulcan_N, reason: collision with other method in class */
    public int m972Vulcan_N(Object[] objArr) {
        return this.Vulcan_T2;
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public int m973Vulcan_Z(Object[] objArr) {
        return this.Vulcan_vh;
    }

    public int Vulcan_xU(Object[] objArr) {
        return this.Vulcan_gt;
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public int m974Vulcan_Q(Object[] objArr) {
        return this.Vulcan_Tb;
    }

    public int Vulcan_xs(Object[] objArr) {
        return this.Vulcan_TN;
    }

    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public int m975Vulcan_j(Object[] objArr) {
        return this.Vulcan_gz;
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public int m976Vulcan_Y(Object[] objArr) {
        return this.Vulcan_NV;
    }

    public int Vulcan_xd(Object[] objArr) {
        return this.Vulcan_vG;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public int m977Vulcan_u(Object[] objArr) {
        return this.Vulcan_D;
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public int m978Vulcan_X(Object[] objArr) {
        return this.Vulcan_gg;
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public int m979Vulcan_B(Object[] objArr) {
        return this.Vulcan_T0;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public int m980Vulcan_I(Object[] objArr) {
        return this.Vulcan_NP;
    }

    /* JADX INFO: renamed from: Vulcan_b, reason: collision with other method in class */
    public int m981Vulcan_b(Object[] objArr) {
        return this.Vulcan_A;
    }

    public int Vulcan_xk(Object[] objArr) {
        return this.Vulcan_N;
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public int m982Vulcan_x(Object[] objArr) {
        return this.Vulcan_gO;
    }

    public int Vulcan_xv(Object[] objArr) {
        return this.Vulcan_T;
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public int m983Vulcan_z(Object[] objArr) {
        return this.Vulcan_vI;
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public int m984Vulcan_a(Object[] objArr) {
        return this.Vulcan_I;
    }

    public int Vulcan_xz(Object[] objArr) {
        return this.Vulcan_gR;
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public int m985Vulcan_G(Object[] objArr) {
        return this.Vulcan_vi;
    }

    /* JADX INFO: renamed from: Vulcan_k, reason: collision with other method in class */
    public int m986Vulcan_k(Object[] objArr) {
        return this.Vulcan_Nl;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public World m987Vulcan_R(Object[] objArr) {
        return this.Vulcan_vm;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public Entity m988Vulcan_C(Object[] objArr) {
        return this.Vulcan_TU;
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public Entity m989Vulcan_p(Object[] objArr) {
        return this.Vulcan_R;
    }

    /* JADX INFO: renamed from: Vulcan_L, reason: collision with other method in class */
    public float m990Vulcan_L(Object[] objArr) {
        return this.Vulcan_vV;
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public float m991Vulcan_G(Object[] objArr) {
        return this.Vulcan_C;
    }

    /* JADX INFO: renamed from: Vulcan_E, reason: collision with other method in class */
    public List m992Vulcan_E(Object[] objArr) {
        return this.Vulcan_Ne;
    }

    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    public LinkedList m993Vulcan_u(Object[] objArr) {
        return this.Vulcan_vN;
    }

    public Vulcan_ka(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_g6 = c0042Vulcan_Oz;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:222:0x06a3
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_zo(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1791
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_zo(java.lang.Object[]):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_y Vulcan_Q(java.lang.Object[] r11) {
        /*
            r10 = this;
            r0 = r11
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r14 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_ka.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            r0 = 0
            r16 = r0
            java.lang.String[] r0 = Vulcan_T()
            me.frep.vulcan.spigot.Vulcan_y r1 = new me.frep.vulcan.spigot.Vulcan_y
            r2 = r1
            r3 = 0
            r4 = 0
            r5 = 0
            r2.<init>(r3, r4, r5)
            r17 = r1
            r15 = r0
            r0 = r10
            java.util.LinkedList r0 = r0.Vulcan_vN
            java.util.Iterator r0 = r0.iterator()
            r18 = r0
        L3a:
            r0 = r18
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto L87
            r0 = r18
            java.lang.Object r0 = r0.next()
            me.frep.vulcan.spigot.Vulcan_y r0 = (me.frep.vulcan.spigot.Vulcan_y) r0
            r19 = r0
            r0 = r12
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L5f
            r0 = r19
            r1 = r15
            if (r1 == 0) goto L89
            r17 = r0
        L5f:
            r0 = r15
            r1 = r12
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L84
            if (r0 == 0) goto L82
            r0 = r16
            r1 = r14
            if (r0 != r1) goto L7f
            goto L78
        L74:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7b
            throw r0     // Catch: java.lang.RuntimeException -> L7b
        L78:
            goto L87
        L7b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L7b
            throw r0
        L7f:
            int r16 = r16 + 1
        L82:
            r0 = r15
        L84:
            if (r0 != 0) goto L3a
        L87:
            r0 = r17
        L89:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_Q(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_y");
    }

    public boolean Vulcan_aa(Object[] objArr) {
        return this.Vulcan_gm;
    }

    /* JADX INFO: renamed from: Vulcan_v, reason: collision with other method in class */
    public boolean m994Vulcan_v(Object[] objArr) {
        return this.Vulcan_ve;
    }

    public boolean Vulcan_am(Object[] objArr) {
        return this.Vulcan_T6;
    }

    /* JADX INFO: renamed from: Vulcan_d, reason: collision with other method in class */
    public boolean m995Vulcan_d(Object[] objArr) {
        return this.Vulcan_z;
    }

    public boolean Vulcan_P9(Object[] objArr) {
        return this.Vulcan_v9;
    }

    public boolean Vulcan_ak(Object[] objArr) {
        return this.Vulcan_vX;
    }

    /* JADX INFO: renamed from: Vulcan_P, reason: collision with other method in class */
    public boolean m996Vulcan_P(Object[] objArr) {
        return this.Vulcan_Tt;
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public boolean m997Vulcan_X(Object[] objArr) {
        return this.Vulcan_w;
    }

    public boolean Vulcan_ar(Object[] objArr) {
        return this.Vulcan_vn;
    }

    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public boolean m998Vulcan_Z(Object[] objArr) {
        return this.Vulcan_NF;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public boolean m999Vulcan_c(Object[] objArr) {
        return this.Vulcan_vZ;
    }

    public boolean Vulcan_aZ(Object[] objArr) {
        return this.Vulcan_TY;
    }

    public boolean Vulcan_aO(Object[] objArr) {
        return this.Vulcan_Nu;
    }

    /* JADX INFO: renamed from: Vulcan_aW, reason: collision with other method in class */
    public boolean m1000Vulcan_aW(Object[] objArr) {
        return this.Vulcan_v7;
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public boolean m1001Vulcan_W(Object[] objArr) {
        return this.Vulcan_T8;
    }

    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public boolean m1002Vulcan_f(Object[] objArr) {
        return this.Vulcan_TR;
    }

    public boolean Vulcan_aS(Object[] objArr) {
        return this.Vulcan_T3;
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v14, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v17, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v2, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v20, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v23, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v26, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v29, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v32, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v35, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v38, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v41, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v44, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v47, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v5, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v50, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r2v8, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    private void Vulcan_F(Object[] objArr) {
        long jLongValue = (a ^ ((Long) objArr[0]).longValue()) ^ 82135598945278L;
        Vulcan_yv vulcan_yvVulcan_C = this.Vulcan_g6.Vulcan_C(new Object[0]);
        Object[] objArr2 = new Object[2];
        Vulcan_yU.FLIGHT[1] = Long.valueOf(jLongValue);
        objArr2[0] = objArr2;
        this.Vulcan_gm = vulcan_yvVulcan_C.Vulcan_r(objArr2);
        Object[] objArr3 = new Object[2];
        Vulcan_yU.CREATIVE[1] = Long.valueOf(jLongValue);
        objArr3[0] = objArr3;
        this.Vulcan_ve = vulcan_yvVulcan_C.Vulcan_r(objArr3);
        Object[] objArr4 = new Object[2];
        Vulcan_yU.JOINED[1] = Long.valueOf(jLongValue);
        objArr4[0] = objArr4;
        this.Vulcan_T6 = vulcan_yvVulcan_C.Vulcan_r(objArr4);
        Object[] objArr5 = new Object[2];
        Vulcan_yU.LIQUID[1] = Long.valueOf(jLongValue);
        objArr5[0] = objArr5;
        this.Vulcan_z = vulcan_yvVulcan_C.Vulcan_r(objArr5);
        Object[] objArr6 = new Object[2];
        Vulcan_yU.LEVITATION[1] = Long.valueOf(jLongValue);
        objArr6[0] = objArr6;
        this.Vulcan_v9 = vulcan_yvVulcan_C.Vulcan_r(objArr6);
        Object[] objArr7 = new Object[2];
        Vulcan_yU.SLOW_FALLING[1] = Long.valueOf(jLongValue);
        objArr7[0] = objArr7;
        this.Vulcan_vX = vulcan_yvVulcan_C.Vulcan_r(objArr7);
        Object[] objArr8 = new Object[2];
        Vulcan_yU.RIPTIDE[1] = Long.valueOf(jLongValue);
        objArr8[0] = objArr8;
        this.Vulcan_Tt = vulcan_yvVulcan_C.Vulcan_r(objArr8);
        Object[] objArr9 = new Object[2];
        Vulcan_yU.VEHICLE[1] = Long.valueOf(jLongValue);
        objArr9[0] = objArr9;
        this.Vulcan_w = vulcan_yvVulcan_C.Vulcan_r(objArr9);
        Object[] objArr10 = new Object[2];
        Vulcan_yU.LENIENT_SCAFFOLDING[1] = Long.valueOf(jLongValue);
        objArr10[0] = objArr10;
        this.Vulcan_vn = vulcan_yvVulcan_C.Vulcan_r(objArr10);
        Object[] objArr11 = new Object[2];
        Vulcan_yU.GLIDING[1] = Long.valueOf(jLongValue);
        objArr11[0] = objArr11;
        this.Vulcan_NF = vulcan_yvVulcan_C.Vulcan_r(objArr11);
        Object[] objArr12 = new Object[2];
        Vulcan_yU.ELYTRA[1] = Long.valueOf(jLongValue);
        objArr12[0] = objArr12;
        this.Vulcan_vZ = vulcan_yvVulcan_C.Vulcan_r(objArr12);
        Object[] objArr13 = new Object[2];
        Vulcan_yU.TELEPORT[1] = Long.valueOf(jLongValue);
        objArr13[0] = objArr13;
        this.Vulcan_TY = vulcan_yvVulcan_C.Vulcan_r(objArr13);
        Object[] objArr14 = new Object[2];
        Vulcan_yU.ENDER_PEARL[1] = Long.valueOf(jLongValue);
        objArr14[0] = objArr14;
        this.Vulcan_Nu = vulcan_yvVulcan_C.Vulcan_r(objArr14);
        Object[] objArr15 = new Object[2];
        Vulcan_yU.CHUNK[1] = Long.valueOf(jLongValue);
        objArr15[0] = objArr15;
        this.Vulcan_v7 = vulcan_yvVulcan_C.Vulcan_r(objArr15);
        Object[] objArr16 = new Object[2];
        Vulcan_yU.COMBO_MODE[1] = Long.valueOf(jLongValue);
        objArr16[0] = objArr16;
        this.Vulcan_T8 = vulcan_yvVulcan_C.Vulcan_r(objArr16);
        Object[] objArr17 = new Object[2];
        Vulcan_yU.MYTHIC_MOB[1] = Long.valueOf(jLongValue);
        objArr17[0] = objArr17;
        this.Vulcan_TR = vulcan_yvVulcan_C.Vulcan_r(objArr17);
        Object[] objArr18 = new Object[2];
        Vulcan_yU.CLIMBABLE[1] = Long.valueOf(jLongValue);
        objArr18[0] = objArr18;
        this.Vulcan_T3 = vulcan_yvVulcan_C.Vulcan_r(objArr18);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void Vulcan_as(java.lang.Object[] r71) {
        /*
            Method dump skipped, instruction units count: 3861
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_as(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v27, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v28, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    public void Vulcan_j(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        this.Vulcan_NV++;
        this.Vulcan_Tw++;
        ?? Vulcan_T = Vulcan_T();
        this.Vulcan_T2++;
        try {
            try {
                try {
                    this.Vulcan_vh++;
                    this.Vulcan_gg++;
                    Vulcan_ka vulcan_ka = this;
                    if (Vulcan_T != 0) {
                        Vulcan_T = vulcan_ka.Vulcan_T4;
                        if (Vulcan_T != 0) {
                            this.Vulcan_vu++;
                            if (jLongValue > 0 && Vulcan_T == 0) {
                            }
                        }
                        vulcan_ka = this;
                        vulcan_ka.Vulcan_vu = 0;
                    } else {
                        vulcan_ka.Vulcan_vu = 0;
                    }
                    ?? r0 = this;
                    try {
                        if (Vulcan_T != 0) {
                            try {
                                try {
                                    r0 = r0.Vulcan_T4;
                                    if (r0 == 0) {
                                        this.Vulcan_Td++;
                                        if (Vulcan_T != 0) {
                                            return;
                                        }
                                    }
                                    r0 = this;
                                } catch (RuntimeException unused) {
                                    throw a((RuntimeException) r0);
                                }
                            } catch (RuntimeException unused2) {
                                throw a((RuntimeException) r0);
                            }
                        }
                        r0.Vulcan_Td = 0;
                    } catch (RuntimeException unused3) {
                        throw a((RuntimeException) r0);
                    }
                } catch (RuntimeException unused4) {
                    throw a((RuntimeException) Vulcan_T);
                }
            } catch (RuntimeException unused5) {
                throw a((RuntimeException) Vulcan_T);
            }
        } catch (RuntimeException unused6) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_I(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 441
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_I(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00d0  */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v19, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v20, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v36, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException, org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v47, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v48, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v49, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v55, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v64, types: [org.bukkit.Material] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_PN(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_PN(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00bf  */
    /* JADX WARN: Removed duplicated region for block: B:44:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [boolean, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v21, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v30, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_a3(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_ka.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String[] r0 = Vulcan_T()
            r11 = r0
            r0 = r7
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_g6     // Catch: java.lang.RuntimeException -> L26
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L26
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L26
            if (r0 != 0) goto L2a
            return
        L26:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L26
            throw r0
        L2a:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L42
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_M(r0)     // Catch: java.lang.RuntimeException -> L42
            r1 = r11
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L73
            if (r1 == 0) goto L71
            if (r0 == 0) goto Lc4
            goto L46
        L42:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6d
            throw r0     // Catch: java.lang.RuntimeException -> L6d
        L46:
            r0 = r7
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_g6     // Catch: java.lang.RuntimeException -> L6d
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L6d
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> L6d
            org.bukkit.inventory.PlayerInventory r0 = r0.getInventory()     // Catch: java.lang.RuntimeException -> L6d
            org.bukkit.inventory.ItemStack r0 = r0.getItemInMainHand()     // Catch: java.lang.RuntimeException -> L6d
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.RuntimeException -> L6d
            java.lang.String r0 = r0.toString()     // Catch: java.lang.RuntimeException -> L6d
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_ka.b     // Catch: java.lang.RuntimeException -> L6d
            r2 = 13
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L6d
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L6d
            goto L71
        L6d:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L71:
            r1 = r11
        L73:
            if (r1 == 0) goto Lbc
            if (r0 == 0) goto L8c
            goto L80
        L7c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L88
            throw r0     // Catch: java.lang.RuntimeException -> L88
        L80:
            r0 = r7
            r1 = 0
            r0.Vulcan_v = r1     // Catch: java.lang.RuntimeException -> L88
            goto L8c
        L88:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L8c:
            r0 = r7
            r1 = r11
            if (r1 == 0) goto Lc0
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_g6     // Catch: java.lang.RuntimeException -> Lb8
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> Lb8
            org.bukkit.entity.Player r0 = r0.Vulcan_e(r1)     // Catch: java.lang.RuntimeException -> Lb8
            org.bukkit.inventory.PlayerInventory r0 = r0.getInventory()     // Catch: java.lang.RuntimeException -> Lb8
            org.bukkit.inventory.ItemStack r0 = r0.getItemInOffHand()     // Catch: java.lang.RuntimeException -> Lb8
            org.bukkit.Material r0 = r0.getType()     // Catch: java.lang.RuntimeException -> Lb8
            java.lang.String r0 = r0.toString()     // Catch: java.lang.RuntimeException -> Lb8
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_ka.b     // Catch: java.lang.RuntimeException -> Lb8
            r2 = 15
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> Lb8
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> Lb8
            goto Lbc
        Lb8:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        Lbc:
            if (r0 == 0) goto Lc4
            r0 = r7
        Lc0:
            r1 = 0
            r0.Vulcan_v = r1
        Lc4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_a3(java.lang.Object[]):void");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:17:0x0046
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_a6(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_a6(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:44:0x00e2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean Vulcan_a(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_a(java.lang.Object[]):boolean");
    }

    public double Vulcan_l(Object[] objArr) {
        return Math.abs(this.Vulcan_gc - this.Vulcan_ga);
    }

    public void Vulcan_aR(Object[] objArr) {
        this.Vulcan_P = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
        this.Vulcan_T2 = 0;
    }

    public void Vulcan_aW(Object[] objArr) {
        this.Vulcan_gz = 0;
        this.Vulcan_gs = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_K] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_K] */
    public void Vulcan_uI(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayServerPlayerAbilities wrapperPlayServerPlayerAbilities = (WrapperPlayServerPlayerAbilities) objArr[1];
        long j = (a ^ jLongValue) ^ 39708007353296L;
        ?? M640Vulcan_O = this.Vulcan_g6.m640Vulcan_O(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = () -> {
            r1.lambda$handleAbilities$0(r2);
        };
        M640Vulcan_O[0] = Long.valueOf(j);
        r3.Vulcan_o(r3);
    }

    private void lambda$handleAbilities$0(WrapperPlayServerPlayerAbilities wrapperPlayServerPlayerAbilities) {
        this.Vulcan_G = 0;
        this.Vulcan_gN = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
        this.Vulcan_TJ = wrapperPlayServerPlayerAbilities.isFlightAllowed();
        this.Vulcan_C = wrapperPlayServerPlayerAbilities.getFlySpeed() * 2.0f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0089 A[PHI: r0 r1
  0x0089: PHI (r0v45 ??) = (r0v62 ??), (r0v63 ??) binds: [B:20:0x0056, B:29:0x0087] A[DONT_GENERATE, DONT_INLINE]
  0x0089: PHI (r1v19 ??) = (r1v24 ??), (r1v20 ??) binds: [B:20:0x0056, B:29:0x0087] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00fd A[PHI: r0 r1
  0x00fd: PHI (r0v25 ??) = (r0v69 ??), (r0v70 ??) binds: [B:51:0x00ca, B:60:0x00fb] A[DONT_GENERATE, DONT_INLINE]
  0x00fd: PHI (r1v8 ??) = (r1v25 ??), (r1v9 ??) binds: [B:51:0x00ca, B:60:0x00fb] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00c0 A[EXC_TOP_SPLITTER, PHI: r0
  0x00c0: PHI (r0v19 ??) = (r0v64 ??), (r0v65 ??), (r0v66 ??) binds: [B:40:0x00a3, B:42:0x00a8, B:47:0x00b5] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x004c A[EXC_TOP_SPLITTER, PHI: r0
  0x004c: PHI (r0v39 ??) = (r0v57 ??), (r0v58 ??), (r0v59 ??) binds: [B:6:0x0028, B:8:0x002d, B:16:0x0041] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:80:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v44, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v45, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_Pg(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 272
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_Pg(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0089 A[PHI: r0 r1
  0x0089: PHI (r0v45 ??) = (r0v62 ??), (r0v63 ??) binds: [B:20:0x0056, B:29:0x0087] A[DONT_GENERATE, DONT_INLINE]
  0x0089: PHI (r1v19 ??) = (r1v24 ??), (r1v20 ??) binds: [B:20:0x0056, B:29:0x0087] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00fd A[PHI: r0 r1
  0x00fd: PHI (r0v25 ??) = (r0v69 ??), (r0v70 ??) binds: [B:51:0x00ca, B:60:0x00fb] A[DONT_GENERATE, DONT_INLINE]
  0x00fd: PHI (r1v8 ??) = (r1v25 ??), (r1v9 ??) binds: [B:51:0x00ca, B:60:0x00fb] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00c0 A[EXC_TOP_SPLITTER, PHI: r0
  0x00c0: PHI (r0v19 ??) = (r0v64 ??), (r0v65 ??), (r0v66 ??) binds: [B:40:0x00a3, B:42:0x00a8, B:47:0x00b5] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x004c A[EXC_TOP_SPLITTER, PHI: r0
  0x004c: PHI (r0v39 ??) = (r0v57 ??), (r0v58 ??), (r0v59 ??) binds: [B:6:0x0028, B:8:0x002d, B:16:0x0041] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:80:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v38, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v44, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v45, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v64 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v70 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v25 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m859Vulcan_j(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 272
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.m859Vulcan_j(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00e3  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0078 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v34, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v35 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v38, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v45, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v47, types: [int] */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56 */
    /* JADX WARN: Type inference failed for: r0v57 */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v28, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v34 */
    /* JADX WARN: Type inference failed for: r1v35 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_aJ(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 253
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_ka.Vulcan_aJ(java.lang.Object[]):void");
    }

    private void lambda$handleUnloadedChunk$1(Location location) {
        this.Vulcan_g6.Vulcan_e(new Object[0]).teleport(location, PlayerTeleportEvent.TeleportCause.UNKNOWN);
    }

    public void Vulcan_t(Object[] objArr) {
        this.Vulcan_Ne.add((Runnable) objArr[0]);
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public void m860Vulcan_a(Object[] objArr) {
        this.Vulcan_Ne.forEach((v0) -> {
            v0.run();
        });
        this.Vulcan_Ne.clear();
    }
}
