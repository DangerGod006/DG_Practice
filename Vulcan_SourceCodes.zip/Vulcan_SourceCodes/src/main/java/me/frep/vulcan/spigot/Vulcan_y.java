package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.HashSet;
import java.util.Set;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_y.class */
public class Vulcan_y {
    private final double Vulcan_q;
    private final double Vulcan_k;
    private final double Vulcan_m;
    private boolean Vulcan_h;
    private boolean Vulcan_v;
    private boolean Vulcan_t;
    private double Vulcan_Q;
    private double Vulcan_O;
    private double Vulcan_j;
    private double Vulcan_I;
    private float Vulcan_y;
    private Set Vulcan_u;
    private static AbstractCheck[] Vulcan_i;
    private static final long a = Vulcan_n.a(8482098368038633192L, 8155592177267124701L, MethodHandles.lookup().lookupClass()).a(51407264651024L);

    public static void Vulcan_p(AbstractCheck[] abstractCheckArr) {
        Vulcan_i = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_R() {
        return Vulcan_i;
    }

    static {
        if (Vulcan_R() == null) {
            Vulcan_p(new AbstractCheck[5]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public void Vulcan_w(Object[] objArr) {
        this.Vulcan_h = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_G(Object[] objArr) {
        this.Vulcan_v = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_h(Object[] objArr) {
        this.Vulcan_t = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public void m1092Vulcan_p(Object[] objArr) {
        this.Vulcan_Q = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_d(Object[] objArr) {
        this.Vulcan_O = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_j = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public void m1093Vulcan_O(Object[] objArr) {
        this.Vulcan_I = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_o(Object[] objArr) {
        this.Vulcan_y = ((Float) objArr[0]).floatValue();
    }

    public void Vulcan_I(Object[] objArr) {
        this.Vulcan_u = (Set) objArr[0];
    }

    public double Vulcan_Y(Object[] objArr) {
        return this.Vulcan_q;
    }

    public double Vulcan_t(Object[] objArr) {
        return this.Vulcan_k;
    }

    public double Vulcan_S(Object[] objArr) {
        return this.Vulcan_m;
    }

    public boolean Vulcan__(Object[] objArr) {
        return this.Vulcan_h;
    }

    public boolean Vulcan_D(Object[] objArr) {
        return this.Vulcan_v;
    }

    public boolean Vulcan_a(Object[] objArr) {
        return this.Vulcan_t;
    }

    public double Vulcan_l(Object[] objArr) {
        return this.Vulcan_Q;
    }

    public double Vulcan_K(Object[] objArr) {
        return this.Vulcan_O;
    }

    public double Vulcan_O(Object[] objArr) {
        return this.Vulcan_j;
    }

    public double Vulcan_P(Object[] objArr) {
        return this.Vulcan_I;
    }

    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public float m1091Vulcan_K(Object[] objArr) {
        return this.Vulcan_y;
    }

    public Set Vulcan_p(Object[] objArr) {
        return this.Vulcan_u;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v18, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    public Vulcan_y(double d, double d2, double d3) {
        long j = a ^ 112388782185215L;
        this.Vulcan_h = false;
        ?? Vulcan_R = Vulcan_R();
        this.Vulcan_v = false;
        this.Vulcan_t = false;
        try {
            this.Vulcan_Q = 0.0d;
            this.Vulcan_O = 0.0d;
            this.Vulcan_j = 0.0d;
            this.Vulcan_I = 0.0d;
            this.Vulcan_y = 0.6f;
            this.Vulcan_u = new HashSet();
            this.Vulcan_q = d;
            this.Vulcan_k = d2;
            this.Vulcan_m = d3;
            if (Vulcan_R == 0) {
                Vulcan_R = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_R);
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_R);
        }
    }
}
