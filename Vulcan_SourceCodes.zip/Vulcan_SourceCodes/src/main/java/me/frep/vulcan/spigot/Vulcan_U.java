package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_U.class */
public final class Vulcan_U {
    private static String Vulcan_b;
    private static final long a = Vulcan_n.a(8867629921702531554L, -6602713378470112664L, MethodHandles.lookup().lookupClass()).a(127013764110982L);
    private static final String[] b;

    public static void Vulcan_r(String str) {
        Vulcan_b = str;
    }

    public static String Vulcan_W() {
        return Vulcan_b;
    }

    static {
        int i;
        long j = a ^ 135965783000169L;
        Vulcan_r("jlbkMb");
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "²\u000b\u0013R\u00130I_ÀáÓ\r%»*ÕÓä\u0013«\u009f¹àA\u0085\u008b\u0089=ÿódÍL\u0010[çTïíð8\u008açÀ#¼y ¸Ã5¨\u0083\u0015·%oÆë\u001aÛ\u000bÀXÖ\u0083N[/Ò\u009d±ª\u0080 ÜGÎ@¼\tÌüÈÏÝÛJ\u0094R\u0084¢Â\u000f{\u008dÒ";
        int length = "²\u000b\u0013R\u00130I_ÀáÓ\r%»*ÕÓä\u0013«\u009f¹àA\u0085\u008b\u0089=ÿódÍL\u0010[çTïíð8\u008açÀ#¼y ¸Ã5¨\u0083\u0015·%oÆë\u001aÛ\u000bÀXÖ\u0083N[/Ò\u009d±ª\u0080 ÜGÎ@¼\tÌüÈÏÝÛJ\u0094R\u0084¢Â\u000f{\u008dÒ".length();
        char cCharAt = '(';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "×\u0006ùa\u0013\u001b_¤\u008d\u001a\u0095Þ«\u009fg\u0090M\u0000ÑÛ3\u0005\u0096p\u001e\r\u0093\u0084©3R\u00115;Hôó³¿\u0092\b\u0094}(\u0095Ô\u009e³\u0082";
                        length = "×\u0006ùa\u0013\u001b_¤\u008d\u001a\u0095Þ«\u009fg\u0090M\u0000ÑÛ3\u0005\u0096p\u001e\r\u0093\u0084©3R\u00115;Hôó³¿\u0092\b\u0094}(\u0095Ô\u009e³\u0082".length();
                        cCharAt = '(';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_U() {
        throw new UnsupportedOperationException(b[1]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:17:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00e3 A[EDGE_INSN: B:50:0x00e3->B:30:0x00e3 BREAK  A[LOOP:1: B:11:0x0077->B:52:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00c3 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v16, types: [double, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r17v0, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2 */
    /* JADX WARN: Type inference failed for: r17v3 */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:25:0x00c0 -> B:14:0x0088). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x00f4 -> B:27:0x00c5). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static double Vulcan_Z(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 274
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_U.Vulcan_Z(java.lang.Object[]):double");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00fd A[EDGE_INSN: B:46:0x00fd->B:34:0x00fd BREAK  A[LOOP:2: B:15:0x0091->B:48:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00dd A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v47, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r17v0, types: [java.util.Iterator] */
    /* JADX WARN: Type inference failed for: r17v1 */
    /* JADX WARN: Type inference failed for: r17v2 */
    /* JADX WARN: Type inference failed for: r17v3 */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x00da -> B:18:0x00a2). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:37:0x010e -> B:31:0x00df). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static double Vulcan_y(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 276
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_U.Vulcan_y(java.lang.Object[]):double");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    private static boolean lambda$getAttributeModifierMove$0(WrapperPlayServerUpdateAttributes.PropertyModifier propertyModifier) {
        long j = a ^ 124404420614076L;
        ?? Vulcan_W = Vulcan_W();
        try {
            try {
                try {
                    Vulcan_W = propertyModifier.getUUID().toString().equals(b[0]);
                    try {
                        try {
                            if (Vulcan_W == 0) {
                                return Vulcan_W;
                            }
                            if (Vulcan_W == 0) {
                                boolean zEquals = propertyModifier.getUUID().toString().equals(b[2]);
                                if (Vulcan_W == 0) {
                                    return zEquals;
                                }
                                if (!zEquals) {
                                    boolean zContains = propertyModifier.getName().toString().toLowerCase().contains(b[3]);
                                    if (Vulcan_W == 0) {
                                        return zContains;
                                    }
                                    if (!zContains) {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        } catch (UnsupportedOperationException unused) {
                            throw a((UnsupportedOperationException) Vulcan_W);
                        }
                    } catch (UnsupportedOperationException unused2) {
                        throw a((UnsupportedOperationException) Vulcan_W);
                    }
                } catch (UnsupportedOperationException unused3) {
                    throw a((UnsupportedOperationException) Vulcan_W);
                }
            } catch (UnsupportedOperationException unused4) {
                throw a((UnsupportedOperationException) Vulcan_W);
            }
        } catch (UnsupportedOperationException unused5) {
            throw a((UnsupportedOperationException) Vulcan_W);
        }
    }
}
