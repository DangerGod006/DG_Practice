package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OP.class */
public class Vulcan_OP implements Listener {
    private static int[] Vulcan_Z;
    private static final long a = Vulcan_n.a(5247653588158311230L, 3075889198572271049L, MethodHandles.lookup().lookupClass()).a(101902670103585L);

    public static void Vulcan_B(int[] iArr) {
        Vulcan_Z = iArr;
    }

    public static int[] Vulcan_D() {
        return Vulcan_Z;
    }

    static {
        if (Vulcan_D() != null) {
            Vulcan_B(new int[4]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler
    public void Vulcan_x(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        long j = a ^ 137719219705000L;
        ?? Vulcan_D = Vulcan_D();
        try {
            try {
                Entity entity = entityDamageByEntityEvent.getEntity();
                if (Vulcan_D == 0) {
                    Vulcan_D = entity instanceof Player;
                    if (Vulcan_D == 0) {
                        return;
                    } else {
                        entity = entityDamageByEntityEvent.getEntity();
                    }
                }
                if (Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{(Player) entity}) != null && Vulcan_r.INSTANCE.Vulcan_O()) {
                }
            } catch (RuntimeException unused) {
                throw a(Vulcan_D);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_D);
        }
    }
}
