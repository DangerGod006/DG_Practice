package me.frep.vulcan.spigot.check.impl.player.badpackets;

import com.github.retrooper.packetevents.event.PacketEvent;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPacketsQ.class */
@CheckInfo(name = "Bad Packets", type = 'Q', complexType = "Hotbar", description = "Too big HeldItemSlot packet.")
public class BadPacketsQ extends AbstractCheck {
    private static final String b;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0055, code lost:
    
        r8 = 20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x005a, code lost:
    
        r8 = 11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x005f, code lost:
    
        r8 = 122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0064, code lost:
    
        r8 = 122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0069, code lost:
    
        r8 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x006e, code lost:
    
        r8 = 119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0070, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0078, code lost:
    
        if (r4 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x007b, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0080, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0084, code lost:
    
        if (r4 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0088, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x009a, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0008, code lost:
    
        me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ.b = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001d, code lost:
    
        if (r2 <= 1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0020, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0023, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x002a, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0050, code lost:
    
        r8 = 30;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x0020, B:19:0x0080], limit reached: 24 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v2, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0084 -> B:6:0x0020). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 97
            java.lang.String r1 = "\f\u0019\u0005o&"
            r2 = -1
            goto Le
        L8:
            me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ.b = r0
            goto L9a
        Le:
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            char[] r2 = r2.toCharArray()
            r3 = r2; r2 = r1; r1 = r3; 
            int r3 = r3.length
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r4 = 0
            r11 = r4
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = 1
            if (r5 > r6) goto L80
        L20:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L23:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L50;
                case 1: goto L55;
                case 2: goto L5a;
                case 3: goto L5f;
                case 4: goto L64;
                case 5: goto L69;
                default: goto L6e;
            }
        L50:
            r8 = 30
            goto L70
        L55:
            r8 = 20
            goto L70
        L5a:
            r8 = 11
            goto L70
        L5f:
            r8 = 122(0x7a, float:1.71E-43)
            goto L70
        L64:
            r8 = 122(0x7a, float:1.71E-43)
            goto L70
        L69:
            r8 = 74
            goto L70
        L6e:
            r8 = 119(0x77, float:1.67E-43)
        L70:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L80
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L23
        L80:
            r6 = r4; r5 = r3; r4 = r2; r3 = r6; r2 = r5; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r11
            if (r5 > r6) goto L20
        L88:
            java.lang.String r4 = new java.lang.String
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            java.lang.String r3 = r3.intern()
            r4 = r2; r2 = r3; r3 = r4; 
            r3 = r1; r1 = r2; r2 = r3; 
            goto L8
        L9a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ.m1249clinit():void");
    }

    public BadPacketsQ(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v21, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsQ] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ?? r1 = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        long j = jLongValue ^ 96001856370153L;
        long j2 = jLongValue ^ 512108961922L;
        ?? Vulcan_n = BadPackets8.Vulcan_n();
        try {
            Vulcan_n = this;
            ?? r0 = Vulcan_n;
            if (Vulcan_n == 0) {
                try {
                    ?? r3 = new Object[2];
                    r1[1] = Long.valueOf(j);
                    r3[0] = r3;
                    Vulcan_n = Vulcan_n.Vulcan_A(r3);
                    if (Vulcan_n != 0) {
                        r0 = this;
                    } else {
                        return;
                    }
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) Vulcan_n);
                }
            }
            int slot = r0.Vulcan_b.Vulcan_Q(new Object[0]).getSlot();
            if (jLongValue > 0) {
                ?? r02 = slot;
                if (r02 > 8) {
                    try {
                        Object[] objArr2 = new Object[2];
                        objArr2[1] = b + slot;
                        r02 = objArr2;
                        this[0] = Long.valueOf(j2);
                        r02.Vulcan_Q(objArr2);
                    } catch (RuntimeException unused2) {
                        throw a((RuntimeException) r02);
                    }
                }
            }
        } catch (RuntimeException unused3) {
            throw a((RuntimeException) Vulcan_n);
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
