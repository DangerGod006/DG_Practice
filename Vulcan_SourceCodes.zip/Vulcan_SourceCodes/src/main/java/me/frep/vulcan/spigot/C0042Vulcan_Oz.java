package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientEntityAction;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientHeldItemChange;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerBlockPlacement;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerDigging;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.api.data.IPlayerData;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Oz, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oz.class */
public class C0042Vulcan_Oz implements IPlayerData {
    private final User Vulcan_H;

    @Nullable
    private Player Vulcan_m;
    private String Vulcan_o;
    private int Vulcan_n;
    private UUID Vulcan_s;
    private ClientVersion Vulcan_y;
    private String Vulcan_A;
    private boolean Vulcan_r;
    private boolean Vulcan_i;
    private boolean Vulcan_z;
    private boolean Vulcan_g;
    private int Vulcan_t;
    private int Vulcan_U;
    private int Vulcan_I;
    private int Vulcan_x;
    private int Vulcan_O;
    private int Vulcan_L;
    private int Vulcan_d;
    private final long Vulcan_B;
    private final int Vulcan_a;
    private long Vulcan_Z;
    private long Vulcan_w;
    private WrapperPlayClientPlayerFlying Vulcan_R;
    private WrapperPlayClientInteractEntity Vulcan_X;
    private WrapperPlayClientPlayerDigging Vulcan_Q;
    private WrapperPlayClientEntityAction Vulcan_q;
    private WrapperPlayClientHeldItemChange Vulcan_u;
    private WrapperPlayClientPlayerBlockPlacement Vulcan_v;
    private int Vulcan_S;
    private List Vulcan_l;
    private HashSet Vulcan_N;
    private HashSet Vulcan_f;
    private final Vulcan_yv Vulcan_G;
    private final Vulcan_Oc Vulcan_E;
    private final C0047Vulcan_fi Vulcan_e;
    private final Vulcan_kw Vulcan_V;
    private final Vulcan_ka Vulcan_M;
    private final C0052Vulcan_ko Vulcan_C;
    private final Vulcan_q Vulcan_P;
    private final C0050Vulcan_k Vulcan__;
    private final Vulcan_K Vulcan_j;
    private final C0036Vulcan_Oj Vulcan_F;
    private final C0036Vulcan_Oj Vulcan_K;
    private long Vulcan_h;
    private static boolean Vulcan_c;
    private static final long a = Vulcan_n.a(2757340450629101744L, 8579216606400099329L, MethodHandles.lookup().lookupClass()).a(29892250947354L);
    private static final String[] b;

    public static void Vulcan_b(boolean z) {
        Vulcan_c = z;
    }

    public static boolean Vulcan_D() {
        return Vulcan_c;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_r() {
        return !Vulcan_D();
    }

    static {
        int i;
        long j = a ^ 29568932324510L;
        Vulcan_b(true);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[13];
        int i3 = 0;
        String str = "\u009b )ÜG\u000bÊ\u0000\u00897\u0094:b\u0098F\u009dtõÄ1P\u0004È7\u0018hfJ\u0003L!H\u008aÃ\u0015æ¬iÆ\u0012µ\u0092Ul\u001f8AòB\u0010Füvi:tH\u0010\u0003\u0086¼Í;Íå®\u0010\u009b )ÜG\u000bÊ\u0000\u0097<Ù¢!âG\u001b\u0018hfJ\u0003L!H\u008aÃ\u0015æ¬iÆ\u0012µ\u0092Ul\u001f8AòB\u0010a0\u008f@ý®X\u0099ëÌ¤ÍLç´\u0090(.\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶K_ub\u0083pÇ\u009c'v\u0011Ñ¿\u00adÐú\u0018\u009b )ÜG\u000bÊ\u0000\u00897\u0094:b\u0098F\u009dtõÄ1P\u0004È7(.\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶¬jí\u008e\u0088ê¹$}\u00adCLLÖg\u001a\u0010a0\u008f@ý®X\u0099ëÌ¤ÍLç´\u0090\u0010Füvi:tH\u0010\u0003\u0086¼Í;Íå®";
        int length = "\u009b )ÜG\u000bÊ\u0000\u00897\u0094:b\u0098F\u009dtõÄ1P\u0004È7\u0018hfJ\u0003L!H\u008aÃ\u0015æ¬iÆ\u0012µ\u0092Ul\u001f8AòB\u0010Füvi:tH\u0010\u0003\u0086¼Í;Íå®\u0010\u009b )ÜG\u000bÊ\u0000\u0097<Ù¢!âG\u001b\u0018hfJ\u0003L!H\u008aÃ\u0015æ¬iÆ\u0012µ\u0092Ul\u001f8AòB\u0010a0\u008f@ý®X\u0099ëÌ¤ÍLç´\u0090(.\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶K_ub\u0083pÇ\u009c'v\u0011Ñ¿\u00adÐú\u0018\u009b )ÜG\u000bÊ\u0000\u00897\u0094:b\u0098F\u009dtõÄ1P\u0004È7(.\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶¬jí\u008e\u0088ê¹$}\u00adCLLÖg\u001a\u0010a0\u008f@ý®X\u0099ëÌ¤ÍLç´\u0090\u0010Füvi:tH\u0010\u0003\u0086¼Í;Íå®".length();
        char cCharAt = 24;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = ".\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶0ø[¡Å¨j©¡Sk³\u0007îþ´\u0010\u009b )ÜG\u000bÊ\u0000\u0097<Ù¢!âG\u001b";
                        length = ".\u009c\u001fÇµ\u008b\u000e\n¥\u0017D,Ý\u008a\r÷ßÓw\u0001Á\u009f\u0083¶0ø[¡Å¨j©¡Sk³\u0007îþ´\u0010\u009b )ÜG\u000bÊ\u0000\u0097<Ù¢!âG\u001b".length();
                        cCharAt = '(';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_w(@Nullable Player player) {
        this.Vulcan_m = player;
    }

    public void Vulcan_p(Object[] objArr) {
        this.Vulcan_o = (String) objArr[0];
    }

    public void Vulcan_j(Object[] objArr) {
        this.Vulcan_n = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public void m642Vulcan_q(Object[] objArr) {
        this.Vulcan_s = (UUID) objArr[0];
    }

    public void Vulcan_Z(Object[] objArr) {
        this.Vulcan_y = (ClientVersion) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public void m643Vulcan_T(Object[] objArr) {
        this.Vulcan_A = (String) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_h, reason: collision with other method in class */
    public void m644Vulcan_h(Object[] objArr) {
        this.Vulcan_r = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_K(Object[] objArr) {
        this.Vulcan_i = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_G(Object[] objArr) {
        this.Vulcan_z = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_w, reason: collision with other method in class */
    public void m645Vulcan_w(Object[] objArr) {
        this.Vulcan_g = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_I(Object[] objArr) {
        this.Vulcan_t = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_m(Object[] objArr) {
        this.Vulcan_U = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public void m646Vulcan_Q(Object[] objArr) {
        this.Vulcan_I = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public void m647Vulcan_y(Object[] objArr) {
        this.Vulcan_x = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_i, reason: collision with other method in class */
    public void m648Vulcan_i(Object[] objArr) {
        this.Vulcan_O = ((Integer) objArr[0]).intValue();
    }

    /* JADX INFO: renamed from: Vulcan_g, reason: collision with other method in class */
    public void m649Vulcan_g(Object[] objArr) {
        this.Vulcan_L = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan__(Object[] objArr) {
        this.Vulcan_d = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_L(Object[] objArr) {
        this.Vulcan_Z = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_D(Object[] objArr) {
        this.Vulcan_w = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_s(Object[] objArr) {
        this.Vulcan_R = (WrapperPlayClientPlayerFlying) objArr[0];
    }

    public void Vulcan_P(Object[] objArr) {
        this.Vulcan_X = (WrapperPlayClientInteractEntity) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public void m650Vulcan_B(Object[] objArr) {
        this.Vulcan_Q = (WrapperPlayClientPlayerDigging) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public void m651Vulcan_Y(Object[] objArr) {
        this.Vulcan_q = (WrapperPlayClientEntityAction) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_e, reason: collision with other method in class */
    public void m652Vulcan_e(Object[] objArr) {
        this.Vulcan_u = (WrapperPlayClientHeldItemChange) objArr[0];
    }

    public void Vulcan_b(Object[] objArr) {
        this.Vulcan_v = (WrapperPlayClientPlayerBlockPlacement) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public void m653Vulcan_l(Object[] objArr) {
        this.Vulcan_S = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_t(Object[] objArr) {
        this.Vulcan_l = (List) objArr[0];
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_N = (HashSet) objArr[0];
    }

    /* JADX INFO: renamed from: Vulcan_X, reason: collision with other method in class */
    public void m654Vulcan_X(Object[] objArr) {
        this.Vulcan_f = (HashSet) objArr[0];
    }

    public void Vulcan_x(Object[] objArr) {
        this.Vulcan_h = ((Long) objArr[0]).longValue();
    }

    public User Vulcan_V(Object[] objArr) {
        return this.Vulcan_H;
    }

    @Nullable
    public Player Vulcan_e(Object[] objArr) {
        return this.Vulcan_m;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public String getClientBrand() {
        return this.Vulcan_o;
    }

    public int Vulcan_B(Object[] objArr) {
        return this.Vulcan_n;
    }

    public UUID Vulcan_o(Object[] objArr) {
        return this.Vulcan_s;
    }

    public ClientVersion Vulcan_y(Object[] objArr) {
        return this.Vulcan_y;
    }

    public String Vulcan_c(Object[] objArr) {
        return this.Vulcan_A;
    }

    /* JADX INFO: renamed from: Vulcan_y, reason: collision with other method in class */
    public boolean m631Vulcan_y(Object[] objArr) {
        return this.Vulcan_r;
    }

    /* JADX INFO: renamed from: Vulcan_V, reason: collision with other method in class */
    public boolean m632Vulcan_V(Object[] objArr) {
        return this.Vulcan_i;
    }

    public boolean Vulcan_u(Object[] objArr) {
        return this.Vulcan_z;
    }

    public boolean Vulcan_O(Object[] objArr) {
        return this.Vulcan_g;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getTotalViolations() {
        return this.Vulcan_t;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getCombatViolations() {
        return this.Vulcan_U;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getMovementViolations() {
        return this.Vulcan_I;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getPlayerViolations() {
        return this.Vulcan_x;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getAutoClickerViolations() {
        return this.Vulcan_O;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getScaffoldViolations() {
        return this.Vulcan_L;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getTimerViolations() {
        return this.Vulcan_d;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public long getJoinTime() {
        return this.Vulcan_B;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public int getJoinTicks() {
        return this.Vulcan_a;
    }

    @Override // me.frep.vulcan.api.data.IPlayerData
    public long getLastClientBrandAlert() {
        return this.Vulcan_Z;
    }

    public long Vulcan_r(Object[] objArr) {
        return this.Vulcan_w;
    }

    public WrapperPlayClientPlayerFlying Vulcan_q(Object[] objArr) {
        return this.Vulcan_R;
    }

    public WrapperPlayClientInteractEntity Vulcan_M(Object[] objArr) {
        return this.Vulcan_X;
    }

    public WrapperPlayClientPlayerDigging Vulcan_l(Object[] objArr) {
        return this.Vulcan_Q;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public WrapperPlayClientEntityAction m633Vulcan_c(Object[] objArr) {
        return this.Vulcan_q;
    }

    public WrapperPlayClientHeldItemChange Vulcan_Q(Object[] objArr) {
        return this.Vulcan_u;
    }

    public WrapperPlayClientPlayerBlockPlacement Vulcan_k(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX INFO: renamed from: Vulcan_c, reason: collision with other method in class */
    public int m634Vulcan_c(Object[] objArr) {
        return this.Vulcan_S;
    }

    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public List m635Vulcan_B(Object[] objArr) {
        return this.Vulcan_l;
    }

    public HashSet Vulcan_h(Object[] objArr) {
        return this.Vulcan_N;
    }

    public HashSet Vulcan_T(Object[] objArr) {
        return this.Vulcan_f;
    }

    public Vulcan_yv Vulcan_C(Object[] objArr) {
        return this.Vulcan_G;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public Vulcan_Oc m636Vulcan_T(Object[] objArr) {
        return this.Vulcan_E;
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public C0047Vulcan_fi m637Vulcan_r(Object[] objArr) {
        return this.Vulcan_e;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public Vulcan_kw m638Vulcan_O(Object[] objArr) {
        return this.Vulcan_V;
    }

    /* JADX INFO: renamed from: Vulcan_M, reason: collision with other method in class */
    public Vulcan_ka m639Vulcan_M(Object[] objArr) {
        return this.Vulcan_M;
    }

    public C0052Vulcan_ko Vulcan_z(Object[] objArr) {
        return this.Vulcan_C;
    }

    public Vulcan_q Vulcan_X(Object[] objArr) {
        return this.Vulcan_P;
    }

    public C0050Vulcan_k Vulcan_W(Object[] objArr) {
        return this.Vulcan__;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public Vulcan_K m640Vulcan_O(Object[] objArr) {
        return this.Vulcan_j;
    }

    public C0036Vulcan_Oj Vulcan_R(Object[] objArr) {
        return this.Vulcan_F;
    }

    public C0036Vulcan_Oj Vulcan_g(Object[] objArr) {
        return this.Vulcan_K;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v30, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    public C0042Vulcan_Oz(User user) {
        long j = a ^ 14811941158840L;
        ?? Vulcan_r = Vulcan_r();
        String[] strArr = b;
        this.Vulcan_o = strArr[9];
        this.Vulcan_n = -42069;
        this.Vulcan_s = null;
        this.Vulcan_y = ClientVersion.UNKNOWN;
        this.Vulcan_A = strArr[5];
        this.Vulcan_r = false;
        try {
            this.Vulcan_i = false;
            this.Vulcan_z = false;
            this.Vulcan_g = false;
            this.Vulcan_B = System.currentTimeMillis();
            this.Vulcan_a = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
            this.Vulcan_S = 0;
            this.Vulcan_l = new ArrayList();
            this.Vulcan_N = new HashSet();
            this.Vulcan_f = new HashSet();
            this.Vulcan_G = new Vulcan_yv(this);
            this.Vulcan_E = new Vulcan_Oc(this);
            this.Vulcan_e = new C0047Vulcan_fi(this);
            this.Vulcan_V = new Vulcan_kw(this);
            this.Vulcan_M = new Vulcan_ka(this);
            this.Vulcan_C = new C0052Vulcan_ko(this);
            this.Vulcan_P = new Vulcan_q(this);
            this.Vulcan__ = new C0050Vulcan_k(this);
            this.Vulcan_j = new Vulcan_K(this);
            this.Vulcan_F = new C0036Vulcan_Oj(100);
            this.Vulcan_K = new C0036Vulcan_Oj(100);
            this.Vulcan_h = -1L;
            this.Vulcan_H = user;
            if (Vulcan_r != 0) {
                Vulcan_r = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_r);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_r);
        }
    }

    public boolean Vulcan_i(Object[] objArr) {
        return C0044Vulcan_fb.Vulcan_h(new Object[]{this});
    }

    public boolean Vulcan_H(Object[] objArr) {
        return C0044Vulcan_fb.Vulcan_R(new Object[]{this});
    }

    public boolean Vulcan_Y(Object[] objArr) {
        return C0044Vulcan_fb.Vulcan_B(new Object[]{this});
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public long m641Vulcan_a(Object[] objArr) {
        return this.Vulcan_h;
    }

    public boolean Vulcan_n(Object[] objArr) {
        return this.Vulcan_y.isOlderThan(ClientVersion.V_1_9);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_w(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            long r0 = me.frep.vulcan.spigot.C0042Vulcan_Oz.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            boolean r0 = Vulcan_r()
            r9 = r0
            r0 = r5
            com.github.retrooper.packetevents.protocol.player.ClientVersion r0 = r0.Vulcan_y     // Catch: java.lang.RuntimeException -> L2c
            com.github.retrooper.packetevents.protocol.player.ClientVersion r1 = com.github.retrooper.packetevents.protocol.player.ClientVersion.V_1_21_2     // Catch: java.lang.RuntimeException -> L2c
            boolean r0 = r0.isNewerThanOrEquals(r1)     // Catch: java.lang.RuntimeException -> L2c
            r1 = r9
            if (r1 != 0) goto L3e
            if (r0 == 0) goto L51
            goto L30
        L2c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3a
            throw r0     // Catch: java.lang.RuntimeException -> L3a
        L30:
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch: java.lang.RuntimeException -> L3a
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_j(r0)     // Catch: java.lang.RuntimeException -> L3a
            goto L3e
        L3a:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3e:
            r1 = r9
            if (r1 != 0) goto L4e
            if (r0 == 0) goto L51
            goto L4d
        L49:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L4d:
            r0 = 1
        L4e:
            goto L52
        L51:
            r0 = 0
        L52:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0042Vulcan_Oz.Vulcan_w(java.lang.Object[]):boolean");
    }

    public boolean Vulcan_a(Object[] objArr) {
        return this.Vulcan_y.isOlderThanOrEquals(ClientVersion.V_1_8);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v14, types: [me.frep.vulcan.spigot.Vulcan_yU] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [me.frep.vulcan.spigot.Vulcan_yv] */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v9, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /* JADX INFO: renamed from: Vulcan_Y, reason: collision with other method in class */
    public List m630Vulcan_Y(Object[] objArr) {
        ?? A;
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        long j = jLongValue ^ 10206925894839L;
        boolean zVulcan_D = Vulcan_D();
        ArrayList arrayList = new ArrayList();
        ?? Values = Vulcan_yU.values();
        int length = Values.length;
        int i = 0;
        try {
            try {
                do {
                    A = i;
                    if (A < length) {
                        ?? r0 = Values[i];
                        A = zVulcan_D;
                        if (jLongValue >= 0) {
                            if (A != 0) {
                                try {
                                    try {
                                        ?? r02 = this.Vulcan_G;
                                        ?? r3 = new Object[2];
                                        r0[1] = Long.valueOf(j);
                                        r3[0] = r3;
                                        A = r02.Vulcan_r(r3);
                                        if (A != 0) {
                                            arrayList.add(r0.toString());
                                        }
                                        i++;
                                    } catch (RuntimeException unused) {
                                        throw a((RuntimeException) A);
                                    }
                                } catch (RuntimeException unused2) {
                                    A = a((RuntimeException) A);
                                    throw A;
                                }
                            }
                            A = zVulcan_D;
                        }
                    }
                    break;
                } while (A != 0);
                break;
                A = arrayList;
                if (AbstractCheck.Vulcan_k() != null) {
                    Vulcan_b(!zVulcan_D);
                }
                return A;
            } catch (RuntimeException unused3) {
                A = a((RuntimeException) A);
                throw A;
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) A);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:131:0x027d
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_U(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 1357
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0042Vulcan_Oz.Vulcan_U(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void lambda$handleClientBrand$0() {
        long j = (a ^ 18727368806166L) ^ 1659543434554L;
        Player player = this.Vulcan_m;
        Object[] objArr = new Object[2];
        b[1][1] = Long.valueOf(j);
        objArr[0] = objArr;
        player.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void lambda$handleClientBrand$1() {
        long j = (a ^ 31209573733050L) ^ 14193287440534L;
        Player player = this.Vulcan_m;
        Object[] objArr = new Object[2];
        b[4][1] = Long.valueOf(j);
        objArr[0] = objArr;
        player.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.String] */
    private void lambda$handleClientBrand$2() {
        long j = (a ^ 63232267825195L) ^ 45115452803591L;
        Player player = this.Vulcan_m;
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_tx.replaceAll(b[3], this.Vulcan_o)[1] = Long.valueOf(j);
        objArr[0] = objArr;
        player.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    /* JADX WARN: Type inference failed for: r1v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.String] */
    private void lambda$handleClientBrand$3() {
        long j = (a ^ 127593325748702L) ^ 110507504573426L;
        Player player = this.Vulcan_m;
        String str = Vulcan_fe.Vulcan_tx;
        String[] strArr = b;
        Object[] objArr = new Object[2];
        str.replaceAll(strArr[3], this.Vulcan_o)[1] = Long.valueOf(j);
        objArr[0] = objArr;
        player.sendMessage(Vulcan_ym.Vulcan_X(objArr));
        Player player2 = this.Vulcan_m;
        Object[] objArr2 = new Object[2];
        Vulcan_fe.Vulcan_tx.replaceAll(strArr[3], this.Vulcan_o)[1] = Long.valueOf(j);
        objArr2[0] = objArr2;
        player2.kickPlayer(Vulcan_ym.Vulcan_X(objArr2));
    }

    private static void lambda$handleClientBrand$4(String str) {
        Vulcan_r.INSTANCE.Vulcan_e().Vulcan_A(new Object[]{str});
    }

    private void lambda$handleClientBrand$5() {
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        String str = Vulcan_fe.Vulcan_bx;
        String[] strArr = b;
        vulcan_OBVulcan_e.Vulcan_A(new Object[]{str.replaceAll(strArr[2], this.Vulcan_m.getName()).replaceAll(strArr[0], this.Vulcan_H.getClientVersion().getReleaseName()).replaceAll(strArr[12], this.Vulcan_o)});
    }
}
