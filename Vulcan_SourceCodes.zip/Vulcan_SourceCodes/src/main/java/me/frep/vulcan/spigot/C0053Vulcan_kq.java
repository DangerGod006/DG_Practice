package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_kq, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kq.class */
public class C0053Vulcan_kq implements Listener {
    private static final long a = Vulcan_n.a(-6567934326751605604L, -2317323376897534974L, MethodHandles.lookup().lookupClass()).a(243193078488256L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @EventHandler(ignoreCancelled = true)
    public void Vulcan_D(EntityResurrectEvent entityResurrectEvent) {
        long j = a ^ 70678069053105L;
        ?? Vulcan_G = C0038Vulcan_Om.Vulcan_G();
        try {
            try {
                LivingEntity entity = entityResurrectEvent.getEntity();
                if (Vulcan_G == 0) {
                    Vulcan_G = entity instanceof Player;
                    if (Vulcan_G != 0) {
                        entity = entityResurrectEvent.getEntity();
                    } else {
                        return;
                    }
                }
                C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{(Player) entity});
                C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
                if (Vulcan_G == 0) {
                    if (c0042Vulcan_Oz == null) {
                        return;
                    } else {
                        c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
                    }
                }
                c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).Vulcan_K(new Object[0]);
            } catch (RuntimeException unused) {
                throw a(Vulcan_G);
            }
        } catch (RuntimeException unused2) {
            throw a(Vulcan_G);
        }
    }
}
