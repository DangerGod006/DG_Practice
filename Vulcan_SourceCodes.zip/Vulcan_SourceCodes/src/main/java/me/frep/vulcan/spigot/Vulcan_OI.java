package me.frep.vulcan.spigot;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_OI.class */
public abstract class Vulcan_OI extends Vulcan_OZ {
    public abstract void Vulcan_w(Object[] objArr);

    public Vulcan_OI(List list) {
        super(list);
    }

    @Override // java.util.List, java.util.Collection
    public int size() {
        return this.Vulcan_Y.size();
    }

    @Override // java.util.List, java.util.Collection
    public boolean isEmpty() {
        return this.Vulcan_Y.isEmpty();
    }

    @Override // java.util.List, java.util.Collection
    public boolean contains(Object obj) {
        return this.Vulcan_Y.contains(obj);
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        Vulcan_w(new Object[0]);
        return listIterator();
    }

    @Override // java.util.List, java.util.Collection
    public Object[] toArray() {
        return this.Vulcan_Y.toArray();
    }

    @Override // java.util.List, java.util.Collection
    public boolean add(Object obj) {
        return this.Vulcan_Y.add(obj);
    }

    @Override // java.util.List, java.util.Collection
    public boolean remove(Object obj) {
        return this.Vulcan_Y.remove(obj);
    }

    @Override // java.util.List, java.util.Collection
    public boolean addAll(Collection collection) {
        return this.Vulcan_Y.addAll(collection);
    }

    @Override // java.util.List
    public boolean addAll(int i, Collection collection) {
        return this.Vulcan_Y.addAll(i, collection);
    }

    @Override // java.util.List, java.util.Collection
    public void clear() {
        this.Vulcan_Y.clear();
    }

    @Override // java.util.List
    public Object get(int i) {
        return this.Vulcan_Y.get(i);
    }

    @Override // java.util.List
    public Object set(int i, Object obj) {
        return this.Vulcan_Y.set(i, obj);
    }

    @Override // java.util.List
    public void add(int i, Object obj) {
        this.Vulcan_Y.add(i, obj);
    }

    @Override // java.util.List
    public Object remove(int i) {
        return this.Vulcan_Y.remove(i);
    }

    @Override // java.util.List
    public int indexOf(Object obj) {
        return this.Vulcan_Y.indexOf(obj);
    }

    @Override // java.util.List
    public int lastIndexOf(Object obj) {
        return this.Vulcan_Y.lastIndexOf(obj);
    }

    @Override // java.util.List
    public ListIterator listIterator() {
        return this.Vulcan_Y.listIterator();
    }

    @Override // java.util.List
    public ListIterator listIterator(int i) {
        return this.Vulcan_Y.listIterator(i);
    }

    @Override // java.util.List
    public List subList(int i, int i2) {
        return this.Vulcan_Y.subList(i, i2);
    }

    @Override // java.util.List, java.util.Collection
    public boolean retainAll(Collection collection) {
        return this.Vulcan_Y.retainAll(collection);
    }

    @Override // java.util.List, java.util.Collection
    public boolean removeAll(Collection collection) {
        return this.Vulcan_Y.removeAll(collection);
    }

    @Override // java.util.List, java.util.Collection
    public boolean containsAll(Collection collection) {
        return this.Vulcan_Y.containsAll(collection);
    }

    @Override // java.util.List, java.util.Collection
    public Object[] toArray(Object[] objArr) {
        return this.Vulcan_Y.toArray(objArr);
    }
}
