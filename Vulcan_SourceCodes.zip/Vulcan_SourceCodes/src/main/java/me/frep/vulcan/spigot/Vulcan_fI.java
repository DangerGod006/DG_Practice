package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.player.User;
import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fI.class */
public final class Vulcan_fI {
    private final Map Vulcan_Y = new ConcurrentHashMap();
    private static String Vulcan_T;
    private static final long a = Vulcan_n.a(-8656732091262350701L, 1486297328033137633L, MethodHandles.lookup().lookupClass()).a(75553581883722L);

    public static void Vulcan_o(String str) {
        Vulcan_T = str;
    }

    public static String Vulcan_b() {
        return Vulcan_T;
    }

    static {
        if (Vulcan_b() != null) {
            Vulcan_o("dDrrgb");
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public C0042Vulcan_Oz Vulcan_L(Object[] objArr) {
        return (C0042Vulcan_Oz) this.Vulcan_Y.get(((Player) objArr[0]).getUniqueId());
    }

    public C0042Vulcan_Oz Vulcan_M(Object[] objArr) {
        return (C0042Vulcan_Oz) this.Vulcan_Y.get(((User) objArr[0]).getUUID());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public void Vulcan_J(Object[] objArr) {
        User user = (User) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String strVulcan_b = Vulcan_b();
        this.Vulcan_Y.put(user.getUUID(), new C0042Vulcan_Oz(user));
        ?? r0 = strVulcan_b;
        if (r0 != 0) {
            try {
                r0 = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
            } catch (RuntimeException unused) {
                throw a(r0);
            }
        }
    }

    public void Vulcan_T(Object[] objArr) {
        this.Vulcan_Y.remove((UUID) objArr[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.String] */
    public void Vulcan__(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        User user = (User) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_b = Vulcan_b();
        this.Vulcan_Y.remove(user.getUUID());
        try {
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_b = "PGrGdb";
                Vulcan_o("PGrGdb");
            }
        } catch (RuntimeException unused) {
            throw a(Vulcan_b);
        }
    }

    public Collection Vulcan_c(Object[] objArr) {
        return this.Vulcan_Y.values();
    }
}
