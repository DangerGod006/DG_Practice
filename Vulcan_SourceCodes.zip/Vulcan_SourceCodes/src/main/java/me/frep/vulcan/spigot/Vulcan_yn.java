package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_yn.class */
public class Vulcan_yn extends PlaceholderExpansion {
    private final VulcanPlugin Vulcan_D;
    private static int[] Vulcan_j;
    private static final long a = Vulcan_n.a(4564348066689561065L, 6601365581099031302L, MethodHandles.lookup().lookupClass()).a(170728151248427L);
    private static final String[] b;

    public static void Vulcan_d(int[] iArr) {
        Vulcan_j = iArr;
    }

    public static int[] Vulcan_a() {
        return Vulcan_j;
    }

    static {
        int i;
        long j = a ^ 49725998997779L;
        Vulcan_d(new int[4]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[8];
        int i3 = 0;
        String str = "\u009dª\u0014\u0011ì;íÌ\u00183¯LDËï§óÒí\u0004§÷j\u007f@úÐ\u0000N°îØæ\u0018\u0083\u00185\u001b\tK\u008dÅU¨\\\u001e¶÷®\">WJÝ\u001cÄ:\u001a\u0018Ú\u0005)Ä(®\u001b)£àTI[§\u0086\røfI2=æA¦\u0010.OºÃÄ\u001d@;i\u000e\u0004^A·,ù\b¢'»¤/£0>";
        int length = "\u009dª\u0014\u0011ì;íÌ\u00183¯LDËï§óÒí\u0004§÷j\u007f@úÐ\u0000N°îØæ\u0018\u0083\u00185\u001b\tK\u008dÅU¨\\\u001e¶÷®\">WJÝ\u001cÄ:\u001a\u0018Ú\u0005)Ä(®\u001b)£àTI[§\u0086\røfI2=æA¦\u0010.OºÃÄ\u001d@;i\u000e\u0004^A·,ù\b¢'»¤/£0>".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "èe\u009cÏ\u0082®È¶ÇÂö\"\u009c*]\u0003é¶\u0089ï8\u0094tò\u0018\u0014Ê\u000b\u0093ÜøZùNã@#aÉ ää\u001c\u000b\u0003¢ÔFË";
                        length = "èe\u009cÏ\u0082®È¶ÇÂö\"\u009c*]\u0003é¶\u0089ï8\u0094tò\u0018\u0014Ê\u000b\u0093ÜøZùNã@#aÉ ää\u001c\u000b\u0003¢ÔFË".length();
                        cCharAt = 24;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public Vulcan_yn() {
        long j = a ^ 4215525585310L;
        int[] iArrVulcan_a = Vulcan_a();
        this.Vulcan_D = Vulcan_r.INSTANCE.m1084Vulcan_j();
        ?? r0 = iArrVulcan_a;
        if (r0 == 0) {
            try {
                r0 = new AbstractCheck[1];
                AbstractCheck.Vulcan_D((AbstractCheck[]) r0);
            } catch (RuntimeException unused) {
                throw a((RuntimeException) r0);
            }
        }
    }

    public boolean persist() {
        return true;
    }

    public boolean canRegister() {
        return true;
    }

    public String getAuthor() {
        return this.Vulcan_D.getDescription().getAuthors().toString();
    }

    public String getIdentifier() {
        return b[0];
    }

    public String getVersion() {
        return this.Vulcan_D.getDescription().getVersion();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:125:0x0182 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0182: PHI (r0v89 ??) = (r0v17 ??), (r0v79 ??) binds: [B:19:0x0049, B:93:0x017f] A[DONT_GENERATE, DONT_INLINE]
  0x0182: PHI (r14v11 char) = (r14v0 char), (r14v8 char) binds: [B:19:0x0049, B:93:0x017f] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:127:0x00e1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x00e1: PHI (r0v80 ??) = (r0v17 ??), (r0v72 ??) binds: [B:19:0x0049, B:45:0x00de] A[DONT_GENERATE, DONT_INLINE]
  0x00e1: PHI (r14v9 char) = (r14v0 char), (r14v6 char) binds: [B:19:0x0049, B:45:0x00de] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:129:0x015a A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x015a: PHI (r0v73 ??) = (r0v17 ??), (r0v65 ??) binds: [B:19:0x0049, B:81:0x0157] A[DONT_GENERATE, DONT_INLINE]
  0x015a: PHI (r14v7 char) = (r14v0 char), (r14v4 char) binds: [B:19:0x0049, B:81:0x0157] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:133:0x00b8 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x00b8: PHI (r0v66 ??) = (r0v17 ??), (r0v101 ??) binds: [B:19:0x0049, B:33:0x00b5] A[DONT_GENERATE, DONT_INLINE]
  0x00b8: PHI (r14v5 char) = (r14v0 char), (r14v14 char) binds: [B:19:0x0049, B:33:0x00b5] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:137:0x0131 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0131: PHI (r0v59 ??) = (r0v17 ??), (r0v58 ??) binds: [B:19:0x0049, B:69:0x012e] A[DONT_GENERATE, DONT_INLINE]
  0x0131: PHI (r14v3 char) = (r14v0 char), (r14v2 char) binds: [B:19:0x0049, B:69:0x012e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:141:0x0109 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0109: PHI (r0v52 ??) = (r0v17 ??), (r0v88 ??) binds: [B:19:0x0049, B:57:0x0106] A[DONT_GENERATE, DONT_INLINE]
  0x0109: PHI (r14v1 char) = (r14v0 char), (r14v10 char) binds: [B:19:0x0049, B:57:0x0106] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v101 */
    /* JADX WARN: Type inference failed for: r0v102 */
    /* JADX WARN: Type inference failed for: r0v103 */
    /* JADX WARN: Type inference failed for: r0v104 */
    /* JADX WARN: Type inference failed for: r0v105 */
    /* JADX WARN: Type inference failed for: r0v106 */
    /* JADX WARN: Type inference failed for: r0v107 */
    /* JADX WARN: Type inference failed for: r0v108 */
    /* JADX WARN: Type inference failed for: r0v109 */
    /* JADX WARN: Type inference failed for: r0v110 */
    /* JADX WARN: Type inference failed for: r0v111 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v48, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v56, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v58 */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v60, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v63, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v70, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r0v74, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v77, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v79 */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v81, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v83, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v84, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v86, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v88 */
    /* JADX WARN: Type inference failed for: r0v89 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r0v90, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v92, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v93, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v95, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v97 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String onPlaceholderRequest(org.bukkit.entity.Player r7, java.lang.String r8) {
        /*
            Method dump skipped, instruction units count: 547
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_yn.onPlaceholderRequest(org.bukkit.entity.Player, java.lang.String):java.lang.String");
    }
}
