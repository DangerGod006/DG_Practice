package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_k2.class */
public class Vulcan_k2 extends Vulcan_k4 implements CommandExecutor {
    private static final long b = Vulcan_n.a(-3628133384911603714L, 1626352963621238389L, MethodHandles.lookup().lookupClass()).a(133161668860439L);
    private static final String d;

    static {
        long j = b ^ 273329290837L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        d = b(cipher.doFinal("Oõ\rÿÍjp±r\u0089¶b\tõo2".getBytes(CharEncoding.ISO_8859_1))).intern();
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v26, types: [me.frep.vulcan.spigot.Vulcan_OB] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v17, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r9v0, types: [me.frep.vulcan.spigot.Vulcan_k2] */
    public boolean onCommand(CommandSender commandSender, Command command, String str, String[] strArr) throws Exception {
        long j = b ^ 88442884885228L;
        long j2 = j ^ 4799601366400L;
        long j3 = j ^ 127084443248002L;
        ?? Vulcan_c = C0051Vulcan_ke.Vulcan_c();
        try {
            Vulcan_c = commandSender;
            ?? r0 = Vulcan_c;
            if (Vulcan_c != 0) {
                try {
                    Vulcan_c = Vulcan_c instanceof Player;
                    if (Vulcan_c == 0) {
                        ?? r4 = new Object[3];
                        Vulcan_fe.Vulcan_vV[2] = Long.valueOf(j2);
                        r4[1] = r4;
                        r4[0] = commandSender;
                        Vulcan_D(r4);
                        return true;
                    }
                    r0 = commandSender;
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) Vulcan_c);
                }
            }
            ?? HasPermission = (Player) r0;
            try {
                try {
                    try {
                        HasPermission = HasPermission.hasPermission(d);
                        if (Vulcan_c == 0) {
                            return HasPermission;
                        }
                        if (HasPermission != 0) {
                            ?? Vulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
                            ?? r3 = new Object[2];
                            HasPermission[1] = Long.valueOf(j3);
                            r3[0] = r3;
                            Vulcan_e.Vulcan_V(r3);
                            if (Vulcan_c != 0) {
                                return true;
                            }
                        }
                        ?? r42 = new Object[3];
                        Vulcan_fe.Vulcan_My[2] = Long.valueOf(j2);
                        r42[1] = r42;
                        r42[0] = commandSender;
                        Vulcan_D(r42);
                        return true;
                    } catch (RuntimeException unused2) {
                        throw a((RuntimeException) HasPermission);
                    }
                } catch (RuntimeException unused3) {
                    throw a((RuntimeException) HasPermission);
                }
            } catch (RuntimeException unused4) {
                throw a((RuntimeException) HasPermission);
            }
        } catch (RuntimeException unused5) {
            throw a((RuntimeException) Vulcan_c);
        }
    }
}
