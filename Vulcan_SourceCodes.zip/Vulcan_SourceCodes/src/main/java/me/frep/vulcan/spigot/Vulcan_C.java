package me.frep.vulcan.spigot;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.StringUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_C.class */
public final class Vulcan_C extends YamlConfiguration {
    private final Map Vulcan_f = new HashMap();
    private boolean Vulcan_X = false;
    private static String[] Vulcan_H;
    private static final long a = Vulcan_n.a(4247686028077061366L, 5187756483463186944L, MethodHandles.lookup().lookupClass()).a(266408354897821L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00d1: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void loadFromString(java.lang.String r10) {
        /*
            Method dump skipped, instruction units count: 343
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.loadFromString(java.lang.String):void");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0261: INVOKE (r-1 I:me.frep.vulcan.spigot.Vulcan_C), (r0 I:java.lang.Object[]) VIRTUAL call: me.frep.vulcan.spigot.Vulcan_C.Vulcan_z(java.lang.Object[]):void
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private boolean Vulcan_l(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 701
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_l(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0045: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static me.frep.vulcan.spigot.Vulcan_C Vulcan_s(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.io.File r1 = (java.io.File) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_C.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 34062951989757(0x1efae62741fd, double:1.68293343740787E-310)
            long r1 = r1 ^ r2
            r11 = r1
            java.io.FileInputStream r0 = new java.io.FileInputStream     // Catch: java.io.FileNotFoundException -> L52
            r1 = r0
            r2 = r10
            r1.<init>(r2)     // Catch: java.io.FileNotFoundException -> L52
            r13 = r0
            java.io.InputStreamReader r0 = new java.io.InputStreamReader     // Catch: java.io.FileNotFoundException -> L52
            r1 = r0
            r2 = r13
            java.nio.charset.Charset r3 = java.nio.charset.StandardCharsets.UTF_8     // Catch: java.io.FileNotFoundException -> L52
            r1.<init>(r2, r3)     // Catch: java.io.FileNotFoundException -> L52
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.io.FileNotFoundException -> L52
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.io.FileNotFoundException -> L52
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.io.FileNotFoundException -> L52
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.io.FileNotFoundException -> L52
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.io.FileNotFoundException -> L52
            r1[r2] = r3     // Catch: java.io.FileNotFoundException -> L52
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1;      // Catch: java.io.FileNotFoundException -> L52
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.io.FileNotFoundException -> L52
            java.lang.Long r1 = java.lang.Long.valueOf(r1)     // Catch: java.io.FileNotFoundException -> L52
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.io.FileNotFoundException -> L52
            r0[r1] = r2     // Catch: java.io.FileNotFoundException -> L52
            Vulcan_e(r-1)     // Catch: java.io.FileNotFoundException -> L52
            return r-1
        L52:
            r13 = move-exception
            java.util.logging.Logger r0 = org.bukkit.Bukkit.getLogger()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r2 = r1
            r2.<init>()
            java.lang.String[] r2 = me.frep.vulcan.spigot.Vulcan_C.b
            r14 = r2
            r2 = r14
            r3 = 1
            r2 = r2[r3]
            java.lang.StringBuilder r1 = r1.append(r2)
            r2 = r10
            java.lang.String r2 = r2.getName()
            java.lang.StringBuilder r1 = r1.append(r2)
            r2 = r14
            r3 = 4
            r2 = r2[r3]
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.warning(r1)
            me.frep.vulcan.spigot.Vulcan_C r0 = new me.frep.vulcan.spigot.Vulcan_C
            r1 = r0
            r1.<init>()
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            me.frep.vulcan.spigot.Vulcan_C r0 = r0.Vulcan_u(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_s(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_C");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003a: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static me.frep.vulcan.spigot.Vulcan_C Vulcan_D(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.io.InputStream r1 = (java.io.InputStream) r1
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_C.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 82428322841065(0x4af7d6e701e9, double:4.07250025600816E-310)
            long r1 = r1 ^ r2
            r11 = r1
            java.io.InputStreamReader r0 = new java.io.InputStreamReader
            r1 = r0
            r2 = r8
            java.nio.charset.Charset r3 = java.nio.charset.StandardCharsets.UTF_8
            r1.<init>(r2, r3)
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            Vulcan_e(r-1)
            return r-1
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_D(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_C");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    private static void Vulcan_f(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 300
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_f(java.lang.Object[]):void");
    }

    public static void Vulcan_R(String[] strArr) {
        Vulcan_H = strArr;
    }

    public static String[] Vulcan_Z() {
        return Vulcan_H;
    }

    static {
        int i;
        long j = a ^ 58713578552523L;
        Vulcan_R((String[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[5];
        int i3 = 0;
        String str = "_@¯0@\u0019é\u0006\b\u000bo\u008aDØè\u0097Â \b\u0002°Î(C\u001f1\u0089³«\t>>\u0007\u0084ÒU\u001f\f]\u000eÌ}J\fÕøè¬#â";
        int length = "_@¯0@\u0019é\u0006\b\u000bo\u008aDØè\u0097Â \b\u0002°Î(C\u001f1\u0089³«\t>>\u0007\u0084ÒU\u001f\f]\u000eÌ}J\fÕøè¬#â".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "_@¯0@\u0019é\u0006\u0010zd\u0089\u0086¼2\rÁ Ã\u0082#\u008d\u0083Ì\u0081";
                        length = "_@¯0@\u0019é\u0006\u0010zd\u0089\u0086¼2\rÁ Ã\u0082#\u008d\u0083Ì\u0081".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Throwable a(Throwable th) {
        return th;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_C] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r22v0, types: [me.frep.vulcan.spigot.Vulcan_C] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_C] */
    public void Vulcan_W(Object[] objArr) throws Throwable {
        File file = (File) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        ?? r1 = (InputStream) objArr[2];
        String[] strArr = (String[]) objArr[3];
        long j = a ^ jLongValue;
        long j2 = j ^ 82978694058519L;
        long j3 = j ^ 86805865340305L;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            Vulcan_Z = this;
            ?? Vulcan_l = Vulcan_Z;
            if (Vulcan_Z == 0) {
                try {
                    Vulcan_Z = Vulcan_Z.Vulcan_X;
                    if (Vulcan_Z != 0) {
                        return;
                    }
                    ?? r2 = new Object[2];
                    r1[1] = Long.valueOf(j2);
                    r2[0] = r2;
                    Vulcan_l = Vulcan_D((Object[]) r2);
                } catch (IOException unused) {
                    throw a((Throwable) Vulcan_Z);
                }
            }
            ?? r22 = Vulcan_l;
            try {
                try {
                    ConfigurationSection configurationSection = r22.getConfigurationSection("");
                    ?? r5 = new Object[4];
                    r5[3] = Arrays.asList(strArr);
                    r5[2] = configurationSection;
                    r5[1] = r22;
                    this[0] = Long.valueOf(j3);
                    Vulcan_l = r5.Vulcan_l(r5);
                    if (Vulcan_l != 0 && file != null) {
                        save(file);
                    }
                } catch (IOException unused2) {
                    throw a((Throwable) Vulcan_l);
                }
            } catch (IOException unused3) {
                throw a((Throwable) Vulcan_l);
            }
        } catch (IOException unused4) {
            throw a((Throwable) Vulcan_Z);
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[], java.lang.Throwable] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public void Vulcan_z(Object[] objArr) throws Throwable {
        String str = (String) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue();
        String str2 = (String) objArr[2];
        long j = a ^ jLongValue;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            try {
                if (Vulcan_Z == 0) {
                    if (str2 == null) {
                        this.Vulcan_f.remove(str);
                        if (Vulcan_Z == 0) {
                            return;
                        }
                    }
                    this.Vulcan_f.put(str, str2);
                }
            } catch (RuntimeException unused) {
                throw a((Throwable) Vulcan_Z);
            }
        } catch (RuntimeException unused2) {
            throw a((Throwable) Vulcan_Z);
        }
    }

    public String Vulcan_P(Object[] objArr) {
        return Vulcan_B(new Object[]{(String) objArr[0], null});
    }

    public String Vulcan_B(Object[] objArr) {
        return (String) this.Vulcan_f.getOrDefault((String) objArr[0], (String) objArr[1]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String] */
    public boolean Vulcan_R(Object[] objArr) throws Throwable {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        ?? Vulcan_P = a ^ jLongValue;
        try {
            Vulcan_P = Vulcan_P(new Object[]{str});
            return Vulcan_P != 0;
        } catch (RuntimeException unused) {
            throw a((Throwable) Vulcan_P);
        }
    }

    public boolean Vulcan_a(Object[] objArr) {
        return this.Vulcan_X;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v21, types: [int] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v42, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v54, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v20, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_C] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object[]] */
    public String saveToString() throws Throwable {
        long j = a ^ 111084053663593L;
        long j2 = j ^ 17871805516728L;
        long j3 = j ^ 22375069693044L;
        long j4 = j ^ 103222099059693L;
        String[] strArrVulcan_Z = Vulcan_Z();
        options().header((String) null);
        ArrayList<??> arrayList = new ArrayList(Arrays.asList(super.saveToString().split(StringUtils.LF)));
        int i = 0;
        String strVulcan_p = "";
        while (true) {
            if (i >= arrayList.size()) {
                break;
            }
            ?? r0 = (String) arrayList.get(i);
            ?? Vulcan_q = strArrVulcan_Z;
            if (Vulcan_q == 0) {
                try {
                    ?? r2 = new Object[2];
                    r0[1] = Long.valueOf(j2);
                    r2[0] = r2;
                    Vulcan_q = Vulcan_q(r2);
                    if (Vulcan_q != 0) {
                        ?? r4 = new Object[4];
                        r4[3] = strVulcan_p;
                        r4[2] = r0;
                        this[1] = Long.valueOf(j3);
                        r4[0] = r4;
                        strVulcan_p = Vulcan_p(r4);
                        ?? A = strArrVulcan_Z;
                        if (A == 0) {
                            try {
                                try {
                                    ?? r3 = new Object[2];
                                    r3[1] = strVulcan_p;
                                    this[0] = Long.valueOf(j4);
                                    A = r3.Vulcan_R(r3);
                                    if (A != 0) {
                                        arrayList.add(i, Vulcan_P(new Object[]{strVulcan_p}));
                                        i++;
                                    }
                                    i++;
                                } catch (RuntimeException unused) {
                                    A = a((Throwable) A);
                                    throw A;
                                }
                            } catch (RuntimeException unused2) {
                                throw a((Throwable) A);
                            }
                        }
                    } else {
                        i++;
                    }
                } catch (RuntimeException unused3) {
                    throw a((Throwable) Vulcan_q);
                }
            }
            if (strArrVulcan_Z != null) {
                AbstractCheck.Vulcan_D(new AbstractCheck[3]);
                break;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (?? r02 : arrayList) {
            try {
                sb.append(StringUtils.LF).append(r02);
                r02 = strArrVulcan_Z;
                if (r02 != 0) {
                    break;
                }
                if (strArrVulcan_Z != null) {
                    break;
                }
            } catch (RuntimeException unused4) {
                throw a((Throwable) r02);
            }
        }
        ?? A2 = sb;
        ?? r03 = A2;
        if (strArrVulcan_Z == null) {
            try {
                try {
                    A2 = A2.length();
                    if (A2 == 0) {
                        return "";
                    }
                    r03 = sb;
                } catch (RuntimeException unused5) {
                    A2 = a((Throwable) A2);
                    throw A2;
                }
            } catch (RuntimeException unused6) {
                throw a((Throwable) A2);
            }
        }
        return r03.substring(1);
    }

    private Vulcan_C Vulcan_u(Object[] objArr) {
        this.Vulcan_X = true;
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0069 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x0093 A[EDGE_INSN: B:85:0x0093->B:32:0x0093 BREAK  A[LOOP:0: B:17:0x005e->B:89:?], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v12, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.io.BufferedReader] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[], java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static me.frep.vulcan.spigot.Vulcan_C Vulcan_e(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_e(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_C");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.Throwable] */
    private static boolean Vulcan_q(Object[] objArr) throws Throwable {
        String str = (String) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_Z = Vulcan_Z();
        String strTrim = str.trim();
        try {
            try {
                try {
                    Vulcan_Z = strTrim.contains(b[0]);
                    if (Vulcan_Z != 0) {
                        return Vulcan_Z;
                    }
                    if (Vulcan_Z == 0) {
                        boolean zEndsWith = strTrim.endsWith(":");
                        if (Vulcan_Z != 0) {
                            return zEndsWith;
                        }
                        if (!zEndsWith) {
                            return false;
                        }
                    }
                    return true;
                } catch (RuntimeException unused) {
                    throw a((Throwable) Vulcan_Z);
                }
            } catch (RuntimeException unused2) {
                throw a((Throwable) Vulcan_Z);
            }
        } catch (RuntimeException unused3) {
            throw a((Throwable) Vulcan_Z);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:57:0x014b
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private static java.lang.String Vulcan_p(java.lang.Object[] r9) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 505
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_C.Vulcan_p(java.lang.Object[]):java.lang.String");
    }

    private static boolean Vulcan_N(Object[] objArr) {
        return ((String) objArr[0]).trim().startsWith(b[2]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    private static String Vulcan_G(Object[] objArr) throws Throwable {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_Z = Vulcan_Z();
        try {
            Vulcan_Z = str;
            if (Vulcan_Z != 0) {
                return Vulcan_Z;
            }
            try {
                Vulcan_Z = Vulcan_Z.contains(".");
                return Vulcan_Z != 0 ? str.substring(0, str.lastIndexOf(46)) : "";
            } catch (RuntimeException unused) {
                throw a((Throwable) Vulcan_Z);
            }
        } catch (RuntimeException unused2) {
            throw a((Throwable) Vulcan_Z);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    private static List Vulcan_d(Object[] objArr) throws Throwable {
        long jLongValue = ((Long) objArr[0]).longValue();
        ConfigurationSection configurationSection = (ConfigurationSection) objArr[1];
        long j = a ^ jLongValue;
        String[] strArrVulcan_Z = Vulcan_Z();
        ArrayList arrayList = new ArrayList();
        loop0: for (String str : configurationSection.getKeys(false)) {
            do {
                if (j > 0) {
                    ?? Add = arrayList;
                    if (strArrVulcan_Z != null) {
                        return Add;
                    }
                    try {
                        Add = Add.add(new Vulcan_f(str, configurationSection.get(str)));
                    } catch (RuntimeException unused) {
                        throw a((Throwable) Add);
                    }
                }
                if (strArrVulcan_Z != null) {
                }
            } while (j < 0);
        }
        return arrayList;
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    private static void m576Vulcan_D(Object[] objArr) {
        ConfigurationSection configurationSection = (ConfigurationSection) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String[] strArrVulcan_Z = Vulcan_Z();
        Iterator it = configurationSection.getKeys(false).iterator();
        while (it.hasNext()) {
            configurationSection.set((String) it.next(), (Object) null);
            if (strArrVulcan_Z != null) {
                return;
            }
        }
    }
}
