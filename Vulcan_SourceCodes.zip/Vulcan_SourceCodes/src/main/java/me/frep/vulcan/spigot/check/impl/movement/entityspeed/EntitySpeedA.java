package me.frep.vulcan.spigot.check.impl.movement.entityspeed;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/movement/entityspeed/EntitySpeedA.class */
@CheckInfo(name = "Entity Speed", type = 'A', complexType = "Limit", description = "Riding an entity too quickly.")
public class EntitySpeedA extends AbstractCheck {
    private int Vulcan_O;
    private static boolean Vulcan_M;
    private static final long b = Vulcan_n.a(-7684779991381989529L, -6289910285632775672L, MethodHandles.lookup().lookupClass()).a(200287324126460L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0266: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 9741
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.movement.entityspeed.EntitySpeedA.Vulcan_T(java.lang.Object[]):void");
    }

    public static void Vulcan_m(boolean z) {
        Vulcan_M = z;
    }

    public static boolean Vulcan_V() {
        return Vulcan_M;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_m() {
        return !Vulcan_V();
    }

    static {
        int i;
        long j = b ^ 118349208588418L;
        Vulcan_m(true);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[17];
        int i3 = 0;
        String str = "·\u0090\u00128íî\u0095?f*ñ\u0097bMìªçÈã@P\u0083\u009dÄ\u0018Èa:\\üÅ\u001ebó¦\u000fK\u0085¬%\u0081ÞsI8q¿èì\u0018X+}(/;å¡\u001c\u0005D¬àý\u000eÌÝ <\u009dæÛ\t<\u0010m\b\u009fh\u001b\t²5e\u0081«ûZ'þÙ\b;¶ÔÂô-B\u007f\u0010øúìö\u00801\u0096 yx\u009f\u0097yä8\u0018\u0010ÌÜuÖó8à\u009f\u0094°ß\u009d\u0087\u0015_;\u0018,\u001e¶\u0010àf\u0082vYþÙcîó\u009d§£\u0000y\u000f\u001eý\u0005ï\u00104ÇkäÙk\u001aßU\u000b/ìºñ\u0014Í\u0010Ð\u0005=\t!\u001cÍ\"yåYÈo#\u008bé\u0010\u008eþ\u008f\u001bþ©\u001fùLòlÜ\u0016éHx\u0010¬\u00ad/HëI.\u0085Düô:\u0084£\u0005t\u0010m\b\u009fh\u001b\t²5e\u0081«ûZ'þÙ\bm~\u009d¶U¦\u008cl\bm~\u009d¶U¦\u008cl";
        int length = "·\u0090\u00128íî\u0095?f*ñ\u0097bMìªçÈã@P\u0083\u009dÄ\u0018Èa:\\üÅ\u001ebó¦\u000fK\u0085¬%\u0081ÞsI8q¿èì\u0018X+}(/;å¡\u001c\u0005D¬àý\u000eÌÝ <\u009dæÛ\t<\u0010m\b\u009fh\u001b\t²5e\u0081«ûZ'þÙ\b;¶ÔÂô-B\u007f\u0010øúìö\u00801\u0096 yx\u009f\u0097yä8\u0018\u0010ÌÜuÖó8à\u009f\u0094°ß\u009d\u0087\u0015_;\u0018,\u001e¶\u0010àf\u0082vYþÙcîó\u009d§£\u0000y\u000f\u001eý\u0005ï\u00104ÇkäÙk\u001aßU\u000b/ìºñ\u0014Í\u0010Ð\u0005=\t!\u001cÍ\"yåYÈo#\u008bé\u0010\u008eþ\u008f\u001bþ©\u001fùLòlÜ\u0016éHx\u0010¬\u00ad/HëI.\u0085Düô:\u0084£\u0005t\u0010m\b\u009fh\u001b\t²5e\u0081«ûZ'þÙ\bm~\u009d¶U¦\u008cl\bm~\u009d¶U¦\u008cl".length();
        char cCharAt = 24;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u008e\n\u0097\u0091®+\u0088-P\u001egñïîWøReÕpîv\u000be\u0010Ôdî\u008f½\u0012\u0016@T*~Nßë\u0088Í";
                        length = "\u008e\n\u0097\u0091®+\u0088-P\u001egñïîWøReÕpîv\u000be\u0010Ôdî\u008f½\u0012\u0016@T*~Nßë\u0088Í".length();
                        cCharAt = 24;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    public EntitySpeedA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        long j = b ^ 116644278016617L;
        ?? Vulcan_m = Vulcan_m();
        try {
            this.Vulcan_O = 10000;
            if (Vulcan_m != 0) {
                Vulcan_m = new AbstractCheck[3];
                AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_m);
            }
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_m);
        }
    }

    private void lambda$handle$0() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$1() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$2() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$3() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$4() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$5() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$6() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$7() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$8() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$9() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    private void lambda$handle$10() {
        this.Vulcan_b.Vulcan_e(new Object[0]).leaveVehicle();
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
