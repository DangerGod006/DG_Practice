package me.frep.vulcan.api.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/api/event/VulcanPunishmentLogCreateEvent.class */
public class VulcanPunishmentLogCreateEvent extends Event implements Cancellable {
    private boolean cancelled;
    private final Player player;
    private static final HandlerList handlers = new HandlerList();

    public Player getPlayer() {
        return this.player;
    }

    public VulcanPunishmentLogCreateEvent(Player player) {
        super(true);
        this.player = player;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean z) {
        this.cancelled = z;
    }
}
