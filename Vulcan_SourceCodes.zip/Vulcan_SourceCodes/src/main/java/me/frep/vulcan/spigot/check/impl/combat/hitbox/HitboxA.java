package me.frep.vulcan.spigot.check.impl.combat.hitbox;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0039Vulcan_Oo;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Location;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/hitbox/HitboxA.class */
@CheckInfo(name = "Hitbox", type = 'A', complexType = "History", description = "Attacked while not looking at target.")
public class HitboxA extends AbstractCheck {
    private boolean Vulcan_x;
    private static final long b = Vulcan_n.a(6988560621569112577L, 6389869471722311436L, MethodHandles.lookup().lookupClass()).a(159755749240742L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x025b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 1092
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.combat.hitbox.HitboxA.Vulcan_T(java.lang.Object[]):void");
    }

    static {
        int i;
        long j = b ^ 127557758476851L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "IÞd\u0007£¶Ô$\u0010.ß\u007fRI*j\u0002Ê|\u0091%h\u008bµ%";
        int length = "IÞd\u0007£¶Ô$\u0010.ß\u007fRI*j\u0002Ê|\u0091%h\u008bµ%".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "zÏ\u000f\u001d\u0096\u0015\u001a#\bµYE\u009dÁO]9";
                        length = "zÏ\u000f\u001d\u0096\u0015\u001a#\bµYE\u009dÁO]9".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public HitboxA(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static boolean lambda$handle$0(int i, int i2, C0039Vulcan_Oo c0039Vulcan_Oo) {
        long j = b ^ 79422182294688L;
        ?? Vulcan_f = HitboxB.Vulcan_f();
        try {
            try {
                Vulcan_f = Math.abs((i - ((Integer) c0039Vulcan_Oo.Vulcan_m(new Object[0])).intValue()) - i2);
                return Vulcan_f != 0 ? Vulcan_f < 3 : Vulcan_f;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_f);
            }
        } catch (RuntimeException unused2) {
            Vulcan_f = a((RuntimeException) Vulcan_f);
            throw Vulcan_f;
        }
    }

    private double lambda$handle$1(Vector vector, C0039Vulcan_Oo c0039Vulcan_Oo) {
        return ((Location) c0039Vulcan_Oo.Vulcan_C(new Object[0])).toVector().setY(0.0d).clone().subtract(vector).angle(Vulcan_t(new Object[]{Float.valueOf(this.Vulcan_b.Vulcan_z(new Object[0]).Vulcan_F(new Object[0])), Float.valueOf(this.Vulcan_b.Vulcan_z(new Object[0]).Vulcan_M(new Object[0]))}).setY(0.0d));
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }

    private Vector Vulcan_t(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        Vector vector = new Vector();
        double d2 = fFloatValue;
        double d3 = fFloatValue2;
        vector.setY(-Math.sin(Math.toRadians(d3)));
        double dCos = Math.cos(Math.toRadians(d3));
        vector.setX((-dCos) * Math.sin(Math.toRadians(d2)));
        vector.setZ(dCos * Math.cos(Math.toRadians(d2)));
        return vector;
    }
}
