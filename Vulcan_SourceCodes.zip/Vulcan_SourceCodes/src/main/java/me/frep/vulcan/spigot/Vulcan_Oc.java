package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityRelativeMove;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityRelativeMoveAndRotation;
import java.lang.invoke.MethodHandles;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oc.class */
public class Vulcan_Oc {
    private final C0042Vulcan_Oz Vulcan_I;
    private int Vulcan_G;
    private int Vulcan_J;
    private int Vulcan_x;
    private Entity Vulcan_h;
    private Player Vulcan_A;
    private Player Vulcan_r;
    private double Vulcan_f;
    private double Vulcan_p;
    private static String Vulcan_s;
    private static final long a = Vulcan_n.a(1946871771774186580L, 683927445966865112L, MethodHandles.lookup().lookupClass()).a(72588407177610L);
    private int Vulcan__ = 100;
    private final C0036Vulcan_Oj Vulcan_w = new C0036Vulcan_Oj(20);

    public static void Vulcan_g(String str) {
        Vulcan_s = str;
    }

    public static String Vulcan_A() {
        return Vulcan_s;
    }

    static {
        if (Vulcan_A() != null) {
            Vulcan_g("kDQbX");
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public C0042Vulcan_Oz m608Vulcan_C(Object[] objArr) {
        return this.Vulcan_I;
    }

    public int Vulcan_D(Object[] objArr) {
        return this.Vulcan__;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public int m609Vulcan_C(Object[] objArr) {
        return this.Vulcan_G;
    }

    public int Vulcan_h(Object[] objArr) {
        return this.Vulcan_J;
    }

    public int Vulcan_s(Object[] objArr) {
        return this.Vulcan_x;
    }

    public Entity Vulcan_t(Object[] objArr) {
        return this.Vulcan_h;
    }

    public Player Vulcan_M(Object[] objArr) {
        return this.Vulcan_A;
    }

    public Player Vulcan_K(Object[] objArr) {
        return this.Vulcan_r;
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public double m610Vulcan_C(Object[] objArr) {
        return this.Vulcan_f;
    }

    public double Vulcan_S(Object[] objArr) {
        return this.Vulcan_p;
    }

    public C0036Vulcan_Oj Vulcan_w(Object[] objArr) {
        return this.Vulcan_w;
    }

    public Vulcan_Oc(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_I = c0042Vulcan_Oz;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0133  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0170  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0195  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x010f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:99:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v11, types: [int] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v18, types: [int] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity$InteractAction] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [org.bukkit.entity.Entity] */
    /* JADX WARN: Type inference failed for: r0v34 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v41, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v52, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v55, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v56, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v57, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v62, types: [org.bukkit.entity.Entity] */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r0v74 */
    /* JADX WARN: Type inference failed for: r0v75 */
    /* JADX WARN: Type inference failed for: r0v76 */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v78 */
    /* JADX WARN: Type inference failed for: r0v79 */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r12v0, types: [org.bukkit.entity.Entity] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_Z(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 411
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oc.Vulcan_Z(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v16, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v42 */
    /* JADX WARN: Type inference failed for: r1v43 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public void Vulcan_f(Object[] objArr) {
        WrapperPlayServerEntityRelativeMove wrapperPlayServerEntityRelativeMove = (WrapperPlayServerEntityRelativeMove) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            try {
                Vulcan_T = this.Vulcan_A;
                ?? r0 = Vulcan_T;
                if (Vulcan_T != 0) {
                    if (Vulcan_T == 0) {
                        return;
                    } else {
                        r0 = this.Vulcan_A;
                    }
                }
                if (r0.getEntityId() == wrapperPlayServerEntityRelativeMove.getEntityId()) {
                    Player playerVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{this.Vulcan_A});
                    Player player = playerVulcan_L;
                    ?? r1 = Vulcan_T;
                    Player playerVulcan_e = player;
                    ?? r02 = player;
                    ?? r12 = r1;
                    if (jLongValue >= 0) {
                        if (r1 != 0) {
                            if (player == null) {
                                return;
                            } else {
                                playerVulcan_e = playerVulcan_L;
                            }
                        }
                        try {
                            r02 = playerVulcan_e;
                            r12 = new Object[0];
                        } catch (RuntimeException unused) {
                            throw a(playerVulcan_e);
                        }
                    }
                    playerVulcan_e = r02.Vulcan_e(r12);
                    if (playerVulcan_e == null) {
                        return;
                    }
                    this.Vulcan_w.add(new C0039Vulcan_Oo(new Location(playerVulcan_L.Vulcan_e(new Object[0]).getWorld(), playerVulcan_L.m639Vulcan_M(new Object[0]).m892Vulcan_q(new Object[0]) - wrapperPlayServerEntityRelativeMove.getDeltaX(), playerVulcan_L.m639Vulcan_M(new Object[0]).m893Vulcan__(new Object[0]) - wrapperPlayServerEntityRelativeMove.getDeltaY(), playerVulcan_L.m639Vulcan_M(new Object[0]).m894Vulcan_t(new Object[0]) - wrapperPlayServerEntityRelativeMove.getDeltaZ()), Integer.valueOf(Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]))));
                }
            } catch (RuntimeException unused2) {
                throw a(Vulcan_T);
            }
        } catch (RuntimeException unused3) {
            throw a(Vulcan_T);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v16, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v42 */
    /* JADX WARN: Type inference failed for: r1v43 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public void Vulcan__(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        WrapperPlayServerEntityRelativeMoveAndRotation wrapperPlayServerEntityRelativeMoveAndRotation = (WrapperPlayServerEntityRelativeMoveAndRotation) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            try {
                Vulcan_T = this.Vulcan_A;
                ?? r0 = Vulcan_T;
                if (Vulcan_T != 0) {
                    if (Vulcan_T == 0) {
                        return;
                    } else {
                        r0 = this.Vulcan_A;
                    }
                }
                if (r0.getEntityId() == wrapperPlayServerEntityRelativeMoveAndRotation.getEntityId()) {
                    Player playerVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{this.Vulcan_A});
                    Player player = playerVulcan_L;
                    ?? r1 = Vulcan_T;
                    Player playerVulcan_e = player;
                    ?? r02 = player;
                    ?? r12 = r1;
                    if (j > 0) {
                        if (r1 != 0) {
                            if (player == null) {
                                return;
                            } else {
                                playerVulcan_e = playerVulcan_L;
                            }
                        }
                        try {
                            r02 = playerVulcan_e;
                            r12 = new Object[0];
                        } catch (RuntimeException unused) {
                            throw a(playerVulcan_e);
                        }
                    }
                    playerVulcan_e = r02.Vulcan_e(r12);
                    if (playerVulcan_e == null) {
                        return;
                    }
                    this.Vulcan_w.add(new C0039Vulcan_Oo(new Location(playerVulcan_L.Vulcan_e(new Object[0]).getWorld(), playerVulcan_L.m639Vulcan_M(new Object[0]).m892Vulcan_q(new Object[0]) - wrapperPlayServerEntityRelativeMoveAndRotation.getDeltaX(), playerVulcan_L.m639Vulcan_M(new Object[0]).m893Vulcan__(new Object[0]) - wrapperPlayServerEntityRelativeMoveAndRotation.getDeltaY(), playerVulcan_L.m639Vulcan_M(new Object[0]).m894Vulcan_t(new Object[0]) - wrapperPlayServerEntityRelativeMoveAndRotation.getDeltaZ()), Integer.valueOf(Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]))));
                }
            } catch (RuntimeException unused2) {
                throw a(Vulcan_T);
            }
        } catch (RuntimeException unused3) {
            throw a(Vulcan_T);
        }
    }

    public void Vulcan_C(Object[] objArr) {
        this.Vulcan_w.clear();
    }

    public void Vulcan_k(Object[] objArr) {
        this.Vulcan_G = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public void Vulcan_b(Object[] objArr) {
        this.Vulcan_J = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public int Vulcan_i(Object[] objArr) {
        return Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - this.Vulcan_G;
    }

    public int Vulcan_P(Object[] objArr) {
        return Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]) - this.Vulcan_J;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.Vulcan_Oc] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException, java.lang.Throwable] */
    public void Vulcan_O(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        String[] strArrVulcan_T = Vulcan_ka.Vulcan_T();
        this.Vulcan__++;
        ?? A = this;
        ?? r0 = A;
        if (strArrVulcan_T != null) {
            try {
                try {
                    A = A.Vulcan_w.isEmpty();
                    if (A != 0) {
                        return;
                    } else {
                        r0 = this;
                    }
                } catch (RuntimeException unused) {
                    A = a(A);
                    throw A;
                }
            } catch (RuntimeException unused2) {
                throw a(A);
            }
        }
        if (r0.Vulcan_A != null) {
            int iVulcan_P = Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
            int iM579Vulcan__ = Vulcan_J.m579Vulcan__(new Object[]{this.Vulcan_I});
            Vector vector = new Vector(this.Vulcan_I.m639Vulcan_M(new Object[0]).m892Vulcan_q(new Object[0]), 0.0d, this.Vulcan_I.m639Vulcan_M(new Object[0]).m894Vulcan_t(new Object[0]));
            this.Vulcan_p = this.Vulcan_I.m636Vulcan_T(new Object[0]).Vulcan_w(new Object[0]).stream().filter((v2) -> {
                return lambda$handleFlying$0(r2, r3, v2);
            }).mapToDouble((v1) -> {
                return lambda$handleFlying$1(r2, v1);
            }).min().orElse(-1.0d);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    private static boolean lambda$handleFlying$0(int i, int i2, C0039Vulcan_Oo c0039Vulcan_Oo) {
        long j = a ^ 20922604093807L;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        try {
            try {
                Vulcan_T = Math.abs((i - ((Integer) c0039Vulcan_Oo.Vulcan_m(new Object[0])).intValue()) - i2);
                return Vulcan_T != 0 ? Vulcan_T < 3 : Vulcan_T;
            } catch (RuntimeException unused) {
                throw a(Vulcan_T);
            }
        } catch (RuntimeException unused2) {
            Vulcan_T = a(Vulcan_T);
            throw Vulcan_T;
        }
    }

    private static double lambda$handleFlying$1(Vector vector, C0039Vulcan_Oo c0039Vulcan_Oo) {
        return vector.distance(((Location) c0039Vulcan_Oo.Vulcan_C(new Object[0])).toVector().setY(0)) - 0.52d;
    }
}
