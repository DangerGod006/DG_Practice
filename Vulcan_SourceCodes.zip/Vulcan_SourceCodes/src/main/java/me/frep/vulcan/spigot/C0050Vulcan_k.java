package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.entity.Player;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_k.class */
public class C0050Vulcan_k {
    private final C0042Vulcan_Oz Vulcan_g;
    private int Vulcan_l;
    private long Vulcan_I;
    private long Vulcan_v;
    private boolean Vulcan_p;
    private double Vulcan_G;
    private boolean Vulcan_T;
    private int Vulcan_J;
    private boolean Vulcan_f;
    private static AbstractCheck[] Vulcan_x;
    private static final long a = Vulcan_n.a(-2620624899560272907L, -8349366504743858056L, MethodHandles.lookup().lookupClass()).a(7757318154690L);
    private static final String[] b;
    private final Map Vulcan_O = new HashMap();
    private final Map Vulcan_r = new HashMap();
    private long Vulcan_k = System.currentTimeMillis();
    private long Vulcan_B = System.currentTimeMillis();
    private long Vulcan_V = System.currentTimeMillis();

    public static void Vulcan_v(AbstractCheck[] abstractCheckArr) {
        Vulcan_x = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_G() {
        return Vulcan_x;
    }

    static {
        int i;
        long j = a ^ 43633221354814L;
        Vulcan_v(new AbstractCheck[2]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[8];
        int i3 = 0;
        String str = "õ=¨AÎ0ùá(ç\u0093¯i3ñÜÍÊÄF\u001a\u0087y§º'²\u0017(%)ö\u009aQ\u009fJüø\u0085Âg\u0013¿\u0013Ø·ÛÄá\u0010¬\u009fåõ\u0010ç\u0095\u0019üâ\u0081\u0019\u0013Öâf\u0010¬\u009fåõ\u0010ç\u0095\u0019üâ\u0081\u0019\u0013Öâf\bwq\u0085)\u0086ÐXy\bwq\u0085)\u0086ÐXy";
        int length = "õ=¨AÎ0ùá(ç\u0093¯i3ñÜÍÊÄF\u001a\u0087y§º'²\u0017(%)ö\u009aQ\u009fJüø\u0085Âg\u0013¿\u0013Ø·ÛÄá\u0010¬\u009fåõ\u0010ç\u0095\u0019üâ\u0081\u0019\u0013Öâf\u0010¬\u009fåõ\u0010ç\u0095\u0019üâ\u0081\u0019\u0013Öâf\bwq\u0085)\u0086ÐXy\bwq\u0085)\u0086ÐXy".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "õ=¨AÎ0ùá(ç\u0093¯i3ñÜÍÊÄF\u001a\u0087y§º'²\u0017(%)ö\u009aó«,< ÛZó|@àÈñõZR";
                        length = "õ=¨AÎ0ùá(ç\u0093¯i3ñÜÍÊÄF\u001a\u0087y§º'²\u0017(%)ö\u009aó«,< ÛZó|@àÈñõZR".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public void Vulcan_y(Object[] objArr) {
        this.Vulcan_l = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_f(Object[] objArr) {
        this.Vulcan_I = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_H(Object[] objArr) {
        this.Vulcan_v = ((Long) objArr[0]).longValue();
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public void m841Vulcan_W(Object[] objArr) {
        this.Vulcan_k = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_m(Object[] objArr) {
        this.Vulcan_B = ((Long) objArr[0]).longValue();
    }

    /* JADX INFO: renamed from: Vulcan_a, reason: collision with other method in class */
    public void m842Vulcan_a(Object[] objArr) {
        this.Vulcan_V = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_v(Object[] objArr) {
        this.Vulcan_p = ((Boolean) objArr[0]).booleanValue();
    }

    /* JADX INFO: renamed from: Vulcan_D, reason: collision with other method in class */
    public void m843Vulcan_D(Object[] objArr) {
        this.Vulcan_G = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    public void m844Vulcan_z(Object[] objArr) {
        this.Vulcan_T = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_E(Object[] objArr) {
        this.Vulcan_J = ((Integer) objArr[0]).intValue();
    }

    public void Vulcan_X(Object[] objArr) {
        this.Vulcan_f = ((Boolean) objArr[0]).booleanValue();
    }

    public C0042Vulcan_Oz Vulcan_W(Object[] objArr) {
        return this.Vulcan_g;
    }

    public int Vulcan_F(Object[] objArr) {
        return this.Vulcan_l;
    }

    public Map Vulcan_z(Object[] objArr) {
        return this.Vulcan_O;
    }

    public Map Vulcan_I(Object[] objArr) {
        return this.Vulcan_r;
    }

    /* JADX INFO: renamed from: Vulcan_W, reason: collision with other method in class */
    public long m839Vulcan_W(Object[] objArr) {
        return this.Vulcan_I;
    }

    public long Vulcan_D(Object[] objArr) {
        return this.Vulcan_v;
    }

    public long Vulcan_B(Object[] objArr) {
        return this.Vulcan_k;
    }

    public long Vulcan_k(Object[] objArr) {
        return this.Vulcan_B;
    }

    public long Vulcan_b(Object[] objArr) {
        return this.Vulcan_V;
    }

    public boolean Vulcan_O(Object[] objArr) {
        return this.Vulcan_p;
    }

    /* JADX INFO: renamed from: Vulcan_O, reason: collision with other method in class */
    public double m840Vulcan_O(Object[] objArr) {
        return this.Vulcan_G;
    }

    public C0050Vulcan_k(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_g = c0042Vulcan_Oz;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, me.frep.vulcan.spigot.Vulcan_k] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v23, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [me.frep.vulcan.spigot.Vulcan_k] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v16, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v40 */
    /* JADX WARN: Type inference failed for: r1v41 */
    /* JADX WARN: Type inference failed for: r1v42 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v16, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_k] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_k] */
    /* JADX WARN: Type inference failed for: r2v27 */
    /* JADX WARN: Type inference failed for: r2v28 */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object[]] */
    public void Vulcan_C(Object[] objArr) {
        int iVulcan_x;
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        long j = jLongValue ^ 54095863952896L;
        long j2 = jLongValue ^ 18795074941584L;
        ?? Vulcan_T = Vulcan_ka.Vulcan_T();
        long jCurrentTimeMillis = System.currentTimeMillis();
        try {
            this.Vulcan_v = jCurrentTimeMillis - this.Vulcan_I;
            Vulcan_T = this;
            int i = (this.Vulcan_v > 5L ? 1 : (this.Vulcan_v == 5L ? 0 : -1));
            ?? r1 = i;
            if (Vulcan_T != 0) {
                r1 = i <= 0 ? 1 : 0;
            }
            try {
                try {
                    Vulcan_T.Vulcan_p = r1;
                    C0050Vulcan_k c0050Vulcan_k = this;
                    ?? A = c0050Vulcan_k;
                    if (jLongValue > 0) {
                        A = c0050Vulcan_k;
                        if (Vulcan_T != 0) {
                            Vulcan_T = c0050Vulcan_k.Vulcan_p;
                            if (Vulcan_T != 0) {
                                this.Vulcan_V = System.currentTimeMillis();
                            }
                            A = this;
                        }
                    }
                    try {
                        try {
                            Player playerVulcan_e = this.Vulcan_g.Vulcan_e(new Object[0]);
                            ?? r2 = Vulcan_T;
                            ?? r22 = r2;
                            if (jLongValue <= 0) {
                                ?? r3 = r22;
                                r3[0] = playerVulcan_e;
                                iVulcan_x = C0044Vulcan_fb.Vulcan_x((Object[]) r3);
                            } else {
                                if (r2 != 0) {
                                    if (playerVulcan_e == null) {
                                        iVulcan_x = 0;
                                    } else {
                                        playerVulcan_e = this.Vulcan_g.Vulcan_e(new Object[0]);
                                    }
                                }
                                r22 = new Object[1];
                                ?? r32 = r22;
                                r32[0] = playerVulcan_e;
                                iVulcan_x = C0044Vulcan_fb.Vulcan_x((Object[]) r32);
                            }
                            A.Vulcan_l = iVulcan_x;
                            this.Vulcan_I = jCurrentTimeMillis;
                            ?? r23 = new Object[1];
                            this[0] = Long.valueOf(j2);
                            r23.Vulcan_j(r23);
                            ?? r24 = new Object[1];
                            this[0] = Long.valueOf(j);
                            r24.Vulcan_h(r24);
                        } catch (RuntimeException unused) {
                            throw a((RuntimeException) A);
                        }
                    } catch (RuntimeException unused2) {
                        A = a((RuntimeException) A);
                        throw A;
                    }
                } catch (RuntimeException unused3) {
                    throw a((RuntimeException) Vulcan_T);
                }
            } catch (RuntimeException unused4) {
                throw a((RuntimeException) Vulcan_T);
            }
        } catch (RuntimeException unused5) {
            throw a((RuntimeException) Vulcan_T);
        }
    }

    public void Vulcan_T(Object[] objArr) {
        this.Vulcan_B = System.currentTimeMillis();
    }

    public boolean Vulcan_a(Object[] objArr) {
        return this.Vulcan_T;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:45:0x00d3
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private void Vulcan_j(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 504
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_j(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$confirmKeepAliveConnection$0() {
        long j = (a ^ 91785272577513L) ^ 78715296964494L;
        Player playerVulcan_e = this.Vulcan_g.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_tZ[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }

    public int Vulcan_U(Object[] objArr) {
        return this.Vulcan_J;
    }

    public boolean Vulcan_Y(Object[] objArr) {
        return this.Vulcan_f;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0170 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:115:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x01d6  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x01e1  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01f5  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [int] */
    /* JADX WARN: Type inference failed for: r0v26, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v37, types: [me.frep.vulcan.spigot.Vulcan_OB] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v49, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v53, types: [int] */
    /* JADX WARN: Type inference failed for: r0v55 */
    /* JADX WARN: Type inference failed for: r0v56, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v59, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v65, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v78 */
    /* JADX WARN: Type inference failed for: r0v79 */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v81 */
    /* JADX WARN: Type inference failed for: r0v82 */
    /* JADX WARN: Type inference failed for: r0v83 */
    /* JADX WARN: Type inference failed for: r0v84 */
    /* JADX WARN: Type inference failed for: r0v85 */
    /* JADX WARN: Type inference failed for: r0v86 */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v32 */
    /* JADX WARN: Type inference failed for: r1v50 */
    /* JADX WARN: Type inference failed for: r1v60 */
    /* JADX WARN: Type inference failed for: r1v61 */
    /* JADX WARN: Type inference failed for: r1v66 */
    /* JADX WARN: Type inference failed for: r1v67 */
    /* JADX WARN: Type inference failed for: r2v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v34, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void Vulcan_h(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 512
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_h(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.lang.String] */
    private void lambda$handleMaxPingKick$1() {
        long j = (a ^ 37929236628153L) ^ 60001488736478L;
        Player playerVulcan_e = this.Vulcan_g.Vulcan_e(new Object[0]);
        Object[] objArr = new Object[2];
        Vulcan_fe.Vulcan_sF[1] = Long.valueOf(j);
        objArr[0] = objArr;
        playerVulcan_e.kickPlayer(Vulcan_ym.Vulcan_X(objArr));
    }
}
