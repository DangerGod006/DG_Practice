package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import me.frep.vulcan.spigot.check.AbstractCheck;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kw.class */
public class Vulcan_kw {
    private final C0042Vulcan_Oz Vulcan_F;
    private long Vulcan_T;
    private double Vulcan_c;
    private double Vulcan_x;
    private static AbstractCheck[] Vulcan_G;
    private static final long a = Vulcan_n.a(-272423316147421069L, 2705578875469760201L, MethodHandles.lookup().lookupClass()).a(88235203732737L);
    private long Vulcan_M = -1;
    private long Vulcan_J = System.currentTimeMillis();
    private long Vulcan_j = System.currentTimeMillis();
    private long Vulcan_a = System.currentTimeMillis();
    private final C0036Vulcan_Oj Vulcan__ = new C0036Vulcan_Oj(20);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ce: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public void Vulcan_P(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 235
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kw.Vulcan_P(java.lang.Object[]):void");
    }

    public static void Vulcan_E(AbstractCheck[] abstractCheckArr) {
        Vulcan_G = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_u() {
        return Vulcan_G;
    }

    static {
        if (Vulcan_u() != null) {
            Vulcan_E(new AbstractCheck[3]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public void Vulcan_u(Object[] objArr) {
        this.Vulcan_M = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_T = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_l(Object[] objArr) {
        this.Vulcan_J = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_V(Object[] objArr) {
        this.Vulcan_j = ((Long) objArr[0]).longValue();
    }

    /* JADX INFO: renamed from: Vulcan_m, reason: collision with other method in class */
    public void m1067Vulcan_m(Object[] objArr) {
        this.Vulcan_a = ((Long) objArr[0]).longValue();
    }

    public void Vulcan_Y(Object[] objArr) {
        this.Vulcan_c = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_q, reason: collision with other method in class */
    public void m1068Vulcan_q(Object[] objArr) {
        this.Vulcan_x = ((Double) objArr[0]).doubleValue();
    }

    public C0042Vulcan_Oz Vulcan_m(Object[] objArr) {
        return this.Vulcan_F;
    }

    public long Vulcan_q(Object[] objArr) {
        return this.Vulcan_M;
    }

    public long Vulcan_I(Object[] objArr) {
        return this.Vulcan_T;
    }

    public long Vulcan_E(Object[] objArr) {
        return this.Vulcan_J;
    }

    public long Vulcan_v(Object[] objArr) {
        return this.Vulcan_j;
    }

    public long Vulcan__(Object[] objArr) {
        return this.Vulcan_a;
    }

    public C0036Vulcan_Oj Vulcan_B(Object[] objArr) {
        return this.Vulcan__;
    }

    public double Vulcan_x(Object[] objArr) {
        return this.Vulcan_c;
    }

    public double Vulcan_h(Object[] objArr) {
        return this.Vulcan_x;
    }

    public Vulcan_kw(C0042Vulcan_Oz c0042Vulcan_Oz) {
        this.Vulcan_F = c0042Vulcan_Oz;
    }
}
