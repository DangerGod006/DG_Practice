package me.frep.vulcan.spigot;

import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_v.class */
public class Vulcan_v {
    private static int[] Vulcan__;
    private static final long a = Vulcan_n.a(2165329561634773785L, 7051870269110124455L, MethodHandles.lookup().lookupClass()).a(243442865241163L);
    private static final String[] b;

    public static void Vulcan_R(int[] iArr) {
        Vulcan__ = iArr;
    }

    public static int[] Vulcan_V() {
        return Vulcan__;
    }

    static {
        int i;
        long j = a ^ 81592572491219L;
        Vulcan_R(null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[8];
        int i3 = 0;
        String str = "42{üßm\u00ad/\u008ce\u001bÇë3\u0016²*«\\)¯¨\u0088¢\u0080¤ÂÃ\u0090;ñò(¦ÁÄÑLëþá6+E#\u0018h\u0099.\u0083N\u000bÕ\u0083y\u008a\u008eñ´\u0082{¨®\t\u0017Â\u0082ORÛ\u0015\u0099m\b\u0011·D\u0081ï\u0012\u000fó\b¥¬3|ã\u000bf;(¦ÁÄÑLëþá6+E#\u0018h\u0099.\u0083N\u000bÕ\u0083y\u008a\u008eñ´\u0082{¨®\t\u0017Â\u0082ORÛ\u0015\u0099m(õjï*\n§\u001b 3U5·Á\u000b\"\u0091ÎpÑ®A\u009e·)éð\u001a\u001e\"ðë^>¯«\u009e[ð\u0012ë";
        int length = "42{üßm\u00ad/\u008ce\u001bÇë3\u0016²*«\\)¯¨\u0088¢\u0080¤ÂÃ\u0090;ñò(¦ÁÄÑLëþá6+E#\u0018h\u0099.\u0083N\u000bÕ\u0083y\u008a\u008eñ´\u0082{¨®\t\u0017Â\u0082ORÛ\u0015\u0099m\b\u0011·D\u0081ï\u0012\u000fó\b¥¬3|ã\u000bf;(¦ÁÄÑLëþá6+E#\u0018h\u0099.\u0083N\u000bÕ\u0083y\u008a\u008eñ´\u0082{¨®\t\u0017Â\u0082ORÛ\u0015\u0099m(õjï*\n§\u001b 3U5·Á\u000b\"\u0091ÎpÑ®A\u009e·)éð\u001a\u001e\"ðë^>¯«\u009e[ð\u0012ë".length();
        char cCharAt = ' ';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "¥¬3|ã\u000bf;(õjï*\n§\u001b 3U5·Á\u000b\"\u0091ÎpÑ®A\u009e·)éð\u001a\u001e\"ðë^>¯«\u009e[ð\u0012ë";
                        length = "¥¬3|ã\u000bf;(õjï*\n§\u001b 3U5·Á\u000b\"\u0091ÎpÑ®A\u009e·)éð\u001a\u001e\"ðë^>¯«\u009e[ð\u0012ë".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_a(me.frep.vulcan.spigot.C0042Vulcan_Oz r10, com.github.retrooper.packetevents.event.PacketSendEvent r11) {
        /*
            Method dump skipped, instruction units count: 1769
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_v.Vulcan_a(me.frep.vulcan.spigot.Vulcan_Oz, com.github.retrooper.packetevents.event.PacketSendEvent):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:6:0x003d  */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.Object[]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void lambda$handle$0(me.frep.vulcan.spigot.C0042Vulcan_Oz r7) {
        /*
            long r0 = me.frep.vulcan.spigot.Vulcan_v.a
            r1 = 54815198838375(0x31daa8747e67, double:2.7082306615998E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 84866569008748(0x4d2f89b2f66c, double:4.1929656227638E-310)
            long r1 = r1 ^ r2
            r10 = r1
            int[] r0 = Vulcan_V()
            java.util.concurrent.ThreadLocalRandom r1 = java.util.concurrent.ThreadLocalRandom.current()
            r2 = -11500(0xffffffffffffd314, float:NaN)
            r3 = -11000(0xffffffffffffd508, float:NaN)
            int r1 = r1.nextInt(r2, r3)
            r14 = r1
            r12 = r0
            r0 = 0
            java.lang.Object[] r0 = new java.lang.Object[r0]
            boolean r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_r(r0)
            if (r0 == 0) goto L3d
            com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing r0 = new com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing
            r1 = r0
            r2 = r14
            r1.<init>(r2)
            r13 = r0
            r0 = r12
            if (r0 == 0) goto L4b
        L3d:
            com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation r0 = new com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation
            r1 = r0
            r2 = 0
            r3 = r14
            short r3 = (short) r3
            r4 = 0
            r1.<init>(r2, r3, r4)
            r13 = r0
        L4b:
            boolean r0 = me.frep.vulcan.spigot.Vulcan_fe.Vulcan_m0     // Catch: java.lang.RuntimeException -> L94
            if (r0 == 0) goto L98
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.RuntimeException -> L94
            r1 = r0
            r1.<init>()     // Catch: java.lang.RuntimeException -> L94
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_v.b     // Catch: java.lang.RuntimeException -> L94
            r2 = 0
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L94
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L94
            r1 = r14
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L94
            java.lang.String[] r1 = me.frep.vulcan.spigot.Vulcan_v.b     // Catch: java.lang.RuntimeException -> L94
            r2 = 2
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L94
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L94
            r1 = r7
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L94
            java.lang.String r1 = r1.Vulcan_c(r2)     // Catch: java.lang.RuntimeException -> L94
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.RuntimeException -> L94
            java.lang.String r0 = r0.toString()     // Catch: java.lang.RuntimeException -> L94
            r1 = r10
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L94
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L94
            r4 = r3; r3 = r2; r2 = r1; r1 = r4;      // Catch: java.lang.RuntimeException -> L94
            java.lang.Long r3 = java.lang.Long.valueOf(r3)     // Catch: java.lang.RuntimeException -> L94
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L94
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L94
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.RuntimeException -> L94
            r3 = r1; r1 = r2; r2 = r3;      // Catch: java.lang.RuntimeException -> L94
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L94
            r1[r2] = r3     // Catch: java.lang.RuntimeException -> L94
            me.frep.vulcan.spigot.Vulcan_OM.Vulcan_X(r0)     // Catch: java.lang.RuntimeException -> L94
            goto L98
        L94:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L98:
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            me.frep.vulcan.spigot.Vulcan_K r0 = r0.m640Vulcan_O(r1)
            r1 = r14
            short r1 = (short) r1
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r4 = 0
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r0.Vulcan_D(r1)
            r0 = r7
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            com.github.retrooper.packetevents.protocol.player.User r0 = r0.Vulcan_V(r1)
            r1 = r13
            r0.sendPacket(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_v.lambda$handle$0(me.frep.vulcan.spigot.Vulcan_Oz):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean, int] */
    private static boolean lambda$handle$1(EntityData entityData) {
        long j = a ^ 127201324330738L;
        ?? Vulcan_V = Vulcan_V();
        try {
            try {
                Vulcan_V = entityData.getIndex();
                return Vulcan_V == 0 ? Vulcan_V == 6 : Vulcan_V;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_V);
            }
        } catch (RuntimeException unused2) {
            Vulcan_V = a((RuntimeException) Vulcan_V);
            throw Vulcan_V;
        }
    }
}
