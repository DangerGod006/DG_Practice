package me.frep.vulcan.spigot;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.api.check.Check;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_ke, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ke.class */
public class C0051Vulcan_ke extends Vulcan_k4 implements CommandExecutor {
    private static boolean Vulcan_B;
    private static final long b = Vulcan_n.a(-8668003202999255971L, 1505000003042544487L, MethodHandles.lookup().lookupClass()).a(146572977178977L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x2b7b: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public boolean onCommand(org.bukkit.command.CommandSender r45, org.bukkit.command.Command r46, java.lang.String r47, java.lang.String[] r48) {
        /*
            Method dump skipped, instruction units count: 14083
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0051Vulcan_ke.onCommand(org.bukkit.command.CommandSender, org.bukkit.command.Command, java.lang.String, java.lang.String[]):boolean");
    }

    public static void Vulcan_w(boolean z) {
        Vulcan_B = z;
    }

    public static boolean Vulcan__() {
        return Vulcan_B;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_c() {
        return !Vulcan__();
    }

    static {
        int i;
        long j = b ^ 30103159351803L;
        Vulcan_w(false);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[172];
        int i3 = 0;
        String str = "tÜ?Gx&\u0002z\u0010ÓV<Ô;Ñú8\u0088\u001d÷Øí\\\u0013\u0090\b\u009eá;÷\u0017\u0099Ôw\u0018Ez\u009cÌY\u008d4Ï¾\u0081£o¼Ã\u0089kÍ±ËâÐFdó\u0010\u0094c\u009a\u009d%©þ\u001aûÚÒP\u009bÐ1'\u0010¼ôò.|di\u009c\u0098Â]!¿0\u0011w\bÊ²G\u001egZ\u0081\u0011\b\u008fõ\f±f\u001a\u0019\u0005\u0018\u008c¥Ú\u0014@DF}ZÝÌ¨¾7\u0087ô\fQÚ,©AÝã\u0018bìT\u008fÖ\fÕ\u0018\rkÞ\n=\nAÝ.\rWñüûýÊ ;h-\u0004¢Ê=íüÛì¡cå¿£¸,\u0002ä¹8\u009f°\f\u0015#\u0010Á\u0091\u0005Ë\u0010¬ô9ûk\u0014È¯g\u0013ð@½\u0007\u008d¬\u0010_ÑK\u0017\u008bÙzù§êp\u000bwØ\n3\u0010ù\u0017\u001eD}o\u0088¯mJttC\u00ad\u0019Ê\u0010DË\u009a#ÄÑÙ\u0002V\u0085æ)ÀQYÖ\u0018bìT\u008fÖ\fÕ\u0018-\u0081\u008b\u000f\u0092 í\u009e÷}ÈÕhÌïß\bl´\u0087.\\÷ko\u0010ù/\u008aO\u001f\u00adVg9vå\u0006Ý/ç»\u0010äºô5Ú\u009f\u008eì\u0088w.$v1!Ö\bÌ$\u0084ÿT\u0092u(\b9íw\"7 ôJ\u0010\u0001·îÁ@DtkXÛó4\u008d\u0093\\¡\u0018æâ|YWi(p\u001eq\u0088Mì\u008b\u001cN¹ü(À{ö.Ð\u0010Ü\u001aY\u0082¿\u007f\u0097Ó\u009d\u001dkÜ\u008dH9\u000b\u0018æâ|YWi(p\u001eq\u0088Mì\u008b\u001cN¹ü(À{ö.Ð\bjü\u001bV_§¼»\bRK\u0007\u009a1\u0084ÿ\\\bâ£þ\u0097\u000f~\bÝ\u0018Ák+9¼ÂVt\u0003\u008e=\u001f\u001aG\u009b\u008817]\u0017q¤\u0099â\u0018æÖF\u0010`vpCÐÐ\têøB\u0014\u001e\u0016\u0095\u0003µ\u0004F\u0090Ç\u0010Ôr\u00127\rÔ^1_ûánÉTÇ\u0095\u0018¨íû\u0098Ä\u0000Ã\b\"l\u008f&\u009a\u0098o4\u0095y-Ö\u001cu-\u0082\u0018\u008c¥Ú\u0014@DF}ØË\u008cÌ«ô\u009c$â\u009bKÆé'`Æ\u0010»\u009b\u0093é§áá\f½Õ\u007f1ÁÍa)\u0010<\u0099Í\u0088¯ñ\u0099\u0014Í]Àpe\u008f\u0005m\u0010ð/\u00153|\u0013\u008deº\u0001NxÖe|Ý\u0010bìT\u008fÖ\fÕ\u0018Â2\u0086JJ\u0001¸A\u0018\u008c¥Ú\u0014@DF}v\u0099\u001b\u0015÷q\u0087\u0003\u0018¬J\u0011c\u009bR=\u0018\u008c¥Ú\u0014@DF}E01Æð«5±ÅoH;¶\u001b<\u0006\u0018\u008c¥Ú\u0014@DF}Å\u008d\u00adÈ(×Þ\"Øa¸h\u00194Çë\u0010E¬\u0003¬þ0\u0011iä\u0017(èê\nÞÔ\b6/\u008cÄ\u0084ª(\u0094\u0010bìT\u008fÖ\fÕ\u0018\u009e£\u0098êßÈ\b\u001f\bß¶\u0004\u0084\u001b\u0085ï8\bXsümÌ\u008e.V\u0010[Sv-\u009b¥Í\u0012¦\u00014'\u0004>j\u0019\u0018\u008c¥Ú\u0014@DF}\"éZ\u0090\n¸Å\u000f¤Û¶H\u0095¦\u0015æ\u0010þ³X¢ûÅâ\u001edo\u009a\u001aFPAÁ\u0018äºô5Ú\u009f\u008eìk}bÞnhå0è¦×\u00adX'éÒ\bXsümÌ\u008e.V\u0010'ù\u0099hm¾-Dr\u00802\u008d\u0000²\tÓ\u00100Á\u0094Á>©\u009bzëÄU'8}%_\u0010r\u0097?\u0004¤\u008e}üÈÓé \u0085èó2\b\u0090\tO\u0084\u0006õº¾\bS®{\u0098à\u007fÆw\b\u009eá;÷\u0017\u0099Ôw\u0018Y8\u007fÔKv±m«Çe¸\u001c\u008f¼\u0087(^\u0090\u009a\u001fÔºÇ\u0018<\u0099Í\u0088¯ñ\u0099\u0014ìÊ\u009e\u009c\u0003ù\t½Í\u008aåGFl½\u008c\u0018¯ªB\u0089)';¸\u0085ø\u009aÃË\u0010ÄÙ\u0097\u0094a¦\u0086c¡£\u0018¯ªB\u0089)';¸Quí\"»R}V\u0090õÎË\u00170.¢\u0010Ä\u0017\u008b\f\u001fÝô`|LeÚ\u0087\\úD\b½\u001d\u000e¾Læiµ\u0010bìT\u008fÖ\fÕ\u0018\u0000LØ:¬ék\u008d\u0010\u0090\u0016ªÊ±\u0096\n\u009bº0Äÿ\u0002 \u009b\u0001\b½\u0012\u0017\u0091Áæ\u008e\u0080\bí\u0018\u0005!Pí\u0081p\b\u009am(eê|p\u0089\u0010bìT\u008fÖ\fÕ\u0018!¬\u008bÔ,\u001fNg\u0010×ÙX\u0005Ãq\u0084í\u009d\u009f\u0085¨\u001bÈ¸\u009e\b[\u008bî\u000fºp·®\u0018\u008cö:\u0089ø\u008fù\u0006#\u0099\u0083\u0002Wt)#\u0093³tP6®Ýw\u0018bìT\u008fÖ\fÕ\u0018èvN\b§\u0012\u000b4\u008f\u0091\u008cÃ\u001aEIr\u0018uSÔ\u0010O\u0084¨?ïé\u0095$ÔYº\u0089©5(CS2Ã´\bnÁ³\u0095Üb¡\u0083\u0010E¬\u0003¬þ0\u0011iä\u0017(èê\nÞÔ\u0018bìT\u008fÖ\fÕ\u0018\u0092Ê¡Ü,®\u0015\u009d\u008f\u0080áyð\u0093\u0007#\u0018±\u0086è\u009f\u008c&ùXnJõ÷\u007f\u008d\u0002Ç@u§öº\u00ad\u0006¯\u0018\u008c¥Ú\u0014@DF}\u0001\u001c:GôZ{÷ 5r\u0099©5\u0012%\u0018\u008c¥Ú\u0014@DF}\u0005æ^&¬8Î¡¦\f\u0089:º\u009dß9\u0010g±3\u000052\rÃQg\u000böýêò~\b\u000euxÓ«éÿ:\u0010Tûç\u009e·Áª\u0085Øk;\u0000\u000bGj´\btÜ?Gx&\u0002z\u0018äºô5Ú\u009f\u008eìk}bÞnhå0è¦×\u00adX'éÒ\u0018<\u0099Í\u0088¯ñ\u0099\u0014Xdhñ²Å¾dÝªÔ\\C°\u0004ô\u0010¾Ø\u000eu±)\u009fs,'+m\u0090úõ#\u0018bìT\u008fÖ\fÕ\u00182>\u0007¨q\u0013¾\u0097ÜÓ:\u009bõ.¬ÿ\u0018\u008c¥Ú\u0014@DF}ù¹4RkÀ\u0002éÞ\u0014Ëì\u0093QË©\u0010<\u0099Í\u0088¯ñ\u0099\u0014Ð®ânkc§' ¥,«89t\u00161õMè(q÷*\u0017~\u000eâ\u001b\f\u009c\u0013Âñ÷\u008cÀ`|\u001eó\bÊ²G\u001egZ\u0081\u0011\bí\u0018\u0005!Pí\u0081p\u0010Tûç\u009e·Áª\u0085Øk;\u0000\u000bGj´\u0010¯ªB\u0089)';¸Ö\u008aô\u0081Á\u008a\u0016\u007f\u0018B×\u0006\u0091*\u0082X)[ÐCYvR°ü7A÷S1Ué\u0086\u0010<\u0099Í\u0088¯ñ\u0099\u0014Þõo¤\tÇF4\u0018\f@k¢\u0089:$ÅÆ\u0090\u0088Ïâ\u0098õ\u0017C[\u0080.é\u0096;ù\u0010¨íû\u0098Ä\u0000Ã\b\u0096¯ÐªVi¶ç\u0010'ù\u0099hm¾-Dr\u00802\u008d\u0000²\tÓ 7ãå*jù\u0013ûõô\u0005\u00adîÄÖºá×\u0097|ÉG\u001ftÞ\u009eÃÇ\u0017ñóé\bS®{\u0098à\u007fÆw\b\f%lú\u0088²c¹\u0018±2ó¡ÑMÖ>ò\u0001,\u0014ìëÕ½¤üøT\u001ap¦à\u0018<\u0099Í\u0088¯ñ\u0099\u0014øÀv¤WýñLL9(\u0094bg\u0018\u009b(a\u0002+H-^\u000ehpB7\u008aFh\u0005Td\u008b\u0098\u0090Â{*\u0007¢s}YÎþ\fº(\u008e®£\u0086¬FÃ\bnÁ³\u0095Üb¡\u0083\u0018ëa\rBÓ\u009eR\u0088©\u001b\u0000<\u001f\u001aËâ(Û:\u0012çZë%\u0018\u008c¥Ú\u0014@DF}¯\u0086\u00101;a\u0084w\u008eCóè~k\u0099Æ\u0010\u008cö:\u0089ø\u008fù\u0006\u0085å·¼\u0018Ü\u009d!\u0018<\u0099Í\u0088¯ñ\u0099\u0014£vpR\u009d]\u008côè\u0012ayÓÒøË ëNç\u0019¹FÈjP\rà;\u001bSÝ~\u0098ä\f}Ãz\u0086¸\u009a\t- ¢»\u0011«\u0018¬ô9ûk\u0014È¯´\u001eç`n>x!5\u001f?úº\u0003¤$\u0018<\u0099Í\u0088¯ñ\u0099\u0014è\u0096`ÛO\u0095B\u0093'2Õ®±÷ª\u001e\u0010Õæ_Ü\u0019½Þ)a\u007f³\u0096»ÖJ\u009a\u0010äºô5Ú\u009f\u008eì\u0088w.$v1!Ö\u0018\u008c¥Ú\u0014@DF}ÿW±\r\u008dÞk\u0099Ø¤\u009d¢\u0000ìeÈ\u0018±2ó¡ÑMÖ>,-?\u0094\u001bm\u0084vXAIS\u0081qµý\bÕq).0÷]\u0001\u0010¬ô9ûk\u0014È¯g\u0013ð@½\u0007\u008d¬\u0010<\u0099Í\u0088¯ñ\u0099\u0014x\u0015\u0093)<\u0007 ¹\u0010<\u0099Í\u0088¯ñ\u0099\u0014x@ Ã]\u0010\u008aÍ\u0010iú~RÌ\u0095ç¼j%\u0016\u000eNñåZ\u0010±\u0086è\u009f\u008c&ùXCµ½[\u001b«\u0080í\u0010ÓV<Ô;Ñú8\u0088\u001d÷Øí\\\u0013\u0090\b\u0011çÿ\u0081\u0099\\¸À\b(ð\u0086uÂÏ\u0083w\u0018bìT\u008fÖ\fÕ\u0018èvN\b§\u0012\u000b4\u008f\u0091\u008cÃ\u001aEIr\bâ£þ\u0097\u000f~\bÝ\u0018mBU\u008b`Ì³äF5nß\u0012h°Qªêiª\u0098\u0086ó;\bn)i\u001d¿L\u0084j\u0010\f\b+XAa\róù\u0003c5gôç\u0003\u0018\u008c¥Ú\u0014@DF}Å\u008d\u00adÈ(×Þ\"Øa¸h\u00194Çë\u0018<\u0099Í\u0088¯ñ\u0099\u0014\u0004,øJ\u0016Ó¸Eª2øï±í\u0002\f\u0010Ò5\u0005ð\u0083¹$ß\u008d¥É½U¬½\u0016\u0010\f5å·ù\u0095\u0098\u0082Ì\u0090\u009e\u000e\u0015ê§d\u0018\u0094c\u009a\u009d%©þ\u001a\u000fiX\u0096ÎÄtÈ\u0011À£<b\u00ad`Þ\u0010Ü\u001aY\u0082¿\u007f\u0097Ó\u009d\u001dkÜ\u008dH9\u000b\b%\u0015Pù\u0092É\u0016\u008d\u0018bìT\u008fÖ\fÕ\u0018L\u008bÞ\u0004\u0094.\u0007ã¹çå\\?\u0006R\u0006\bç\u009f¿zÎøß\u0012\b½\u001d\u000e¾Læiµ\u0010jÊ'¾Ö\u0094\u0007,É\u0014f¦½ÊÏ°\u0018iú~RÌ\u0095ç¼Ã\u0087ü±\"\u008e\u008d¹D\u000eìÖDõ\u0018À\u00181KØéÆj?]>\u0082LÎ óË\u008cöJ\u0085]:Þ\u0016Ü\u0018_ÑK\u0017\u008bÙzù\u0007\\/½ß9*L¨ \u001fÅu\u000fTq\u0010jÊ'¾Ö\u0094\u0007,É\u0014f¦½ÊÏ°\bÕq).0÷]\u0001\bòý)\u0093Ã\u009cp¦\u0018×ÙX\u0005Ãq\u0084í\u0087íö\u0087ÜÌ\ngÇ\u0093Ø\u009b ªú \u0010DË\u009a#ÄÑÙ\u0002\u0018GL\u0019 \u001bÉÚ\u0018NÑ¶à\u001c©AÑvö»\u0002\u0013«5\u009d\u0000ÆÊ\r\u0099®\u0005W\u0010¼¬Z×%=P\u008d½§\u001fð¤ôkU\u0010bìT\u008fÖ\fÕ\u00188\u0018b\u001cvÑðã\u0018*~\u0098¼ÿFâßÌb\u0000\u0012\u0097_\u00941\u0018¹\u009dº<\u009cLÚ\u0010\u0083VJ\u0014Õ8Íé)\u001bÊdW\u000bÊö\u0010uSÔ\u0010O\u0084¨?æëQ\u00065¿#p\u0010±2ó¡ÑMÖ>Î\u001d|\u0093óqäyÀ\u008e(g\u0005ÛÜüÛ\u0019Ò\u000eöÄ@eEL+\u0085\u0014>\u0082~#\u0014\fäd\u0086Z\u009eã9Þ°\u009aì#v![Ü6\u001fÖgNFõ0x1\u001dp}Gx\u00ad½a¤@:QÜà@+ra(V_I\u001c\u0017\u009cÞÑÒW\u0094«k\u001dÕª÷\u0002õ4g\u00118Åð~f\u0095\u0080Ý¤ûÿ`î\u0003ú\u0096vc\u009d¼\u008eËæ@¤\u001fÁ\u0010H(£ª\u0014±ïw\u0081iç\u0083åvËÛj¢¯\bQbY\u0007b\u0002W\u0081P¯¬ôÿ\u0088#pK`Ò\u008fðÁó\u009cj\u0081\u009dÓú\u001e']«µ_í\u0013jü\u0019\u0097\u009d\u00140z\u009fn\u001b\u008e<Þ\bÉ£\u001f2\u0001c\u000fh\u0018<\u0099Í\u0088¯ñ\u0099\u0014øÀv¤WýñLL9(\u0094bg\u0018\u009b\u0010ð/\u00153|\u0013\u008deº\u0001NxÖe|Ý\u0018è\u00993ïy5%\u0006ÞÈÎ¯ðY\u007f>¤¿*\u0018\u0093øÐo\b\n´\u0093ýýmè\u00ad\b/¨kA\tç2\u0082\u0018Ez\u009cÌY\u008d4Ïá³bö*\u0017hn0\r²\u0093\u0011irM\u0018mBU\u008b`Ì³äF5nß\u0012h°Qªêiª\u0098\u0086ó;\u0018¬ô9ûk\u0014È¯´\u001eç`n>x!5\u001f?úº\u0003¤$\u00104ÀÏPÚ\u0014Îæ\u0004·ÀÕæy\u007f¡\bX-íX\u001c(±ß\u0018\u008cö:\u0089ø\u008fù\u0006#\u0099\u0083\u0002Wt)#\u0093³tP6®Ýw";
        int length = "tÜ?Gx&\u0002z\u0010ÓV<Ô;Ñú8\u0088\u001d÷Øí\\\u0013\u0090\b\u009eá;÷\u0017\u0099Ôw\u0018Ez\u009cÌY\u008d4Ï¾\u0081£o¼Ã\u0089kÍ±ËâÐFdó\u0010\u0094c\u009a\u009d%©þ\u001aûÚÒP\u009bÐ1'\u0010¼ôò.|di\u009c\u0098Â]!¿0\u0011w\bÊ²G\u001egZ\u0081\u0011\b\u008fõ\f±f\u001a\u0019\u0005\u0018\u008c¥Ú\u0014@DF}ZÝÌ¨¾7\u0087ô\fQÚ,©AÝã\u0018bìT\u008fÖ\fÕ\u0018\rkÞ\n=\nAÝ.\rWñüûýÊ ;h-\u0004¢Ê=íüÛì¡cå¿£¸,\u0002ä¹8\u009f°\f\u0015#\u0010Á\u0091\u0005Ë\u0010¬ô9ûk\u0014È¯g\u0013ð@½\u0007\u008d¬\u0010_ÑK\u0017\u008bÙzù§êp\u000bwØ\n3\u0010ù\u0017\u001eD}o\u0088¯mJttC\u00ad\u0019Ê\u0010DË\u009a#ÄÑÙ\u0002V\u0085æ)ÀQYÖ\u0018bìT\u008fÖ\fÕ\u0018-\u0081\u008b\u000f\u0092 í\u009e÷}ÈÕhÌïß\bl´\u0087.\\÷ko\u0010ù/\u008aO\u001f\u00adVg9vå\u0006Ý/ç»\u0010äºô5Ú\u009f\u008eì\u0088w.$v1!Ö\bÌ$\u0084ÿT\u0092u(\b9íw\"7 ôJ\u0010\u0001·îÁ@DtkXÛó4\u008d\u0093\\¡\u0018æâ|YWi(p\u001eq\u0088Mì\u008b\u001cN¹ü(À{ö.Ð\u0010Ü\u001aY\u0082¿\u007f\u0097Ó\u009d\u001dkÜ\u008dH9\u000b\u0018æâ|YWi(p\u001eq\u0088Mì\u008b\u001cN¹ü(À{ö.Ð\bjü\u001bV_§¼»\bRK\u0007\u009a1\u0084ÿ\\\bâ£þ\u0097\u000f~\bÝ\u0018Ák+9¼ÂVt\u0003\u008e=\u001f\u001aG\u009b\u008817]\u0017q¤\u0099â\u0018æÖF\u0010`vpCÐÐ\têøB\u0014\u001e\u0016\u0095\u0003µ\u0004F\u0090Ç\u0010Ôr\u00127\rÔ^1_ûánÉTÇ\u0095\u0018¨íû\u0098Ä\u0000Ã\b\"l\u008f&\u009a\u0098o4\u0095y-Ö\u001cu-\u0082\u0018\u008c¥Ú\u0014@DF}ØË\u008cÌ«ô\u009c$â\u009bKÆé'`Æ\u0010»\u009b\u0093é§áá\f½Õ\u007f1ÁÍa)\u0010<\u0099Í\u0088¯ñ\u0099\u0014Í]Àpe\u008f\u0005m\u0010ð/\u00153|\u0013\u008deº\u0001NxÖe|Ý\u0010bìT\u008fÖ\fÕ\u0018Â2\u0086JJ\u0001¸A\u0018\u008c¥Ú\u0014@DF}v\u0099\u001b\u0015÷q\u0087\u0003\u0018¬J\u0011c\u009bR=\u0018\u008c¥Ú\u0014@DF}E01Æð«5±ÅoH;¶\u001b<\u0006\u0018\u008c¥Ú\u0014@DF}Å\u008d\u00adÈ(×Þ\"Øa¸h\u00194Çë\u0010E¬\u0003¬þ0\u0011iä\u0017(èê\nÞÔ\b6/\u008cÄ\u0084ª(\u0094\u0010bìT\u008fÖ\fÕ\u0018\u009e£\u0098êßÈ\b\u001f\bß¶\u0004\u0084\u001b\u0085ï8\bXsümÌ\u008e.V\u0010[Sv-\u009b¥Í\u0012¦\u00014'\u0004>j\u0019\u0018\u008c¥Ú\u0014@DF}\"éZ\u0090\n¸Å\u000f¤Û¶H\u0095¦\u0015æ\u0010þ³X¢ûÅâ\u001edo\u009a\u001aFPAÁ\u0018äºô5Ú\u009f\u008eìk}bÞnhå0è¦×\u00adX'éÒ\bXsümÌ\u008e.V\u0010'ù\u0099hm¾-Dr\u00802\u008d\u0000²\tÓ\u00100Á\u0094Á>©\u009bzëÄU'8}%_\u0010r\u0097?\u0004¤\u008e}üÈÓé \u0085èó2\b\u0090\tO\u0084\u0006õº¾\bS®{\u0098à\u007fÆw\b\u009eá;÷\u0017\u0099Ôw\u0018Y8\u007fÔKv±m«Çe¸\u001c\u008f¼\u0087(^\u0090\u009a\u001fÔºÇ\u0018<\u0099Í\u0088¯ñ\u0099\u0014ìÊ\u009e\u009c\u0003ù\t½Í\u008aåGFl½\u008c\u0018¯ªB\u0089)';¸\u0085ø\u009aÃË\u0010ÄÙ\u0097\u0094a¦\u0086c¡£\u0018¯ªB\u0089)';¸Quí\"»R}V\u0090õÎË\u00170.¢\u0010Ä\u0017\u008b\f\u001fÝô`|LeÚ\u0087\\úD\b½\u001d\u000e¾Læiµ\u0010bìT\u008fÖ\fÕ\u0018\u0000LØ:¬ék\u008d\u0010\u0090\u0016ªÊ±\u0096\n\u009bº0Äÿ\u0002 \u009b\u0001\b½\u0012\u0017\u0091Áæ\u008e\u0080\bí\u0018\u0005!Pí\u0081p\b\u009am(eê|p\u0089\u0010bìT\u008fÖ\fÕ\u0018!¬\u008bÔ,\u001fNg\u0010×ÙX\u0005Ãq\u0084í\u009d\u009f\u0085¨\u001bÈ¸\u009e\b[\u008bî\u000fºp·®\u0018\u008cö:\u0089ø\u008fù\u0006#\u0099\u0083\u0002Wt)#\u0093³tP6®Ýw\u0018bìT\u008fÖ\fÕ\u0018èvN\b§\u0012\u000b4\u008f\u0091\u008cÃ\u001aEIr\u0018uSÔ\u0010O\u0084¨?ïé\u0095$ÔYº\u0089©5(CS2Ã´\bnÁ³\u0095Üb¡\u0083\u0010E¬\u0003¬þ0\u0011iä\u0017(èê\nÞÔ\u0018bìT\u008fÖ\fÕ\u0018\u0092Ê¡Ü,®\u0015\u009d\u008f\u0080áyð\u0093\u0007#\u0018±\u0086è\u009f\u008c&ùXnJõ÷\u007f\u008d\u0002Ç@u§öº\u00ad\u0006¯\u0018\u008c¥Ú\u0014@DF}\u0001\u001c:GôZ{÷ 5r\u0099©5\u0012%\u0018\u008c¥Ú\u0014@DF}\u0005æ^&¬8Î¡¦\f\u0089:º\u009dß9\u0010g±3\u000052\rÃQg\u000böýêò~\b\u000euxÓ«éÿ:\u0010Tûç\u009e·Áª\u0085Øk;\u0000\u000bGj´\btÜ?Gx&\u0002z\u0018äºô5Ú\u009f\u008eìk}bÞnhå0è¦×\u00adX'éÒ\u0018<\u0099Í\u0088¯ñ\u0099\u0014Xdhñ²Å¾dÝªÔ\\C°\u0004ô\u0010¾Ø\u000eu±)\u009fs,'+m\u0090úõ#\u0018bìT\u008fÖ\fÕ\u00182>\u0007¨q\u0013¾\u0097ÜÓ:\u009bõ.¬ÿ\u0018\u008c¥Ú\u0014@DF}ù¹4RkÀ\u0002éÞ\u0014Ëì\u0093QË©\u0010<\u0099Í\u0088¯ñ\u0099\u0014Ð®ânkc§' ¥,«89t\u00161õMè(q÷*\u0017~\u000eâ\u001b\f\u009c\u0013Âñ÷\u008cÀ`|\u001eó\bÊ²G\u001egZ\u0081\u0011\bí\u0018\u0005!Pí\u0081p\u0010Tûç\u009e·Áª\u0085Øk;\u0000\u000bGj´\u0010¯ªB\u0089)';¸Ö\u008aô\u0081Á\u008a\u0016\u007f\u0018B×\u0006\u0091*\u0082X)[ÐCYvR°ü7A÷S1Ué\u0086\u0010<\u0099Í\u0088¯ñ\u0099\u0014Þõo¤\tÇF4\u0018\f@k¢\u0089:$ÅÆ\u0090\u0088Ïâ\u0098õ\u0017C[\u0080.é\u0096;ù\u0010¨íû\u0098Ä\u0000Ã\b\u0096¯ÐªVi¶ç\u0010'ù\u0099hm¾-Dr\u00802\u008d\u0000²\tÓ 7ãå*jù\u0013ûõô\u0005\u00adîÄÖºá×\u0097|ÉG\u001ftÞ\u009eÃÇ\u0017ñóé\bS®{\u0098à\u007fÆw\b\f%lú\u0088²c¹\u0018±2ó¡ÑMÖ>ò\u0001,\u0014ìëÕ½¤üøT\u001ap¦à\u0018<\u0099Í\u0088¯ñ\u0099\u0014øÀv¤WýñLL9(\u0094bg\u0018\u009b(a\u0002+H-^\u000ehpB7\u008aFh\u0005Td\u008b\u0098\u0090Â{*\u0007¢s}YÎþ\fº(\u008e®£\u0086¬FÃ\bnÁ³\u0095Üb¡\u0083\u0018ëa\rBÓ\u009eR\u0088©\u001b\u0000<\u001f\u001aËâ(Û:\u0012çZë%\u0018\u008c¥Ú\u0014@DF}¯\u0086\u00101;a\u0084w\u008eCóè~k\u0099Æ\u0010\u008cö:\u0089ø\u008fù\u0006\u0085å·¼\u0018Ü\u009d!\u0018<\u0099Í\u0088¯ñ\u0099\u0014£vpR\u009d]\u008côè\u0012ayÓÒøË ëNç\u0019¹FÈjP\rà;\u001bSÝ~\u0098ä\f}Ãz\u0086¸\u009a\t- ¢»\u0011«\u0018¬ô9ûk\u0014È¯´\u001eç`n>x!5\u001f?úº\u0003¤$\u0018<\u0099Í\u0088¯ñ\u0099\u0014è\u0096`ÛO\u0095B\u0093'2Õ®±÷ª\u001e\u0010Õæ_Ü\u0019½Þ)a\u007f³\u0096»ÖJ\u009a\u0010äºô5Ú\u009f\u008eì\u0088w.$v1!Ö\u0018\u008c¥Ú\u0014@DF}ÿW±\r\u008dÞk\u0099Ø¤\u009d¢\u0000ìeÈ\u0018±2ó¡ÑMÖ>,-?\u0094\u001bm\u0084vXAIS\u0081qµý\bÕq).0÷]\u0001\u0010¬ô9ûk\u0014È¯g\u0013ð@½\u0007\u008d¬\u0010<\u0099Í\u0088¯ñ\u0099\u0014x\u0015\u0093)<\u0007 ¹\u0010<\u0099Í\u0088¯ñ\u0099\u0014x@ Ã]\u0010\u008aÍ\u0010iú~RÌ\u0095ç¼j%\u0016\u000eNñåZ\u0010±\u0086è\u009f\u008c&ùXCµ½[\u001b«\u0080í\u0010ÓV<Ô;Ñú8\u0088\u001d÷Øí\\\u0013\u0090\b\u0011çÿ\u0081\u0099\\¸À\b(ð\u0086uÂÏ\u0083w\u0018bìT\u008fÖ\fÕ\u0018èvN\b§\u0012\u000b4\u008f\u0091\u008cÃ\u001aEIr\bâ£þ\u0097\u000f~\bÝ\u0018mBU\u008b`Ì³äF5nß\u0012h°Qªêiª\u0098\u0086ó;\bn)i\u001d¿L\u0084j\u0010\f\b+XAa\róù\u0003c5gôç\u0003\u0018\u008c¥Ú\u0014@DF}Å\u008d\u00adÈ(×Þ\"Øa¸h\u00194Çë\u0018<\u0099Í\u0088¯ñ\u0099\u0014\u0004,øJ\u0016Ó¸Eª2øï±í\u0002\f\u0010Ò5\u0005ð\u0083¹$ß\u008d¥É½U¬½\u0016\u0010\f5å·ù\u0095\u0098\u0082Ì\u0090\u009e\u000e\u0015ê§d\u0018\u0094c\u009a\u009d%©þ\u001a\u000fiX\u0096ÎÄtÈ\u0011À£<b\u00ad`Þ\u0010Ü\u001aY\u0082¿\u007f\u0097Ó\u009d\u001dkÜ\u008dH9\u000b\b%\u0015Pù\u0092É\u0016\u008d\u0018bìT\u008fÖ\fÕ\u0018L\u008bÞ\u0004\u0094.\u0007ã¹çå\\?\u0006R\u0006\bç\u009f¿zÎøß\u0012\b½\u001d\u000e¾Læiµ\u0010jÊ'¾Ö\u0094\u0007,É\u0014f¦½ÊÏ°\u0018iú~RÌ\u0095ç¼Ã\u0087ü±\"\u008e\u008d¹D\u000eìÖDõ\u0018À\u00181KØéÆj?]>\u0082LÎ óË\u008cöJ\u0085]:Þ\u0016Ü\u0018_ÑK\u0017\u008bÙzù\u0007\\/½ß9*L¨ \u001fÅu\u000fTq\u0010jÊ'¾Ö\u0094\u0007,É\u0014f¦½ÊÏ°\bÕq).0÷]\u0001\bòý)\u0093Ã\u009cp¦\u0018×ÙX\u0005Ãq\u0084í\u0087íö\u0087ÜÌ\ngÇ\u0093Ø\u009b ªú \u0010DË\u009a#ÄÑÙ\u0002\u0018GL\u0019 \u001bÉÚ\u0018NÑ¶à\u001c©AÑvö»\u0002\u0013«5\u009d\u0000ÆÊ\r\u0099®\u0005W\u0010¼¬Z×%=P\u008d½§\u001fð¤ôkU\u0010bìT\u008fÖ\fÕ\u00188\u0018b\u001cvÑðã\u0018*~\u0098¼ÿFâßÌb\u0000\u0012\u0097_\u00941\u0018¹\u009dº<\u009cLÚ\u0010\u0083VJ\u0014Õ8Íé)\u001bÊdW\u000bÊö\u0010uSÔ\u0010O\u0084¨?æëQ\u00065¿#p\u0010±2ó¡ÑMÖ>Î\u001d|\u0093óqäyÀ\u008e(g\u0005ÛÜüÛ\u0019Ò\u000eöÄ@eEL+\u0085\u0014>\u0082~#\u0014\fäd\u0086Z\u009eã9Þ°\u009aì#v![Ü6\u001fÖgNFõ0x1\u001dp}Gx\u00ad½a¤@:QÜà@+ra(V_I\u001c\u0017\u009cÞÑÒW\u0094«k\u001dÕª÷\u0002õ4g\u00118Åð~f\u0095\u0080Ý¤ûÿ`î\u0003ú\u0096vc\u009d¼\u008eËæ@¤\u001fÁ\u0010H(£ª\u0014±ïw\u0081iç\u0083åvËÛj¢¯\bQbY\u0007b\u0002W\u0081P¯¬ôÿ\u0088#pK`Ò\u008fðÁó\u009cj\u0081\u009dÓú\u001e']«µ_í\u0013jü\u0019\u0097\u009d\u00140z\u009fn\u001b\u008e<Þ\bÉ£\u001f2\u0001c\u000fh\u0018<\u0099Í\u0088¯ñ\u0099\u0014øÀv¤WýñLL9(\u0094bg\u0018\u009b\u0010ð/\u00153|\u0013\u008deº\u0001NxÖe|Ý\u0018è\u00993ïy5%\u0006ÞÈÎ¯ðY\u007f>¤¿*\u0018\u0093øÐo\b\n´\u0093ýýmè\u00ad\b/¨kA\tç2\u0082\u0018Ez\u009cÌY\u008d4Ïá³bö*\u0017hn0\r²\u0093\u0011irM\u0018mBU\u008b`Ì³äF5nß\u0012h°Qªêiª\u0098\u0086ó;\u0018¬ô9ûk\u0014È¯´\u001eç`n>x!5\u001f?úº\u0003¤$\u00104ÀÏPÚ\u0014Îæ\u0004·ÀÕæy\u007f¡\bX-íX\u001c(±ß\u0018\u008cö:\u0089ø\u008fù\u0006#\u0099\u0083\u0002Wt)#\u0093³tP6®Ýw".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "DË\u009a#ÄÑÙ\u0002o¨°ÁJãJ¨\u0010~Ë\u0010\u00addÔ÷\u008eýÙç+\u001bÝ[>";
                        length = "DË\u009a#ÄÑÙ\u0002o¨°ÁJãJ¨\u0010~Ë\u0010\u00addÔ÷\u008eýÙç+\u001bÝ[>".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.String] */
    private void lambda$onCommand$0(CommandSender commandSender, String str) {
        long j = (b ^ 742390546625L) ^ 13817893292052L;
        Object[] objArr = new Object[3];
        str.replaceAll(d[141], Vulcan_r.INSTANCE.m1084Vulcan_j().getDescription().getVersion())[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.String] */
    private void lambda$onCommand$1(CommandSender commandSender, String str) {
        long j = (b ^ 116523110975841L) ^ 111908691673524L;
        Object[] objArr = new Object[3];
        str.replaceAll(d[145], Vulcan_r.INSTANCE.m1084Vulcan_j().getDescription().getVersion())[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    private static Integer lambda$onCommand$2(Integer num, Integer num2) {
        return num;
    }

    private static Integer lambda$onCommand$3(Integer num, Integer num2) {
        return num;
    }

    private static Integer lambda$onCommand$4(Integer num, Integer num2) {
        return num;
    }

    private static Integer lambda$onCommand$5(Integer num, Integer num2) {
        return num;
    }

    /* JADX WARN: Type inference failed for: r2v41, types: [java.lang.String] */
    private void lambda$onCommand$6(CommandSender commandSender, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, String str18, String str19, String str20, String str21, String str22, String str23, String str24, String str25, String str26, String str27, String str28, String str29, String str30, String str31, String str32, String str33, String str34, String str35, String str36, String str37, String str38, String str39, String str40, String str41) {
        long j = (b ^ 136433398117652L) ^ 123317156134337L;
        String[] strArr = d;
        Object[] objArr = new Object[3];
        str41.replaceAll(strArr[122], str).replaceAll(strArr[12], str2).replaceAll(strArr[4], str3).replaceAll(strArr[68], str4).replaceAll(strArr[155], str5).replaceAll(strArr[76], str6).replaceAll(strArr[144], str7).replaceAll(strArr[135], str8).replaceAll(strArr[148], str9).replaceAll(strArr[72], str10).replaceAll(strArr[95], str11).replaceAll(strArr[88], str12).replaceAll(strArr[119], str13).replaceAll(strArr[34], str14).replaceAll(strArr[120], str15).replaceAll(strArr[132], str16).replaceAll(strArr[57], str17).replaceAll(strArr[112], str18).replaceAll(strArr[109], str19).replaceAll(strArr[84], str20).replaceAll(strArr[8], str21).replaceAll(strArr[78], str22).replaceAll(strArr[107], str23).replaceAll(strArr[46], str24).replaceAll(strArr[32], str25).replaceAll(strArr[77], str26).replaceAll(strArr[37], str27).replaceAll(strArr[38], str28).replaceAll(strArr[115], str29).replaceAll(strArr[87], str30).replaceAll(strArr[67], str31).replaceAll(strArr[36], str32).replaceAll(strArr[62], str33).replaceAll(strArr[152], str34).replaceAll(strArr[42], str35).replaceAll(strArr[86], str36).replaceAll(strArr[138], str37).replaceAll(strArr[75], str38).replaceAll(strArr[15], str39).replaceAll(strArr[9], str40)[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [java.lang.String] */
    private void lambda$onCommand$7(CommandSender commandSender, String str) {
        Object[] objArr = new Object[3];
        (d[168] + str)[2] = Long.valueOf((b ^ 79462599483492L) ^ 75285264345265L);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    private static void lambda$onCommand$8(Check check, C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = (b ^ 15958539528030L) ^ 78746602811402L;
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        Object[] objArr = d;
        Object[] objArr2 = new Object[4];
        objArr2[3] = objArr[136];
        c0042Vulcan_Oz[2] = Long.valueOf(j);
        objArr2[1] = objArr2;
        objArr2[0] = (AbstractCheck) check;
        vulcan_OBVulcan_e.Vulcan_N(objArr2);
        Vulcan_OB vulcan_OBVulcan_e2 = Vulcan_r.INSTANCE.Vulcan_e();
        Object[] objArr3 = new Object[4];
        objArr3[3] = objArr[23];
        c0042Vulcan_Oz[2] = Long.valueOf(j);
        objArr3[1] = objArr3;
        objArr3[0] = (AbstractCheck) check;
        vulcan_OBVulcan_e2.Vulcan_N(objArr3);
        Vulcan_OB vulcan_OBVulcan_e3 = Vulcan_r.INSTANCE.Vulcan_e();
        Object[] objArr4 = new Object[4];
        objArr4[3] = objArr[23];
        c0042Vulcan_Oz[2] = Long.valueOf(j);
        objArr4[1] = objArr4;
        objArr4[0] = (AbstractCheck) check;
        vulcan_OBVulcan_e3.Vulcan_N(objArr4);
    }

    private static void lambda$onCommand$9(Player player, Player player2, String str) {
        player.performCommand(str.replaceAll(d[123], player2.getName()));
    }

    private static void lambda$onCommand$10(String str, String str2) {
        Vulcan_OM.Vulcan_Y(str2.replaceAll(d[123], str));
    }

    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.String] */
    private void lambda$onCommand$11(CommandSender commandSender, Player player, String str, String str2, String str3, String str4, String str5, String str6) {
        long j = (b ^ 108684598824584L) ^ 121929718826589L;
        String[] strArr = d;
        Object[] objArr = new Object[3];
        str6.replaceAll(strArr[1], player.getName()).replaceAll(strArr[153], str).replaceAll(strArr[96], str2).replaceAll(strArr[106], str3).replaceAll(strArr[89], str4).replaceAll(strArr[134], str5)[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    private static String lambda$onCommand$12(Vulcan_OU vulcan_OU) {
        return String.valueOf(vulcan_OU.Vulcan_G(new Object[0]));
    }

    /* JADX WARN: Type inference failed for: r2v19, types: [java.lang.String] */
    private void lambda$onCommand$13(CommandSender commandSender, String str, String str2, String str3, String str4, C0042Vulcan_Oz c0042Vulcan_Oz, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13) {
        long j = (b ^ 112625485239010L) ^ 116905947535927L;
        String[] strArr = d;
        Object[] objArr = new Object[3];
        str13.replaceAll(strArr[123], str).replaceAll(strArr[18], str2).replaceAll(strArr[117], str3).replaceAll(strArr[2], str4).replaceAll(strArr[160], Double.toString(c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m708Vulcan_C(new Object[0]))).replaceAll(strArr[90], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_x1(new Object[0]))).replaceAll(strArr[0], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m961Vulcan_w(new Object[0]))).replaceAll(strArr[44], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m962Vulcan_c(new Object[0]))).replaceAll(strArr[91], c0042Vulcan_Oz.Vulcan_e(new Object[0]).getWorld().getName()).replaceAll(strArr[22], c0042Vulcan_Oz.Vulcan_e(new Object[0]).getActivePotionEffects().toString()).replaceAll(strArr[118], str5).replaceAll(strArr[111], str6).replaceAll(strArr[83], str7).replaceAll(strArr[165], str8).replaceAll(strArr[103], str9).replaceAll(strArr[39], str10).replaceAll(strArr[71], str11).replaceAll(strArr[40], str12)[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    /* JADX WARN: Type inference failed for: r2v19, types: [java.lang.String] */
    private void lambda$onCommand$14(CommandSender commandSender, String str, String str2, String str3, String str4, C0042Vulcan_Oz c0042Vulcan_Oz, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13) {
        long j = (b ^ 76615529319393L) ^ 80898160263988L;
        String[] strArr = d;
        Object[] objArr = new Object[3];
        str13.replaceAll(strArr[123], str).replaceAll(strArr[114], str2).replaceAll(strArr[146], str3).replaceAll(strArr[55], str4).replaceAll(strArr[35], Double.toString(c0042Vulcan_Oz.m637Vulcan_r(new Object[0]).m708Vulcan_C(new Object[0]))).replaceAll(strArr[6], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_x1(new Object[0]))).replaceAll(strArr[82], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m961Vulcan_w(new Object[0]))).replaceAll(strArr[49], Integer.toString(c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).m962Vulcan_c(new Object[0]))).replaceAll(strArr[65], c0042Vulcan_Oz.Vulcan_e(new Object[0]).getWorld().getName()).replaceAll(strArr[24], c0042Vulcan_Oz.Vulcan_e(new Object[0]).getActivePotionEffects().toString()).replaceAll(strArr[11], str5).replaceAll(strArr[166], str6).replaceAll(strArr[48], str7).replaceAll(strArr[128], str8).replaceAll(strArr[159], str9).replaceAll(strArr[131], str10).replaceAll(strArr[126], str11).replaceAll(strArr[74], str12)[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = commandSender;
        Vulcan_D(objArr);
    }

    private void Vulcan_Q(Object[] objArr) {
        Player player = (Player) objArr[0];
        String str = (String) objArr[1];
        ByteArrayDataOutput byteArrayDataOutputNewDataOutput = ByteStreams.newDataOutput();
        String[] strArr = d;
        byteArrayDataOutputNewDataOutput.writeUTF(strArr[79]);
        byteArrayDataOutputNewDataOutput.writeUTF(str);
        player.sendPluginMessage(Vulcan_r.INSTANCE.m1084Vulcan_j(), strArr[33], byteArrayDataOutputNewDataOutput.toByteArray());
    }
}
