package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fP.class */
public final class Vulcan_fP {
    private static final long a = Vulcan_n.a(1655811503910339886L, 1308621989524972002L, MethodHandles.lookup().lookupClass()).a(101520191611660L);
    private static final String b;

    static {
        long j = a ^ 113405402791419L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        b = a(cipher.doFinal("[Õ#\u007fÞ\u008cöP\u009cì\u008fJCÂò\u0018°%\u000b\u0010îYï\u009c%àD\u0092\u0012úß\u0019¹P\u0083?Ñ?\u0015\u001dµÇâ#\u0091¼ËË\u00adOògÊ\u001d*g".getBytes(CharEncoding.ISO_8859_1))).intern();
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_fP() {
        throw new UnsupportedOperationException(b);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_w(Object[] objArr) {
        Collection collection = (Collection) objArr[0];
        Predicate predicate = (Predicate) objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        if (predicate == null) {
            return false;
        }
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            ?? next = it.next();
            try {
                try {
                    next = predicate.test(next);
                    AbstractCheck[] abstractCheckArr = abstractCheckArrVulcan_q;
                    if (jLongValue > 0) {
                        if (abstractCheckArr == null) {
                            return next;
                        }
                        abstractCheckArr = abstractCheckArrVulcan_q;
                    }
                    if (abstractCheckArr == null) {
                        return next;
                    }
                    if (next != 0) {
                        return true;
                    }
                    if (abstractCheckArrVulcan_q == null) {
                        break;
                    }
                } catch (UnsupportedOperationException unused) {
                    next = a((UnsupportedOperationException) next);
                    throw next;
                }
            } catch (UnsupportedOperationException unused2) {
                throw a((UnsupportedOperationException) next);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v17, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static boolean Vulcan_a(Object[] objArr) {
        Collection collection = (Collection) objArr[0];
        Predicate predicate = (Predicate) objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        if (predicate == null) {
            return false;
        }
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            ?? next = it.next();
            try {
                try {
                    next = predicate.test(next);
                    AbstractCheck[] abstractCheckArr = abstractCheckArrVulcan_q;
                    if (jLongValue >= 0) {
                        if (abstractCheckArr == null) {
                            return next;
                        }
                        abstractCheckArr = abstractCheckArrVulcan_q;
                    }
                    if (abstractCheckArr == null) {
                        return next;
                    }
                    if (next == 0) {
                        return false;
                    }
                    if (abstractCheckArrVulcan_q == null) {
                        break;
                    }
                } catch (UnsupportedOperationException unused) {
                    throw a((UnsupportedOperationException) next);
                }
            } catch (UnsupportedOperationException unused2) {
                next = a((UnsupportedOperationException) next);
                throw next;
            }
        }
        return true;
    }
}
