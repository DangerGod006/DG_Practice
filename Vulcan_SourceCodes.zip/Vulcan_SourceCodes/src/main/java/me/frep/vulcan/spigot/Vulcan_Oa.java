package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Oa.class */
public class Vulcan_Oa {
    public final double Vulcan_v;
    public final double Vulcan_I;
    public final double Vulcan_h;
    private static final String Vulcan__;
    private static final long a = Vulcan_n.a(-9091270933151287248L, 3648387812003044703L, MethodHandles.lookup().lookupClass()).a(144883251139745L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0033: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public me.frep.vulcan.spigot.Vulcan_Oa Vulcan_R(java.lang.Object[] r12) {
        /*
            r11 = this;
            r0 = r12
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Oa.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            r0 = r11
            double r0 = r0.Vulcan_v
            r1 = r11
            double r1 = r1.Vulcan_v
            double r0 = r0 * r1
            r1 = r11
            double r1 = r1.Vulcan_I
            r2 = r11
            double r2 = r2.Vulcan_I
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r11
            double r1 = r1.Vulcan_h
            r2 = r11
            double r2 = r2.Vulcan_h
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            r15 = r0
            r0 = r15
            r1 = 4547007122018943789(0x3f1a36e2eb1c432d, double:1.0E-4)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L5c
            me.frep.vulcan.spigot.Vulcan_Oa r0 = new me.frep.vulcan.spigot.Vulcan_Oa     // Catch: java.lang.RuntimeException -> L58
            r1 = r0
            r2 = 0
            r3 = 0
            r4 = 0
            r1.<init>(r2, r3, r4)     // Catch: java.lang.RuntimeException -> L58
            goto L78
        L58:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L58
            throw r0
        L5c:
            me.frep.vulcan.spigot.Vulcan_Oa r0 = new me.frep.vulcan.spigot.Vulcan_Oa
            r1 = r0
            r2 = r11
            double r2 = r2.Vulcan_v
            r3 = r15
            double r2 = r2 / r3
            r3 = r11
            double r3 = r3.Vulcan_I
            r4 = r15
            double r3 = r3 / r4
            r4 = r11
            double r4 = r4.Vulcan_h
            r5 = r15
            double r4 = r4 / r5
            r1.<init>(r2, r3, r4)
        L78:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.Vulcan_R(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_Oa");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x003c: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_B, reason: collision with other method in class */
    public double m605Vulcan_B(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            me.frep.vulcan.spigot.Vulcan_Oa r1 = (me.frep.vulcan.spigot.Vulcan_Oa) r1
            r9 = r1
            r0 = r9
            double r0 = r0.Vulcan_v
            r1 = r7
            double r1 = r1.Vulcan_v
            double r0 = r0 - r1
            r10 = r0
            r0 = r9
            double r0 = r0.Vulcan_I
            r1 = r7
            double r1 = r1.Vulcan_I
            double r0 = r0 - r1
            r12 = r0
            r0 = r9
            double r0 = r0.Vulcan_h
            r1 = r7
            double r1 = r1.Vulcan_h
            double r0 = r0 - r1
            r14 = r0
            r0 = r10
            r1 = r10
            double r0 = r0 * r1
            r1 = r12
            r2 = r12
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r14
            r2 = r14
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.m605Vulcan_B(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0023: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public double Vulcan_x(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r0 = r7
            double r0 = r0.Vulcan_v
            r1 = r7
            double r1 = r1.Vulcan_v
            double r0 = r0 * r1
            r1 = r7
            double r1 = r1.Vulcan_I
            r2 = r7
            double r2 = r2.Vulcan_I
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = r7
            double r1 = r1.Vulcan_h
            r2 = r7
            double r2 = r2.Vulcan_h
            double r1 = r1 * r2
            double r0 = r0 + r1
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Double r2 = java.lang.Double.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            float r0 = me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_j(r0)
            double r0 = (double) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.Vulcan_x(java.lang.Object[]):double");
    }

    static {
        int i;
        long j = a ^ 54165329873615L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[6];
        int i3 = 0;
        String str = "N\u000fs`5ö2Îù:\u0089h¾Ó\u0012H¬è&Ô\u009d\tu\u007f\u0010?µ%\u009f©·\u009bF\u001båÆ{Ûd¥C\bS÷¤ä÷U7\u0087\u0010xÀ\u0001\u0004-ãË\u009cf;uR©\u0000ÕQ";
        int length = "N\u000fs`5ö2Îù:\u0089h¾Ó\u0012H¬è&Ô\u009d\tu\u007f\u0010?µ%\u009f©·\u009bF\u001båÆ{Ûd¥C\bS÷¤ä÷U7\u0087\u0010xÀ\u0001\u0004-ãË\u009cf;uR©\u0000ÕQ".length();
        char cCharAt = 24;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            Vulcan__ = b[5];
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "S÷¤ä÷U7\u0087\u0010l¥/B¶j_u\feÇý¬(êF";
                        length = "S÷¤ä÷U7\u0087\u0010l¥/B¶j_u\feÇý¬(êF".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public double Vulcan_f(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public double m606Vulcan_R(Object[] objArr) {
        return this.Vulcan_I;
    }

    public double Vulcan_t(Object[] objArr) {
        return this.Vulcan_h;
    }

    public static String spigot() {
        return b[1];
    }

    public static String nonce() {
        return b[3];
    }

    public static String resource() {
        return b[0];
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public Vulcan_Oa(double r6, double r8, double r10) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_Oa.a
            r1 = 22164784430440(0x1428a41a3d68, double:1.09508585345573E-310)
            long r0 = r0 ^ r1
            r12 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r1 = r5
            r1.<init>()
            r14 = r0
            r0 = r6
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 != 0) goto L2d
            if (r0 != 0) goto L28
            goto L26
        L22:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L26:
            r0 = 0
            r6 = r0
        L28:
            r0 = r8
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
        L2d:
            r1 = r14
            if (r1 != 0) goto L50
            if (r0 != 0) goto L3e
            goto L3c
        L38:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L3c:
            r0 = 0
            r8 = r0
        L3e:
            r0 = r10
            r1 = r14
            if (r1 != 0) goto L54
            r1 = -9223372036854775808
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L50
        L4c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L50:
            if (r0 != 0) goto L56
            r0 = 0
        L54:
            r10 = r0
        L56:
            r0 = r5
            r1 = r6
            r0.Vulcan_v = r1
            r0 = r5
            r1 = r8
            r0.Vulcan_I = r1
            r0 = r5
            r1 = r10
            r0.Vulcan_h = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.<init>(double, double, double):void");
    }

    public Vulcan_Oa Vulcan_C(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        return new Vulcan_Oa(vulcan_Oa.Vulcan_v - this.Vulcan_v, vulcan_Oa.Vulcan_I - this.Vulcan_I, vulcan_Oa.Vulcan_h - this.Vulcan_h);
    }

    /* JADX INFO: renamed from: Vulcan_C, reason: collision with other method in class */
    public double m604Vulcan_C(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        return (this.Vulcan_v * vulcan_Oa.Vulcan_v) + (this.Vulcan_I * vulcan_Oa.Vulcan_I) + (this.Vulcan_h * vulcan_Oa.Vulcan_h);
    }

    public Vulcan_Oa Vulcan_J(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        return new Vulcan_Oa((this.Vulcan_I * vulcan_Oa.Vulcan_h) - (this.Vulcan_h * vulcan_Oa.Vulcan_I), (this.Vulcan_h * vulcan_Oa.Vulcan_v) - (this.Vulcan_v * vulcan_Oa.Vulcan_h), (this.Vulcan_v * vulcan_Oa.Vulcan_I) - (this.Vulcan_I * vulcan_Oa.Vulcan_v));
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [double] */
    /* JADX WARN: Type inference failed for: r2v2, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_Oa] */
    public Vulcan_Oa Vulcan_U(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        ?? r1 = vulcan_Oa.Vulcan_v;
        ?? r4 = new Object[3];
        vulcan_Oa.Vulcan_I[2] = Double.valueOf(vulcan_Oa.Vulcan_h);
        r1[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_s(r4);
    }

    /* JADX WARN: Type inference failed for: r1v13, types: [double] */
    /* JADX WARN: Type inference failed for: r2v4, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_Oa] */
    public Vulcan_Oa Vulcan_s(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        ?? r4 = new Object[3];
        (-((Double) objArr[1]).doubleValue())[2] = Double.valueOf(-((Double) objArr[2]).doubleValue());
        (-dDoubleValue)[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_B(r4);
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [double] */
    /* JADX WARN: Type inference failed for: r2v2, types: [double] */
    /* JADX WARN: Type inference failed for: r4v1, types: [double, java.lang.Object[], me.frep.vulcan.spigot.Vulcan_Oa] */
    public Vulcan_Oa Vulcan_G(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        ?? r1 = vulcan_Oa.Vulcan_v;
        ?? r4 = new Object[3];
        vulcan_Oa.Vulcan_I[2] = Double.valueOf(vulcan_Oa.Vulcan_h);
        r1[1] = Double.valueOf((double) r4);
        this[0] = Double.valueOf((double) r4);
        return r4.Vulcan_B(r4);
    }

    public Vulcan_Oa Vulcan_B(Object[] objArr) {
        return new Vulcan_Oa(this.Vulcan_v + ((Double) objArr[0]).doubleValue(), this.Vulcan_I + ((Double) objArr[1]).doubleValue(), this.Vulcan_h + ((Double) objArr[2]).doubleValue());
    }

    public double Vulcan_p(Object[] objArr) {
        Vulcan_Oa vulcan_Oa = (Vulcan_Oa) objArr[0];
        double d = vulcan_Oa.Vulcan_v - this.Vulcan_v;
        double d2 = vulcan_Oa.Vulcan_I - this.Vulcan_I;
        double d3 = vulcan_Oa.Vulcan_h - this.Vulcan_h;
        return (d * d) + (d2 * d2) + (d3 * d3);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_Oa Vulcan_O(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.Vulcan_O(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_Oa");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_Oa Vulcan_P(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 207
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.Vulcan_P(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_Oa");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public me.frep.vulcan.spigot.Vulcan_Oa Vulcan_D(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 203
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Oa.Vulcan_D(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_Oa");
    }

    public String toString() {
        StringBuilder sbAppend = new StringBuilder().append("(").append(this.Vulcan_v);
        String[] strArr = b;
        return sbAppend.append(strArr[4]).append(this.Vulcan_I).append(strArr[2]).append(this.Vulcan_h).append(")").toString();
    }

    public Vulcan_Oa Vulcan_S(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fVulcan_Q = Vulcan_Ov.Vulcan_Q(new Object[]{Float.valueOf(fFloatValue)});
        float fVulcan_G = Vulcan_Ov.Vulcan_G(new Object[]{Float.valueOf(fFloatValue)});
        return new Vulcan_Oa(this.Vulcan_v, (this.Vulcan_I * ((double) fVulcan_Q)) + (this.Vulcan_h * ((double) fVulcan_G)), (this.Vulcan_h * ((double) fVulcan_Q)) - (this.Vulcan_I * ((double) fVulcan_G)));
    }

    public Vulcan_Oa Vulcan_g(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fVulcan_Q = Vulcan_Ov.Vulcan_Q(new Object[]{Float.valueOf(fFloatValue)});
        float fVulcan_G = Vulcan_Ov.Vulcan_G(new Object[]{Float.valueOf(fFloatValue)});
        return new Vulcan_Oa((this.Vulcan_v * ((double) fVulcan_Q)) + (this.Vulcan_h * ((double) fVulcan_G)), this.Vulcan_I, (this.Vulcan_h * ((double) fVulcan_Q)) - (this.Vulcan_v * ((double) fVulcan_G)));
    }
}
