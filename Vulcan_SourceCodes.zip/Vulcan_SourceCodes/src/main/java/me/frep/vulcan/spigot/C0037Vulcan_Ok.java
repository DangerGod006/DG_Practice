package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Ok, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Ok.class */
public final class C0037Vulcan_Ok {
    private static final long a = Vulcan_n.a(4854335639080208691L, 6967197542832657940L, MethodHandles.lookup().lookupClass()).a(95550228441654L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 92307424259423L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[34];
        int i3 = 0;
        String str = "rÖoÑ\u009fø\u0019¸~\u0012Q\u0004\u0019Ü\u008dÒ\u0010¸\u000e0\u000fu±O\"w®¼Û\u0014`³\u0002\u0010CDXlv\u0016î\u000e\u0084æ`e\u0098É\u0095\u0097\u0010yÏs·ÏH\u00911\u0081Vá\u0018ÃgÃ\u0005\u0018îñöxÌ²J%}\u0007`§ª£êd²K\u0011Pe\r@Ü\u0010\u000b\u0005\u0007L~'ÐVç\u008e$Áz\u008e\u0015,\u0010T\u0010¾\u0087àXp`S\u0095\u0019§ZÞ\u0011g\b\u0005\u0007£ÑÞ\u0091\u008d\u0099\u0010:M32ó7´¨6$ý©Z9ð²\u0010zÝu`\u001f²Ä\u008f\"\u001axc\u0015ö\u0015\"\u0010Õ\u0086&\u0098\u007f±UõÌ\u0090*U6\u0086]\u0091\u0010è\u00910Û\u001fÃ->%\u0093Òï½d`?\u0010¸\u000e0\u000fu±O\"\u0084\u000b;Q\u0015í¨Ø\u0010îñöxÌ²J%\u0091©¸\u008cññ¾\u001a\u0010¸\u000e0\u000fu±O\"\u0080&´ã@¿\u0000~\u0010\u000bPÄÜ\\½\u009b\u0080þ\u0086á1W\u0015hj\u0010\u000bPÄÜ\\½\u009b\u0080E¾\u001cª`eØè\u0010\u0014=dZ\u001b\u0081\u0007\u009b\b\u0094ÕÂÅ\u009b6â\u0010Í\u0010ºLÀyç\u001fñÏ\u001f\u0018eÐf\u0006\bÕB\u001c\u0011÷0\"\u001f\u0010~D[åS¶\u008fàÏi\u008f°\u0099cú\u0092\u0010¯d\u0019ñÉ:I\u0012\u00016õ¸Ó²ýÝ\u0010CO\u0002Ô\u0093+XQÛ)+m´ôL\u0087\u0010¸\u000e0\u000fu±O\"'à\u000fYÒ\u0098\u009f\u0015\u0010\u007fnLÑÇ[Å\u00ad\rÙ×þ\u0017A²5\u0010\u0084Ã/\u0014íÆ\u0004#\u001e|§=$Ô£õ\u0010K\\ï\u001bî\u0013è\u0018È\u0080-\u0004Gð\u001cP\u0010\u009a\u0088$FF¤\u0097_É\\\u0015\u0019\u000fÅ+y\u0010{\u007f 6\u0000\u0011ó\u0088I\u0081OåZÆv\u008a8.¯li]\u000fÃp2Í\u008aìå\u0007OJÑ\b«8\u009e\u001d²Et~ðêÔ\u0001\u0003H`]ú\u009eým»ç?ê§\u0012\ræ\u0089B\u009a]\u0016\u0091Ô&\u001bÉ\u0010\u009a\u0088$FF¤\u0097_\u009a_\u001cbý7²z\u0018îñöxÌ²J%çq'\u000b\u008cË71a5xØ\u001dÞ\u0001²";
        int length = "rÖoÑ\u009fø\u0019¸~\u0012Q\u0004\u0019Ü\u008dÒ\u0010¸\u000e0\u000fu±O\"w®¼Û\u0014`³\u0002\u0010CDXlv\u0016î\u000e\u0084æ`e\u0098É\u0095\u0097\u0010yÏs·ÏH\u00911\u0081Vá\u0018ÃgÃ\u0005\u0018îñöxÌ²J%}\u0007`§ª£êd²K\u0011Pe\r@Ü\u0010\u000b\u0005\u0007L~'ÐVç\u008e$Áz\u008e\u0015,\u0010T\u0010¾\u0087àXp`S\u0095\u0019§ZÞ\u0011g\b\u0005\u0007£ÑÞ\u0091\u008d\u0099\u0010:M32ó7´¨6$ý©Z9ð²\u0010zÝu`\u001f²Ä\u008f\"\u001axc\u0015ö\u0015\"\u0010Õ\u0086&\u0098\u007f±UõÌ\u0090*U6\u0086]\u0091\u0010è\u00910Û\u001fÃ->%\u0093Òï½d`?\u0010¸\u000e0\u000fu±O\"\u0084\u000b;Q\u0015í¨Ø\u0010îñöxÌ²J%\u0091©¸\u008cññ¾\u001a\u0010¸\u000e0\u000fu±O\"\u0080&´ã@¿\u0000~\u0010\u000bPÄÜ\\½\u009b\u0080þ\u0086á1W\u0015hj\u0010\u000bPÄÜ\\½\u009b\u0080E¾\u001cª`eØè\u0010\u0014=dZ\u001b\u0081\u0007\u009b\b\u0094ÕÂÅ\u009b6â\u0010Í\u0010ºLÀyç\u001fñÏ\u001f\u0018eÐf\u0006\bÕB\u001c\u0011÷0\"\u001f\u0010~D[åS¶\u008fàÏi\u008f°\u0099cú\u0092\u0010¯d\u0019ñÉ:I\u0012\u00016õ¸Ó²ýÝ\u0010CO\u0002Ô\u0093+XQÛ)+m´ôL\u0087\u0010¸\u000e0\u000fu±O\"'à\u000fYÒ\u0098\u009f\u0015\u0010\u007fnLÑÇ[Å\u00ad\rÙ×þ\u0017A²5\u0010\u0084Ã/\u0014íÆ\u0004#\u001e|§=$Ô£õ\u0010K\\ï\u001bî\u0013è\u0018È\u0080-\u0004Gð\u001cP\u0010\u009a\u0088$FF¤\u0097_É\\\u0015\u0019\u000fÅ+y\u0010{\u007f 6\u0000\u0011ó\u0088I\u0081OåZÆv\u008a8.¯li]\u000fÃp2Í\u008aìå\u0007OJÑ\b«8\u009e\u001d²Et~ðêÔ\u0001\u0003H`]ú\u009eým»ç?ê§\u0012\ræ\u0089B\u009a]\u0016\u0091Ô&\u001bÉ\u0010\u009a\u0088$FF¤\u0097_\u009a_\u001cbý7²z\u0018îñöxÌ²J%çq'\u000b\u008cË71a5xØ\u001dÞ\u0001²".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "áÌ\u001f\u0088i\u009b0ÚùuÕ¿\u0013&Ú\u0082\u0010qfÃpb\u0085/¥·\u0019¾¶¨o\u000f\u001d";
                        length = "áÌ\u001f\u0088i\u009b0ÚùuÕ¿\u0013&Ú\u0082\u0010qfÃpb\u0085/¥·\u0019¾¶¨o\u000f\u001d".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private C0037Vulcan_Ok() {
        throw new UnsupportedOperationException(b[29]);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static long Vulcan_Q(java.lang.Object[] r14) {
        /*
            Method dump skipped, instruction units count: 466
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0037Vulcan_Ok.Vulcan_Q(java.lang.Object[]):long");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:447:0x07a0, code lost:
    
        if (r0 == 0) goto L448;
     */
    /* JADX WARN: Code restructure failed: missing block: B:451:0x07b3, code lost:
    
        if (r0 == 0) goto L452;
     */
    /* JADX WARN: Code restructure failed: missing block: B:455:0x07c6, code lost:
    
        if (r0 == 0) goto L456;
     */
    /* JADX WARN: Code restructure failed: missing block: B:459:0x07d9, code lost:
    
        if (r0 == 0) goto L460;
     */
    /* JADX WARN: Code restructure failed: missing block: B:463:0x07ec, code lost:
    
        if (r0 == 0) goto L464;
     */
    /* JADX WARN: Code restructure failed: missing block: B:468:0x07ff, code lost:
    
        if (r0 != 0) goto L474;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:451:0x07b3  */
    /* JADX WARN: Removed duplicated region for block: B:453:0x07c0 A[PHI: r0 r12
  0x07c0: PHI (r0v371 ??) = (r0v364 ??), (r0v415 ??) binds: [B:452:0x07b6, B:450:0x07b0] A[DONT_GENERATE, DONT_INLINE]
  0x07c0: PHI (r12v8 ??) = (r12v3 ??), (r12v14 ??) binds: [B:452:0x07b6, B:450:0x07b0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:455:0x07c6  */
    /* JADX WARN: Removed duplicated region for block: B:457:0x07d3 A[PHI: r0 r12
  0x07d3: PHI (r0v370 ??) = (r0v361 ??), (r0v416 ??) binds: [B:456:0x07c9, B:454:0x07c3] A[DONT_GENERATE, DONT_INLINE]
  0x07d3: PHI (r12v7 ??) = (r12v2 ??), (r12v15 ??) binds: [B:456:0x07c9, B:454:0x07c3] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:459:0x07d9  */
    /* JADX WARN: Removed duplicated region for block: B:461:0x07e6 A[PHI: r0 r12
  0x07e6: PHI (r0v369 ??) = (r0v358 ??), (r0v417 ??) binds: [B:460:0x07dc, B:458:0x07d6] A[DONT_GENERATE, DONT_INLINE]
  0x07e6: PHI (r12v6 ??) = (r12v1 ??), (r12v16 ??) binds: [B:460:0x07dc, B:458:0x07d6] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:463:0x07ec  */
    /* JADX WARN: Removed duplicated region for block: B:468:0x07ff A[PHI: r0 r12
  0x07ff: PHI (r0v368 ??) = (r0v355 ??), (r0v418 ??) binds: [B:467:0x07fd, B:462:0x07e9] A[DONT_GENERATE, DONT_INLINE]
  0x07ff: PHI (r12v5 ??) = (r12v0 ??), (r12v17 ??) binds: [B:467:0x07fd, B:462:0x07e9] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:477:0x05b1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x05b1: PHI (r0v331 ??) = (r0v14 ??), (r0v226 ??), (r0v227 ??) binds: [B:5:0x0034, B:341:0x05a9, B:343:0x05ae] A[DONT_GENERATE, DONT_INLINE]
  0x05b1: PHI (r14v59 char) = (r14v0 char), (r14v36 char), (r14v36 char) binds: [B:5:0x0034, B:341:0x05a9, B:343:0x05ae] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:479:0x0433 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0433: PHI (r0v320 ??) = (r0v14 ??), (r0v217 ??), (r0v218 ??) binds: [B:5:0x0034, B:229:0x042b, B:231:0x0430] A[DONT_GENERATE, DONT_INLINE]
  0x0433: PHI (r14v57 char) = (r14v0 char), (r14v34 char), (r14v34 char) binds: [B:5:0x0034, B:229:0x042b, B:231:0x0430] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:481:0x02b4 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x02b4: PHI (r0v309 ??) = (r0v14 ??), (r0v235 ??), (r0v236 ??) binds: [B:5:0x0034, B:117:0x02ac, B:119:0x02b1] A[DONT_GENERATE, DONT_INLINE]
  0x02b4: PHI (r14v55 char) = (r14v0 char), (r14v38 char), (r14v38 char) binds: [B:5:0x0034, B:117:0x02ac, B:119:0x02b1] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:485:0x0226 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0226: PHI (r0v300 ??) = (r0v14 ??), (r0v208 ??), (r0v209 ??) binds: [B:5:0x0034, B:75:0x021e, B:77:0x0223] A[DONT_GENERATE, DONT_INLINE]
  0x0226: PHI (r14v53 char) = (r14v0 char), (r14v32 char), (r14v32 char) binds: [B:5:0x0034, B:75:0x021e, B:77:0x0223] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:487:0x06a1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x06a1: PHI (r0v291 ??) = (r0v14 ??), (r0v199 ??), (r0v200 ??) binds: [B:5:0x0034, B:411:0x0699, B:413:0x069e] A[DONT_GENERATE, DONT_INLINE]
  0x06a1: PHI (r14v51 char) = (r14v0 char), (r14v30 char), (r14v30 char) binds: [B:5:0x0034, B:411:0x0699, B:413:0x069e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:489:0x0521 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0521: PHI (r0v282 ??) = (r0v14 ??), (r0v190 ??), (r0v191 ??) binds: [B:5:0x0034, B:299:0x0519, B:301:0x051e] A[DONT_GENERATE, DONT_INLINE]
  0x0521: PHI (r14v49 char) = (r14v0 char), (r14v28 char), (r14v28 char) binds: [B:5:0x0034, B:299:0x0519, B:301:0x051e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:491:0x03a3 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x03a3: PHI (r0v273 ??) = (r0v14 ??), (r0v181 ??), (r0v182 ??) binds: [B:5:0x0034, B:187:0x039b, B:189:0x03a0] A[DONT_GENERATE, DONT_INLINE]
  0x03a3: PHI (r14v47 char) = (r14v0 char), (r14v26 char), (r14v26 char) binds: [B:5:0x0034, B:187:0x039b, B:189:0x03a0] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:493:0x019a A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x019a: PHI (r0v264 ??) = (r0v14 ??), (r0v172 ??), (r0v173 ??) binds: [B:5:0x0034, B:33:0x0192, B:35:0x0197] A[DONT_GENERATE, DONT_INLINE]
  0x019a: PHI (r14v45 char) = (r14v0 char), (r14v24 char), (r14v24 char) binds: [B:5:0x0034, B:33:0x0192, B:35:0x0197] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:495:0x0611 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0611: PHI (r0v255 ??) = (r0v14 ??), (r0v163 ??), (r0v164 ??) binds: [B:5:0x0034, B:369:0x0609, B:371:0x060e] A[DONT_GENERATE, DONT_INLINE]
  0x0611: PHI (r14v43 char) = (r14v0 char), (r14v22 char), (r14v22 char) binds: [B:5:0x0034, B:369:0x0609, B:371:0x060e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:497:0x0492 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0492: PHI (r0v246 ??) = (r0v14 ??), (r0v154 ??), (r0v155 ??) binds: [B:5:0x0034, B:257:0x048a, B:259:0x048f] A[DONT_GENERATE, DONT_INLINE]
  0x0492: PHI (r14v41 char) = (r14v0 char), (r14v20 char), (r14v20 char) binds: [B:5:0x0034, B:257:0x048a, B:259:0x048f] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:499:0x0313 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0313: PHI (r0v237 ??) = (r0v14 ??), (r0v145 ??), (r0v146 ??) binds: [B:5:0x0034, B:145:0x030b, B:147:0x0310] A[DONT_GENERATE, DONT_INLINE]
  0x0313: PHI (r14v39 char) = (r14v0 char), (r14v18 char), (r14v18 char) binds: [B:5:0x0034, B:145:0x030b, B:147:0x0310] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:501:0x0285 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0285: PHI (r0v228 ??) = (r0v14 ??), (r0v136 ??), (r0v137 ??) binds: [B:5:0x0034, B:103:0x027d, B:105:0x0282] A[DONT_GENERATE, DONT_INLINE]
  0x0285: PHI (r14v37 char) = (r14v0 char), (r14v16 char), (r14v16 char) binds: [B:5:0x0034, B:103:0x027d, B:105:0x0282] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:503:0x0581 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0581: PHI (r0v219 ??) = (r0v14 ??), (r0v121 ??), (r0v122 ??) binds: [B:5:0x0034, B:327:0x0579, B:329:0x057e] A[DONT_GENERATE, DONT_INLINE]
  0x0581: PHI (r14v35 char) = (r14v0 char), (r14v12 char), (r14v12 char) binds: [B:5:0x0034, B:327:0x0579, B:329:0x057e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:505:0x0403 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0403: PHI (r0v210 ??) = (r0v14 ??), (r0v112 ??), (r0v113 ??) binds: [B:5:0x0034, B:215:0x03fb, B:217:0x0400] A[DONT_GENERATE, DONT_INLINE]
  0x0403: PHI (r14v33 char) = (r14v0 char), (r14v10 char), (r14v10 char) binds: [B:5:0x0034, B:215:0x03fb, B:217:0x0400] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:509:0x01f7 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x01f7: PHI (r0v201 ??) = (r0v14 ??), (r0v103 ??), (r0v104 ??) binds: [B:5:0x0034, B:61:0x01ef, B:63:0x01f4] A[DONT_GENERATE, DONT_INLINE]
  0x01f7: PHI (r14v31 char) = (r14v0 char), (r14v8 char), (r14v8 char) binds: [B:5:0x0034, B:61:0x01ef, B:63:0x01f4] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:511:0x0671 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0671: PHI (r0v192 ??) = (r0v14 ??), (r0v94 ??), (r0v95 ??) binds: [B:5:0x0034, B:397:0x0669, B:399:0x066e] A[DONT_GENERATE, DONT_INLINE]
  0x0671: PHI (r14v29 char) = (r14v0 char), (r14v6 char), (r14v6 char) binds: [B:5:0x0034, B:397:0x0669, B:399:0x066e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:513:0x04f1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x04f1: PHI (r0v183 ??) = (r0v14 ??), (r0v85 ??), (r0v86 ??) binds: [B:5:0x0034, B:285:0x04e9, B:287:0x04ee] A[DONT_GENERATE, DONT_INLINE]
  0x04f1: PHI (r14v27 char) = (r14v0 char), (r14v4 char), (r14v4 char) binds: [B:5:0x0034, B:285:0x04e9, B:287:0x04ee] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:515:0x0373 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0373: PHI (r0v174 ??) = (r0v14 ??), (r0v76 ??), (r0v77 ??) binds: [B:5:0x0034, B:173:0x036b, B:175:0x0370] A[DONT_GENERATE, DONT_INLINE]
  0x0373: PHI (r14v25 char) = (r14v0 char), (r14v2 char), (r14v2 char) binds: [B:5:0x0034, B:173:0x036b, B:175:0x0370] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:517:0x016b A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x016b: PHI (r0v165 ??) = (r0v14 ??), (r0v347 ??), (r0v348 ??) binds: [B:5:0x0034, B:19:0x0163, B:21:0x0168] A[DONT_GENERATE, DONT_INLINE]
  0x016b: PHI (r14v23 char) = (r14v0 char), (r14v62 char), (r14v62 char) binds: [B:5:0x0034, B:19:0x0163, B:21:0x0168] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:519:0x05e1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x05e1: PHI (r0v156 ??) = (r0v14 ??), (r0v340 ??), (r0v341 ??) binds: [B:5:0x0034, B:355:0x05d9, B:357:0x05de] A[DONT_GENERATE, DONT_INLINE]
  0x05e1: PHI (r14v21 char) = (r14v0 char), (r14v60 char), (r14v60 char) binds: [B:5:0x0034, B:355:0x05d9, B:357:0x05de] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:521:0x0463 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0463: PHI (r0v147 ??) = (r0v14 ??), (r0v329 ??), (r0v330 ??) binds: [B:5:0x0034, B:243:0x045b, B:245:0x0460] A[DONT_GENERATE, DONT_INLINE]
  0x0463: PHI (r14v19 char) = (r14v0 char), (r14v58 char), (r14v58 char) binds: [B:5:0x0034, B:243:0x045b, B:245:0x0460] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:523:0x02e3 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x02e3: PHI (r0v138 ??) = (r0v14 ??), (r0v318 ??), (r0v319 ??) binds: [B:5:0x0034, B:131:0x02db, B:133:0x02e0] A[DONT_GENERATE, DONT_INLINE]
  0x02e3: PHI (r14v17 char) = (r14v0 char), (r14v56 char), (r14v56 char) binds: [B:5:0x0034, B:131:0x02db, B:133:0x02e0] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:525:0x0255 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0255: PHI (r0v129 ??) = (r0v14 ??), (r0v307 ??), (r0v308 ??) binds: [B:5:0x0034, B:89:0x024d, B:91:0x0252] A[DONT_GENERATE, DONT_INLINE]
  0x0255: PHI (r14v15 char) = (r14v0 char), (r14v54 char), (r14v54 char) binds: [B:5:0x0034, B:89:0x024d, B:91:0x0252] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:527:0x06d1 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x06d1: PHI (r0v123 ??) = (r0v14 ??), (r0v298 ??), (r0v299 ??) binds: [B:5:0x0034, B:425:0x06c9, B:427:0x06ce] A[DONT_GENERATE, DONT_INLINE]
  0x06d1: PHI (r14v13 char) = (r14v0 char), (r14v52 char), (r14v52 char) binds: [B:5:0x0034, B:425:0x06c9, B:427:0x06ce] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:529:0x0551 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0551: PHI (r0v114 ??) = (r0v14 ??), (r0v289 ??), (r0v290 ??) binds: [B:5:0x0034, B:313:0x0549, B:315:0x054e] A[DONT_GENERATE, DONT_INLINE]
  0x0551: PHI (r14v11 char) = (r14v0 char), (r14v50 char), (r14v50 char) binds: [B:5:0x0034, B:313:0x0549, B:315:0x054e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:531:0x03d3 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x03d3: PHI (r0v105 ??) = (r0v14 ??), (r0v280 ??), (r0v281 ??) binds: [B:5:0x0034, B:201:0x03cb, B:203:0x03d0] A[DONT_GENERATE, DONT_INLINE]
  0x03d3: PHI (r14v9 char) = (r14v0 char), (r14v48 char), (r14v48 char) binds: [B:5:0x0034, B:201:0x03cb, B:203:0x03d0] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:533:0x01c9 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x01c9: PHI (r0v96 ??) = (r0v14 ??), (r0v271 ??), (r0v272 ??) binds: [B:5:0x0034, B:47:0x01c1, B:49:0x01c6] A[DONT_GENERATE, DONT_INLINE]
  0x01c9: PHI (r14v7 char) = (r14v0 char), (r14v46 char), (r14v46 char) binds: [B:5:0x0034, B:47:0x01c1, B:49:0x01c6] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:535:0x0641 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0641: PHI (r0v87 ??) = (r0v14 ??), (r0v262 ??), (r0v263 ??) binds: [B:5:0x0034, B:383:0x0639, B:385:0x063e] A[DONT_GENERATE, DONT_INLINE]
  0x0641: PHI (r14v5 char) = (r14v0 char), (r14v44 char), (r14v44 char) binds: [B:5:0x0034, B:383:0x0639, B:385:0x063e] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:537:0x04c2 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x04c2: PHI (r0v78 ??) = (r0v14 ??), (r0v253 ??), (r0v254 ??) binds: [B:5:0x0034, B:271:0x04ba, B:273:0x04bf] A[DONT_GENERATE, DONT_INLINE]
  0x04c2: PHI (r14v3 char) = (r14v0 char), (r14v42 char), (r14v42 char) binds: [B:5:0x0034, B:271:0x04ba, B:273:0x04bf] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:539:0x0343 A[EXC_TOP_SPLITTER, PHI: r0 r14
  0x0343: PHI (r0v69 ??) = (r0v14 ??), (r0v244 ??), (r0v245 ??) binds: [B:5:0x0034, B:159:0x033b, B:161:0x0340] A[DONT_GENERATE, DONT_INLINE]
  0x0343: PHI (r14v1 char) = (r14v0 char), (r14v40 char), (r14v40 char) binds: [B:5:0x0034, B:159:0x033b, B:161:0x0340] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v100, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v103, types: [int] */
    /* JADX WARN: Type inference failed for: r0v104 */
    /* JADX WARN: Type inference failed for: r0v105 */
    /* JADX WARN: Type inference failed for: r0v106, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v109, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v112, types: [int] */
    /* JADX WARN: Type inference failed for: r0v113 */
    /* JADX WARN: Type inference failed for: r0v114 */
    /* JADX WARN: Type inference failed for: r0v115, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v118, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v121, types: [int] */
    /* JADX WARN: Type inference failed for: r0v122 */
    /* JADX WARN: Type inference failed for: r0v123 */
    /* JADX WARN: Type inference failed for: r0v124, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v127, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v129 */
    /* JADX WARN: Type inference failed for: r0v130, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v133, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v136, types: [int] */
    /* JADX WARN: Type inference failed for: r0v137 */
    /* JADX WARN: Type inference failed for: r0v138 */
    /* JADX WARN: Type inference failed for: r0v139, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v142, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v145, types: [int] */
    /* JADX WARN: Type inference failed for: r0v146 */
    /* JADX WARN: Type inference failed for: r0v147 */
    /* JADX WARN: Type inference failed for: r0v148, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v151, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v154, types: [int] */
    /* JADX WARN: Type inference failed for: r0v155 */
    /* JADX WARN: Type inference failed for: r0v156 */
    /* JADX WARN: Type inference failed for: r0v157, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v160, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v163, types: [int] */
    /* JADX WARN: Type inference failed for: r0v164 */
    /* JADX WARN: Type inference failed for: r0v165 */
    /* JADX WARN: Type inference failed for: r0v166, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v169, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v172, types: [int] */
    /* JADX WARN: Type inference failed for: r0v173 */
    /* JADX WARN: Type inference failed for: r0v174 */
    /* JADX WARN: Type inference failed for: r0v175, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v178, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v181, types: [int] */
    /* JADX WARN: Type inference failed for: r0v182 */
    /* JADX WARN: Type inference failed for: r0v183 */
    /* JADX WARN: Type inference failed for: r0v184, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v187, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v190, types: [int] */
    /* JADX WARN: Type inference failed for: r0v191 */
    /* JADX WARN: Type inference failed for: r0v192 */
    /* JADX WARN: Type inference failed for: r0v193, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v196, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v199, types: [int] */
    /* JADX WARN: Type inference failed for: r0v200 */
    /* JADX WARN: Type inference failed for: r0v201 */
    /* JADX WARN: Type inference failed for: r0v202, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v205, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v208, types: [int] */
    /* JADX WARN: Type inference failed for: r0v209 */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v210 */
    /* JADX WARN: Type inference failed for: r0v211, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v214, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v217, types: [int] */
    /* JADX WARN: Type inference failed for: r0v218 */
    /* JADX WARN: Type inference failed for: r0v219 */
    /* JADX WARN: Type inference failed for: r0v220, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v223, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v226, types: [int] */
    /* JADX WARN: Type inference failed for: r0v227 */
    /* JADX WARN: Type inference failed for: r0v228 */
    /* JADX WARN: Type inference failed for: r0v229, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v232, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v235, types: [int] */
    /* JADX WARN: Type inference failed for: r0v236 */
    /* JADX WARN: Type inference failed for: r0v237 */
    /* JADX WARN: Type inference failed for: r0v238, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v241, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v244, types: [int] */
    /* JADX WARN: Type inference failed for: r0v245 */
    /* JADX WARN: Type inference failed for: r0v246 */
    /* JADX WARN: Type inference failed for: r0v247, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v250, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v253, types: [int] */
    /* JADX WARN: Type inference failed for: r0v254 */
    /* JADX WARN: Type inference failed for: r0v255 */
    /* JADX WARN: Type inference failed for: r0v256, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v259, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v262, types: [int] */
    /* JADX WARN: Type inference failed for: r0v263 */
    /* JADX WARN: Type inference failed for: r0v264 */
    /* JADX WARN: Type inference failed for: r0v265, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v268, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v271, types: [int] */
    /* JADX WARN: Type inference failed for: r0v272 */
    /* JADX WARN: Type inference failed for: r0v273 */
    /* JADX WARN: Type inference failed for: r0v274, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v277, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v280, types: [int] */
    /* JADX WARN: Type inference failed for: r0v281 */
    /* JADX WARN: Type inference failed for: r0v282 */
    /* JADX WARN: Type inference failed for: r0v283, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v286, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v289, types: [int] */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v290 */
    /* JADX WARN: Type inference failed for: r0v291 */
    /* JADX WARN: Type inference failed for: r0v292, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v295, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v298, types: [int] */
    /* JADX WARN: Type inference failed for: r0v299 */
    /* JADX WARN: Type inference failed for: r0v300 */
    /* JADX WARN: Type inference failed for: r0v301, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v304, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v307, types: [int] */
    /* JADX WARN: Type inference failed for: r0v308 */
    /* JADX WARN: Type inference failed for: r0v309 */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v310, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v312, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v313, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v315, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v318, types: [int] */
    /* JADX WARN: Type inference failed for: r0v319 */
    /* JADX WARN: Type inference failed for: r0v320 */
    /* JADX WARN: Type inference failed for: r0v321, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v323, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v324, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v326, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v329, types: [int] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v330 */
    /* JADX WARN: Type inference failed for: r0v331 */
    /* JADX WARN: Type inference failed for: r0v332, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v334, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v335, types: [java.lang.Throwable, java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v337, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v340, types: [int] */
    /* JADX WARN: Type inference failed for: r0v341 */
    /* JADX WARN: Type inference failed for: r0v342 */
    /* JADX WARN: Type inference failed for: r0v347, types: [int] */
    /* JADX WARN: Type inference failed for: r0v348 */
    /* JADX WARN: Type inference failed for: r0v349, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v351 */
    /* JADX WARN: Type inference failed for: r0v352 */
    /* JADX WARN: Type inference failed for: r0v355 */
    /* JADX WARN: Type inference failed for: r0v358 */
    /* JADX WARN: Type inference failed for: r0v361 */
    /* JADX WARN: Type inference failed for: r0v364 */
    /* JADX WARN: Type inference failed for: r0v367 */
    /* JADX WARN: Type inference failed for: r0v368 */
    /* JADX WARN: Type inference failed for: r0v369 */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v370 */
    /* JADX WARN: Type inference failed for: r0v371 */
    /* JADX WARN: Type inference failed for: r0v372 */
    /* JADX WARN: Type inference failed for: r0v375 */
    /* JADX WARN: Type inference failed for: r0v376 */
    /* JADX WARN: Type inference failed for: r0v377 */
    /* JADX WARN: Type inference failed for: r0v378 */
    /* JADX WARN: Type inference failed for: r0v380 */
    /* JADX WARN: Type inference failed for: r0v381 */
    /* JADX WARN: Type inference failed for: r0v382 */
    /* JADX WARN: Type inference failed for: r0v383 */
    /* JADX WARN: Type inference failed for: r0v384 */
    /* JADX WARN: Type inference failed for: r0v385 */
    /* JADX WARN: Type inference failed for: r0v386 */
    /* JADX WARN: Type inference failed for: r0v387 */
    /* JADX WARN: Type inference failed for: r0v388 */
    /* JADX WARN: Type inference failed for: r0v389 */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v390 */
    /* JADX WARN: Type inference failed for: r0v391 */
    /* JADX WARN: Type inference failed for: r0v392 */
    /* JADX WARN: Type inference failed for: r0v393 */
    /* JADX WARN: Type inference failed for: r0v394 */
    /* JADX WARN: Type inference failed for: r0v395 */
    /* JADX WARN: Type inference failed for: r0v396 */
    /* JADX WARN: Type inference failed for: r0v397 */
    /* JADX WARN: Type inference failed for: r0v398 */
    /* JADX WARN: Type inference failed for: r0v399 */
    /* JADX WARN: Type inference failed for: r0v400 */
    /* JADX WARN: Type inference failed for: r0v401 */
    /* JADX WARN: Type inference failed for: r0v402 */
    /* JADX WARN: Type inference failed for: r0v403 */
    /* JADX WARN: Type inference failed for: r0v404 */
    /* JADX WARN: Type inference failed for: r0v405 */
    /* JADX WARN: Type inference failed for: r0v406 */
    /* JADX WARN: Type inference failed for: r0v407 */
    /* JADX WARN: Type inference failed for: r0v408 */
    /* JADX WARN: Type inference failed for: r0v409 */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v410 */
    /* JADX WARN: Type inference failed for: r0v411 */
    /* JADX WARN: Type inference failed for: r0v412 */
    /* JADX WARN: Type inference failed for: r0v413 */
    /* JADX WARN: Type inference failed for: r0v414 */
    /* JADX WARN: Type inference failed for: r0v415 */
    /* JADX WARN: Type inference failed for: r0v416 */
    /* JADX WARN: Type inference failed for: r0v417 */
    /* JADX WARN: Type inference failed for: r0v418 */
    /* JADX WARN: Type inference failed for: r0v419 */
    /* JADX WARN: Type inference failed for: r0v43, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v45, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v47, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v49, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v55, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v57, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v59, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v61, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v63, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v65, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v67, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v70, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v73, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v76, types: [int] */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v78 */
    /* JADX WARN: Type inference failed for: r0v79, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v82, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v85, types: [int] */
    /* JADX WARN: Type inference failed for: r0v86 */
    /* JADX WARN: Type inference failed for: r0v87 */
    /* JADX WARN: Type inference failed for: r0v88, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v91, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v94, types: [int] */
    /* JADX WARN: Type inference failed for: r0v95 */
    /* JADX WARN: Type inference failed for: r0v96 */
    /* JADX WARN: Type inference failed for: r0v97, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r12v0 */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v10 */
    /* JADX WARN: Type inference failed for: r12v11 */
    /* JADX WARN: Type inference failed for: r12v12 */
    /* JADX WARN: Type inference failed for: r12v13 */
    /* JADX WARN: Type inference failed for: r12v14 */
    /* JADX WARN: Type inference failed for: r12v15 */
    /* JADX WARN: Type inference failed for: r12v16 */
    /* JADX WARN: Type inference failed for: r12v17 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4 */
    /* JADX WARN: Type inference failed for: r12v5 */
    /* JADX WARN: Type inference failed for: r12v6 */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r12v8 */
    /* JADX WARN: Type inference failed for: r12v9 */
    /* JADX WARN: Type inference failed for: r1v133 */
    /* JADX WARN: Type inference failed for: r1v146 */
    /* JADX WARN: Type inference failed for: r1v147 */
    /* JADX WARN: Type inference failed for: r1v36 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static int Vulcan_J(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 2063
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0037Vulcan_Ok.Vulcan_J(java.lang.Object[]):int");
    }
}
