package me.frep.vulcan.spigot.check;

import com.github.retrooper.packetevents.event.PacketEvent;
import com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent;
import com.github.retrooper.packetevents.event.simple.PacketPlaySendEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import java.lang.invoke.MethodHandles;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.api.check.Check;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.C0043Vulcan_e;
import me.frep.vulcan.spigot.C0050Vulcan_k;
import me.frep.vulcan.spigot.Vulcan_OB;
import me.frep.vulcan.spigot.Vulcan_OM;
import me.frep.vulcan.spigot.Vulcan_fe;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.Vulcan_r;
import me.frep.vulcan.spigot.Vulcan_yU;
import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.StringUtils;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/AbstractCheck.class */
public abstract class AbstractCheck implements Check {
    protected final C0042Vulcan_Oz Vulcan_b;
    private int Vulcan_H;
    private double Vulcan_q;
    public final String Vulcan_z;
    public final double Vulcan_c;
    public final double Vulcan_Y;
    public final double Vulcan_e;
    private static AbstractCheck[] Vulcan_Q;
    private static final long a = Vulcan_n.a(-4133645244899447386L, -1997017403234553774L, MethodHandles.lookup().lookupClass()).a(146702622123868L);
    private static final String[] c;

    public abstract void Vulcan_T(Object[] objArr);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0078: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public me.frep.vulcan.spigot.check.api.CheckInfo Vulcan_i(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 71577022536645(0x411953009bc5, double:3.5363747866961E-310)
            long r1 = r1 ^ r2
            r11 = r1
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r13 = r0
            r0 = r13
            if (r0 == 0) goto L84
            r0 = r7
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.RuntimeException -> L35 java.lang.RuntimeException -> L47
            java.lang.Class<me.frep.vulcan.spigot.check.api.CheckInfo> r1 = me.frep.vulcan.spigot.check.api.CheckInfo.class
            boolean r0 = r0.isAnnotationPresent(r1)     // Catch: java.lang.RuntimeException -> L35 java.lang.RuntimeException -> L47
            if (r0 == 0) goto L4b
            goto L39
        L35:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L47
            throw r0     // Catch: java.lang.RuntimeException -> L47
        L39:
            r0 = r7
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.RuntimeException -> L47
            java.lang.Class<me.frep.vulcan.spigot.check.api.CheckInfo> r1 = me.frep.vulcan.spigot.check.api.CheckInfo.class
            java.lang.annotation.Annotation r0 = r0.getAnnotation(r1)     // Catch: java.lang.RuntimeException -> L47
            me.frep.vulcan.spigot.check.api.CheckInfo r0 = (me.frep.vulcan.spigot.check.api.CheckInfo) r0     // Catch: java.lang.RuntimeException -> L47
            return r0
        L47:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L47
            throw r0
        L4b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r1 = r0
            r1.<init>()
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.AbstractCheck.c
            r2 = 7
            r1 = r1[r2]
            java.lang.StringBuilder r0 = r0.append(r1)
            r1 = r7
            java.lang.String r1 = r1.Vulcan_z
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r1 = "."
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
            r1 = r11
            r2 = r1; r1 = r0; r0 = r2; 
            r1 = 2
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r2; 
            r3 = r1; r1 = r2; r2 = r3; 
            r3 = 1
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            r1 = r0; r0 = r-1; r-1 = r-2; r-2 = r1; 
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            r2 = 0
            r3 = r1; r1 = r2; r2 = r3; 
            r0[r1] = r2
            me.frep.vulcan.spigot.Vulcan_OM.Vulcan_k(r-1)
        L84:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_i(java.lang.Object[]):me.frep.vulcan.spigot.check.api.CheckInfo");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00e5: MOVE_MULTI (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r-2 I:??), (r-2 I:??), (r1 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public void m1114Vulcan_S(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 242
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.m1114Vulcan_S(java.lang.Object[]):void");
    }

    public abstract void Vulcan_a(Object[] objArr);

    public static void Vulcan_D(AbstractCheck[] abstractCheckArr) {
        Vulcan_Q = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_k() {
        return Vulcan_Q;
    }

    static {
        int i;
        long j = a ^ 11519693893992L;
        Vulcan_D((AbstractCheck[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[9];
        int i3 = 0;
        String str = "\u0010¾ÁR^{·(\u0010\u0001\"\u007f\u0005Ï\u009dVÙÖe×hÆ%|ý\b×¥\u008bH¶\u008a·\u001c\u0010\u0001\"\u007f\u0005Ï\u009dVÙÖe×hÆ%|ý\u0018ÏC\u0097\u0090ã®\u0098\u0096;µ\u0098+[§>v\u0004\u0094S\"ðäv\u0010\b\u0010¾ÁR^{·(\b×¥\u008bH¶\u008a·\u001c";
        int length = "\u0010¾ÁR^{·(\u0010\u0001\"\u007f\u0005Ï\u009dVÙÖe×hÆ%|ý\b×¥\u008bH¶\u008a·\u001c\u0010\u0001\"\u007f\u0005Ï\u009dVÙÖe×hÆ%|ý\u0018ÏC\u0097\u0090ã®\u0098\u0096;µ\u0098+[§>v\u0004\u0094S\"ðäv\u0010\b\u0010¾ÁR^{·(\b×¥\u008bH¶\u008a·\u001c".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b = -1;
            while (true) {
                String str2 = strSubstring;
                byte b2 = b;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b2) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            c = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u0087PS\u009f\u0088\u0096\u001d\n\r¬®ê7Hð¸5\u000bAãCöI\u0001v\u001eê\u009d\t1pè\tôÜô\u0007æm¯t®ÛVÓ¤½7\u001b´×è©j\u0088¿\u0018ÏC\u0097\u0090ã®\u0098\u0096;µ\u0098+[§>v\u0004\u0094S\"ðäv\u0010";
                        length = "\u0087PS\u009f\u0088\u0096\u001d\n\r¬®ê7Hð¸5\u000bAãCöI\u0001v\u001eê\u009d\t1pè\tôÜô\u0007æm¯t®ÛVÓ¤½7\u001b´×è©j\u0088¿\u0018ÏC\u0097\u0090ã®\u0098\u0096;µ\u0098+[§>v\u0004\u0094S\"ðäv\u0010".length();
                        cCharAt = '8';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException b(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c2 = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c2 | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public C0042Vulcan_Oz m1119Vulcan_R(Object[] objArr) {
        return this.Vulcan_b;
    }

    @Override // me.frep.vulcan.api.check.Check
    public void setVl(int i) {
        this.Vulcan_H = i;
    }

    @Override // me.frep.vulcan.api.check.Check
    public void setBuffer(double d) {
        this.Vulcan_q = d;
    }

    @Override // me.frep.vulcan.api.check.Check
    public double getBuffer() {
        return this.Vulcan_q;
    }

    public String Vulcan_D(Object[] objArr) {
        return this.Vulcan_z;
    }

    /* JADX INFO: renamed from: Vulcan_t, reason: collision with other method in class */
    public double m1120Vulcan_t(Object[] objArr) {
        return this.Vulcan_c;
    }

    public double Vulcan_x(Object[] objArr) {
        return this.Vulcan_Y;
    }

    /* JADX INFO: renamed from: Vulcan_R, reason: collision with other method in class */
    public double m1121Vulcan_R(Object[] objArr) {
        return this.Vulcan_e;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    public AbstractCheck(C0042Vulcan_Oz c0042Vulcan_Oz) {
        long j = a ^ 126742054381364L;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            this.Vulcan_z = getClass().getSimpleName();
            this.Vulcan_c = ((Integer) Vulcan_fe.Vulcan_s1.get(this.Vulcan_z)).intValue();
            this.Vulcan_Y = ((Double) Vulcan_fe.Vulcan_vm.get(this.Vulcan_z)).doubleValue();
            this.Vulcan_e = ((Double) Vulcan_fe.Vulcan_tl.get(this.Vulcan_z)).doubleValue();
            this.Vulcan_b = c0042Vulcan_Oz;
            if (Vulcan_G == 0) {
                Vulcan_G = new AbstractCheck[3];
                Vulcan_D((AbstractCheck[]) Vulcan_G);
            }
        } catch (RuntimeException unused) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x0129, code lost:
    
        if (r0 == 0) goto L55;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00b1 A[Catch: RuntimeException -> 0x00c2, RuntimeException -> 0x00cc, TRY_ENTER, TryCatch #2 {RuntimeException -> 0x00c2, blocks: (B:28:0x0098, B:29:0x00a8, B:31:0x00b1), top: B:77:0x0098, outer: #7 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0175 A[PHI: r0
  0x0175: PHI (r0v26 ??) = (r0v77 ??), (r0v78 ??), (r0v79 ??) binds: [B:33:0x00b7, B:35:0x00bc, B:61:0x013f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0178 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v38, types: [me.frep.vulcan.api.event.VulcanSetbackEvent, org.bukkit.event.Event] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v52, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v58, types: [me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r0v74 */
    /* JADX WARN: Type inference failed for: r0v75 */
    /* JADX WARN: Type inference failed for: r0v76 */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v78 */
    /* JADX WARN: Type inference failed for: r0v79 */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v81 */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v18 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v30 */
    /* JADX WARN: Type inference failed for: r1v52, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v57 */
    /* JADX WARN: Type inference failed for: r1v58 */
    /* JADX WARN: Type inference failed for: r1v66 */
    /* JADX WARN: Type inference failed for: r1v67 */
    /* JADX WARN: Type inference failed for: r1v68 */
    /* JADX WARN: Type inference failed for: r2v30, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r2v34, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_Q(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 490
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_Q(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    private void lambda$fail$0(Object obj) {
        long j = (a ^ 136801970731243L) ^ 85742610164129L;
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        ?? r2 = this.Vulcan_b;
        Object[] objArr = new Object[4];
        objArr[3] = Objects.toString(obj);
        r2[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = this;
        vulcan_OBVulcan_e.Vulcan_N(objArr);
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x0122, code lost:
    
        if (r0 == 0) goto L55;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00aa A[Catch: RuntimeException -> 0x00bb, RuntimeException -> 0x00c5, TRY_ENTER, TryCatch #8 {RuntimeException -> 0x00bb, blocks: (B:28:0x0091, B:29:0x00a1, B:31:0x00aa), top: B:83:0x0091, outer: #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x016f A[PHI: r0
  0x016f: PHI (r0v26 ??) = (r0v75 ??), (r0v76 ??), (r0v77 ??) binds: [B:33:0x00b0, B:35:0x00b5, B:61:0x0138] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0172 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v38, types: [me.frep.vulcan.api.event.VulcanSetbackEvent, org.bukkit.event.Event] */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v52, types: [me.frep.vulcan.spigot.Vulcan_ka] */
    /* JADX WARN: Type inference failed for: r0v58, types: [me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v63 */
    /* JADX WARN: Type inference failed for: r0v65, types: [int] */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r0v72 */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r0v74 */
    /* JADX WARN: Type inference failed for: r0v75 */
    /* JADX WARN: Type inference failed for: r0v76 */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v9, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v49, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r1v54 */
    /* JADX WARN: Type inference failed for: r1v55 */
    /* JADX WARN: Type inference failed for: r1v59, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v63 */
    /* JADX WARN: Type inference failed for: r2v29, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r2v33, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_K(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 483
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_K(java.lang.Object[]):void");
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    private void lambda$fail$1() {
        long j = (a ^ 115559681216749L) ^ 97349270716839L;
        Vulcan_OB vulcan_OBVulcan_e = Vulcan_r.INSTANCE.Vulcan_e();
        ?? r2 = this.Vulcan_b;
        Object[] objArr = new Object[4];
        objArr[3] = "";
        r2[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = this;
        vulcan_OBVulcan_e.Vulcan_N(objArr);
    }

    public void Vulcan_e(Object[] objArr) {
        Vulcan_r.INSTANCE.Vulcan_Y().execute(this::lambda$punish$2);
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [me.frep.vulcan.spigot.Vulcan_Oz] */
    private void lambda$punish$2() {
        long j = (a ^ 70468543398388L) ^ 32044462477710L;
        C0043Vulcan_e c0043Vulcan_eVulcan_S = Vulcan_r.INSTANCE.Vulcan_S();
        Object[] objArr = new Object[3];
        this.Vulcan_b[2] = Long.valueOf(j);
        objArr[1] = objArr;
        objArr[0] = this;
        c0043Vulcan_eVulcan_S.Vulcan_f(objArr);
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [me.frep.vulcan.spigot.Vulcan_yv] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_yv] */
    protected boolean Vulcan_t(Object[] objArr) {
        Vulcan_yU[] vulcan_yUArr = (Vulcan_yU[]) objArr[0];
        long jLongValue = (a ^ ((Long) objArr[1]).longValue()) ^ 124243282939378L;
        ?? Vulcan_C = this.Vulcan_b.Vulcan_C(new Object[0]);
        ?? r3 = new Object[2];
        r3[1] = vulcan_yUArr;
        Vulcan_C[0] = Long.valueOf(jLongValue);
        return r3.Vulcan_L(r3);
    }

    public int Vulcan_S(Object[] objArr) {
        return Vulcan_r.INSTANCE.Vulcan_N().Vulcan_P(new Object[0]);
    }

    public double Vulcan_N(Object[] objArr) {
        double dMin = Math.min(10000.0d, this.Vulcan_q + 1.0d);
        this.Vulcan_q = dMin;
        return dMin;
    }

    public double Vulcan_G(Object[] objArr) {
        double dMax = Math.max(0.0d, this.Vulcan_q - ((Double) objArr[0]).doubleValue());
        this.Vulcan_q = dMax;
        return dMax;
    }

    public double Vulcan_u(Object[] objArr) {
        double dMin = Math.min(10000.0d, this.Vulcan_q + ((Double) objArr[0]).doubleValue());
        this.Vulcan_q = dMin;
        return dMin;
    }

    public void Vulcan_o(Object[] objArr) {
        this.Vulcan_q = 0.0d;
    }

    public void Vulcan_E(Object[] objArr) {
        this.Vulcan_q *= ((Double) objArr[0]).doubleValue();
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public void m1112Vulcan_G(Object[] objArr) {
        ?? r2 = new Object[1];
        this[0] = Double.valueOf(this.Vulcan_Y);
        r2.Vulcan_G(r2);
    }

    public int Vulcan_s(Object[] objArr) {
        return this.Vulcan_b.m636Vulcan_T(new Object[0]).Vulcan_D(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x006f A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX INFO: renamed from: Vulcan_u, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m1113Vulcan_u(java.lang.Object[] r6) {
        /*
            r5 = this;
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r10 = r0
            r0 = r5
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_b     // Catch: java.lang.RuntimeException -> L3f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3f
            me.frep.vulcan.spigot.Vulcan_Oc r0 = r0.m636Vulcan_T(r1)     // Catch: java.lang.RuntimeException -> L3f
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L3f
            int r0 = r0.Vulcan_D(r1)     // Catch: java.lang.RuntimeException -> L3f
            r1 = r7
            r2 = r10
            if (r2 == 0) goto L6c
            if (r0 >= r1) goto L73
            goto L43
        L3f:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L5d
            throw r0     // Catch: java.lang.RuntimeException -> L5d
        L43:
            r0 = r5
            me.frep.vulcan.spigot.Vulcan_Oz r0 = r0.Vulcan_b     // Catch: java.lang.RuntimeException -> L5d java.lang.RuntimeException -> L68
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5d java.lang.RuntimeException -> L68
            me.frep.vulcan.spigot.Vulcan_Oc r0 = r0.m636Vulcan_T(r1)     // Catch: java.lang.RuntimeException -> L5d java.lang.RuntimeException -> L68
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.RuntimeException -> L5d java.lang.RuntimeException -> L68
            int r0 = r0.Vulcan_i(r1)     // Catch: java.lang.RuntimeException -> L5d java.lang.RuntimeException -> L68
            r1 = r10
            if (r1 == 0) goto L70
            goto L61
        L5d:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L68
            throw r0     // Catch: java.lang.RuntimeException -> L68
        L61:
            r1 = r7
            r2 = 6
            int r1 = r1 * r2
            goto L6c
        L68:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L6c:
            if (r0 >= r1) goto L73
            r0 = 1
        L70:
            goto L74
        L73:
            r0 = 0
        L74:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.m1113Vulcan_u(java.lang.Object[]):boolean");
    }

    public void Vulcan_H(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        Object obj = objArr[1];
        long j = a ^ jLongValue;
        long j2 = j ^ 75794221926587L;
        Vulcan_OM.Vulcan_x(new Object[]{Integer.valueOf((int) (j >>> 32)), obj, Integer.valueOf((char) ((j2 << 32) >>> 48)), Integer.valueOf((short) ((j2 << 48) >>> 48))});
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x003a, code lost:
    
        if (r0 == 0) goto L45;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0057  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0092 A[PHI: r0 r9
  0x0092: PHI (r0v10 ??) = (r0v47 ??), (r0v48 ??) binds: [B:16:0x0054, B:29:0x0082] A[DONT_GENERATE, DONT_INLINE]
  0x0092: PHI (r9v2 java.lang.String) = (r9v1 java.lang.String), (r9v4 java.lang.String) binds: [B:16:0x0054, B:29:0x0082] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0095  */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26, types: [java.lang.RuntimeException, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42 */
    /* JADX WARN: Type inference failed for: r0v43 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.api.check.Check
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String getCategory() {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = 18703014086665(0x1102a282c809, double:9.240516733906E-311)
            long r0 = r0 ^ r1
            r6 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            java.lang.String r1 = ""
            r9 = r1
            r8 = r0
            r0 = r5
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.RuntimeException -> L2a
            java.lang.String r0 = r0.getName()     // Catch: java.lang.RuntimeException -> L2a
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.AbstractCheck.c     // Catch: java.lang.RuntimeException -> L2a
            r2 = 5
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L2a
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L2a
            r1 = r8
            if (r1 == 0) goto L53
            if (r0 == 0) goto L3d
            goto L2e
        L2a:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L2e:
            java.lang.String[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.c
            r10 = r0
            r0 = r10
            r1 = 0
            r0 = r0[r1]
            r9 = r0
            r0 = r8
            if (r0 != 0) goto L9c
        L3d:
            r0 = r5
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.RuntimeException -> L4f
            java.lang.String r0 = r0.getName()     // Catch: java.lang.RuntimeException -> L4f
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.AbstractCheck.c     // Catch: java.lang.RuntimeException -> L4f
            r2 = 3
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L4f
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L4f
            goto L53
        L4f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L53:
            r1 = r8
            if (r1 == 0) goto L92
            if (r0 == 0) goto L70
            goto L61
        L5d:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L61:
            java.lang.String[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.c
            r10 = r0
            r0 = r10
            r1 = 1
            r0 = r0[r1]
            r9 = r0
            r0 = r8
            if (r0 != 0) goto L9c
        L70:
            r0 = r5
            java.lang.Class r0 = r0.getClass()     // Catch: java.lang.RuntimeException -> L7e java.lang.RuntimeException -> L8e
            java.lang.String r0 = r0.getName()     // Catch: java.lang.RuntimeException -> L7e java.lang.RuntimeException -> L8e
            r1 = r8
            if (r1 == 0) goto L9e
            goto L82
        L7e:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L8e
            throw r0     // Catch: java.lang.RuntimeException -> L8e
        L82:
            java.lang.String[] r1 = me.frep.vulcan.spigot.check.AbstractCheck.c     // Catch: java.lang.RuntimeException -> L8e
            r2 = 6
            r1 = r1[r2]     // Catch: java.lang.RuntimeException -> L8e
            boolean r0 = r0.contains(r1)     // Catch: java.lang.RuntimeException -> L8e
            goto L92
        L8e:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L92:
            if (r0 == 0) goto L9c
            java.lang.String[] r0 = me.frep.vulcan.spigot.check.AbstractCheck.c
            r1 = 2
            r0 = r0[r1]
            r9 = r0
        L9c:
            r0 = r9
        L9e:
            me.frep.vulcan.spigot.check.AbstractCheck[] r1 = Vulcan_k()     // Catch: java.lang.RuntimeException -> Lae
            if (r1 == 0) goto Lb2
            r1 = 5
            me.frep.vulcan.spigot.check.AbstractCheck[] r1 = new me.frep.vulcan.spigot.check.AbstractCheck[r1]     // Catch: java.lang.RuntimeException -> Lae
            me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_v(r1)     // Catch: java.lang.RuntimeException -> Lae
            goto Lb2
        Lae:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        Lb2:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.getCategory():java.lang.String");
    }

    public boolean Vulcan_U(Object[] objArr) {
        return this.Vulcan_b.m637Vulcan_r(new Object[0]).m697Vulcan_c(new Object[0]);
    }

    public boolean Vulcan_I(Object[] objArr) {
        return this.Vulcan_b.m639Vulcan_M(new Object[0]).Vulcan_V(new Object[0]);
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public String getName() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 101409954245871L) ^ 1365454902536L);
        return r2.Vulcan_i(r2).name().toLowerCase().replaceAll(StringUtils.SPACE, "");
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public char getType() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 63318902535L) ^ 102289161404128L);
        return Character.toLowerCase(r2.Vulcan_i(r2).type());
    }

    public String toString() {
        return super.toString();
    }

    @Override // me.frep.vulcan.api.check.Check
    public int getVl() {
        return this.Vulcan_H;
    }

    @Override // me.frep.vulcan.api.check.Check
    public int getMaxVl() {
        return ((Integer) Vulcan_fe.Vulcan_vH.get(this.Vulcan_z)).intValue();
    }

    @Override // me.frep.vulcan.api.check.Check
    public int getMinimumVlToNotify() {
        return ((Integer) Vulcan_fe.Vulcan_MI.get(this.Vulcan_z)).intValue();
    }

    @Override // me.frep.vulcan.api.check.Check
    public double getMaxBuffer() {
        return this.Vulcan_c;
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public String getDescription() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 137607797908906L) ^ 35330347588685L);
        return r2.Vulcan_i(r2).description();
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public String getComplexType() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 127558462523941L) ^ 45102389015490L);
        return r2.Vulcan_i(r2).complexType();
    }

    @Override // me.frep.vulcan.api.check.Check
    public double getBufferDecay() {
        return this.Vulcan_Y;
    }

    @Override // me.frep.vulcan.api.check.Check
    public int getAlertInterval() {
        return ((Integer) Vulcan_fe.Vulcan_b7.get(this.Vulcan_z)).intValue();
    }

    @Override // me.frep.vulcan.api.check.Check
    public double getBufferMultiple() {
        return this.Vulcan_e;
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public boolean isExperimental() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 79405012951255L) ^ 23301685500208L);
        return r2.Vulcan_i(r2).experimental();
    }

    @Override // me.frep.vulcan.api.check.Check
    public boolean isPunishable() {
        return ((Boolean) Vulcan_fe.Vulcan_D.get(this.Vulcan_z)).booleanValue();
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public String getDisplayName() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 77814550082480L) ^ 30525131934295L);
        return r2.Vulcan_i(r2).name();
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    @Override // me.frep.vulcan.api.check.Check
    public char getDisplayType() {
        ?? r2 = new Object[1];
        this[0] = Long.valueOf((a ^ 96356966939045L) ^ 11701268365378L);
        return r2.Vulcan_i(r2).type();
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_F(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 227
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_F(java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0071 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_y(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r11 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r12 = r0
            r0 = r11
            boolean r0 = r0 instanceof com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent     // Catch: java.lang.RuntimeException -> L2f
            r1 = r12
            if (r1 == 0) goto L74
            if (r0 == 0) goto L73
            goto L33
        L2f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L33:
            r0 = r11
            com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent r0 = (com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent) r0
            r13 = r0
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L53
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_ROTATION     // Catch: java.lang.RuntimeException -> L53
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L66
            r2 = r12
            if (r2 == 0) goto L66
            if (r0 == r1) goto L69
            goto L57
        L53:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L62
            throw r0     // Catch: java.lang.RuntimeException -> L62
        L57:
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L62
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION     // Catch: java.lang.RuntimeException -> L62
            goto L66
        L62:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L66:
            if (r0 != r1) goto L71
        L69:
            r0 = 1
            goto L72
        L6d:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L6d
            throw r0
        L71:
            r0 = 0
        L72:
            return r0
        L73:
            r0 = 0
        L74:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_y(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0071 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_B(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r12 = r0
            r0 = r11
            boolean r0 = r0 instanceof com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent     // Catch: java.lang.RuntimeException -> L2f
            r1 = r12
            if (r1 == 0) goto L74
            if (r0 == 0) goto L73
            goto L33
        L2f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L33:
            r0 = r11
            com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent r0 = (com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent) r0
            r13 = r0
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L53
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.INTERACT_ENTITY     // Catch: java.lang.RuntimeException -> L53
            r2 = r9
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L66
            r2 = r12
            if (r2 == 0) goto L66
            if (r0 == r1) goto L69
            goto L57
        L53:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L62
            throw r0     // Catch: java.lang.RuntimeException -> L62
        L57:
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L62
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.ATTACK     // Catch: java.lang.RuntimeException -> L62
            goto L66
        L62:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L66:
            if (r0 != r1) goto L71
        L69:
            r0 = 1
            goto L72
        L6d:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L6d
            throw r0
        L71:
            r0 = 0
        L72:
            return r0
        L73:
            r0 = 0
        L74:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.Vulcan_B(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:44:0x00b2
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_K, reason: collision with other method in class */
    public boolean m1115Vulcan_K(java.lang.Object[] r9) {
        /*
            r8 = this;
            r0 = r9
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r10 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r11
            long r0 = r0 ^ r1
            r11 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r13 = r0
            r0 = r10
            boolean r0 = r0 instanceof com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent     // Catch: java.lang.RuntimeException -> L2d
            r1 = r13
            if (r1 == 0) goto Lb9
            if (r0 == 0) goto Lb8
            goto L31
        L2d:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L31:
            r0 = r10
            com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent r0 = (com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent) r0
            r14 = r0
            r0 = r14
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L50
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_FLYING     // Catch: java.lang.RuntimeException -> L50
            r2 = r13
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 < 0) goto L65
            if (r2 == 0) goto L63
            if (r0 == r1) goto Lae
            goto L54
        L50:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L5f
            throw r0     // Catch: java.lang.RuntimeException -> L5f
        L54:
            r0 = r14
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L5f
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_POSITION     // Catch: java.lang.RuntimeException -> L5f
            goto L63
        L5f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L63:
            r2 = r13
        L65:
            r3 = r11
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L8f
            if (r2 == 0) goto L87
            if (r0 == r1) goto Lae
            goto L78
        L74:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L83
            throw r0     // Catch: java.lang.RuntimeException -> L83
        L78:
            r0 = r14
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L83
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_ROTATION     // Catch: java.lang.RuntimeException -> L83
            goto L87
        L83:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L87:
            r2 = r11
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto Lab
            r2 = r13
        L8f:
            if (r2 == 0) goto Lab
            if (r0 == r1) goto Lae
            goto L9c
        L98:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> La7
            throw r0     // Catch: java.lang.RuntimeException -> La7
        L9c:
            r0 = r14
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> La7
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION     // Catch: java.lang.RuntimeException -> La7
            goto Lab
        La7:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        Lab:
            if (r0 != r1) goto Lb6
        Lae:
            r0 = 1
            goto Lb7
        Lb2:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> Lb2
            throw r0
        Lb6:
            r0 = 0
        Lb7:
            return r0
        Lb8:
            r0 = 0
        Lb9:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.m1115Vulcan_K(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_c(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.PLAYER_BLOCK_PLACEMENT;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_h(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.USE_ITEM;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x006e A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean m1116Vulcan_G(java.lang.Object[] r8) {
        /*
            r7 = this;
            r0 = r8
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            com.github.retrooper.packetevents.event.PacketEvent r1 = (com.github.retrooper.packetevents.event.PacketEvent) r1
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.check.AbstractCheck.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.C0050Vulcan_k.Vulcan_G()
            r12 = r0
            r0 = r9
            boolean r0 = r0 instanceof com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent     // Catch: java.lang.RuntimeException -> L2d
            r1 = r12
            if (r1 == 0) goto L71
            if (r0 == 0) goto L70
            goto L31
        L2d:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L31:
            r0 = r9
            com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent r0 = (com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent) r0
            r13 = r0
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L50
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_POSITION     // Catch: java.lang.RuntimeException -> L50
            r2 = r10
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 < 0) goto L63
            r2 = r12
            if (r2 == 0) goto L63
            if (r0 == r1) goto L66
            goto L54
        L50:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L5f
            throw r0     // Catch: java.lang.RuntimeException -> L5f
        L54:
            r0 = r13
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r0 = r0.getPacketType()     // Catch: java.lang.RuntimeException -> L5f
            com.github.retrooper.packetevents.protocol.packettype.PacketType$Play$Client r1 = com.github.retrooper.packetevents.protocol.packettype.PacketType.Play.Client.PLAYER_POSITION_AND_ROTATION     // Catch: java.lang.RuntimeException -> L5f
            goto L63
        L5f:
            java.lang.RuntimeException r0 = b(r0)
            throw r0
        L63:
            if (r0 != r1) goto L6e
        L66:
            r0 = 1
            goto L6f
        L6a:
            java.lang.RuntimeException r0 = b(r0)     // Catch: java.lang.RuntimeException -> L6a
            throw r0
        L6e:
            r0 = 0
        L6f:
            return r0
        L70:
            r0 = 0
        L71:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.AbstractCheck.m1116Vulcan_G(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_v(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.ANIMATION;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public boolean m1117Vulcan_F(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.VEHICLE_MOVE;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_J(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.ENTITY_ACTION;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_C(Object[] objArr) {
        PacketType.Play.Client client = (PacketEvent) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.PLAYER_DIGGING;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_R(Object[] objArr) {
        PacketType.Play.Client client = (PacketEvent) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.PLAYER_ABILITIES;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_m(Object[] objArr) {
        PacketType.Play.Client client = (PacketEvent) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.STEER_VEHICLE;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_f(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.CLIENT_STATUS;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_A(Object[] objArr) {
        PacketType.Play.Client client = (PacketEvent) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.HELD_ITEM_CHANGE;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_z(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.KEEP_ALIVE;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_O(Object[] objArr) {
        PacketType.Play.Client client = (PacketEvent) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.CLICK_WINDOW;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    public boolean Vulcan__(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long jIntValue = (((((long) iIntValue) << 48) | ((((long) ((Integer) objArr[2]).intValue()) << 32) >>> 16)) | ((((long) ((Integer) objArr[3]).intValue()) << 48) >>> 48)) ^ a;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.SPECTATE;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    public boolean Vulcan_j(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Server server = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = server instanceof PacketPlaySendEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Server packetType = (PacketPlaySendEvent) server;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Server.PLAYER_POSITION_AND_LOOK;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [boolean] */
    /* JADX INFO: renamed from: Vulcan_o, reason: collision with other method in class */
    public boolean m1118Vulcan_o(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        PacketType.Play.Client client = (PacketEvent) objArr[1];
        long j = a ^ jLongValue;
        ?? Vulcan_G = C0050Vulcan_k.Vulcan_G();
        try {
            Vulcan_G = client instanceof PacketPlayReceiveEvent;
            if (Vulcan_G == 0) {
                return Vulcan_G;
            }
            if (Vulcan_G != 0) {
                PacketType.Play.Client packetType = (PacketPlayReceiveEvent) client;
                try {
                    packetType = packetType.getPacketType();
                    return packetType == PacketType.Play.Client.CLIENT_TICK_END;
                } catch (RuntimeException unused) {
                    throw b(packetType);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw b(Vulcan_G);
        }
    }
}
