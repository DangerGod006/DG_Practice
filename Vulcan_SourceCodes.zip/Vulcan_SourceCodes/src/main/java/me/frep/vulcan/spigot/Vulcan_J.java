package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.util.NumberConversions;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_J.class */
public final class Vulcan_J {
    public static final double Vulcan_T;
    private static AbstractCheck[] Vulcan_e;
    private static final long a = Vulcan_n.a(-1733465501845440655L, -3914487860173867453L, MethodHandles.lookup().lookupClass()).a(53195465030524L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x002e: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static double Vulcan_t(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Collection r1 = (java.util.Collection) r1
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_J.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            r0 = r9
            r1 = r0; r1 = r0; 
            r2 = 34486715458520(0x1f5d906ca3d8, double:1.7038701345957E-310)
            long r1 = r1 ^ r2
            r11 = r1
            r0 = r11
            r1 = r8
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = r2; r2 = r1; r1 = r3; 
            r4 = r2; r2 = r3; r3 = r4; 
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            double r0 = Vulcan_p(r0)
            r13 = r0
            r0 = r13
            double r0 = java.lang.Math.sqrt(r0)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_t(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00ed: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static double Vulcan_V(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 290
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_V(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0070: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static long Vulcan_P(java.lang.Object[] r10) {
        /*
            r0 = r10
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r11 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r15 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_J.a
            r1 = r15
            long r0 = r0 ^ r1
            r15 = r0
            r0 = r15
            r1 = r0; r1 = r0; 
            r2 = 120360721043895(0x6d77aa05d1b7, double:5.946609737647E-310)
            long r1 = r1 ^ r2
            r17 = r1
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r19 = r0
            r0 = r13
            r1 = 16384(0x4000, double:8.095E-320)
            r2 = r19
            if (r2 == 0) goto L58
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L54
            goto L4c
        L48:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L50
            throw r0     // Catch: java.lang.NullPointerException -> L50
        L4c:
            r0 = r11
            goto L7c
        L50:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L50
            throw r0
        L54:
            r0 = r13
            r1 = r11
            r2 = r13
            long r1 = r1 % r2
        L58:
            r2 = r17
            r3 = 3
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            java.lang.Long r4 = java.lang.Long.valueOf(r4)
            r5 = 2
            r6 = r4; r4 = r5; r5 = r6; 
            r3[r4] = r5
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5; 
            r2[r3] = r4
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            long r0 = Vulcan_P(r0)
        L7c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_P(java.lang.Object[]):long");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0063: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static double Vulcan_U(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 205
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_U(java.lang.Object[]):double");
    }

    public static void Vulcan_P(AbstractCheck[] abstractCheckArr) {
        Vulcan_e = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_K() {
        return Vulcan_e;
    }

    private static NullPointerException a(NullPointerException nullPointerException) {
        return nullPointerException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_J() {
        throw new UnsupportedOperationException(b[0]);
    }

    static {
        long j = a ^ 87042533017596L;
        Vulcan_P(new AbstractCheck[3]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "ôÙ\u008eÀ\f?\u009ay5£Á4h\\\u001a\u0094k-\u0081\u000f\u008c\u009e\\\u009b\fÛD!1\"e[h\\j]_6ÚÆÑ;h»J\u0092à?\u0090\u0093$\rFb»®\b[£$ã\u0093xãý".length();
        char cCharAt = '8';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("ôÙ\u008eÀ\f?\u009ay5£Á4h\\\u001a\u0094k-\u0081\u000f\u008c\u009e\\\u009b\fÛD!1\"e[h\\j]_6ÚÆÑ;h»J\u0092à?\u0090\u0093$\rFb»®\b[£$ã\u0093xãý".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                Vulcan_T = Math.pow(2.0d, 24.0d);
                return;
            }
            cCharAt = "ôÙ\u008eÀ\f?\u009ay5£Á4h\\\u001a\u0094k-\u0081\u000f\u008c\u009e\\\u009b\fÛD!1\"e[h\\j]_6ÚÆÑ;h»J\u0092à?\u0090\u0093$\rFb»®\b[£$ã\u0093xãý".charAt(i3);
        }
    }

    public static double Vulcan_l(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        return Math.sqrt((dDoubleValue * dDoubleValue) + (dDoubleValue2 * dDoubleValue2));
    }

    public static double Vulcan_W(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        return Math.sqrt((dDoubleValue * dDoubleValue) + (dDoubleValue2 * dDoubleValue2) + (dDoubleValue3 * dDoubleValue3));
    }

    public static String Vulcan_E(Object[] objArr) {
        return new DecimalFormat(b[1]).format(((Double) objArr[0]).doubleValue());
    }

    public static float Vulcan_A(Object[] objArr) {
        float fAbs = Math.abs((((Float) objArr[0]).floatValue() % 360.0f) - (((Float) objArr[1]).floatValue() % 360.0f));
        return (float) Math.abs(Math.min(360.0d - ((double) fAbs), fAbs));
    }

    public static double Vulcan_p(Object[] objArr) {
        double dDoubleValue;
        long jLongValue = ((Long) objArr[0]).longValue();
        Collection<Number> collection = (Collection) objArr[1];
        long j = a ^ jLongValue;
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        int i = 0;
        double d = 0.0d;
        double d2 = 0.0d;
        for (Number number : collection) {
            if (j > 0) {
                dDoubleValue = d + number.doubleValue();
                if (abstractCheckArrVulcan_q == null) {
                    break;
                }
                d = dDoubleValue;
                i++;
            }
            if (abstractCheckArrVulcan_q == null) {
                break;
            }
        }
        dDoubleValue = d;
        if (j >= 0) {
            dDoubleValue /= (double) i;
        }
        double d3 = dDoubleValue;
        for (Number number2 : collection) {
            if (j >= 0) {
                double dPow = d2 + Math.pow(number2.doubleValue() - d3, 2.0d);
                if (abstractCheckArrVulcan_q == null) {
                    return dPow;
                }
                d2 = dPow;
            }
            if (abstractCheckArrVulcan_q == null) {
                break;
            }
        }
        return d2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static double Vulcan_O(Object[] objArr) {
        Collection<Number> collection = (Collection) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        Collection collection2 = collection;
        NullPointerException nullPointerExceptionIsEmpty = collection2;
        if (abstractCheckArrVulcan_q != null) {
            if (collection2 == null) {
                return 0.0d;
            }
            nullPointerExceptionIsEmpty = collection;
        }
        try {
            nullPointerExceptionIsEmpty = nullPointerExceptionIsEmpty.isEmpty();
            if (nullPointerExceptionIsEmpty != 0) {
                return 0.0d;
            }
            double d = 0.0d;
            for (Number number : collection) {
                if (jLongValue > 0) {
                    double dDoubleValue = d + number.doubleValue();
                    if (abstractCheckArrVulcan_q == null) {
                        return dDoubleValue;
                    }
                    d = dDoubleValue;
                }
                if (abstractCheckArrVulcan_q == null) {
                    break;
                }
            }
            double d2 = d;
            return jLongValue >= 0 ? d2 / ((double) collection.size()) : d2;
        } catch (NullPointerException unused) {
            throw a(nullPointerExceptionIsEmpty);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x008e, code lost:
    
        r0 = r16;
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0090, code lost:
    
        r1 = ((((double) r16) - 1.0d) * (((double) r16) - 2.0d)) * (((double) r16) - 3.0d);
        r0 = ((double) r0) * (((double) r16) + 1.0d);
        r14 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00ac, code lost:
    
        r0 = r0 / r1;
        r0 = (3.0d * java.lang.Math.pow(((double) r16) - 1.0d, 2.0d)) / ((((double) r16) - 2.0d) * (((double) r16) - 3.0d));
        r0 = r14 / ((double) r16);
        r23 = 0.0d;
        r25 = 0.0d;
        r0 = r1.iterator();
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00ed, code lost:
    
        if (r0.hasNext() == false) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00f0, code lost:
    
        r0 = (java.lang.Number) r0.next();
        r23 = r23 + java.lang.Math.pow(r0 - r0.doubleValue(), 2.0d);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0112, code lost:
    
        if (r0 <= 0) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0115, code lost:
    
        r0 = r25 + java.lang.Math.pow(r0 - r0.doubleValue(), 4.0d);
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0128, code lost:
    
        if (r0 == null) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x012b, code lost:
    
        r25 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x012f, code lost:
    
        if (r0 != null) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x0132, code lost:
    
        r0 = r0 * (r25 / java.lang.Math.pow(r23 / r14, 2.0d));
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0146, code lost:
    
        if (r0 <= 0) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x014c, code lost:
    
        return r0 - r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:?, code lost:
    
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0078  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.NullPointerException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.NullPointerException] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.NullPointerException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v15, types: [double] */
    /* JADX WARN: Type inference failed for: r0v18, types: [double] */
    /* JADX WARN: Type inference failed for: r0v23, types: [double] */
    /* JADX WARN: Type inference failed for: r0v51, types: [double] */
    /* JADX WARN: Type inference failed for: r0v52, types: [double, java.lang.NullPointerException] */
    /* JADX WARN: Type inference failed for: r0v59 */
    /* JADX WARN: Type inference failed for: r0v60 */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1 */
    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11 */
    /* JADX WARN: Type inference failed for: r14v12 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v6 */
    /* JADX WARN: Type inference failed for: r14v7 */
    /* JADX WARN: Type inference failed for: r14v8 */
    /* JADX WARN: Type inference failed for: r14v9 */
    /* JADX WARN: Type inference failed for: r3v2, types: [double] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static double Vulcan_o(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 333
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_o(java.lang.Object[]):double");
    }

    public static Number Vulcan_Y(Object[] objArr) {
        Collection collection = (Collection) objArr[0];
        HashMap map = new HashMap();
        collection.forEach((v1) -> {
            lambda$getModeElevated$0(r1, v1);
        });
        return (Number) ((Vulcan_T) map.keySet().stream().map((v1) -> {
            return lambda$getModeElevated$1(r1, v1);
        }).max(Comparator.comparing((v0) -> {
            return v0.Vulcan_S();
        }, Comparator.naturalOrder())).orElseThrow(NullPointerException::new)).Vulcan_X(new Object[0]);
    }

    private static void lambda$getModeElevated$0(Map map, Number number) {
        map.put(number, Integer.valueOf(((Integer) map.getOrDefault(number, 0)).intValue() + 1));
    }

    private static Vulcan_T lambda$getModeElevated$1(Map map, Number number) {
        return new Vulcan_T(number, map.get(number));
    }

    public static Double Vulcan__(Object[] objArr) {
        double[] dArr = (double[]) objArr[0];
        HashMap map = new HashMap();
        Arrays.stream(dArr).forEach((v1) -> {
            lambda$getMode$2(r1, v1);
        });
        return (Double) ((Vulcan_T) map.keySet().stream().map((v1) -> {
            return lambda$getMode$3(r1, v1);
        }).max(Comparator.comparing((v0) -> {
            return v0.Vulcan_S();
        }, Comparator.naturalOrder())).orElseThrow(NullPointerException::new)).Vulcan_X(new Object[0]);
    }

    private static void lambda$getMode$2(Map map, double d) {
        map.put(Double.valueOf(d), Integer.valueOf(((Integer) map.getOrDefault(Double.valueOf(d), 0)).intValue() + 1));
    }

    private static Vulcan_T lambda$getMode$3(Map map, Double d) {
        return new Vulcan_T(d, map.get(d));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    public static double Vulcan_f(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        int iIntValue = ((Integer) objArr[1]).intValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        NullPointerException illegalArgumentException = iIntValue;
        if (illegalArgumentException < 0) {
            try {
                illegalArgumentException = new IllegalArgumentException();
                throw illegalArgumentException;
            } catch (NullPointerException unused) {
                throw a(illegalArgumentException);
            }
        }
        return new BigDecimal(dDoubleValue).setScale(iIntValue, RoundingMode.HALF_UP).doubleValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:26:0x00a6, B:32:0x00be], limit reached: 45 */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00cd A[EDGE_INSN: B:44:0x00cd->B:37:0x00cd BREAK  A[LOOP:1: B:4:0x0040->B:45:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:? A[LOOP:3: B:8:0x005f->B:47:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [int] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v37 */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r13v0 */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v10 */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v12 */
    /* JADX WARN: Type inference failed for: r13v13 */
    /* JADX WARN: Type inference failed for: r13v14 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7 */
    /* JADX WARN: Type inference failed for: r13v8 */
    /* JADX WARN: Type inference failed for: r16v0 */
    /* JADX WARN: Type inference failed for: r16v1 */
    /* JADX WARN: Type inference failed for: r16v10 */
    /* JADX WARN: Type inference failed for: r16v11 */
    /* JADX WARN: Type inference failed for: r16v12 */
    /* JADX WARN: Type inference failed for: r16v13 */
    /* JADX WARN: Type inference failed for: r16v14 */
    /* JADX WARN: Type inference failed for: r16v15 */
    /* JADX WARN: Type inference failed for: r16v16 */
    /* JADX WARN: Type inference failed for: r16v17 */
    /* JADX WARN: Type inference failed for: r16v18 */
    /* JADX WARN: Type inference failed for: r16v2 */
    /* JADX WARN: Type inference failed for: r16v3, types: [int] */
    /* JADX WARN: Type inference failed for: r16v4 */
    /* JADX WARN: Type inference failed for: r16v5 */
    /* JADX WARN: Type inference failed for: r16v6 */
    /* JADX WARN: Type inference failed for: r16v9 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x00ca -> B:11:0x0070). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int Vulcan_z(java.lang.Object[] r7) {
        /*
            Method dump skipped, instruction units count: 211
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_z(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.NullPointerException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.NullPointerException] */
    private static double Vulcan_j(Object[] objArr) {
        List list = (List) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? size = list;
        ?? r0 = size;
        if (Vulcan_OM.Vulcan_q() != null) {
            try {
                try {
                    size = size.size() % 2;
                    if (size == 0) {
                        return (((Double) list.get(list.size() / 2)).doubleValue() + ((Double) list.get((list.size() / 2) - 1)).doubleValue()) / 2.0d;
                    }
                    r0 = list.get(list.size() / 2);
                } catch (NullPointerException unused) {
                    throw a((NullPointerException) size);
                }
            } catch (NullPointerException unused2) {
                throw a((NullPointerException) size);
            }
        }
        return ((Double) r0).doubleValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean m578Vulcan_z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Number r1 = (java.lang.Number) r1
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_J.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r8
            double r0 = r0.doubleValue()     // Catch: java.lang.NullPointerException -> L2f
            r1 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r9
            if (r1 == 0) goto L47
            if (r0 >= 0) goto L5a
            goto L33
        L2f:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L43
            throw r0     // Catch: java.lang.NullPointerException -> L43
        L33:
            r0 = r8
            double r0 = r0.doubleValue()     // Catch: java.lang.NullPointerException -> L43
            java.lang.String r0 = java.lang.Double.toString(r0)     // Catch: java.lang.NullPointerException -> L43
            java.lang.String r1 = "E"
            boolean r0 = r0.contains(r1)     // Catch: java.lang.NullPointerException -> L43
            goto L47
        L43:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L47:
            r1 = r9
            if (r1 == 0) goto L57
            if (r0 == 0) goto L5a
            goto L56
        L52:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L56:
            r0 = 1
        L57:
            goto L5b
        L5a:
            r0 = 0
        L5b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.m578Vulcan_z(java.lang.Object[]):boolean");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static double Vulcan_J(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r11 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r13 = r1
            r1 = r0
            r2 = 4
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r15 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_J.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r1 = r11
            r2 = r15
            double r1 = r1 - r2
            r18 = r1
            r17 = r0
            r0 = r13
            r1 = r9
            double r0 = r0 - r1
            r20 = r0
            r0 = r18
            r1 = r20
            double r0 = java.lang.Math.atan2(r0, r1)
            double r0 = java.lang.Math.toDegrees(r0)
            r22 = r0
            r0 = r22
            r1 = 0
            r2 = r17
            if (r2 == 0) goto L7a
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L7e
            goto L6e
        L6a:
            java.lang.NullPointerException r0 = a(r0)     // Catch: java.lang.NullPointerException -> L76
            throw r0     // Catch: java.lang.NullPointerException -> L76
        L6e:
            r0 = 4645040803167600640(0x4076800000000000, double:360.0)
            r1 = r22
            goto L7a
        L76:
            java.lang.NullPointerException r0 = a(r0)
            throw r0
        L7a:
            double r0 = r0 + r1
            goto L80
        L7e:
            r0 = r22
        L80:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_J.Vulcan_J(java.lang.Object[]):double");
    }

    public static double Vulcan_M(Object[] objArr) {
        double dAbs = Math.abs((((Double) objArr[0]).doubleValue() % 360.0d) - (((Double) objArr[1]).doubleValue() % 360.0d));
        return Math.abs(Math.min(360.0d - dAbs, dAbs));
    }

    public static double Vulcan_X(Object[] objArr) {
        return Math.abs((((Double) objArr[0]).doubleValue() % 360.0d) - (((Double) objArr[1]).doubleValue() % 360.0d));
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.util.Collection] */
    public static double Vulcan_H(Object[] objArr) {
        Object[] objArr2 = new Object[2];
        ((Collection) objArr[1])[1] = Long.valueOf((a ^ ((Long) objArr[0]).longValue()) ^ 76689453087292L);
        objArr2[0] = objArr2;
        return (20.0d / Vulcan_O(objArr2)) * 50.0d;
    }

    public static int Vulcan_Q(Object[] objArr) {
        Collection collection = (Collection) objArr[0];
        return (int) (((long) collection.size()) - collection.stream().distinct().count());
    }

    public static int Vulcan_e(Object[] objArr) {
        return (int) ((Collection) objArr[0]).stream().distinct().count();
    }

    /* JADX INFO: renamed from: Vulcan__, reason: collision with other method in class */
    public static int m579Vulcan__(Object[] objArr) {
        return NumberConversions.floor(((C0042Vulcan_Oz) objArr[0]).m640Vulcan_O(new Object[0]).Vulcan_m(new Object[0]) / 50.0d) + 3;
    }
}
