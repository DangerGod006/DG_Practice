package me.frep.vulcan.spigot.check.impl.player.scaffold;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.Vulcan_n;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.block.BlockFace;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/scaffold/ScaffoldN.class */
@CheckInfo(name = "Scaffold", type = 'N', complexType = "Expand", description = "Invalid block face.", experimental = true)
public class ScaffoldN extends AbstractCheck {
    private List Vulcan_C;
    private static AbstractCheck[] Vulcan_f;
    private static final long b = Vulcan_n.a(4103117679642259322L, -4654661519490716143L, MethodHandles.lookup().lookupClass()).a(107250551761970L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x025f: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(java.lang.Object[] r13) {
        /*
            Method dump skipped, instruction units count: 1296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldN.Vulcan_a(java.lang.Object[]):void");
    }

    public static void Vulcan_h(AbstractCheck[] abstractCheckArr) {
        Vulcan_f = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_B() {
        return Vulcan_f;
    }

    static {
        long j = b ^ 36118303940105L;
        Vulcan_h((AbstractCheck[]) null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "\u0019meæÀp÷\u0092\u0010/\n\u0081¶C(\u0083uN\u008aé)\u0097\u0007ze".length();
        char cCharAt = '\b';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = b(cipher.doFinal("\u0019meæÀp÷\u0092\u0010/\n\u0081¶C(\u0083uN\u008aé)\u0097\u0007ze".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                d = strArr;
                return;
            }
            cCharAt = "\u0019meæÀp÷\u0092\u0010/\n\u0081¶C(\u0083uN\u008aé)\u0097\u0007ze".charAt(i3);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public ScaffoldN(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        this.Vulcan_C = new ArrayList();
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException, me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r1v16 */
    /* JADX WARN: Type inference failed for: r3v1, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r8v0, types: [me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldN] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    private BlockFace Vulcan_W(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        long jLongValue = (b ^ ((Long) objArr[1]).longValue()) ^ 133958560511759L;
        ?? Vulcan_B = Vulcan_B();
        float f = (fFloatValue - 90.0f) % 360.0f;
        try {
            float f2 = f;
            if (Vulcan_B != 0) {
                f = f2;
            } else if (f2 < 0.0f) {
                f2 = (float) (((double) f) + 360.0d);
                f = f2;
            }
            ?? r3 = new Object[2];
            f[1] = Long.valueOf(jLongValue);
            r3[0] = Float.valueOf((float) r3);
            return Vulcan_h(r3);
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_B);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private org.bukkit.block.BlockFace Vulcan_h(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 340
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.scaffold.ScaffoldN.Vulcan_h(java.lang.Object[]):org.bukkit.block.BlockFace");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [double] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v19, types: [org.bukkit.util.Vector] */
    public Vector Vulcan_A(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        long jLongValue = b ^ ((Long) objArr[2]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_B = Vulcan_B();
        Vector vector = new Vector();
        double d2 = fFloatValue;
        double d3 = fFloatValue2;
        vector.setY(-Math.sin(Math.toRadians(d3)));
        ?? Cos = Math.cos(Math.toRadians(d3));
        try {
            vector.setX((-Cos) * Math.sin(Math.toRadians(d2)));
            vector.setZ(Cos * Math.cos(Math.toRadians(d2)));
            Cos = vector;
            if (abstractCheckArrVulcan_B != null) {
                AbstractCheck.Vulcan_D(new AbstractCheck[1]);
            }
            return Cos;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Cos);
        }
    }
}
