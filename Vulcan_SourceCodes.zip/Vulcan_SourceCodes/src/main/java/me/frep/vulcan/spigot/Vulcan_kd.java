package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.CommandExecutor;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kd.class */
public class Vulcan_kd extends Vulcan_k4 implements CommandExecutor {
    private static final long b = Vulcan_n.a(3212173471803856379L, -1637585525464501277L, MethodHandles.lookup().lookupClass()).a(224837368451902L);
    private static final String[] d;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00be: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public boolean onCommand(org.bukkit.command.CommandSender r10, org.bukkit.command.Command r11, java.lang.String r12, java.lang.String[] r13) {
        /*
            Method dump skipped, instruction units count: 2198
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kd.onCommand(org.bukkit.command.CommandSender, org.bukkit.command.Command, java.lang.String, java.lang.String[]):boolean");
    }

    static {
        int i;
        long j = b ^ 108616554018086L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[26];
        int i3 = 0;
        String str = "f\u0001ëjÄ´ìQ\u00ad\u0017àèFx1|\u0010´B\u0013Í\u0000ç\u00839®\u008e\u0091M=\u0007êã\u0010?xÜñ\u0096Vµ}\u00adºñ3\u0091g\u001b¯\u0010\u0005j03)âë:\u000eÿ\u0089\u0006ÏMÆÉ\b¼DÁ]RHwë\bÖ*£<Á\nH÷\bÖ*£<Á\nH÷\u0010¥#Ý*\u000bÞÛad\u0097(ÙW\u0093\u0013\u008c\bØØDÔæ¦é\u00ad\b\u0012\u000e\u008fÔ\u009auø$\u0010¥#Ý*\u000bÞÛad\u0097(ÙW\u0093\u0013\u008c\bÄ\u000f\u0085Àz¬È=\u0010\u0005j03)âë:\u000eÿ\u0089\u0006ÏMÆÉ\b\u0016\u009a½\f{\u0082\r\u0093\u0018¼¦OÀ½?·)óóWjß`kupïü\u0082õ~=õ\bØØDÔæ¦é\u00ad\bw¶YFêC\u000eÍ\bx\u0081Ï\u0098á\u0099Á\u0002\b»ÓØ\u001d\u009c £Í\u0010f\u0001ëjÄ´ìQ\u00ad\u0017àèFx1|\b\u0012\u000e\u008fÔ\u009auø$\u0010¥#Ý*\u000bÞÛa\u001dE0Ã\u0010Û\u0016<\u0010¥#Ý*\u000bÞÛa\u001dE0Ã\u0010Û\u0016<\u0010?xÜñ\u0096Vµ}\u00adºñ3\u0091g\u001b¯";
        int length = "f\u0001ëjÄ´ìQ\u00ad\u0017àèFx1|\u0010´B\u0013Í\u0000ç\u00839®\u008e\u0091M=\u0007êã\u0010?xÜñ\u0096Vµ}\u00adºñ3\u0091g\u001b¯\u0010\u0005j03)âë:\u000eÿ\u0089\u0006ÏMÆÉ\b¼DÁ]RHwë\bÖ*£<Á\nH÷\bÖ*£<Á\nH÷\u0010¥#Ý*\u000bÞÛad\u0097(ÙW\u0093\u0013\u008c\bØØDÔæ¦é\u00ad\b\u0012\u000e\u008fÔ\u009auø$\u0010¥#Ý*\u000bÞÛad\u0097(ÙW\u0093\u0013\u008c\bÄ\u000f\u0085Àz¬È=\u0010\u0005j03)âë:\u000eÿ\u0089\u0006ÏMÆÉ\b\u0016\u009a½\f{\u0082\r\u0093\u0018¼¦OÀ½?·)óóWjß`kupïü\u0082õ~=õ\bØØDÔæ¦é\u00ad\bw¶YFêC\u000eÍ\bx\u0081Ï\u0098á\u0099Á\u0002\b»ÓØ\u001d\u009c £Í\u0010f\u0001ëjÄ´ìQ\u00ad\u0017àèFx1|\b\u0012\u000e\u008fÔ\u009auø$\u0010¥#Ý*\u000bÞÛa\u001dE0Ã\u0010Û\u0016<\u0010¥#Ý*\u000bÞÛa\u001dE0Ã\u0010Û\u0016<\u0010?xÜñ\u0096Vµ}\u00adºñ3\u0091g\u001b¯".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "\u0016\u009a½\f{\u0082\r\u0093\u0010\u0085i\u009b\u008f\u0013Cl\u008c4òG\u0001Î\u009fª¾";
                        length = "\u0016\u009a½\f{\u0082\r\u0093\u0010\u0085i\u009b\u008f\u0013Cl\u008c4òG\u0001Î\u009fª¾".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }
}
