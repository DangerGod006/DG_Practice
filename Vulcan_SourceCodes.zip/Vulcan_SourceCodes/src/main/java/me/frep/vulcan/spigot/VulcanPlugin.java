package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_O8;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import org.apache.commons.lang3.BooleanUtils;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/VulcanPlugin.class */
public final class VulcanPlugin extends JavaPlugin {
    private static /* bridge */ /* synthetic */ void loadConfig0() {
        try {
            URLConnection con = new URL("https://api.spigotmc.org/legacy/premium.php?user_id=1815274&resource_id=83626&nonce=444119193").openConnection();
            con.setConnectTimeout(Vulcan_O8.Vulcan_z);
            con.setReadTimeout(Vulcan_O8.Vulcan_z);
            ((HttpURLConnection) con).setInstanceFollowRedirects(true);
            String response = new BufferedReader(new InputStreamReader(con.getInputStream())).readLine();
            if (BooleanUtils.FALSE.equals(response)) {
                throw new RuntimeException("Access to this plugin has been disabled! Please contact the author!");
            }
        } catch (IOException e) {
        }
    }

    public void onEnable() {
        loadConfig0();
        Vulcan_r.INSTANCE.Vulcan_B(this);
    }

    public void onDisable() {
        Vulcan_r.INSTANCE.Vulcan_e(this);
    }
}
