package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.Random;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Ov.class */
public class Vulcan_Ov {
    public static final float Vulcan_W;
    private static final float[] Vulcan_e;
    private static final int[] Vulcan_t;
    private static final String Vulcan_o;
    private static final long a = Vulcan_n.a(-4326573978262781092L, 7908912073984118320L, MethodHandles.lookup().lookupClass()).a(25113108636619L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0047: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    /* JADX INFO: renamed from: Vulcan_j, reason: collision with other method in class */
    public static boolean m619Vulcan_j(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r10
            long r0 = r0 ^ r1
            r10 = r0
            r0 = r10
            r1 = r0; r1 = r0; 
            r2 = 100960145536431(0x5bd29d9c75af, double:4.9880939508683E-310)
            long r1 = r1 ^ r2
            r12 = r1
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r14 = r0
            r0 = r9
            r1 = r8
            float r0 = r0 - r1
            r1 = r12
            r2 = r1; r1 = r0; r0 = r2;      // Catch: java.lang.RuntimeException -> L61
            r2 = 2
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch: java.lang.RuntimeException -> L61
            r3 = r2; r2 = r1; r1 = r3;      // Catch: java.lang.RuntimeException -> L61
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L61
            java.lang.Float r3 = java.lang.Float.valueOf(r3)     // Catch: java.lang.RuntimeException -> L61
            r4 = 1
            r5 = r3; r3 = r4; r4 = r5;      // Catch: java.lang.RuntimeException -> L61
            r2[r3] = r4     // Catch: java.lang.RuntimeException -> L61
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2;      // Catch: java.lang.RuntimeException -> L61
            r3 = r2; r2 = r1; r1 = r0; r0 = r3;      // Catch: java.lang.RuntimeException -> L61
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch: java.lang.RuntimeException -> L61
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4;      // Catch: java.lang.RuntimeException -> L61
            r1[r2] = r3     // Catch: java.lang.RuntimeException -> L61
            float r0 = Vulcan_x(r0)     // Catch: java.lang.RuntimeException -> L61
            r1 = 925353388(0x3727c5ac, float:1.0E-5)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 != 0) goto L66
            if (r0 >= 0) goto L69
            goto L65
        L61:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L65:
            r0 = 1
        L66:
            goto L6a
        L69:
            r0 = 0
        L6a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.m619Vulcan_j(java.lang.Object[]):boolean");
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v30 */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [float[]] */
    static {
        int i;
        long j = a ^ 42403724607574L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[4];
        int i3 = 0;
        String str = "¾OlV´\u008eE¤`~`H\u008aÍ\u00947\u0010Ä@gê©\u0011ëJ\u0017X¬î\u00067¡$";
        int length = "¾OlV´\u008eE¤`~`H\u008aÍ\u00947\u0010Ä@gê©\u0011ëJ\u0017X¬î\u00067¡$".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 < length) {
                            cCharAt = str.charAt(i);
                            break;
                        } else {
                            b = strArr;
                            Vulcan_o = b[2];
                            Vulcan_W = Vulcan_u(new Object[]{Float.valueOf(2.0f)});
                            Vulcan_e = new float[65536];
                            int i8 = 0;
                            while (true) {
                                ?? r0 = i8;
                                if (r0 < 65536) {
                                    try {
                                        r0 = Vulcan_e;
                                        r0[i8] = (float) Math.sin(((((double) i8) * 3.141592653589793d) * 2.0d) / 65536.0d);
                                        i8++;
                                    } catch (RuntimeException unused) {
                                        throw a((RuntimeException) r0);
                                    }
                                } else {
                                    Vulcan_t = new int[]{0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8, 31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9};
                                    return;
                                }
                            }
                        }
                        break;
                    default:
                        int i9 = i3;
                        i3++;
                        strArr[i9] = strIntern;
                        int i10 = i5 + cCharAt;
                        i4 = i10;
                        if (i10 < length) {
                        }
                        str = "\u0096N\u008fòJ\u001aOm\u0005ðÍ\u00016[»s\u0018Ì\u0096Y\u0013z½\u0007«%àFÃ\u001e\u009b\u001b\u0095¢ü^²Ð\u0096#\u0082";
                        length = "\u0096N\u008fòJ\u001aOm\u0005ðÍ\u00016[»s\u0018Ì\u0096Y\u0013z½\u0007«%àFÃ\u001e\u009b\u001b\u0095¢ü^²Ð\u0096#\u0082".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    public static float Vulcan_G(Object[] objArr) {
        return Vulcan_e[((int) (((Float) objArr[0]).floatValue() * 10430.378f)) & 65535];
    }

    public static String spigot() {
        return b[1];
    }

    public static String nonce() {
        return b[0];
    }

    public static String resource() {
        return b[3];
    }

    public static float Vulcan_Q(Object[] objArr) {
        return Vulcan_e[((int) ((((Float) objArr[0]).floatValue() * 10430.378f) + 16384.0f)) & 65535];
    }

    public static float Vulcan_u(Object[] objArr) {
        return (float) Math.sqrt(((Float) objArr[0]).floatValue());
    }

    public static float Vulcan_j(Object[] objArr) {
        return (float) Math.sqrt(((Double) objArr[0]).doubleValue());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public static int Vulcan_v(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        int i = (int) fFloatValue;
        try {
            try {
                Vulcan_J = (fFloatValue > i ? 1 : (fFloatValue == i ? 0 : -1));
                return Vulcan_J == 0 ? Vulcan_J < 0 ? i - 1 : i : Vulcan_J;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_J);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    public static int Vulcan_d(Object[] objArr) {
        return ((int) (((Double) objArr[0]).doubleValue() + 1024.0d)) - 1024;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public static int Vulcan_Z(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        double dDoubleValue = ((Double) objArr[1]).doubleValue();
        long j = a ^ jLongValue;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        int i = (int) dDoubleValue;
        try {
            try {
                Vulcan_J = (dDoubleValue > i ? 1 : (dDoubleValue == i ? 0 : -1));
                return Vulcan_J == 0 ? Vulcan_J < 0 ? i - 1 : i : Vulcan_J;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_J);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [long] */
    /* JADX WARN: Type inference failed for: r0v4, types: [long] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    public static long Vulcan_l(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        double dDoubleValue = ((Double) objArr[1]).doubleValue();
        long j = a ^ jLongValue;
        ?? r0 = (long) dDoubleValue;
        try {
            if (dDoubleValue >= ((double) r0)) {
                return r0;
            }
            r0--;
            return r0;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) r0);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_L(java.lang.Object[] r6) {
        /*
            r0 = r6
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r9 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r11 = r0
            r0 = r9
            r1 = 0
            r2 = r11
            if (r2 != 0) goto L3e
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L3b
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L37
            throw r0     // Catch: java.lang.RuntimeException -> L37
        L33:
            r0 = r9
            goto L3f
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L37
            throw r0
        L3b:
            r0 = r9
            double r0 = -r0
            r1 = 4607182418800017408(0x3ff0000000000000, double:1.0)
        L3e:
            double r0 = r0 + r1
        L3f:
            int r0 = (int) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_L(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static float Vulcan_x(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3c
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L3b
            goto L33
        L2f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L37
            throw r0     // Catch: java.lang.RuntimeException -> L37
        L33:
            r0 = r8
            goto L3d
        L37:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L37
            throw r0
        L3b:
            r0 = r8
        L3c:
            float r0 = -r0
        L3d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_x(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_F(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r9 = r0
            r0 = r8
            r1 = r9
            if (r1 != 0) goto L3a
            if (r0 < 0) goto L39
            goto L31
        L2d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L35
            throw r0     // Catch: java.lang.RuntimeException -> L35
        L31:
            r0 = r8
            goto L3b
        L35:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L35
            throw r0
        L39:
            r0 = r8
        L3a:
            int r0 = -r0
        L3b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_F(java.lang.Object[]):int");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public static int Vulcan_N(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        float fFloatValue = ((Float) objArr[1]).floatValue();
        long j = a ^ jLongValue;
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        int i = (int) fFloatValue;
        try {
            try {
                Vulcan_J = (fFloatValue > i ? 1 : (fFloatValue == i ? 0 : -1));
                return Vulcan_J == 0 ? Vulcan_J > 0 ? i + 1 : i : Vulcan_J;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_J);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    public static int Vulcan_z(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        int i = (int) dDoubleValue;
        try {
            try {
                Vulcan_J = (dDoubleValue > i ? 1 : (dDoubleValue == i ? 0 : -1));
                return Vulcan_J == 0 ? Vulcan_J > 0 ? i + 1 : i : Vulcan_J;
            } catch (RuntimeException unused) {
                throw a((RuntimeException) Vulcan_J);
            }
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_f(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r6 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r9
            long r0 = r0 ^ r1
            r9 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r11 = r0
            r0 = r8
            r1 = r7
            r2 = r11
            if (r2 != 0) goto L5f
            if (r0 >= r1) goto L51
            goto L49
        L45:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0     // Catch: java.lang.RuntimeException -> L4d
        L49:
            r0 = r7
            goto L67
        L4d:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4d
            throw r0
        L51:
            r0 = r8
            r1 = r11
            if (r1 != 0) goto L63
            r1 = r6
            goto L5f
        L5b:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L5f:
            if (r0 <= r1) goto L66
            r0 = r6
        L63:
            goto L67
        L66:
            r0 = r8
        L67:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_f(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static float Vulcan_s(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r11 = r0
            r0 = r9
            r1 = r8
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r11
            if (r1 != 0) goto L63
            if (r0 >= 0) goto L52
            goto L4a
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4e
            throw r0     // Catch: java.lang.RuntimeException -> L4e
        L4a:
            r0 = r8
            goto L6d
        L4e:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4e
            throw r0
        L52:
            r0 = r9
            r1 = r11
            if (r1 != 0) goto L68
            r1 = r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L63:
            if (r0 <= 0) goto L6b
            r0 = r10
        L68:
            goto L6d
        L6b:
            r0 = r9
        L6d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_s(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_Z, reason: collision with other method in class */
    public static double m618Vulcan_Z(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r6 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r12 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r14 = r0
            r0 = r6
            r1 = r10
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r14
            if (r1 != 0) goto L63
            if (r0 >= 0) goto L53
            goto L4a
        L46:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4f
            throw r0     // Catch: java.lang.RuntimeException -> L4f
        L4a:
            r0 = r10
            goto L6c
        L4f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4f
            throw r0
        L53:
            r0 = r6
            r1 = r14
            if (r1 != 0) goto L68
            r1 = r12
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L63
        L5f:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L63:
            if (r0 <= 0) goto L6b
            r0 = r12
        L68:
            goto L6c
        L6b:
            r0 = r6
        L6c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.m618Vulcan_Z(java.lang.Object[]):double");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static double Vulcan_V(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r8 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r12 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r14 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r12
            long r0 = r0 ^ r1
            r12 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r16 = r0
            r0 = r14
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            r1 = r16
            if (r1 != 0) goto L64
            if (r0 >= 0) goto L54
            goto L4c
        L48:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L50
            throw r0     // Catch: java.lang.RuntimeException -> L50
        L4c:
            r0 = r8
            goto L77
        L50:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L50
            throw r0
        L54:
            r0 = r14
            r1 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            r2 = r16
            if (r2 != 0) goto L76
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            goto L64
        L60:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L64:
            if (r0 <= 0) goto L6f
            r0 = r10
            goto L77
        L6b:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L6b
            throw r0
        L6f:
            r0 = r8
            r1 = r10
            r2 = r8
            double r1 = r1 - r2
            r2 = r14
            double r1 = r1 * r2
        L76:
            double r0 = r0 + r1
        L77:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_V(java.lang.Object[]):double");
    }

    public static double Vulcan_Y(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        String[] strArrVulcan_J = Vulcan_fq.Vulcan_J();
        int i = (dDoubleValue > 0.0d ? 1 : (dDoubleValue == 0.0d ? 0 : -1));
        if (strArrVulcan_J == null) {
            if (i < 0) {
                dDoubleValue = -dDoubleValue;
            }
            i = (dDoubleValue2 > 0.0d ? 1 : (dDoubleValue2 == 0.0d ? 0 : -1));
        }
        if (strArrVulcan_J == null) {
            if (i < 0) {
                dDoubleValue2 = -dDoubleValue2;
            }
            double d = dDoubleValue;
            if (strArrVulcan_J != null) {
                return d;
            }
            i = (d > dDoubleValue2 ? 1 : (d == dDoubleValue2 ? 0 : -1));
        }
        return i > 0 ? dDoubleValue : dDoubleValue2;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException, java.lang.String[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static int Vulcan_D(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        ?? Vulcan_J = Vulcan_fq.Vulcan_J();
        try {
            int i = iIntValue;
            if (Vulcan_J == 0) {
                if (i < 0) {
                    return (-(((-iIntValue) - 1) / iIntValue2)) - 1;
                }
                i = iIntValue;
            }
            return i / iIntValue2;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_J);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_o(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Random r1 = (java.util.Random) r1
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r6 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r11 = r0
            r0 = r6
            r1 = r10
            r2 = r11
            if (r2 != 0) goto L58
            if (r0 < r1) goto L4d
            goto L45
        L41:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0     // Catch: java.lang.RuntimeException -> L49
        L45:
            r0 = r6
            goto L59
        L49:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L49
            throw r0
        L4d:
            r0 = r7
            r1 = r10
            r2 = r6
            int r1 = r1 - r2
            r2 = 1
            int r1 = r1 + r2
            int r0 = r0.nextInt(r1)
            r1 = r6
        L58:
            int r0 = r0 + r1
        L59:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_o(java.lang.Object[]):int");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static float Vulcan_h(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.util.Random r1 = (java.util.Random) r1
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r9 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r6 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Float r1 = (java.lang.Float) r1
            float r1 = r1.floatValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r6
            long r0 = r0 ^ r1
            r6 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r11 = r0
            r0 = r9
            r1 = r8
            r2 = r11
            if (r2 != 0) goto L5c
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L50
            goto L47
        L43:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0     // Catch: java.lang.RuntimeException -> L4c
        L47:
            r0 = r9
            goto L5d
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0
        L50:
            r0 = r10
            float r0 = r0.nextFloat()
            r1 = r8
            r2 = r9
            float r1 = r1 - r2
            float r0 = r0 * r1
            r1 = r9
        L5c:
            float r0 = r0 + r1
        L5d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_h(java.lang.Object[]):float");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static double Vulcan_P(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r13 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.util.Random r1 = (java.util.Random) r1
            r12 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r8 = r1
            r1 = r0
            r2 = 3
            r1 = r1[r2]
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            r10 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r13
            long r0 = r0 ^ r1
            r13 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r15 = r0
            r0 = r8
            r1 = r10
            r2 = r15
            if (r2 != 0) goto L5a
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 < 0) goto L50
            goto L48
        L44:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0     // Catch: java.lang.RuntimeException -> L4c
        L48:
            r0 = r8
            goto L5b
        L4c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L4c
            throw r0
        L50:
            r0 = r12
            double r0 = r0.nextDouble()
            r1 = r10
            r2 = r8
            double r1 = r1 - r2
            double r0 = r0 * r1
            r1 = r8
        L5a:
            double r0 = r0 + r1
        L5b:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_P(java.lang.Object[]):double");
    }

    public static double Vulcan_p(Object[] objArr) {
        long j;
        long[] jArr = (long[]) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        long j2 = 0;
        String[] strArrVulcan_J = Vulcan_fq.Vulcan_J();
        int length = jArr.length;
        int i = 0;
        while (i < length) {
            long j3 = jArr[i];
            if (jLongValue > 0) {
                j = j2 + j3;
                if (strArrVulcan_J != null) {
                    break;
                }
                j2 = j;
                i++;
            }
            if (strArrVulcan_J != null) {
                break;
            }
        }
        j = j2;
        return j / ((double) jArr.length);
    }

    public static int Vulcan_M(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        return ((iIntValue % iIntValue2) + iIntValue2) % iIntValue2;
    }

    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    public static float m620Vulcan_F(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        String[] strArrVulcan_J = Vulcan_fq.Vulcan_J();
        float f = fFloatValue % 360.0f;
        int i = (f > 180.0f ? 1 : (f == 180.0f ? 0 : -1));
        if (strArrVulcan_J == null) {
            if (i >= 0) {
                f -= 360.0f;
            }
            float f2 = f;
            if (strArrVulcan_J != null) {
                return f2;
            }
            i = (f2 > (-180.0f) ? 1 : (f2 == (-180.0f) ? 0 : -1));
        }
        if (i < 0) {
            f += 360.0f;
        }
        return f;
    }

    public static double Vulcan_i(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        double dDoubleValue = ((Double) objArr[1]).doubleValue();
        long j = a ^ jLongValue;
        String[] strArrVulcan_J = Vulcan_fq.Vulcan_J();
        double d = dDoubleValue % 360.0d;
        int i = (d > 180.0d ? 1 : (d == 180.0d ? 0 : -1));
        if (strArrVulcan_J == null) {
            if (i >= 0) {
                d -= 360.0d;
            }
            double d2 = d;
            if (strArrVulcan_J != null) {
                return d2;
            }
            i = (d2 > (-180.0d) ? 1 : (d2 == (-180.0d) ? 0 : -1));
        }
        if (i < 0) {
            d += 360.0d;
        }
        return d;
    }

    public static int Vulcan_r(Object[] objArr) {
        try {
            return Integer.parseInt((String) objArr[0]);
        } catch (Throwable th) {
            return ((Integer) objArr[1]).intValue();
        }
    }

    public static int Vulcan_m(Object[] objArr) {
        return Math.max(((Integer) objArr[2]).intValue(), Vulcan_r(new Object[]{(String) objArr[0], Integer.valueOf(((Integer) objArr[1]).intValue())}));
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static double m621Vulcan_Q(Object[] objArr) {
        try {
            return Double.parseDouble((String) objArr[0]);
        } catch (Throwable th) {
            return ((Double) objArr[1]).doubleValue();
        }
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.String] */
    /* JADX INFO: renamed from: Vulcan_f, reason: collision with other method in class */
    public static double m622Vulcan_f(Object[] objArr) {
        ?? r1 = (String) objArr[0];
        double dDoubleValue = ((Double) objArr[1]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[2]).doubleValue();
        Object[] objArr2 = new Object[2];
        r1[1] = Double.valueOf(dDoubleValue);
        objArr2[0] = objArr2;
        return Math.max(dDoubleValue2, m621Vulcan_Q(objArr2));
    }

    /* JADX INFO: renamed from: Vulcan_l, reason: collision with other method in class */
    public static int m623Vulcan_l(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue() - 1;
        int i = iIntValue | (iIntValue >> 1);
        int i2 = i | (i >> 2);
        int i3 = i2 | (i2 >> 4);
        int i4 = i3 | (i3 >> 8);
        return (i4 | (i4 >> 16)) + 1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX INFO: renamed from: Vulcan_F, reason: collision with other method in class */
    private static boolean m624Vulcan_F(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        ?? LongValue = a ^ ((Long) objArr[1]).longValue();
        try {
            LongValue = iIntValue;
            if (LongValue != 0) {
                try {
                    LongValue = iIntValue & (iIntValue - 1);
                    if (LongValue == 0) {
                        return true;
                    }
                } catch (RuntimeException unused) {
                    throw a((RuntimeException) LongValue);
                }
            }
            return false;
        } catch (RuntimeException unused2) {
            throw a((RuntimeException) LongValue);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v3, types: [long] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r1v3, types: [int] */
    /* JADX WARN: Type inference failed for: r2v4, types: [int, java.lang.Object[]] */
    private static int Vulcan_O(Object[] objArr) {
        ?? IntValue = ((Integer) objArr[0]).intValue();
        ?? LongValue = a ^ ((Long) objArr[1]).longValue();
        try {
            ?? r2 = new Object[2];
            IntValue[1] = Long.valueOf(LongValue ^ 24986217990112L);
            r2[0] = Integer.valueOf((int) r2);
            LongValue = m624Vulcan_F((Object[]) r2);
            return Vulcan_t[((int) ((((LongValue != 0 ? IntValue : m623Vulcan_l(new Object[]{Integer.valueOf((int) IntValue)})) == true ? 1L : 0L) * 125613361) >> 27)) & 31];
        } catch (RuntimeException unused) {
            throw a((RuntimeException) LongValue);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [long] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v9, types: [int] */
    /* JADX WARN: Type inference failed for: r1v7, types: [int] */
    /* JADX WARN: Type inference failed for: r2v6, types: [int, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v8, types: [int, java.lang.Object[]] */
    public static int Vulcan_A(Object[] objArr) {
        long jLongValue = ((Long) objArr[0]).longValue();
        ?? IntValue = ((Integer) objArr[1]).intValue();
        ?? Vulcan_O = a ^ jLongValue;
        long j = Vulcan_O ^ 49724085984822L;
        try {
            ?? r2 = new Object[2];
            IntValue[1] = Long.valueOf(Vulcan_O ^ 124624119224334L);
            r2[0] = Integer.valueOf((int) r2);
            Vulcan_O = Vulcan_O(r2);
            ?? r3 = new Object[2];
            IntValue[1] = Long.valueOf(j);
            r3[0] = Integer.valueOf((int) r3);
            return Vulcan_O - (m624Vulcan_F((Object[]) r3) ? 0 : 1);
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan_O);
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static int Vulcan_w(java.lang.Object[] r7) {
        /*
            r0 = r7
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r10 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r11 = r1
            r1 = r0
            r2 = 2
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r8 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_Ov.a
            r1 = r8
            long r0 = r0 ^ r1
            r8 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_fq.Vulcan_J()
            r12 = r0
            r0 = r11
            r1 = r12
            if (r1 != 0) goto L44
            if (r0 != 0) goto L43
            goto L3d
        L39:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3f
            throw r0     // Catch: java.lang.RuntimeException -> L3f
        L3d:
            r0 = 0
            return r0
        L3f:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L3f
            throw r0
        L43:
            r0 = r10
        L44:
            r1 = r12
            r2 = r8
            r3 = 0
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 <= 0) goto L63
            if (r1 != 0) goto L61
            if (r0 != 0) goto L60
            goto L59
        L55:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5c
            throw r0     // Catch: java.lang.RuntimeException -> L5c
        L59:
            r0 = r11
            return r0
        L5c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L5c
            throw r0
        L60:
            r0 = r10
        L61:
            r1 = r12
        L63:
            if (r1 != 0) goto L7a
            if (r0 >= 0) goto L76
            goto L70
        L6c:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L70:
            r0 = r11
            r1 = -1
            int r0 = r0 * r1
            r11 = r0
        L76:
            r0 = r10
            r1 = r11
            int r0 = r0 % r1
        L7a:
            r13 = r0
            r0 = r13
            r1 = r12
            if (r1 != 0) goto L99
            if (r0 != 0) goto L95
            goto L8d
        L89:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L91
            throw r0     // Catch: java.lang.RuntimeException -> L91
        L8d:
            r0 = r10
            goto L9c
        L91:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L91
            throw r0
        L95:
            r0 = r10
            r1 = r11
            int r0 = r0 + r1
        L99:
            r1 = r13
            int r0 = r0 - r1
        L9c:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_Ov.Vulcan_w(java.lang.Object[]):int");
    }

    /* JADX WARN: Type inference failed for: r0v5, types: [float] */
    /* JADX WARN: Type inference failed for: r1v27, types: [float] */
    /* JADX WARN: Type inference failed for: r2v20, types: [float] */
    /* JADX WARN: Type inference failed for: r2v6, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v8, types: [float, java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v12, types: [float, java.lang.Object[]] */
    public static int Vulcan_q(Object[] objArr) {
        float fFloatValue = ((Float) objArr[0]).floatValue();
        float fFloatValue2 = ((Float) objArr[1]).floatValue();
        float fFloatValue3 = ((Float) objArr[2]).floatValue();
        long jLongValue = (a ^ ((Long) objArr[3]).longValue()) ^ 135606148053497L;
        ?? r2 = new Object[2];
        (fFloatValue * 255.0f)[1] = Long.valueOf(jLongValue);
        r2[0] = Float.valueOf((float) r2);
        int iVulcan_v = Vulcan_v(r2);
        ?? r3 = new Object[2];
        (fFloatValue2 * 255.0f)[1] = Long.valueOf(jLongValue);
        r3[0] = Float.valueOf((float) r3);
        int iVulcan_v2 = Vulcan_v(r3);
        ?? r4 = new Object[2];
        (fFloatValue3 * 255.0f)[1] = Long.valueOf(jLongValue);
        r4[0] = Float.valueOf((float) r4);
        return Vulcan_X(new Object[]{Integer.valueOf(iVulcan_v), Integer.valueOf(iVulcan_v2), Integer.valueOf(Vulcan_v(r4))});
    }

    public static int Vulcan_X(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        return (((iIntValue << 8) + ((Integer) objArr[1]).intValue()) << 8) + ((Integer) objArr[2]).intValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v30, types: [int] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v37, types: [int] */
    public static int Vulcan_C(Object[] objArr) {
        int iIntValue = ((Integer) objArr[0]).intValue();
        int iIntValue2 = ((Integer) objArr[1]).intValue();
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        int i = (iIntValue & 16711680) >> 16;
        int i2 = (iIntValue2 & 16711680) >> 16;
        Vulcan_fq.Vulcan_J();
        int i3 = (int) ((i * i2) / 255.0f);
        ?? r0 = (int) ((((iIntValue & 255) >> 0) * ((iIntValue2 & 255) >> 0)) / 255.0f);
        try {
            r0 = (iIntValue & (-16777216)) | (i3 << 16) | (((int) ((((iIntValue & 65280) >> 8) * ((iIntValue2 & 65280) >> 8)) / 255.0f)) << 8) | r0;
            if (AbstractCheck.Vulcan_k() != null) {
                Vulcan_fq.Vulcan_E(new String[5]);
            }
            return r0;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) r0);
        }
    }

    /* JADX INFO: renamed from: Vulcan_p, reason: collision with other method in class */
    public static long m625Vulcan_p(Object[] objArr) {
        Vulcan_fq vulcan_fq = (Vulcan_fq) objArr[0];
        return m626Vulcan_r(new Object[]{Integer.valueOf(vulcan_fq.Vulcan_s(new Object[0])), Integer.valueOf(vulcan_fq.Vulcan_y(new Object[0])), Integer.valueOf(vulcan_fq.Vulcan_L(new Object[0]))});
    }

    /* JADX INFO: renamed from: Vulcan_r, reason: collision with other method in class */
    public static long m626Vulcan_r(Object[] objArr) {
        long jIntValue = (((long) (((Integer) objArr[0]).intValue() * 3129871)) ^ (((long) ((Integer) objArr[2]).intValue()) * 116129781)) ^ ((long) ((Integer) objArr[1]).intValue());
        return (jIntValue * jIntValue * 42317861) + (jIntValue * 11);
    }

    /* JADX INFO: renamed from: Vulcan_Q, reason: collision with other method in class */
    public static UUID m627Vulcan_Q(Object[] objArr) {
        Random random = (Random) objArr[0];
        return new UUID((random.nextLong() & (-61441)) | 16384, (random.nextLong() & 4611686018427387903L) | Long.MIN_VALUE);
    }
}
