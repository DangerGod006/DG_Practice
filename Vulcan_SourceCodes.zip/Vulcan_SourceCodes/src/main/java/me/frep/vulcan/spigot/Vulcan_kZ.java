package me.frep.vulcan.spigot;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kZ.class */
public class Vulcan_kZ {
    private String Vulcan_B;
    private String Vulcan_t;
    private String Vulcan_q;
    private Color Vulcan_U;
    private Vulcan_OJ Vulcan_S;
    private Vulcan_Og Vulcan_H;
    private Vulcan_y8 Vulcan_b;
    private Vulcan_E Vulcan_X;
    private List Vulcan_h = new ArrayList();

    public String Vulcan_w(Object[] objArr) {
        return this.Vulcan_B;
    }

    public String Vulcan_c(Object[] objArr) {
        return this.Vulcan_t;
    }

    public String Vulcan_a(Object[] objArr) {
        return this.Vulcan_q;
    }

    public Color Vulcan_G(Object[] objArr) {
        return this.Vulcan_U;
    }

    public Vulcan_OJ Vulcan_U(Object[] objArr) {
        return this.Vulcan_S;
    }

    public Vulcan_Og Vulcan_m(Object[] objArr) {
        return this.Vulcan_H;
    }

    public Vulcan_y8 Vulcan_y(Object[] objArr) {
        return this.Vulcan_b;
    }

    public Vulcan_E Vulcan_L(Object[] objArr) {
        return this.Vulcan_X;
    }

    public List Vulcan_I(Object[] objArr) {
        return this.Vulcan_h;
    }

    public Vulcan_kZ Vulcan_W(Object[] objArr) {
        this.Vulcan_B = (String) objArr[0];
        return this;
    }

    /* JADX INFO: renamed from: Vulcan_G, reason: collision with other method in class */
    public Vulcan_kZ m855Vulcan_G(Object[] objArr) {
        this.Vulcan_t = (String) objArr[0];
        return this;
    }

    /* JADX INFO: renamed from: Vulcan_I, reason: collision with other method in class */
    public Vulcan_kZ m856Vulcan_I(Object[] objArr) {
        this.Vulcan_q = (String) objArr[0];
        return this;
    }

    public Vulcan_kZ Vulcan_x(Object[] objArr) {
        this.Vulcan_U = (Color) objArr[0];
        return this;
    }

    public Vulcan_kZ Vulcan_g(Object[] objArr) {
        this.Vulcan_S = new Vulcan_OJ(this, (String) objArr[0], (String) objArr[1], null);
        return this;
    }

    public Vulcan_kZ Vulcan_h(Object[] objArr) {
        this.Vulcan_H = new Vulcan_Og(this, (String) objArr[0], null);
        return this;
    }

    public Vulcan_kZ Vulcan_R(Object[] objArr) {
        this.Vulcan_b = new Vulcan_y8(this, (String) objArr[0], null);
        return this;
    }

    public Vulcan_kZ Vulcan_e(Object[] objArr) {
        this.Vulcan_X = new Vulcan_E(this, (String) objArr[0], (String) objArr[1], (String) objArr[2], null);
        return this;
    }

    public Vulcan_kZ Vulcan_K(Object[] objArr) {
        this.Vulcan_h.add(new Vulcan_OE(this, (String) objArr[0], (String) objArr[1], ((Boolean) objArr[2]).booleanValue(), null));
        return this;
    }
}
