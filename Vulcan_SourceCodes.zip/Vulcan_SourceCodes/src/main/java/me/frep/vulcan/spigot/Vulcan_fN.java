package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fN.class */
public final class Vulcan_fN {
    private static final long a = Vulcan_n.a(-7422083029792808474L, -7723113836132336011L, MethodHandles.lookup().lookupClass()).a(198033158380756L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00f0: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public static void Vulcan_c(java.lang.Object[] r11) {
        /*
            Method dump skipped, instruction units count: 1229
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fN.Vulcan_c(java.lang.Object[]):void");
    }

    static {
        int i;
        long j = a ^ 107816358589751L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[97];
        int i3 = 0;
        String str = "\u007f¼ühJU\u0012\u008d±T\u001d»SÏÊ.äK-þ\u0089\u009bô/\u0010Ã¯\u000f¯\u0007\u0018<\u009b£Ü\u0084_Kû\u0089è G\u0098ÜÀ¹¾÷¼JÒ;\u0015aIbÍ7Çíãª¬!ÜøûVèñ9~ÿ\u0010PD¸];¢\u00addt4\u00981\u0007[-Ë\bEZ\u009c¤ãÖ{!\bz¾Q¶k\u0089åp\u0010\tµ\u009fX¹i¨TÐ-êa16\u0099ò\u0010¡@YÓW9\u001bËdÀT\u0019\u009aûø;\u0010Ê¬ùûÛ\u0083¨\u001c>G×ªð¯N\b G\u0098ÜÀ¹¾÷¼ù\u0098êÿÚK1à\u0097%:±\u0091ÅÍ\u0095q¹þ\u009bíU\u009c_\u0010§ \u009bÎnI\u0002¿\u008b}É+9Ïy\u0013\u0010ëbß\u0081¶hÜ\u001c|Fðp\u0092\u008fJ_\u0010PD¸];¢\u00addt4\u00981\u0007[-Ë\u0018\u0083ÕLÊ\u00038´\u009eTJh\u000bo\u00ad0ªªüÁ\u008fl²Ý~ b\u009c\u0016/\u0003\u000b\u0097nÝÈ\rêÍtµPL{\u009e\u0093ÌØ, 0Ê\u0016&à\u008c¾ê\b\u008c\u0013ÓÜ7Ì£G\u0010&ùPpf×b_\u001f¸ñ\u0084nú\u008dî\u0018ÉyiÕI\u0019\u0011\u0004ÿvß\u0097©çø,~\u009f\f3%:\u0080\u000b\u0018ÀM\u0010ìs\u0019&ß%{Ãq8Ø~*JL\u008ds\u009d\u007f\u0015m\b\u0012\u009aIl\tIvÍ\u0010\u008d|bàì\rCÿË©C\u001a9øj\u00ad\u0018G\u0098ÜÀ¹¾÷¼ÀÎW\rt\u0094\u009bU\u0087ê¨5¥\u0005,º\u0018b\u009c\u0016/\u0003\u000b\u0097nð×\u0091°\u0081J¥2<¯$9ø\u000e\u00014\u0010&ùPpf×b_\u001f¸ñ\u0084nú\u008dî\u0010² õüì1\u008dî_\u001c\u0096\u0081\u0090ûã'8½ªc\u008a\u0099°\u00837#Íö *VÚø\u0017µZù×\u0012¢\u0012\u009f_Å(ÞÈp\u008aî\u0019\u008c\b\u000fþUHñMÑ**{H\u0083ÂÏ¹ü<ÏD\u0004\u0010\u001f[rWßYVÐQ°fbÎ>n¬\u0018\u0005Ëlà¦^K=±ôO\u009d\u009et}Z\u0089;2:'k¬ã\b},ýá\u0089KÚÙ\u00106JÜ\u0007\u008dV\u001bÂL°\u0084é«µ@\u000e\b¸k5H^¬\u000f\u0090\u0010ç,ì\u00ad\f\u0010Zá_!K \u0094\u008d\u0084© ¤\tÜø0\u00130Üa:@³Ê=\u007fôÇ\u0095ïpß²¦ZO×mù*\u0096\u0088\u001b G\u0098ÜÀ¹¾÷¼²bm²,<An`\u0004\u008c¬\u008f\u0099\u0001¬SØ_\u0011  ±r\u0010M\r\u0018uÊß²\u001c¹0\u0003g½î\u009cÀ G\u0098ÜÀ¹¾÷¼w¹\u00ad\u000b\u0080\u000fº\u000etÜ\u008b\u000e\u009a¨¯øÆ\u007f\u0011Dfê³\u008b G\u0098ÜÀ¹¾÷¼-\u0096?dõþ\u001f8\u008bÛ\u0012'¼\u0088>¼\u0002Î\u001ar\u0099¥\u0015r Ð%2Õæ\u0014 *Cù½j\u001dÓX\u0088ØH¸³¶>Ìå\u008eQëÏ¤\u001b\u0080§\bJzEHèªÏð\u0010@ò_n{W\u0081ÜÜµ·\u000b»\u001e¾\u001d G\u0098ÜÀ¹¾÷¼\u0005R`Þ\u0096³\u009b\u008c\u0000vÖ$º\u008d\u009c>°\u0007x\u0091ªó1C\u0018Ð%2Õæ\u0014 *\u001aZôð[ûIwðT¾A)\u007fÔ¬\u0018À\u000e\u001d\u000bÚ¶¦Xu\u0089\tôáRC\u000e¡ð\u008a;©\u009cxr\u0010\b\u0081X\u0019nu\u0014\u0085;óü\u001ax\u0012ú\u001d úN!ö#oLï\u0016ÆÁ\u0091Í\u0089+D\u009d¨z®ê(1@\u000el\u0098S\u00175\u008b\u008e\b%tAì«\u009c'Ù\bt\u0081E©ÎÒã4\u0018\u001eñ`»Q\u008e/\u008eÔ¯ãr\u0094Qðá\u000fù\u008d\u008bR]\u0012·\u0010v«\u0003\u0019ÝFZj×à³Y \u0087¨\u009ePöx\u0019$UX\u0098¥K±T2ê÷Õã\u0091ë\u0084\fu¬Á7Å½-,-dú %Ô±è¾zm:3\u0014ÏÃ \u0012\\\u001e?i3\t:qg\t\u0002®ãájOî\u0080ü\"Ñ6\r\u008a½bF»\u0010Ø:½o.\u0010\b\u0081X\u0019nu\u0014\u0085;óü\u001ax\u0012ú\u001d\u0010\u0094O\u008e\u001dÕU®ÑMß\nå²R°ã\b¿YæÖû;tÂ\bÏ\u0091 z\u000bY\r@\u0010ëbß\u0081¶hÜ\u001c|Fðp\u0092\u008fJ_\u0018\u009e\u001b\u000f-\u0016.@\u0084\u0010\f6\rJ¦_¸ÓÉyZ\u0097Â\u0091H Ð%2Õæ\u0014 *v\u0007\u0084\u0099+(\u0099°óQ\u008c\b%\u0097\u001c\u0091çü\u0007ú.¤H`\bEZ\u009c¤ãÖ{!\u0018öx\u0019$UX\u0098¥oØ\u0003!](C°õ\u0088\u009a\u001cz;D9\b\u008c\u0013ÓÜ7Ì£G\u0010W\u008f\u0086ý\nMércH\nKmÊçG\u0010>\u0088òé\u0016¡Ó8«åÍ7\u0089\u001dvÇ\u0018üQ¸0T\u007f2\u0092í Èeò \u0002M#¬\u008e\u0097½R\u009aó\b*ØCàÚî\u000ex G\u0098ÜÀ¹¾÷¼ì©H\u0007fô5Lª=\t5µÐUó\u008d\u0086&?\u0016*®T\u0010h°\u0089\u001dDëz\n{gß\\\u0084xcS b\u009c\u0016/\u0003\u000b\u0097nÝÈ\rêÍtµP\u0090\u001búÁR']\u007fÕÌõúã\u0016\u008bõ\u0010¤B<îS\u0097õ8È\u0019H\u0084Z\u007fâ4\b\u009a\u007f·ë§Ã\u0090M\bG\u009a|à´¯\b\u0013\b\u000b²iJP\u0010\u009cý G\u0098ÜÀ¹¾÷¼\r\u001aíí\u0013\\V\u00120\u0085þ\u0095Â9\u0096/Âc\u0018£eC3d\u0010NTöüm\u0006\u001c»\u001a\u0006]ëíÚhå\b>*Ø-Ç¹T?\b\u0089\u0094Ô\u000b%T\u0003n\u0018\u0081\u009f2V:'|â¡\u000b1*5ìÂØ5õ!)+é\rÚ\bÎîà\u0090Þ*>e\bGáM\u0091í<ýt\u0010¡@YÓW9\u001bËdÀT\u0019\u009aûø;\bÒù\u008eÃî«/D\u0010x£ã×^\u0085êý³È\u0084Z×Õ`0\b¢Q+´÷\u008aý\u0097\b¿YæÖû;tÂ\u0018ì©¡u«|{\\S9È\u00ad|Ú\u0098·(\u0005ý\u0086È\u001euÑ\bS\u000bÎ[\u009d«}6\btØ×_\u0012ªaÖ\u0018Î\u001a°\u001c\u0010\u0083îëÎ¤wÆ\u0092Ü#\u001fG¨VQ/'8ú\u0010|ìv\"Q\u0002Ç#\u0093\u0094\u00995pº^¸\ba!<¨'¾D\f\u0018¨ü`Í\u0018dÆO;ð¯¾\u009c7én+\u008bÙ·ÁKEé\u0010%\u0087ÍnE\r¨Þx\u0094]\u0090\u008aüÛ\u0003\u0010:µ\u0085\u008bg8ø\b¶Ç]y,$ÛA\b\u0013oÐfèP\u0090ù\u0018£+ôXQ\u0096\u0081\u0006\u0099·á8½c¡ÐI×\u0084(\u008fA\u0091³\u0018û\u008b\u009c\u008aü\n÷Ö\u008aµ\u009e[\u008c\u0093¿=\u0085UÅîfN¢\u0092";
        int length = "\u007f¼ühJU\u0012\u008d±T\u001d»SÏÊ.äK-þ\u0089\u009bô/\u0010Ã¯\u000f¯\u0007\u0018<\u009b£Ü\u0084_Kû\u0089è G\u0098ÜÀ¹¾÷¼JÒ;\u0015aIbÍ7Çíãª¬!ÜøûVèñ9~ÿ\u0010PD¸];¢\u00addt4\u00981\u0007[-Ë\bEZ\u009c¤ãÖ{!\bz¾Q¶k\u0089åp\u0010\tµ\u009fX¹i¨TÐ-êa16\u0099ò\u0010¡@YÓW9\u001bËdÀT\u0019\u009aûø;\u0010Ê¬ùûÛ\u0083¨\u001c>G×ªð¯N\b G\u0098ÜÀ¹¾÷¼ù\u0098êÿÚK1à\u0097%:±\u0091ÅÍ\u0095q¹þ\u009bíU\u009c_\u0010§ \u009bÎnI\u0002¿\u008b}É+9Ïy\u0013\u0010ëbß\u0081¶hÜ\u001c|Fðp\u0092\u008fJ_\u0010PD¸];¢\u00addt4\u00981\u0007[-Ë\u0018\u0083ÕLÊ\u00038´\u009eTJh\u000bo\u00ad0ªªüÁ\u008fl²Ý~ b\u009c\u0016/\u0003\u000b\u0097nÝÈ\rêÍtµPL{\u009e\u0093ÌØ, 0Ê\u0016&à\u008c¾ê\b\u008c\u0013ÓÜ7Ì£G\u0010&ùPpf×b_\u001f¸ñ\u0084nú\u008dî\u0018ÉyiÕI\u0019\u0011\u0004ÿvß\u0097©çø,~\u009f\f3%:\u0080\u000b\u0018ÀM\u0010ìs\u0019&ß%{Ãq8Ø~*JL\u008ds\u009d\u007f\u0015m\b\u0012\u009aIl\tIvÍ\u0010\u008d|bàì\rCÿË©C\u001a9øj\u00ad\u0018G\u0098ÜÀ¹¾÷¼ÀÎW\rt\u0094\u009bU\u0087ê¨5¥\u0005,º\u0018b\u009c\u0016/\u0003\u000b\u0097nð×\u0091°\u0081J¥2<¯$9ø\u000e\u00014\u0010&ùPpf×b_\u001f¸ñ\u0084nú\u008dî\u0010² õüì1\u008dî_\u001c\u0096\u0081\u0090ûã'8½ªc\u008a\u0099°\u00837#Íö *VÚø\u0017µZù×\u0012¢\u0012\u009f_Å(ÞÈp\u008aî\u0019\u008c\b\u000fþUHñMÑ**{H\u0083ÂÏ¹ü<ÏD\u0004\u0010\u001f[rWßYVÐQ°fbÎ>n¬\u0018\u0005Ëlà¦^K=±ôO\u009d\u009et}Z\u0089;2:'k¬ã\b},ýá\u0089KÚÙ\u00106JÜ\u0007\u008dV\u001bÂL°\u0084é«µ@\u000e\b¸k5H^¬\u000f\u0090\u0010ç,ì\u00ad\f\u0010Zá_!K \u0094\u008d\u0084© ¤\tÜø0\u00130Üa:@³Ê=\u007fôÇ\u0095ïpß²¦ZO×mù*\u0096\u0088\u001b G\u0098ÜÀ¹¾÷¼²bm²,<An`\u0004\u008c¬\u008f\u0099\u0001¬SØ_\u0011  ±r\u0010M\r\u0018uÊß²\u001c¹0\u0003g½î\u009cÀ G\u0098ÜÀ¹¾÷¼w¹\u00ad\u000b\u0080\u000fº\u000etÜ\u008b\u000e\u009a¨¯øÆ\u007f\u0011Dfê³\u008b G\u0098ÜÀ¹¾÷¼-\u0096?dõþ\u001f8\u008bÛ\u0012'¼\u0088>¼\u0002Î\u001ar\u0099¥\u0015r Ð%2Õæ\u0014 *Cù½j\u001dÓX\u0088ØH¸³¶>Ìå\u008eQëÏ¤\u001b\u0080§\bJzEHèªÏð\u0010@ò_n{W\u0081ÜÜµ·\u000b»\u001e¾\u001d G\u0098ÜÀ¹¾÷¼\u0005R`Þ\u0096³\u009b\u008c\u0000vÖ$º\u008d\u009c>°\u0007x\u0091ªó1C\u0018Ð%2Õæ\u0014 *\u001aZôð[ûIwðT¾A)\u007fÔ¬\u0018À\u000e\u001d\u000bÚ¶¦Xu\u0089\tôáRC\u000e¡ð\u008a;©\u009cxr\u0010\b\u0081X\u0019nu\u0014\u0085;óü\u001ax\u0012ú\u001d úN!ö#oLï\u0016ÆÁ\u0091Í\u0089+D\u009d¨z®ê(1@\u000el\u0098S\u00175\u008b\u008e\b%tAì«\u009c'Ù\bt\u0081E©ÎÒã4\u0018\u001eñ`»Q\u008e/\u008eÔ¯ãr\u0094Qðá\u000fù\u008d\u008bR]\u0012·\u0010v«\u0003\u0019ÝFZj×à³Y \u0087¨\u009ePöx\u0019$UX\u0098¥K±T2ê÷Õã\u0091ë\u0084\fu¬Á7Å½-,-dú %Ô±è¾zm:3\u0014ÏÃ \u0012\\\u001e?i3\t:qg\t\u0002®ãájOî\u0080ü\"Ñ6\r\u008a½bF»\u0010Ø:½o.\u0010\b\u0081X\u0019nu\u0014\u0085;óü\u001ax\u0012ú\u001d\u0010\u0094O\u008e\u001dÕU®ÑMß\nå²R°ã\b¿YæÖû;tÂ\bÏ\u0091 z\u000bY\r@\u0010ëbß\u0081¶hÜ\u001c|Fðp\u0092\u008fJ_\u0018\u009e\u001b\u000f-\u0016.@\u0084\u0010\f6\rJ¦_¸ÓÉyZ\u0097Â\u0091H Ð%2Õæ\u0014 *v\u0007\u0084\u0099+(\u0099°óQ\u008c\b%\u0097\u001c\u0091çü\u0007ú.¤H`\bEZ\u009c¤ãÖ{!\u0018öx\u0019$UX\u0098¥oØ\u0003!](C°õ\u0088\u009a\u001cz;D9\b\u008c\u0013ÓÜ7Ì£G\u0010W\u008f\u0086ý\nMércH\nKmÊçG\u0010>\u0088òé\u0016¡Ó8«åÍ7\u0089\u001dvÇ\u0018üQ¸0T\u007f2\u0092í Èeò \u0002M#¬\u008e\u0097½R\u009aó\b*ØCàÚî\u000ex G\u0098ÜÀ¹¾÷¼ì©H\u0007fô5Lª=\t5µÐUó\u008d\u0086&?\u0016*®T\u0010h°\u0089\u001dDëz\n{gß\\\u0084xcS b\u009c\u0016/\u0003\u000b\u0097nÝÈ\rêÍtµP\u0090\u001búÁR']\u007fÕÌõúã\u0016\u008bõ\u0010¤B<îS\u0097õ8È\u0019H\u0084Z\u007fâ4\b\u009a\u007f·ë§Ã\u0090M\bG\u009a|à´¯\b\u0013\b\u000b²iJP\u0010\u009cý G\u0098ÜÀ¹¾÷¼\r\u001aíí\u0013\\V\u00120\u0085þ\u0095Â9\u0096/Âc\u0018£eC3d\u0010NTöüm\u0006\u001c»\u001a\u0006]ëíÚhå\b>*Ø-Ç¹T?\b\u0089\u0094Ô\u000b%T\u0003n\u0018\u0081\u009f2V:'|â¡\u000b1*5ìÂØ5õ!)+é\rÚ\bÎîà\u0090Þ*>e\bGáM\u0091í<ýt\u0010¡@YÓW9\u001bËdÀT\u0019\u009aûø;\bÒù\u008eÃî«/D\u0010x£ã×^\u0085êý³È\u0084Z×Õ`0\b¢Q+´÷\u008aý\u0097\b¿YæÖû;tÂ\u0018ì©¡u«|{\\S9È\u00ad|Ú\u0098·(\u0005ý\u0086È\u001euÑ\bS\u000bÎ[\u009d«}6\btØ×_\u0012ªaÖ\u0018Î\u001a°\u001c\u0010\u0083îëÎ¤wÆ\u0092Ü#\u001fG¨VQ/'8ú\u0010|ìv\"Q\u0002Ç#\u0093\u0094\u00995pº^¸\ba!<¨'¾D\f\u0018¨ü`Í\u0018dÆO;ð¯¾\u009c7én+\u008bÙ·ÁKEé\u0010%\u0087ÍnE\r¨Þx\u0094]\u0090\u008aüÛ\u0003\u0010:µ\u0085\u008bg8ø\b¶Ç]y,$ÛA\b\u0013oÐfèP\u0090ù\u0018£+ôXQ\u0096\u0081\u0006\u0099·á8½c¡ÐI×\u0084(\u008fA\u0091³\u0018û\u008b\u009c\u008aü\n÷Ö\u008aµ\u009e[\u008c\u0093¿=\u0085UÅîfN¢\u0092".length();
        char cCharAt = 24;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "aåÎ¼ÖS\u0018Û\u0089ZU\u0007ëu¢]\u00101\u000bø\u0006\fÖïG!\u008a\nÛ\u008a|\u0087s";
                        length = "aåÎ¼ÖS\u0018Û\u0089ZU\u0007ëu¢]\u00101\u000bø\u0006\fÖïG!\u008a\nÛ\u008a|\u0087s".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_fN() {
        throw new UnsupportedOperationException(b[25]);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static final java.lang.String Vulcan_O(java.lang.Object[] r5) {
        /*
            r0 = r5
            r1 = r0
            r2 = 0
            r1 = r1[r2]
            java.lang.Long r1 = (java.lang.Long) r1
            long r1 = r1.longValue()
            r7 = r1
            r1 = r0
            r2 = 1
            r1 = r1[r2]
            java.lang.String r1 = (java.lang.String) r1
            r6 = r1
            long r0 = me.frep.vulcan.spigot.Vulcan_fN.a
            r1 = r7
            long r0 = r0 ^ r1
            r7 = r0
            me.frep.vulcan.spigot.check.AbstractCheck[] r0 = me.frep.vulcan.spigot.Vulcan_OM.Vulcan_q()
            r9 = r0
            r0 = r6
            r1 = r9
            if (r1 == 0) goto L50
            if (r0 == 0) goto L48
            goto L2e
        L2a:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L37
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L37
        L2e:
            r0 = r6
            r1 = r9
            if (r1 == 0) goto L6f
            goto L3b
        L37:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L44
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L44
        L3b:
            int r0 = r0.length()     // Catch: java.lang.UnsupportedOperationException -> L44 java.lang.UnsupportedOperationException -> L4c
            if (r0 != 0) goto L51
            goto L48
        L44:
            java.lang.Exception r0 = a(r0)     // Catch: java.lang.UnsupportedOperationException -> L4c
            throw r0     // Catch: java.lang.UnsupportedOperationException -> L4c
        L48:
            r0 = r6
            goto L50
        L4c:
            java.lang.Exception r0 = a(r0)
            throw r0
        L50:
            return r0
        L51:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r1 = r0
            r1.<init>()
            r1 = r6
            r2 = 0
            r3 = 1
            java.lang.String r1 = r1.substring(r2, r3)
            java.lang.String r1 = r1.toUpperCase()
            java.lang.StringBuilder r0 = r0.append(r1)
            r1 = r6
            r2 = 1
            java.lang.String r1 = r1.substring(r2)
            java.lang.StringBuilder r0 = r0.append(r1)
            java.lang.String r0 = r0.toString()
        L6f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fN.Vulcan_O(java.lang.Object[]):java.lang.String");
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x0a8d, code lost:
    
        if (r0 == 0) goto L104;
     */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x0a90, code lost:
    
        r0 = r0;
        r0.println(me.frep.vulcan.spigot.Vulcan_fN.b[42] + r1.m639Vulcan_M(new java.lang.Object[0]).m878Vulcan_N(new java.lang.Object[0]));
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x0ac1, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x0ac2, code lost:
    
        r1 = new java.lang.StringBuilder();
        r2 = me.frep.vulcan.spigot.Vulcan_fN.b;
        r0.println(r1.append(r2[17]).append(r1.Vulcan_e(new java.lang.Object[0]).getActivePotionEffects()).toString());
        r0.println(r2[49]);
        r0.println("");
        r0.println("");
        r0.flush();
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:131:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x09bf, code lost:
    
        if (r0 == 0) goto L108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x09c2, code lost:
    
        r0 = r1.m639Vulcan_M(new java.lang.Object[0]).m886Vulcan_D(new java.lang.Object[0]);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x09d4, code lost:
    
        if (r0 == null) goto L100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x09da, code lost:
    
        r0 = a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x09dd, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x09de, code lost:
    
        if (r0 == 0) goto L99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x09e7, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x09e8, code lost:
    
        r0.println(me.frep.vulcan.spigot.Vulcan_fN.b[16] + r1.m639Vulcan_M(new java.lang.Object[0]).m886Vulcan_D(new java.lang.Object[0]));
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x0a15, code lost:
    
        if (r0 != 0) goto L99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x0a1e, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x0a1f, code lost:
    
        r0 = r1.m639Vulcan_M(new java.lang.Object[0]).Vulcan_c(new java.lang.Object[0]);
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:86:0x0a32, code lost:
    
        if (r0 < 0) goto L100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x0a35, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x0a37, code lost:
    
        if (r0 == null) goto L100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0a40, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x0a41, code lost:
    
        if (r0 == null) goto L99;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x0a4a, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x0a4b, code lost:
    
        r0.println(me.frep.vulcan.spigot.Vulcan_fN.b[23] + r1.m639Vulcan_M(new java.lang.Object[0]).Vulcan_c(new java.lang.Object[0]));
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0a7c, code lost:
    
        throw a((java.lang.Exception) r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0a7d, code lost:
    
        r0 = r1.m639Vulcan_M(new java.lang.Object[0]).m878Vulcan_N(new java.lang.Object[0]);
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:129:0x09bc A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x074e  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0906  */
    /* JADX WARN: Type inference failed for: r0v101, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v102, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v105, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v107 */
    /* JADX WARN: Type inference failed for: r0v108 */
    /* JADX WARN: Type inference failed for: r0v109, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v111, types: [java.io.PrintWriter] */
    /* JADX WARN: Type inference failed for: r0v121, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v128, types: [me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Type inference failed for: r0v129, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v130, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v131, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v134, types: [int] */
    /* JADX WARN: Type inference failed for: r0v147, types: [java.io.PrintWriter] */
    /* JADX WARN: Type inference failed for: r0v148, types: [java.io.PrintWriter, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v150 */
    /* JADX WARN: Type inference failed for: r0v151 */
    /* JADX WARN: Type inference failed for: r0v152 */
    /* JADX WARN: Type inference failed for: r0v155 */
    /* JADX WARN: Type inference failed for: r0v156 */
    /* JADX WARN: Type inference failed for: r0v157 */
    /* JADX WARN: Type inference failed for: r0v158 */
    /* JADX WARN: Type inference failed for: r0v159 */
    /* JADX WARN: Type inference failed for: r0v160 */
    /* JADX WARN: Type inference failed for: r0v161 */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.text.DateFormat, java.text.SimpleDateFormat] */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v75, types: [int, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v79, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.io.File, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v95, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v99, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r1v246, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r1v28, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r22v0, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r2v97, types: [java.text.DecimalFormat] */
    /* JADX WARN: Type inference failed for: r4v14, types: [java.lang.Object[], java.text.DecimalFormat] */
    /* JADX WARN: Type inference failed for: r4v25, types: [java.lang.Object[], java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r4v3, types: [java.lang.Object[], java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r4v33, types: [java.lang.Object[], me.frep.vulcan.spigot.check.AbstractCheck] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:68:0x09b9 -> B:53:0x08f6). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_l(java.lang.Object[] r9) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 2846
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fN.Vulcan_l(java.lang.Object[]):void");
    }
}
