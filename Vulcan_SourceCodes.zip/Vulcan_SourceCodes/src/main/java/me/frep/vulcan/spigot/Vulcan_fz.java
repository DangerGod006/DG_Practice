package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import org.bukkit.Location;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fz.class */
public final class Vulcan_fz {
    private double Vulcan_m;
    private double Vulcan_t;
    private double Vulcan_E;
    private double Vulcan_v;
    private double Vulcan_W;
    private double Vulcan_U;
    private final long Vulcan_K;
    private static int[] Vulcan_o;
    private static final long a = Vulcan_n.a(-3121565596375816913L, 4504076957045894052L, MethodHandles.lookup().lookupClass()).a(79528636612615L);

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x00c5: INVOKE (r-1 I:me.frep.vulcan.spigot.Vulcan_O), (r0 I:java.lang.Object[]) VIRTUAL call: me.frep.vulcan.spigot.Vulcan_O.Vulcan_m(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_O
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public me.frep.vulcan.spigot.Vulcan_d Vulcan_e(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 1422
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fz.Vulcan_e(java.lang.Object[]):me.frep.vulcan.spigot.Vulcan_d");
    }

    public static void Vulcan_f(int[] iArr) {
        Vulcan_o = iArr;
    }

    public static int[] Vulcan_K() {
        return Vulcan_o;
    }

    static {
        if (Vulcan_K() == null) {
            Vulcan_f(new int[1]);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public void Vulcan_Y(Object[] objArr) {
        this.Vulcan_m = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_W(Object[] objArr) {
        this.Vulcan_t = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_N(Object[] objArr) {
        this.Vulcan_E = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_x, reason: collision with other method in class */
    public void m835Vulcan_x(Object[] objArr) {
        this.Vulcan_v = ((Double) objArr[0]).doubleValue();
    }

    public void Vulcan_I(Object[] objArr) {
        this.Vulcan_W = ((Double) objArr[0]).doubleValue();
    }

    /* JADX INFO: renamed from: Vulcan_S, reason: collision with other method in class */
    public void m836Vulcan_S(Object[] objArr) {
        this.Vulcan_U = ((Double) objArr[0]).doubleValue();
    }

    public double Vulcan_Q(Object[] objArr) {
        return this.Vulcan_m;
    }

    public double Vulcan_S(Object[] objArr) {
        return this.Vulcan_t;
    }

    public double Vulcan_H(Object[] objArr) {
        return this.Vulcan_E;
    }

    public double Vulcan_u(Object[] objArr) {
        return this.Vulcan_v;
    }

    /* JADX INFO: renamed from: Vulcan_T, reason: collision with other method in class */
    public double m833Vulcan_T(Object[] objArr) {
        return this.Vulcan_W;
    }

    public double Vulcan_q(Object[] objArr) {
        return this.Vulcan_U;
    }

    /* JADX INFO: renamed from: Vulcan_H, reason: collision with other method in class */
    public long m834Vulcan_H(Object[] objArr) {
        return this.Vulcan_K;
    }

    public Vulcan_fz(double d, double d2, double d3) {
        this(d, d, d2, d2, d3, d3);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r0v23, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v29 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    public Vulcan_fz(double d, double d2, double d3, double d4, double d5, double d6) {
        long j = a ^ 42920139057904L;
        ?? Vulcan_K = Vulcan_K();
        try {
            try {
                try {
                    this.Vulcan_K = System.currentTimeMillis();
                    Vulcan_K = Vulcan_K;
                    if (Vulcan_K != 0) {
                        if (d < d2) {
                            this.Vulcan_m = d;
                            this.Vulcan_v = d2;
                            if (Vulcan_K == 0) {
                            }
                        }
                        this.Vulcan_m = d2;
                        this.Vulcan_v = d;
                    } else {
                        this.Vulcan_v = d;
                    }
                    ?? r0 = (d3 > d4 ? 1 : (d3 == d4 ? 0 : -1));
                    try {
                        if (r0 < 0) {
                            try {
                                this.Vulcan_t = d3;
                                this.Vulcan_W = d4;
                                r0 = Vulcan_K;
                                if (r0 == 0) {
                                    this.Vulcan_t = d4;
                                    this.Vulcan_W = d3;
                                }
                            } catch (RuntimeException unused) {
                                throw a(r0);
                            }
                        } else {
                            this.Vulcan_t = d4;
                            this.Vulcan_W = d3;
                        }
                        ?? r02 = (d5 > d6 ? 1 : (d5 == d6 ? 0 : -1));
                        if (r02 < 0) {
                            try {
                                try {
                                    this.Vulcan_E = d5;
                                    this.Vulcan_U = d6;
                                    r02 = Vulcan_K;
                                    if (r02 != 0) {
                                        return;
                                    }
                                } catch (RuntimeException unused2) {
                                    throw a(r02);
                                }
                            } catch (RuntimeException unused3) {
                                throw a(r02);
                            }
                        }
                        this.Vulcan_E = d6;
                        this.Vulcan_U = d5;
                    } catch (RuntimeException unused4) {
                        throw a(r0);
                    }
                } catch (RuntimeException unused5) {
                    throw a(Vulcan_K);
                }
            } catch (RuntimeException unused6) {
                throw a(Vulcan_K);
            }
        } catch (RuntimeException unused7) {
            throw a(Vulcan_K);
        }
    }

    public double Vulcan_o(Object[] objArr) {
        Location location = (Location) objArr[0];
        return Math.sqrt(Math.min(Math.pow(location.getX() - this.Vulcan_m, 2.0d), Math.pow(location.getX() - this.Vulcan_v, 2.0d)) + Math.min(Math.pow(location.getZ() - this.Vulcan_E, 2.0d), Math.pow(location.getZ() - this.Vulcan_U, 2.0d)));
    }

    public double Vulcan_i(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        return Math.sqrt(Math.min(Math.pow(dDoubleValue - this.Vulcan_m, 2.0d), Math.pow(dDoubleValue - this.Vulcan_v, 2.0d)) + Math.min(Math.pow(dDoubleValue2 - this.Vulcan_E, 2.0d), Math.pow(dDoubleValue2 - this.Vulcan_U, 2.0d)));
    }

    public double Vulcan_y(Object[] objArr) {
        Vulcan_fz vulcan_fz = (Vulcan_fz) objArr[0];
        return Math.sqrt(Math.min(Math.pow(vulcan_fz.Vulcan_m - this.Vulcan_m, 2.0d), Math.pow(vulcan_fz.Vulcan_v - this.Vulcan_v, 2.0d)) + Math.min(Math.pow(vulcan_fz.Vulcan_E - this.Vulcan_E, 2.0d), Math.pow(vulcan_fz.Vulcan_U - this.Vulcan_U, 2.0d)));
    }

    public Vulcan_fz Vulcan_T(Object[] objArr) {
        Vulcan_fz vulcan_fz = (Vulcan_fz) objArr[0];
        this.Vulcan_m += vulcan_fz.Vulcan_m;
        this.Vulcan_t += vulcan_fz.Vulcan_t;
        this.Vulcan_E += vulcan_fz.Vulcan_E;
        this.Vulcan_v += vulcan_fz.Vulcan_v;
        this.Vulcan_W += vulcan_fz.Vulcan_W;
        this.Vulcan_U += vulcan_fz.Vulcan_U;
        return this;
    }

    public Vulcan_fz Vulcan_f(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        this.Vulcan_m += dDoubleValue;
        this.Vulcan_t += dDoubleValue2;
        this.Vulcan_E += dDoubleValue3;
        this.Vulcan_v += dDoubleValue;
        this.Vulcan_W += dDoubleValue2;
        this.Vulcan_U += dDoubleValue3;
        return this;
    }

    public Vulcan_fz Vulcan_z(Object[] objArr) {
        double dDoubleValue = ((Double) objArr[0]).doubleValue();
        double dDoubleValue2 = ((Double) objArr[1]).doubleValue();
        double dDoubleValue3 = ((Double) objArr[2]).doubleValue();
        this.Vulcan_m -= dDoubleValue;
        this.Vulcan_t -= dDoubleValue2;
        this.Vulcan_E -= dDoubleValue3;
        this.Vulcan_v += dDoubleValue;
        this.Vulcan_W += dDoubleValue2;
        this.Vulcan_U += dDoubleValue3;
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x00d3, code lost:
    
        r30 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x00d9, code lost:
    
        if (r30 >= r1) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00dc, code lost:
    
        r0 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00e0, code lost:
    
        if (r0 == null) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00e3, code lost:
    
        r31 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00e5, code lost:
    
        r0 = r31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00e9, code lost:
    
        if (r0 >= r0) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00ec, code lost:
    
        r6 = new java.lang.Object[5];
        r6[4] = java.lang.Integer.valueOf(r31);
        r6[3] = java.lang.Integer.valueOf(r30 == true ? 1 : 0);
        r6[2] = java.lang.Integer.valueOf(r29);
        r1[1] = java.lang.Long.valueOf(r1);
        r6[0] = r6;
        r0 = r0.add(me.frep.vulcan.spigot.C0046Vulcan_ff.Vulcan_T((java.lang.Object[]) r6));
        r31 = r31 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x012e, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0133, code lost:
    
        if (r0 < 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0136, code lost:
    
        if (r0 == null) goto L65;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x013b, code lost:
    
        if (r0 != null) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0141, code lost:
    
        if (r0 < 0) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x014a, code lost:
    
        throw a(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x014b, code lost:
    
        r30 = r30 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x014e, code lost:
    
        r0 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0150, code lost:
    
        if (r0 != null) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0153, code lost:
    
        r29 = r29 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0159, code lost:
    
        if (r0 <= 0) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x015e, code lost:
    
        if (r0 != null) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0164, code lost:
    
        if (r0 < 0) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x00c3, code lost:
    
        if (r0 < r1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x00c6, code lost:
    
        r0 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x00cb, code lost:
    
        if (r0 <= 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x00d0, code lost:
    
        if (r0 == null) goto L54;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x00c6, B:37:0x0161], limit reached: 68 */
    /* JADX WARN: Type inference failed for: r0v21, types: [boolean, java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v25, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v38, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v2, types: [org.bukkit.World] */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.util.function.Predicate] */
    /* JADX WARN: Type inference failed for: r30v0 */
    /* JADX WARN: Type inference failed for: r30v1, types: [int] */
    /* JADX WARN: Type inference failed for: r30v2 */
    /* JADX WARN: Type inference failed for: r30v3 */
    /* JADX WARN: Type inference failed for: r30v4, types: [int] */
    /* JADX WARN: Type inference failed for: r3v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v14, types: [java.lang.Object[]] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:38:0x0164 -> B:6:0x00c6). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean Vulcan_M(java.lang.Object[] r12) {
        /*
            Method dump skipped, instruction units count: 417
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fz.Vulcan_M(java.lang.Object[]):boolean");
    }

    public double Vulcan_x(Object[] objArr) {
        return (this.Vulcan_m + this.Vulcan_v) / 2.0d;
    }

    public double Vulcan_g(Object[] objArr) {
        return (this.Vulcan_t + this.Vulcan_W) / 2.0d;
    }

    public double Vulcan_h(Object[] objArr) {
        return (this.Vulcan_E + this.Vulcan_U) / 2.0d;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:46:0x00c7
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    /* JADX INFO: renamed from: Vulcan_z, reason: collision with other method in class */
    private boolean m832Vulcan_z(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 209
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fz.m832Vulcan_z(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:46:0x00c1
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_K(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 203
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fz.Vulcan_K(java.lang.Object[]):boolean");
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:46:0x00c7
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    private boolean Vulcan_E(java.lang.Object[] r8) {
        /*
            Method dump skipped, instruction units count: 209
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fz.Vulcan_E(java.lang.Object[]):boolean");
    }

    public Vulcan_fz Vulcan_b(Object[] objArr) {
        return new Vulcan_fz(this.Vulcan_m, this.Vulcan_v, this.Vulcan_t, this.Vulcan_W, this.Vulcan_E, this.Vulcan_U);
    }
}
