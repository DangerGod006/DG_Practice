package me.frep.vulcan.spigot;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_fc, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fc.class */
public final class EnumC0045Vulcan_fc {
    public static final EnumC0045Vulcan_fc MISS;
    public static final EnumC0045Vulcan_fc BLOCK;
    public static final EnumC0045Vulcan_fc ENTITY;
    private static final EnumC0045Vulcan_fc[] Vulcan_b;

    public static EnumC0045Vulcan_fc[] values() {
        return (EnumC0045Vulcan_fc[]) Vulcan_b.clone();
    }

    public static EnumC0045Vulcan_fc valueOf(String str) {
        return (EnumC0045Vulcan_fc) Enum.valueOf(EnumC0045Vulcan_fc.class, str);
    }

    private EnumC0045Vulcan_fc(String str, int i) {
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x005d, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0061, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0069, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L13;
            case 1: goto L14;
            case 2: goto L15;
            case 3: goto L16;
            case 4: goto L17;
            case 5: goto L18;
            default: goto L19;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0090, code lost:
    
        r8 = 31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0095, code lost:
    
        r8 = 44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x009a, code lost:
    
        r8 = 93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x009f, code lost:
    
        r8 = 103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00a4, code lost:
    
        r8 = 116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00a9, code lost:
    
        r8 = 127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ae, code lost:
    
        r8 = 51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00b0, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r18 = r18 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00b8, code lost:
    
        if (r4 != 0) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00bb, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00c0, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00c5, code lost:
    
        if (r4 > r18) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00c9, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00db, code lost:
    
        me.frep.vulcan.spigot.EnumC0045Vulcan_fc.MISS = new me.frep.vulcan.spigot.EnumC0045Vulcan_fc(r0[0], 0);
        me.frep.vulcan.spigot.EnumC0045Vulcan_fc.BLOCK = new me.frep.vulcan.spigot.EnumC0045Vulcan_fc(r0[2], 1);
        me.frep.vulcan.spigot.EnumC0045Vulcan_fc.ENTITY = new me.frep.vulcan.spigot.EnumC0045Vulcan_fc(r0[1], 2);
        me.frep.vulcan.spigot.EnumC0045Vulcan_fc.Vulcan_b = new me.frep.vulcan.spigot.EnumC0045Vulcan_fc[]{me.frep.vulcan.spigot.EnumC0045Vulcan_fc.MISS, me.frep.vulcan.spigot.EnumC0045Vulcan_fc.BLOCK, me.frep.vulcan.spigot.EnumC0045Vulcan_fc.ENTITY};
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x011e, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0027, code lost:
    
        r2 = r15;
        r15 = r15 + 1;
        r0[r2] = -1;
        r0 = r12 + r13;
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0038, code lost:
    
        if (r0 >= r0) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x005a, code lost:
    
        if (r2 <= 1) goto L10;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:10:0x005d, B:23:0x00c0], limit reached: 30 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v17, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v19, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v21, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v26 */
    /* JADX WARN: Type inference failed for: r2v3, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00c5 -> B:10:0x005d). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 287
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.EnumC0045Vulcan_fc.m685clinit():void");
    }
}
