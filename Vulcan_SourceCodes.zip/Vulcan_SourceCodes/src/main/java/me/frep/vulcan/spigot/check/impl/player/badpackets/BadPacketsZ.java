package me.frep.vulcan.spigot.check.impl.player.badpackets;

import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPacketsZ.class */
@CheckInfo(name = "Bad Packets", type = 'Z', complexType = "Spectate", description = "Invalid Spectate Packets.")
public class BadPacketsZ extends AbstractCheck {
    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    public BadPacketsZ(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00fc A[PHI: r0 r1
  0x00fc: PHI (r0v23 ??) = (r0v49 ??), (r0v50 ??), (r0v51 ??) binds: [B:27:0x00ce, B:29:0x00d3, B:34:0x00e0] A[DONT_GENERATE, DONT_INLINE]
  0x00fc: PHI (r1v20 org.bukkit.GameMode) = (r1v19 org.bukkit.GameMode), (r1v19 org.bukkit.GameMode), (r1v29 org.bukkit.GameMode) binds: [B:27:0x00ce, B:29:0x00d3, B:34:0x00e0] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00ff  */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v16, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v17, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v22, types: [org.bukkit.GameMode] */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsZ] */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_T(java.lang.Object[] r10) {
        /*
            Method dump skipped, instruction units count: 304
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPacketsZ.Vulcan_T(java.lang.Object[]):void");
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
