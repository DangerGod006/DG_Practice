package me.frep.vulcan.spigot.check.impl.player.badpackets;

import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/player/badpackets/BadPackets7.class */
@CheckInfo(name = "Bad Packets", type = '7', complexType = "No Swing", description = "Hitting without swinging.")
public class BadPackets7 extends AbstractCheck {
    private boolean Vulcan_m;
    private boolean Vulcan_a;
    private boolean Vulcan_g;
    private boolean Vulcan_C;
    private static final String b;

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0055, code lost:
    
        r8 = 108;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x005a, code lost:
    
        r8 = 35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x005f, code lost:
    
        r8 = 84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0064, code lost:
    
        r8 = 90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0069, code lost:
    
        r8 = 5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x006d, code lost:
    
        r8 = 39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x006f, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r11 = r11 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0077, code lost:
    
        if (r4 != 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x007a, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x007f, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0083, code lost:
    
        if (r4 > r11) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0087, code lost:
    
        r3 = new java.lang.String(r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0099, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0008, code lost:
    
        me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7.b = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001d, code lost:
    
        if (r2 <= 1) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0020, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0023, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x002a, code lost:
    
        switch((r11 % 7)) {
            case 0: goto L9;
            case 1: goto L10;
            case 2: goto L11;
            case 3: goto L12;
            case 4: goto L13;
            case 5: goto L14;
            default: goto L15;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0050, code lost:
    
        r8 = 58;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:6:0x0020, B:19:0x007f], limit reached: 24 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v2, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v16 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0083 -> B:6:0x0020). Please report as a decompilation issue!!! */
    static {
        /*
            r0 = 109(0x6d, float:1.53E-43)
            java.lang.String r1 = "$v;WPU"
            r2 = -1
            goto Le
        L8:
            me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7.b = r0
            goto L99
        Le:
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            char[] r2 = r2.toCharArray()
            r3 = r2; r2 = r1; r1 = r3; 
            int r3 = r3.length
            r4 = r3; r3 = r2; r2 = r1; r1 = r4; 
            r4 = 0
            r11 = r4
            r5 = r3; r4 = r2; r3 = r1; r2 = r5; r1 = r4; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = 1
            if (r5 > r6) goto L7f
        L20:
            r4 = r2; r5 = r3; 
            r6 = r4; r4 = r5; r5 = r6; 
            r6 = r11
        L23:
            r8 = r6; r7 = r5; r6 = r4; r5 = r8; r4 = r7; 
            char r7 = r7[r8]
            r8 = r6; r6 = r7; r7 = r8; 
            r8 = r11
            r9 = 7
            int r8 = r8 % r9
            switch(r8) {
                case 0: goto L50;
                case 1: goto L55;
                case 2: goto L5a;
                case 3: goto L5f;
                case 4: goto L64;
                case 5: goto L69;
                default: goto L6d;
            }
        L50:
            r8 = 58
            goto L6f
        L55:
            r8 = 108(0x6c, float:1.51E-43)
            goto L6f
        L5a:
            r8 = 35
            goto L6f
        L5f:
            r8 = 84
            goto L6f
        L64:
            r8 = 90
            goto L6f
        L69:
            r8 = 5
            goto L6f
        L6d:
            r8 = 39
        L6f:
            r7 = r7 ^ r8
            r6 = r6 ^ r7
            char r6 = (char) r6
            r4[r5] = r6
            int r11 = r11 + 1
            r4 = r3
            if (r4 != 0) goto L7f
            r4 = r2; r5 = r3; 
            r6 = r5; r5 = r4; r4 = r6; 
            goto L23
        L7f:
            r6 = r4; r5 = r3; r4 = r2; r3 = r6; r2 = r5; 
            r5 = r4; r4 = r3; r3 = r2; r2 = r5; 
            r6 = r11
            if (r5 > r6) goto L20
        L87:
            java.lang.String r4 = new java.lang.String
            r5 = r4; r4 = r3; r3 = r5; 
            r6 = r4; r4 = r5; r5 = r6; 
            r4.<init>(r5)
            java.lang.String r3 = r3.intern()
            r4 = r2; r2 = r3; r3 = r4; 
            r3 = r1; r1 = r2; r2 = r3; 
            goto L8
        L99:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7.m1235clinit():void");
    }

    public BadPackets7(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
        this.Vulcan_m = this.Vulcan_b.Vulcan_y(new Object[0]).isNewerThan(ClientVersion.V_1_8);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:104:0x01b0 A[EXC_TOP_SPLITTER, PHI: r0
  0x01b0: PHI (r0v41 ??) = (r0v40 ??), (r0v51 ??) binds: [B:87:0x01ad, B:79:0x0196] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:111:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x016d  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x01ad A[PHI: r0
  0x01ad: PHI (r0v40 ??) = (r0v83 ??), (r0v84 ??), (r0v85 ??) binds: [B:62:0x016a, B:64:0x016f, B:84:0x01a3] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x015c A[EXC_TOP_SPLITTER, PHI: r0
  0x015c: PHI (r0v28 ??) = (r0v80 ??), (r0v81 ??), (r0v82 ??) binds: [B:50:0x0136, B:52:0x013b, B:58:0x0150] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v14, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v20 */
    /* JADX WARN: Type inference failed for: r0v21, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r0v23, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v31, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v36, types: [java.lang.RuntimeException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v39, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v41 */
    /* JADX WARN: Type inference failed for: r0v42, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v45, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r0v46, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r0v47, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v49, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v51, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v52, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r0v53 */
    /* JADX WARN: Type inference failed for: r0v54 */
    /* JADX WARN: Type inference failed for: r0v55, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v58, types: [com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity$InteractAction] */
    /* JADX WARN: Type inference failed for: r0v60, types: [me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r0v61, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v63, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v69, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v75 */
    /* JADX WARN: Type inference failed for: r0v76 */
    /* JADX WARN: Type inference failed for: r0v77 */
    /* JADX WARN: Type inference failed for: r0v78 */
    /* JADX WARN: Type inference failed for: r0v79 */
    /* JADX WARN: Type inference failed for: r0v80 */
    /* JADX WARN: Type inference failed for: r0v81 */
    /* JADX WARN: Type inference failed for: r0v82 */
    /* JADX WARN: Type inference failed for: r0v83 */
    /* JADX WARN: Type inference failed for: r0v84 */
    /* JADX WARN: Type inference failed for: r0v85 */
    /* JADX WARN: Type inference failed for: r0v86 */
    /* JADX WARN: Type inference failed for: r0v87 */
    /* JADX WARN: Type inference failed for: r0v88 */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r1v19 */
    /* JADX WARN: Type inference failed for: r1v2, types: [com.github.retrooper.packetevents.event.PacketEvent] */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v21 */
    /* JADX WARN: Type inference failed for: r1v51 */
    /* JADX WARN: Type inference failed for: r1v56, types: [me.frep.vulcan.spigot.Vulcan_yU[]] */
    /* JADX WARN: Type inference failed for: r1v59 */
    /* JADX WARN: Type inference failed for: r1v60 */
    /* JADX WARN: Type inference failed for: r3v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v20, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7] */
    /* JADX WARN: Type inference failed for: r3v29, types: [java.lang.Object[]] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_T(java.lang.Object[] r9) {
        /*
            Method dump skipped, instruction units count: 497
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.check.impl.player.badpackets.BadPackets7.Vulcan_T(java.lang.Object[]):void");
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
