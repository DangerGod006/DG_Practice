package me.frep.vulcan.spigot;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Found several "values" enum fields: [] */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_B.class */
public final class Vulcan_B {
    public static final Vulcan_B POSITIVE;
    public static final Vulcan_B NEGATIVE;
    private final int Vulcan_F;
    private final String Vulcan_a;
    private static final Vulcan_B[] Vulcan_C;
    private static final String Vulcan_L;
    private static final Vulcan_B[] Vulcan_i;

    public static Vulcan_B[] values() {
        return (Vulcan_B[]) Vulcan_i.clone();
    }

    public static Vulcan_B valueOf(String str) {
        return (Vulcan_B) Enum.valueOf(Vulcan_B.class, str);
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0076, code lost:
    
        if (r0 >= r16) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0079, code lost:
    
        r13 = r14.charAt(r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0082, code lost:
    
        me.frep.vulcan.spigot.Vulcan_B.Vulcan_L = r0[5];
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00a0, code lost:
    
        if (r2 <= 1) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x00a3, code lost:
    
        r4 = r3;
        r5 = r2;
        r6 = r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a7, code lost:
    
        r8 = r6;
        r7 = r5;
        r6 = r4;
        r7 = r7[r8];
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x00af, code lost:
    
        switch((r18 % 7)) {
            case 0: goto L18;
            case 1: goto L19;
            case 2: goto L20;
            case 3: goto L21;
            case 4: goto L22;
            case 5: goto L23;
            default: goto L24;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x00d4, code lost:
    
        r8 = 100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00d9, code lost:
    
        r8 = 112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00de, code lost:
    
        r8 = 73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00e3, code lost:
    
        r8 = 122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00e8, code lost:
    
        r8 = 32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00ed, code lost:
    
        r8 = 74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00f2, code lost:
    
        r8 = 36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00f4, code lost:
    
        r7[r8] = (char) (r7 ^ (r6 ^ r8));
        r18 = r18 + 1;
        r4 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x00fc, code lost:
    
        if (r4 != 0) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00ff, code lost:
    
        r6 = r3;
        r5 = r2;
        r4 = r6 == true ? 1 : 0;
        r6 = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0104, code lost:
    
        r4 = r2;
        r3 = r3;
        r2 = r4;
        r3 = r3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0109, code lost:
    
        if (r4 > r18) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x010d, code lost:
    
        r3 = new java.lang.String((char[]) r3).intern();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x011b, code lost:
    
        switch(r2) {
            case 0: goto L9;
            default: goto L4;
        };
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x012c, code lost:
    
        me.frep.vulcan.spigot.Vulcan_B.POSITIVE = new me.frep.vulcan.spigot.Vulcan_B(r0[4], 0, r0[3], 0, 1, r0[1]);
        me.frep.vulcan.spigot.Vulcan_B.NEGATIVE = new me.frep.vulcan.spigot.Vulcan_B(r0[2], 1, r0[0], 1, -1, r0[6]);
        me.frep.vulcan.spigot.Vulcan_B.Vulcan_i = new me.frep.vulcan.spigot.Vulcan_B[]{me.frep.vulcan.spigot.Vulcan_B.POSITIVE, me.frep.vulcan.spigot.Vulcan_B.NEGATIVE};
        me.frep.vulcan.spigot.Vulcan_B.Vulcan_C = new me.frep.vulcan.spigot.Vulcan_B[]{me.frep.vulcan.spigot.Vulcan_B.POSITIVE, me.frep.vulcan.spigot.Vulcan_B.NEGATIVE};
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x017f, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0029, code lost:
    
        r2 = r15;
        r15 = r15 + 1;
        r0[r2] = r3;
        r0 = r12 + r13;
        r12 = r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x003a, code lost:
    
        if (r0 >= r16) goto L7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0046, code lost:
    
        r14 = "e~T\bR8V\u0014\u00019\b\u0010r]|Y\u0010l\u0015\u0006\\n_\u0003|\u000fPW";
        r16 = "e~T\bR8V\u0014\u00019\b\u0010r]|Y\u0010l\u0015\u0006\\n_\u0003|\u000fPW".length();
        r13 = 11;
        r12 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0065, code lost:
    
        r2 = r15;
        r15 = r15 + 1;
        r0[r2] = r3;
        r0 = r12 + r13;
        r12 = r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:15:0x00a3, B:28:0x0104], limit reached: 39 */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v16, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v19, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v21, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v31 */
    /* JADX WARN: Type inference failed for: r2v32 */
    /* JADX WARN: Type inference failed for: r2v4, types: [char[]] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v10, types: [char[]] */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v27 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v17 */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v21 */
    /* JADX WARN: Type inference failed for: r4v22 */
    /* JADX WARN: Type inference failed for: r4v23 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v13 */
    /* JADX WARN: Type inference failed for: r6v15 */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r7v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x0109 -> B:15:0x00a3). Please report as a decompilation issue!!! */
    static {
        /*
            Method dump skipped, instruction units count: 384
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_B.m574clinit():void");
    }

    private Vulcan_B(String str, int i, String str2, int i2, int i3, String str3) {
        this.Vulcan_F = i3;
        this.Vulcan_a = str3;
    }

    public int Vulcan_r() {
        return this.Vulcan_F;
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.Vulcan_a;
    }
}
