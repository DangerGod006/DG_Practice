package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_Os, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_Os.class */
public final class C0040Vulcan_Os {
    private static final long a = Vulcan_n.a(-8734928811804146528L, -7539866067698149732L, MethodHandles.lookup().lookupClass()).a(135639424070526L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 40953545143076L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[7];
        int i3 = 0;
        String str = "Ç00\u0011¼TµÁ33A\u0012\t¡\u001cØ\u00adö\u007f\u00ad\u0080áã\u0098éÇfm¼µ\u0091\u00928áí·\u008a³¾¬·ü\u0010\u0017\n\u0014\u0017\u0087*ªûuG\u0086iWú)\u000bV¼\u009fd¹\u009d5M.\u0095\u009e¤n\u0080\u0014\u0097Q«L-\u0011Ö¨KÜ\u0091ßñ¤C\u0010_\nú¡×µHâï\b4.%\u0099N(\u0010_\nú¡×µHâï\b4.%\u0099N( Ç00\u0011¼TµÁ33A\u0012\t¡\u001cØ\u00adö\u007f\u00ad\u0080áã\u0098éÇfm¼µ\u0091\u0092";
        int length = "Ç00\u0011¼TµÁ33A\u0012\t¡\u001cØ\u00adö\u007f\u00ad\u0080áã\u0098éÇfm¼µ\u0091\u00928áí·\u008a³¾¬·ü\u0010\u0017\n\u0014\u0017\u0087*ªûuG\u0086iWú)\u000bV¼\u009fd¹\u009d5M.\u0095\u009e¤n\u0080\u0014\u0097Q«L-\u0011Ö¨KÜ\u0091ßñ¤C\u0010_\nú¡×µHâï\b4.%\u0099N(\u0010_\nú¡×µHâï\b4.%\u0099N( Ç00\u0011¼TµÁ33A\u0012\t¡\u001cØ\u00adö\u007f\u00ad\u0080áã\u0098éÇfm¼µ\u0091\u0092".length();
        char cCharAt = ' ';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "Ð.¤\u0002\\ï(kr\f\u0089«¡\u0082\u001cW(Ç00\u0011¼TµÁ\u0007\u0006ê8\u0002Â\u009aø4öj¸ÞÍîÑ\r\u0083±!\u008ds\u0012A\u0089_È®ý\u00131ã";
                        length = "Ð.¤\u0002\\ï(kr\f\u0089«¡\u0082\u001cW(Ç00\u0011¼TµÁ\u0007\u0006ê8\u0002Â\u009aø4öj¸ÞÍîÑ\r\u0083±!\u008ds\u0012A\u0089_È®ý\u00131ã".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private C0040Vulcan_Os() {
        throw new UnsupportedOperationException(b[1]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Class] */
    public static boolean Vulcan_h(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        String str = (String) objArr[1];
        ?? Vulcan_Y = a ^ jLongValue;
        try {
            Vulcan_Y = Vulcan_Y(new Object[]{str});
            return Vulcan_Y != 0;
        } catch (UnsupportedOperationException unused) {
            throw a((Exception) Vulcan_Y);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [long] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.reflect.Method] */
    public static boolean Vulcan_w(@NotNull Class cls, String str, Class[] clsArr, long j) throws Exception {
        ?? Vulcan_X = a ^ j;
        try {
            Vulcan_X = Vulcan_X(cls, str, Vulcan_X ^ 6439418304049L, clsArr);
            return Vulcan_X != 0;
        } catch (UnsupportedOperationException unused) {
            throw a((Exception) Vulcan_X);
        }
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    @Nullable
    public static Method Vulcan_X(@NotNull Class cls, @NotNull String str, long j, Class[] clsArr) {
        long j2 = a ^ j;
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        try {
            return cls.getMethod(Vulcan_m.b(str, cls, clsArr), clsArr);
        } catch (NoSuchMethodException e) {
            while (true) {
                Class cls2 = cls;
                if (abstractCheckArrVulcan_q != null) {
                    if (cls2 != null) {
                        cls2 = cls;
                    } else {
                        return null;
                    }
                }
                try {
                    Class cls3 = cls2;
                    return cls3.getDeclaredMethod(Vulcan_m.b(str, cls3, clsArr), clsArr);
                } catch (NoSuchMethodException e2) {
                    cls = cls.getSuperclass();
                    if (j2 > 0 && abstractCheckArrVulcan_q == null) {
                        return null;
                    }
                }
            }
        }
    }

    @Nullable
    public static Class Vulcan_Y(Object[] objArr) {
        try {
            return Class.forName(Vulcan_m.a((String) objArr[0]));
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v31, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v32, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.reflect.Field] */
    /* JADX WARN: Type inference failed for: r0v36 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1, types: [int] */
    /* JADX WARN: Type inference failed for: r18v2 */
    /* JADX WARN: Type inference failed for: r18v4 */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r1v18 */
    public static Field Vulcan_p(Object[] objArr) throws Exception {
        Class cls = (Class) objArr[0];
        String[] strArr = (String[]) objArr[1];
        long jLongValue = a ^ ((Long) objArr[2]).longValue();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        int length = strArr.length;
        int i = 0;
        loop0: do {
            ?? Equals = i;
            while (Equals < length) {
                String str = strArr[i];
                Field[] declaredFields = cls.getDeclaredFields();
                int length2 = declaredFields.length;
                Equals = 0;
                while (true) {
                    ?? r18 = Equals;
                    while (r18 < length2) {
                        Field field = declaredFields[r18 == true ? 1 : 0];
                        String simpleName = field.getType().getSimpleName();
                        Equals = abstractCheckArrVulcan_q;
                        r18 = r18;
                        if (jLongValue >= 0) {
                            if (Equals != 0) {
                                try {
                                    Equals = str.equals(simpleName);
                                    if (abstractCheckArrVulcan_q != null) {
                                        if (jLongValue >= 0) {
                                            if (Equals == 0) {
                                                r18++;
                                            } else {
                                                try {
                                                    field.setAccessible(true);
                                                    Equals = field;
                                                    return Equals;
                                                } catch (NoSuchFieldException unused) {
                                                    throw a((Exception) Equals);
                                                }
                                            }
                                        }
                                    }
                                } catch (NoSuchFieldException unused2) {
                                    throw a((Exception) Equals);
                                }
                            }
                            Equals = abstractCheckArrVulcan_q;
                        }
                        if (Equals == 0) {
                            break;
                        }
                    }
                }
                i++;
                if (jLongValue <= 0) {
                    break;
                }
            }
            break loop0;
        } while (abstractCheckArrVulcan_q != null);
        StringBuilder sb = new StringBuilder();
        String[] strArr2 = b;
        throw new NoSuchFieldException(sb.append(strArr2[4]).append(cls.getName()).append(strArr2[5]).append(Arrays.toString(strArr)).toString());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12 */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v16, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v19, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    public static Field Vulcan_X(Object[] objArr) throws Exception {
        long jLongValue = ((Long) objArr[0]).longValue();
        Class cls = (Class) objArr[1];
        Class cls2 = (Class) objArr[2];
        long j = a ^ jLongValue;
        Field[] declaredFields = cls.getDeclaredFields();
        AbstractCheck[] abstractCheckArrVulcan_q = Vulcan_OM.Vulcan_q();
        int length = declaredFields.length;
        int i = 0;
        while (i < length) {
            Field field = declaredFields[i];
            Class<?> type = field.getType();
            ?? IsAssignableFrom = abstractCheckArrVulcan_q;
            if (j >= 0) {
                if (IsAssignableFrom != 0) {
                    try {
                        try {
                            IsAssignableFrom = cls2.isAssignableFrom(type);
                            if (IsAssignableFrom == 0) {
                                i++;
                            } else {
                                field.setAccessible(true);
                                return field;
                            }
                        } catch (NoSuchFieldException unused) {
                            throw a((Exception) IsAssignableFrom);
                        }
                    } catch (NoSuchFieldException unused2) {
                        throw a((Exception) IsAssignableFrom);
                    }
                }
                IsAssignableFrom = abstractCheckArrVulcan_q;
            }
            if (IsAssignableFrom == 0) {
                break;
            }
        }
        StringBuilder sb = new StringBuilder();
        String[] strArr = b;
        throw new NoSuchFieldException(sb.append(strArr[0]).append(cls.getName()).append(strArr[3]).append(cls2.getName()).toString());
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public static java.lang.Object Vulcan_O(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 205
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0040Vulcan_Os.Vulcan_O(java.lang.Object[]):java.lang.Object");
    }
}
