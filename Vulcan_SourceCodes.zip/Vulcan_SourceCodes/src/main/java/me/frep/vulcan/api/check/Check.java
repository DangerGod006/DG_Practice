package me.frep.vulcan.api.check;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/api/check/Check.class */
public interface Check {
    String getCategory();

    String getName();

    char getType();

    char getDisplayType();

    int getMaxVl();

    int getVl();

    double getMaxBuffer();

    boolean isExperimental();

    double getBufferDecay();

    double getBufferMultiple();

    int getMinimumVlToNotify();

    int getAlertInterval();

    double getBuffer();

    void setVl(int i);

    boolean isPunishable();

    void setBuffer(double d);

    String getDescription();

    String getComplexType();

    String getDisplayName();
}
