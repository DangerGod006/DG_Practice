package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.command.CommandExecutor;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_kY.class */
public class Vulcan_kY extends Vulcan_k4 implements CommandExecutor {
    private final ExecutorService Vulcan_h = Executors.newSingleThreadExecutor();
    private static final long b = Vulcan_n.a(5120321931738953700L, -4756152032913250094L, MethodHandles.lookup().lookupClass()).a(202558452528599L);
    private static final String[] d;

    static {
        int i;
        long j = b ^ 20315350633859L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[14];
        int i3 = 0;
        String str = "ÚHç®\u0006Ã\u0098î\b\u0096ñme¥ª\u0088C\u0010ò÷\u0093ÏÝ\u0005\u0095Ó\u0003hyýOcëõ\u0010ò÷\u0093ÏÝ\u0005\u0095Ó\u0003hyýOcëõ\u0010\u0018íf\u000e}\u0098ôTá(ÿmØiøÍ\u0010\u0018íf\u000e}\u0098ôTá(ÿmØiøÍ\u0010×\füe]\u0081I\u009c\u000eÅè¼Èbã\u007f\b\u0081\u0086DÄT×p7\b^¸\u000emsy\u0085Ð\u0010/Þ\u0095\u009f5\u0006\t þ¸4·\u0087*\u0086u\u0010e^\u0098\u0017G\u001bY;u\u0005\u0019ê\u0091\"¬\"\b\u0096ñme¥ª\u0088C";
        int length = "ÚHç®\u0006Ã\u0098î\b\u0096ñme¥ª\u0088C\u0010ò÷\u0093ÏÝ\u0005\u0095Ó\u0003hyýOcëõ\u0010ò÷\u0093ÏÝ\u0005\u0095Ó\u0003hyýOcëõ\u0010\u0018íf\u000e}\u0098ôTá(ÿmØiøÍ\u0010\u0018íf\u000e}\u0098ôTá(ÿmØiøÍ\u0010×\füe]\u0081I\u009c\u000eÅè¼Èbã\u007f\b\u0081\u0086DÄT×p7\b^¸\u000emsy\u0085Ð\u0010/Þ\u0095\u009f5\u0006\t þ¸4·\u0087*\u0086u\u0010e^\u0098\u0017G\u001bY;u\u0005\u0019ê\u0091\"¬\"\b\u0096ñme¥ª\u0088C".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = b(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            d = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "³Yí¿}Ï»\u008fÓ¿«À\u008aoùi\u0007Ùìã§\u0017ÿó\u0010ÌL\u0018GEÚ\u008b¬¾|ÿ³#Î\u0084Ã";
                        length = "³Yí¿}Ï»\u008fÓ¿«À\u008aoùi\u0007Ùìã§\u0017ÿó\u0010ÌL\u0018GEÚ\u008b¬¾|ÿ³#Î\u0084Ã".length();
                        cCharAt = 24;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static Exception a(Exception exc) {
        return exc;
    }

    private static String b(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00eb A[PHI: r0
  0x00eb: PHI (r0v25 org.bukkit.command.CommandSender) = (r0v24 org.bukkit.command.CommandSender), (r0v34 org.bukkit.command.CommandSender) binds: [B:35:0x00cc, B:44:0x00e3] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean, java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v22, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r0v26, types: [org.bukkit.entity.Player] */
    /* JADX WARN: Type inference failed for: r0v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v30, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v32, types: [me.frep.vulcan.spigot.Vulcan_kY] */
    /* JADX WARN: Type inference failed for: r0v39 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v40 */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v9, types: [boolean] */
    /* JADX WARN: Type inference failed for: r2v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v15, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v21, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r9v0, types: [me.frep.vulcan.spigot.Vulcan_kY] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onCommand(org.bukkit.command.CommandSender r10, org.bukkit.command.Command r11, java.lang.String r12, java.lang.String[] r13) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 349
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kY.onCommand(org.bukkit.command.CommandSender, org.bukkit.command.Command, java.lang.String, java.lang.String[]):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:101:0x0243 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:114:0x02b4 A[EDGE_INSN: B:114:0x02b4->B:87:0x02b4 BREAK  A[LOOP:1: B:63:0x0209->B:115:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:115:? A[LOOP:1: B:63:0x0209->B:115:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0213  */
    /* JADX WARN: Type inference failed for: r0v11, types: [java.io.File] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v24, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v27, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v37, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v38 */
    /* JADX WARN: Type inference failed for: r0v39, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v41, types: [org.bukkit.command.CommandSender] */
    /* JADX WARN: Type inference failed for: r0v44, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v46, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v56, types: [int] */
    /* JADX WARN: Type inference failed for: r0v61, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v63, types: [java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v64, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v65, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v66, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v67, types: [java.lang.Exception, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v68, types: [java.lang.Exception] */
    /* JADX WARN: Type inference failed for: r0v72, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v73 */
    /* JADX WARN: Type inference failed for: r1v28, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r1v36, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r25v0 */
    /* JADX WARN: Type inference failed for: r2v11, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v35, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v42, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v48, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v53, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r3v16, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v24, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v41, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v56, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v68, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v78, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r9v0, types: [me.frep.vulcan.spigot.Vulcan_kY] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void lambda$onCommand$0(java.lang.String[] r10, org.bukkit.command.CommandSender r11) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 774
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_kY.lambda$onCommand$0(java.lang.String[], org.bukkit.command.CommandSender):void");
    }

    public static String spigot() {
        return d[9];
    }

    public static String nonce() {
        return d[6];
    }

    public static String resource() {
        return d[12];
    }
}
