package me.frep.vulcan.spigot;

import ac.vulcan.anticheat.Vulcan_t;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.api.event.VulcanViolationResetEvent;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Bukkit;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_k1.class */
public class Vulcan_k1 implements Runnable {
    private static Vulcan_t Vulcan_F;
    static final boolean Vulcan_w;
    private static String Vulcan_s;
    private static final long a = Vulcan_n.a(1147984175337620711L, -767829456692963846L, MethodHandles.lookup().lookupClass()).a(129666966008153L);
    private static final String[] b;

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect negative register number in instruction: 0x0015: MOVE_MULTI (r2 I:??), (r1 I:??), (r1 I:??), (r0 I:??), (r0 I:??), (r-1 I:??), (r-1 I:??), (r2 I:??)
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:76)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    @Override // java.lang.Runnable
    public void run() {
        /*
            r7 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_k1.a
            r1 = 56295015417558(0x3333346586d6, double:2.78134331499187E-310)
            long r0 = r0 ^ r1
            r8 = r0
            r0 = r8
            r1 = r0; r1 = r0; 
            r2 = 77496061840659(0x467b753ccd13, double:3.82881418434584E-310)
            long r1 = r1 ^ r2
            r10 = r1
            r0 = r10
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = r1; r1 = r0; r0 = r-1; r-1 = r2; 
            r3 = r2; r2 = r1; r1 = r0; r0 = r3; 
            java.lang.Long r2 = java.lang.Long.valueOf(r2)
            r3 = 0
            r4 = r2; r2 = r3; r3 = r4; 
            r1[r2] = r3
            Vulcan_f(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_k1.run():void");
    }

    public static void Vulcan_m(String str) {
        Vulcan_s = str;
    }

    public static String Vulcan__() {
        return Vulcan_s;
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v20, types: [java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r0v21, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v24, types: [boolean] */
    static {
        long j = a ^ 1203877276843L;
        Vulcan_m(null);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[2];
        int i2 = 0;
        int length = "\u0084\u008a\u0086ö@k¼\u001aü:\u0016~QA\u009e1CÚ\u000büîì°Î\u009a\u0086\u00902ÇÀÏógî!£\u009c¢mù¯ó+\u009dã\u009f]\r(¼)0ô0Êsæ¾Ôø©xÅðÌíÔ\u000bW³\u008d\u000eHÜ¥½m\u0097uBdþ\u0090J\r\u0003¾rf".length();
        char cCharAt = '0';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("\u0084\u008a\u0086ö@k¼\u001aü:\u0016~QA\u009e1CÚ\u000büîì°Î\u009a\u0086\u00902ÇÀÏógî!£\u009c¢mù¯ó+\u009dã\u009f]\r(¼)0ô0Êsæ¾Ôø©xÅðÌíÔ\u000bW³\u008d\u000eHÜ¥½m\u0097uBdþ\u0090J\r\u0003¾rf".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                break;
            } else {
                cCharAt = "\u0084\u008a\u0086ö@k¼\u001aü:\u0016~QA\u009e1CÚ\u000büîì°Î\u009a\u0086\u00902ÇÀÏógî!£\u009c¢mù¯ó+\u009dã\u009f]\r(¼)0ô0Êsæ¾Ôø©xÅðÌíÔ\u000bW³\u008d\u000eHÜ¥½m\u0097uBdþ\u0090J\r\u0003¾rf".charAt(i3);
            }
        }
        ?? DesiredAssertionStatus = strArr;
        b = DesiredAssertionStatus;
        try {
            DesiredAssertionStatus = Vulcan_k1.class.desiredAssertionStatus();
            Vulcan_w = DesiredAssertionStatus == 0;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) DesiredAssertionStatus);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:37:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00ab A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0080 A[EXC_TOP_SPLITTER, PHI: r0
  0x0080: PHI (r0v24 ??) = (r0v23 ??), (r0v39 ??) binds: [B:31:0x007d, B:21:0x0052] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:65:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v20, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v22 */
    /* JADX WARN: Type inference failed for: r0v23 */
    /* JADX WARN: Type inference failed for: r0v24 */
    /* JADX WARN: Type inference failed for: r0v25, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v27, types: [org.bukkit.plugin.PluginManager] */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v29, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v32, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v33, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v35, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v39, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v44, types: [int] */
    /* JADX WARN: Type inference failed for: r0v45 */
    /* JADX WARN: Type inference failed for: r0v47 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v49 */
    /* JADX WARN: Type inference failed for: r0v50 */
    /* JADX WARN: Type inference failed for: r0v51 */
    /* JADX WARN: Type inference failed for: r0v52 */
    /* JADX WARN: Type inference failed for: r0v6, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void Vulcan_f(java.lang.Object[] r6) {
        /*
            Method dump skipped, instruction units count: 238
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_k1.Vulcan_f(java.lang.Object[]):void");
    }

    private static void lambda$reset$0(VulcanViolationResetEvent vulcanViolationResetEvent) {
        Bukkit.getPluginManager().callEvent(vulcanViolationResetEvent);
    }

    private static void lambda$reset$2(C0042Vulcan_Oz c0042Vulcan_Oz) {
        c0042Vulcan_Oz.Vulcan_I(new Object[]{0});
        c0042Vulcan_Oz.Vulcan_m(new Object[]{0});
        c0042Vulcan_Oz.m646Vulcan_Q(new Object[]{0});
        c0042Vulcan_Oz.m647Vulcan_y(new Object[]{0});
        c0042Vulcan_Oz.m648Vulcan_i(new Object[]{0});
        c0042Vulcan_Oz.m649Vulcan_g(new Object[]{0});
        c0042Vulcan_Oz.Vulcan__(new Object[]{0});
        c0042Vulcan_Oz.m635Vulcan_B(new Object[0]).forEach(Vulcan_k1::lambda$null$1);
    }

    private static void lambda$null$1(AbstractCheck abstractCheck) {
        abstractCheck.setVl(0);
        abstractCheck.Vulcan_o(new Object[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v14, types: [ac.vulcan.anticheat.Vulcan_H] */
    /* JADX WARN: Type inference failed for: r0v20, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v27 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r2v3, types: [long] */
    /* JADX WARN: Type inference failed for: r4v2, types: [java.lang.Object[], long] */
    public void Vulcan_M(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan__ = Vulcan__();
        try {
            try {
                try {
                    Vulcan__ = Vulcan_w;
                    ?? Vulcan_S = Vulcan__;
                    if (Vulcan__ == 0) {
                        if (Vulcan__ == 0 && Vulcan_F != null) {
                            throw new AssertionError(b[0]);
                        }
                        Vulcan_S = Vulcan_fe.Vulcan_S(new Object[]{b[1]});
                    }
                    ?? r15 = Vulcan_S;
                    try {
                        ?? M1085Vulcan_j = Vulcan_r.m1085Vulcan_j();
                        ?? r4 = new Object[3];
                        ((r15 == true ? 1L : 0L) * 1200)[2] = Long.valueOf((r15 == true ? 1L : 0L) * 1200);
                        this[1] = Long.valueOf((long) r4);
                        r4[0] = r4;
                        Vulcan_F = M1085Vulcan_j.Vulcan_H(r4);
                        if (jLongValue >= 0) {
                            if (Vulcan__ == 0) {
                                return;
                            }
                            Vulcan_S = new AbstractCheck[3];
                            AbstractCheck.Vulcan_D((AbstractCheck[]) Vulcan_S);
                        }
                    } catch (RuntimeException unused) {
                        throw a((RuntimeException) Vulcan_S);
                    }
                } catch (RuntimeException unused2) {
                    throw a((RuntimeException) Vulcan__);
                }
            } catch (RuntimeException unused3) {
                throw a((RuntimeException) Vulcan__);
            }
        } catch (RuntimeException unused4) {
            throw a((RuntimeException) Vulcan__);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r0v6, types: [ac.vulcan.anticheat.Vulcan_t] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ac.vulcan.anticheat.Vulcan_t] */
    public void Vulcan_Z(Object[] objArr) {
        long jLongValue = a ^ ((Long) objArr[0]).longValue();
        ?? Vulcan__ = Vulcan__();
        try {
            Vulcan__ = Vulcan_F;
            ?? r0 = Vulcan__;
            if (Vulcan__ == 0) {
                if (Vulcan__ == 0) {
                    return;
                } else {
                    r0 = Vulcan_F;
                }
            }
            r0.Vulcan_T(new Object[0]);
            Vulcan_F = null;
        } catch (RuntimeException unused) {
            throw a((RuntimeException) Vulcan__);
        }
    }
}
