package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.ChatColor;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ym.class */
public final class Vulcan_ym {
    private static final long a = Vulcan_n.a(-409438828577300883L, -6586301539304144122L, MethodHandles.lookup().lookupClass()).a(234158493189415L);
    private static final String[] b;

    static {
        long j = a ^ 97423854966972L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i = 1; i < 8; i++) {
            bArr[i] = (byte) ((j << (i * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[3];
        int i2 = 0;
        int length = "MJÀÀGûñ+\u0019Ex e\rM\u0003FCkx9qá|\u0089À\r\u0097£\u0010\u008d[!,;\u0019\u009et(3Är÷ï@ïµ\u009dÝã\u0082û\u0094\u0012å\u0006\u0010¬®Ñ\u0013¸\u0093 \u0099\u0016\u008aTýNk!G\u0010z\u0091â\u009a'Í½Züða_&óÈ\u0090".length();
        char cCharAt = '8';
        int i3 = -1;
        while (true) {
            int i4 = i3 + 1;
            int i5 = i2;
            i2++;
            strArr[i5] = a(cipher.doFinal("MJÀÀGûñ+\u0019Ex e\rM\u0003FCkx9qá|\u0089À\r\u0097£\u0010\u008d[!,;\u0019\u009et(3Är÷ï@ïµ\u009dÝã\u0082û\u0094\u0012å\u0006\u0010¬®Ñ\u0013¸\u0093 \u0099\u0016\u008aTýNk!G\u0010z\u0091â\u009a'Í½Züða_&óÈ\u0090".substring(i4, i4 + cCharAt).getBytes(CharEncoding.ISO_8859_1))).intern();
            int i6 = i4 + cCharAt;
            i3 = i6;
            if (i6 >= length) {
                b = strArr;
                return;
            }
            cCharAt = "MJÀÀGûñ+\u0019Ex e\rM\u0003FCkx9qá|\u0089À\r\u0097£\u0010\u008d[!,;\u0019\u009et(3Är÷ï@ïµ\u009dÝã\u0082û\u0094\u0012å\u0006\u0010¬®Ñ\u0013¸\u0093 \u0099\u0016\u008aTýNk!G\u0010z\u0091â\u009a'Í½Züða_&óÈ\u0090".charAt(i3);
        }
    }

    private static UnsupportedOperationException a(UnsupportedOperationException unsupportedOperationException) {
        return unsupportedOperationException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    private Vulcan_ym() {
        throw new UnsupportedOperationException(b[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v3, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v32 */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.UnsupportedOperationException] */
    /* JADX WARN: Type inference failed for: r0v8, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v9, types: [char] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    public static String Vulcan_X(Object[] objArr) {
        String str = (String) objArr[0];
        long jLongValue = a ^ ((Long) objArr[1]).longValue();
        ?? Vulcan_q = Vulcan_OM.Vulcan_q();
        String strReplaceAll = str.replaceAll(b[1], Vulcan_fe.Vulcan_vP);
        try {
            Vulcan_q = Vulcan_OM.Vulcan_f(new Object[0]);
            ?? r0 = Vulcan_q;
            if (Vulcan_q != 0) {
                if (Vulcan_q != 0) {
                    Pattern patternCompile = Pattern.compile(b[2]);
                    Matcher matcher = patternCompile.matcher(strReplaceAll);
                    loop0: while (matcher.find()) {
                        String strSubstring = strReplaceAll.substring(matcher.start(), matcher.end());
                        String strReplace = strReplaceAll.replace(strSubstring, ChatColor.of(strSubstring) + "");
                        if (jLongValue < 0) {
                            return strReplace;
                        }
                        strReplaceAll = strReplace;
                        matcher = patternCompile.matcher(strReplaceAll);
                        while (Vulcan_q != 0) {
                            if (Vulcan_q == 0) {
                                if (jLongValue > 0) {
                                    break loop0;
                                }
                            }
                        }
                        break loop0;
                    }
                    strReplaceAll = strReplaceAll.replace('&', (char) 167);
                    return strReplaceAll;
                }
                r0 = 38;
            }
            return ChatColor.translateAlternateColorCodes((char) r0, strReplaceAll);
        } catch (UnsupportedOperationException unused) {
            throw a((UnsupportedOperationException) Vulcan_q);
        }
    }
}
