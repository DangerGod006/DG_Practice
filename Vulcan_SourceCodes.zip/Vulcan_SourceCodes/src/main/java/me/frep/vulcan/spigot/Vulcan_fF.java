package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.CharEncoding;
import org.bukkit.Location;
import org.bukkit.event.player.PlayerTeleportEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_fF.class */
public class Vulcan_fF {
    private static final long a = Vulcan_n.a(6152252489369354366L, 4932139949882587860L, MethodHandles.lookup().lookupClass()).a(8769201399722L);
    private static final String[] b;

    static {
        int i;
        long j = a ^ 65575067404825L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[8];
        int i3 = 0;
        String str = "âq3\u001c\u000fótgÚ®â\u009fz\u008fmÏ(ÎW\u008bÑ¿\u0085ÅÕ\u000bÙöÀ¥(G\u0097¿¦\fi^[³D,Å]#ü.q5CN\u0086vÕ\u009e\u0001Ï(¯®¸\u0092ö\u008cS¥3\u0012Òûô)8TÔ\u00869\u008eÚêL=\u0081 ü5\u0002|öº£Å¹\u008fF4K\\(¯®¸\u0092ö\u008cS¥3\u0012Òûô)8TÔ\u00869\u008eÚêL=\u0081 ü5\u0002|öº£Å¹\u008fF4K\\\u0018µæ\u0081.m¢½©×\tlUÒh\u0097;\u009c0F4\u00ad\u001e/³(ÎW\u008bÑ¿\u0085ÅÕ\u000bÙöÀ¥(G\u0097¿¦\fi^[³D,Å]#ü.q5CN\u0086vÕ\u009e\u0001Ï";
        int length = "âq3\u001c\u000fótgÚ®â\u009fz\u008fmÏ(ÎW\u008bÑ¿\u0085ÅÕ\u000bÙöÀ¥(G\u0097¿¦\fi^[³D,Å]#ü.q5CN\u0086vÕ\u009e\u0001Ï(¯®¸\u0092ö\u008cS¥3\u0012Òûô)8TÔ\u00869\u008eÚêL=\u0081 ü5\u0002|öº£Å¹\u008fF4K\\(¯®¸\u0092ö\u008cS¥3\u0012Òûô)8TÔ\u00869\u008eÚêL=\u0081 ü5\u0002|öº£Å¹\u008fF4K\\\u0018µæ\u0081.m¢½©×\tlUÒh\u0097;\u009c0F4\u00ad\u001e/³(ÎW\u008bÑ¿\u0085ÅÕ\u000bÙöÀ¥(G\u0097¿¦\fi^[³D,Å]#ü.q5CN\u0086vÕ\u009e\u0001Ï".length();
        char cCharAt = 16;
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "âq3\u001c\u000fótgÚ®â\u009fz\u008fmÏ\b9\u0082<<¹\u00828§";
                        length = "âq3\u001c\u000fótgÚ®â\u009fz\u008fmÏ\b9\u0082<<¹\u00828§".length();
                        cCharAt = 16;
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Try blocks wrapping queue limit reached! Please report as an issue!
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.connectExcHandlers(BlockExceptionHandler.java:95)
        	at jadx.core.dex.visitors.blocks.BlockExceptionHandler.process(BlockExceptionHandler.java:61)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.independentBlockTreeMod(BlockProcessor.java:380)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:57)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public void Vulcan_h(java.lang.Object[] r15) {
        /*
            Method dump skipped, instruction units count: 4162
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_fF.Vulcan_h(java.lang.Object[]):void");
    }

    private static void lambda$handle$0(C0042Vulcan_Oz c0042Vulcan_Oz, Location location) {
        c0042Vulcan_Oz.Vulcan_e(new Object[0]).teleport(location, PlayerTeleportEvent.TeleportCause.UNKNOWN);
    }
}
