package me.frep.vulcan.spigot;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.frep.vulcan.spigot.check.AbstractCheck;
import org.apache.commons.lang3.CharEncoding;

/* JADX INFO: renamed from: me.frep.vulcan.spigot.Vulcan_ky, reason: case insensitive filesystem */
/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_ky.class */
public class C0055Vulcan_ky {
    private final String Vulcan_E;
    private String Vulcan_t;
    private String Vulcan_m;
    private String Vulcan_j;
    private boolean Vulcan_M;
    private List Vulcan_F = new ArrayList();
    private static AbstractCheck[] Vulcan_X;
    private static final long a = Vulcan_n.a(-5718386628372289015L, -4125414050503477198L, MethodHandles.lookup().lookupClass()).a(173967999333610L);
    private static final String[] b;

    public static void Vulcan_h(AbstractCheck[] abstractCheckArr) {
        Vulcan_X = abstractCheckArr;
    }

    public static AbstractCheck[] Vulcan_D() {
        return Vulcan_X;
    }

    static {
        int i;
        long j = a ^ 501571647921L;
        Vulcan_h(new AbstractCheck[3]);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] bArr = new byte[8];
        bArr[0] = (byte) (j >>> 56);
        for (int i2 = 1; i2 < 8; i2++) {
            bArr[i2] = (byte) ((j << (i2 * 8)) >>> 56);
        }
        cipher.init(2, secretKeyFactory.generateSecret(new DESKeySpec(bArr)), new IvParameterSpec(new byte[8]));
        String[] strArr = new String[28];
        int i3 = 0;
        String str = "O$ùM~ÅFë\u0010Î#tÈ{\u0088³Ðè\u0004Ì#\u008fw7[\b\u0006Ó\u0080Ùÿ°^©\b\u009eÐiû\u009fí°Ö\bø!»*Û²Ô\u008a\b¬{\u009e£§xlù\u0018¡P\rfl\u0086}²\u0089h¦±\u009b*)\u0086§Ê\u00adtî\u0018\u0094?\b¸AÍ\u009b`\u001d\u001c'\b\f\u0095yyÇßíÉ\u0010\n\u0017óS~üP\u0081Éd\u0080õ^ìçq\bYo1j=°ØÎ\bn²;Õ\u0012õ\u00adN\u0010ÿ\u0017=Ã²ø¸^\u0087\u0017\u0015º\u008a·£Å0Ö¿\u0098uKÉÜ@\u001e¶\u0088BzªÖ\u0001éF\u0086\u0081Q×\u000e\u0016N\\ßÿe\u0011r¨V\u008aÓÆ\u0086k)]#\u0099ÆZ\u0095C´Ï\u0010zÛÜ\u0080|:\u0092õx\u001bÛ\u0001\u0089\u007f\u000e\u008c\u0010âÈd\u009c·½\u001dÿÚ¼\u008a\u0093MI~ì\bÀ6\u0002ãYH\u008c5\bÀõ\u009fº\"ê\u0081(\u0010KÎü\u0010èx¯Î\u007fH/±E\u0016wÎ\b¸AÍ\u009b`\u001d\u001c'\b/\u0086\"\u0093\u0005±¥~\u0010Î#tÈ{\u0088³Ðè\u0004Ì#\u008fw7[\b¥\u001e¦Î[w\u0082·\b8\u009f\u0011\u00938º\u0087Ý\u0010Výè\u0095U)9/ÌcEqd, }\u0010;Ò\u0086È\u000eíàM\\\u008diÎïÍÁ÷";
        int length = "O$ùM~ÅFë\u0010Î#tÈ{\u0088³Ðè\u0004Ì#\u008fw7[\b\u0006Ó\u0080Ùÿ°^©\b\u009eÐiû\u009fí°Ö\bø!»*Û²Ô\u008a\b¬{\u009e£§xlù\u0018¡P\rfl\u0086}²\u0089h¦±\u009b*)\u0086§Ê\u00adtî\u0018\u0094?\b¸AÍ\u009b`\u001d\u001c'\b\f\u0095yyÇßíÉ\u0010\n\u0017óS~üP\u0081Éd\u0080õ^ìçq\bYo1j=°ØÎ\bn²;Õ\u0012õ\u00adN\u0010ÿ\u0017=Ã²ø¸^\u0087\u0017\u0015º\u008a·£Å0Ö¿\u0098uKÉÜ@\u001e¶\u0088BzªÖ\u0001éF\u0086\u0081Q×\u000e\u0016N\\ßÿe\u0011r¨V\u008aÓÆ\u0086k)]#\u0099ÆZ\u0095C´Ï\u0010zÛÜ\u0080|:\u0092õx\u001bÛ\u0001\u0089\u007f\u000e\u008c\u0010âÈd\u009c·½\u001dÿÚ¼\u008a\u0093MI~ì\bÀ6\u0002ãYH\u008c5\bÀõ\u009fº\"ê\u0081(\u0010KÎü\u0010èx¯Î\u007fH/±E\u0016wÎ\b¸AÍ\u009b`\u001d\u001c'\b/\u0086\"\u0093\u0005±¥~\u0010Î#tÈ{\u0088³Ðè\u0004Ì#\u008fw7[\b¥\u001e¦Î[w\u0082·\b8\u009f\u0011\u00938º\u0087Ý\u0010Výè\u0095U)9/ÌcEqd, }\u0010;Ò\u0086È\u000eíàM\\\u008diÎïÍÁ÷".length();
        char cCharAt = '\b';
        int i4 = -1;
        while (true) {
            int i5 = i4 + 1;
            String strSubstring = str.substring(i5, i5 + cCharAt);
            byte b2 = -1;
            while (true) {
                String str2 = strSubstring;
                byte b3 = b2;
                String strIntern = a(cipher.doFinal(str2.getBytes(CharEncoding.ISO_8859_1))).intern();
                switch (b3) {
                    case 0:
                        int i6 = i3;
                        i3++;
                        strArr[i6] = strIntern;
                        int i7 = i5 + cCharAt;
                        i = i7;
                        if (i7 >= length) {
                            b = strArr;
                            return;
                        }
                        cCharAt = str.charAt(i);
                        break;
                    default:
                        int i8 = i3;
                        i3++;
                        strArr[i8] = strIntern;
                        int i9 = i5 + cCharAt;
                        i4 = i9;
                        if (i9 < length) {
                        }
                        str = "ø!»*Û²Ô\u008a\b¯\u0082\u000eS<\u0004ç5";
                        length = "ø!»*Û²Ô\u008a\b¯\u0082\u000eS<\u0004ç5".length();
                        cCharAt = '\b';
                        i = -1;
                        break;
                        break;
                }
                i5 = i + 1;
                strSubstring = str.substring(i5, i5 + cCharAt);
                b2 = 0;
            }
            cCharAt = str.charAt(i4);
        }
    }

    private static IOException a(IOException iOException) {
        return iOException;
    }

    private static String a(byte[] bArr) {
        int i = 0;
        int length = bArr.length;
        char[] cArr = new char[length];
        int i2 = 0;
        while (i2 < length) {
            int i3 = 255 & bArr[i2];
            if (i3 < 192) {
                int i4 = i;
                i++;
                cArr[i4] = (char) i3;
            } else if (i3 < 224) {
                i2++;
                int i5 = i;
                i++;
                cArr[i5] = (char) (((char) (((char) (i3 & 31)) << 6)) | ((char) (bArr[i2] & 63)));
            } else if (i2 < length - 2) {
                int i6 = i2 + 1;
                char c = (char) (((char) (((char) (i3 & 15)) << '\f')) | (((char) (bArr[i6] & 63)) << 6));
                i2 = i6 + 1;
                int i7 = i;
                i++;
                cArr[i7] = (char) (c | ((char) (bArr[i2] & 63)));
            }
            i2++;
        }
        return new String(cArr, 0, i);
    }

    public C0055Vulcan_ky(String str) {
        this.Vulcan_E = str;
    }

    public void Vulcan_v(Object[] objArr) {
        this.Vulcan_t = (String) objArr[0];
    }

    public void Vulcan_B(Object[] objArr) {
        this.Vulcan_m = (String) objArr[0];
    }

    public void Vulcan_k(Object[] objArr) {
        this.Vulcan_j = (String) objArr[0];
    }

    public void Vulcan_o(Object[] objArr) {
        this.Vulcan_M = ((Boolean) objArr[0]).booleanValue();
    }

    public void Vulcan_A(Object[] objArr) {
        this.Vulcan_F.add((Vulcan_kZ) objArr[0]);
    }

    /* JADX WARN: Code restructure failed: missing block: B:71:0x05bb, code lost:
    
        r2 = me.frep.vulcan.spigot.C0055Vulcan_ky.b[5];
        r4 = new java.lang.Object[3];
        r4[2] = r0.toArray();
        r4[1] = r2;
        r0[0] = java.lang.Long.valueOf(r1);
        r4.Vulcan_D(r4);
        r0.add(r0);
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0046 A[Catch: IOException -> 0x0054, TryCatch #2 {IOException -> 0x0054, blocks: (B:13:0x003b, B:15:0x0046, B:16:0x0053), top: B:82:0x003b }] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x01d3  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x062d A[EDGE_INSN: B:90:0x062d->B:77:0x062d BREAK  A[LOOP:0: B:22:0x0126->B:94:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:91:0x0600 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v101, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v102 */
    /* JADX WARN: Type inference failed for: r0v108, types: [me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v117, types: [me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v122, types: [me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v127, types: [me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v134 */
    /* JADX WARN: Type inference failed for: r0v136 */
    /* JADX WARN: Type inference failed for: r0v151, types: [me.frep.vulcan.spigot.Vulcan_ky] */
    /* JADX WARN: Type inference failed for: r0v152, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v156, types: [java.lang.IllegalArgumentException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v157 */
    /* JADX WARN: Type inference failed for: r0v158 */
    /* JADX WARN: Type inference failed for: r0v159 */
    /* JADX WARN: Type inference failed for: r0v160 */
    /* JADX WARN: Type inference failed for: r0v161 */
    /* JADX WARN: Type inference failed for: r0v162 */
    /* JADX WARN: Type inference failed for: r0v4, types: [me.frep.vulcan.spigot.check.AbstractCheck[]] */
    /* JADX WARN: Type inference failed for: r0v46 */
    /* JADX WARN: Type inference failed for: r0v48 */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v50, types: [java.lang.Object, me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v51, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v53, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v54, types: [java.io.IOException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r0v61 */
    /* JADX WARN: Type inference failed for: r0v62, types: [me.frep.vulcan.spigot.Vulcan_kZ] */
    /* JADX WARN: Type inference failed for: r0v63, types: [me.frep.vulcan.spigot.Vulcan_kZ] */
    /* JADX WARN: Type inference failed for: r0v7, types: [me.frep.vulcan.spigot.Vulcan_ky] */
    /* JADX WARN: Type inference failed for: r0v8, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r0v82 */
    /* JADX WARN: Type inference failed for: r0v83 */
    /* JADX WARN: Type inference failed for: r0v91, types: [java.lang.Object, me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r0v92, types: [java.io.IOException] */
    /* JADX WARN: Type inference failed for: r1v128 */
    /* JADX WARN: Type inference failed for: r1v129 */
    /* JADX WARN: Type inference failed for: r1v50 */
    /* JADX WARN: Type inference failed for: r1v51, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v101, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v115, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v129, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v143, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v157, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v171, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v181, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v195, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v205, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v21, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v219, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v229, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v243, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v257, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v267, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v277, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v31, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v41, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v53, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v65, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v77, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Type inference failed for: r4v87, types: [java.lang.Object[], me.frep.vulcan.spigot.Vulcan_fC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:75:0x05fd -> B:25:0x0137). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void Vulcan_c(java.lang.Object[] r10) throws java.io.IOException {
        /*
            Method dump skipped, instruction units count: 1699
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.C0055Vulcan_ky.Vulcan_c(java.lang.Object[]):void");
    }
}
