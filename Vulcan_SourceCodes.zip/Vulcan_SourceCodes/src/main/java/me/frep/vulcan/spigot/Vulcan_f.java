package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_f.class */
class Vulcan_f {
    private final Object Vulcan_N;
    private final Object Vulcan_z;
    private static final long a = Vulcan_n.a(4192968100812111838L, -8270244104109578325L, MethodHandles.lookup().lookupClass()).a(223827601394414L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    static Object Vulcan_G(Object[] objArr) {
        return ((Vulcan_f) objArr[0]).Vulcan_N;
    }

    static Object Vulcan_V(Object[] objArr) {
        return ((Vulcan_f) objArr[0]).Vulcan_z;
    }

    Vulcan_f(Object obj, Object obj2) {
        this.Vulcan_N = obj;
        this.Vulcan_z = obj2;
    }

    /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: Unreachable block: B:16:0x0040
        	at jadx.core.dex.visitors.blocks.BlockProcessor.checkForUnreachableBlocks(BlockProcessor.java:132)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:58)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:50)
        */
    public boolean equals(java.lang.Object r6) {
        /*
            r5 = this;
            long r0 = me.frep.vulcan.spigot.Vulcan_f.a
            r1 = 54832780194385(0x31dec062b251, double:2.709099296001E-310)
            long r0 = r0 ^ r1
            r7 = r0
            java.lang.String[] r0 = me.frep.vulcan.spigot.Vulcan_C.Vulcan_Z()
            r9 = r0
            r0 = r6
            boolean r0 = r0 instanceof me.frep.vulcan.spigot.Vulcan_f     // Catch: java.lang.RuntimeException -> L1c
            r1 = r9
            if (r1 != 0) goto L35
            if (r0 == 0) goto L6c
            goto L20
        L1c:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L31
            throw r0     // Catch: java.lang.RuntimeException -> L31
        L20:
            r0 = r5
            java.lang.Object r0 = r0.Vulcan_N     // Catch: java.lang.RuntimeException -> L31
            r1 = r6
            me.frep.vulcan.spigot.Vulcan_f r1 = (me.frep.vulcan.spigot.Vulcan_f) r1     // Catch: java.lang.RuntimeException -> L31
            java.lang.Object r1 = r1.Vulcan_N     // Catch: java.lang.RuntimeException -> L31
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L31
            goto L35
        L31:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L35:
            r1 = r9
            if (r1 != 0) goto L59
            if (r0 == 0) goto L6c
            goto L44
        L40:
            java.lang.RuntimeException r0 = a(r0)     // Catch: java.lang.RuntimeException -> L55
            throw r0     // Catch: java.lang.RuntimeException -> L55
        L44:
            r0 = r5
            java.lang.Object r0 = r0.Vulcan_z     // Catch: java.lang.RuntimeException -> L55
            r1 = r6
            me.frep.vulcan.spigot.Vulcan_f r1 = (me.frep.vulcan.spigot.Vulcan_f) r1     // Catch: java.lang.RuntimeException -> L55
            java.lang.Object r1 = r1.Vulcan_z     // Catch: java.lang.RuntimeException -> L55
            boolean r0 = r0.equals(r1)     // Catch: java.lang.RuntimeException -> L55
            goto L59
        L55:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L59:
            r1 = r9
            if (r1 != 0) goto L69
            if (r0 == 0) goto L6c
            goto L68
        L64:
            java.lang.RuntimeException r0 = a(r0)
            throw r0
        L68:
            r0 = 1
        L69:
            goto L6d
        L6c:
            r0 = 0
        L6d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: me.frep.vulcan.spigot.Vulcan_f.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return this.Vulcan_N.hashCode();
    }
}
