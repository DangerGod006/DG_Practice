package me.frep.vulcan.spigot.check.impl.combat.velocity;

import com.github.retrooper.packetevents.event.PacketEvent;
import me.frep.vulcan.spigot.C0042Vulcan_Oz;
import me.frep.vulcan.spigot.check.AbstractCheck;
import me.frep.vulcan.spigot.check.api.CheckInfo;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/check/impl/combat/velocity/VelocityC.class */
@CheckInfo(name = "Velocity", type = 'C', complexType = "Ignored Vertical", description = "Vertical velocity modifications.")
public class VelocityC extends AbstractCheck {
    public VelocityC(C0042Vulcan_Oz c0042Vulcan_Oz) {
        super(c0042Vulcan_Oz);
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object[], me.frep.vulcan.spigot.check.impl.combat.velocity.VelocityC] */
    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_T(Object[] objArr) {
        PacketEvent packetEvent = (PacketEvent) objArr[0];
        long jLongValue = ((Long) objArr[1]).longValue() ^ 99138911307370L;
        ?? r3 = new Object[2];
        r3[1] = packetEvent;
        this[0] = Long.valueOf(jLongValue);
        if (r3.Vulcan_K(r3)) {
        }
    }

    @Override // me.frep.vulcan.spigot.check.AbstractCheck
    public void Vulcan_a(Object[] objArr) {
        ((Long) objArr[1]).longValue();
    }
}
