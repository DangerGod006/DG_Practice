package me.frep.vulcan.spigot;

import java.lang.invoke.MethodHandles;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRiptideEvent;

/* JADX INFO: loaded from: Vulcan-2.9.7.23.jar:me/frep/vulcan/spigot/Vulcan_f6.class */
public class Vulcan_f6 implements Listener {
    private static final long a = Vulcan_n.a(-292779153968131777L, -4988028450258693882L, MethodHandles.lookup().lookupClass()).a(92710861631805L);

    private static RuntimeException a(RuntimeException runtimeException) {
        return runtimeException;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void Vulcan_f(PlayerRiptideEvent playerRiptideEvent) {
        long j = a ^ 74736313905293L;
        Player player = playerRiptideEvent.getPlayer();
        String[] strArrVulcan_G = C0038Vulcan_Om.Vulcan_G();
        C0042Vulcan_Oz c0042Vulcan_OzVulcan_L = Vulcan_r.INSTANCE.m1082Vulcan_r().Vulcan_L(new Object[]{player});
        C0042Vulcan_Oz c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
        if (strArrVulcan_G == null) {
            if (c0042Vulcan_Oz == null) {
                return;
            } else {
                c0042Vulcan_Oz = c0042Vulcan_OzVulcan_L;
            }
        }
        c0042Vulcan_Oz.m639Vulcan_M(new Object[0]).Vulcan_UT(new Object[]{0});
    }
}
