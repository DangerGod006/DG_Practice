package com.d4nger.smputils.gui;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.managers.RecipeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class RecipeEditGUI implements InventoryHolder {

    private final SMPUtils plugin;
    private final Inventory inventory;

    public RecipeEditGUI(SMPUtils plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54,
                MiniMessage.miniMessage().deserialize("<gradient:#FF5500:#FF0000>ᴛᴏᴜʀɴᴀᴍᴇɴᴛ ʀᴇᴄɪᴘᴇ ᴇᴅɪᴛᴏʀ</gradient>"));
        setupItems();
    }

    private void setupItems() {
        // Black background
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inventory.setItem(i, black);

        // Gray border
        ItemStack gray = createItem(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i <= 8; i++) inventory.setItem(i, gray);
        for (int i = 45; i <= 53; i++) inventory.setItem(i, gray);

        // Header
        ItemStack header = createItem(Material.WRITABLE_BOOK,
                "<gradient:#FFAA00:#FF5500>ᴛᴏᴜʀɴᴀᴍᴇɴᴛ ʀᴇᴄɪᴘᴇ ᴇᴅɪᴛᴏʀ</gradient>",
                "<gray>ʟᴇꜰᴛ-ᴄʟɪᴄᴋ = ᴛᴏɢɢʟᴇ</gray>",
                "<gray>ꜱʜɪꜰᴛ-ᴄʟɪᴄᴋ = ᴄʀᴇᴀᴛᴇ ɴᴇᴡ ʀᴇᴄɪᴘᴇ</gray>",
                "<gray>ʀɪɢʜᴛ-ᴄʟɪᴄᴋ = ᴅᴇʟᴇᴛᴇ ʀᴇᴄɪᴘᴇ</gray>");
        inventory.setItem(4, header);

        // Recipes
        Map<String, RecipeManager.RecipeData> recipes = plugin.getRecipeManager().getRecipes();
        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        int index = 0;

        for (Map.Entry<String, RecipeManager.RecipeData> entry : recipes.entrySet()) {
            if (index >= slots.length) break;

            RecipeManager.RecipeData data = entry.getValue();
            boolean enabled = plugin.getRecipeManager().isEnabled(entry.getKey());

            ItemStack item;
            if (enabled) {
                item = createItem(data.resultMaterial(), data.displayName(),
                        "<green>✓ ᴇɴᴀʙʟᴇᴅ</green>",
                        "<gray>ʟᴇꜰᴛ-ᴄʟɪᴄᴋ: ᴛᴏɢɢʟᴇ</gray>",
                        "<gray>ʀɪɢʜᴛ-ᴄʟɪᴄᴋ: ᴅᴇʟᴇᴛᴇ</gray>");
            } else {
                item = createItem(Material.GRAY_STAINED_GLASS_PANE,
                        "<dark_gray>🔒 " + stripTags(data.displayName()) + "</dark_gray>",
                        "<red>✘ ᴅɪꜱᴀʙʟᴇᴅ</red>",
                        "<gray>ʟᴇꜰᴛ-ᴄʟɪᴄᴋ: ᴇɴᴀʙʟᴇ</gray>");
            }
            inventory.setItem(slots[index], item);
            index++;
        }

        // Create new recipe button (shift click hint)
        ItemStack create = createItem(Material.EMERALD,
                "<green>➕ ᴄʀᴇᴀᴛᴇ ɴᴇᴡ ʀᴇᴄɪᴘᴇ</green>",
                "<gray>ꜱʜɪꜰᴛ + ʟᴇꜰᴛ ᴄʟɪᴄᴋ ᴀɴʏ ᴇᴍᴘᴛʏ ꜱʟᴏᴛ</gray>");
        inventory.setItem(49, create);

        // Close
        ItemStack close = createItem(Material.REDSTONE, "<red>✗ ᴄʟᴏꜱᴇ</red>");
        inventory.setItem(53, close);
    }

    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            // Disable italic
            meta.displayName(MiniMessage.miniMessage().deserialize("<!italic>" + name));
            if (lore.length > 0) {
                List<net.kyori.adventure.text.Component> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(MiniMessage.miniMessage().deserialize("<!italic>" + line));
                }
                meta.lore(loreList);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private String stripTags(String text) {
        return text.replaceAll("<[^>]+>", "");
    }

    public void open(Player player) {
        player.openInventory(inventory);
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_CHEST_OPEN, 0.8f, 1.0f);
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}