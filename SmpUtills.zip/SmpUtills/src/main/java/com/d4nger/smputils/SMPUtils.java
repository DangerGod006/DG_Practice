package com.d4nger.smputils;

import com.d4nger.smputils.commands.KeepInventoryCommand;
import com.d4nger.smputils.commands.RecipeCommand;
import com.d4nger.smputils.commands.TournamentCommand;
import com.d4nger.smputils.listeners.GUIListener;
import com.d4nger.smputils.listeners.LocationListener;
import com.d4nger.smputils.managers.LocationManager;
import com.d4nger.smputils.managers.RecipeManager;
import com.d4nger.smputils.managers.WorldGuardManager;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Level;

public final class SMPUtils extends JavaPlugin {

    private static SMPUtils instance;
    private RecipeManager recipeManager;
    private LocationManager locationManager;
    private WorldGuardManager worldGuardManager;
    private File dataFile;
    private FileConfiguration dataConfig;
    private Map<Integer, Location> savedPositions = new HashMap<>();

    @Override
    public void onEnable() {
        instance = this;

        // Recipe Manager
        this.recipeManager = new RecipeManager(this);
        recipeManager.registerAllRecipes();

        // Data file
        loadDataFile();

        // Location Manager
        this.locationManager = new LocationManager(this);
        // WorldGuard Manager
        this.worldGuardManager = new WorldGuardManager(this);

        // Commands
        RecipeCommand recipeCommand = new RecipeCommand(this);
        TournamentCommand tournamentCommand = new TournamentCommand(this);
        KeepInventoryCommand keepInventoryCommand = new KeepInventoryCommand();
        Objects.requireNonNull(getCommand("recipe")).setExecutor(recipeCommand);
        Objects.requireNonNull(getCommand("recipe")).setTabCompleter(recipeCommand);
        Objects.requireNonNull(getCommand("tournament")).setExecutor(tournamentCommand);
        Objects.requireNonNull(getCommand("tournament")).setTabCompleter(tournamentCommand);
        Objects.requireNonNull(getCommand("tmkp")).setExecutor(keepInventoryCommand);
        Objects.requireNonNull(getCommand("tmkp")).setTabCompleter(keepInventoryCommand);

        // Listeners (JoinReminderListener removed)
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new LocationListener(this), this);

        getLogger().log(Level.INFO,
                "TournamentRecipes v{0} enabled successfully!",
                getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        if (recipeManager != null) {
            recipeManager.unregisterAllRecipes();
        }
        saveDataConfig();
        getLogger().info("TournamentRecipes disabled.");
        instance = null;
    }

    public static SMPUtils getInstance() {
        return instance;
    }

    public RecipeManager getRecipeManager() {
        return recipeManager;
    }

    private void loadDataFile() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            saveResource("data.yml", false);
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        loadSavedPositions();
    }

    public void saveDataConfig() {
        // Save positions to config
        for (Map.Entry<Integer, Location> entry : savedPositions.entrySet()) {
            dataConfig.set("positions." + entry.getKey(), entry.getValue());
        }

        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }

    private void loadSavedPositions() {
        savedPositions.clear();
        if (dataConfig.contains("positions")) {
            for (String key : dataConfig.getConfigurationSection("positions").getKeys(false)) {
                try {
                    int posNum = Integer.parseInt(key);
                    Location loc = (Location) dataConfig.get("positions." + key);
                    if (loc != null) {
                        savedPositions.put(posNum, loc);
                    }
                } catch (Exception e) {
                    getLogger().warning("Invalid position " + key + " in data.yml");
                }
            }
        }
    }

    public Map<Integer, Location> getSavedPositions() {
        return savedPositions;
    }

    public void setSavedPosition(int number, Location location) {
        savedPositions.put(number, location);
        saveDataConfig();
    }

    public void removeSavedPosition(int number) {
        savedPositions.remove(number);
        dataConfig.set("positions." + number, null);
        saveDataConfig();
    }

    // Getters for data file and location manager
    public File getDataFile() {
        return dataFile;
    }

    public FileConfiguration getDataConfig() {
        return dataConfig;
    }

    public LocationManager getLocationManager() {
        return locationManager;
    }

    public WorldGuardManager getWorldGuardManager() {
        return worldGuardManager;
    }
}