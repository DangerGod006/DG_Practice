package com.d4nger.smputils.commands;

import com.d4nger.smputils.SMPUtils;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class KeepInventoryCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (!sender.hasPermission("recipes.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§eUsage: /tmkp on | /tmkp off");
            return true;
        }

        boolean enable = args[0].equalsIgnoreCase("on");

        // Folia compatible: Use global region scheduler
        SMPUtils.getInstance().getServer().getGlobalRegionScheduler().run(SMPUtils.getInstance(), (task) -> {
            Bukkit.getWorlds().forEach(world -> {
                world.setGameRule(GameRule.KEEP_INVENTORY, enable);
            });
        });

        String status = enable ? "<green><bold>ENABLED</bold></green>" : "<red><bold>DISABLED</bold></red>";

        // Title Announcement
        Title title = Title.title(
                MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500><bold>KEEPINVENTORY</bold></gradient>"),
                MiniMessage.miniMessage().deserialize(status),
                Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2500), Duration.ofMillis(300)));

        // Broadcast to all players
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(title);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.0f);
        }

        // Chat Message
        String chatMsg = enable
                ? "<gradient:#58FF00:#29FF06><bold>✓ ᴋᴇᴇᴘɪɴᴠᴇɴᴛᴏʀʏ ʜᴀꜱ ʙᴇᴇɴ ENABLED!</bold></gradient>"
                : "<gradient:#FF4444:#AA0000><bold>✗ ᴋᴇᴇᴘɪɴᴠᴇɴᴛᴏʀʏ ʜᴀꜱ ʙᴇᴇɴ DISABLED!</bold></gradient>";

        Bukkit.broadcast(MiniMessage.miniMessage().deserialize(chatMsg));

        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return filterSuggestions(args[0], List.of("on", "off"));
        }
        return List.of();
    }

    private List<String> filterSuggestions(String input, List<String> options) {
        String lowerInput = input.toLowerCase();
        List<String> filtered = new java.util.ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase().startsWith(lowerInput)) {
                filtered.add(option);
            }
        }
        return filtered;
    }
}