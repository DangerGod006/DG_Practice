package com.d4nger.smputils.listeners;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.gui.RecipeEditGUI;
import com.d4nger.smputils.gui.RecipeGridEditGUI;
import com.d4nger.smputils.gui.RecipeListGUI;
import com.d4nger.smputils.gui.RecipeViewGUI;
import com.d4nger.smputils.managers.RecipeManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class GUIListener implements Listener {

    private final SMPUtils plugin;
    private final Map<UUID, String> creatingRecipe = new HashMap<>();

    public GUIListener(SMPUtils plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        InventoryHolder holder = event.getInventory().getHolder();

        if (holder instanceof RecipeListGUI) {
            event.setCancelled(true);
            handleListClick(player, event.getSlot());
        }

        if (holder instanceof RecipeViewGUI view) {
            event.setCancelled(true);
            handleViewClick(player, event.getSlot(), view);
        }

        if (holder instanceof RecipeEditGUI) {
            event.setCancelled(true);
            handleEditClick(player, event.getSlot(), event.isShiftClick(), event.isRightClick());
        }

        if (holder instanceof RecipeGridEditGUI gridGui) {
            event.setCancelled(true);
            handleGridEditClick(player, gridGui, event.getSlot(), event.isRightClick());
        }
    }

    // ==================== LIST GUI ====================
    private void handleListClick(Player player, int slot) {
        if (slot == 40) { // Close button
            player.closeInventory();
            player.playSound(player.getLocation(), Sound.BLOCK_CHEST_CLOSE, 0.8f, 1.0f);
            return;
        }

        // Recipe slots (middle row)
        int[] recipeSlots = {19, 20, 21, 22, 23, 24, 25};

        for (int i = 0; i < recipeSlots.length; i++) {
            if (slot == recipeSlots[i]) {
                RecipeManager manager = plugin.getRecipeManager();
                List<String> recipeIds = new ArrayList<>(manager.getRecipes().keySet());

                if (i < recipeIds.size()) {
                    String recipeId = recipeIds.get(i);
                    if (manager.isEnabled(recipeId)) {
                        new RecipeViewGUI(plugin, recipeId).open(player);
                    } else {
                        player.sendMessage("§cThis recipe is disabled.");
                    }
                }
                return;
            }
        }
    }

    // ==================== VIEW GUI ====================
    private void handleViewClick(Player player, int slot, RecipeViewGUI view) {
        if (slot == 40) {
            new RecipeListGUI(plugin).open(player);
        } else if (slot == 44) {
            player.closeInventory();
        }
    }

    // ==================== EDIT GUI ====================
    private void handleEditClick(Player player, int slot, boolean shift, boolean rightClick) {
        RecipeManager manager = plugin.getRecipeManager();

        if (slot == 53) {
            player.closeInventory();
            return;
        }

        // Create new recipe
        if (slot == 49 && shift) {
            player.closeInventory();
            player.sendMessage("§eType the §bname§e of the new recipe in chat:");
            creatingRecipe.put(player.getUniqueId(), "WAITING");
            return;
        }

        // Dynamic recipe detection
        List<String> recipeIds = new ArrayList<>(manager.getRecipes().keySet());
        int[] recipeSlots = {19, 20, 21, 22, 23, 24, 25};

        for (int i = 0; i < recipeSlots.length; i++) {
            if (slot == recipeSlots[i]) {
                if (i >= recipeIds.size()) {
                    return;
                }

                String recipeId = recipeIds.get(i);

                if (shift && rightClick) {
                    // Shift + Right Click → Grid Editor
                    new RecipeGridEditGUI(plugin, recipeId).open(player);
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.0f);
                } else if (rightClick) {
                    // Delete
                    manager.getRecipesConfig().set("recipes." + recipeId, null);
                    manager.saveRecipesConfig();
                    manager.unregisterAllRecipes();
                    manager.registerAllRecipes();
                    new RecipeEditGUI(plugin).open(player);
                    player.sendMessage("§cRecipe deleted: §f" + recipeId);
                } else {
                    // Toggle
                    boolean current = manager.isEnabled(recipeId);
                    manager.setEnabled(recipeId, !current);
                    new RecipeEditGUI(plugin).open(player);
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.0f);
                }
                return;
            }
        }
    }

    // ==================== GRID EDIT GUI ====================
    private void handleGridEditClick(Player player, RecipeGridEditGUI gridGui, int slot, boolean rightClick) {
        String recipeId = gridGui.getRecipeId();
        Material[] grid = gridGui.getWorkingGrid();
        int gridIndex = gridGui.getGridIndex(slot);

        if (slot == 53) {
            player.closeInventory();
            return;
        }

        if (slot == 45) {
            new RecipeEditGUI(plugin).open(player);
            return;
        }

        if (slot == 40) {
            plugin.getRecipeManager().saveGridToConfig(recipeId, grid);
            plugin.getRecipeManager().unregisterAllRecipes();
            plugin.getRecipeManager().registerAllRecipes();
            player.sendMessage("§aRecipe grid saved!");
            new RecipeEditGUI(plugin).open(player);
            return;
        }

        if (gridIndex != -1) {
            if (rightClick) {
                grid[gridIndex] = null;
            } else {
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand.getType() != Material.AIR && hand.getType().isItem()) {
                    grid[gridIndex] = hand.getType();
                } else {
                    player.sendMessage("§cHold an item in your hand!");
                    return;
                }
            }
            new RecipeGridEditGUI(plugin, recipeId).open(player);
        }
    }

    // ==================== CHAT FOR NEW RECIPE ====================
    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!creatingRecipe.containsKey(player.getUniqueId())) {
            return;
        }

        event.setCancelled(true);
        String name = event.getMessage().trim().toLowerCase().replace(" ", "_");

        if (name.isEmpty() || plugin.getRecipeManager().getRecipe(name) != null) {
            player.sendMessage("§cInvalid or duplicate name. Try again.");
            creatingRecipe.remove(player.getUniqueId());
            return;
        }

        // Folia compatible: Run config changes on global region scheduler
        plugin.getServer().getGlobalRegionScheduler().run(plugin, (task) -> {
            // Create new recipe
            plugin.getRecipeManager().getRecipesConfig().set("recipes." + name + ".enabled", true);
            plugin.getRecipeManager().getRecipesConfig().set("recipes." + name + ".result-amount", 1);
            for (int i = 0; i < 9; i++) {
                plugin.getRecipeManager().getRecipesConfig().set("recipes." + name + ".grid." + i, "AIR");
            }
            plugin.getRecipeManager().saveRecipesConfig();
            plugin.getRecipeManager().unregisterAllRecipes();
            plugin.getRecipeManager().registerAllRecipes();

            creatingRecipe.remove(player.getUniqueId());
            player.sendMessage("§aRecipe created: §f" + name);
            new RecipeEditGUI(plugin).open(player);
        });
    }
}