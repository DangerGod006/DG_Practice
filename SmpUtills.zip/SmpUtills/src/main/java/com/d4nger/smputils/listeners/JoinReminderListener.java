package com.d4nger.smputils.listeners;

import com.d4nger.smputils.SMPUtils;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class JoinReminderListener implements Listener {

    private final SMPUtils plugin;

    public JoinReminderListener(SMPUtils plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.getConfig().getBoolean("join-reminder.enabled", true)) {
            return;
        }

        Player player = event.getPlayer();

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    return;
                }

                List<String> messages = plugin.getConfig().getStringList("join-reminder.messages.join");

                if (messages == null || messages.isEmpty()) {
                    return;
                }

                for (String line : messages) {
                    player.sendMessage(MiniMessage.miniMessage().deserialize(line));
                }

                String soundName = plugin.getConfig().getString("join-reminder.sounds.reminder", "ENTITY_EXPERIENCE_ORB_PICKUP");
                try {
                    Sound sound = Sound.valueOf(soundName);
                    player.playSound(player.getLocation(), sound, 0.8f, 1.2f);
                } catch (Exception ignored) {}
            }
        }.runTaskLater(plugin, 40L);
    }
}