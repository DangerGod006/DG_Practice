package com.d4nger.smputils.commands;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.gui.RecipeEditGUI;
import com.d4nger.smputils.gui.RecipeListGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class RecipeCommand implements CommandExecutor, TabCompleter {

    private final SMPUtils plugin;

    public RecipeCommand(SMPUtils plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("edit")) {
            if (!player.hasPermission("recipes.admin")) {
                player.sendMessage("§cYou don't have permission to edit recipes.");
                return true;
            }
            new RecipeEditGUI(plugin).open(player);
        } else {
            new RecipeListGUI(plugin).open(player);
        }
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return filterSuggestions(args[0], List.of("edit"));
        }
        return List.of();
    }

    private List<String> filterSuggestions(String input, List<String> options) {
        String lowerInput = input.toLowerCase();
        List<String> filtered = new java.util.ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase().startsWith(lowerInput)) {
                filtered.add(option);
            }
        }
        return filtered;
    }
}