package com.d4nger.smputils.gui;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.managers.RecipeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class RecipeViewGUI implements InventoryHolder {

    private final SMPUtils plugin;
    private final Inventory inventory;
    private final String recipeId;

    public RecipeViewGUI(SMPUtils plugin, String recipeId) {
        this.plugin = plugin;
        this.recipeId = recipeId;
        this.inventory = Bukkit.createInventory(this, 45,
                MiniMessage.miniMessage().deserialize("<gradient:#00BFFF:#1E90FF>Recipe Preview</gradient>"));
        setupItems();
    }

    private void setupItems() {
        // Black background
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 45; i++) inventory.setItem(i, black);

        RecipeManager.RecipeData data = plugin.getRecipeManager().getRecipe(recipeId);
        if (data == null) return;

        Material[] grid = plugin.getRecipeManager().loadGrid(recipeId, new Material[9]);

        // Crafting grid positions (3x3)
        int[] gridSlots = {11, 12, 13, 20, 21, 22, 29, 30, 31};
        for (int i = 0; i < 9; i++) {
            ItemStack item = grid[i] != null ? new ItemStack(grid[i]) : new ItemStack(Material.AIR);
            inventory.setItem(gridSlots[i], item);
        }

        // Result item
        ItemStack result = new ItemStack(data.resultMaterial(), data.resultAmount());
        ItemMeta meta = result.getItemMeta();
        if (meta != null) {
            meta.displayName(MiniMessage.miniMessage().deserialize(data.displayName()));
            result.setItemMeta(meta);
        }
        inventory.setItem(24, result);

        // Back button
        ItemStack back = createItem(Material.ARROW, "<gray>ʙᴀᴄᴋ ᴛᴏ ʟɪꜱᴛ</gray>");
        inventory.setItem(40, back);

        // Close button
        ItemStack close = createItem(Material.REDSTONE, "<red>ᴄʟᴏꜱᴇ</red>");
        inventory.setItem(44, close);
    }

    private ItemStack createItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            // Disable italic
            meta.displayName(MiniMessage.miniMessage().deserialize("<!italic>" + name));
            item.setItemMeta(meta);
        }
        return item;
    }

    public void open(Player player) {
        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.8f, 1.0f);
    }

    public String getRecipeId() {
        return recipeId;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}