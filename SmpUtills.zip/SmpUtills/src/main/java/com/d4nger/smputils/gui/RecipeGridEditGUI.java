package com.d4nger.smputils.gui;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.managers.RecipeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class RecipeGridEditGUI implements InventoryHolder {

    private final SMPUtils plugin;
    private final Inventory inventory;
    private final String recipeId;
    private final Material[] workingGrid;

    public RecipeGridEditGUI(SMPUtils plugin, String recipeId) {
        this.plugin = plugin;
        this.recipeId = recipeId;
        this.workingGrid = plugin.getRecipeManager().loadGrid(recipeId, new Material[9]);
        this.inventory = Bukkit.createInventory(this, 54,
                MiniMessage.miniMessage().deserialize("<gradient:#00AAFF:#0066CC>Edit Grid: " + recipeId + "</gradient>"));
        setupItems();
    }

    private void setupItems() {
        // Background
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) {
            inventory.setItem(i, black);
        }

        // Grid slots (10-12, 19-21, 28-30)
        int[] gridSlots = {10,11,12, 19,20,21, 28,29,30};
        for (int i = 0; i < 9; i++) {
            ItemStack item = workingGrid[i] != null ? new ItemStack(workingGrid[i]) : new ItemStack(Material.AIR);
            inventory.setItem(gridSlots[i], item);
        }

        // Result
        RecipeManager.RecipeData data = plugin.getRecipeManager().getRecipe(recipeId);
        if (data != null) {
            ItemStack result = new ItemStack(data.resultMaterial(), data.resultAmount());
            ItemMeta meta = result.getItemMeta();
            if (meta != null) {
                meta.displayName(MiniMessage.miniMessage().deserialize(data.displayName()));
                result.setItemMeta(meta);
            }
            inventory.setItem(24, result);
        }

        // Instructions
        ItemStack info = createItem(Material.BOOK,
                "<yellow>ʜᴏᴡ ᴛᴏ ᴇᴅɪᴛ</yellow>",
                "<gray>ᴄʟɪᴄᴋ ɢʀɪᴅ ꜱʟᴏᴛ ᴡɪᴛʜ ɪᴛᴇᴍ ɪɴ ʜᴀɴᴅ</gray>",
                "<gray>ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ ʀᴇᴍᴏᴠᴇ ɪᴛᴇᴍ</gray>");
        inventory.setItem(4, info);

        // Save button
        ItemStack save = createItem(Material.EMERALD, "<green>✓ ꜱᴀᴠᴇ ᴄʜᴀɴɢᴇꜱ</green>");
        inventory.setItem(40, save);

        // Back button
        ItemStack back = createItem(Material.ARROW, "<gray>ʙᴀᴄᴋ ᴛᴏ ᴇᴅɪᴛᴏʀ</gray>");
        inventory.setItem(45, back);

        // Close
        ItemStack close = createItem(Material.REDSTONE, "<red>ᴄʟᴏꜱᴇ</red>");
        inventory.setItem(53, close);
    }

    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            // Disable italic
            meta.displayName(MiniMessage.miniMessage().deserialize("<!italic>" + name));
            if (lore.length > 0) {
                List<net.kyori.adventure.text.Component> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(MiniMessage.miniMessage().deserialize("<!italic>" + line));
                }
                meta.lore(loreList);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    public void open(Player player) {
        player.openInventory(inventory);
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_CHEST_OPEN, 0.8f, 1.0f);
    }

    public String getRecipeId() {
        return recipeId;
    }

    public Material[] getWorkingGrid() {
        return workingGrid;
    }

    public int getGridIndex(int slot) {
        if (slot == 10) {
            return 0;
        }
        if (slot == 11) {
            return 1;
        }
        if (slot == 12) {
            return 2;
        }
        if (slot == 19) {
            return 3;
        }
        if (slot == 20) {
            return 4;
        }
        if (slot == 21) {
            return 5;
        }
        if (slot == 28) {
            return 6;
        }
        if (slot == 29) {
            return 7;
        }
        if (slot == 30) {
            return 8;
        }
        return -1;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}