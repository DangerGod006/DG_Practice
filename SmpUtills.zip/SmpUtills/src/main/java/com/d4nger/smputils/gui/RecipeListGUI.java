package com.d4nger.smputils.gui;

import com.d4nger.smputils.SMPUtils;
import com.d4nger.smputils.managers.RecipeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class RecipeListGUI implements InventoryHolder {

    private final SMPUtils plugin;
    private final Inventory inventory;

    public RecipeListGUI(SMPUtils plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 45,
                MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500>ᴄᴜꜱᴛᴏᴍ ʀᴇᴄɪᴘᴇꜱ</gradient>"));
        setupItems();
    }

    private void setupItems() {
        ItemStack black = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 45; i++) inventory.setItem(i, black);

        // Cyan border
        ItemStack cyan = createItem(Material.CYAN_STAINED_GLASS_PANE, " ");
        for (int i = 0; i <= 8; i++) inventory.setItem(i, cyan);
        for (int i = 36; i <= 44; i++) inventory.setItem(i, cyan);

        // Header
        ItemStack header = createItem(Material.BOOK,
                "<gradient:#FFD700:#FFA500>ᴄᴜꜱᴛᴏᴍ ʀᴇᴄɪᴘᴇꜱ</gradient>",
                "<gray>ᴛʜᴇꜱᴇ ᴀʀᴇ ᴄᴜꜱᴛᴏᴍ ʀᴇᴄɪᴘᴇꜱ ᴏɴ ᴛʜᴇ ꜱᴇʀᴠᴇʀ</gray>");
        inventory.setItem(4, header);

        // ==================== MIDDLE ROW (Recipes) ====================
        Map<String, RecipeManager.RecipeData> recipes = plugin.getRecipeManager().getRecipes();

        // Middle row slots (better centered)
        int[] slots = {19, 20, 21, 22, 23, 24, 25};   // 7 recipes

        int index = 0;
        for (Map.Entry<String, RecipeManager.RecipeData> entry : recipes.entrySet()) {
            if (index >= slots.length) break;

            RecipeManager.RecipeData data = entry.getValue();
            boolean enabled = plugin.getRecipeManager().isEnabled(entry.getKey());

            ItemStack item;
            if (enabled) {
                item = createItem(data.resultMaterial(), data.displayName(),
                        "<gray>ᴄʟɪᴄᴋ ᴛᴏ ᴘʀᴇᴠɪᴇᴡ ʀᴇᴄɪᴘᴇ</gray>");
            } else {
                item = createItem(Material.GRAY_STAINED_GLASS_PANE,
                        "<dark_gray>🔒 " + stripTags(data.displayName()) + "</dark_gray>",
                        "<red>✘ ᴅɪꜱᴀʙʟᴇᴅ</red>");
            }
            inventory.setItem(slots[index], item);
            index++;
        }

        // ==================== BOTTOM ROW ====================
        // Close button at bottom center
        ItemStack close = createItem(Material.REDSTONE, "<red>✗ ᴄʟᴏꜱᴇ</red>");
        inventory.setItem(40, close);
    }

    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            // Disable italic
            meta.displayName(MiniMessage.miniMessage().deserialize("<!italic>" + name));
            if (lore.length > 0) {
                List<net.kyori.adventure.text.Component> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(MiniMessage.miniMessage().deserialize("<!italic>" + line));
                }
                meta.lore(loreList);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private String stripTags(String text) {
        return text.replaceAll("<[^>]+>", "");
    }

    public void open(Player player) {
        player.openInventory(inventory);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.8f, 1.0f);
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}