package com.d4nger.smputils.managers;

import com.d4nger.smputils.SMPUtils;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class LocationManager {

    private final SMPUtils plugin;
    private final Map<String, Location> locations = new HashMap<>();

    public LocationManager(SMPUtils plugin) {
        this.plugin = plugin;
        loadLocations();
    }

    public void loadLocations() {
        locations.clear();
        FileConfiguration config = plugin.getDataConfig();
        if (config.contains("special_locations")) {
            for (String key : config.getConfigurationSection("special_locations").getKeys(false)) {
                Location loc = (Location) config.get("special_locations." + key);
                if (loc != null) {
                    locations.put(key, loc);
                }
            }
        }
    }

    public void saveLocations() {
        FileConfiguration config = plugin.getDataConfig();
        config.set("special_locations", null);
        for (Map.Entry<String, Location> entry : locations.entrySet()) {
            config.set("special_locations." + entry.getKey(), entry.getValue());
        }
        try {
            config.save(plugin.getDataFile());
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save locations: " + e.getMessage());
        }
    }

    public void setLocation(String name, Location location) {
        locations.put(name, location);
        saveLocations();
    }

    public Location getLocation(String name) {
        return locations.get(name);
    }

    public boolean hasLocation(String name) {
        return locations.containsKey(name);
    }

    public void removeLocation(String name) {
        locations.remove(name);
        saveLocations();
    }

    public Map<String, Location> getAllLocations() {
        return new HashMap<>(locations);
    }
}
