package com.d4nger.smputils.commands;

import com.d4nger.smputils.SMPUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TournamentCommand implements TabExecutor {

    private final SMPUtils plugin;
    private final Random random = new Random();
    private io.papermc.paper.threadedregions.scheduler.ScheduledTask countdownTask;
    private int remainingTime = 30;
    private boolean isPaused = false;

    public TournamentCommand(SMPUtils plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {

        if (!sender.hasPermission("recipes.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "announce" -> sendAnnouncement();
            case "setpos" -> handleSetPos(sender, args);
            case "removepos" -> handleRemovePos(sender, args);
            case "start" -> startCountdown(sender);
            case "stop" -> stopCountdown(sender);
            case "pause" -> pauseCountdown(sender);
            case "resume" -> resumeCountdown(sender);
            case "spawn" -> handleSpawnCommands(sender, args);
            default -> sendUsage(sender);
        }

        return true;
    }

    private void handleSpawnCommands(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage: /tm spawn set <name> | /tm spawn unset <name> | /tm spawn tp <name>"));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "set" -> handleSetSpawn(sender, args);
            case "unset" -> handleUnsetSpawn(sender, args);
            case "tp" -> handleTpSpawn(sender, args);
            default -> sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage: /tm spawn set <name> | /tm spawn unset <name> | /tm spawn tp <name>"));
        }
    }

    private void handleSetSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage: /tm spawn set <name>"));
            return;
        }
        String name = args[2].toLowerCase();
        plugin.getServer().getGlobalRegionScheduler().run(plugin, (task) -> {
            plugin.getLocationManager().setLocation(name, player.getLocation());
            // If setting respawn, set immediate respawn
            if (name.equals("respawn")) {
                for (org.bukkit.World world : Bukkit.getWorlds()) {
                    world.setGameRule(org.bukkit.GameRule.DO_IMMEDIATE_RESPAWN, true);
                }
            }
            player.sendMessage(MiniMessage.miniMessage().deserialize("<green>✓ Location '" + name + "' set!"));
        });
    }

    private void handleUnsetSpawn(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage: /tm spawn unset <name>"));
            return;
        }
        String name = args[2].toLowerCase();
        plugin.getServer().getGlobalRegionScheduler().run(plugin, (task) -> {
            plugin.getLocationManager().removeLocation(name);
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✓ Location '" + name + "' removed!"));
        });
    }

    private void handleTpSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage: /tm spawn tp <name>"));
            return;
        }
        String name = args[2].toLowerCase();
        Location loc = plugin.getLocationManager().getLocation(name);
        if (loc == null) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Location '" + name + "' not found!</red>"));
            return;
        }
        plugin.getWorldGuardManager().teleportPlayerBypassingRestrictions(player, loc);
        player.sendMessage(MiniMessage.miniMessage().deserialize("<green>✓ Teleported to '" + name + "'!</green>"));
    }

    private void handleSetPos(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /tm setpos <number>");
            return;
        }
        try {
            int posNum = Integer.parseInt(args[1]);
            plugin.getServer().getGlobalRegionScheduler().run(plugin, (task) -> {
                plugin.setSavedPosition(posNum, player.getLocation());
                player.sendMessage(MiniMessage.miniMessage().deserialize("<green>✓ Position " + posNum + " saved!"));
            });
        } catch (NumberFormatException e) {
            sender.sendMessage("§cInvalid number!");
        }
    }

    private void handleRemovePos(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /tm removepos <number>");
            return;
        }
        try {
            int posNum = Integer.parseInt(args[1]);
            plugin.getServer().getGlobalRegionScheduler().run(plugin, (task) -> {
                plugin.removeSavedPosition(posNum);
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✓ Position " + posNum + " removed!"));
            });
        } catch (NumberFormatException e) {
            sender.sendMessage("§cInvalid number!");
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Usage:"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm announce"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm setpos <number>"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm removepos <number>"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm start"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm stop"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm pause"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm resume"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm spawn set <name>"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm spawn unset <name>"));
        sender.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>  /tm spawn tp <name>"));
    }

    private void sendAnnouncement() {
        // First, send the main title
        Title title = Title.title(
                MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500><bold>ᴄᴜꜱᴛᴏᴍ ʀᴇᴄɪᴘᴇꜱ!</bold>"),
                MiniMessage.miniMessage().deserialize("<gray>ᴜꜱᴇ /ʀᴇᴄɪᴘᴇ ꜰᴏʀ ᴅᴇᴛᴀɪʟꜱ!</gray>"),
                Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(3000), Duration.ofMillis(500))
        );

        // Broadcast each recipe
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(title);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.0f);
            for (var recipe : plugin.getRecipeManager().getRecipes().values()) {
                if (!plugin.getRecipeManager().isEnabled(recipe.id())) continue;
                p.sendMessage(MiniMessage.miniMessage().deserialize(" "));
                p.sendMessage(MiniMessage.miniMessage().deserialize(
                        "<gradient:#FFD700:#FFA500>★ " + recipe.displayName() + " <gradient:#FFD700:#FFA500>★"
                ));
                for (var info : recipe.extraInfo()) {
                    p.sendMessage(MiniMessage.miniMessage().deserialize(info));
                }
            }
        }

        Bukkit.broadcast(MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500><bold>ᴄʜᴇᴄᴋ /ʀᴇᴄɪᴘᴇ ꜰᴏʀ ᴀʟʟ ᴄᴜꜱᴛᴏᴍ ʀᴇᴄɪᴘᴇꜱ!</bold>"));
    }

    private void startCountdown(CommandSender sender) {
        var positions = plugin.getSavedPositions();
        if (positions.isEmpty()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ No positions saved! Use /tm setpos <number> first!</red>"));
            return;
        }

        // Check at least one non-op player
        boolean hasNonOp = false;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!p.isOp()) {
                hasNonOp = true;
                break;
            }
        }
        if (!hasNonOp) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ At least 1 non-op player online!</red>"));
            return;
        }

        if (countdownTask != null && !countdownTask.isCancelled()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown already running!</red>"));
            return;
        }

        isPaused = false;
        remainingTime = 30;
        var posList = new ArrayList<>(positions.values());

        countdownTask = plugin.getServer().getGlobalRegionScheduler().runAtFixedRate(plugin, task -> {
            if (isPaused) return;
            if (remainingTime <= 0) {
                task.cancel();
                countdownTask = null;
                teleportPlayers(posList);
                return;
            }
            Component actionBarMsg = MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500>ᴛᴏᴜʀɴᴀᴍᴇɴᴛ ꜱᴛᴀʀᴛꜱ ɪɴ " + remainingTime + " ꜱᴇᴄᴏɴᴅꜱ!</gradient>");
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.sendActionBar(actionBarMsg);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.0f);
            }
            if (remainingTime <= 10) {
                Title title = Title.title(
                        MiniMessage.miniMessage().deserialize("<gradient:#FF4444:#AA0000>" + remainingTime + "</gradient>"),
                        MiniMessage.miniMessage().deserialize("<gray>ɢᴇᴛ ʀᴇᴀᴅʏ!</gray>"),
                        Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(800), Duration.ofMillis(100))
                );
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.showTitle(title);
                }
            }
            remainingTime--;
        }, 1, 20);
    }

    private void stopCountdown(CommandSender sender) {
        if (countdownTask == null || countdownTask.isCancelled()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown not running!</red>"));
            return;
        }
        countdownTask.cancel();
        countdownTask = null;
        isPaused = false;
        remainingTime = 30;
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendActionBar(Component.text(""));
        }
        Bukkit.broadcast(MiniMessage.miniMessage().deserialize("<yellow>⚠ Tournament countdown stopped!</yellow>"));
    }

    private void pauseCountdown(CommandSender sender) {
        if (countdownTask == null || countdownTask.isCancelled()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown not running!</red>"));
            return;
        }
        if (isPaused) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown already paused!</red>"));
            return;
        }
        isPaused = true;
        Bukkit.broadcast(MiniMessage.miniMessage().deserialize("<yellow>⚠ Tournament countdown paused!</yellow>"));
    }

    private void resumeCountdown(CommandSender sender) {
        if (countdownTask == null || countdownTask.isCancelled()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown not running!</red>"));
            return;
        }
        if (!isPaused) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Countdown not paused!</red>"));
            return;
        }
        isPaused = false;
        Bukkit.broadcast(MiniMessage.miniMessage().deserialize("<green>✓ Tournament countdown resumed!</green>"));
    }

    private void teleportPlayers(List<Location> posList) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isOp()) continue;
            if (posList.isEmpty()) {
                p.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ No positions to teleport to!</red>"));
                continue;
            }
            Location randomLoc = posList.get(random.nextInt(posList.size()));
            if (randomLoc == null) {
                p.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Invalid position!</red>"));
                continue;
            }
            if (randomLoc.getWorld() == null) {
                p.sendMessage(MiniMessage.miniMessage().deserialize("<red>✗ Position world is null!</red>"));
                continue;
            }
            plugin.getWorldGuardManager().teleportPlayerBypassingRestrictions(p, randomLoc);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }

        // Announce after teleport
        plugin.getServer().getGlobalRegionScheduler().runDelayed(plugin, task -> {
            Title title = Title.title(
                    MiniMessage.miniMessage().deserialize("<gradient:#FFD700:#FFA500><bold>ᴛᴏᴜʀɴᴀᴍᴇɴᴛ ꜱᴛᴀʀᴛ!</bold>"),
                    MiniMessage.miniMessage().deserialize("<gradient:#58FF00:#29FF06><bold>ɢᴇᴛ ᴛʜᴇ ᴅʀᴀɢᴏɴ ᴇɢɢ ᴛᴏ ᴡɪɴ!</bold>"),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofMillis(3000), Duration.ofMillis(500))
            );
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(title);
                p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
            }
            String chatMsg = "<gradient:#FFD700:#FFA500>★ <gradient:#FFD700:#FFA500><bold>ᴛᴏᴜʀɴᴀᴍᴇɴᴛ ʜᴀꜱ ꜱᴛᴀʀᴛᴇᴅ!</bold> <gradient:#FFD700:#FFA500>★\n<gradient:#58FF00:#29FF06><bold>ɢᴇᴛ ᴛʜᴇ ᴅʀᴀɢᴏɴ ᴇɢɢ ᴛᴏ ᴡɪɴ!</bold>";
            Bukkit.broadcast(MiniMessage.miniMessage().deserialize(chatMsg));
        }, 15);
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return filterSuggestions(args[0], List.of("announce", "setpos", "removepos", "start", "stop", "pause", "resume", "spawn"));
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("setpos") || args[0].equalsIgnoreCase("removepos"))) {
            List<String> suggestions = new ArrayList<>();
            for (Integer num : plugin.getSavedPositions().keySet()) {
                suggestions.add(num.toString());
            }
            if (args[0].equalsIgnoreCase("setpos")) {
                for (int i = 1; i <= 10; i++) {
                    String s = String.valueOf(i);
                    if (!suggestions.contains(s)) {
                        suggestions.add(s);
                    }
                }
            }
            return filterSuggestions(args[1], suggestions);
        }
        if (args[0].equalsIgnoreCase("spawn")) {
            if (args.length == 2) {
                return filterSuggestions(args[1], List.of("set", "unset", "tp"));
            }
            if (args.length == 3 && (args[1].equalsIgnoreCase("unset") || args[1].equalsIgnoreCase("tp"))) {
                return filterSuggestions(args[2], new ArrayList<>(plugin.getLocationManager().getAllLocations().keySet()));
            }
            if (args.length == 3 && args[1].equalsIgnoreCase("set")) {
                return filterSuggestions(args[2], List.of("respawn", "firstjoin", "rejoin"));
            }
        }
        return List.of();
    }

    private List<String> filterSuggestions(String input, List<String> options) {
        String lowerInput = input.toLowerCase();
        List<String> filtered = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase().startsWith(lowerInput)) {
                filtered.add(option);
            }
        }
        return filtered;
    }
}
