package com.d4nger.smputils.managers;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class WorldGuardManager {

    private final Plugin plugin;
    private final boolean worldGuardEnabled;

    public WorldGuardManager(Plugin plugin) {
        this.plugin = plugin;
        this.worldGuardEnabled = plugin.getServer().getPluginManager().getPlugin("WorldGuard") != null;
    }

    public void teleportPlayerBypassingRestrictions(Player player, Location location) {
        player.setInvulnerable(true);
        player.teleportAsync(location).thenAccept(success -> {
            if (success) {
                // Keep invulnerable for a short time just in case
                plugin.getServer().getGlobalRegionScheduler().runDelayed(plugin, task -> {
                    player.setInvulnerable(false);
                }, 20);
            } else {
                player.setInvulnerable(false);
            }
        });
    }
}
