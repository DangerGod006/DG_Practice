package com.d4nger.smputils.managers;

import com.d4nger.smputils.SMPUtils;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class RecipeManager {

    private final SMPUtils plugin;
    private final List<NamespacedKey> registeredKeys = new ArrayList<>();
    private final Map<String, RecipeData> recipes = new LinkedHashMap<>();

    private File recipesFile;
    private FileConfiguration recipesConfig;

    public RecipeManager(SMPUtils plugin) {
        this.plugin = plugin;
        loadRecipesFile();
    }

    private void loadRecipesFile() {
        recipesFile = new File(plugin.getDataFolder(), "recipes.yml");
        if (!recipesFile.exists()) {
            plugin.saveResource("recipes.yml", false);
        }
        recipesConfig = YamlConfiguration.loadConfiguration(recipesFile);
    }

    public void reloadRecipesFile() {
        loadRecipesFile();
    }

    public FileConfiguration getRecipesConfig() {
        return recipesConfig;
    }

    public void saveRecipesConfig() {
        try {
            recipesConfig.save(recipesFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save recipes.yml: " + e.getMessage());
        }
    }

    public void registerAllRecipes() {
        recipes.clear();
        registerEnderPearlRecipe();
        registerTridentRecipe();
        registerCobwebRecipe();
        registerShulkerBoxRecipe();
        registerCookedPorkchopRecipe();
        registerBlazeRodRecipe();
        registerGhastTearRecipe();
    }

    public void unregisterAllRecipes() {
        for (NamespacedKey key : registeredKeys) {
            plugin.getServer().removeRecipe(key);
        }
        registeredKeys.clear();
        recipes.clear();
    }

    // ==================== RECIPES ====================

    private void registerEnderPearlRecipe() {
        Material[] defaults = {
                Material.OBSIDIAN, Material.DIAMOND,   Material.OBSIDIAN,
                Material.DIAMOND,  Material.DIAMOND,   Material.DIAMOND,
                Material.OBSIDIAN, Material.DIAMOND,   Material.OBSIDIAN
        };
        Material[] grid = loadGrid("ender_pearl", defaults);
        int resultAmount = recipesConfig.getInt("recipes.ender_pearl.result-amount", 2);

        if (isEnabled("ender_pearl")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_ender_pearl");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.ENDER_PEARL, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("ender_pearl", new RecipeData(
                "ender_pearl", Material.ENDER_PEARL,
                "<gradient:#AA00FF:#6600CC>ᴇɴᴅᴇʀ ᴘᴇᴀʀʟ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>4 ᴏʙꜱɪᴅɪᴀɴ + 8 ᴅɪᴀᴍᴏɴᴅꜱ</gray>")));
    }

    private void registerTridentRecipe() {
        Material[] defaults = {
                null, Material.IRON_INGOT, Material.IRON_INGOT,
                null, Material.DIAMOND, Material.IRON_INGOT,
                null, Material.DIAMOND, null
        };
        Material[] grid = loadGrid("trident", defaults);
        int resultAmount = recipesConfig.getInt("recipes.trident.result-amount", 1);

        if (isEnabled("trident")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_trident");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.TRIDENT, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("trident", new RecipeData(
                "trident", Material.TRIDENT,
                "<gradient:#00BFFF:#1E90FF>ᴛʀɪᴅᴇɴᴛ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>3 ɪʀᴏɴ ɪɴɢᴏᴛꜱ + 2 ᴅɪᴀᴍᴏɴᴅꜱ</gray>")));
    }

    private void registerCobwebRecipe() {
        Material[] defaults = {
                Material.STRING, Material.STRING, null,
                null, Material.STRING, null,
                Material.STRING, Material.STRING, null
        };
        Material[] grid = loadGrid("cobweb", defaults);
        int resultAmount = recipesConfig.getInt("recipes.cobweb.result-amount", 1);

        if (isEnabled("cobweb")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_cobweb");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.COBWEB, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("cobweb", new RecipeData(
                "cobweb", Material.COBWEB,
                "<gradient:#CCCCCC:#FFFFFF>ᴄᴏʙᴡᴇʙ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>5 ꜱᴛʀɪɴɢ ɪɴ ᴄᴏʙᴡᴇʙ ᴘᴀᴛᴛᴇʀɴ</gray>")));
    }

    private void registerShulkerBoxRecipe() {
        Material[] defaults = {
                Material.DIAMOND, Material.DIAMOND, Material.DIAMOND,
                Material.DIAMOND, Material.CHEST, Material.DIAMOND,
                Material.DIAMOND, Material.DIAMOND, Material.DIAMOND
        };
        Material[] grid = loadGrid("shulker_box", defaults);
        int resultAmount = recipesConfig.getInt("recipes.shulker_box.result-amount", 1);

        if (isEnabled("shulker_box")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_shulker_box");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.SHULKER_BOX, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("shulker_box", new RecipeData(
                "shulker_box", Material.SHULKER_BOX,
                "<gradient:#DA70D6:#9B59B6>ꜱʜᴜʟᴋᴇʀ ʙᴏx</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>8 ᴅɪᴀᴍᴏɴᴅꜱ + 1 ᴄʜᴇꜱᴛ</gray>")));
    }

    private void registerCookedPorkchopRecipe() {
        Material[] defaults = {
                null, null, null,
                null, Material.OAK_LOG, null,
                null, null, null
        };
        Material[] grid = loadGrid("cooked_porkchop", defaults);
        int resultAmount = recipesConfig.getInt("recipes.cooked_porkchop.result-amount", 4);

        if (isEnabled("cooked_porkchop")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_cooked_porkchop");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.COOKED_PORKCHOP, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("cooked_porkchop", new RecipeData(
                "cooked_porkchop", Material.COOKED_PORKCHOP,
                "<gradient:#FFAA00:#FF5500>ᴄᴏᴏᴋᴇᴅ ᴘᴏʀᴋᴄʜᴏᴘ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>1 ᴏᴀᴋ ʟᴏɢ → 4 ᴄᴏᴏᴋᴇᴅ ᴘᴏʀᴋᴄʜᴏᴘ</gray>")));
    }

    private void registerBlazeRodRecipe() {
        Material[] defaults = {
                Material.GOLD_BLOCK, Material.IRON_BLOCK, Material.GOLD_BLOCK,
                Material.IRON_BLOCK, Material.GHAST_TEAR, Material.IRON_BLOCK,
                Material.GOLD_BLOCK, Material.IRON_BLOCK, Material.GOLD_BLOCK
        };
        Material[] grid = loadGrid("blaze_rod", defaults);
        int resultAmount = recipesConfig.getInt("recipes.blaze_rod.result-amount", 4);

        if (isEnabled("blaze_rod")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_blaze_rod");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.BLAZE_ROD, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("blaze_rod", new RecipeData(
                "blaze_rod", Material.BLAZE_ROD,
                "<gradient:#FF6600:#AA3300>ʙʟᴀᴢᴇ ʀᴏᴅ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>4 ɢᴏʟᴅ ʙʟᴏᴄᴋꜱ + 4 ɪʀᴏɴ ʙʟᴏᴄᴋꜱ + 1 ɢʜᴀꜱᴛ ᴛᴇᴀʀ</gray>")));
    }

    private void registerGhastTearRecipe() {
        Material[] defaults = {
                Material.BLAZE_ROD, Material.GOLD_BLOCK, Material.BLAZE_ROD,
                Material.GOLD_BLOCK, Material.DIAMOND, Material.GOLD_BLOCK,
                Material.BLAZE_ROD, Material.GOLD_BLOCK, Material.BLAZE_ROD
        };
        Material[] grid = loadGrid("ghast_tear", defaults);
        int resultAmount = recipesConfig.getInt("recipes.ghast_tear.result-amount", 2);

        if (isEnabled("ghast_tear")) {
            NamespacedKey key = new NamespacedKey(plugin, "custom_ghast_tear");
            plugin.getServer().addRecipe(buildShapedRecipe(key, Material.GHAST_TEAR, resultAmount, grid));
            registeredKeys.add(key);
        }
        recipes.put("ghast_tear", new RecipeData(
                "ghast_tear", Material.GHAST_TEAR,
                "<gradient:#AA00FF:#6600CC>ɢʜᴀꜱᴛ ᴛᴇᴀʀ</gradient>",
                grid, buildAmounts(grid), resultAmount,
                List.of("<gray>4 ʙʟᴀᴢᴇ ʀᴏᴅꜱ + 4 ɢᴏʟᴅ ʙʟᴏᴄᴋꜱ + 1 ᴅɪᴀᴍᴏɴᴅ</gray>")));
    }

    // ==================== IMPORTANT METHOD ====================

    public boolean isEnabled(String recipeId) {
        String path = "recipes." + recipeId + ".enabled";
        if (!recipesConfig.contains(path)) {
            recipesConfig.set(path, true);
            saveRecipesConfig();
        }
        return recipesConfig.getBoolean(path, true);
    }

    public void setEnabled(String recipeId, boolean enabled) {
        recipesConfig.set("recipes." + recipeId + ".enabled", enabled);
        saveRecipesConfig();
    }

    public Material[] loadGrid(String recipeId, Material[] defaults) {
        String base = "recipes." + recipeId + ".grid";
        if (!recipesConfig.contains(base)) {
            return defaults;
        }

        Material[] grid = new Material[9];
        for (int i = 0; i < 9; i++) {
            String name = recipesConfig.getString(base + "." + i, "AIR");
            try {
                Material m = Material.valueOf(name);
                grid[i] = (m == Material.AIR) ? null : m;
            } catch (Exception e) {
                grid[i] = defaults[i];
            }
        }
        return grid;
    }

    public void saveGridToConfig(String recipeId, Material[] grid) {
        String base = "recipes." + recipeId + ".grid";
        for (int i = 0; i < 9; i++) {
            recipesConfig.set(base + "." + i, grid[i] != null ? grid[i].name() : "AIR");
        }
        saveRecipesConfig();
    }

    private ShapedRecipe buildShapedRecipe(NamespacedKey key, Material result, int amount, Material[] grid) {
        ShapedRecipe recipe = new ShapedRecipe(key, new ItemStack(result, amount));
        char[] chars = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'};
        Map<Material, Character> matToChar = new LinkedHashMap<>();
        int idx = 0;

        for (Material m : grid) {
            if (m != null && !matToChar.containsKey(m)) {
                matToChar.put(m, chars[idx++]);
            }
        }

        StringBuilder[] rows = new StringBuilder[3];
        for (int r = 0; r < 3; r++) {
            rows[r] = new StringBuilder();
            for (int c = 0; c < 3; c++) {
                Material m = grid[r * 3 + c];
                rows[r].append(m != null ? matToChar.get(m) : ' ');
            }
        }

        recipe.shape(rows[0].toString(), rows[1].toString(), rows[2].toString());
        for (Map.Entry<Material, Character> e : matToChar.entrySet()) {
            recipe.setIngredient(e.getValue(), e.getKey());
        }
        return recipe;
    }

    private int[] buildAmounts(Material[] grid) {
        int[] amounts = new int[9];
        for (int i = 0; i < 9; i++) {
            amounts[i] = grid[i] != null ? 1 : 0;
        }
        return amounts;
    }

    public Map<String, RecipeData> getRecipes() {
        return Collections.unmodifiableMap(recipes);
    }

    public RecipeData getRecipe(String id) {
        return recipes.get(id);
    }

    public record RecipeData(
            String id,
            Material resultMaterial,
            String displayName,
            Material[] grid,
            int[] amounts,
            int resultAmount,
            List<String> extraInfo
    ) {}
}