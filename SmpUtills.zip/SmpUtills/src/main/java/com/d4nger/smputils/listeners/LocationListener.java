package com.d4nger.smputils.listeners;

import com.d4nger.smputils.SMPUtils;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class LocationListener implements Listener {

    private final SMPUtils plugin;

    public LocationListener(SMPUtils plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Check if first join
        if (!player.hasPlayedBefore()) {
            Location firstJoinLoc = plugin.getLocationManager().getLocation("firstjoin");
            if (firstJoinLoc != null) {
                player.getScheduler().runDelayed(plugin, (task) -> {
                    plugin.getWorldGuardManager().teleportPlayerBypassingRestrictions(player, firstJoinLoc);
                }, null, 10); // 10 tick delay
            }
        } else {
            // Check rejoin location
            Location rejoinLoc = plugin.getLocationManager().getLocation("rejoin");
            if (rejoinLoc != null) {
                player.getScheduler().runDelayed(plugin, (task) -> {
                    plugin.getWorldGuardManager().teleportPlayerBypassingRestrictions(player, rejoinLoc);
                }, null, 10); // 10 tick delay
            }
        }
    }

    @EventHandler(priority = org.bukkit.event.EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Location respawnLoc = plugin.getLocationManager().getLocation("respawn");
        if (respawnLoc != null) {
            event.setRespawnLocation(respawnLoc);
            Player player = event.getPlayer();
            player.getScheduler().runDelayed(plugin, (task) -> {
                plugin.getWorldGuardManager().teleportPlayerBypassingRestrictions(player, respawnLoc);
            }, null, 5); // 5 tick delay after respawn
        }
    }
}
