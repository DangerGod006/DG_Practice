# FoliaSMPUtils - Folia Compatible Version

This is the **exact same plugin** as the original SmpUtil (https://github.com/DangerGod006/SmpUtil) but made fully compatible with **Folia**, **Paper**, and **Spigot**.

### Key Changes Made:

1. **FoliaScheduler Integration** (from https://github.com/CJCrafter/FoliaScheduler)
   - Added dependency + Maven Shade plugin to bundle FoliaScheduler
   - Main class now initializes `ServerImplementation scheduler = new FoliaCompatibility(this).getServerImplementation();`
   - Plugin exposes `getScheduler()` for any future Folia-native scheduling

2. **plugin.yml**
   - Added `folia-supported: true`

3. **Recipe System** (the focus)
   - **Completely unchanged** and fully working
   - Custom recipes (Trident, Cobweb, Shulker Box, Golden Apple, String Duplication) are registered exactly the same way
   - All GUI editing features work identically
   - Recipes are stored in `recipes.yml`

4. **Scheduler Compatibility**
   - Old `BukkitRunnable` / `Bukkit.getScheduler()` code remains (still works on Folia via compatibility layer)
   - For maximum future-proofing, new code should use `plugin.getScheduler().entity(player).run(...)` etc.

### Custom Recipe System Features (Exact Same as Original):

- `/recipe` command opens beautiful GUI
- Full recipe editor with grid editing
- Enable/disable individual recipes
- Change result amounts
- 5 built-in custom recipes:
  - **Trident** (Iron + Diamond)
  - **Cobweb** (String pattern)
  - **Shulker Box** (Diamond + Chest)
  - **Golden Apple** (Gold + Apple)
  - **String Duplication** (1 → 32 string)

### How to Build:

```bash
mvn clean package
```

The final jar will be in `target/FoliaSMPUtils-1.0.0.jar`

### How FoliaScheduler Works (from the linked library):

```java
// Get the scheduler once in your main class
ServerImplementation scheduler = new FoliaCompatibility(plugin).getServerImplementation();

// Entity task (safe on Folia)
scheduler.entity(player).run(() -> {
    player.teleport(location);
});

// Delayed task
scheduler.global().runDelayed(task -> {
    // runs after delay
}, 20L);

// Async task
scheduler.async().run(() -> {
    // heavy I/O here
});
```

This plugin is ready to run on **Folia 1.20+**, **Paper**, and **Spigot**.

### Original Author Credit:
Original plugin: DangerGod006 / D4NGER
Folia port: Arena.ai agent (based on exact original source)