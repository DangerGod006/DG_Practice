package org.enyo.pearlFix;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PearlFix-1.0.jar:org/enyo/pearlFix/PearlMomentumFix.class */
public class PearlMomentumFix implements Listener {
    private final JavaPlugin plugin;
    private final Map<UUID, Vector> pending = new WeakHashMap();

    public PearlMomentumFix(JavaPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPearlTeleport(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            return;
        }
        Player player = event.getPlayer();
        Vector velToKeep = player.getVelocity().clone();
        this.pending.put(player.getUniqueId(), velToKeep);
        Bukkit.getScheduler().runTask(this.plugin, () -> {
            Vector vel = this.pending.remove(player.getUniqueId());
            if (vel == null || !player.isOnline() || player.isDead()) {
                return;
            }
            player.setVelocity(vel);
        });
    }
}
