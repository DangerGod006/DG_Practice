package org.enyo.pearlFix;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.AbstractWindCharge;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PearlFix-1.0.jar:org/enyo/pearlFix/WindChargePearlCollisionFix.class */
public class WindChargePearlCollisionFix implements Listener {
    private final JavaPlugin plugin;
    private final Set<UUID> handledProjectiles = new HashSet();

    public WindChargePearlCollisionFix(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (!this.plugin.getConfig().getBoolean("windcharge-pearl-collision.enabled", true)) {
            return;
        }
        Projectile entity = event.getEntity();
        if (!(entity instanceof EnderPearl) && !(entity instanceof AbstractWindCharge)) {
            return;
        }
        trackProjectile(entity);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent event) {
        Entity hitEntity;
        if (!this.plugin.getConfig().getBoolean("windcharge-pearl-collision.enabled", true) || (hitEntity = event.getHitEntity()) == null) {
            return;
        }
        collideIfPair(event.getEntity(), hitEntity);
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [org.enyo.pearlFix.WindChargePearlCollisionFix$1] */
    private void trackProjectile(final Entity projectile) {
        final int maxTicks = this.plugin.getConfig().getInt("windcharge-pearl-collision.tracked-ticks", 100);
        final double radius = this.plugin.getConfig().getDouble("windcharge-pearl-collision.radius", 1.25d);
        new BukkitRunnable() { // from class: org.enyo.pearlFix.WindChargePearlCollisionFix.1
            private int ticks;

            public void run() {
                AbstractWindCharge windCharge;
                EnderPearl pearl;
                int i = this.ticks + 1;
                this.ticks = i;
                if (i > maxTicks || !projectile.isValid() || projectile.isDead()) {
                    cancel();
                    return;
                }
                if (projectile instanceof EnderPearl) {
                    EnderPearl pearl2 = projectile;
                    AbstractWindCharge windCharge2 = WindChargePearlCollisionFix.this.findNearbyWindCharge(pearl2, radius);
                    if (windCharge2 != null) {
                        WindChargePearlCollisionFix.this.collide(windCharge2, pearl2);
                        cancel();
                        return;
                    }
                    return;
                }
                if ((projectile instanceof AbstractWindCharge) && (pearl = WindChargePearlCollisionFix.this.findNearbyPearl((windCharge = projectile), radius)) != null) {
                    WindChargePearlCollisionFix.this.collide(windCharge, pearl);
                    cancel();
                }
            }
        }.runTaskTimer(this.plugin, 1L, 1L);
    }

    private AbstractWindCharge findNearbyWindCharge(EnderPearl pearl, double radius) {
        BoundingBox horizontalCollisionBox = getHorizontalCollisionBox(pearl, radius);
        for (Entity nearby : pearl.getWorld().getNearbyEntities(horizontalCollisionBox)) {
            if (nearby instanceof AbstractWindCharge) {
                AbstractWindCharge windCharge = (AbstractWindCharge) nearby;
                if (canCollide(pearl, windCharge) && isHorizontallyColliding(horizontalCollisionBox, windCharge)) {
                    return windCharge;
                }
            }
        }
        return null;
    }

    private EnderPearl findNearbyPearl(AbstractWindCharge windCharge, double radius) {
        BoundingBox horizontalCollisionBox = getHorizontalCollisionBox(windCharge, radius);
        for (Entity nearby : windCharge.getWorld().getNearbyEntities(horizontalCollisionBox)) {
            if (nearby instanceof EnderPearl) {
                EnderPearl pearl = (EnderPearl) nearby;
                if (canCollide(pearl, windCharge) && isHorizontallyColliding(horizontalCollisionBox, pearl)) {
                    return pearl;
                }
            }
        }
        return null;
    }

    private BoundingBox getHorizontalCollisionBox(Entity projectile, double radius) {
        return projectile.getBoundingBox().expand(radius, 0.0d, radius);
    }

    private boolean isHorizontallyColliding(BoundingBox horizontalCollisionBox, Entity other) {
        return horizontalCollisionBox.overlaps(other.getBoundingBox());
    }

    private boolean collideIfPair(Entity first, Entity second) {
        if (first instanceof EnderPearl) {
            EnderPearl pearl = (EnderPearl) first;
            if (second instanceof AbstractWindCharge) {
                AbstractWindCharge windCharge = (AbstractWindCharge) second;
                return collide(windCharge, pearl);
            }
        }
        if (!(first instanceof AbstractWindCharge)) {
            return false;
        }
        AbstractWindCharge windCharge2 = (AbstractWindCharge) first;
        if (second instanceof EnderPearl) {
            EnderPearl pearl2 = (EnderPearl) second;
            return collide(windCharge2, pearl2);
        }
        return false;
    }

    private boolean canCollide(EnderPearl pearl, AbstractWindCharge windCharge) {
        return (!pearl.isValid() || pearl.isDead() || !windCharge.isValid() || windCharge.isDead() || this.handledProjectiles.contains(pearl.getUniqueId()) || this.handledProjectiles.contains(windCharge.getUniqueId())) ? false : true;
    }

    private boolean collide(AbstractWindCharge windCharge, EnderPearl pearl) {
        if (!canCollide(pearl, windCharge)) {
            return false;
        }
        ProjectileSource shooter = pearl.getShooter();
        if (!(shooter instanceof Player)) {
            return false;
        }
        Player player = (Player) shooter;
        this.handledProjectiles.add(windCharge.getUniqueId());
        this.handledProjectiles.add(pearl.getUniqueId());
        Location destination = pearl.getLocation();
        Location playerLocation = player.getLocation();
        destination.setYaw(playerLocation.getYaw());
        destination.setPitch(playerLocation.getPitch());
        redirectWindCharge(windCharge, player);
        player.teleport(destination, PlayerTeleportEvent.TeleportCause.ENDER_PEARL);
        destination.getWorld().playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        pearl.remove();
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            this.handledProjectiles.remove(windCharge.getUniqueId());
            this.handledProjectiles.remove(pearl.getUniqueId());
        }, 20L);
        return true;
    }

    private void redirectWindCharge(AbstractWindCharge windCharge, Player player) {
        Vector direction = player.getEyeLocation().getDirection().normalize();
        double speed = windCharge.getVelocity().length();
        if (speed <= 0.0d) {
            speed = 1.5d;
        }
        windCharge.setShooter(player);
        windCharge.setDirection(direction);
        windCharge.setVelocity(direction.multiply(speed));
    }
}
