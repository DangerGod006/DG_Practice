package org.enyo.pearlFix;

import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: PearlFix-1.0.jar:org/enyo/pearlFix/PearlFix.class */
public final class PearlFix extends JavaPlugin {
    public void onEnable() {
        saveDefaultConfig();
        new PearlMomentumFix(this);
        new AccuracyFix(this);
        new WindChargePearlCollisionFix(this);
    }

    public void onDisable() {
    }
}
