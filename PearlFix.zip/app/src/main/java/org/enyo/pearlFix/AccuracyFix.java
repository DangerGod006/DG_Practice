package org.enyo.pearlFix;

import java.util.Random;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AbstractWindCharge;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

/* JADX INFO: loaded from: PearlFix-1.0.jar:org/enyo/pearlFix/AccuracyFix.class */
public class AccuracyFix implements Listener {
    private final JavaPlugin plugin;
    private final Random random = new Random();
    private boolean disableMultishotAccuracy;
    private boolean disableGlobalAccuracy;

    public AccuracyFix(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectileFire(ProjectileLaunchEvent event) {
        if (this.disableGlobalAccuracy) {
            return;
        }
        Projectile projectile = event.getEntity();
        if (!isAllowedAccuracyProjectile(projectile)) {
            return;
        }
        ProjectileSource source = projectile.getShooter();
        if (!(source instanceof Player)) {
            return;
        }
        Player player = (Player) source;
        boolean isMultishot = isMultishotCrossbow(player.getInventory().getItemInMainHand()) || isMultishotCrossbow(player.getInventory().getItemInOffHand());
        if (isMultishot) {
            if (this.disableMultishotAccuracy) {
                applyDefaultMultishotSpread(projectile);
                return;
            } else {
                adjustMultishotAccuracy(projectile, player);
                return;
            }
        }
        adjustProjectileAccuracy(projectile, player.getEyeLocation().getDirection());
    }

    private boolean isAllowedAccuracyProjectile(Projectile projectile) {
        return (projectile instanceof AbstractWindCharge) || (projectile instanceof EnderPearl) || (projectile instanceof ThrownPotion);
    }

    private boolean isMultishotCrossbow(ItemStack item) {
        return item != null && item.getType() == Material.CROSSBOW && item.getEnchantmentLevel(Enchantment.MULTISHOT) > 0;
    }

    private void adjustMultishotAccuracy(Projectile projectile, Player player) {
        Vector direction = player.getEyeLocation().getDirection().normalize();
        Vector left = rotateVector(direction, -10.0d);
        Vector right = rotateVector(direction, 10.0d);
        double speed = projectile.getVelocity().length();
        int choice = this.random.nextInt(3);
        if (choice == 0) {
            projectile.setVelocity(direction.multiply(speed));
        } else if (this.random.nextInt(2) == 0) {
            projectile.setVelocity(left.multiply(speed));
        } else {
            projectile.setVelocity(right.multiply(speed));
        }
    }

    private void adjustProjectileAccuracy(Projectile projectile, Vector direction) {
        projectile.setVelocity(direction.clone().normalize().multiply(projectile.getVelocity().length()));
    }

    private void applyDefaultMultishotSpread(Projectile projectile) {
        Vector velocity = projectile.getVelocity();
        velocity.add(new Vector((this.random.nextDouble() - 0.5d) * 0.1d, (this.random.nextDouble() - 0.5d) * 0.1d, (this.random.nextDouble() - 0.5d) * 0.1d));
        projectile.setVelocity(velocity);
    }

    private Vector rotateVector(Vector vector, double degrees) {
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double x = (vector.getX() * cos) - (vector.getZ() * sin);
        double z = (vector.getX() * sin) + (vector.getZ() * cos);
        return new Vector(x, vector.getY(), z);
    }
}
