package dev.ninja.mcPVPFlags;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:dev/ninja/mcPVPFlags/A.class */
public final class A extends PlaceholderExpansion {
    private final McPVPFlags A;

    public A(McPVPFlags mcPVPFlags) {
        this.A = mcPVPFlags;
    }

    public String getIdentifier() {
        return "mcpvpflags";
    }

    public String getAuthor() {
        return "Qasim";
    }

    public String getVersion() {
        return this.A.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    public String onPlaceholderRequest(Player player, String str) {
        if (str.equalsIgnoreCase("flag")) {
            return this.A.getCountryFlagService().B(player);
        }
        return null;
    }
}
