package dev.ninja.mcPVPFlags;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.stream.Collectors;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:dev/ninja/mcPVPFlags/C.class */
public class C {
    private static final String B = "http://uae-lemon.royalnode.cloud:25581";
    private static final int A = 4;

    public static boolean B(JavaPlugin javaPlugin) {
        String strC = C(javaPlugin);
        if (B(strC) || D(strC)) {
            javaPlugin.getLogger().severe("\n\nProduct: McPvPFlags | License Verification\n\n" + (B(strC) ? "Missing 'license-key' in country-flags.yml or LICENSE_KEY environment variable." : "The license key is a placeholder value."));
            return false;
        }
        String strA = A(System.getProperty("lemon.licensing.base", System.getenv().getOrDefault("LEMON_LICENSE_API_URL", javaPlugin.getConfig().getString("licensing.api-url", B))));
        String version = javaPlugin.getPluginMeta().getVersion();
        try {
            String strC2 = C(strA);
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strC2).openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setDoOutput(true);
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("licenseKey", strC.trim());
            jsonObject.addProperty("productId", Integer.valueOf(A));
            jsonObject.addProperty("hwid", A());
            jsonObject.addProperty("productVersion", version);
            jsonObject.addProperty("ip", A(javaPlugin));
            jsonObject.addProperty("javaVersion", System.getProperty("java.version"));
            jsonObject.addProperty("operatingSystem", System.getProperty("os.name"));
            jsonObject.addProperty("operatingSystemVersion", System.getProperty("os.version"));
            jsonObject.addProperty("operatingSystemArchitecture", System.getProperty("os.arch"));
            String json = new Gson().toJson((JsonElement) jsonObject);
            javaPlugin.getLogger().info("License validation request -> url=" + strC2 + ", productId=4, key=" + E(strC));
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
                outputStream.write(bytes, 0, bytes.length);
                if (outputStream != null) {
                    outputStream.close();
                }
                int responseCode = httpURLConnection.getResponseCode();
                String str = (String) new BufferedReader(new InputStreamReader((responseCode < 200 || responseCode >= 300) ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream(), StandardCharsets.UTF_8)).lines().collect(Collectors.joining());
                JsonObject jsonObject2 = (JsonObject) new Gson().fromJson(str, JsonObject.class);
                if (responseCode >= 200 && responseCode < 300 && jsonObject2 != null && ((jsonObject2.has("status") && jsonObject2.get("status").getAsInt() == 200) || (jsonObject2.has("message") && jsonObject2.get("message").getAsString().toLowerCase().contains("validated")))) {
                    javaPlugin.getLogger().info("\n █████╗ ██╗   ██╗████████╗██╗  ██╗  ██████╗ ██╗   ██╗ █████╗ ██████╗ ██████╗ \n██╔══██╗██║   ██║╚══██╔══╝██║  ██║ ██╔════╝ ██║   ██║██╔══██╗██╔══██╗██╔══██╗\n███████║██║   ██║   ██║   ███████║ ██║  ███╗██║   ██║███████║██████╔╝██║  ██║\n██╔══██║██║   ██║   ██║   ██╔══██║ ██║   ██║██║   ██║██╔══██║██╔══██╗██║  ██║\n██║  ██║╚██████╔╝   ██║   ██║  ██║ ╚██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝\n╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ \n\n\nProduct: McPvPFlags | License Verification\n\n✅ License validated successfully!\n" + "\n");
                    return true;
                }
                javaPlugin.getLogger().severe("\n\nProduct: McPvPFlags | License Verification\n\nLicense validation failed: " + ((jsonObject2 == null || !jsonObject2.has("message")) ? str : jsonObject2.get("message").getAsString()));
                return false;
            } finally {
            }
        } catch (IOException e) {
            javaPlugin.getLogger().log(Level.SEVERE, "\n\nProduct: McPvPFlags | License Verification\n\nLicense validation failed with the license API.", (Throwable) e);
            return false;
        }
    }

    private static boolean D(String str) {
        if (B(str)) {
            return true;
        }
        String lowerCase = str.trim().toLowerCase();
        return "change_me".equals(lowerCase) || "your-license-key".equals(lowerCase) || "your_license_key".equals(lowerCase) || "Unable to acquire a license key automatically, please contact the creator directly.".equals(lowerCase) || lowerCase.contains("%%__license__") || lowerCase.contains("your license key") || lowerCase.contains("your-license") || lowerCase.contains("insert-license-key");
    }

    private static String C(JavaPlugin javaPlugin) {
        String str = System.getenv("LICENSE_KEY");
        return !B(str) ? str : YamlConfiguration.loadConfiguration(new File(javaPlugin.getDataFolder(), "country-flags.yml")).getString("license-key", "");
    }

    private static boolean B(String str) {
        return str == null || str.trim().isEmpty();
    }

    private static String C(String str) {
        return str.replaceAll("/+$", "").replaceAll("(?i)/api/v1/licenses/validate$", "").replaceAll("(?i)/api/v1/licenses$", "").replaceAll("(?i)/api/v1/validate$", "").replaceAll("(?i)/api/v1$", "").replaceAll("(?i)/api/license$", "").replaceAll("(?i)/api$", "").replaceAll("(?i)/validate$", "") + "/api/v1/validate";
    }

    private static String A() {
        String hostName = "unknown";
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
        }
        return Integer.toHexString((System.getProperty("os.name") + System.getProperty("os.arch") + System.getProperty("java.version") + hostName).hashCode()).toUpperCase();
    }

    private static String A(JavaPlugin javaPlugin) {
        String string = javaPlugin.getConfig().getString("server-ip", "");
        if (!B(string)) {
            return string.trim();
        }
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            return "127.0.0.1";
        }
    }

    public static String A(String str, String str2, String str3, String str4) {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("licenseKey", str);
        jsonObject.addProperty("product_id", str2);
        jsonObject.addProperty("id", str3);
        jsonObject.addProperty("hwid", A());
        jsonObject.addProperty("plugin_version", str4);
        jsonObject.addProperty("version", str4);
        jsonObject.addProperty("ip", B());
        jsonObject.addProperty("java_version", System.getProperty("java.version"));
        jsonObject.addProperty("operating_system", System.getProperty("os.name"));
        jsonObject.addProperty("operating_system_version", System.getProperty("os.version"));
        jsonObject.addProperty("operating_system_architecture", System.getProperty("os.arch"));
        return new Gson().toJson((JsonElement) jsonObject);
    }

    public static String A(JsonObject jsonObject) {
        if (jsonObject == null) {
            return null;
        }
        if (jsonObject.has("version") && !jsonObject.get("version").isJsonNull()) {
            return jsonObject.get("version").getAsString();
        }
        if (jsonObject.has("productVersion") && !jsonObject.get("productVersion").isJsonNull()) {
            return jsonObject.get("productVersion").getAsString();
        }
        if (!jsonObject.has("status") || jsonObject.get("status").isJsonNull()) {
            return null;
        }
        return jsonObject.get("status").getAsString();
    }

    private static String B() {
        return "127.0.0.1";
    }

    static String A(String str) {
        if (B(str)) {
            return B;
        }
        String strReplaceAll = str.trim().replaceAll("/+$", "").replaceAll("(?i)/api/v1/licenses/validate$", "").replaceAll("(?i)/api/v1/licenses$", "").replaceAll("(?i)/api/v1/validate$", "").replaceAll("(?i)/api/v1$", "").replaceAll("(?i)/api/license$", "").replaceAll("(?i)/api$", "").replaceAll("(?i)/validate$", "");
        return B(strReplaceAll) ? B : strReplaceAll;
    }

    private static String E(String str) {
        return B(str) ? "<empty>" : str.length() <= 6 ? "***" : str.substring(0, 3) + "***" + str.substring(str.length() - 2);
    }
}
