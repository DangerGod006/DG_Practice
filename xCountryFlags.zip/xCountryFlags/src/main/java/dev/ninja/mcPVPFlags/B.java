package dev.ninja.mcPVPFlags;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:dev/ninja/mcPVPFlags/B.class */
public final class B {
    private static final Pattern D = Pattern.compile("\\\"countryCode\\\"\\s*:\\s*\\\"([A-Za-z]{2})\\\"");
    private final McPVPFlags F;
    private final Map<String, String> B = new ConcurrentHashMap();
    private final Map<UUID, String> A = new ConcurrentHashMap();
    private final Map<String, Component> E = new ConcurrentHashMap();
    private volatile boolean C;
    private volatile boolean G;
    private volatile int H;

    public B(McPVPFlags mcPVPFlags) {
        this.F = mcPVPFlags;
        A();
    }

    public void A() {
        File file = new File(this.F.getDataFolder(), "country-flags.yml");
        if (!file.exists()) {
            this.F.saveResource("country-flags.yml", false);
        }
        YamlConfiguration yamlConfigurationLoadConfiguration = YamlConfiguration.loadConfiguration(file);
        this.C = yamlConfigurationLoadConfiguration.getBoolean("enabled", false);
        this.G = "api".equalsIgnoreCase(yamlConfigurationLoadConfiguration.getString("geoip.method", "api"));
        this.H = Math.max(1, yamlConfigurationLoadConfiguration.getInt("geoip.timeout-seconds", 4)) * 1000;
        this.B.clear();
        this.E.clear();
        ConfigurationSection configurationSection = yamlConfigurationLoadConfiguration.getConfigurationSection("flags");
        if (configurationSection != null) {
            for (String str : configurationSection.getKeys(false)) {
                String string = configurationSection.getString(str);
                if (string != null && !string.isBlank()) {
                    this.B.put(str.toUpperCase(Locale.ROOT), string.trim());
                }
            }
        }
    }

    public void A(Player player) {
        if (!this.C || !this.G || player.getAddress() == null || player.getAddress().getAddress() == null) {
            return;
        }
        String hostAddress = player.getAddress().getAddress().getHostAddress();
        if (A(hostAddress)) {
            return;
        }
        UUID uniqueId = player.getUniqueId();
        this.F.getServer().getAsyncScheduler().runNow(this.F, scheduledTask -> {
            String strC = C(hostAddress);
            if (strC == null) {
                return;
            }
            this.A.put(uniqueId, strC.toUpperCase(Locale.ROOT));
        });
    }

    public void A(UUID uuid) {
        this.A.remove(uuid);
    }

    public String B(Player player) {
        if (!this.C || player == null) {
            return "";
        }
        String str = this.A.get(player.getUniqueId());
        String str2 = str == null ? null : this.B.get(str);
        return str2 == null ? "" : "<head_texture:" + str2 + ">";
    }

    public Component C(Player player) {
        if (!this.C || player == null) {
            return null;
        }
        String str = this.A.get(player.getUniqueId());
        String str2 = str == null ? null : this.B.get(str);
        if (str2 == null) {
            return null;
        }
        return this.E.computeIfAbsent(str, str3 -> {
            return B(str2);
        });
    }

    private String C(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) URI.create("http://ip-api.com/json/" + str + "?fields=status,countryCode").toURL().openConnection();
            httpURLConnection.setConnectTimeout(this.H);
            httpURLConnection.setReadTimeout(this.H);
            httpURLConnection.setRequestProperty("User-Agent", "McPVPFlags-CountryFlags");
            try {
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    Matcher matcher = D.matcher(new String(inputStream.readAllBytes(), StandardCharsets.UTF_8));
                    String strGroup = matcher.find() ? matcher.group(1) : null;
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    return strGroup;
                } catch (Throwable th) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } finally {
                httpURLConnection.disconnect();
            }
        } catch (Exception e) {
            return null;
        }
    }

    private Component B(String str) {
        return GsonComponentSerializer.gson().deserialize("{\"type\":\"object\",\"object\":\"player\",\"player\":{\"name\":\"flag\",\"id\":\"00000000-0000-0000-0000-000000000000\",\"properties\":[{\"name\":\"textures\",\"value\":\"" + Base64.getEncoder().encodeToString(("{\"textures\":{\"SKIN\":{\"url\":\"http://textures.minecraft.net/texture/" + str + "\"}}}").getBytes(StandardCharsets.UTF_8)) + "\"}]},\"hat\":true}");
    }

    private boolean A(String str) {
        return str.startsWith("127.") || str.startsWith("10.") || str.startsWith("192.168.") || str.equals("0:0:0:0:0:0:0:1") || str.equals("::1");
    }
}
