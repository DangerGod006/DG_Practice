package dev.ninja.mcPVPFlags;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:dev/ninja/mcPVPFlags/McPVPFlags.class */
public final class McPVPFlags extends JavaPlugin implements Listener {
    private B A;

    public void onEnable() {
        saveResource("country-flags.yml", false);
        if (!C.B(this) && getConfig().getBoolean("licensing.block-startup", true)) {
            getLogger().severe("Disabling McPVPFlags due to an invalid or missing license.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        this.A = new B(this);
        getServer().getPluginManager().registerEvents(this, this);
        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new A(this).register();
        }
    }

    public void onDisable() {
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent playerJoinEvent) {
        this.A.A(playerJoinEvent.getPlayer());
    }

    public B getCountryFlagService() {
        return this.A;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent playerQuitEvent) {
        this.A.A(playerQuitEvent.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onChat(AsyncChatEvent asyncChatEvent) {
        Component componentC = this.A.C(asyncChatEvent.getPlayer());
        if (componentC == null) {
            return;
        }
        asyncChatEvent.renderer((player, component, component2, audience) -> {
            return componentC.append(Component.space()).append(component).append(Component.text(": ")).append(component2);
        });
    }

    public boolean onCommand(CommandSender commandSender, Command command, String str, String[] strArr) {
        if (!command.getName().equalsIgnoreCase("mcpvpflags")) {
            return false;
        }
        if (!commandSender.hasPermission("mcpvpflags.admin")) {
            commandSender.sendMessage("You do not have permission to use this command.");
            return true;
        }
        if (strArr.length != 1 || !strArr[0].equalsIgnoreCase("reload")) {
            commandSender.sendMessage("Usage: /mcpvpflags reload");
            return true;
        }
        this.A.A();
        commandSender.sendMessage("McPVPFlags configuration reloaded.");
        return true;
    }
}
