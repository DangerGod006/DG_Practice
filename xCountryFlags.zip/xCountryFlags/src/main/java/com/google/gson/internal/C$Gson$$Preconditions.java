package com.google.gson.internal;

/* JADX INFO: renamed from: com.google.gson.internal.$Gson$$Preconditions, reason: invalid class name */
/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/$Gson$$Preconditions.class */
public final class C$Gson$$Preconditions {
    private C$Gson$$Preconditions() {
        throw new UnsupportedOperationException();
    }

    @Deprecated
    public static <T> T checkNotNull(T t) {
        if (t == null) {
            throw new NullPointerException();
        }
        return t;
    }

    public static void checkArgument(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }
}
