package com.google.gson;

import java.lang.reflect.Field;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/FieldNamingStrategy.class */
public interface FieldNamingStrategy {
    String translateName(Field field);
}
