package com.google.gson.internal.bind.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/bind/util/ISO8601Utils.class */
public class ISO8601Utils {
    private static final String UTC_ID = "UTC";
    private static final TimeZone TIMEZONE_UTC = TimeZone.getTimeZone(UTC_ID);

    private ISO8601Utils() {
    }

    public static String format(Date date) {
        return format(date, false, TIMEZONE_UTC);
    }

    public static String format(Date date, boolean z) {
        return format(date, z, TIMEZONE_UTC);
    }

    public static String format(Date date, boolean z, TimeZone timeZone) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar(timeZone, Locale.US);
        gregorianCalendar.setTime(date);
        StringBuilder sb = new StringBuilder("yyyy-MM-ddThh:mm:ss".length() + (z ? ".sss".length() : 0) + (timeZone.getRawOffset() == 0 ? "Z".length() : "+hh:mm".length()));
        padInt(sb, gregorianCalendar.get(1), "yyyy".length());
        sb.append('-');
        padInt(sb, gregorianCalendar.get(2) + 1, "MM".length());
        sb.append('-');
        padInt(sb, gregorianCalendar.get(5), "dd".length());
        sb.append('T');
        padInt(sb, gregorianCalendar.get(11), "hh".length());
        sb.append(':');
        padInt(sb, gregorianCalendar.get(12), "mm".length());
        sb.append(':');
        padInt(sb, gregorianCalendar.get(13), "ss".length());
        if (z) {
            sb.append('.');
            padInt(sb, gregorianCalendar.get(14), "sss".length());
        }
        int offset = timeZone.getOffset(gregorianCalendar.getTimeInMillis());
        if (offset != 0) {
            int iAbs = Math.abs((offset / 60000) / 60);
            int iAbs2 = Math.abs((offset / 60000) % 60);
            sb.append(offset < 0 ? '-' : '+');
            padInt(sb, iAbs, "hh".length());
            sb.append(':');
            padInt(sb, iAbs2, "mm".length());
        } else {
            sb.append('Z');
        }
        return sb.toString();
    }

    public static Date parse(String str, ParsePosition parsePosition) throws ParseException {
        int length;
        TimeZone timeZone;
        char cCharAt;
        try {
            int index = parsePosition.getIndex();
            int i = index + 4;
            int i2 = parseInt(str, index, i);
            if (checkOffset(str, i, '-')) {
                i++;
            }
            int i3 = i;
            int i4 = i + 2;
            int i5 = parseInt(str, i3, i4);
            if (checkOffset(str, i4, '-')) {
                i4++;
            }
            int i6 = i4;
            int i7 = i4 + 2;
            int i8 = parseInt(str, i6, i7);
            int i9 = 0;
            int i10 = 0;
            int i11 = 0;
            int i12 = 0;
            boolean zCheckOffset = checkOffset(str, i7, 'T');
            if (!zCheckOffset && str.length() <= i7) {
                GregorianCalendar gregorianCalendar = new GregorianCalendar(i2, i5 - 1, i8);
                gregorianCalendar.setLenient(false);
                parsePosition.setIndex(i7);
                return gregorianCalendar.getTime();
            }
            if (zCheckOffset) {
                int i13 = i7 + 1;
                int i14 = i13 + 2;
                i9 = parseInt(str, i13, i14);
                if (checkOffset(str, i14, ':')) {
                    i14++;
                }
                int i15 = i14;
                i7 = i14 + 2;
                i10 = parseInt(str, i15, i7);
                if (checkOffset(str, i7, ':')) {
                    i7++;
                }
                if (str.length() > i7 && (cCharAt = str.charAt(i7)) != 'Z' && cCharAt != '+' && cCharAt != '-') {
                    int i16 = i7;
                    i7 += 2;
                    i11 = parseInt(str, i16, i7);
                    if (i11 > 59 && i11 < 63) {
                        i11 = 59;
                    }
                    if (checkOffset(str, i7, '.')) {
                        int i17 = i7 + 1;
                        int iIndexOfNonDigit = indexOfNonDigit(str, i17 + 1);
                        int iMin = Math.min(iIndexOfNonDigit, i17 + 3);
                        int i18 = parseInt(str, i17, iMin);
                        switch (iMin - i17) {
                            case 1:
                                i12 = i18 * 100;
                                break;
                            case 2:
                                i12 = i18 * 10;
                                break;
                            default:
                                i12 = i18;
                                break;
                        }
                        i7 = iIndexOfNonDigit;
                    }
                }
            }
            if (str.length() <= i7) {
                throw new IllegalArgumentException("No time zone indicator");
            }
            char cCharAt2 = str.charAt(i7);
            if (cCharAt2 == 'Z') {
                timeZone = TIMEZONE_UTC;
                length = i7 + 1;
            } else {
                if (cCharAt2 != '+' && cCharAt2 != '-') {
                    throw new IndexOutOfBoundsException("Invalid time zone indicator '" + cCharAt2 + "'");
                }
                String strSubstring = str.substring(i7);
                String str2 = strSubstring.length() >= 5 ? strSubstring : strSubstring + "00";
                length = i7 + str2.length();
                if (str2.equals("+0000") || str2.equals("+00:00")) {
                    timeZone = TIMEZONE_UTC;
                } else {
                    String str3 = "GMT" + str2;
                    timeZone = TimeZone.getTimeZone(str3);
                    String id = timeZone.getID();
                    if (!id.equals(str3) && !id.replace(":", "").equals(str3)) {
                        throw new IndexOutOfBoundsException("Mismatching time zone indicator: " + str3 + " given, resolves to " + timeZone.getID());
                    }
                }
            }
            GregorianCalendar gregorianCalendar2 = new GregorianCalendar(timeZone);
            gregorianCalendar2.setLenient(false);
            gregorianCalendar2.set(1, i2);
            gregorianCalendar2.set(2, i5 - 1);
            gregorianCalendar2.set(5, i8);
            gregorianCalendar2.set(11, i9);
            gregorianCalendar2.set(12, i10);
            gregorianCalendar2.set(13, i11);
            gregorianCalendar2.set(14, i12);
            parsePosition.setIndex(length);
            return gregorianCalendar2.getTime();
        } catch (IllegalArgumentException | IndexOutOfBoundsException e) {
            String str4 = str == null ? null : '\"' + str + '\"';
            String message = e.getMessage();
            if (message == null || message.isEmpty()) {
                message = "(" + e.getClass().getName() + ")";
            }
            ParseException parseException = new ParseException("Failed to parse date [" + str4 + "]: " + message, parsePosition.getIndex());
            parseException.initCause(e);
            throw parseException;
        }
    }

    private static boolean checkOffset(String str, int i, char c) {
        return i < str.length() && str.charAt(i) == c;
    }

    private static int parseInt(String str, int i, int i2) throws NumberFormatException {
        if (i < 0 || i2 > str.length() || i > i2) {
            throw new NumberFormatException(str);
        }
        int i3 = i;
        int i4 = 0;
        if (i3 < i2) {
            i3++;
            int iDigit = Character.digit(str.charAt(i3), 10);
            if (iDigit < 0) {
                throw new NumberFormatException("Invalid number: " + str.substring(i, i2));
            }
            i4 = -iDigit;
        }
        while (i3 < i2) {
            int i5 = i3;
            i3++;
            int iDigit2 = Character.digit(str.charAt(i5), 10);
            if (iDigit2 < 0) {
                throw new NumberFormatException("Invalid number: " + str.substring(i, i2));
            }
            i4 = (i4 * 10) - iDigit2;
        }
        return -i4;
    }

    private static void padInt(StringBuilder sb, int i, int i2) {
        String string = Integer.toString(i);
        for (int length = i2 - string.length(); length > 0; length--) {
            sb.append('0');
        }
        sb.append(string);
    }

    private static int indexOfNonDigit(String str, int i) {
        for (int i2 = i; i2 < str.length(); i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt < '0' || cCharAt > '9') {
                return i2;
            }
        }
        return str.length();
    }
}
