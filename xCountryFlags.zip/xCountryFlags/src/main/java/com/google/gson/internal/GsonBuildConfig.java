package com.google.gson.internal;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/GsonBuildConfig.class */
public final class GsonBuildConfig {
    public static final String VERSION = "2.11.0";

    private GsonBuildConfig() {
    }
}
