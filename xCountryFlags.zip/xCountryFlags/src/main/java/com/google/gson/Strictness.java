package com.google.gson;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/Strictness.class */
public enum Strictness {
    LENIENT,
    LEGACY_STRICT,
    STRICT
}
