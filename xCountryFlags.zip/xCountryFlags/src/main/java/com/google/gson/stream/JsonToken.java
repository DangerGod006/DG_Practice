package com.google.gson.stream;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/stream/JsonToken.class */
public enum JsonToken {
    BEGIN_ARRAY,
    END_ARRAY,
    BEGIN_OBJECT,
    END_OBJECT,
    NAME,
    STRING,
    NUMBER,
    BOOLEAN,
    NULL,
    END_DOCUMENT
}
