package com.google.gson;

import java.lang.reflect.Type;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/JsonSerializationContext.class */
public interface JsonSerializationContext {
    JsonElement serialize(Object obj);

    JsonElement serialize(Object obj, Type type);
}
