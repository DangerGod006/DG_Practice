package com.google.gson.stream;

import java.io.IOException;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/stream/MalformedJsonException.class */
public final class MalformedJsonException extends IOException {
    private static final long serialVersionUID = 1;

    public MalformedJsonException(String str) {
        super(str);
    }

    public MalformedJsonException(String str, Throwable th) {
        super(str, th);
    }

    public MalformedJsonException(Throwable th) {
        super(th);
    }
}
