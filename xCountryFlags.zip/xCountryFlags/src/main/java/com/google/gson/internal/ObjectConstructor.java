package com.google.gson.internal;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/ObjectConstructor.class */
public interface ObjectConstructor<T> {
    T construct();
}
