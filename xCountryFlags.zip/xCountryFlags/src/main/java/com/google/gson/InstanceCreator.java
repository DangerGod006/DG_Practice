package com.google.gson;

import java.lang.reflect.Type;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/InstanceCreator.class */
public interface InstanceCreator<T> {
    T createInstance(Type type);
}
