package com.google.gson.internal;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/TroubleshootingGuide.class */
public class TroubleshootingGuide {
    private TroubleshootingGuide() {
    }

    public static String createUrl(String str) {
        return "https://github.com/google/gson/blob/main/Troubleshooting.md#" + str;
    }
}
