package com.google.gson;

import com.google.gson.stream.JsonReader;
import java.io.IOException;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/ToNumberStrategy.class */
public interface ToNumberStrategy {
    Number readNumber(JsonReader jsonReader) throws IOException;
}
