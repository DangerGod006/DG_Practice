package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Objects;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: renamed from: com.google.gson.internal.$Gson$$Types$$ParameterizedTypeImpl, reason: invalid class name */
/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/$Gson$$Types$$ParameterizedTypeImpl.class */
public final class C$Gson$$Types$$ParameterizedTypeImpl implements ParameterizedType, Serializable {
    private final Type ownerType;
    private final Type rawType;
    private final Type[] typeArguments;
    private static final long serialVersionUID = 0;

    public C$Gson$$Types$$ParameterizedTypeImpl(Type type, Type type2, Type... typeArr) {
        Objects.requireNonNull(type2);
        if (type == null && C$Gson$$Types.requiresOwnerType(type2)) {
            throw new IllegalArgumentException("Must specify owner type for " + type2);
        }
        this.ownerType = type == null ? null : C$Gson$$Types.canonicalize(type);
        this.rawType = C$Gson$$Types.canonicalize(type2);
        this.typeArguments = (Type[]) typeArr.clone();
        int length = this.typeArguments.length;
        for (int i = 0; i < length; i++) {
            Objects.requireNonNull(this.typeArguments[i]);
            C$Gson$$Types.checkNotPrimitive(this.typeArguments[i]);
            this.typeArguments[i] = C$Gson$$Types.canonicalize(this.typeArguments[i]);
        }
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type[] getActualTypeArguments() {
        return (Type[]) this.typeArguments.clone();
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type getRawType() {
        return this.rawType;
    }

    @Override // java.lang.reflect.ParameterizedType
    public Type getOwnerType() {
        return this.ownerType;
    }

    public boolean equals(Object obj) {
        return (obj instanceof ParameterizedType) && C$Gson$$Types.equals(this, (ParameterizedType) obj);
    }

    private static int hashCodeOrZero(Object obj) {
        if (obj != null) {
            return obj.hashCode();
        }
        return 0;
    }

    public int hashCode() {
        return (Arrays.hashCode(this.typeArguments) ^ this.rawType.hashCode()) ^ hashCodeOrZero(this.ownerType);
    }

    public String toString() {
        int length = this.typeArguments.length;
        if (length == 0) {
            return C$Gson$$Types.typeToString(this.rawType);
        }
        StringBuilder sb = new StringBuilder(30 * (length + 1));
        sb.append(C$Gson$$Types.typeToString(this.rawType)).append("<").append(C$Gson$$Types.typeToString(this.typeArguments[0]));
        for (int i = 1; i < length; i++) {
            sb.append(", ").append(C$Gson$$Types.typeToString(this.typeArguments[i]));
        }
        return sb.append(">").toString();
    }
}
