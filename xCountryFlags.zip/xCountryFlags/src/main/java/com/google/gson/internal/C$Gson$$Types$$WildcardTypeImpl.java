package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.Objects;

/* JADX INFO: Access modifiers changed from: private */
/* JADX INFO: renamed from: com.google.gson.internal.$Gson$$Types$$WildcardTypeImpl, reason: invalid class name */
/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/gson/internal/$Gson$$Types$$WildcardTypeImpl.class */
public final class C$Gson$$Types$$WildcardTypeImpl implements WildcardType, Serializable {
    private final Type upperBound;
    private final Type lowerBound;
    private static final long serialVersionUID = 0;

    public C$Gson$$Types$$WildcardTypeImpl(Type[] typeArr, Type[] typeArr2) {
        C$Gson$$Preconditions.checkArgument(typeArr2.length <= 1);
        C$Gson$$Preconditions.checkArgument(typeArr.length == 1);
        if (typeArr2.length != 1) {
            Objects.requireNonNull(typeArr[0]);
            C$Gson$$Types.checkNotPrimitive(typeArr[0]);
            this.lowerBound = null;
            this.upperBound = C$Gson$$Types.canonicalize(typeArr[0]);
            return;
        }
        Objects.requireNonNull(typeArr2[0]);
        C$Gson$$Types.checkNotPrimitive(typeArr2[0]);
        C$Gson$$Preconditions.checkArgument(typeArr[0] == Object.class);
        this.lowerBound = C$Gson$$Types.canonicalize(typeArr2[0]);
        this.upperBound = Object.class;
    }

    @Override // java.lang.reflect.WildcardType
    public Type[] getUpperBounds() {
        return new Type[]{this.upperBound};
    }

    @Override // java.lang.reflect.WildcardType
    public Type[] getLowerBounds() {
        return this.lowerBound != null ? new Type[]{this.lowerBound} : C$Gson$$Types.EMPTY_TYPE_ARRAY;
    }

    public boolean equals(Object obj) {
        return (obj instanceof WildcardType) && C$Gson$$Types.equals(this, (WildcardType) obj);
    }

    public int hashCode() {
        return (this.lowerBound != null ? 31 + this.lowerBound.hashCode() : 1) ^ (31 + this.upperBound.hashCode());
    }

    public String toString() {
        return this.lowerBound != null ? "? super " + C$Gson$$Types.typeToString(this.lowerBound) : this.upperBound == Object.class ? "?" : "? extends " + C$Gson$$Types.typeToString(this.upperBound);
    }
}
