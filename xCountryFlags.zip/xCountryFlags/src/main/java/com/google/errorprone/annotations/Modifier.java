package com.google.errorprone.annotations;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/errorprone/annotations/Modifier.class */
public enum Modifier {
    PUBLIC,
    PROTECTED,
    PRIVATE,
    ABSTRACT,
    DEFAULT,
    STATIC,
    FINAL,
    TRANSIENT,
    VOLATILE,
    SYNCHRONIZED,
    NATIVE,
    STRICTFP
}
