package com.google.errorprone.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/errorprone/annotations/FormatString.class */
@Target({ElementType.PARAMETER})
@Documented
@Retention(RetentionPolicy.CLASS)
public @interface FormatString {
}
