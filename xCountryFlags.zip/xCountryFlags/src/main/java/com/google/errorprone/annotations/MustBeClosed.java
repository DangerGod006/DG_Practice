package com.google.errorprone.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/errorprone/annotations/MustBeClosed.class */
@Target({ElementType.CONSTRUCTOR, ElementType.METHOD})
@Documented
public @interface MustBeClosed {
}
