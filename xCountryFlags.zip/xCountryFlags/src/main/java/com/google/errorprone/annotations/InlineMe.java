package com.google.errorprone.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: mcpvpflags-v2.4.jar:com/google/errorprone/annotations/InlineMe.class */
@Target({ElementType.METHOD, ElementType.CONSTRUCTOR})
@Documented
public @interface InlineMe {
    String replacement();

    String[] imports() default {};

    String[] staticImports() default {};
}
