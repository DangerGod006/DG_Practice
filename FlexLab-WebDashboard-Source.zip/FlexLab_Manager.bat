@echo off
title FlexLab // Cloud License Hub
start "" "%~dp0FlexLab-Dashboard.html"
exit
