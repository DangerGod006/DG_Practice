# FlexLab // Cloud License Hub - Source Code

Welcome to the **FlexLab Cloud License Hub** source code package!

## 📦 What's in this folder:
- `FlexLab-Dashboard.html`: The complete, self-contained single-file Web Dashboard application. No web server or build steps needed — simply double-click or launch with `FlexLab_Manager.bat`!
- `FlexLab_Manager.bat`: 1-Click desktop launcher for Windows.
- `AI_CONTEXT_AND_PROMPTS.md`: Complete guide for ChatGPT, Claude, Cursor, v0, etc., detailing Firebase endpoints, data models, cryptographic HMAC salts, and design structure.

## 🚀 How to Run
1. Double click `FlexLab_Manager.bat` or open `FlexLab-Dashboard.html` in Chrome, Edge, Brave, or Firefox.
2. The dashboard will instantly connect to the live Firebase Realtime Database and display all active licenses.

## 🤖 Giving this to an AI to modify:
1. Upload this zip file to your AI assistant (e.g. ChatGPT, Claude, Cursor).
2. Tell the AI:
   > *"I have uploaded the FlexLab Cloud License Hub source code and the AI_CONTEXT_AND_PROMPTS.md file. Please read the architecture and help me modify the design/styling [specify your changes here, such as table layout, key click button position, color themes, etc.]. Keep the Firebase REST endpoints and HMAC crypto generation intact."*
