# FlexLab // Cloud License Hub - AI Context & Modification Guide

> **Notice for AI Models (ChatGPT, Claude, Cursor, v0, etc.)**:
> This document provides the complete architectural context, API contracts, cryptographic specifications, and UI design rules for the **FlexLab Cloud License Hub**. Use this file to understand the system and modify or redesign the dashboard while preserving 100% functionality with the Firebase backend and Minecraft plugins.

---

## 1. Project Overview
- **Name**: FlexLab Cloud License Hub
- **Purpose**: A client-side, zero-dependency web dashboard for managing software licenses for Minecraft plugins (`xStrengthSmp` and `xCountryFlags`).
- **Hosting Model**: Operates directly as a standalone `file:///` local application in the user's browser, communicating with Firebase Realtime Database via REST API.

---

## 2. Cloud Backend Specification (Firebase RTDB)
- **Database Base URL**:
  `https://licence-manager-d75be-default-rtdb.asia-southeast1.firebasedatabase.app`
- **Data Endpoint**: `/licenses.json` or `/licenses/<LICENSE_KEY>.json`
- **CORS Support**: Firebase RTDB natively responds with `Access-Control-Allow-Origin: *`, allowing direct browser `fetch()` requests without any proxy server or authentication tokens.

### Schema of a License Object:
```json
{
  "key": "XSS-VEVTVHxBTLl8LTE-7a02e3a2c92f",
  "buyer_name": "TEST",
  "target_plugin": "xStrengthSmp",
  "ip_lock": "ANY",
  "validity_days": -1,
  "created_at": "2026-10-15T11:04:00Z",
  "status": "ACTIVE",
  "is_claimed": false,
  "server_ip": null,
  "server_port": null,
  "server_hwid": null,
  "activated_at": null,
  "last_ping": null,
  "revocation_reason": null
}
```

### Key Field Definitions:
- `key` (string): The compact license key (e.g. `XSS-V2FoYWp8QU5ZfC0x-5b28910db798`).
- `buyer_name` (string): Name or Discord tag of the customer.
- `target_plugin` (string): Either `"xStrengthSmp"` or `"xCountryFlags"`.
- `ip_lock` (string): `"ANY"` or a specific IP address (e.g. `192.168.1.50`).
- `validity_days` (number): Duration in days, or `-1` for Lifetime.
- `status` (string): `"ACTIVE"`, `"SUSPENDED"`, or `"REVOKED"`.
- `is_claimed` (boolean): `false` when key is fresh (unbound). Changes to `true` on first boot when a Minecraft server binds to it.
- `server_ip` (string): Bound server IP address.
- `server_port` (number/string): Bound server port.
- `server_hwid` (string): SHA-256 hardware fingerprint of the host machine.
- `last_ping` (string): ISO timestamp of the last heartbeat check from the server.

---

## 3. Cryptographic Key Format & Generation Logic

### Prefix:
- `XSS-` for `xStrengthSmp`
- `XCF-` for `xCountryFlags`

### Secret HMAC Salts (DO NOT CHANGE):
- **xStrengthSmp**: `DANGERxDEV_XSS_SECURE_HMAC_KEY_2026_!#987`
- **xCountryFlags**: `DANGERxDEV_XCF_SECURE_HMAC_KEY_2026_!#987`

### Payload Construction:
`payload = buyerName + "|" + ipLock + "|" + validityDays`
Example: `"Wahaj|ANY|-1"`
Base64 URL-safe encoded (without trailing `=` padding):
`b64 = btoa(payload).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')`

### HMAC-SHA256 Signature (Truncated to 12 Hex Chars):
Using `window.crypto.subtle`:
1. Key: Secret salt above.
2. Sign payload string with HMAC-SHA256.
3. Convert the signature to hex.
4. Take the **first 12 lowercase characters** of the hex string (`sigHex.substring(0, 12)`).

### Final Key Format:
`${prefix}${b64}-${shortSig}`
Example: `XSS-V2FoYWp8QU5ZfC0x-5b28910db798`

---

## 4. REST Operations Implemented in the Dashboard

1. **Fetch All Licenses**:
   ```javascript
   const res = await fetch(`${FIREBASE_URL}/licenses.json`);
   const data = await res.json();
   // data is a key-value object: { "<KEY_1>": { ... }, "<KEY_2>": { ... } }
   ```
2. **Toggle Status (Suspend / Reactivate)**:
   ```javascript
   await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
     method: "PATCH",
     headers: { "Content-Type": "application/json" },
     body: JSON.stringify({ status: newStatus, revocation_reason: reason })
   });
   ```
3. **Reset / Unlock Server (Unbind HWID, IP, Port)**:
   ```javascript
   await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
     method: "PATCH",
     headers: { "Content-Type": "application/json" },
     body: JSON.stringify({
       is_claimed: false,
       server_ip: null,
       server_port: null,
       server_hwid: null,
       activated_at: null
     })
   });
   ```
4. **Create New License (PUT)**:
   ```javascript
   await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
     method: "PUT",
     headers: { "Content-Type": "application/json" },
     body: JSON.stringify(payload)
   });
   ```
5. **Delete License**:
   ```javascript
   await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
     method: "DELETE"
   });
   ```

---

## 5. UI Elements & Layout Customization Instructions

The dashboard contains the following UI sections:
1. **Top Navbar**:
   - FlexLab Brand Logo (`F` badge + `FlexLab // LICENSE HUB`).
   - Live Firebase Connection indicator pill (`FIREBASE RTDB: LIVE`).
   - `Refresh Data` button (triggers immediate sync).
   - `+ Generate New Key` button (opens creation modal).
2. **Metrics Bar**:
   - 4 glassmorphic stat cards: Total Licenses, Active & Bound Servers, Ready to Claim Keys, Suspended Keys.
3. **Control Bar**:
   - Live instant fuzzy search input.
   - Filter tabs: `All`, `xStrengthSmp`, `xCountryFlags`, `Active`, `Ready`, `Suspended`.
4. **Data Table**:
   - Columns: `PLUGIN`, `BUYER`, `LICENSE KEY (COMPACT)`, `LOCKED SERVER`, `STATUS`, `VALIDITY`, `ACTIONS`.
   - **Key Cell**: Contains `.key-pill` with the key text and `.copy-btn` for 1-click clipboard copy with visual feedback. Both the pill and button can be clicked to copy.
   - **Action Buttons**: Inspect Telemetry, Toggle Status (Suspend/Active), Unlock Server, Delete Key.
5. **Telemetry Modal (`modalInspect`)**:
   - Detailed inspection card with full hardware & network metrics (HWID, IP, Port, Timestamps, raw JSON).
6. **Key Generator Modal (`modalGenerate`)**:
   - Form for Target Plugin, Buyer Name, IP Lock, Expiry Days, Live Key Preview, and Save Button.
7. **Interactive Background Canvas**:
   - Ambient particle network that animates and responds to mouse motion.

---

## 6. How to Modify with an AI

When asking an AI to redesign or add features:
- **Preserve the Firebase URL and REST logic**: Keep `fetchLicensesFromFirebase()`, `toggleStatus()`, `resetServer()`, `generateLicense()`, and `deleteLicense()`.
- **Maintain Web Crypto HMAC calculation**: Do not change the salts or the 12-char hex truncation logic so keys remain valid for the Minecraft plugins.
- **Single-File or Multi-File**: You can keep everything in a single `.html` file for zero-setup execution, or split into HTML, CSS, and JS.
