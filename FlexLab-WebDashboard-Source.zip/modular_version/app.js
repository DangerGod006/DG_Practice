// ==========================================
    // CONFIG & SECURITY SALTS
    // ==========================================
    const FIREBASE_URL = "https://licence-manager-d75be-default-rtdb.asia-southeast1.firebasedatabase.app";
    const SALT_XSS = "DANGERxDEV_XSS_SECURE_HMAC_KEY_2026_!#987";
    const SALT_XCF = "DANGERxDEV_XCF_SECURE_HMAC_KEY_2026_!#987";

    let allLicenses = [];
    let currentFilterPlugin = "all";
    let currentFilterStatus = "all";

    // ==========================================
    // AMBIENT BACKGROUND CANVAS
    // ==========================================
    const canvas = document.getElementById('bgCanvas');
    const ctx = canvas.getContext('2d');
    let particles = [];

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.5 + 0.1
      });
    }

    function animateBg() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';

      for (let i = 0; i < particles.length; i++) {
        let p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(16, 185, 129, ${p.alpha})`;
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          let p2 = particles[j];
          let dx = p.x - p2.x;
          let dy = p.y - p2.y;
          let dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 110) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(16, 185, 129, ${0.1 * (1 - dist / 110)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(animateBg);
    }
    animateBg();

    // ==========================================
    // CRYPTOGRAPHY & COMPACT KEY GENERATION
    // ==========================================
    function toBase64Url(str) {
      const bytes = new TextEncoder().encode(str);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }

    async function computeHmac(data, keyStr) {
      const enc = new TextEncoder();
      const cryptoKey = await window.crypto.subtle.importKey(
        "raw",
        enc.encode(keyStr),
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      const signature = await window.crypto.subtle.sign("HMAC", cryptoKey, enc.encode(data));
      const hashArray = Array.from(new Uint8Array(signature));
      const hex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      // Truncate to 12 hex characters for clean compact key!
      return hex.substring(0, 12);
    }

    async function generateCompactKey(pluginName, buyer, binding, expiryEpoch) {
      const isStrength = pluginName === "xStrengthSmp";
      const prefix = isStrength ? "XSS-" : "XCF-";
      const salt = isStrength ? SALT_XSS : SALT_XCF;

      const cleanBuyer = (buyer || "Customer").trim();
      const cleanBinding = (binding || "ANY").trim();

      const payload = `${cleanBuyer}|${cleanBinding}|${expiryEpoch}`;
      const b64Payload = toBase64Url(payload);
      const signature = await computeHmac(b64Payload, salt);

      return `${prefix}${b64Payload}-${signature}`;
    }

    function extractExpiryFromKey(key) {
      try {
        if (!key) return -1;
        const withoutPrefix = key.startsWith("XSS-") ? key.substring(4) : (key.startsWith("XCF-") ? key.substring(4) : key);
        const dashIdx = withoutPrefix.lastIndexOf('-');
        if (dashIdx === -1) return -1;
        const b64 = withoutPrefix.substring(0, dashIdx);
        // Base64 decode URL safe
        let standardB64 = b64.replace(/-/g, '+').replace(/_/g, '/');
        while (standardB64.length % 4) standardB64 += '=';
        const decoded = atob(standardB64);
        const parts = decoded.split('|');
        if (parts.length >= 3) {
          return parseInt(parts[2], 10);
        }
      } catch (e) {
      }
      return -1;
    }

    function formatExpiry(epoch) {
      if (epoch === -1 || epoch === "-1") return { text: "Lifetime", type: "life" };
      const now = Math.floor(Date.now() / 1000);
      const diff = epoch - now;
      if (diff <= 0) return { text: "EXPIRED", type: "expired" };
      const days = Math.floor(diff / 86400);
      if (days > 0) return { text: `${days}d left`, type: "active" };
      const hours = Math.floor(diff / 3600);
      if (hours > 0) return { text: `${hours}h left`, type: "active" };
      const mins = Math.floor(diff / 60);
      return { text: `${mins}m left`, type: "active" };
    }

    // ==========================================
    // FIREBASE REST API OPERATIONS
    // ==========================================
    async function fetchLicensesFromFirebase() {
      try {
        const btn = document.getElementById('btnRefresh');
        btn.classList.add('loading');

        const res = await fetch(`${FIREBASE_URL}/licenses.json`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

        allLicenses = [];
        if (data) {
          for (let key in data) {
            allLicenses.push({
              key: key,
              ...data[key]
            });
          }
        }

        // Sort descending by created_at
        allLicenses.sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));

        updateDashboard();
        showToast("Synchronized with Firebase Cloud!", "success");
      } catch (err) {
        showToast("Failed to fetch licenses: " + err.message, "error");
      } finally {
        const btn = document.getElementById('btnRefresh');
        btn.classList.remove('loading');
      }
    }

    async function toggleLicenseStatus(key, currentStatus) {
      const newStatus = (currentStatus === "ACTIVE") ? "SUSPENDED" : "ACTIVE";
      try {
        const res = await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: newStatus })
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        // Update local item
        const item = allLicenses.find(l => l.key === key);
        if (item) item.status = newStatus;
        updateDashboard();
        showToast(`License status changed to ${newStatus}`, "success");
      } catch (err) {
        showToast("Error toggling status: " + err.message, "error");
      }
    }

    async function unlockServerBinding(key) {
      if (!confirm("Are you sure you want to unlock this server? This allows the license to bind to a new IP & port on the next boot.")) return;
      try {
        const patchData = {
          server_ip: "",
          server_port: 0,
          server_hwid: "",
          is_claimed: false,
          status: "ACTIVE",
          activated_at: "",
          last_ping: ""
        };
        const res = await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patchData)
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const item = allLicenses.find(l => l.key === key);
        if (item) Object.assign(item, patchData);
        updateDashboard();
        showToast("Server lock reset! Ready to re-bind.", "success");
      } catch (err) {
        showToast("Error unlocking server: " + err.message, "error");
      }
    }

    async function deleteLicense(key) {
      if (!confirm(`Are you sure you want to PERMANENTLY delete license:\n${key}\nThis action cannot be undone!`)) return;
      try {
        const res = await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
          method: "DELETE"
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        allLicenses = allLicenses.filter(l => l.key !== key);
        updateDashboard();
        showToast("License deleted permanently.", "success");
      } catch (err) {
        showToast("Error deleting license: " + err.message, "error");
      }
    }

    // ==========================================
    // UI RENDERING & FILTERING
    // ==========================================
    function updateDashboard() {
      // 1. Calculate metrics
      const total = allLicenses.length;
      const active = allLicenses.filter(l => l.is_claimed && l.status === "ACTIVE").length;
      const unclaimed = allLicenses.filter(l => !l.is_claimed && l.status === "ACTIVE").length;
      const suspended = allLicenses.filter(l => l.status === "SUSPENDED" || l.status === "REVOKED").length;

      document.getElementById('statTotal').innerText = total;
      document.getElementById('statActive').innerText = active;
      document.getElementById('statUnclaimed').innerText = unclaimed;
      document.getElementById('statSuspended').innerText = suspended;

      // 2. Filter list
      const query = document.getElementById('searchInput').value.trim().toLowerCase();
      const filtered = allLicenses.filter(l => {
        // Plugin filter
        if (currentFilterPlugin === "XSS" && !l.key.startsWith("XSS-")) return false;
        if (currentFilterPlugin === "XCF" && !l.key.startsWith("XCF-")) return false;

        // Status filter
        if (currentFilterStatus === "active" && (!l.is_claimed || l.status !== "ACTIVE")) return false;
        if (currentFilterStatus === "unclaimed" && (l.is_claimed || l.status !== "ACTIVE")) return false;
        if (currentFilterStatus === "suspended" && l.status !== "SUSPENDED" && l.status !== "REVOKED") return false;

        // Search query
        if (query) {
          const text = [
            l.key,
            l.buyer_name,
            l.server_ip,
            l.server_port,
            l.server_hwid,
            l.status
          ].filter(Boolean).join(" ").toLowerCase();
          return text.includes(query);
        }
        return true;
      });

      // 3. Render table
      const tbody = document.getElementById('licensesTableBody');
      const emptyState = document.getElementById('emptyState');

      if (filtered.length === 0) {
        tbody.innerHTML = "";
        emptyState.style.display = "block";
        return;
      }

      emptyState.style.display = "none";
      tbody.innerHTML = filtered.map(item => {
        const isXss = item.key.startsWith("XSS-");
        const pluginTag = isXss ? "xStrengthSmp" : "xCountryFlags";
        const pluginClass = isXss ? "badge-xss" : "badge-xcf";
        const prefix = isXss ? "XSS" : "XCF";

        const buyer = item.buyer_name || "Customer";
        const initial = buyer.charAt(0).toUpperCase();

        const expEpoch = extractExpiryFromKey(item.key);
        const exp = formatExpiry(expEpoch);

        const isClaimed = Boolean(item.is_claimed);
        const isSuspended = item.status === "SUSPENDED" || item.status === "REVOKED";

        let serverHtml = "";
        if (isClaimed) {
          serverHtml = `<span class="server-pill server-locked">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            ${item.server_ip}:${item.server_port}
          </span>`;
        } else {
          serverHtml = `<span class="server-pill server-unclaimed">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            Auto-lock on boot
          </span>`;
        }

        let statusBadge = "";
        if (isSuspended) {
          statusBadge = `<span class="status-pill status-suspended">SUSPENDED</span>`;
        } else if (isClaimed) {
          statusBadge = `<span class="status-pill status-active">ACTIVE</span>`;
        } else {
          statusBadge = `<span class="status-pill status-ready">READY</span>`;
        }

        return `
          <tr>
            <td>
              <span class="plugin-badge ${pluginClass}">
                <span>${prefix}</span> • ${pluginTag}
              </span>
            </td>
            <td>
              <div class="buyer-cell">
                <div class="avatar">${initial}</div>
                <div class="buyer-info">
                  <div class="name">${escapeHtml(buyer)}</div>
                  <div class="created">${formatDate(item.created_at)}</div>
                </div>
              </div>
            </td>
            <td>
              <div class="key-cell">
                <span class="key-pill" title="Click to copy key: ${escapeHtml(item.key)}" onclick="copyKey('${escapeHtml(item.key)}', this)">${escapeHtml(item.key)}</span>
                <button class="copy-btn" onclick="copyKey('${escapeHtml(item.key)}', this)">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                  Copy
                </button>
              </div>
            </td>
            <td>${serverHtml}</td>
            <td>${statusBadge}</td>
            <td>
              <span class="expiry-pill expiry-${exp.type}">
                ${exp.text}
              </span>
            </td>
            <td>
              <div class="actions-cell">
                <button class="action-icon-btn" title="Inspect Telemetry" onclick="inspectLicense('${escapeHtml(item.key)}')">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                </button>
                <button class="action-icon-btn" title="Toggle Active / Suspended" onclick="toggleLicenseStatus('${escapeHtml(item.key)}', '${item.status || 'ACTIVE'}')">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>
                </button>
                <button class="action-icon-btn" title="Reset Server IP Lock" onclick="unlockServerBinding('${escapeHtml(item.key)}')">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>
                </button>
                <button class="action-icon-btn danger" title="Delete License Key" onclick="deleteLicense('${escapeHtml(item.key)}')">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }

    function escapeHtml(str) {
      if (!str) return "";
      return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function formatDate(isoStr) {
      if (!isoStr) return "Just now";
      try {
        const d = new Date(isoStr);
        return d.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
      } catch (e) {
        return isoStr;
      }
    }

    // ==========================================
    // CLIPBOARD COPY
    // ==========================================
    function copyKey(text, btnElement) {
      navigator.clipboard.writeText(text).then(() => {
        if (btnElement) {
          const original = btnElement.innerHTML;
          if (btnElement.classList.contains('key-pill')) {
            btnElement.innerHTML = `✓ Copied!`;
            btnElement.style.color = "var(--neon-green)";
            btnElement.style.borderColor = "rgba(16, 185, 129, 0.5)";
            setTimeout(() => {
              btnElement.innerHTML = original;
              btnElement.style.color = "";
              btnElement.style.borderColor = "";
            }, 1200);
          } else {
            btnElement.innerHTML = `✓ Copied!`;
            btnElement.style.color = "var(--neon-green)";
            setTimeout(() => {
              btnElement.innerHTML = original;
              btnElement.style.color = "";
            }, 1500);
          }
        }
        showToast("License key copied to clipboard!", "success");
      });
    }

    // ==========================================
    // MODAL DIALOGS & GENERATE FLOW
    // ==========================================
    function openModal(id) {
      document.getElementById(id).classList.add('open');
    }

    function closeModal(id) {
      document.getElementById(id).classList.remove('open');
    }

    document.getElementById('btnOpenGenerate').addEventListener('click', () => {
      document.getElementById('genBuyer').value = "";
      document.getElementById('genBinding').value = "ANY";
      document.getElementById('genDays').value = "-1";
      document.querySelectorAll('.preset-chip').forEach(c => c.classList.remove('active'));
      document.querySelector('.preset-chip').classList.add('active');
      updateLivePreview();
      openModal('modalGenerate');
    });

    function setValidityPreset(element, days) {
      document.querySelectorAll('.preset-chip').forEach(c => c.classList.remove('active'));
      element.classList.add('active');
      document.getElementById('genDays').value = days;
      updateLivePreview();
    }

    async function updateLivePreview() {
      const plugin = document.getElementById('genPlugin').value;
      const buyer = document.getElementById('genBuyer').value.trim() || "Buyer";
      const binding = document.getElementById('genBinding').value.trim() || "ANY";
      const days = parseInt(document.getElementById('genDays').value, 10);

      const expiryEpoch = (days <= 0) ? -1 : Math.floor(Date.now() / 1000) + (days * 86400);
      const key = await generateCompactKey(plugin, buyer, binding, expiryEpoch);

      document.getElementById('previewKey').innerText = key;
      document.getElementById('previewKeyLen').innerText = `${key.length} characters (Compact)`;
    }

    async function submitGenerateKey() {
      const plugin = document.getElementById('genPlugin').value;
      const buyer = document.getElementById('genBuyer').value.trim() || "Customer";
      const binding = document.getElementById('genBinding').value.trim() || "ANY";
      const days = parseInt(document.getElementById('genDays').value, 10);
      const expiryEpoch = (days <= 0) ? -1 : Math.floor(Date.now() / 1000) + (days * 86400);

      const submitBtn = document.getElementById('btnSubmitGenerate');
      submitBtn.disabled = true;
      submitBtn.innerText = "Saving to Cloud...";

      try {
        const key = await generateCompactKey(plugin, buyer, binding, expiryEpoch);
        const nowIso = new Date().toISOString();

        const payload = {
          license_key: key,
          buyer_name: buyer,
          is_claimed: false,
          status: "ACTIVE",
          created_at: nowIso,
          server_ip: "",
          server_port: 0,
          server_hwid: "",
          activated_at: "",
          last_ping: ""
        };

        const res = await fetch(`${FIREBASE_URL}/licenses/${encodeURIComponent(key)}.json`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        // Add to local array
        allLicenses.unshift({ key: key, ...payload });
        updateDashboard();

        closeModal('modalGenerate');
        copyKey(key);
        showToast("License key created & stored 24/7 in Firebase!", "success");
      } catch (err) {
        showToast("Error generating key: " + err.message, "error");
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `✓ Generate & Save to Cloud`;
      }
    }

    function inspectLicense(key) {
      const item = allLicenses.find(l => l.key === key);
      if (!item) return;

      const isXss = item.key.startsWith("XSS-");
      const pluginTag = isXss ? "xStrengthSmp" : "xCountryFlags";
      const expEpoch = extractExpiryFromKey(item.key);
      const exp = formatExpiry(expEpoch);

      const html = `
        <div style="background: rgba(0,0,0,0.4); border: 1px solid var(--border-card); border-radius: 14px; padding: 16px; margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Target Plugin</span>
            <span style="font-weight: 700; color: #fff;">${pluginTag}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Buyer Name</span>
            <span style="font-weight: 600; color: var(--neon-cyan);">${escapeHtml(item.buyer_name || 'Customer')}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Status</span>
            <span style="font-weight: 700; color: ${item.status === 'ACTIVE' ? 'var(--neon-green)' : 'var(--neon-red)'};">${item.status || 'ACTIVE'}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Server Lock</span>
            <span style="font-family: 'Fira Code', monospace; font-size: 12px; color: #fff;">${item.server_ip ? `${item.server_ip}:${item.server_port}` : 'UNCLAIMED'}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Hardware HWID</span>
            <span style="font-family: 'Fira Code', monospace; font-size: 11px; color: var(--text-muted);">${item.server_hwid || 'None'}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Created</span>
            <span style="font-size: 12px; color: var(--text-muted);">${formatDate(item.created_at)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Activated</span>
            <span style="font-size: 12px; color: var(--text-muted);">${formatDate(item.activated_at)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700;">Last Ping</span>
            <span style="font-size: 12px; color: var(--text-muted);">${formatDate(item.last_ping)}</span>
          </div>
        </div>

        <div style="margin-bottom: 10px;">
          <span style="font-size: 11px; text-transform: uppercase; color: var(--text-dim); font-weight: 700; display: block; margin-bottom: 6px;">Full Compact License Key</span>
          <div style="background: rgba(0,0,0,0.5); padding: 12px; border-radius: 10px; font-family: 'Fira Code', monospace; font-size: 13px; color: var(--neon-green); word-break: break-all; border: 1px solid var(--border-card);">
            ${escapeHtml(item.key)}
          </div>
        </div>
      `;

      document.getElementById('inspectContent').innerHTML = html;
      document.getElementById('btnCopyInspectKey').onclick = () => copyKey(item.key);
      openModal('modalInspect');
    }

    // ==========================================
    // TOAST SYSTEM
    // ==========================================
    function showToast(message, type = "info") {
      const container = document.getElementById('toastContainer');
      const toast = document.createElement('div');
      toast.className = 'toast';

      let icon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
      if (type === "error") {
        icon = `<svg viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
        toast.style.borderColor = "rgba(239, 68, 68, 0.4)";
      }

      toast.innerHTML = `${icon} <span>${escapeHtml(message)}</span>`;
      container.appendChild(toast);

      setTimeout(() => toast.classList.add('show'), 10);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }, 3500);
    }

    // ==========================================
    // EVENT LISTENERS & INITIALIZATION
    // ==========================================
    document.getElementById('btnRefresh').addEventListener('click', fetchLicensesFromFirebase);
    document.getElementById('searchInput').addEventListener('input', updateDashboard);

    document.querySelectorAll('[data-filter]').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('[data-filter]').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        currentFilterPlugin = pill.dataset.filter;
        updateDashboard();
      });
    });

    document.querySelectorAll('[data-status]').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('[data-status]').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        currentFilterStatus = pill.dataset.status;
        updateDashboard();
      });
    });

    // Auto-refresh every 12 seconds
    setInterval(() => {
      fetchLicensesFromFirebase();
    }, 12000);

    // Initial load
    fetchLicensesFromFirebase();