/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

class \u03b8\u03bc\u03a9\u03b8\u03bf\u03bf\u03be\u03c1\u03bc {
}

