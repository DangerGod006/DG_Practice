/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.event.player.AsyncChatEvent
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import io.papermc.paper.event.player.AsyncChatEvent;
import lombok.Generated;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

public class \u03b7\u03c4\u03c2\u03c2\u03c7\u03b7\u03bc\u0394\u03c7\u03a6
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int a = 256 >>> 8 | 256 << ~8 + 1;
    private final nLoginBukkit e;

    @EventHandler(priority=EventPriority.HIGH)
    public void a(AsyncChatEvent asyncChatEvent) {
        String string;
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.e.b().a(asyncChatEvent.getPlayer());
        Component component = asyncChatEvent.message();
        String string2 = string = component instanceof TextComponent ? ((TextComponent)component).content() : null;
        if (this.e.a().b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string)) {
            asyncChatEvent.setCancelled(a != 0);
        }
    }

    @Generated
    public \u03b7\u03c4\u03c2\u03c2\u03c7\u03b7\u03bc\u0394\u03c7\u03a6(nLoginBukkit nLoginBukkit2) {
        this.e = nLoginBukkit2;
    }
}

