/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1
extends \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394 {
    private static int ax;
    private static String[] g;
    private static int f;
    private static long ac;
    private static long ar;
    private static int bc;
    private static int al;
    private static long s;
    private static long aq;
    private static long ad;
    private static long bd;
    private static long az;
    private static String[] h;
    private static int bk;
    private static long bg;
    private static int bi;

    public \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.I, (String)\u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.c("\u3e80", (int)f, (long)(ac ^ ad)), (String)\u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.c("\u3e83", (int)al, (long)(aq ^ ar)), (String)\u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.c("\u3e86", (int)ax, (long)az), (String)\u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.c("\u3e89", (int)bc, (long)(bd ^ bg)));
    }

    private static String a(int n, long l) {
        l ^= 0x60L;
        l ^= 0x732D00EA64655AC6L;
        if (g[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(29 + 39), (byte)(36 + 33), (byte)(43 + 40), (byte)(26 + 21), (byte)(41 + 26), (byte)(23 + 43), (byte)(60 + 7), (byte)(29 + 18), 80, (byte)(33 + 42), (byte)(49 + 18), (byte)(37 + 46), (byte)(8 + 45), (byte)(78 + 2), 97, (byte)(75 + 25), (byte)(4 + 96), (byte)(81 + 24), (byte)(89 + 21), (byte)(27 + 76)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(40 + 28), (byte)(54 + 15), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08ef\u08ed\u08f5\u08f1\u08e4\u08e6\u08c7\u08f5\u08e9\u08dd\u08f7\u08cc\u08eb", (byte)97, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.g[n] = new String(cipher.doFinal(Base64.getDecoder().decode(h[n])), StandardCharsets.UTF_8);
        }
        return g[n];
    }

    private static void b() {
        int n;
        s = -9092927670442856610L;
        long l = s ^ 0x732D00EA64655AC6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(26 + 43), (byte)(79 + 4), (byte)(42 + 5), (byte)(48 + 19), (byte)(60 + 6), (byte)(26 + 41), (byte)(27 + 20), (byte)(53 + 27), (byte)(71 + 4), 67, (byte)(58 + 25), (byte)(4 + 49), (byte)(68 + 12), (byte)(40 + 57), (byte)(76 + 24), 100, (byte)(25 + 80), (byte)(35 + 75), (byte)(44 + 59)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(4 + 64), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u0520\u0526\u0534\u0532\u0541\u0528\u0543\u0516\u0544\u0533\u0556\u054b\u051e\u0536\u053b\u0550\u0532\u0544\u0557\u0530\u0554\u0556\u052d\u052e", (byte)30, 69);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0552\u052c\u0528\u054a\u050f\u054d\u0515\u0544\u0524\u0538\u053d\u0522", (byte)30, 69);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u0456\u043b\u0477\u047f\u047a\u045b\u0445\u046d\u0469\u0466\u046e\u0457", (byte)30, 67);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u00f3\u012a\u0117\u00f0\u0114\u0117\u0125\u010b\u0125\u0114\u0138\u0103", (byte)30, 66);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0520\u0526\u0534\u0532\u0541\u0528\u0543\u0516\u0544\u0533\u0554\u0536\u053d\u053b\u0519\u0539\u052e\u053f\u051f\u0532\u0522\u0556\u052d\u052e", (byte)30, 70);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0512\u0532\u054e\u0528\u0528\u0549\u0525\u054a\u054f\u0530\u0557\u0522", (byte)30, 69);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u0133\u0102\u00e8\u0136\u012d\u0135\u0127\u00f2\u00f3\u011d\u0129\u0116\u010f\u012c\u0139\u0115\u0132\u0139\u011a\u011f\u011e\u0147\u010e\u010f", (byte)30, 66);
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u054c\u0534\u0528\u054d\u0511\u0557\u0547\u0548\u0553\u055d\u0557\u0522", (byte)30, 69);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u054e\u050a\u0552\u0530\u0538\u052d\u0526\u054a\u054e\u0551\u0547\u0535\u053c\u0530\u0537\u054e\u0536\u054e\u054e\u051c\u0557\u0528\u0561\u0554\u0541\u055c\u0527\u0541\u0565\u054b\u056a\u055b", (byte)30, 70);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.h[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0456\u0482\u0443\u0461\u0476\u046d\u0461\u048e\u0479\u046e\u0460\u0481\u046d\u0480\u047f\u0473\u0466\u0468\u0477\u0479\u047b\u048b\u0462\u0463", (byte)30, 67);
                }
            }
        }
    }

    static {
        f = (0 >>> 240 | 0 << -240) & 0xFFFFFFFF;
        ac = Long.reverse(8860681993167762305L);
        ad = Long.reverse(0x600000000000000L);
        al = Integer.reverse(Integer.MIN_VALUE);
        aq = Long.reverse(8860681993167762305L);
        ar = Long.reverse(0x600000000000000L);
        ax = (16384 >>> 173 | 16384 << ~173 + 1) & 0xFFFFFFFF;
        az = Long.reverse(9004797181243618177L);
        bc = (0x18000000 >>> 59 | 0x18000000 << -59) & 0xFFFFFFFF;
        bd = Long.reverse(8860681993167762305L);
        bg = Long.reverse(0x600000000000000L);
        bi = (131072 >>> 79 | 131072 << -79) & 0xFFFFFFFF;
        bk = Integer.reverse(0x20000000);
        g = new String[bi];
        h = new String[bk];
        \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0491\u04b3\u04b5\u0495\u04b9\u04d8\u04d0\u04e6\u04d2\u04a1\u04df\u04d5\u04e3\u04dd\u04a6\u04cb\u04ed\u04ec\u04e4\u04ea\u04e4\u04b9", (byte)60, 68), \u03c1\u03be\u03c5\u03c0\u03b2\u03b3\u0393\u03c0\u03b3\u03a6\u03bf\u0393\u03b1.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u015a\u0167\u0166\u0129\u0169\u0165\u0160\u0169\u0174\u0163\u0130\u016e\u0172\u016b\u016e\u0174\u0136\u04c9\u04c7\u04cf\u04cb\u04be\u04c0\u04a1\u04cf\u04c3\u04b7\u04d1\u04a6\u04c5\u014f", (byte)60, 66) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u0131", (byte)60, 65) + methodType.toString(), exception);
        }
    }
}

