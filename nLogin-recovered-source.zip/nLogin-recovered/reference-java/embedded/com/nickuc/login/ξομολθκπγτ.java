/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import java.util.Map;
import java.util.concurrent.Callable;

public class \u03be\u03bf\u03bc\u03bf\u03bb\u03b8\u03ba\u03c0\u03b3\u03c4 {
    public static <T, V> T a(Map<T, V> map, Callable<T> callable) {
        T t;
        while (map.containsKey(t = callable.call())) {
        }
        return t;
    }
}

