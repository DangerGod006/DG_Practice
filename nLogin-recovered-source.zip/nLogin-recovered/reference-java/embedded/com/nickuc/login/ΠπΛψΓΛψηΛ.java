/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import lombok.Generated;

public class \u03a0\u03c0\u039b\u03c8\u0393\u039b\u03c8\u03b7\u039b {
    private final String ba;
    private final long q;

    @Generated
    public \u03a0\u03c0\u039b\u03c8\u0393\u039b\u03c8\u03b7\u039b(long l, String string) {
        this.q = l;
        this.ba = string;
    }

    @Generated
    public long e() {
        return this.q;
    }

    @Generated
    public String U() {
        return this.ba;
    }
}

