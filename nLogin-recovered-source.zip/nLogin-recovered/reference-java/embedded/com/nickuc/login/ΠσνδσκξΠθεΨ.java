/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8
extends Enum<\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8> {
    public static final /* enum */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 a;
    public static final /* enum */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 b;
    public static final /* enum */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 c;
    public static final /* enum */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 d;
    private final char e;
    private final Function<Long, Long> a;
    private static final /* synthetic */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static long a;
    private static long b;
    private static long d;
    private static long e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static int k;
    private static int l;
    private static int m;
    private static long n;
    private static long o;
    private static int p;
    private static int q;
    private static int r;
    private static long s;
    private static long t;
    private static int u;
    private static int v;
    private static int w;
    private static long x;
    private static long y;
    private static int z;
    private static int aa;
    private static int ab;
    private static int ac;
    private static long ad;
    private static int ae;
    private static int af;

    static /* synthetic */ Function a(\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8) {
        return \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.a;
    }

    private static void b() {
        int n;
        c = 1987452390614443889L;
        long l = c ^ 0xBFA2B39A5486BBC0L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(35 + 34), (byte)(36 + 47), (byte)(21 + 26), 67, (byte)(11 + 55), (byte)(63 + 4), (byte)(34 + 13), (byte)(17 + 63), (byte)(39 + 36), (byte)(48 + 19), (byte)(2 + 81), (byte)(16 + 37), (byte)(70 + 10), (byte)(84 + 13), (byte)(41 + 59), (byte)(39 + 61), (byte)(88 + 17), (byte)(81 + 29), (byte)(27 + 76)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(23 + 45), (byte)(13 + 56), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0499\u0488\u04ba\u0479\u047b\u04c1\u047c\u04c4\u04c4\u04a2\u0487\u048d", (byte)48, 68);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u012c\u014f\u014a\u0147\u0118\u0148\u0138\u0150\u0133\u0130\u014c\u0127", (byte)48, 65);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u014f\u0155\u0135\u012c\u013a\u0136\u012d\u0131\u0135\u0152\u0150\u0127", (byte)48, 66);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[3] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0558\u0526\u053e\u055e\u0559\u0568\u056a\u0534\u054d\u0557\u0543\u0534", (byte)48, 70);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0531\u0558\u0533\u0568\u055f\u0537\u0541\u0565\u0561\u056f\u0543\u0534", (byte)48, 69);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0560\u0536\u055e\u0522\u0536\u0542\u0562\u0556\u0541\u0526\u054b\u0534", (byte)48, 70);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u049f\u04ad\u04b4\u0497\u04a0\u04b9\u048e\u0480\u049f\u0486\u047e\u0485\u04c9\u0498\u049c\u0499\u04c8\u04b7\u0490\u0499\u04a6\u049b\u0498\u0499", (byte)48, 68);
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u053f\u0564\u0541\u0527\u0560\u0542\u0546\u0547\u056c\u054f\u0540\u0566\u054d\u0570\u0570\u0561\u0556\u0553\u054c\u0564\u0531\u0578\u053f\u0540", (byte)48, 69);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u048a\u0488\u04c0\u049c\u04b1\u048b\u04b8\u04ad\u049f\u049c\u04b8\u04aa\u047c\u04ab\u04c3\u04bb\u04b7\u0488\u04a9\u04c9\u04c1\u04ab\u0498\u0499", (byte)48, 68);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u054e\u0521\u0520\u055c\u0561\u0539\u056b\u0559\u055d\u055c\u052c\u052c\u055f\u0560\u0533\u054f\u0547\u0534\u0541\u056f\u0535\u0542\u053f\u0540", (byte)48, 70);
                }
            }
        }
    }

    private static /* synthetic */ \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[] a() {
        \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[] \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array = new \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[f];
        \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array[\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.g] = a;
        \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array[\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.h] = b;
        \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array[\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.i] = c;
        \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array[\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.j] = d;
        return \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8Array;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04c4\u04e6\u04e8\u04c8\u04ec\u050b\u0503\u0519\u0505\u04d4\u0512\u0508\u0516\u0510\u04d9\u04fe\u0520\u051f\u0517\u051d\u0517\u04ec", (byte)77, 67), \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u017c\u0189\u0188\u014b\u018b\u0187\u0182\u018b\u0196\u0185\u0152\u0190\u0194\u018d\u0190\u0196\u0158\u04ca\u04ee\u04e9\u04e1\u04f1\u04e9\u04ee\u04d1\u04ea\u04e8\u04dc\u016f", (byte)77, 65) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0543", (byte)77, 70) + methodType.toString(), exception);
        }
    }

    static /* synthetic */ char a(\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8) {
        return \u03c0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.e;
    }

    public static \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8 valueOf(String string) {
        return Enum.valueOf(\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.class, string);
    }

    private static String a(int n, long l) {
        l ^= 0x59L;
        l ^= 0xBFA2B39A5486BBC0L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(43 + 26), (byte)(25 + 58), (byte)(16 + 31), (byte)(5 + 62), (byte)(2 + 64), (byte)(58 + 9), (byte)(22 + 25), (byte)(70 + 10), (byte)(55 + 20), 67, (byte)(8 + 75), (byte)(19 + 34), (byte)(11 + 69), (byte)(38 + 59), 100, (byte)(85 + 15), (byte)(100 + 5), (byte)(28 + 82), (byte)(88 + 15)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(18 + 51), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0427\u0434\u0433\u03f6\u0436\u0432\u042d\u0436\u0441\u0430\u03fd\u043b\u043f\u0438\u043b\u0441\u0403\u0775\u0799\u0794\u078c\u079c\u0794\u0799\u077c\u0795\u0793\u0787", (byte)5, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    private \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8(char c, Function<Long, Long> function) {
        this.e = c;
        this.a = function;
    }

    public static \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[] values() {
        return (\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8[])a.clone();
    }

    static {
        a = Long.reverse(0x3C00000000000000L);
        b = Long.reverse(0x3C00000000000000L);
        d = Long.reverse(0x1800000000000000L);
        e = Long.reverse(-2L);
        f = (65536 >>> 78 | 65536 << ~78 + 1) & 0xFFFFFFFF;
        g = 0 >>> 6 | 0 << -6;
        h = 0x200000 >>> 85 | 0x200000 << -85;
        i = Integer.reverse(0x40000000);
        j = Integer.reverse(-1073741824);
        k = 8 >>> 33 | 8 << ~33 + 1;
        \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.l = 0x10000000 >>> 58 | 0x10000000 << ~58 + 1;
        m = Integer.reverse(0);
        n = Long.reverse(-8150167964929545768L);
        o = Long.reverse(-7349874591868649472L);
        p = (0 >>> 116 | 0 << ~116 + 1) & 0xFFFFFFFF;
        q = 200 >>> 97 | 200 << -97;
        r = Integer.reverse(Integer.MIN_VALUE);
        s = Long.reverse(-8150167964929545768L);
        t = Long.reverse(-7349874591868649472L);
        u = 0x100000 >>> 148 | 0x100000 << -148;
        v = Integer.reverse(0x16000000);
        w = 4096 >>> 11 | 4096 << ~11 + 1;
        x = Long.reverse(-8150167964929545768L);
        y = Long.reverse(-7349874591868649472L);
        z = Integer.reverse(0x40000000);
        aa = Integer.reverse(-1241513984);
        ab = (0x6000000 >>> 185 | 0x6000000 << ~185 + 1) & 0xFFFFFFFF;
        ac = (-1 >>> 189 | -1 << ~189 + 1) & 0xFFFFFFFF;
        ad = Long.reverse(1505549636152797656L);
        ae = Integer.reverse(-1073741824);
        af = Integer.reverse(-838860800);
        a = new String[k];
        b = new String[\u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.l];
        \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.b();
        a = new \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8((char)q, l -> TimeUnit.MILLISECONDS.toDays((long)l) % e);
        b = new \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8((char)v, l -> TimeUnit.MILLISECONDS.toHours((long)l) % d);
        c = new \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8((char)aa, l -> TimeUnit.MILLISECONDS.toMinutes((long)l) % b);
        d = new \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8((char)af, l -> TimeUnit.MILLISECONDS.toSeconds((long)l) % a);
        a = \u03a0\u03c3\u03bd\u03b4\u03c3\u03ba\u03be\u03a0\u03b8\u03b5\u03a8.a();
    }
}

