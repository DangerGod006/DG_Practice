/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1 {
    private final boolean W;
    private static String[] b;
    private static int f;
    private static long k;
    private static int e;
    private static String[] a;
    private static long g;
    private static int j;
    private static long o;
    private static int p;
    private static long i;
    private final long r;
    private static long d;
    private final int X;
    private static long b;
    private static int h;
    private final Throwable a;
    private static int n;
    private static int q;
    private static long l;
    private static int a;
    private static int m;
    private static long c;

    private static void b() {
        int n;
        c = 1633953353190640994L;
        long l = c ^ 0x7A0F4353D89C2B46L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(54 + 15), (byte)(16 + 67), (byte)(20 + 27), (byte)(25 + 42), (byte)(56 + 10), (byte)(58 + 9), (byte)(20 + 27), (byte)(14 + 66), (byte)(54 + 21), (byte)(4 + 63), 83, (byte)(32 + 21), (byte)(3 + 77), (byte)(26 + 71), (byte)(83 + 17), 100, (byte)(98 + 7), (byte)(25 + 85), (byte)(17 + 86)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(58 + 25)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u043e\u0430\u043d\u0452\u0454\u0442\u043c\u041d\u0441\u0462\u0461\u0425\u042e\u0428\u043a\u0468\u042b\u0452\u0446\u045f\u0478\u0450\u047b\u044b\u043c\u0473\u043c\u0435\u045f\u043e\u0480\u0464", (byte)18, 67);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0534\u04fe\u0537\u0532\u0535\u0520\u0522\u0526\u050c\u051e\u0550\u0533\u0540\u0544\u050d\u051e\u0558\u0551\u0546\u0510\u0550\u054a\u0521\u0522", (byte)18, 70);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u051f\u0547\u0549\u0501\u053e\u050b\u051b\u050e\u051a\u0530\u053d\u054c\u0540\u0545\u054c\u0523\u0510\u0514\u0545\u0519\u0545\u051b\u0551\u0519\u0560\u055f\u0530\u051d\u0559\u0535\u054d\u0526", (byte)18, 70);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0454\u045e\u042f\u0455\u0469\u0437\u0420\u045e\u0446\u0426\u045b\u046e\u045c\u045a\u0452\u0470\u046b\u045f\u046c\u0457\u0467\u0477\u043e\u043f", (byte)18, 67);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0452\u0465\u0458\u0425\u041a\u0428\u0423\u0433\u0460\u0458\u0458\u0433", (byte)18, 67);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u043e\u0430\u043d\u0452\u0454\u0442\u043c\u041d\u0441\u0462\u0461\u0425\u042e\u0428\u043a\u0468\u042b\u0452\u0446\u045f\u0478\u044f\u047b\u0435\u0436\u0455\u047c\u043a\u045a\u0474\u046b\u044c\u0484\u0484\u046f\u0456\u0475\u0454\u0461\u0469\u0443\u046c\u0484\u0453", (byte)18, 68);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0451\u041b\u0454\u044f\u0452\u043d\u043f\u0443\u0429\u043b\u046c\u0466\u0466\u045b\u0464\u045c\u0455\u0450\u0448\u0429\u044b\u0472\u0452\u0458\u0435\u046b\u044d\u0476\u043f\u047e\u0463\u044d", (byte)18, 68);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u00f4\u011c\u011e\u00d6\u0113\u00e0\u00f0\u00e3\u00ef\u0105\u0112\u0121\u0115\u011a\u0121\u00f8\u00e5\u00e9\u011a\u00ee\u011a\u00eb\u0130\u0127\u00e6\u0120\u0125\u00f1\u0120\u00f4\u0132\u00f9", (byte)18, 66);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0537\u0541\u0512\u0538\u054c\u051a\u0503\u0541\u0529\u0509\u053d\u053b\u0523\u0554\u0529\u054a\u0513\u0543\u050f\u052d\u0546\u0527\u051c\u0538\u054a\u0558\u0535\u0537\u053c\u055c\u0520\u0542", (byte)18, 70);
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u053b\u053a\u051f\u0522\u052b\u0547\u0507\u052b\u0530\u054d\u0510\u0516", (byte)18, 69);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u00eb\u0113\u00fa\u00fd\u0114\u00e9\u00f2\u00d5\u0122\u00f8\u00e3\u0119\u0106\u0120\u0103\u00fb\u011d\u012e\u00fa\u0128\u0131\u00fd\u012c\u010f\u012b\u0128\u00f4\u012b\u010d\u010b\u00f8\u0135", (byte)18, 66);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0456\u0450\u045b\u043e\u043d\u0469\u043c\u0435\u045e\u0468\u0427\u0443\u0461\u0463\u045f\u0454\u043c\u0470\u0477\u0445\u0455\u0477\u043e\u043f", (byte)18, 67);
                }
            }
        }
    }

    @Generated
    public long f() {
        return this.r;
    }

    @Generated
    public String toString() {
        return (String)\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.c("\u3e80", (int)a, (long)(b ^ d)) + this.af() + (String)\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.c("\u3e83", (int)(e & f), (long)g) + this.p() + (String)\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.c("\u3e86", (int)h, (long)i) + this.f() + (String)\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.c("\u3e89", (int)j, (long)(k ^ l)) + this.a() + (String)\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.c("\u3e8c", (int)(m & n), (long)o);
    }

    @Generated
    public Throwable a() {
        return this.a;
    }

    static {
        a = 0 >>> 113 | 0 << -113;
        b = Long.reverse(5093921060952159592L);
        d = Long.reverse(-6196953087261802496L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(-1);
        g = Long.reverse(-1391262402461354648L);
        h = Integer.reverse(0x40000000);
        i = Long.reverse(-1391262402461354648L);
        j = Integer.reverse(-1073741824);
        k = Long.reverse(5093921060952159592L);
        l = Long.reverse(-6196953087261802496L);
        m = Integer.reverse(0x20000000);
        n = (-1 >>> 45 | -1 << ~45 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-1391262402461354648L);
        p = Integer.reverse(-1610612736);
        q = (0x50000000 >>> 220 | 0x50000000 << ~220 + 1) & 0xFFFFFFFF;
        a = new String[p];
        b = new String[q];
        \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.b();
    }

    @Generated
    public \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1(boolean bl, int n, long l, Throwable throwable) {
        this.W = bl;
        this.X = n;
        this.r = l;
        this.a = throwable;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0541\u0563\u0565\u0545\u0569\u0588\u0580\u0596\u0582\u0551\u058f\u0585\u0593\u058d\u0556\u057b\u059d\u059c\u0594\u059a\u0594\u0569", (byte)93, 70), \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u019c\u01a9\u01a8\u016b\u01ab\u01a7\u01a2\u01ab\u01b6\u01a5\u0172\u01b0\u01b4\u01ad\u01b0\u01b6\u0178\u04fc\u04eb\u0510\u050d\u050c\u050f\u04eb\u0518\u0509\u04f9\u04fa\u04f0\u0507\u0191", (byte)93, 66) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0506", (byte)93, 67) + methodType.toString(), exception);
        }
    }

    @Generated
    public int p() {
        return this.X;
    }

    public \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1(boolean bl, int n, long l) {
        this(bl, n, l, null);
    }

    @Generated
    public boolean af() {
        return this.W;
    }

    private static String a(int n, long l) {
        l ^= 0x55L;
        l ^= 0x7A0F4353D89C2B46L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(67 + 2), (byte)(68 + 15), (byte)(12 + 35), (byte)(32 + 35), (byte)(8 + 58), (byte)(19 + 48), (byte)(31 + 16), (byte)(48 + 32), (byte)(31 + 44), (byte)(18 + 49), (byte)(45 + 38), 53, (byte)(72 + 8), (byte)(84 + 13), (byte)(99 + 1), (byte)(56 + 44), (byte)(21 + 84), (byte)(70 + 40), (byte)(94 + 9)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(71 + 12)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u018c\u0199\u0198\u015b\u019b\u0197\u0192\u019b\u01a6\u0195\u0162\u01a0\u01a4\u019d\u01a0\u01a6\u0168\u04ec\u04db\u0500\u04fd\u04fc\u04ff\u04db\u0508\u04f9\u04e9\u04ea\u04e0\u04f7", (byte)85, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03a0\u03c4\u03c0\u03be\u03c0\u039b\u03c7\u03b7\u03a6\u03a6\u039b\u03b1.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

