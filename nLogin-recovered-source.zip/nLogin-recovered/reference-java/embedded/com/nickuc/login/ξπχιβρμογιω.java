/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.Location;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9 {
    private static long c;
    private static String[] a;
    private static int n;
    private static int l;
    private static String[] b;
    private static int a;
    private static int c;
    private static int h;
    private static int j;
    private static long m;
    private static int b;
    private static final \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2 a;
    private static int e;
    private static int k;
    private static int o;
    private static long f;
    private static long g;
    private static int d;
    private static int i;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive exception aggregation
     */
    public static Location a(String string) {
        try {
            if (string != null) {
                byte[] byArray = Base64.getDecoder().decode(string.getBytes(StandardCharsets.UTF_8));
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byArray);
                try {
                    Location location;
                    block11: {
                        DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
                        try {
                            location = a.a(dataInputStream);
                            if (Collections.singletonList(dataInputStream).get(h) == null) break block11;
                        }
                        catch (Throwable throwable) {
                            if (Collections.singletonList(dataInputStream).get(j) != null) {
                                dataInputStream.close();
                            }
                            throw throwable;
                        }
                        dataInputStream.close();
                    }
                    return location;
                }
                finally {
                    if (Collections.singletonList(byteArrayInputStream).get(i) != null) {
                        byteArrayInputStream.close();
                    }
                }
            }
            return null;
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.c("\u3e80", (int)l, (long)m), iOException);
        }
    }

    private static void b() {
        int n;
        c = 6502404894674115231L;
        long l = c ^ 0xFFE34964924C23A5L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(14 + 54), (byte)(58 + 11), (byte)(58 + 25), (byte)(36 + 11), (byte)(49 + 18), (byte)(29 + 37), 67, (byte)(22 + 25), (byte)(68 + 12), (byte)(50 + 25), (byte)(33 + 34), (byte)(13 + 70), (byte)(42 + 11), (byte)(19 + 61), (byte)(77 + 20), (byte)(12 + 88), (byte)(51 + 49), (byte)(32 + 73), (byte)(32 + 78), (byte)(94 + 9)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(67 + 1), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u00d9\u00f5\u00ca\u00c8\u010b\u00c3\u00c8\u00c5\u00fd\u00cf\u00e6\u00e9\u00ec\u0108\u00da\u00d7\u00f4\u00d8\u00fd\u00d9\u00e9\u00f9\u00db\u00f6\u00d6\u00f4\u0126\u0103\u00e1\u00f7\u00fa\u00fb\u0108\u00e8\u00ed\u00fe\u00e7\u010c\u011f\u0102\u00f1\u0105\u0112\u00fb", (byte)10, 66);
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u050c\u0528\u04fd\u04fb\u053e\u04f6\u04fb\u04f8\u0530\u0502\u051b\u0507\u0508\u0541\u0505\u0529\u0518\u053b\u0527\u051f\u0545\u0550\u054e\u054c\u0552\u0511\u0530\u0527\u0528\u0548\u0517\u0528\u054c\u0533\u0513\u0557\u0543\u054c\u055f\u0558\u0560\u0521\u0541\u052e", (byte)10, 70);
                    continue block7;
                }
                case 1: {
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u00d9\u00f5\u00ca\u00c8\u010b\u00c3\u00c8\u00c5\u00fd\u00cf\u00e6\u00e9\u00ec\u0108\u00da\u00d7\u00f4\u00d8\u00fd\u00d9\u00e9\u00f9\u00db\u00f6\u00d6\u00f4\u0126\u0103\u00e1\u00f7\u00fa\u00fb\u00fd\u010c\u0104\u012c\u012f\u0124\u0108\u0103\u011c\u00fd\u010a\u00fb", (byte)10, 65);
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u050c\u0528\u04fd\u04fb\u053e\u04f6\u04fb\u04f8\u0530\u0502\u051b\u0507\u0508\u0541\u0505\u0529\u0518\u053b\u0527\u051f\u0545\u0550\u054e\u054c\u0552\u0511\u0530\u0527\u0528\u0548\u0517\u0528\u0553\u0554\u053f\u052c\u0553\u0563\u0563\u0559\u053a\u0531\u0545\u052e", (byte)10, 69);
                    continue block7;
                }
                case 2: {
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u00e5\u00e5\u00c5\u00e3\u0100\u0109\u010d\u010a\u00e1\u00c7\u00cf\u0111\u0114\u0110\u0109\u0116\u0112\u00d5\u010d\u00d9\u010c\u00f9\u00e6\u00e7", (byte)10, 66);
                    continue block7;
                }
                case 4: {
                    \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00d6\u00e6\u0105\u0102\u00c2\u00cc\u00c4\u0100\u0114\u00e1\u00d6\u00e4\u00e8\u010f\u00d9\u0119\u0112\u00e6\u00f4\u0114\u00f9\u00ea\u00fd\u011d\u00db\u0106\u00fe\u00e0\u0128\u0128\u0101\u00f9", (byte)10, 66);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u053f\u0561\u0563\u0543\u0567\u0586\u057e\u0594\u0580\u054f\u058d\u0583\u0591\u058b\u0554\u0579\u059b\u059a\u0592\u0598\u0592\u0567", (byte)118, 68), \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u0595\u05a2\u05a1\u0564\u05a4\u05a0\u059b\u05a4\u05af\u059e\u056b\u05a9\u05ad\u05a6\u05a9\u05af\u0571\u0901\u0904\u090c\u08ff\u08f9\u0909\u0905\u0909\u08fe\u0905\u0916\u0588", (byte)118, 70) + string + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u01a5", (byte)118, 66) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x68L;
        l ^= 0xFFE34964924C23A5L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(13 + 56), 83, (byte)(34 + 13), (byte)(40 + 27), (byte)(36 + 30), (byte)(46 + 21), (byte)(36 + 11), (byte)(68 + 12), (byte)(18 + 57), (byte)(32 + 35), (byte)(76 + 7), (byte)(39 + 14), (byte)(6 + 74), (byte)(55 + 42), (byte)(68 + 32), 100, (byte)(16 + 89), (byte)(101 + 9), (byte)(36 + 67)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(22 + 46), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u047b\u0488\u0487\u044a\u048a\u0486\u0481\u048a\u0495\u0484\u0451\u048f\u0493\u048c\u048f\u0495\u0457\u07e7\u07ea\u07f2\u07e5\u07df\u07ef\u07eb\u07ef\u07e4\u07eb\u07fc", (byte)33, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2 a() {
        return a;
    }

    static {
        a = Integer.reverse(0);
        b = 0 >>> 211 | 0 << ~211 + 1;
        c = (0 >>> 177 | 0 << ~177 + 1) & 0xFFFFFFFF;
        d = (0 >>> 19 | 0 << ~19 + 1) & 0xFFFFFFFF;
        e = Integer.reverse(0);
        f = Long.reverse(-478521516972786598L);
        g = Long.reverse(0x1600000000000000L);
        h = 0 >>> 172 | 0 << -172;
        i = Integer.reverse(0);
        j = (0 >>> 89 | 0 << ~89 + 1) & 0xFFFFFFFF;
        k = 0 >>> 200 | 0 << ~200 + 1;
        l = Integer.reverse(Integer.MIN_VALUE);
        m = Long.reverse(-1199097457352065958L);
        n = Integer.reverse(0x40000000);
        o = Integer.reverse(0x40000000);
        a = new String[n];
        b = new String[o];
        \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.b();
        a = new \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive exception aggregation
     */
    public static String a(Location location) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                String string;
                block10: {
                    DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
                    try {
                        a.a(location, dataOutputStream);
                        string = new String(Base64.getEncoder().encode(byteArrayOutputStream.toByteArray()), StandardCharsets.UTF_8);
                        if (Collections.singletonList(dataOutputStream).get(a) == null) break block10;
                    }
                    catch (Throwable throwable) {
                        if (Collections.singletonList(dataOutputStream).get(c) != null) {
                            dataOutputStream.close();
                        }
                        throw throwable;
                    }
                    dataOutputStream.close();
                }
                return string;
            }
            finally {
                if (Collections.singletonList(byteArrayOutputStream).get(b) != null) {
                    byteArrayOutputStream.close();
                }
            }
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.c("\u3e80", (int)e, (long)(f ^ g)), iOException);
        }
    }
}

