/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8
implements \u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5 {
    protected final String cm;
    private static long e;
    private static int o;
    private static int p;
    private static long g;
    private static long h;
    private static int a;
    private static String[] b;
    private static int f;
    private static String[] a;
    private static int i;
    private static int b;
    private static int m;
    private static int j;
    private static long d;
    private static int q;
    private static int n;
    private static long c;
    private static long k;
    private static long l;

    private static void b() {
        int n;
        c = 3637993376777380919L;
        long l = c ^ 0xF02759B462886919L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(23 + 46), 83, 47, (byte)(42 + 25), (byte)(2 + 64), (byte)(51 + 16), (byte)(46 + 1), (byte)(13 + 67), (byte)(54 + 21), (byte)(24 + 43), (byte)(69 + 14), (byte)(35 + 18), (byte)(66 + 14), (byte)(65 + 32), (byte)(44 + 56), (byte)(76 + 24), (byte)(64 + 41), (byte)(66 + 44), (byte)(60 + 43)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(61 + 8), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0173\u016c\u016f\u0153\u0176\u0150\u0166\u0145\u0168\u0160\u0149\u014f", (byte)68, 65);
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u04b2\u04c4\u04d3\u04b4\u04f9\u04d1\u04ff\u04cd\u04ee\u04d6\u04fa\u04c9", (byte)68, 67);
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0534\u0543\u057b\u057d\u054f\u0549\u0537\u053d\u0578\u053c\u0557\u0548", (byte)68, 69);
                    continue block7;
                }
                case 1: {
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0551\u0566\u056b\u057b\u0567\u0556\u0555\u057b\u057e\u0553\u054b\u0548", (byte)68, 70);
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0176\u0182\u0151\u0176\u0177\u0145\u0172\u0140\u0181\u0149\u0145\u014f", (byte)68, 66);
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[2] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u04b6\u04c8\u04f6\u04f1\u04f3\u04c9\u04f6\u0501\u04cb\u04cb\u0502\u04c9", (byte)68, 68);
                    continue block7;
                }
                case 2: {
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u04c8\u04e6\u04e8\u04dc\u04ed\u04e7\u04f0\u04ca\u04f6\u04f6\u04cd\u04c0\u04ef\u0501\u0501\u04d9\u04e2\u04f4\u04f7\u04ee\u04ec\u04d9\u04da\u04c8\u0510\u04ee\u04f0\u04f4\u0514\u050d\u04f6\u0516", (byte)68, 67);
                    continue block7;
                }
                case 4: {
                    \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056f\u0553\u0531\u0566\u0553\u0530\u054b\u053d\u0541\u055f\u053e\u0548", (byte)68, 70);
                }
            }
        }
    }

    @Override
    public boolean v(String string) {
        return string.contains((CharSequence)\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.c("\u3e80", (int)b, (long)(d ^ e)));
    }

    @Generated
    protected \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8(String string) {
        this.cm = string;
    }

    @Override
    public boolean i(String string, String string2) {
        return a != 0;
    }

    static {
        a = 0 >>> 139 | 0 << -139;
        b = Integer.reverse(0);
        d = Long.reverse(-1430930400598999476L);
        e = Long.reverse(-8070450532247928832L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-1430930400598999476L);
        h = Long.reverse(-8070450532247928832L);
        i = (0x8000000 >>> 123 | 0x8000000 << ~123 + 1) & 0xFFFFFFFF;
        j = Integer.reverse(0x40000000);
        k = Long.reverse(-1430930400598999476L);
        l = Long.reverse(-8070450532247928832L);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Integer.reverse(0);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(-1073741824);
        q = (0x300000 >>> 116 | 0x300000 << -116) & 0xFFFFFFFF;
        a = new String[p];
        b = new String[q];
        \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u012f\u0151\u0153\u0133\u0157\u0176\u016e\u0184\u0170\u013f\u017d\u0173\u0181\u017b\u0144\u0169\u018b\u018a\u0182\u0188\u0182\u0157", (byte)68, 66), \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0563\u0570\u056f\u0532\u0572\u056e\u0569\u0572\u057d\u056c\u0539\u0577\u057b\u0574\u0577\u057d\u053f\u08d1\u08cf\u08d3\u08da\u08c9\u08d1\u08b2\u08d8\u08d6\u08e2\u0555", (byte)68, 70) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u053a", (byte)68, 69) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 9L;
        l ^= 0xF02759B462886919L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(23 + 45), (byte)(53 + 16), (byte)(80 + 3), (byte)(8 + 39), (byte)(35 + 32), 66, (byte)(20 + 47), (byte)(31 + 16), (byte)(53 + 27), (byte)(9 + 66), (byte)(17 + 50), (byte)(14 + 69), (byte)(44 + 9), (byte)(16 + 64), (byte)(17 + 80), 100, (byte)(83 + 17), (byte)(20 + 85), (byte)(77 + 33), (byte)(99 + 4)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(56 + 12), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0535\u0542\u0541\u0504\u0544\u0540\u053b\u0544\u054f\u053e\u050b\u0549\u054d\u0546\u0549\u054f\u0511\u08a3\u08a1\u08a5\u08ac\u089b\u08a3\u0884\u08aa\u08a8\u08b4", (byte)22, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public String w(String string) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(this.cm);
            messageDigest.reset();
            messageDigest.update(string.getBytes());
            byte[] byArray = messageDigest.digest();
            Object[] objectArray = new Object[m];
            objectArray[\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.n] = new BigInteger(o, byArray);
            return String.format((String)\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.c("\u3e80", (int)f, (long)(g ^ h)) + (byArray.length << i) + (String)\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8.c("\u3e83", (int)j, (long)(k ^ l)), objectArray);
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new RuntimeException(noSuchAlgorithmException);
        }
    }
}

