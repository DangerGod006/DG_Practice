/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.md_5.bungee.api.CommandSender
 *  net.md_5.bungee.api.ProxyServer
 *  net.md_5.bungee.api.chat.TextComponent
 */
package com.nickuc.login;

import com.nickuc.login.\u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8;
import lombok.Generated;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03b3\u0394\u03b9\u03a0\u03a9\u03b6\u03b9
implements \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 {
    private static int b;
    private final CommandSender a;
    private static int c;
    private final ProxyServer b;
    private static int d;
    private static int a;

    @Generated
    private \u03a0\u03b3\u0394\u03b9\u03a0\u03a9\u03b6\u03b9(ProxyServer proxyServer, CommandSender commandSender) {
        this.b = proxyServer;
        this.a = commandSender;
    }

    @Override
    public void k(String string) {
        this.a.sendMessage(TextComponent.fromLegacyText((String)string));
    }

    @Override
    public String getName() {
        return this.a.getName();
    }

    static {
        a = Integer.reverse(0x40000000);
        b = Integer.reverse(0);
        c = Integer.reverse(-201326592);
        d = 8192 >>> 237 | 8192 << ~237 + 1;
    }

    public static \u03a0\u03b3\u0394\u03b9\u03a0\u03a9\u03b6\u03b9 a(ProxyServer proxyServer, CommandSender commandSender) {
        return new \u03a0\u03b3\u0394\u03b9\u03a0\u03a9\u03b6\u03b9(proxyServer, commandSender);
    }

    @Override
    public boolean i(String string) {
        return this.a.hasPermission(string);
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    @Override
    public void l(String string) {
        if (string.length() >= a && string.charAt(b) == c) {
            string = string.substring(d);
        }
        this.b.getPluginManager().dispatchCommand(this.a, string);
    }
}

