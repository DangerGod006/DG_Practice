/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.md_5.bungee.api.plugin.Plugin
 */
package com.nickuc.login;

import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import lombok.Generated;
import net.md_5.bungee.api.plugin.Plugin;

public class \u03a0\u03bc\u03c5\u039b\u03bb\u03b4\u03c0\u03b9
implements \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 {
    private final \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 c = new \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2();
    private final Plugin a;

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, TimeUnit timeUnit) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, consumer).a(this.a, l, timeUnit);
    }

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Runnable runnable, long l, TimeUnit timeUnit) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, runnable).a(this.a, l, timeUnit);
    }

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, consumer).a(this.a);
    }

    @Generated
    public \u03a0\u03bc\u03c5\u039b\u03bb\u03b4\u03c0\u03b9(Plugin plugin) {
        this.a = plugin;
    }

    @Override
    public void Y() {
        this.a.getProxy().getScheduler().cancel(this.a);
    }

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Runnable runnable) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, runnable).a(this.a);
    }

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Runnable runnable, long l, long l2, TimeUnit timeUnit) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, runnable).a(this.a, l, l2, timeUnit);
    }

    @Override
    public \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a() {
        return this.c;
    }

    @Override
    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, long l2, TimeUnit timeUnit) {
        return new \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(this.c, consumer).a(this.a, l, l2, timeUnit);
    }
}

