/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityAirChangeEvent
 *  org.bukkit.event.entity.EntityEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityAirChangeEvent;
import org.bukkit.event.entity.EntityEvent;

public class \u03be\u03c6\u03c2\u03b7\u03b2\u03c2\u03a6\u0393\u03b8\u03b2\u03c6\u03b5\u03bc\u03b1
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private final \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 d;
    private static int a = 4 >>> 66 | 4 << ~66 + 1;

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(EntityAirChangeEvent entityAirChangeEvent) {
        if (this.d.a((EntityEvent)entityAirChangeEvent)) {
            entityAirChangeEvent.setCancelled(a != 0);
        }
    }

    @Generated
    public \u03be\u03c6\u03c2\u03b7\u03b2\u03c2\u03a6\u0393\u03b8\u03b2\u03c6\u03b5\u03bc\u03b1(\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52) {
        this.d = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52;
    }
}

