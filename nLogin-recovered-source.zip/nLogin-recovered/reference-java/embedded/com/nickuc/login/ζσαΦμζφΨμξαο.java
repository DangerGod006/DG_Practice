/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.server.TabCompleteEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.server.TabCompleteEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static long b;
    private static long c;
    private static int o;
    private static int l;
    private static String[] a;
    private static long i;
    private static long v;
    private static int a;
    private static int w;
    private static int g;
    private static long r;
    private static int e;
    private static int z;
    private static int y;
    private static long h;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 h;
    private static int x;
    private static int s;
    private static int j;
    private static long d;
    private static int t;
    private static String[] b;
    private static int m;
    private static int ab;
    private static long q;
    private static long u;
    private static long f;
    private static int aa;
    private static int n;
    private static int p;
    private static int k;

    static {
        a = Integer.reverse(0);
        b = Long.reverse(1775176098274178350L);
        d = Long.reverse(0x5E00000000000000L);
        e = (128 >>> 39 | 128 << ~39 + 1) & 0xFFFFFFFF;
        f = Long.reverse(5089825424018863406L);
        g = 0x10000000 >>> 155 | 0x10000000 << -155;
        h = Long.reverse(1775176098274178350L);
        i = Long.reverse(0x5E00000000000000L);
        j = (65536 >>> 208 | 65536 << -208) & 0xFFFFFFFF;
        k = 0 >>> 16 | 0 << ~16 + 1;
        l = Integer.reverse(0);
        m = 0 >>> 250 | 0 << ~250 + 1;
        n = Integer.reverse(-201326592);
        o = Integer.reverse(0);
        p = (-2147483647 >>> 127 | -2147483647 << -127) & 0xFFFFFFFF;
        q = Long.reverse(1775176098274178350L);
        r = Long.reverse(0x5E00000000000000L);
        s = Integer.reverse(0);
        t = Integer.reverse(0x20000000);
        u = Long.reverse(1775176098274178350L);
        v = Long.reverse(0x5E00000000000000L);
        w = Integer.reverse(Integer.MIN_VALUE);
        x = Integer.reverse(0);
        y = Integer.reverse(Integer.MIN_VALUE);
        z = Integer.reverse(0);
        aa = Integer.reverse(-1610612736);
        ab = Integer.reverse(-1610612736);
        a = new String[aa];
        b = new String[ab];
        \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b();
    }

    @Generated
    public \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.h = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u018b\u01ad\u01af\u018f\u01b3\u01d2\u01ca\u01e0\u01cc\u019b\u01d9\u01cf\u01dd\u01d7\u01a0\u01c5\u01e7\u01e6\u01de\u01e4\u01de\u01b3", (byte)114, 65), \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u01c6\u01d3\u01d2\u0195\u01d5\u01d1\u01cc\u01d5\u01e0\u01cf\u019c\u01da\u01de\u01d7\u01da\u01e0\u01a2\u052a\u0538\u0527\u051d\u0534\u052f\u0540\u0523\u0538\u053b\u052f\u053e\u01ba", (byte)114, 66) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0545", (byte)114, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 8407841110554920216L;
        long l = c ^ 0x36E7FA0484912C83L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(53 + 16), (byte)(17 + 66), (byte)(33 + 14), 67, (byte)(31 + 35), (byte)(63 + 4), (byte)(42 + 5), (byte)(66 + 14), 75, (byte)(24 + 43), (byte)(55 + 28), (byte)(16 + 37), (byte)(68 + 12), (byte)(80 + 17), (byte)(32 + 68), (byte)(3 + 97), (byte)(45 + 60), (byte)(23 + 87), (byte)(56 + 47)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(27 + 42), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u017b\u0172\u017c\u0157\u016a\u018c\u01a2\u0173\u0163\u0180\u01a4\u016b", (byte)82, 65);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u057a\u0544\u055e\u055a\u0563\u0545\u0589\u0583\u058f\u055b\u0583\u055f\u0583\u0580\u058a\u0589\u0585\u0597\u0566\u0563\u0559\u0576\u058e\u0591\u057d\u0557\u059b\u0577\u0575\u059d\u055f\u05a4", (byte)82, 70);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[2] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0583\u0553\u0564\u0557\u0574\u057f\u055c\u0579\u054c\u057f\u058c\u0560\u0570\u0581\u0561\u0585\u056a\u0579\u0597\u0582\u0570\u058a\u0561\u0562", (byte)82, 69);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[3] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u016e\u0154\u0178\u016e\u01a0\u017e\u0194\u016b\u019c\u01a4\u0182\u016b", (byte)82, 65);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0188\u0198\u017d\u018d\u015d\u0197\u017f\u0176\u0175\u0191\u0186\u016b", (byte)82, 65);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u0173\u0190\u0168\u019b\u018d\u015e\u0194\u0172\u01a4\u017a\u0198\u016b", (byte)82, 66);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0517\u04e1\u04fb\u04f7\u0500\u04e2\u0526\u0520\u052c\u04f8\u0520\u04fc\u0520\u051d\u0527\u0526\u0522\u0534\u0503\u0500\u04f6\u0521\u04f6\u050c\u052f\u0517\u0534\u0540\u0536\u0512\u0531\u0539\u04fc\u053b\u04f8\u0543\u0543\u0500\u0501\u051c\u054d\u0527\u054c\u0513", (byte)82, 67);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0198\u0168\u0179\u016c\u0189\u0194\u0171\u018e\u0161\u0194\u01a1\u0183\u0179\u0160\u0169\u0180\u0196\u019d\u017c\u01a4\u0178\u0179\u0176\u0177", (byte)82, 65);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0583\u0563\u0552\u055e\u0576\u0545\u0555\u0549\u0588\u057a\u0571\u0556", (byte)82, 70);
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u04fb\u04e2\u04fc\u0515\u04e7\u0511\u050a\u0518\u04f8\u04ff\u0525\u0522\u0523\u0525\u04fd\u0504\u050a\u052d\u0516\u04f3\u0531\u0501\u04fe\u04ff", (byte)82, 67);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04e1\u04de\u04fd\u04f7\u0528\u051c\u0517\u0524\u04e2\u0502\u0504\u0525\u04f9\u0520\u0511\u0525\u0522\u0520\u04f0\u04ff\u0529\u0527\u04fe\u04ff", (byte)82, 67);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u0551\u0584\u0555\u0578\u056a\u0547\u053f\u058d\u055a\u0589\u0565\u0556", (byte)82, 70);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.LOW, ignoreCancelled=true)
    public void a(TabCompleteEvent tabCompleteEvent) {
        CommandSender commandSender = tabCompleteEvent.getSender();
        if (!(commandSender instanceof Player)) {
            return;
        }
        if (tabCompleteEvent.getCompletions().isEmpty()) {
            return;
        }
        if (!tabCompleteEvent.getBuffer().startsWith((String)\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.c("\u3e80", (int)a, (long)(b ^ d)))) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.h.b().a(commandSender);
        int n = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.i((String)\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.c("\u3e83", (int)e, (long)f)) || \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.i((String)\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.c("\u3e86", (int)g, (long)(h ^ i))) ? j : k;
        ArrayList<String> arrayList = new ArrayList<String>(tabCompleteEvent.getCompletions());
        arrayList.removeIf(arg_0 -> this.a(n != 0, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, arg_0));
        tabCompleteEvent.setCompletions(arrayList);
    }

    private /* synthetic */ boolean a(boolean bl, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, String string) {
        if (string.trim().isEmpty()) {
            return l != 0;
        }
        if (string.charAt(m) != n) {
            return o != 0;
        }
        String[] stringArray = string.split((String)\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.c("\u3e80", (int)p, (long)(q ^ r)));
        String string2 = stringArray[s].toLowerCase(Locale.ENGLISH);
        if (!bl && string2.equals(\u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.c("\u3e83", (int)t, (long)(u ^ v)))) {
            return w != 0;
        }
        if (this.h.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            return x != 0;
        }
        \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9 \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92 = this.h.a();
        return (\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92 == null || \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92.b(string2) ? y : z) != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x7AL;
        l ^= 0x36E7FA0484912C83L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(8 + 61), (byte)(51 + 32), (byte)(38 + 9), (byte)(8 + 59), (byte)(35 + 31), (byte)(66 + 1), 47, (byte)(28 + 52), (byte)(72 + 3), (byte)(26 + 41), (byte)(76 + 7), (byte)(50 + 3), (byte)(79 + 1), (byte)(40 + 57), (byte)(6 + 94), (byte)(20 + 80), (byte)(58 + 47), (byte)(99 + 11), (byte)(86 + 17)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(37 + 46)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u054f\u055c\u055b\u051e\u055e\u055a\u0555\u055e\u0569\u0558\u0525\u0563\u0567\u0560\u0563\u0569\u052b\u08b3\u08c1\u08b0\u08a6\u08bd\u08b8\u08c9\u08ac\u08c1\u08c4\u08b8\u08c7", (byte)48, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03c3\u03b1\u03a6\u03bc\u03b6\u03c6\u03a8\u03bc\u03be\u03b1\u03bf.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

