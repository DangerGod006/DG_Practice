/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7 {
    public Class<?> getPlayerClass();

    public boolean callEvent(Object var1);
}

