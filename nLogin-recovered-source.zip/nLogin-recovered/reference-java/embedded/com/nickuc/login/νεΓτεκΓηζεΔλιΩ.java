/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.LoaderBootstrap
 *  com.nickuc.login.loader.platform.VelocityLoader
 *  com.velocitypowered.api.proxy.ProxyServer
 *  com.velocitypowered.api.proxy.server.RegisteredServer
 */
package com.nickuc.login;

import com.nickuc.login.loader.LoaderBootstrap;
import com.nickuc.login.loader.platform.VelocityLoader;
import com.nickuc.login.\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393;
import com.nickuc.login.\u03a0\u03c6\u03c8\u03a8\u03a3\u03a0\u03bd\u039b\u03a0;
import com.nickuc.login.\u03a6\u03a6\u03b4\u0393\u03b8\u03a3\u03b7\u03b5\u03a6\u03c0\u03bf\u03c7\u03b8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394;
import com.nickuc.login.\u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9;
import com.nickuc.login.\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd;
import com.nickuc.login.\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9
implements LoaderBootstrap,
\u03a6\u03a6\u03b4\u0393\u03b8\u03a3\u03b7\u03b5\u03a6\u03c0\u03bf\u03c7\u03b8,
\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<VelocityLoader> {
    private static long p;
    private static int r;
    private final \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 c;
    private static int e;
    private final \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc a;
    private static int c;
    private static int b;
    private static int n;
    private static int i;
    private final VelocityLoader a;
    private static int g;
    private static int k;
    private static long m;
    private static int h;
    private static String[] b;
    private static int f;
    private static int l;
    private static int d;
    private static long c;
    private static String[] a;
    private static int q;
    private static long j;
    final \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb c;
    private static long o;
    private boolean Q;
    private static int a;

    @Override
    public File c() {
        return this.a.getDataDirectory();
    }

    @Override
    public /* synthetic */ \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 b() {
        return this.a();
    }

    public void enable() {
        this.c.av();
    }

    public VelocityLoader a() {
        return this.a;
    }

    @Override
    public boolean N() {
        return this.Q;
    }

    private static void b() {
        int n;
        c = -5306594483585466474L;
        long l = c ^ 0xDA5EBB9F89330E0EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(21 + 47), 69, (byte)(76 + 7), (byte)(43 + 4), (byte)(6 + 61), (byte)(7 + 59), (byte)(55 + 12), (byte)(33 + 14), (byte)(58 + 22), (byte)(57 + 18), 67, (byte)(80 + 3), (byte)(29 + 24), (byte)(23 + 57), (byte)(37 + 60), (byte)(7 + 93), (byte)(8 + 92), (byte)(9 + 96), (byte)(50 + 60), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), 69, (byte)(22 + 61)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0573\u0589\u0591\u0597\u056f\u059d\u055c\u0579\u05a0\u0574\u0572\u056b", (byte)103, 69);
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0594\u0586\u055e\u0579\u0590\u059b\u0578\u0580\u059a\u056d\u0594\u056b", (byte)103, 70);
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0532\u0520\u0520\u051d\u055c\u053c\u0548\u0542\u056c\u0545\u0545\u0532", (byte)103, 68);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u019a\u01a7\u01c2\u019d\u01ba\u01c9\u01cd\u01a3\u01ca\u01ba\u01ce\u0195", (byte)103, 65);
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u01c1\u01bf\u0185\u0195\u0185\u01c1\u01cc\u01c9\u01af\u01a5\u019f\u01aa\u019e\u01bb\u01ca\u01be\u01d2\u01d4\u01d9\u01cf\u01b5\u01a3\u01a0\u01a1", (byte)103, 66);
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0560\u054f\u0566\u055f\u0533\u0538\u0546\u0535\u054b\u055b\u0524\u0532", (byte)103, 68);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u019c\u01b8\u01a2\u0191\u01b6\u01a7\u01b9\u01a7\u01ad\u019f\u01bb\u01c7\u01a9\u01c8\u01a5\u01a0\u01d1\u01c8\u01a0\u01b4\u01a3\u01d9\u01a0\u01a1", (byte)103, 65);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u01a4\u019e\u01b7\u01a0\u01a6\u01bd\u0189\u01ce\u019c\u01cf\u01a1\u019c\u018c\u019f\u01a7\u01a4\u01ce\u0195\u01a3\u01d0\u01da\u0197\u01da\u01be\u01cb\u01d5\u01d2\u0197\u019b\u01cd\u0196\u01d7", (byte)103, 65);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u04ec\u050e\u0510\u04f0\u0514\u0533\u052b\u0541\u052d\u04fc\u053a\u0530\u053e\u0538\u0501\u0526\u0548\u0547\u053f\u0545\u053f\u0514", (byte)8, 70), \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u00f2\u00ff\u00fe\u00c1\u0101\u00fd\u00f8\u0101\u010c\u00fb\u00c8\u0106\u010a\u0103\u0106\u010c\u00ce\u045d\u0456\u0435\u0467\u0459\u045f\u0439\u045e\u045e\u045e\u043e\u0466\u0465\u0456\u00e8", (byte)8, 65) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u04fe", (byte)8, 69) + methodType.toString(), exception);
        }
    }

    @Override
    public String q() {
        return this.c.bn;
    }

    public ProxyServer a() {
        return this.a.getServer();
    }

    public \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9(VelocityLoader velocityLoader, String string, \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3 \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b32) {
        this.a = velocityLoader;
        this.a = new \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc(this);
        this.c = new \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb(string, velocityLoader.getVersion(), \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b32, this);
        this.c = new \u03a0\u03c6\u03c8\u03a8\u03a3\u03a0\u03bd\u039b\u03a0(velocityLoader.getLogger());
    }

    public void load() {
        this.Q = a;
        this.c.au();
    }

    static {
        a = 0x800000 >>> 247 | 0x800000 << -247;
        b = Integer.reverse(0);
        c = (0 >>> 164 | 0 << ~164 + 1) & 0xFFFFFFFF;
        d = (16 >>> 196 | 16 << ~196 + 1) & 0xFFFFFFFF;
        e = 0 >>> 90 | 0 << -90;
        f = Integer.reverse(0);
        g = Integer.reverse(Integer.MIN_VALUE);
        h = 0x20000000 >>> 29 | 0x20000000 << -29;
        i = Integer.reverse(0);
        j = Long.reverse(8357813820907641453L);
        k = 16 >>> 164 | 16 << ~164 + 1;
        l = (-1 >>> 176 | -1 << -176) & 0xFFFFFFFF;
        m = Long.reverse(8357813820907641453L);
        n = 2048 >>> 74 | 2048 << -74;
        o = Long.reverse(7637237880528362093L);
        p = Long.reverse(0x1A00000000000000L);
        q = Integer.reverse(-1073741824);
        r = Integer.reverse(-1073741824);
        a = new String[q];
        b = new String[r];
        \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.b();
    }

    @Override
    public void c() {
        this.Q = c;
    }

    @Override
    public \u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4 a() {
        return this.a;
    }

    @Override
    public String s() {
        return this.a.getVersion();
    }

    protected abstract \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a();

    protected void j() {
        if (this.c.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.c.a()).j();
        }
    }

    protected void T() {
        if (this.c.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.c.a()).T();
        }
    }

    @Override
    public /* synthetic */ Object b() {
        return this.a();
    }

    protected void O() {
        if (this.c.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.c.a()).O();
        }
    }

    @Override
    public Object a(int n) {
        switch (n) {
            case 0: {
                Collection collection = this.a().getAllServers();
                if (collection == null || collection.isEmpty()) break;
                StringBuilder stringBuilder = new StringBuilder();
                for (RegisteredServer registeredServer : collection) {
                    String string;
                    int n2;
                    InetSocketAddress inetSocketAddress = registeredServer.getServerInfo().getAddress();
                    if (!inetSocketAddress.isUnresolved()) {
                        InetAddress inetAddress = inetSocketAddress.getAddress();
                        n2 = inetAddress.isLoopbackAddress() || inetAddress.isAnyLocalAddress() || \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.a.b(inetAddress) || \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b.b(inetAddress) || \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c.b(inetAddress) ? d : e;
                        string = inetAddress.getHostAddress();
                    } else {
                        n2 = f;
                        string = inetSocketAddress.getHostName();
                        if (string == null) {
                            n2 = g;
                        } else {
                            try {
                                string = InetAddress.getByName(string).getHostAddress();
                            }
                            catch (UnknownHostException unknownHostException) {
                                n2 = h;
                            }
                        }
                    }
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append((String)\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.c("\u3e80", (int)i, (long)j));
                    }
                    if (n2 != 0) {
                        stringBuilder.append((String)\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.c("\u3e83", (int)(k & l), (long)m));
                    } else {
                        stringBuilder.append(string);
                    }
                    stringBuilder.append((String)\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.c("\u3e86", (int)\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.n, (long)(o ^ p)));
                    stringBuilder.append(inetSocketAddress.getPort());
                }
                return stringBuilder.toString();
            }
            case 1: {
                return this.a().getBoundAddress().getPort();
            }
        }
        return null;
    }

    @Override
    public \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb a() {
        return this.c;
    }

    protected void i() {
        if (this.c.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.c.a()).i();
        }
    }

    public \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394 a() {
        return (\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394)this.c.c();
    }

    @Override
    public \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 a() {
        return this.c;
    }

    public \u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9 a(boolean bl) {
        return (\u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9)this.c.b(bl);
    }

    private static String a(int n, long l) {
        l ^= 0x58L;
        l ^= 0xDA5EBB9F89330E0EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(25 + 44), (byte)(56 + 27), (byte)(23 + 24), (byte)(13 + 54), (byte)(33 + 33), (byte)(59 + 8), (byte)(39 + 8), (byte)(30 + 50), 75, (byte)(53 + 14), (byte)(69 + 14), (byte)(31 + 22), (byte)(8 + 72), (byte)(58 + 39), (byte)(15 + 85), (byte)(31 + 69), (byte)(104 + 1), (byte)(98 + 12), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(40 + 29), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0116\u0123\u0122\u00e5\u0125\u0121\u011c\u0125\u0130\u011f\u00ec\u012a\u012e\u0127\u012a\u0130\u00f2\u0481\u047a\u0459\u048b\u047d\u0483\u045d\u0482\u0482\u0482\u0462\u048a\u0489\u047a", (byte)26, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public void disable() {
        this.c.aw();
        this.Q = b;
    }

    @Override
    public /* synthetic */ \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b(boolean bl) {
        return this.a(bl);
    }

    public String toString() {
        return this.c.toString();
    }
}

