/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7
extends Enum<\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7> {
    public static final /* enum */ \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 a;
    public static final /* enum */ \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 b;
    private static final /* synthetic */ \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static long h;
    private static int i;
    private static int j;
    private static long k;
    private static long l;
    private static int m;

    private static String a(int n, long l) {
        l ^= 0x72L;
        l ^= 0xC5F3BF889DF4725DL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(22 + 47), (byte)(28 + 55), 47, (byte)(9 + 58), (byte)(53 + 13), (byte)(55 + 12), 47, (byte)(26 + 54), (byte)(27 + 48), (byte)(4 + 63), (byte)(69 + 14), (byte)(30 + 23), (byte)(8 + 72), (byte)(42 + 55), (byte)(3 + 97), (byte)(22 + 78), (byte)(101 + 4), (byte)(5 + 105), (byte)(69 + 34)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(24 + 59)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u04c0\u04cd\u04cc\u048f\u04cf\u04cb\u04c6\u04cf\u04da\u04c9\u0496\u04d4\u04d8\u04d1\u04d4\u04da\u049c\u0821\u0815\u0810\u0836\u0833\u0834\u0835\u0835\u082d", (byte)56, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[] values() {
        return (\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[])a.clone();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0509\u052b\u052d\u050d\u0531\u0550\u0548\u055e\u054a\u0519\u0557\u054d\u055b\u0555\u051e\u0543\u0565\u0564\u055c\u0562\u055c\u0531", (byte)100, 68), \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u01aa\u01b7\u01b6\u0179\u01b9\u01b5\u01b0\u01b9\u01c4\u01b3\u0180\u01be\u01c2\u01bb\u01be\u01c4\u0186\u050b\u04ff\u04fa\u0520\u051d\u051e\u051f\u051f\u0517\u019b", (byte)100, 66) + string + \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u055a", (byte)100, 70) + methodType.toString(), exception);
        }
    }

    private static /* synthetic */ \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[] a() {
        \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[] \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7Array = new \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7[a];
        \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7Array[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b] = a;
        \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7Array[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.c] = b;
        return \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7Array;
    }

    public static \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 valueOf(String string) {
        return Enum.valueOf(\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.class, string);
    }

    private static void b() {
        int n;
        c = 8535226561786485389L;
        long l = c ^ 0xC5F3BF889DF4725DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(19 + 50), (byte)(18 + 65), (byte)(39 + 8), (byte)(52 + 15), (byte)(39 + 27), (byte)(6 + 61), (byte)(11 + 36), (byte)(24 + 56), (byte)(21 + 54), (byte)(27 + 40), (byte)(48 + 35), (byte)(12 + 41), (byte)(26 + 54), (byte)(89 + 8), (byte)(13 + 87), (byte)(35 + 65), (byte)(2 + 103), 110, 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(4 + 65), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0567\u056b\u0597\u057a\u0597\u058d\u0555\u054f\u057d\u0578\u055d\u0589\u059a\u0559\u05a1\u057d\u0586\u0571\u05a5\u0594\u0581\u0583\u0570\u0571", (byte)120, 67);
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u01b2\u01c3\u01ea\u01c9\u01c9\u01db\u01c4\u01ba\u01bb\u01d2\u01e4\u01cf\u01d5\u01bd\u01f5\u01d6\u01eb\u01fa\u01d6\u01b5\u01fd\u01eb\u01c2\u01c3", (byte)120, 65);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u01b9\u01bd\u01e9\u01cc\u01e9\u01df\u01a7\u01a1\u01cf\u01ca\u01ae\u01bb\u01c9\u01f0\u01ac\u01e3\u01c7\u01d5\u01d9\u01cd\u01d3\u01d5\u01c2\u01c3", (byte)120, 65);
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0577\u0588\u05af\u058e\u058e\u05a0\u0589\u057f\u0580\u0597\u05ac\u0583\u0597\u0585\u0596\u0589\u0593\u05b9\u0590\u05b5\u0573\u05b0\u0587\u0588", (byte)120, 70);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0589\u0583\u058f\u0564\u058f\u0588\u059d\u0575\u0594\u056c\u057a\u0569\u0592\u055f\u059a\u059a\u059a\u0576\u0599\u05a6\u058b\u0583\u0570\u0571", (byte)120, 68);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01bd\u01a6\u01b9\u01bb\u01b9\u01c7\u01a8\u01e3\u01bb\u01e9\u01db\u01c1\u01f2\u01eb\u01ef\u01b4\u01f0\u01ce\u01d3\u01c6\u01ba\u01eb\u01c2\u01c3", (byte)120, 66);
                }
            }
        }
    }

    static {
        a = 0x8000000 >>> 186 | 0x8000000 << -186;
        b = Integer.reverse(0);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = 65536 >>> 15 | 65536 << -15;
        e = Integer.reverse(0x40000000);
        f = Integer.reverse(0);
        g = (-1 >>> 72 | -1 << ~72 + 1) & 0xFFFFFFFF;
        h = Long.reverse(-47073149007901074L);
        i = Integer.reverse(0);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(-5667565483966280082L);
        l = Long.reverse(0x4E00000000000000L);
        m = (128 >>> 39 | 128 << -39) & 0xFFFFFFFF;
        a = new String[d];
        b = new String[e];
        \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b();
        a = new \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7();
        b = new \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7();
        a = \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.a();
    }
}

