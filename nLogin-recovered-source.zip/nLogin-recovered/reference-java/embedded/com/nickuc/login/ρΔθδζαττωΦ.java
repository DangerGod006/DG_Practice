/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.event.bukkit.auth.request.LoginRequestEvent
 *  com.nickuc.login.api.event.internal.LockableEvent
 *  com.nickuc.login.api.event.internal.LockableNewActionEvent
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.api.event.bukkit.auth.request.LoginRequestEvent;
import com.nickuc.login.api.event.internal.LockableEvent;
import com.nickuc.login.api.event.internal.LockableNewActionEvent;
import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03b9\u03b2\u03b9\u03c8\u03ba\u03c9\u0393\u03b3;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u0394;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

public class \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6
extends \u03a8\u03b9\u03b2\u03b9\u03c8\u03ba\u03c9\u0393\u03b3 {
    private static int b = Integer.reverse(0);
    final /* synthetic */ \u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u0394 a;
    private static long f = Long.reverse(672140677574624022L);
    private static int g = Integer.reverse(Integer.MIN_VALUE);
    private static int i = Integer.reverse(Integer.MIN_VALUE);
    private static String[] c = new String[g];
    private static String[] d = new String[i];
    private static long e;

    static {
        \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.b();
    }

    public void lockableNewAction(LockableNewActionEvent<?> lockableNewActionEvent) {
        nLoginBukkit nLoginBukkit2 = (nLoginBukkit)((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)((Object)this.a.a)).c();
        nLoginBukkit2.callEvent(lockableNewActionEvent);
    }

    private static void b() {
        int n;
        e = 7548234913128368860L;
        long l = e ^ 0xFB59B5E19ADDE66DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(20 + 48), (byte)(5 + 64), (byte)(60 + 23), (byte)(46 + 1), (byte)(5 + 62), 66, 67, (byte)(31 + 16), (byte)(29 + 51), (byte)(19 + 56), (byte)(60 + 7), (byte)(8 + 75), (byte)(30 + 23), (byte)(70 + 10), (byte)(71 + 26), (byte)(74 + 26), (byte)(27 + 73), (byte)(54 + 51), (byte)(89 + 21), (byte)(76 + 27)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(20 + 49), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u053d\u053d\u04fd\u0531\u0505\u0535\u0501\u0531\u052a\u051f\u0507\u0528\u054b\u0509\u053d\u0527\u050d\u052a\u053f\u0523\u0522\u0545\u051c\u051d", (byte)92, 67);
                    continue block7;
                }
                case 1: {
                    \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.d[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u01ab\u01ab\u016b\u019f\u0173\u01a3\u016f\u019f\u0198\u018d\u0175\u01b0\u01b5\u018d\u0189\u0188\u01b7\u01ab\u01ba\u01c4\u01b0\u0182\u01ba\u018f\u01bd\u01c1\u01b8\u01b6\u01c0\u01a7\u01ae\u01a1", (byte)92, 65);
                    continue block7;
                }
                case 2: {
                    \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.d[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0530\u050f\u0541\u051d\u0514\u051b\u0508\u0516\u0533\u0528\u051b\u0528\u053e\u0506\u0510\u053f\u050f\u050d\u0511\u0522\u0557\u0555\u051c\u051d", (byte)92, 67);
                    continue block7;
                }
                case 4: {
                    \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.d[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0180\u0167\u016c\u01af\u01ac\u0193\u0180\u0177\u01a6\u01b4\u0196\u017f", (byte)92, 66);
                }
            }
        }
    }

    public void lockableEvent(LockableEvent lockableEvent, byte by, byte by2) {
        nLoginBukkit nLoginBukkit2 = (nLoginBukkit)((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)((Object)this.a.a)).c();
        if (by == 0) {
            LoginRequestEvent loginRequestEvent = (LoginRequestEvent)lockableEvent;
            Player player = loginRequestEvent.getPlayer();
            if (!player.isOnline()) {
                return;
            }
            switch (by2) {
                case 1: {
                    nLoginBukkit2.callEvent(loginRequestEvent);
                    break;
                }
                case 2: {
                    ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a.a)).b().a().b(((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)((Object)this.a.a)).b().a(player), loginRequestEvent.isCancelled());
                    break;
                }
                default: {
                    throw new IllegalArgumentException((String)\u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.c("\u3e80", (int)b, (long)f) + by);
                }
            }
        }
    }

    public \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6(\u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u0394 \u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u03942) {
        this.a = \u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u03942;
    }

    private static String a(int n, long l) {
        l ^= 0x4CL;
        l ^= 0xFB59B5E19ADDE66DL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(44 + 24), (byte)(55 + 14), (byte)(73 + 10), 47, (byte)(17 + 50), (byte)(6 + 60), (byte)(48 + 19), (byte)(22 + 25), (byte)(33 + 47), (byte)(43 + 32), 67, (byte)(69 + 14), (byte)(12 + 41), (byte)(13 + 67), (byte)(66 + 31), (byte)(34 + 66), (byte)(82 + 18), (byte)(20 + 85), (byte)(40 + 70), (byte)(71 + 32)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(13 + 56), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u056b\u0578\u0577\u053a\u057a\u0576\u0571\u057a\u0585\u0574\u0541\u057f\u0583\u057c\u057f\u0585\u0547\u08da\u08ae\u08d3\u08d0\u08d3\u08cf\u08e3\u08e4\u08ea\u08c8", (byte)76, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u053a\u055c\u055e\u053e\u0562\u0581\u0579\u058f\u057b\u054a\u0588\u057e\u058c\u0586\u054f\u0574\u0596\u0595\u058d\u0593\u058d\u0562", (byte)86, 69), \u03c1\u0394\u03b8\u03b4\u03b6\u03b1\u03c4\u03c4\u03c9\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u018e\u019b\u019a\u015d\u019d\u0199\u0194\u019d\u01a8\u0197\u0164\u01a2\u01a6\u019f\u01a2\u01a8\u016a\u04fd\u04d1\u04f6\u04f3\u04f6\u04f2\u0506\u0507\u050d\u04eb\u0180", (byte)86, 65) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0165", (byte)86, 65) + methodType.toString(), exception);
        }
    }
}

