/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0;
import com.nickuc.login.\u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7;
import com.nickuc.login.\u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b;
import com.nickuc.login.\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393
extends Enum<\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393>
implements \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 {
    public static final /* enum */ \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393 a;
    public static final int j;
    private static final \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 a;
    private final \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 a;
    private final Object b;
    private static final /* synthetic */ \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static long d;
    private static int e;
    private static int f;
    private static long g;
    private static long h;
    private static int i;
    private static int k;
    private static int l;
    private static long m;
    private static long n;
    private static int o;
    private static long p;
    private static long q;
    private static int r;
    private static int s;
    private static int t;
    private static int u;
    private static long v;
    private static int w;
    private static int x;
    private static long y;
    private static int z;
    private static long aa;
    private static long ab;
    private static int ac;
    private static long ad;
    private static long ae;
    private static int af;
    private static int ag;
    private static int ah;
    private static int ai;
    private static int aj;
    private static long ak;
    private static long al;
    private static int am;
    private static int an;
    private static int ao;
    private static int ap;
    private static int aq;
    private static int ar;
    private static int as;
    private static int at;
    private static int au;
    private static int av;
    private static int aw;
    private static int ax;
    private static int ay;
    private static long az;
    private static int ba;
    private static int bb;
    private static long bc;
    private static int bd;
    private static int be;
    private static long bf;

    public static \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393 valueOf(String string) {
        return Enum.valueOf(\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.class, string);
    }

    @Override
    public int a() {
        return this.ordinal();
    }

    private \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393(String string2, Object object) {
        String[] stringArray = new String[a];
        stringArray[\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b] = string2;
        this.a = \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4.a(stringArray);
        this.b = object;
    }

    public static boolean j() {
        return ((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e80", (int)c, (long)d)).equals(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.b.a(new Object[e]));
    }

    private static /* synthetic */ \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[] a() {
        \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[] \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393Array = new \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[as];
        \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393Array[\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.at] = a;
        return \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393Array;
    }

    private static void b() {
        int n;
        c = -932372931710296230L;
        long l = c ^ 0x15D03DFB6CA29E1CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(27 + 41), (byte)(47 + 22), 83, (byte)(46 + 1), (byte)(47 + 20), (byte)(54 + 12), (byte)(66 + 1), (byte)(46 + 1), (byte)(58 + 22), (byte)(27 + 48), (byte)(47 + 20), (byte)(48 + 35), (byte)(46 + 7), (byte)(15 + 65), (byte)(6 + 91), (byte)(43 + 57), (byte)(38 + 62), 105, (byte)(66 + 44), (byte)(25 + 78)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(46 + 23), (byte)(13 + 70)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0135\u0125\u0126\u0115\u013b\u0132\u0131\u014a\u014e\u013d\u014c\u0141\u0116\u0155\u0138\u0134\u015c\u015c\u0159\u0156\u0166\u0135\u0132\u0133", (byte)48, 66);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u0111\u014c\u0136\u0114\u0128\u014b\u011c\u0137\u012b\u0130\u0163\u013b\u012e\u0153\u0121\u0160\u013e\u0161\u0166\u013c\u0128\u015d\u0162\u015f\u0164\u015b\u012d\u016e\u0130\u0146\u0130\u0166\u0131\u0138\u014f\u012d\u0132\u012f\u0172\u0172\u0148\u0155\u0170\u016f\u0172\u017b\u013f\u0159\u0185\u015e\u0179\u0163\u017d\u018b\u0166\u017c\u0184\u015e\u0151\u018c\u0193\u0180\u0152\u018e", (byte)48, 65);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0536\u054e\u0544\u0531\u0534\u054a\u055b\u0526\u0556\u054a\u054c\u0549\u0559\u054e\u0560\u054e\u054d\u0534\u0567\u0550\u052f\u0568\u0572\u0571\u0574\u0549\u0547\u054a\u0553\u0580\u0560\u053b\u055d\u056f\u0572\u0540\u0545\u055d\u057c\u0585\u055b\u055e\u056f\u0554", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0122\u0127\u013a\u014f\u012a\u0135\u0139\u0131\u011c\u015e\u013a\u0127", (byte)48, 66);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0517\u053a\u0524\u051f\u055b\u0527\u052b\u0561\u054a\u0520\u053b\u0545\u0544\u056b\u0573\u0572\u0575\u0554\u0537\u0535\u0558\u0542\u053f\u0540", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[5] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u04ba\u0489\u0499\u0492\u0482\u0482\u04bc\u049c\u0494\u048f\u04a8\u048d", (byte)48, 68);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[6] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0542\u0532\u0533\u0522\u0548\u053f\u053e\u0557\u055b\u054a\u055b\u0561\u056f\u0524\u0532\u0561\u0562\u056a\u056e\u0556\u0574\u0578\u053f\u0540", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u055c\u053e\u0527\u0566\u0524\u0527\u0523\u0569\u052c\u0528\u054b\u0534", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u055d\u055b\u0521\u0568\u0553\u051c\u0526\u0569\u054a\u055c\u0544\u054f\u0561\u053f\u053d\u0544\u0570\u052c\u0555\u0572\u0563\u0543\u0545\u054f\u055c\u0546\u0573\u055c\u0574\u055c\u0560\u0556\u0562\u057f\u055a\u0570\u0575\u0547\u0586\u058c\u056c\u0545\u0589\u0568\u057c\u0570\u057d\u0594\u057e\u0552\u0572\u0564\u0591\u0558\u0571\u0585\u0555\u057d\u055f\u056d\u058e\u055c\u0596\u0581\u0574\u05a7\u0580\u0594\u0576\u0583\u059c\u0562\u058d\u05a1\u058f\u059f\u058c\u05a5\u056e\u0582\u056b\u0575\u0588\u0591\u05a5\u05b8\u057f\u0580", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[9] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u012e\u0129\u0146\u0148\u0156\u012c\u0129\u0111\u012f\u014d\u0137\u011b\u0157\u015a\u0123\u0123\u0168\u0140\u0128\u015f\u0141\u0167\u015c\u016a\u012f\u014a\u015c\u016d\u012b\u015e\u0176\u0153", (byte)48, 66);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[10] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0538\u0565\u053a\u0542\u0544\u055c\u0555\u054c\u054b\u0562\u054a\u055d\u052c\u056c\u0549\u0545\u052f\u0533\u0566\u0557\u0558\u054b\u057b\u0554\u0534\u0539\u0573\u0561\u0574\u0580\u057c\u053c", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[11] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0487\u0478\u04a0\u04ba\u04ab\u0490\u04b6\u047f\u0494\u04a7\u0488\u049a\u049d\u04bf\u04b6\u04c7\u04c2\u04a1\u04a9\u04ac\u04c1\u049b\u0498\u0499", (byte)48, 67);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0135\u0125\u0126\u0115\u013b\u0132\u0131\u014a\u014e\u013d\u014f\u0162\u015b\u0165\u015b\u0155\u0151\u0166\u0147\u013f\u015d\u014b\u0129\u015d\u015d\u0127\u014b\u013b\u0162\u0167\u0174\u0153", (byte)48, 65);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u0477\u04b2\u049c\u047a\u048e\u04b1\u0482\u049d\u0491\u0496\u04c9\u04a1\u0494\u04b9\u0487\u04c6\u04a4\u04c7\u04cc\u04a2\u048e\u04c3\u04c8\u04c5\u04ca\u04c1\u0493\u04d4\u0496\u04ac\u0496\u04cc\u0497\u049e\u04b5\u0493\u0498\u0495\u04d8\u04d8\u04ae\u04bb\u04d6\u04d5\u04d8\u04e1\u04a5\u04bf\u04eb\u04c4\u04df\u04c9\u04e3\u04f2\u04dd\u04d6\u04f0\u04d4\u04d0\u04c3\u04c9\u04ba\u04f3\u04b7", (byte)48, 67);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0536\u054e\u0544\u0531\u0534\u054a\u055b\u0526\u0556\u054a\u054c\u0549\u0559\u054e\u0560\u054e\u054d\u0534\u0567\u0550\u052f\u0568\u0572\u0571\u0574\u0549\u0547\u054a\u0553\u0580\u0560\u053b\u0573\u0556\u0583\u0583\u0577\u0546\u055d\u0568\u055b\u0549\u0589\u0554", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[3] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0564\u0560\u051f\u0524\u055f\u0524\u055d\u055f\u0537\u0558\u052c\u052d\u054f\u0552\u0525\u053c\u054d\u052c\u0562\u0547\u054e\u0552\u053f\u0540", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[4] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0517\u053a\u0524\u051f\u055b\u0527\u052b\u0561\u054a\u0520\u053d\u054e\u0563\u0572\u056d\u056a\u0541\u0577\u0563\u052f\u0551\u0575\u057c\u057a\u0556\u0573\u055a\u0578\u0533\u055a\u0550\u055d", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[5] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0158\u012c\u0139\u012f\u014f\u014a\u013f\u0135\u012b\u015c\u0121\u0127", (byte)48, 66);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u049b\u048b\u048c\u047b\u04a1\u0498\u0497\u04b0\u04b4\u04a3\u04b5\u0492\u0486\u04b6\u0483\u049e\u04a1\u04a4\u048a\u04ad\u049d\u04c1\u0498\u0499", (byte)48, 68);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[7] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u054e\u0566\u053f\u053b\u053a\u0568\u0563\u0540\u0544\u0540\u0566\u055a\u0550\u0531\u0566\u053f\u0541\u0547\u056e\u0535\u0567\u0578\u053f\u0540", (byte)48, 69);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[8] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0150\u014e\u0114\u015b\u0146\u010f\u0119\u015c\u013d\u014f\u0137\u0142\u0154\u0132\u0130\u0137\u0163\u011f\u0148\u0165\u0156\u0136\u0138\u0142\u014f\u0139\u0166\u014f\u0167\u014f\u0153\u0149\u0155\u0172\u014d\u0163\u0168\u013a\u0179\u017f\u015f\u0138\u017c\u015b\u016f\u0163\u0170\u0187\u0171\u0145\u0165\u0157\u0184\u014b\u0164\u0178\u0148\u0170\u0152\u0160\u0181\u014f\u0189\u0174\u0167\u019a\u0173\u0187\u0169\u0176\u018f\u0155\u0180\u0194\u0183\u015d\u015b\u0157\u0158\u019e\u0166\u017f\u0183\u01a2\u0187\u01ab\u0172\u0173", (byte)48, 66);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[9] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u053b\u0536\u0553\u0555\u0563\u0539\u0536\u051e\u053c\u055a\u0544\u0528\u0564\u0567\u0530\u0530\u0575\u054d\u0535\u056c\u054e\u0575\u0546\u0537\u0533\u0537\u055e\u055f\u0557\u055a\u057c\u057b", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0538\u0565\u053a\u0542\u0544\u055c\u0555\u054c\u054b\u0562\u054a\u055d\u052c\u056c\u0549\u0545\u052f\u0533\u0566\u0557\u0558\u054d\u0570\u0544\u0578\u056e\u057e\u0557\u0552\u055d\u0579\u057b", (byte)48, 70);
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[11] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0487\u0478\u04a0\u04ba\u04ab\u0490\u04b6\u047f\u0494\u04a7\u0488\u0489\u04cb\u0493\u0494\u049e\u04ae\u04bd\u04b9\u04ac\u04b1\u04c1\u0498\u0499", (byte)48, 67);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0487\u04ad\u04ae\u049d\u048f\u04b0\u049c\u0495\u0486\u0484\u04a4\u0485\u049d\u04aa\u04c2\u04cb\u04c1\u0498\u04cc\u04aa\u0491\u049b\u0498\u0499", (byte)48, 68);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u04be\u04ba\u04ad\u04b6\u04be\u0496\u0481\u04b2\u0495\u04b7\u04b8\u04c9\u047c\u0493\u0485\u04bc\u04b9\u04b9\u04bc\u0499\u04c7\u049b\u0498\u0499", (byte)48, 68);
                }
            }
        }
    }

    @Override
    public Object a() {
        return this.b;
    }

    public static \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[] values() {
        return (\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393[])a.clone();
    }

    public static boolean a(nLoginBukkit nLoginBukkit2, boolean bl) {
        \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b2 = new \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b();
        \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22 = nLoginBukkit2.a();
        if (!\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.r()) {
            \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.o((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e80", (int)f, (long)(g ^ h)));
        } else if (!bl && !\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.X()) {
            return i != 0;
        }
        if (!\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.Z()) {
            return k != 0;
        }
        \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.values(), a, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22);
        \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.a(nLoginBukkit2.a());
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e83", (int)l, (long)(m ^ n)) + \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b2.h() + (String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e86", (int)o, (long)(p ^ q)), new Object[r]);
        return s != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x25L;
        l ^= 0x15D03DFB6CA29E1CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(52 + 17), (byte)(65 + 18), (byte)(31 + 16), (byte)(59 + 8), (byte)(9 + 57), (byte)(13 + 54), (byte)(6 + 41), (byte)(62 + 18), 75, (byte)(24 + 43), (byte)(75 + 8), (byte)(19 + 34), (byte)(34 + 46), (byte)(42 + 55), 100, (byte)(88 + 12), (byte)(94 + 11), (byte)(68 + 42), (byte)(58 + 45)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(77 + 6)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u00f2\u00ff\u00fe\u00c1\u0101\u00fd\u00f8\u0101\u010c\u00fb\u00c8\u0106\u010a\u0103\u0106\u010c\u00ce\u0454\u0469\u0468\u044b\u0467\u046d\u045b\u0462\u043b", (byte)8, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        File file = new File(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.c(), (String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e80", (int)(t & u), (long)v));
        if (!file.exists()) {
            \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2 \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22 = \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.a();
            if (\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22 != null) {
                Object object = \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22.af();
                if (\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22 == \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.d) {
                    object = \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e83", (int)(w & x), (long)y);
                }
                \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.b, (Object)((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e86", (int)z, (long)(aa ^ ab)) + (String)object + (String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e89", (int)ac, (long)(ad ^ ae))));
            }
        } else {
            try (InputStream inputStream = Files.newInputStream(file.toPath(), new OpenOption[af]);){
                DataInputStream dataInputStream = new DataInputStream(inputStream);
                if (dataInputStream.readUnsignedShort() != ag) {
                    return;
                }
                int n = dataInputStream.readUnsignedShort();
                block14: for (int i = ah; i < n; ++i) {
                    String string = dataInputStream.readUTF();
                    \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2 \u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22 = Arrays.stream(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.values()).filter(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2 -> string.equals(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h.a()[ar])).findFirst().orElse(null);
                    if (\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22 == null) continue;
                    switch (dataInputStream.readByte()) {
                        case 0: {
                            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22, \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h, (Object)dataInputStream.readUTF());
                            continue block14;
                        }
                        case 1: {
                            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22, \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h, dataInputStream.readBoolean());
                            continue block14;
                        }
                        case 2: {
                            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22, \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h, dataInputStream.readInt());
                            continue block14;
                        }
                        case 3: {
                            int n2 = dataInputStream.readInt();
                            String[] stringArray = new String[n2];
                            for (int j = ai; j < n2; ++j) {
                                stringArray[j] = dataInputStream.readUTF();
                            }
                            \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<String> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(stringArray);
                            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b22, \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02);
                        }
                    }
                }
            }
            catch (IOException iOException) {
                Object[] objectArray = new Object[am];
                objectArray[\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.an] = ao;
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e8c", (int)aj, (long)(ak ^ al)), iOException, objectArray);
            }
        }
        \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.c(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, ap != 0);
        \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.e(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, aq != 0);
    }

    @Override
    public \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 a() {
        return a;
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 0 >>> 106 | 0 << -106;
        c = 0 >>> 74 | 0 << ~74 + 1;
        d = Long.reverse(-73204435067473713L);
        e = 0 >>> 241 | 0 << ~241 + 1;
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(6556094216421896399L);
        h = Long.reverse(-6629298651489370112L);
        i = (0 >>> 165 | 0 << ~165 + 1) & 0xFFFFFFFF;
        k = (0 >>> 45 | 0 << ~45 + 1) & 0xFFFFFFFF;
        l = Integer.reverse(0x40000000);
        m = Long.reverse(6556094216421896399L);
        n = Long.reverse(-6629298651489370112L);
        o = 0x18000000 >>> 27 | 0x18000000 << -27;
        p = Long.reverse(6556094216421896399L);
        q = Long.reverse(-6629298651489370112L);
        r = Integer.reverse(0);
        s = Integer.reverse(Integer.MIN_VALUE);
        t = (262144 >>> 144 | 262144 << -144) & 0xFFFFFFFF;
        u = (-1 >>> 200 | -1 << ~200 + 1) & 0xFFFFFFFF;
        v = Long.reverse(-73204435067473713L);
        w = Integer.reverse(-1610612736);
        x = (-1 >>> 91 | -1 << ~91 + 1) & 0xFFFFFFFF;
        y = Long.reverse(-73204435067473713L);
        z = (384 >>> 102 | 384 << ~102 + 1) & 0xFFFFFFFF;
        aa = Long.reverse(6556094216421896399L);
        ab = Long.reverse(-6629298651489370112L);
        ac = 0xE00000 >>> 149 | 0xE00000 << -149;
        ad = Long.reverse(6556094216421896399L);
        ae = Long.reverse(-6629298651489370112L);
        af = 0 >>> 41 | 0 << ~41 + 1;
        ag = (16384 >>> 172 | 16384 << ~172 + 1) & 0xFFFFFFFF;
        ah = Integer.reverse(0);
        ai = Integer.reverse(0);
        aj = 0x800000 >>> 20 | 0x800000 << ~20 + 1;
        ak = Long.reverse(6556094216421896399L);
        al = Long.reverse(-6629298651489370112L);
        am = Integer.reverse(Integer.MIN_VALUE);
        an = (0 >>> 86 | 0 << ~86 + 1) & 0xFFFFFFFF;
        ao = Integer.reverse(0x20000000);
        ap = (16384 >>> 14 | 16384 << ~14 + 1) & 0xFFFFFFFF;
        aq = 65536 >>> 80 | 65536 << -80;
        ar = (0 >>> 14 | 0 << ~14 + 1) & 0xFFFFFFFF;
        as = Integer.reverse(Integer.MIN_VALUE);
        at = 0 >>> 153 | 0 << ~153 + 1;
        au = 786432 >>> 112 | 786432 << -112;
        av = Integer.reverse(0x30000000);
        aw = Integer.reverse(0x20000000);
        ax = 36864 >>> 172 | 36864 << -172;
        ay = (-1 >>> 216 | -1 << -216) & 0xFFFFFFFF;
        az = Long.reverse(-73204435067473713L);
        ba = (0 >>> 181 | 0 << -181) & 0xFFFFFFFF;
        bb = Integer.reverse(0x50000000);
        bc = Long.reverse(-73204435067473713L);
        bd = (0x40000000 >>> 62 | 0x40000000 << -62) & 0xFFFFFFFF;
        be = Integer.reverse(-805306368);
        bf = Long.reverse(-73204435067473713L);
        a = new String[au];
        b = new String[av];
        \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.b();
        j = aw;
        a = new \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e83", (int)bb, (long)bc), bd != 0);
        a = \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.a();
        a = new \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393((String)\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.c("\u3e86", (int)be, (long)bf), \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.values().length);
    }

    @Override
    public \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 a() {
        return this.a;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u00b7\u00d9\u00db\u00bb\u00df\u00fe\u00f6\u010c\u00f8\u00c7\u0105\u00fb\u0109\u0103\u00cc\u00f1\u0113\u0112\u010a\u0110\u010a\u00df", (byte)8, 65), \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0430\u043d\u043c\u03ff\u043f\u043b\u0436\u043f\u044a\u0439\u0406\u0444\u0448\u0441\u0444\u044a\u040c\u0792\u07a7\u07a6\u0789\u07a5\u07ab\u0799\u07a0\u0779\u0421", (byte)8, 68) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u00c9", (byte)8, 66) + methodType.toString(), exception);
        }
    }
}

