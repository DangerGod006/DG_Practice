/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private final boolean x;
    protected final \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 l = \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.b;
    private static int a = (2048 >>> 43 | 2048 << -43) & 0xFFFFFFFF;
    protected \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a;
    private final List<String> b;
    private final String p;
    protected \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3 a;
    private static int b = (0 >>> 246 | 0 << ~246 + 1) & 0xFFFFFFFF;
    private final String o;
    private final boolean w;

    @Generated
    public String f() {
        return this.p;
    }

    public void a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        this.a = \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 ? this.a.a().b((\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2).a() : \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.c();
        this.b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, stringArray);
    }

    public \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, String string, String string2, boolean bl, boolean bl2, String ... stringArray) {
        this.a = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
        this.o = string;
        this.p = string2;
        this.w = bl;
        this.x = bl2;
        this.b = stringArray.length == 0 ? Collections.emptyList() : Arrays.asList(stringArray);
    }

    @Generated
    public \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 a() {
        return this.l;
    }

    @Generated
    public String e() {
        return this.o;
    }

    @Generated
    public \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 b() {
        return this.a;
    }

    @Generated
    public List<String> b() {
        return this.b;
    }

    @Generated
    public \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3 a() {
        return this.a;
    }

    @Generated
    public boolean o() {
        return this.x;
    }

    @Generated
    public boolean n() {
        return this.w;
    }

    protected abstract void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba var1, String[] var2);

    protected List<String> c(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        return null;
    }

    protected boolean j() {
        return (this.a == \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3.c || this.a == \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3.s ? a : b) != 0;
    }
}

