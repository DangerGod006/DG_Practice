/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03b6\u03c9\u03c7\u03c2\u03b8\u03bd\u03bb\u03b5\u03a6\u03b9;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb {
    private static int ar;
    private static int ax;
    private static boolean ao;
    private static String[] a;
    private static long ac;
    private static int an;
    private static int p;
    private static int z;
    private static long aa;
    private static int af;
    private static long m;
    private static int av;
    private static long at;
    private static long d;
    private static int h;
    static \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[][] a;
    private static int b;
    private static int ad;
    private static int l;
    private static int az;
    private static int al;
    private static int ab;
    private static String[] b;
    private static int am;
    private static int ag;
    private static long q;
    private static long o;
    private static int y;
    private static int a;
    private static int as;
    private static int f;
    private static int k;
    private static int ah;
    private static int ay;
    private static long e;
    private static int i;
    private static long c;
    private static int t;
    private static int ak;
    private static int n;
    private static int aw;
    private static long au;
    private static int u;
    private static int g;
    private static int aq;
    private static int w;
    private static int ao;
    private static int v;
    private static int s;
    private static long r;
    private static int ai;
    private static int x;
    private static long ae;
    private static int j;
    private static int ap;
    private static int aj;

    public static void a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, Object object) {
        \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, object, w != 0);
    }

    private static String a(int n, long l) {
        l ^= 0x27L;
        l ^= 0xDF40C94D44CA5361L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(5 + 63), (byte)(40 + 29), (byte)(40 + 43), (byte)(42 + 5), (byte)(2 + 65), (byte)(13 + 53), (byte)(40 + 27), 47, (byte)(7 + 73), (byte)(44 + 31), (byte)(39 + 28), (byte)(59 + 24), (byte)(10 + 43), (byte)(68 + 12), 97, (byte)(50 + 50), (byte)(25 + 75), (byte)(83 + 22), (byte)(16 + 94), (byte)(93 + 10)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(62 + 7), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0508\u0515\u0514\u04d7\u0517\u0513\u050e\u0517\u0522\u0511\u04de\u051c\u0520\u0519\u051c\u0522\u04e4\u0875\u085a\u0875\u086d\u085a\u0879\u084f\u087f\u0875\u087a", (byte)80, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6[] \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6Array, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22) {
        \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6[] \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6Array2 = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6Array;
        int n = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6Array2.length;
        for (int i = ag; i < n; ++i) {
            \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62 = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6Array2[i];
            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, ah != 0);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0539\u055b\u055d\u053d\u0561\u0580\u0578\u058e\u057a\u0549\u0587\u057d\u058b\u0585\u054e\u0573\u0595\u0594\u058c\u0592\u058c\u0561", (byte)85, 69), \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0517\u0524\u0523\u04e6\u0526\u0522\u051d\u0526\u0531\u0520\u04ed\u052b\u052f\u0528\u052b\u0531\u04f3\u0884\u0869\u0884\u087c\u0869\u0888\u085e\u088e\u0884\u0889\u0509", (byte)85, 68) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u054b", (byte)85, 70) + methodType.toString(), exception);
        }
    }

    public static void a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, boolean bl) {
        String[] stringArray = ((\u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4)\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a()).a();
        if (stringArray == null) {
            throw new IllegalArgumentException((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e80", (int)(y & z), (long)aa));
        }
        if (stringArray.length == 0) {
            throw new IllegalArgumentException((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e83", (int)ab, (long)ac));
        }
        Object object = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a();
        if (object == null) {
            throw new IllegalArgumentException((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e86", (int)ad, (long)ae) + \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62);
        }
        Object object2 = \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(stringArray, object, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, af);
        \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, object2, bl);
    }

    @Nullable
    public static Object a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        int n = \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.ab;
        if (n == a) {
            return null;
        }
        \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array = a[n];
        int n2 = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a();
        if (n2 < \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array.length) {
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2 \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array[n2];
            return \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22 != null ? \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2.a(\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22) : null;
        }
        Object[] objectArray = new Object[f];
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.g] = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62;
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.h] = n2;
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.i] = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array.length;
        throw new ArrayIndexOutOfBoundsException(String.format((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e80", (int)b, (long)(d ^ e)), objectArray));
    }

    @Generated
    public static boolean as() {
        return ao;
    }

    public static void g(boolean bl) {
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.f(bl);
        ao = bl;
    }

    private static synchronized void a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        if (a != null) {
            int n;
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[][] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array = a;
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[][] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray = new \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array.length + ai][];
            System.arraycopy(\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array, aj, \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray, ak, \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array.length);
            \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.ab = n = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray.length - al;
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray[n] = new \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.aa];
            a = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray;
        } else {
            \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.ab = am;
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[][] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray = new \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[an][];
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.ao] = new \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.aa];
            a = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2ArrayArray;
        }
    }

    public static void a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, Object object) {
        \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, (\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a(), object, x != 0);
    }

    public static void a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, Object object2, boolean bl) {
        Object object3;
        if (\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.ab == j) {
            \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
        }
        if (object2 == null) {
            throw new IllegalArgumentException((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e80", (int)(k & l), (long)m));
        }
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0 \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, object2);
        if (\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 == null) {
            throw new IllegalArgumentException((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e83", (int)n, (long)o));
        }
        if (bl) {
            if (\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 instanceof String) {
                \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.q((String)((Object)\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02));
            } else if (\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 instanceof List) {
                object3 = new ArrayList(\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02);
                if (!object3.isEmpty()) {
                    object3.replaceAll(object -> {
                        if (object instanceof String) {
                            object = \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.q((String)object);
                        }
                        return object;
                    });
                }
                \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(object3);
            }
        }
        object3 = a[\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932.ab];
        int n = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a();
        if (n < ((\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[])object3).length) {
            object3[n] = new \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02, null);
            return;
        }
        Object[] objectArray = new Object[s];
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.t] = \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62;
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.u] = n;
        objectArray[\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.v] = ((Object)object3).length;
        throw new ArrayIndexOutOfBoundsException(String.format((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e86", (int)p, (long)(q ^ r)), objectArray));
    }

    private static void b() {
        int n;
        c = 7195700355031914830L;
        long l = c ^ 0xDF40C94D44CA5361L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(5 + 63), (byte)(13 + 56), (byte)(12 + 71), (byte)(36 + 11), (byte)(17 + 50), (byte)(13 + 53), (byte)(9 + 58), 47, (byte)(69 + 11), (byte)(48 + 27), (byte)(5 + 62), 83, (byte)(49 + 4), (byte)(62 + 18), (byte)(94 + 3), (byte)(29 + 71), (byte)(66 + 34), (byte)(4 + 101), (byte)(98 + 12), (byte)(21 + 82)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(40 + 28), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u053a\u053d\u0521\u04ff\u04fd\u050f\u0525\u04ff\u04ff\u053f\u0506\u0505\u0508\u0526\u0537\u0522\u050c\u051e\u0550\u054f\u050f\u0524\u051f\u054f\u0521\u0528\u0538\u0555\u052b\u052d\u0531\u052a\u054d\u0518\u053b\u0561\u0539\u054d\u052c\u055a\u051d\u0557\u0558\u0536\u055a\u0547\u0569\u0562\u053d\u0568\u0528\u0542\u052d\u053b\u0538\u0539", (byte)9, 69);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u051d\u04fd\u052c\u0539\u052a\u0544\u051b\u050d\u0530\u0518\u0540\u0528\u0533\u053e\u0535\u0516\u050e\u053c\u051c\u0547\u052e\u051b\u0530\u050f\u0526\u0522\u0543\u052e\u050c\u0511\u0526\u052f", (byte)9, 70);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[2] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0104\u010a\u00fc\u00fb\u00d7\u00e5\u00d8\u00db\u00e6\u00f3\u00e1\u00f5\u00e3\u00f2\u00ce\u0109\u00e8\u00ee\u0111\u00fa\u0106\u011c\u00d2\u0120\u00d4\u00f7\u0104\u00fa\u00f7\u00e1\u00fa\u00f7\u0127\u012c\u00de\u0120\u00ed\u012a\u0109\u0107\u011c\u0114\u012e\u00f4\u011f\u0138\u0125\u00f5\u0112\u0139\u010c\u0125\u00f6\u013e\u012f\u0111\u0139\u00fb\u013c\u00fc\u0137\u0111\u0145\u0121", (byte)9, 66);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[3] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u053a\u053d\u0521\u04ff\u04fd\u050f\u0525\u04ff\u04ff\u053f\u0506\u0505\u0508\u0526\u0537\u0522\u050c\u051e\u0550\u054f\u050f\u0524\u051f\u054f\u0521\u0528\u0538\u0555\u052b\u052d\u0531\u052a\u054d\u0518\u053b\u0561\u0539\u054d\u052c\u055a\u051d\u0557\u0558\u0536\u055a\u0547\u0569\u0562\u053d\u0568\u0528\u0542\u052d\u053b\u0538\u0539", (byte)9, 69);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u00ca\u00e8\u010c\u0104\u00ca\u00c1\u00fc\u010a\u00dc\u0113\u00de\u00d3\u0114\u00ec\u00ce\u0116\u00f5\u00f3\u00fb\u00db\u00d6\u00ef\u00ec\u010f\u0100\u010d\u0101\u00ef\u00f3\u00ff\u0112\u0102", (byte)9, 66);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[5] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0409\u0427\u044b\u0443\u0409\u0400\u043b\u0449\u041b\u0452\u041b\u040a\u0430\u0435\u0450\u0426\u0458\u042c\u0447\u043d\u044c\u0419\u0447\u045a\u0453\u0457\u043b\u0459\u042d\u0441\u045d\u0447", (byte)9, 68);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[6] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u041d\u0424\u0407\u0423\u042c\u041e\u0420\u042e\u0420\u041c\u043d\u041e\u042e\u0450\u044b\u0454\u042f\u041a\u0418\u0444\u043a\u045d\u043b\u041f\u0442\u0418\u041b\u0433\u0463\u0434\u0445\u0421\u0458\u0432\u0460\u043f\u042a\u0442\u044e\u043b\u046a\u0461\u0447\u0438", (byte)9, 68);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[7] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0435\u0442\u0420\u0422\u0440\u041e\u044c\u041a\u044f\u043c\u042b\u0418", (byte)9, 68);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0445\u0448\u042c\u040a\u0408\u041a\u0430\u040a\u040a\u044a\u0411\u0410\u0413\u0431\u0442\u042d\u0417\u0429\u045b\u045a\u041a\u042f\u042a\u045a\u042c\u0433\u0443\u0460\u0436\u0438\u043c\u0435\u0458\u0423\u0446\u046c\u0444\u0458\u0437\u0465\u0428\u0462\u0461\u0462\u0467\u0474\u0430\u0461\u0437\u045a\u043a\u046d\u046d\u0456\u0443\u0444", (byte)9, 68);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u00e9\u00c9\u00f8\u0105\u00f6\u0110\u00e7\u00d9\u00fc\u00e4\u010c\u00f4\u00ff\u010a\u0101\u00e2\u00da\u0108\u00e8\u0113\u00fa\u00f6\u0119\u011c\u0118\u00f1\u00f5\u0101\u0116\u011f\u0128\u0119", (byte)9, 66);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0443\u0449\u043b\u043a\u0416\u0424\u0417\u041a\u0425\u0432\u0420\u0434\u0422\u0431\u040d\u0448\u0427\u042d\u0450\u0439\u0445\u045b\u0411\u045f\u0413\u0436\u0443\u0439\u0436\u0420\u0439\u0436\u0466\u046b\u041d\u045f\u042c\u0469\u0448\u0446\u045b\u0453\u046d\u0433\u045e\u0477\u0464\u0434\u0451\u0478\u044b\u0464\u0435\u0435\u0447\u046c\u043a\u047f\u0479\u0455\u0474\u043f\u045f\u0484", (byte)9, 67);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u053a\u053d\u0521\u04ff\u04fd\u050f\u0525\u04ff\u04ff\u053f\u0506\u0505\u0508\u0526\u0537\u0522\u050c\u051e\u0550\u054f\u050f\u0524\u051f\u054f\u0521\u0528\u0538\u0555\u052b\u052d\u0531\u052a\u054d\u0518\u053b\u0561\u0539\u054d\u052c\u055a\u051d\u0557\u0558\u0553\u0556\u0565\u051e\u056a\u0568\u0560\u053b\u054d\u056a\u0561\u0538\u0539", (byte)9, 69);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0409\u0427\u044b\u0443\u0409\u0400\u043b\u0449\u041b\u0452\u041d\u0412\u0453\u042b\u040d\u0455\u0434\u0432\u043a\u041a\u0415\u0432\u043e\u045b\u044c\u041a\u0433\u044e\u0444\u0465\u0443\u0441", (byte)9, 67);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0409\u0427\u044b\u0443\u0409\u0400\u043b\u0449\u041b\u0452\u041b\u040a\u0430\u0435\u0450\u0426\u0458\u042c\u0447\u043d\u044c\u0418\u0456\u0459\u0429\u042e\u044c\u045d\u0461\u041f\u0467\u0461", (byte)9, 67);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[6] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0512\u0519\u04fc\u0518\u0521\u0513\u0515\u0523\u0515\u0511\u0532\u0513\u0523\u0545\u0540\u0549\u0524\u050f\u050d\u0539\u052f\u0552\u0530\u0514\u0537\u050d\u0510\u0528\u0558\u0529\u053a\u0516\u051e\u0553\u0561\u051c\u053f\u055d\u052f\u0534\u0562\u0524\u0568\u0541\u0555\u053f\u0565\u0529\u054c\u0526\u055f\u0565\u0562\u0561\u0538\u0539", (byte)9, 69);
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[7] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u041a\u0443\u040b\u040c\u0429\u042e\u0448\u040b\u0429\u0448\u042f\u0418", (byte)9, 67);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0408\u041e\u0437\u0402\u0448\u0442\u044c\u040e\u0444\u0444\u0425\u0426\u0445\u0428\u040f\u0413\u0446\u0456\u0433\u0419\u040f\u0426\u0423\u0424", (byte)9, 68);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0109\u00e0\u0107\u00e0\u0100\u00c9\u00fd\u010f\u00cd\u0106\u010d\u0116\u0102\u00d6\u0109\u00d2\u010e\u0114\u00e4\u011b\u00e7\u010c\u00ff\u0113\u0120\u00e1\u0104\u0126\u0119\u0106\u0127\u0118", (byte)9, 65);
                }
            }
        }
    }

    private static Object a(String[] stringArray, Object object, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, int n) {
        Object object2;
        if (n >= stringArray.length) {
            return object;
        }
        return (object2 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.e(stringArray[n++])) == null || object != null && !(object instanceof Iterable) && !object.getClass().isAssignableFrom(object2.getClass()) ? \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(stringArray, object, \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, n) : object2;
    }

    public static JSONObject a(boolean bl) {
        JSONObject jSONObject = new JSONObject();
        if (a == null) {
            return jSONObject;
        }
        HashMap<String, JSONObject> hashMap = new HashMap<String, JSONObject>();
        \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[][] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array = a;
        int n = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array.length;
        block0: for (int i = ap; i < n; ++i) {
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array2;
            \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2[] \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array3 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array2 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array[i];
            int n2 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array3.length;
            for (int j = aq; j < n2; ++j) {
                \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2 \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2Array3[j];
                if (\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22 == null) continue;
                \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62 = \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2.a(\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22);
                if (bl && \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62 instanceof \u0394\u03b6\u03c9\u03c7\u03c2\u03b8\u03bd\u03bb\u03b5\u03a6\u03b9) continue block0;
                String string3 = ((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2.a((\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2)\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22)).bB;
                JSONObject jSONObject2 = hashMap.computeIfAbsent(string3, string2 -> {
                    JSONObject jSONObject2 = new JSONObject();
                    jSONObject.put(string3, (Object)jSONObject2);
                    return jSONObject2;
                });
                String string4 = ((\u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4)\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62.a()).a()[ar];
                String[] stringArray = string4.split((String)\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.c("\u3e80", (int)as, (long)(at ^ au)));
                JSONObject jSONObject3 = jSONObject2;
                for (int k = av; k < stringArray.length - aw; ++k) {
                    JSONObject jSONObject4 = jSONObject3;
                    int n3 = k;
                    jSONObject3 = hashMap.computeIfAbsent(k + stringArray[k], string -> {
                        JSONObject jSONObject2 = new JSONObject();
                        jSONObject4.put(stringArray[n3], (Object)jSONObject2);
                        return jSONObject2;
                    });
                }
                jSONObject3.put(stringArray[stringArray.length - ax], \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2.a(\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22) != null ? \u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c2.a(\u03c7\u03b8\u03b4\u0394\u03bf\u03c6\u03a3\u03c8\u03c9\u03b1\u03b8\u03b6\u03c22) : JSONObject.NULL);
            }
        }
        return jSONObject;
    }

    static {
        a = Integer.reverse(-1);
        b = 0 >>> 92 | 0 << ~92 + 1;
        d = Long.reverse(8257961024506969030L);
        e = Long.reverse(-2017612633061982208L);
        f = Integer.reverse(-1073741824);
        g = Integer.reverse(0);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Integer.reverse(0x40000000);
        j = (-1 >>> 245 | -1 << -245) & 0xFFFFFFFF;
        k = Integer.reverse(Integer.MIN_VALUE);
        l = Integer.reverse(-1);
        m = Long.reverse(-7594709663837176890L);
        n = Integer.reverse(0x40000000);
        o = Long.reverse(-7594709663837176890L);
        p = 393216 >>> 241 | 393216 << -241;
        q = Long.reverse(8257961024506969030L);
        r = Long.reverse(-2017612633061982208L);
        s = (0x1800000 >>> 87 | 0x1800000 << ~87 + 1) & 0xFFFFFFFF;
        t = (0 >>> 113 | 0 << ~113 + 1) & 0xFFFFFFFF;
        u = Integer.reverse(Integer.MIN_VALUE);
        v = (0x2000000 >>> 184 | 0x2000000 << ~184 + 1) & 0xFFFFFFFF;
        w = Integer.reverse(Integer.MIN_VALUE);
        x = (0x2000000 >>> 121 | 0x2000000 << -121) & 0xFFFFFFFF;
        y = Integer.reverse(0x20000000);
        z = -1 >>> 137 | -1 << ~137 + 1;
        aa = Long.reverse(-7594709663837176890L);
        ab = 327680 >>> 80 | 327680 << ~80 + 1;
        ac = Long.reverse(-7594709663837176890L);
        ad = (0x18000000 >>> 122 | 0x18000000 << ~122 + 1) & 0xFFFFFFFF;
        ae = Long.reverse(-7594709663837176890L);
        af = 0 >>> 88 | 0 << ~88 + 1;
        ag = (0 >>> 165 | 0 << ~165 + 1) & 0xFFFFFFFF;
        ah = Integer.reverse(Integer.MIN_VALUE);
        ai = 0x2000000 >>> 217 | 0x2000000 << -217;
        aj = (0 >>> 226 | 0 << -226) & 0xFFFFFFFF;
        ak = 0 >>> 87 | 0 << -87;
        al = Integer.reverse(Integer.MIN_VALUE);
        am = 0 >>> 91 | 0 << -91;
        an = Integer.reverse(Integer.MIN_VALUE);
        ao = 0 >>> 232 | 0 << -232;
        ap = Integer.reverse(0);
        aq = 0 >>> 14 | 0 << -14;
        ar = 0 >>> 220 | 0 << ~220 + 1;
        as = Integer.reverse(-536870912);
        at = Long.reverse(8257961024506969030L);
        au = Long.reverse(-2017612633061982208L);
        av = 0 >>> 37 | 0 << ~37 + 1;
        aw = Integer.reverse(Integer.MIN_VALUE);
        ax = Integer.reverse(Integer.MIN_VALUE);
        ay = Integer.reverse(0x10000000);
        az = 0x4000000 >>> 23 | 0x4000000 << ~23 + 1;
        a = new String[ay];
        b = new String[az];
        \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.b();
    }
}

