/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent$Result
 *  org.bukkit.event.player.PlayerBedEnterEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerEditBookEvent
 *  org.bukkit.event.player.PlayerEvent
 *  org.bukkit.event.player.PlayerFishEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerItemHeldEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerKickEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerShearEntityEvent
 *  org.bukkit.event.server.ServerCommandEvent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerShearEntityEvent;
import org.bukkit.event.server.ServerCommandEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int ak;
    private static long n;
    private static int f;
    private static int ah;
    private static int bl;
    private static int bc;
    private static int ao;
    private static long bn;
    private static long h;
    private static int ac;
    private static int bi;
    private static int u;
    private static long ba;
    private static int bp;
    private static long ay;
    private static int ab;
    private static int aw;
    private static int ad;
    private static long bb;
    private static long c;
    private static int q;
    private static int s;
    private static long y;
    private static int al;
    private static int ar;
    private static long bs;
    private static long e;
    private static int c;
    private static int az;
    private static int bf;
    private static int ap;
    private static int d;
    private static int a;
    private static int br;
    private static int j;
    private static int bh;
    private static long o;
    private static int av;
    private final nLoginBukkit g;
    private static int aa;
    private static int bk;
    private static int an;
    private final \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 a;
    private static int bd;
    private static int aq;
    private static int af;
    private static int aj;
    private static int b;
    private static long r;
    private final \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 c;
    private static String[] a;
    private static int w;
    private static int bm;
    private static int bo;
    private final boolean o;
    private static int as;
    private static long v;
    private static int i;
    private static long ax;
    private static int t;
    private static long at;
    private static int p;
    private static long bj;
    private static int l;
    private static int bq;
    private static String[] b;
    private static int g;
    private static long bt;
    private static int x;
    private static int am;
    private static int z;
    private static int ai;
    private static long k;
    private static int m;
    private static int au;
    private static int bg;
    private static final GameMode b;
    private static int ae;
    private static int be;
    private static int ag;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u04e5\u0507\u0509\u04e9\u050d\u052c\u0524\u053a\u0526\u04f5\u0533\u0529\u0537\u0531\u04fa\u051f\u0541\u0540\u0538\u053e\u0538\u050d", (byte)88, 67), \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0520\u052d\u052c\u04ef\u052f\u052b\u0526\u052f\u053a\u0529\u04f6\u0534\u0538\u0531\u0534\u053a\u04fc\u088c\u0875\u088f\u0897\u089b\u0884\u0893\u0898\u0892\u0511", (byte)88, 68) + string + \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u054e", (byte)88, 69) + methodType.toString(), exception);
        }
    }

    @EventHandler(priority=EventPriority.LOW)
    public void b(PlayerQuitEvent playerQuitEvent) {
        ((\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5)this.g.a().b()).a(playerQuitEvent);
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerItemConsumeEvent playerItemConsumeEvent) {
        if (this.c.a((PlayerEvent)playerItemConsumeEvent)) {
            playerItemConsumeEvent.setCancelled(al != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerBedEnterEvent playerBedEnterEvent) {
        if (this.c.a((PlayerEvent)playerBedEnterEvent)) {
            playerBedEnterEvent.setCancelled(ag != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerInteractEntityEvent playerInteractEntityEvent) {
        if (this.c.a((PlayerEvent)playerInteractEntityEvent)) {
            playerInteractEntityEvent.setCancelled(ad != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerInteractEvent playerInteractEvent) {
        if (this.c.a((PlayerEvent)playerInteractEvent)) {
            playerInteractEvent.setCancelled(ac != 0);
        }
    }

    @Generated
    public \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc(nLoginBukkit nLoginBukkit2, \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942, \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52, boolean bl) {
        this.g = nLoginBukkit2;
        this.a = \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942;
        this.c = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52;
        this.o = bl;
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerDropItemEvent playerDropItemEvent) {
        if (this.c.a((PlayerEvent)playerDropItemEvent)) {
            playerDropItemEvent.setCancelled(aj != 0);
        }
    }

    static {
        GameMode gameMode;
        a = 0xA00000 >>> 149 | 0xA00000 << ~149 + 1;
        b = 0 >>> 229 | 0 << ~229 + 1;
        c = Integer.reverse(0);
        d = -1 >>> 138 | -1 << ~138 + 1;
        e = Long.reverse(2641655171636518950L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(Integer.MIN_VALUE);
        h = Long.reverse(2641655171636518950L);
        i = Integer.reverse(0x40000000);
        j = Integer.reverse(0x40000000);
        k = Long.reverse(2641655171636518950L);
        l = Integer.reverse(-1073741824);
        m = Integer.reverse(-1073741824);
        n = Long.reverse(8694493070822465574L);
        o = Long.reverse(0x5C00000000000000L);
        p = (0x400000 >>> 244 | 0x400000 << -244) & 0xFFFFFFFF;
        q = 0x20000000 >>> 123 | 0x20000000 << -123;
        r = Long.reverse(2641655171636518950L);
        s = Integer.reverse(Integer.MIN_VALUE);
        t = 0xA00000 >>> 21 | 0xA00000 << ~21 + 1;
        u = (-1 >>> 145 | -1 << -145) & 0xFFFFFFFF;
        v = Long.reverse(2641655171636518950L);
        w = 24 >>> 194 | 24 << -194;
        x = Integer.reverse(-1);
        y = Long.reverse(2641655171636518950L);
        z = Integer.reverse(Integer.MIN_VALUE);
        aa = Integer.reverse(0);
        ab = 131072 >>> 177 | 131072 << ~177 + 1;
        ac = (64 >>> 230 | 64 << ~230 + 1) & 0xFFFFFFFF;
        ad = Integer.reverse(Integer.MIN_VALUE);
        ae = Integer.reverse(Integer.MIN_VALUE);
        af = Integer.reverse(Integer.MIN_VALUE);
        ag = (16384 >>> 206 | 16384 << ~206 + 1) & 0xFFFFFFFF;
        ah = Integer.reverse(Integer.MIN_VALUE);
        ai = 32 >>> 229 | 32 << -229;
        aj = 0x8000000 >>> 59 | 0x8000000 << ~59 + 1;
        ak = Integer.reverse(Integer.MIN_VALUE);
        al = (1024 >>> 42 | 1024 << -42) & 0xFFFFFFFF;
        am = Integer.reverse(Integer.MIN_VALUE);
        an = 1 >>> 128 | 1 << ~128 + 1;
        ao = (128 >>> 39 | 128 << -39) & 0xFFFFFFFF;
        ap = (0 >>> 62 | 0 << -62) & 0xFFFFFFFF;
        aq = Integer.reverse(Integer.MIN_VALUE);
        ar = Integer.reverse(-536870912);
        as = Integer.reverse(-1);
        at = Long.reverse(2641655171636518950L);
        au = 0 >>> 20 | 0 << -20;
        av = Integer.reverse(0);
        aw = 0x800000 >>> 244 | 0x800000 << ~244 + 1;
        ax = Long.reverse(8694493070822465574L);
        ay = Long.reverse(0x5C00000000000000L);
        az = 9 >>> 192 | 9 << ~192 + 1;
        ba = Long.reverse(8694493070822465574L);
        bb = Long.reverse(0x5C00000000000000L);
        bc = Integer.reverse(0);
        bd = Integer.reverse(0);
        be = 0 >>> 187 | 0 << -187;
        bf = (0x5E000000 >>> 153 | 0x5E000000 << ~153 + 1) & 0xFFFFFFFF;
        bg = 2013265921 >>> 27 | 2013265921 << ~27 + 1;
        bh = Integer.reverse(0x50000000);
        bi = (-1 >>> 167 | -1 << -167) & 0xFFFFFFFF;
        bj = Long.reverse(2641655171636518950L);
        bk = (8192 >>> 45 | 8192 << ~45 + 1) & 0xFFFFFFFF;
        bl = (0 >>> 79 | 0 << ~79 + 1) & 0xFFFFFFFF;
        bm = 0x16000000 >>> 153 | 0x16000000 << -153;
        bn = Long.reverse(2641655171636518950L);
        bo = Integer.reverse(0);
        bp = 0x1A00000 >>> 181 | 0x1A00000 << ~181 + 1;
        bq = Integer.reverse(-1342177280);
        br = Integer.reverse(0x30000000);
        bs = Long.reverse(8694493070822465574L);
        bt = Long.reverse(0x5C00000000000000L);
        a = new String[bp];
        b = new String[bq];
        \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b();
        try {
            gameMode = GameMode.valueOf((String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e80", (int)br, (long)(bs ^ bt)));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            gameMode = null;
        }
        b = gameMode;
    }

    private static void b() {
        int n;
        c = 7207991650882196766L;
        long l = c ^ 0x5A217F76B020AF9EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), (byte)(38 + 31), (byte)(48 + 35), (byte)(20 + 27), (byte)(62 + 5), (byte)(51 + 15), 67, (byte)(26 + 21), (byte)(16 + 64), (byte)(40 + 35), (byte)(2 + 65), (byte)(69 + 14), (byte)(23 + 30), (byte)(76 + 4), 97, (byte)(21 + 79), (byte)(31 + 69), (byte)(100 + 5), (byte)(107 + 3), (byte)(86 + 17)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(62 + 6), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0137\u0111\u013c\u0103\u0147\u0136\u012a\u0105\u0142\u0105\u010e\u013a\u010e\u010f\u0114\u0147\u0128\u0140\u0157\u0130\u014d\u0149\u0120\u0121", (byte)39, 66);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0117\u013f\u0145\u0123\u0117\u013c\u0136\u011f\u010a\u012f\u0124\u0115", (byte)39, 65);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0528\u0530\u055b\u0511\u052b\u0530\u054a\u055c\u0533\u055b\u055e\u0521\u0560\u0544\u055a\u051d\u0555\u0528\u0543\u053f\u0570\u055f\u056a\u0570\u053f\u056f\u0535\u0557\u0567\u0537\u0578\u0558\u0573\u057a\u0559\u056e\u053d\u056b\u057c\u057b\u0575\u0570\u054f\u057f\u055c\u057f\u0554\u054b\u0546\u054d\u0561\u0586\u054f\u055c\u056e\u057f\u0570\u056f\u0592\u0552\u0590\u057a\u0592\u0579\u0569\u059e\u059f\u058f\u0589\u0594\u057c\u0596\u057b\u05a1\u0561\u059a\u057d\u0588\u0565\u0567\u0586\u056a\u059c\u0598\u05ab\u05a8\u059d\u05ac\u05a5\u0580\u05a7\u05b2\u0572\u0598\u058a\u05a9", (byte)39, 70);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0474\u049c\u04a2\u0480\u0474\u0499\u0493\u047c\u0467\u048c\u0481\u0472", (byte)39, 67);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u0140\u0118\u0145\u0116\u013b\u0138\u013c\u0139\u0144\u013d\u0140\u013f\u010f\u013c\u010b\u0127\u0120\u0127\u0152\u0157\u014a\u013a\u0138\u015e\u015b\u0153\u014b\u015d\u014e\u011e\u0163\u0136\u0142\u0168\u0162\u0136\u0164\u0122\u0139\u0143\u016f\u014b\u013c\u014b\u013c\u0133\u013e\u012e\u0177\u0178\u0163\u0155\u0178\u0146\u0156\u015b\u0168\u0178\u0180\u0149\u0140\u0158\u0185\u0176\u0151\u0162\u0183\u0165\u0146\u0189\u015d\u0177\u017c\u0178\u0182\u0155", (byte)39, 65);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[5] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0459\u045f\u0472\u0470\u0494\u0494\u04a4\u0460\u04a6\u046a\u0499\u04ab\u04a8\u047e\u047d\u046c\u04a3\u04a2\u0487\u04b6\u04b0\u0494\u0472\u0476\u0483\u0494\u04b9\u047e\u04a0\u04b1\u04ac\u04c0\u0482\u0492\u0484\u04a3\u0486\u04c7\u04a6\u0499\u04bb\u04cb\u049c\u0486\u04ad\u04c7\u04a1\u04c9\u049c\u04c4\u04a9\u04d4\u04a9\u04d6\u049d\u049e", (byte)39, 67);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[6] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0134\u0134\u0106\u0115\u0113\u0129\u014c\u0109\u0106\u010c\u013c\u0141\u013c\u0146\u0120\u0142\u0144\u0109\u014b\u0126\u0159\u0133\u0127\u0150\u011b\u0153\u0119\u0161\u013a\u0138\u0154\u0133\u0140\u013d\u0158\u0148\u0154\u0167\u0138\u013f\u0147\u0142\u0171\u0170\u015c\u013d\u012c\u015d\u014a\u0148\u0136\u0135\u0132\u0153\u0140\u0141", (byte)39, 65);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0147\u0120\u0110\u0147\u013b\u014c\u0134\u010c\u0144\u014d\u0109\u0149\u0143\u0113\u0153\u0122\u0111\u0122\u012c\u010b\u0153\u0159\u0120\u0121", (byte)39, 65);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[8] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0463\u0494\u0473\u049b\u0463\u0477\u0474\u0495\u0469\u0483\u049f\u047a\u047f\u0480\u04a2\u046b\u047c\u0483\u0488\u04a0\u04ac\u0480\u047d\u047e", (byte)39, 68);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[9] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u055b\u054a\u0555\u051e\u0554\u053c\u051a\u051d\u051c\u0532\u051c\u0525\u0549\u0535\u053d\u053f\u054d\u0555\u0568\u0565\u056a\u055f\u0536\u0537", (byte)39, 70);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[10] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u045e\u0462\u046e\u049e\u049a\u04a7\u0466\u0478\u04ac\u0468\u0481\u0472", (byte)39, 67);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[11] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0527\u0532\u053f\u0548\u053e\u0520\u053f\u051d\u0538\u0544\u0546\u052b", (byte)39, 69);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[12] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u013e\u0145\u0100\u0127\u011e\u0104\u0118\u010a\u013f\u012f\u0149\u011d\u0126\u012a\u014b\u010e\u0147\u0123\u0159\u0139\u0112\u0123\u0120\u0121", (byte)39, 66);
                    continue block7;
                }
                case 1: {
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u054d\u0527\u0552\u0519\u055d\u054c\u0540\u051b\u0558\u051b\u0523\u0564\u0565\u0569\u0524\u0566\u0542\u055f\u0543\u056f\u053b\u055f\u0536\u0537", (byte)39, 69);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u053c\u0551\u054c\u0529\u0532\u053a\u052e\u0562\u052f\u0551\u0532\u052b", (byte)39, 69);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0112\u011a\u0145\u00fb\u0115\u011a\u0134\u0146\u011d\u0145\u0148\u010b\u014a\u012e\u0144\u0107\u013f\u0112\u012d\u0129\u015a\u0149\u0154\u015a\u0129\u0159\u011f\u0141\u0151\u0121\u0162\u0142\u015d\u0164\u0143\u0158\u0127\u0155\u0166\u0165\u015f\u015a\u0139\u0169\u0146\u0169\u013e\u0135\u0130\u0137\u014b\u0170\u0139\u0146\u0158\u0169\u015a\u0159\u017c\u013c\u017a\u0164\u017c\u0163\u0153\u0188\u0189\u0179\u0173\u017e\u0166\u0180\u0165\u018b\u014b\u0184\u0167\u0172\u014f\u0151\u0170\u0154\u0186\u0182\u0195\u0196\u016f\u0158\u016e\u016c\u015f\u0191\u0162\u015d\u0160\u0193", (byte)39, 65);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[3] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0493\u047b\u0493\u0481\u047b\u04a8\u0497\u0468\u046b\u0482\u0468\u0472", (byte)39, 67);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[4] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0140\u0118\u0145\u0116\u013b\u0138\u013c\u0139\u0144\u013d\u0140\u013f\u010f\u013c\u010b\u0127\u0120\u0127\u0152\u0157\u014a\u013a\u0138\u015e\u015b\u0153\u014b\u015d\u014e\u011e\u0163\u0136\u0142\u0168\u0162\u0136\u0164\u0122\u0139\u0143\u016f\u014b\u013c\u014b\u013c\u0133\u013e\u012e\u0177\u0178\u0163\u0155\u0178\u0146\u0156\u015b\u0168\u0178\u0180\u0149\u0140\u0158\u0185\u0176\u0144\u0153\u0142\u0183\u0143\u017f\u0148\u0158\u015a\u017c\u016c\u0155", (byte)39, 66);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[5] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0512\u0518\u052b\u0529\u054d\u054d\u055d\u0519\u055f\u0523\u0552\u0564\u0561\u0537\u0536\u0525\u055c\u055b\u0540\u056f\u0569\u054d\u052b\u052f\u053c\u054d\u0572\u0537\u0559\u056a\u0565\u0579\u053b\u054b\u053d\u055c\u053f\u0580\u055f\u0552\u0574\u0584\u0554\u055a\u0553\u0559\u0549\u0568\u0576\u0543\u0557\u0578\u0570\u0569\u0556\u0557", (byte)39, 69);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[6] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0491\u0491\u0463\u0472\u0470\u0486\u04a9\u0466\u0463\u0469\u0499\u049e\u0499\u04a3\u047d\u049f\u04a1\u0466\u04a8\u0483\u04b6\u0490\u0484\u04ad\u0478\u04b0\u0476\u04be\u0497\u0495\u04b1\u0490\u049d\u049a\u04b5\u04a5\u04b1\u04c4\u0495\u049c\u04a4\u049f\u04cd\u04c9\u04ab\u0499\u048b\u04b3\u04a7\u04cb\u049f\u04c5\u0494\u04a0\u049d\u049e", (byte)39, 68);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[7] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u055d\u0536\u0526\u055d\u0551\u0562\u054a\u0522\u055a\u0563\u051d\u0546\u0566\u055e\u0520\u053c\u053a\u0544\u054b\u0542\u0563\u055f\u0536\u0537", (byte)39, 70);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[8] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0463\u0494\u0473\u049b\u0463\u0477\u0474\u0495\u0469\u0483\u049f\u0469\u0484\u04a6\u049f\u04b0\u0489\u0483\u04b6\u0472\u0486\u04b6\u04b8\u04b0\u0472\u0490\u0487\u048a\u049d\u0493\u047e\u04a0", (byte)39, 67);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[9] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04a2\u0491\u049c\u0465\u049b\u0483\u0461\u0464\u0463\u0479\u046d\u04ae\u0482\u0499\u048e\u047d\u04b2\u048c\u04af\u0488\u0487\u04b6\u047d\u047e", (byte)39, 68);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[10] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u054c\u0554\u052a\u0559\u0549\u051a\u053d\u0550\u051c\u0551\u0564\u052b", (byte)39, 69);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[11] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u00ff\u0147\u0138\u0104\u010a\u0126\u0120\u0123\u0109\u0127\u010b\u0139\u012c\u0134\u0151\u010f\u0131\u0136\u0131\u0113\u0113\u0133\u0120\u0121", (byte)39, 66);
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[12] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u049b\u04a2\u045d\u0484\u047b\u0461\u0475\u0467\u049c\u048c\u04a5\u047f\u0468\u049e\u048c\u046d\u047f\u0489\u0483\u0489\u04b6\u0480\u047d\u047e", (byte)39, 67);
                    continue block7;
                }
                case 2: {
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u052a\u0519\u0559\u053f\u054c\u055d\u0551\u053f\u0542\u0543\u0546\u0532\u0563\u0566\u0522\u0529\u055c\u0539\u0558\u0543\u0529\u0539\u0536\u0537", (byte)39, 70);
                    continue block7;
                }
                case 4: {
                    \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0515\u0531\u052e\u052f\u0528\u0532\u0532\u052d\u051e\u0563\u0545\u0546\u0548\u0535\u0560\u0526\u055a\u052b\u052b\u0566\u0564\u055b\u0542\u0552\u052e\u053f\u054c\u0575\u054d\u0579\u0567\u0531", (byte)39, 70);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x3AL;
        l ^= 0x5A217F76B020AF9EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(46 + 22), (byte)(31 + 38), (byte)(13 + 70), (byte)(18 + 29), (byte)(4 + 63), (byte)(36 + 30), (byte)(61 + 6), (byte)(22 + 25), (byte)(19 + 61), 75, (byte)(40 + 27), 83, (byte)(14 + 39), (byte)(8 + 72), (byte)(17 + 80), (byte)(78 + 22), (byte)(85 + 15), (byte)(22 + 83), (byte)(62 + 48), (byte)(9 + 94)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(36 + 33), (byte)(19 + 64)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0553\u0560\u055f\u0522\u0562\u055e\u0559\u0562\u056d\u055c\u0529\u0567\u056b\u0564\u0567\u056d\u052f\u08bf\u08a8\u08c2\u08ca\u08ce\u08b7\u08c6\u08cb\u08c5", (byte)105, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerShearEntityEvent playerShearEntityEvent) {
        if (this.c.a((PlayerEvent)playerShearEntityEvent)) {
            playerShearEntityEvent.setCancelled(ae != 0);
        }
    }

    private boolean a(String string) {
        if (!string.isEmpty()) {
            String[] stringArray;
            if (string.charAt(be) != bf) {
                string = (char)bg + string;
            }
            if ((stringArray = string.split((String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e80", (int)(bh & bi), (long)bj))).length > bk) {
                String string2 = stringArray[bl].toLowerCase(Locale.ENGLISH);
                return string2.equals(\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e83", (int)bm, (long)bn));
            }
        }
        return bo != 0;
    }

    @EventHandler
    public void a(PlayerRespawnEvent playerRespawnEvent) {
        Player player = playerRespawnEvent.getPlayer();
        if (this.g.a().a().b(player.getName(), player.getUniqueId())) {
            return;
        }
        \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932 = (\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393)this.g.a().b();
        Location location = \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932.a().e();
        if (location != null) {
            playerRespawnEvent.setRespawnLocation(location);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(InventoryClickEvent inventoryClickEvent) {
        if (this.c.a((Entity)inventoryClickEvent.getWhoClicked()) && this.a(inventoryClickEvent.getView())) {
            inventoryClickEvent.setCancelled(an != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerItemHeldEvent playerItemHeldEvent) {
        if (this.c.a((PlayerEvent)playerItemHeldEvent)) {
            playerItemHeldEvent.setCancelled(ak != 0);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void a(ServerCommandEvent serverCommandEvent) {
        if (!this.o && serverCommandEvent instanceof Cancellable && serverCommandEvent.isCancelled() && this.a(serverCommandEvent.getCommand())) {
            serverCommandEvent.setCancelled(bd != 0);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void a(PlayerKickEvent playerKickEvent) {
        int n;
        String string = playerKickEvent.getReason();
        int n2 = n = string.equalsIgnoreCase((String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e80", (int)(t & u), (long)v)) || !this.a.b(this.g.b().a(playerKickEvent.getPlayer())) && string.equalsIgnoreCase((String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e83", (int)(w & x), (long)y)) ? z : aa;
        if (n != 0) {
            playerKickEvent.setCancelled(ab != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerPickupItemEvent playerPickupItemEvent) {
        if (this.c.a((PlayerEvent)playerPickupItemEvent)) {
            playerPickupItemEvent.setCancelled(ai != 0);
        }
    }

    private boolean a(Object object) {
        String string;
        if (object == null) {
            return ao != 0;
        }
        List<String> list = \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.D.a(new Object[ap]);
        if (list.isEmpty()) {
            return aq != 0;
        }
        try {
            string = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(object.getClass(), (String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e80", (int)(ar & as), (long)at), new Class[au]).invoke(object, new Object[av]).toString();
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException((String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e83", (int)aw, (long)(ax ^ ay)) + object.getClass().getCanonicalName() + (String)\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e86", (int)az, (long)(ba ^ bb)), reflectiveOperationException);
        }
        return list.stream().filter(Objects::nonNull).noneMatch(string2 -> \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.m(string2).contains(string));
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerFishEvent playerFishEvent) {
        if (this.c.a((PlayerEvent)playerFishEvent)) {
            playerFishEvent.setCancelled(af != 0);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void a(PlayerMoveEvent playerMoveEvent) {
        if (!\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.z.ar()) {
            return;
        }
        Player player = playerMoveEvent.getPlayer();
        Location location = playerMoveEvent.getFrom();
        Location location2 = playerMoveEvent.getTo();
        if (location2 != null && location.getY() > location2.getY() && (b == null || player.getGameMode() != b)) {
            return;
        }
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.a.b(this.g.b().a(player));
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a().b(\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.g) && \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.y) == false) {
            return;
        }
        playerMoveEvent.setTo(location);
    }

    @EventHandler(priority=EventPriority.LOW)
    public void b(PlayerJoinEvent playerJoinEvent) {
        ((\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5)this.g.a().b()).a(playerJoinEvent);
    }

    @EventHandler(priority=EventPriority.LOW)
    public void a(AsyncPlayerPreLoginEvent asyncPlayerPreLoginEvent) {
        if (asyncPlayerPreLoginEvent.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
            return;
        }
        InetAddress inetAddress = asyncPlayerPreLoginEvent.getAddress();
        if (inetAddress == null || inetAddress.getHostAddress() == null) {
            String[] stringArray = new String[a];
            stringArray[\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.b] = \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e80", (int)(c & d), (long)e);
            stringArray[\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.f] = \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e83", (int)g, (long)h);
            stringArray[\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.i] = \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e86", (int)j, (long)k);
            stringArray[\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.l] = \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e89", (int)m, (long)(n ^ o));
            stringArray[\u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.p] = \u03be\u03a6\u03bf\u03c6\u03c9\u03b1\u03bf\u03c3\u03bc.c("\u3e8c", (int)q, (long)r);
            asyncPlayerPreLoginEvent.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.g.b().a(playerCommandPreprocessEvent.getPlayer());
        String string = playerCommandPreprocessEvent.getMessage().trim();
        String string2 = this.g.a().b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string);
        if (string2 == null) {
            playerCommandPreprocessEvent.setCancelled(s != 0);
            return;
        }
        if (!string.equals(string2)) {
            playerCommandPreprocessEvent.setMessage(string2);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(InventoryOpenEvent inventoryOpenEvent) {
        HumanEntity humanEntity = inventoryOpenEvent.getPlayer();
        if (this.c.a((Entity)humanEntity) && this.a(inventoryOpenEvent.getView())) {
            inventoryOpenEvent.setCancelled(am != 0);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void b(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        if (!this.o && playerCommandPreprocessEvent.isCancelled() && this.a(playerCommandPreprocessEvent.getMessage())) {
            playerCommandPreprocessEvent.setCancelled(bc != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(PlayerEditBookEvent playerEditBookEvent) {
        if (this.c.a((PlayerEvent)playerEditBookEvent)) {
            playerEditBookEvent.setCancelled(ah != 0);
        }
    }
}

