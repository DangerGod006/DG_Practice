/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  com.nickuc.login.lib.packetevents.api.util.crypto.SignatureData
 *  com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper
 *  com.nickuc.login.lib.packetevents.api.wrapper.login.client.WrapperLoginClientLoginStart
 *  com.nickuc.login.lib.packetevents.impl.util.SpigotReflectionUtil
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.lib.packetevents.api.util.crypto.SignatureData;
import com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper;
import com.nickuc.login.lib.packetevents.api.wrapper.login.client.WrapperLoginClientLoginStart;
import com.nickuc.login.lib.packetevents.impl.util.SpigotReflectionUtil;
import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7;
import com.nickuc.login.\u03b6\u03bf\u03bb\u03c7\u0393\u03bf\u03c6\u03c3\u03bf\u03ba\u03bf\u03bc\u03c0;
import com.nickuc.login.\u03b7\u03a0\u03c4\u03a0\u03a9\u0394\u03b3\u03a6\u03c1\u03b4\u03c1;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c8\u03a9\u03b4\u03c9\u03c9\u03a0\u0394\u03bd\u03a0\u03b8\u03c0\u03bc\u03b6\u03c5;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyPair;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8 {
    private static int g;
    private static int ae;
    private static long ab;
    private static int z;
    private static String[] a;
    private static int l;
    private static long av;
    private static int u;
    private static long aq;
    private static int x;
    private static int k;
    private static int ac;
    private static long w;
    private static int v;
    private static long aa;
    private final KeyPair b;
    private final nLoginBukkit t;
    private static int m;
    public final \u03c8\u03a9\u03b4\u03c9\u03c9\u03a0\u0394\u03bd\u03a0\u03b8\u03c0\u03bc\u03b6\u03c5 a;
    private static int f;
    private static int h;
    private static final Method n;
    private static long aw;
    private static int ar;
    private static int s;
    @Generated
    private static final Logger c;
    private static int ao;
    private static int r;
    private static int y;
    private static int ah;
    private static final String bX;
    private static int b;
    private static int ag;
    private static int as;
    private static int ak;
    private static long e;
    private static int au;
    private static String[] b;
    private static long n;
    private static long am;
    public final \u03b6\u03bf\u03bb\u03c7\u0393\u03bf\u03c6\u03c3\u03bf\u03ba\u03bf\u03bc\u03c0 a = new \u03c8\u03a9\u03b4\u03c9\u03c9\u03a0\u0394\u03bd\u03a0\u03b8\u03c0\u03bc\u03b6\u03c5(this, null);
    private static long d;
    private static long c;
    private static int ad;
    private static long an;
    private static long j;
    private static long o;
    private static int p;
    private static final Method o;
    private static long ap;
    private static int t;
    private static long af;
    private static long ai;
    private static int a;
    private static int q;
    private static int at;
    private static long i;
    private static int al;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 y;
    private static long aj;

    static {
        a = 0 >>> 106 | 0 << ~106 + 1;
        b = (0 >>> 5 | 0 << ~5 + 1) & 0xFFFFFFFF;
        d = Long.reverse(3752268005612515544L);
        e = Long.reverse(0x5800000000000000L);
        f = 0x4000000 >>> 144 | 0x4000000 << ~144 + 1;
        g = Integer.reverse(0x8000000);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Long.reverse(3752268005612515544L);
        j = Long.reverse(0x5800000000000000L);
        k = 160 >>> 100 | 160 << -100;
        l = (0x14000000 >>> 153 | 0x14000000 << ~153 + 1) & 0xFFFFFFFF;
        m = Integer.reverse(0x40000000);
        n = Long.reverse(3752268005612515544L);
        o = Long.reverse(0x5800000000000000L);
        p = 32768 >>> 79 | 32768 << -79;
        q = Integer.reverse(0);
        r = 8192 >>> 108 | 8192 << ~108 + 1;
        s = (0 >>> 186 | 0 << ~186 + 1) & 0xFFFFFFFF;
        t = Integer.reverse(Integer.MIN_VALUE);
        u = (0x3000000 >>> 152 | 0x3000000 << ~152 + 1) & 0xFFFFFFFF;
        v = -1 >>> 188 | -1 << ~188 + 1;
        w = Long.reverse(7787493271736479960L);
        x = (262144 >>> 144 | 262144 << -144) & 0xFFFFFFFF;
        y = 0 >>> 100 | 0 << -100;
        z = 8192 >>> 171 | 8192 << ~171 + 1;
        aa = Long.reverse(3752268005612515544L);
        ab = Long.reverse(0x5800000000000000L);
        ac = Integer.reverse(Integer.MIN_VALUE);
        ad = Integer.reverse(-1610612736);
        ae = Integer.reverse(-1);
        af = Long.reverse(7787493271736479960L);
        ag = Integer.reverse(0x40000000);
        ah = Integer.reverse(0x60000000);
        ai = Long.reverse(3752268005612515544L);
        aj = Long.reverse(0x5800000000000000L);
        ak = Integer.reverse(-1073741824);
        al = (0x3800000 >>> 119 | 0x3800000 << ~119 + 1) & 0xFFFFFFFF;
        am = Long.reverse(3752268005612515544L);
        an = Long.reverse(0x5800000000000000L);
        ao = Integer.reverse(0x10000000);
        ap = Long.reverse(3752268005612515544L);
        aq = Long.reverse(0x5800000000000000L);
        ar = Integer.reverse(0x40000000);
        as = 0 >>> 159 | 0 << -159;
        at = Integer.reverse(Integer.MIN_VALUE);
        au = (9216 >>> 138 | 9216 << ~138 + 1) & 0xFFFFFFFF;
        av = Long.reverse(3752268005612515544L);
        aw = Long.reverse(0x5800000000000000L);
        a = new String[k];
        b = new String[l];
        \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b();
        bX = \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e80", (int)m, (long)(n ^ o));
        c = LoggerFactory.getLogger(\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.class);
        Method method = null;
        Class[] classArray = new Class[p];
        classArray[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.q] = SecretKey.class;
        Method method2 = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(SpigotReflectionUtil.NETWORK_MANAGER_CLASS, null, null, classArray);
        if (method2 == null) {
            Class[] classArray2 = new Class[r];
            classArray2[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.s] = Cipher.class;
            classArray2[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.t] = Cipher.class;
            method2 = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(SpigotReflectionUtil.NETWORK_MANAGER_CLASS, null, null, classArray2);
            if (method2 == null) {
                throw new IllegalArgumentException((String)\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e83", (int)(u & v), (long)w));
            }
            String[] stringArray = new String[x];
            stringArray[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.y] = \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e86", (int)z, (long)(aa ^ ab));
            stringArray[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.ac] = \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e89", (int)(ad & ae), (long)af);
            stringArray[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.ag] = \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e8c", (int)ah, (long)(ai ^ aj));
            stringArray[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.ak] = \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e8f", (int)al, (long)(am ^ an));
            Class<?> clazz = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray);
            if (clazz == null) {
                throw new IllegalArgumentException((String)\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e92", (int)ao, (long)(ap ^ aq)));
            }
            Class[] classArray3 = new Class[ar];
            classArray3[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.as] = Integer.TYPE;
            classArray3[\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.at] = Key.class;
            method = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(clazz, null, null, classArray3);
            if (method == null) {
                throw new IllegalArgumentException((String)\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e95", (int)au, (long)(av ^ aw)));
            }
        }
        n = method2;
        o = method;
    }

    @Generated
    private \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8(nLoginBukkit nLoginBukkit2, \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, KeyPair keyPair) {
        this.t = nLoginBukkit2;
        this.y = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
        this.b = keyPair;
    }

    private static KeyPair a(Server server) {
        Field field;
        KeyPair keyPair = null;
        Object object = SpigotReflectionUtil.getMinecraftServerInstance((Server)server);
        if (object != null && (field = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(SpigotReflectionUtil.MINECRAFT_SERVER_CLASS, KeyPair.class, a)) != null) {
            try {
                keyPair = (KeyPair)field.get(object);
            }
            catch (ReflectiveOperationException reflectiveOperationException) {
                throw new RuntimeException((String)\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e80", (int)b, (long)(d ^ e)), reflectiveOperationException);
            }
        }
        if (keyPair == null) {
            keyPair = \u03b7\u03a0\u03c4\u03a0\u03a9\u0394\u03b3\u03a6\u03c1\u03b4\u03c1.a(f);
        }
        return keyPair;
    }

    static /* synthetic */ void b(User user, WrapperLoginClientLoginStart wrapperLoginClientLoginStart, String string) {
        \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.a(user, wrapperLoginClientLoginStart, string);
    }

    static /* synthetic */ Method b() {
        return n;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0534\u0556\u0558\u0538\u055c\u057b\u0573\u0589\u0575\u0544\u0582\u0578\u0586\u0580\u0549\u056e\u0590\u058f\u0587\u058d\u0587\u055c", (byte)80, 70), \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u056f\u057c\u057b\u053e\u057e\u057a\u0575\u057e\u0589\u0578\u0545\u0583\u0587\u0580\u0583\u0589\u054b\u08ce\u08d2\u08de\u08d2\u08e5\u08c5\u08e6\u08c4\u08e1\u08e2\u08ee\u08e7\u08d1\u0564", (byte)80, 69) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0546", (byte)80, 69) + methodType.toString(), exception);
        }
    }

    private static void a(User user, WrapperLoginClientLoginStart wrapperLoginClientLoginStart, String string) {
        if (string.length() > g) {
            throw new IllegalArgumentException((String)\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.c("\u3e80", (int)h, (long)(i ^ j)) + string);
        }
        user.receivePacketSilently((PacketWrapper)new WrapperLoginClientLoginStart(wrapperLoginClientLoginStart.getClientVersion(), wrapperLoginClientLoginStart.getUsername(), (SignatureData)wrapperLoginClientLoginStart.getSignatureData().orElse(null), (UUID)wrapperLoginClientLoginStart.getPlayerUUID().orElse(null)));
    }

    static /* synthetic */ KeyPair a(\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8 \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82) {
        return \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82.b;
    }

    public \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8(nLoginBukkit nLoginBukkit2) {
        this(nLoginBukkit2, nLoginBukkit2.a(), \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.a(nLoginBukkit2.a()));
    }

    static /* synthetic */ \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a(\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8 \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82) {
        return \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82.y;
    }

    private static String a(int n, long l) {
        l ^= 0x1AL;
        l ^= 0x942F215925FDF4BAL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(17 + 52), (byte)(6 + 77), (byte)(38 + 9), (byte)(34 + 33), 66, (byte)(59 + 8), (byte)(24 + 23), (byte)(29 + 51), 75, (byte)(43 + 24), (byte)(9 + 74), (byte)(40 + 13), (byte)(15 + 65), (byte)(67 + 30), (byte)(41 + 59), (byte)(67 + 33), (byte)(18 + 87), (byte)(55 + 55), (byte)(58 + 45)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(17 + 51), (byte)(2 + 67), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0573\u0580\u057f\u0542\u0582\u057e\u0579\u0582\u058d\u057c\u0549\u0587\u058b\u0584\u0587\u058d\u054f\u08d2\u08d6\u08e2\u08d6\u08e9\u08c9\u08ea\u08c8\u08e5\u08e6\u08f2\u08eb\u08d5", (byte)84, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static /* synthetic */ nLoginBukkit a(\u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8 \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82) {
        return \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a82.t;
    }

    static /* synthetic */ Method a() {
        return o;
    }

    private static void b() {
        int n;
        c = 1949804752327755820L;
        long l = c ^ 0x942F215925FDF4BAL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(7 + 62), (byte)(61 + 22), (byte)(23 + 24), (byte)(48 + 19), (byte)(12 + 54), (byte)(37 + 30), (byte)(24 + 23), 80, (byte)(69 + 6), (byte)(8 + 59), (byte)(30 + 53), (byte)(39 + 14), (byte)(74 + 6), (byte)(88 + 9), (byte)(95 + 5), (byte)(88 + 12), (byte)(92 + 13), (byte)(17 + 93), (byte)(35 + 68)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(21 + 47), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u050c\u0539\u0533\u0511\u050c\u0517\u0537\u0527\u0548\u0502\u051f\u053c\u0516\u053f\u051b\u051f\u053b\u0543\u0525\u053e\u0544\u0513\u054e\u0543\u054c\u0545\u050f\u054b\u0527\u0517\u051b\u052f\u0547\u0558\u0550\u0560\u0519\u051a\u051d\u0535\u0555\u0537\u0563\u052e", (byte)10, 70);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u00d9\u00eb\u010d\u010b\u00ef\u00e3\u00f2\u00eb\u0100\u0111\u0101\u00d7\u0108\u00f7\u0108\u0114\u00fc\u010b\u0118\u00dc\u0111\u00fe\u00eb\u00ed\u00e1\u00dd\u011b\u00e0\u0112\u0116\u0106\u00f5\u0114\u0108\u010f\u00eb\u012a\u0102\u0130\u012c\u0108\u0125\u012b\u0134\u012e\u0104\u0117\u0104\u0137\u013e\u00f7\u0117\u0137\u012f\u0106\u0107", (byte)10, 65);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0100\u00db\u010a\u00e2\u00f1\u00ea\u00ec\u0111\u00cd\u0108\u0110\u00db", (byte)10, 66);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u051c\u052b\u052f\u0511\u050b\u04f6\u051c\u0505\u0523\u0508\u0549\u053c\u0523\u053c\u04ff\u0517\u0517\u0523\u054c\u0526\u052d\u0546\u050e\u0510\u0547\u0518\u0514\u0538\u0528\u0557\u0539\u053b\u0557\u0554\u0517\u0521\u053c\u0564\u0530\u0521\u0521\u0531\u0542\u0524\u0523\u0564\u056b\u052a\u054e\u0565\u0540\u0572\u0574\u055d\u0560\u0564\u0537\u0572\u0562\u0538\u0549\u0557\u056a\u054e", (byte)10, 69);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[4] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u00eb\u0102\u0108\u00e5\u0109\u00e1\u00f2\u0114\u00ca\u00dd\u00e3\u00f6\u00d2\u00d4\u00ea\u0103\u00da\u0105\u00eb\u0107\u0121\u00f9\u010e\u00ff\u011b\u00ef\u00e0\u010f\u0111\u0116\u0104\u00e9\u011b\u0119\u00e8\u010e\u00ee\u011a\u0100\u010f\u00ed\u010b\u012f\u00f2\u0134\u0114\u011a\u010b\u0107\u00f6\u0116\u011c\u0111\u012f\u0106\u0107", (byte)10, 65);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[5] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u042b\u0442\u0448\u0425\u0449\u0421\u0432\u0454\u040a\u041d\u0423\u0436\u0412\u0414\u042a\u0443\u041a\u0445\u042b\u0447\u0461\u043e\u0419\u045e\u0455\u045f\u0418\u0448\u0435\u0448\u0466\u0462\u0434\u043f\u045d\u043c\u043c\u0468\u044c\u0467\u0472\u0432\u0464\u043b", (byte)10, 67);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[6] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00eb\u0102\u0108\u00e5\u0109\u00e1\u00f2\u0114\u00ca\u00dd\u00e3\u00f6\u00d2\u00d4\u00ea\u0103\u00da\u0105\u00eb\u0107\u0121\u00fe\u00d9\u011e\u0115\u011f\u00d8\u0108\u00f5\u0108\u0126\u0122\u0100\u00f7\u012d\u00ef\u0125\u010b\u0101\u012d\u011c\u0112\u0124\u00fb", (byte)10, 65);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[7] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u051c\u04fe\u0538\u0540\u0503\u0514\u0544\u0518\u051e\u0540\u0519\u053b\u0533\u0525\u0524\u054a\u0519\u0548\u054e\u0528\u0543\u0541\u0533\u053f\u054a\u0548\u0533\u0539\u0511\u0550\u0526\u0539\u0537\u055f\u0555\u054d\u0564\u0564\u0534\u053c\u0550\u0530\u0567\u052e", (byte)10, 70);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[8] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u051c\u052b\u052f\u0511\u050b\u04f6\u051c\u0505\u0523\u0508\u0549\u053c\u051d\u0546\u052d\u0518\u0520\u0508\u054f\u0520\u0544\u0526\u053d\u0514\u0558\u0554\u0528\u0517\u0536\u051a\u053e\u0528\u053e\u052f\u0551\u053e\u0557\u055f\u0531\u0562\u0536\u055e\u0555\u0541\u0529\u0566\u0558\u056d\u055d\u0538\u055c\u054d\u0541\u0562\u0539\u053a", (byte)10, 70);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[9] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00e9\u00f8\u00fc\u00de\u00d8\u00c3\u00e9\u00d2\u00f0\u00d5\u0117\u010b\u00e5\u00ed\u0114\u00f1\u0119\u00ea\u0119\u00fa\u00d8\u00fc\u0119\u0104\u00dc\u0118\u0125\u00fc\u00df\u0120\u00e3\u00ea\u00e5\u00e4\u0122\u0129\u010e\u010d\u010e\u0124\u0105\u0125\u011e\u0127\u0100\u00f4\u012c\u0126\u0135\u00fc\u00fd\u010a\u0137\u012d\u012c\u0116\u0113\u0138\u0126\u0101\u0107\u0140\u011b\u0116\u012c\u014c\u013d\u0106\u0147\u012b\u013a\u013d\u012e\u010c\u0153\u012a\u0145\u0135\u0148\u0149\u012a\u0146\u0147\u011d\u014a\u0129\u0126\u0127", (byte)10, 65);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u00d9\u0106\u0100\u00de\u00d9\u00e4\u0104\u00f4\u0115\u00cf\u00ec\u0109\u00e3\u010c\u00e8\u00ec\u0108\u0110\u00f2\u010b\u0111\u00e0\u011b\u0110\u0119\u0112\u00dc\u0118\u00f4\u00e4\u00e8\u00fc\u0104\u00f6\u0104\u00e6\u0105\u012d\u012a\u011d\u011d\u0120\u0110\u0116\u0125\u0132\u010e\u0113\u012d\u011d\u0136\u013e\u011b\u0109\u0106\u0107", (byte)10, 65);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0419\u042b\u044d\u044b\u042f\u0423\u0432\u042b\u0440\u0451\u0441\u0417\u0448\u0437\u0448\u0454\u043c\u044b\u0458\u041c\u0451\u043e\u042b\u042d\u0421\u041d\u045b\u0420\u0452\u0456\u0446\u0435\u0454\u0448\u044f\u042b\u046a\u0442\u0470\u046c\u0448\u0465\u046a\u0456\u0466\u046a\u0436\u044c\u0447\u044c\u046b\u0453\u044d\u0459\u0446\u0447", (byte)10, 67);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[2] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0529\u04f2\u0530\u0520\u050c\u050e\u052d\u053e\u0521\u0503\u0500\u050e", (byte)10, 69);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0429\u0438\u043c\u041e\u0418\u0403\u0429\u0412\u0430\u0415\u0456\u0449\u0430\u0449\u040c\u0424\u0424\u0430\u0459\u0433\u043a\u0453\u041b\u041d\u0454\u0425\u0421\u0445\u0435\u0464\u0446\u0448\u0464\u0461\u0424\u042e\u0449\u0471\u043d\u042e\u042e\u043e\u044f\u0431\u0430\u0471\u0478\u0437\u045b\u0472\u044d\u047f\u0481\u0459\u047c\u0442\u0470\u0444\u0445\u047e\u0441\u0459\u0482\u045e\u0466\u047d\u0468\u0457\u0450\u0468\u045d\u0450\u046c\u048c\u0466\u045b", (byte)10, 67);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u051e\u0535\u053b\u0518\u053c\u0514\u0525\u0547\u04fd\u0510\u0516\u0529\u0505\u0507\u051d\u0536\u050d\u0538\u051e\u053a\u0554\u052c\u0541\u0532\u054e\u0522\u0513\u0542\u0544\u0549\u0537\u051c\u054e\u054c\u051b\u0541\u0521\u054d\u0533\u0542\u0520\u053e\u0562\u0535\u0563\u054a\u055d\u0561\u053f\u0549\u053f\u0567\u056c\u0542\u054d\u0567\u054b\u0573\u0571\u054f\u0536\u0538\u056f\u055b", (byte)10, 69);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[5] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u042b\u0442\u0448\u0425\u0449\u0421\u0432\u0454\u040a\u041d\u0423\u0436\u0412\u0414\u042a\u0443\u041a\u0445\u042b\u0447\u0461\u043e\u0419\u045e\u0455\u045f\u0418\u0448\u0435\u0448\u0466\u0462\u0466\u045a\u0437\u0467\u045e\u0470\u0452\u045e\u044b\u044f\u0446\u043b", (byte)10, 68);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[6] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u042b\u0442\u0448\u0425\u0449\u0421\u0432\u0454\u040a\u041d\u0423\u0436\u0412\u0414\u042a\u0443\u041a\u0445\u042b\u0447\u0461\u043e\u0419\u045e\u0455\u045f\u0418\u0448\u0435\u0448\u0466\u0462\u0435\u0427\u0438\u0428\u043f\u044b\u0452\u046e\u0475\u042f\u0453\u0457\u0442\u0464\u0459\u0459\u043a\u0447\u0477\u047b\u0437\u047f\u0446\u0447", (byte)10, 67);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0429\u040b\u0445\u044d\u0410\u0421\u0451\u0425\u042b\u044d\u0426\u0448\u0440\u0432\u0431\u0457\u0426\u0455\u045b\u0435\u0450\u044e\u0440\u044c\u0457\u0455\u0440\u0446\u041e\u045d\u0433\u0446\u0458\u0427\u0440\u044f\u045d\u0446\u0466\u0472\u0468\u0462\u0435\u043b", (byte)10, 67);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[8] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u051c\u052b\u052f\u0511\u050b\u04f6\u051c\u0505\u0523\u0508\u0549\u053c\u051d\u0546\u052d\u0518\u0520\u0508\u054f\u0520\u0544\u0526\u053d\u0514\u0558\u0554\u0528\u0517\u0536\u051a\u053e\u0528\u053e\u052f\u0551\u053e\u0557\u055f\u0531\u0562\u0536\u055e\u0555\u053e\u0524\u0548\u053a\u0529\u056d\u0551\u0562\u0549\u056e\u0547\u054c\u0528\u0542\u0574\u0574\u0536\u0566\u0534\u053c\u0557", (byte)10, 69);
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[9] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u051c\u052b\u052f\u0511\u050b\u04f6\u051c\u0505\u0523\u0508\u054a\u053e\u0518\u0520\u0547\u0524\u054c\u051d\u054c\u052d\u050b\u052f\u054c\u0537\u050f\u054b\u0558\u052f\u0512\u0553\u0516\u051d\u0518\u0517\u0555\u055c\u0541\u0540\u0541\u0557\u0538\u0558\u0551\u055a\u0533\u0527\u055f\u0559\u0568\u052f\u0530\u053d\u056a\u0560\u055f\u0549\u0546\u056b\u0559\u0534\u053a\u0573\u054e\u0549\u055f\u057f\u0570\u0539\u057a\u055e\u056d\u0570\u0561\u053f\u0586\u058a\u055e\u0567\u0578\u056d\u055b\u0549\u054b\u058a\u0585\u0582\u0559\u055a", (byte)10, 69);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u041f\u043d\u044c\u043c\u044e\u0431\u0451\u0440\u0411\u0432\u0422\u0428\u0434\u0413\u0438\u044e\u045d\u0430\u0435\u045d\u042b\u0433\u0456\u0456\u0424\u0451\u0423\u0441\u0457\u0441\u046a\u043b", (byte)10, 67);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03b4\u03bf\u03b2\u03c4\u03a3\u03c3\u03a0\u03bc\u03bc\u03c7\u03bf\u03a8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u041e\u0426\u0438\u040f\u0407\u0426\u0411\u0449\u0426\u0422\u0440\u042b\u0458\u0427\u0451\u041a\u0455\u0453\u0451\u044a\u041d\u045f\u0426\u0427", (byte)10, 68);
                }
            }
        }
    }
}

