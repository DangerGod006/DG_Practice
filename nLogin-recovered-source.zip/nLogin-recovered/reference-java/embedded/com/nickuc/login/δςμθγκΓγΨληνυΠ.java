/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.nLoginAPI
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0;
import com.nickuc.login.\u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import com.nickuc.login.\u03b3\u03a6\u03c2\u03b8\u03b4\u03c8\u03b5\u03b3\u03c9\u03a9\u03c7\u03c9\u03ba\u03c4\u03be;
import com.nickuc.login.\u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c4\u03bc\u03b4\u03c7\u03a3\u03bb\u03b2\u03a6\u03ba\u03b1;
import com.nickuc.login.\u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03c2\u03bc\u03b8\u03b3\u03ba\u0393\u03b3\u03a8\u03bb\u03b7\u03bd\u03c5\u03a0
implements \u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8 {
    private static int c;
    private final nLoginBukkit m;
    private static int b;
    private static int a;
    private static int d;

    @Override
    public void c() {
    }

    @Generated
    public \u03b4\u03c2\u03bc\u03b8\u03b3\u03ba\u0393\u03b3\u03a8\u03bb\u03b7\u03bd\u03c5\u03a0(nLoginBukkit nLoginBukkit2) {
        this.m = nLoginBukkit2;
    }

    @Override
    public boolean a() {
        return \u03b4\u03c8\u03c6\u03a8\u03c3\u03c8\u03b5\u03bb\u0393.a(this.m, b != 0);
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(Integer.MIN_VALUE);
        c = (0x400000 >>> 22 | 0x400000 << -22) & 0xFFFFFFFF;
        d = (0 >>> 18 | 0 << -18) & 0xFFFFFFFF;
    }

    @Override
    public void b() {
        \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 = this.m.a();
        this.m.b().c().forEach(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 -> \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.p, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[d])));
        \u03b3\u03a6\u03c2\u03b8\u03b4\u03c8\u03b5\u03b3\u03c9\u03a9\u03c7\u03c9\u03ba\u03c4\u03be.a(this.m, a != 0);
        this.m.a().n();
    }

    @Override
    public \u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0 a() {
        return new \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.m.b(), this.m, c != 0);
    }

    @Override
    public nLoginAPI a() {
        return new \u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393(this.m);
    }

    @Override
    public \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 a() {
        return new \u03c4\u03bc\u03b4\u03c7\u03a3\u03bb\u03b2\u03a6\u03ba\u03b1(this.m);
    }

    @Override
    public \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6 a() {
        return new \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6(this.m);
    }
}

