/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7;
import com.nickuc.login.\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0;

class \u03bf\u03a8\u03c4\u03bc\u03c2\u03ba\u03a6\u03b8\u03b7\u03a9\u03b2\u03a9\u03a8\u03b7\u03bb {
    static final /* synthetic */ int[] f;
    private static int b;
    private static int c;
    private static int a;
    static final /* synthetic */ int[] e;
    private static int d;

    static {
        a = 32768 >>> 111 | 32768 << -111;
        b = Integer.reverse(0x40000000);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = 0x200000 >>> 244 | 0x200000 << ~244 + 1;
        f = new int[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.values().length];
        try {
            \u03bf\u03a8\u03c4\u03bc\u03c2\u03ba\u03a6\u03b8\u03b7\u03a9\u03b2\u03a9\u03a8\u03b7\u03bb.f[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bf\u03a8\u03c4\u03bc\u03c2\u03ba\u03a6\u03b8\u03b7\u03a9\u03b2\u03a9\u03a8\u03b7\u03bb.f[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        e = new int[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.values().length];
        try {
            \u03bf\u03a8\u03c4\u03bc\u03c2\u03ba\u03a6\u03b8\u03b7\u03a9\u03b2\u03a9\u03a8\u03b7\u03bb.e[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.e.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bf\u03a8\u03c4\u03bc\u03c2\u03ba\u03a6\u03b8\u03b7\u03a9\u03b2\u03a9\u03a8\u03b7\u03bb.e[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.f.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

