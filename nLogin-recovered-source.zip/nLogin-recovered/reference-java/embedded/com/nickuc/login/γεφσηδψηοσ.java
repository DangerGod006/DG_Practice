/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerCommandSendEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import java.util.Locale;
import java.util.Set;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerCommandSendEvent;

public class \u03b3\u03b5\u03c6\u03c3\u03b7\u03b4\u03c8\u03b7\u03bf\u03c3
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private final Set<String> f;
    private static int a = Integer.reverse(0x5C000000);
    private static int c;
    private static int b;
    private final String ad;

    static {
        b = 32768 >>> 79 | 32768 << ~79 + 1;
        c = (0 >>> 86 | 0 << -86) & 0xFFFFFFFF;
    }

    @Generated
    \u03b3\u03b5\u03c6\u03c3\u03b7\u03b4\u03c8\u03b7\u03bf\u03c3(String string, Set<String> set) {
        this.ad = string;
        this.f = set;
    }

    @EventHandler(priority=EventPriority.LOW)
    public void a(PlayerCommandSendEvent playerCommandSendEvent) {
        playerCommandSendEvent.getCommands().removeIf(string -> ((string = string.toLowerCase(Locale.ENGLISH)).startsWith(this.ad + (char)a) || this.f.contains(string) ? b : c) != 0);
    }
}

