/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a3\u03a3\u03c0\u03b4\u03b2\u03c9\u03a6\u03b4\u03b9\u03c2\u03b4\u03c2\u03c8\u03a3\u03c2;
import com.nickuc.login.\u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc
implements \u03a3\u03a3\u03c0\u03b4\u03b2\u03c9\u03a6\u03b4\u03b9\u03c2\u03b4\u03c2\u03c8\u03a3\u03c2 {
    private static String[] b;
    private static int g;
    private static long d;
    private final \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9 c;
    private static long e;
    private static long j;
    private static int b;
    private static String[] a;
    private static int o;
    private static long c;
    private static int f;
    private static long p;
    private static int m;
    private static int h;
    private static int a;
    private static int n;
    private static int k;
    private static long i;
    private static final String cw;
    private static int l;

    @Override
    public boolean filter(String string, String string2, Object ... objectArray) {
        if (objectArray.length == a && string2.contains((CharSequence)\u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.c("\u3e80", (int)b, (long)(d ^ e)))) {
            String string3 = (char)f + (String)objectArray[g];
            String string4 = string3.split((String)\u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.c("\u3e83", (int)h, (long)(i ^ j)))[k].toLowerCase(Locale.ENGLISH);
            return this.c.a().stream().anyMatch(string4::equals);
        }
        return l != 0;
    }

    /* synthetic */ \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9 \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92, \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0 \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c02) {
        this(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92);
    }

    private static void b() {
        int n;
        c = 8952395262487060646L;
        long l = c ^ 0xF0C1F85DDA7795C3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), 69, (byte)(74 + 9), (byte)(43 + 4), (byte)(54 + 13), (byte)(49 + 17), (byte)(35 + 32), (byte)(26 + 21), (byte)(46 + 34), (byte)(45 + 30), (byte)(66 + 1), (byte)(76 + 7), (byte)(48 + 5), 80, (byte)(45 + 52), (byte)(3 + 97), (byte)(82 + 18), (byte)(71 + 34), (byte)(23 + 87), (byte)(71 + 32)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(42 + 41)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u04b1\u04bc\u04c3\u0496\u04b6\u0495\u049c\u0494\u04b1\u04b8\u04c5\u04b4\u04ad\u0480\u04bc\u0488\u04bf\u0492\u0490\u04a5\u04d5\u04c9\u048d\u04d1\u0492\u04c7\u04d4\u04c9\u04dc\u0495\u04b3\u04b9", (byte)49, 68);
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u053c\u051f\u0549\u0527\u0527\u0539\u051e\u0564\u0563\u0529\u0527\u0535", (byte)49, 69);
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04b1\u04bc\u04c3\u0496\u04b6\u0495\u049c\u0494\u04b1\u04b8\u04c5\u04b4\u04ad\u0480\u04bc\u0488\u04bf\u0492\u0490\u04a5\u04d5\u04c9\u048d\u04d1\u0492\u04c7\u04d4\u04c9\u04dc\u0495\u04b3\u04b9", (byte)49, 67);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u014a\u0155\u015c\u012f\u014f\u012e\u0135\u012d\u014a\u0151\u015e\u014d\u0146\u0119\u0155\u0121\u0158\u012b\u0129\u013e\u016e\u0168\u016c\u0127\u0132\u0169\u016a\u016c\u0128\u0149\u0170\u0172", (byte)49, 66);
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0531\u0533\u0567\u056a\u0552\u0561\u0522\u0543\u053c\u0569\u0566\u0535", (byte)49, 70);
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[2] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u04b1\u04bc\u04c3\u0496\u04b6\u0495\u049c\u0494\u04b1\u04b8\u04c5\u04b4\u04ad\u0480\u04bc\u0488\u04bf\u0492\u0490\u04a5\u04d5\u04cd\u04a8\u0491\u04c1\u04cf\u04c5\u04d8\u04b6\u049a\u04c8\u04ad", (byte)49, 68);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0499\u048d\u04ab\u0490\u04a5\u04a5\u049b\u049f\u0487\u0488\u04b9\u04a2\u04c1\u048a\u0488\u04bf\u048b\u04ca\u04c1\u04b2\u04b5\u04d4\u049b\u049c", (byte)49, 68);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04af\u04ba\u049f\u04b1\u0496\u04b2\u04c0\u04a8\u049f\u0494\u04b5\u0490", (byte)49, 67);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u03dd\u03ff\u0401\u03e1\u0405\u0424\u041c\u0432\u041e\u03ed\u042b\u0421\u042f\u0429\u03f2\u0417\u0439\u0438\u0430\u0436\u0430\u0405", (byte)0, 67), \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0418\u0425\u0424\u03e7\u0427\u0423\u041e\u0427\u0432\u0421\u03ee\u042c\u0430\u0429\u042c\u0432\u03f4\u0777\u0787\u078e\u078b\u077c\u075e\u0794\u0773\u0780\u0789\u0794\u076c\u078e\u040d", (byte)0, 67) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u04f6", (byte)0, 70) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 4L;
        l ^= 0xF0C1F85DDA7795C3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(41 + 27), (byte)(49 + 20), (byte)(35 + 48), (byte)(6 + 41), (byte)(42 + 25), (byte)(63 + 3), (byte)(19 + 48), 47, 80, (byte)(21 + 54), (byte)(12 + 55), (byte)(62 + 21), (byte)(16 + 37), (byte)(66 + 14), (byte)(4 + 93), (byte)(40 + 60), (byte)(9 + 91), (byte)(9 + 96), (byte)(72 + 38), (byte)(11 + 92)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(16 + 52), (byte)(36 + 33), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0590\u059d\u059c\u055f\u059f\u059b\u0596\u059f\u05aa\u0599\u0566\u05a4\u05a8\u05a1\u05a4\u05aa\u056c\u08ef\u08ff\u0906\u0903\u08f4\u08d6\u090c\u08eb\u08f8\u0901\u090c\u08e4\u0906", (byte)113, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = 0x20000000 >>> 188 | 0x20000000 << ~188 + 1;
        b = (0 >>> 76 | 0 << -76) & 0xFFFFFFFF;
        d = Long.reverse(7279636332827294782L);
        e = Long.reverse(0x2000000000000000L);
        f = (0xBC0000 >>> 178 | 0xBC0000 << -178) & 0xFFFFFFFF;
        g = (512 >>> 9 | 512 << -9) & 0xFFFFFFFF;
        h = (256 >>> 8 | 256 << ~8 + 1) & 0xFFFFFFFF;
        i = Long.reverse(7279636332827294782L);
        j = Long.reverse(0x2000000000000000L);
        k = 0 >>> 52 | 0 << ~52 + 1;
        l = (0 >>> 88 | 0 << ~88 + 1) & 0xFFFFFFFF;
        m = Integer.reverse(-1073741824);
        n = Integer.reverse(-1073741824);
        o = (0x200000 >>> 180 | 0x200000 << -180) & 0xFFFFFFFF;
        p = Long.reverse(4973793323613600830L);
        a = new String[m];
        b = new String[n];
        \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.b();
        cw = \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc.c("\u3e80", (int)o, (long)p);
    }

    @Generated
    private \u03b1\u03c0\u03c6\u03c2\u03b2\u0393\u03c8\u03a6\u03b2\u03ba\u03c4\u039b\u03bc(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9 \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92) {
        this.c = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92;
    }
}

