/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerSystemChatMessage
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TranslatableComponent
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerSystemChatMessage;
import com.nickuc.login.\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TranslatableComponent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4
implements \u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b {
    private static long h;
    private static int c;
    private static long d;
    private static int s;
    private static long e;
    private static String[] b;
    private static long b;
    private static int g;
    private static long o;
    private static long k;
    private static int m;
    final /* synthetic */ \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 d;
    private static int t;
    private static long c;
    private static int i;
    private static long n;
    private static int a;
    private static int l;
    private static long j;
    private static int f;
    private static int q;
    private static String[] a;
    private static int p;
    private static int r;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0532\u0554\u0556\u0536\u055a\u0579\u0571\u0587\u0573\u0542\u0580\u0576\u0584\u057e\u0547\u056c\u058e\u058d\u0585\u058b\u0585\u055a", (byte)78, 70), \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0502\u050f\u050e\u04d1\u0511\u050d\u0508\u0511\u051c\u050b\u04d8\u0516\u051a\u0513\u0516\u051c\u04de\u0843\u0872\u0846\u0873\u0847\u0872\u087e\u085d\u086c\u087d\u04f4", (byte)78, 67) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u04d9", (byte)78, 68) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x44L;
        l ^= 0x353AF49D9A0EF46FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(29 + 40), (byte)(42 + 41), (byte)(34 + 13), (byte)(39 + 28), (byte)(19 + 47), (byte)(33 + 34), (byte)(39 + 8), (byte)(52 + 28), (byte)(38 + 37), 67, (byte)(74 + 9), (byte)(2 + 51), 80, (byte)(56 + 41), (byte)(50 + 50), (byte)(74 + 26), (byte)(24 + 81), (byte)(88 + 22), (byte)(100 + 3)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(55 + 28)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u054f\u055c\u055b\u051e\u055e\u055a\u0555\u055e\u0569\u0558\u0525\u0563\u0567\u0560\u0563\u0569\u052b\u0890\u08bf\u0893\u08c0\u0894\u08bf\u08cb\u08aa\u08b9\u08ca", (byte)48, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -8555349894714872711L;
        long l = c ^ 0x353AF49D9A0EF46FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(43 + 26), (byte)(33 + 50), (byte)(3 + 44), 67, (byte)(11 + 55), (byte)(23 + 44), (byte)(14 + 33), (byte)(4 + 76), (byte)(21 + 54), (byte)(23 + 44), (byte)(81 + 2), (byte)(31 + 22), (byte)(13 + 67), 97, (byte)(79 + 21), (byte)(52 + 48), (byte)(47 + 58), (byte)(107 + 3), (byte)(85 + 18)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(18 + 51), (byte)(60 + 23)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u01ad\u01a4\u01d0\u0192\u01ce\u01c9\u019f\u01b3\u01b4\u01b9\u01ab\u01a5\u0196\u01aa\u019b\u01ce\u019e\u01d0\u01af\u01df\u01e5\u01bd\u01a0\u01c7\u01c3\u01b3\u01cb\u01bc\u01c7\u01bf\u01d8\u01cd\u01de\u01bf\u01c3\u01ae\u01ef\u01ca\u01e6\u01e2\u01c5\u01c4\u01fa\u01f7\u01cd\u01f4\u01d1\u01dc\u01f0\u01bc\u01d5\u0202\u0204\u01cd\u01ca\u01cb", (byte)108, 65);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u01bd\u01ba\u01c4\u019f\u01ca\u01c9\u018d\u01b4\u01d4\u01c7\u0192\u0191\u0199\u0199\u01ad\u01cd\u01bc\u01aa\u01cf\u01dd\u01ad\u01d4\u019f\u01c2\u01a5\u01a8\u01b6\u01e1\u01a6\u01e1\u01cb\u01ba\u01c0\u01be\u01bb\u01c8\u01f0\u01c1\u01c5\u01ad\u01cc\u01e9\u01d1\u01d6\u01f5\u01fe\u01ec\u01dc\u01f8\u01d0\u01d0\u01fa\u01e4\u01dd\u01ca\u01cb", (byte)108, 66);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u057e\u0575\u05a1\u0563\u059f\u059a\u0570\u0584\u0585\u058a\u057c\u0576\u0567\u057b\u056c\u059f\u056f\u05a1\u0580\u05b0\u05b6\u058e\u0571\u0598\u0594\u0584\u059c\u058d\u0598\u0590\u05a9\u059e\u05af\u0590\u0594\u057f\u05c0\u059b\u05b7\u05b3\u0596\u0595\u05cb\u05c8\u059e\u05c5\u05a2\u05ad\u05c1\u058d\u05a6\u05d3\u05d5\u059e\u059b\u059c", (byte)108, 69);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u01cc\u01a7\u01cd\u01cc\u01d3\u01cf\u01b5\u01b8\u01aa\u01ac\u0191\u019f", (byte)108, 66);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[4] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u01cc\u018f\u01ac\u01b2\u01bd\u0195\u01a8\u01b0\u018e\u01aa\u01b3\u01db\u01a8\u01d7\u01b5\u01df\u01d0\u01ba\u01b3\u01cf\u01d1\u01e5\u01d3\u01e1\u01df\u01e9\u01e4\u01bb\u01b7\u01b8\u01a4\u01ab\u01ef\u01af\u01c5\u01ab\u01d2\u01e8\u01b0\u01a9\u01c0\u01b3\u01f2\u01c9\u01c8\u01bb\u01de\u01eb\u01d6\u01ef\u01f6\u01df\u01de\u01cd\u01ca\u01cb", (byte)108, 66);
                    continue block7;
                }
                case 1: {
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u054f\u0546\u0572\u0534\u0570\u056b\u0541\u0555\u0556\u055b\u054d\u0547\u0538\u054c\u053d\u0570\u0540\u0572\u0551\u0581\u0587\u055f\u0542\u0569\u0565\u0555\u056d\u055e\u0569\u0561\u057a\u056f\u0580\u0561\u0565\u0550\u0591\u056c\u0588\u0584\u0567\u0566\u059b\u0579\u0569\u056c\u058e\u0597\u0559\u057b\u059c\u0564\u057a\u0595\u056c\u056d", (byte)108, 68);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u055f\u055c\u0566\u0541\u056c\u056b\u052f\u0556\u0576\u0569\u0534\u0533\u053b\u053b\u054f\u056f\u055e\u054c\u0571\u057f\u054f\u0576\u0541\u0564\u0547\u054a\u0558\u0583\u0548\u0583\u056d\u055c\u0562\u0560\u055d\u056a\u0592\u0563\u0567\u054f\u056e\u058b\u0572\u056d\u058c\u059b\u058c\u055c\u055e\u05a0\u058f\u056f\u0578\u056f\u056c\u056d", (byte)108, 67);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u054f\u0546\u0572\u0534\u0570\u056b\u0541\u0555\u0556\u055b\u054d\u0547\u0538\u054c\u053d\u0570\u0540\u0572\u0551\u0581\u0587\u055f\u0542\u0569\u0565\u0555\u056d\u055e\u0569\u0561\u057a\u056f\u0580\u0561\u0565\u0550\u0591\u056c\u0588\u0584\u0567\u0566\u059b\u058d\u056d\u0575\u0571\u059f\u0595\u056c\u059c\u059c\u057e\u056f\u056c\u056d", (byte)108, 67);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u052b\u0563\u0545\u0531\u0545\u0553\u0554\u0551\u0566\u0574\u0576\u0541", (byte)108, 68);
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u01cc\u018f\u01ac\u01b2\u01bd\u0195\u01a8\u01b0\u018e\u01aa\u01b3\u01db\u01a8\u01d7\u01b5\u01df\u01d0\u01ba\u01b3\u01cf\u01d1\u01e5\u01d3\u01e1\u01df\u01e9\u01e4\u01bb\u01b7\u01b8\u01a4\u01ab\u01ef\u01af\u01c5\u01ab\u01d2\u01e8\u01b0\u01a9\u01c0\u01b3\u01f0\u01c6\u01f8\u01f4\u01cd\u01bd\u01cc\u01d8\u01e2\u01f2\u01ec\u0203\u01ca\u01cb", (byte)108, 66);
                    continue block7;
                }
                case 2: {
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01c3\u01bc\u01c7\u01a9\u01cd\u01cb\u01c1\u01d6\u01b0\u01c6\u01ae\u01c4\u01c7\u01d4\u01b7\u01de\u01c1\u01e1\u01bd\u01dd\u01b3\u01d3\u01aa\u01ab", (byte)108, 65);
                    continue block7;
                }
                case 4: {
                    \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u01d0\u019f\u01a6\u01a5\u019d\u0193\u01c6\u01cb\u01c5\u0194\u01d4\u01d1\u01dd\u01aa\u01b2\u01d7\u01c1\u01cd\u01b2\u01d3\u019b\u01ad\u01aa\u01ab", (byte)108, 65);
                }
            }
        }
    }

    /* synthetic */ \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393, \u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7 \u03bb\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7) {
        this(\u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393);
    }

    @Override
    public void a(PacketSendEvent packetSendEvent) {
        Object object;
        WrapperPlayServerSystemChatMessage wrapperPlayServerSystemChatMessage;
        if (!\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.an.ar()) {
            return;
        }
        Object object2 = packetSendEvent.getPlayer();
        if (object2 == null) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.d).b().a(object2);
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.d).a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 == null) {
            return;
        }
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a().b(\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.f)) {
            return;
        }
        try {
            wrapperPlayServerSystemChatMessage = new WrapperPlayServerSystemChatMessage(packetSendEvent);
        }
        catch (Throwable throwable) {
            if (\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.aj() || !(throwable instanceof IllegalArgumentException)) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.c("\u3e80", (int)a, (long)b) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName() + (String)\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.c("\u3e83", (int)c, (long)(d ^ e)), throwable, new Object[f]);
            } else {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.c("\u3e86", (int)g, (long)h) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName() + (String)\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.c("\u3e89", (int)i, (long)(j ^ k)) + throwable.getMessage(), new Object[l]);
            }
            return;
        }
        if (wrapperPlayServerSystemChatMessage.isOverlay()) {
            return;
        }
        Component component = wrapperPlayServerSystemChatMessage.getMessage();
        if (component instanceof TranslatableComponent) {
            object = (TranslatableComponent)component;
            if (((String)\u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.c("\u3e8c", (int)m, (long)(n ^ o))).equals(object.key())) {
                packetSendEvent.setCancelled(p != 0);
                return;
            }
        }
        if ((object = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.l, string -> new ArrayList())).size() < q) {
            object.add(component);
        }
        packetSendEvent.setCancelled(r != 0);
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-4885250925526867311L);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Long.reverse(-7046978746664705391L);
        e = Long.reverse(0x2200000000000000L);
        f = Integer.reverse(0);
        g = Integer.reverse(0x40000000);
        h = Long.reverse(-4885250925526867311L);
        i = Integer.reverse(-1073741824);
        j = Long.reverse(-7046978746664705391L);
        k = Long.reverse(0x2200000000000000L);
        l = 0 >>> 28 | 0 << ~28 + 1;
        m = Integer.reverse(0x20000000);
        n = Long.reverse(-7046978746664705391L);
        o = Long.reverse(0x2200000000000000L);
        p = (16 >>> 164 | 16 << -164) & 0xFFFFFFFF;
        q = Integer.reverse(-268435456);
        r = Integer.reverse(Integer.MIN_VALUE);
        s = (5120 >>> 170 | 5120 << ~170 + 1) & 0xFFFFFFFF;
        t = Integer.reverse(-1610612736);
        a = new String[s];
        b = new String[t];
        \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4.b();
    }

    @Generated
    private \u0393\u03c1\u0394\u03c0\u0393\u03bd\u03c8\u03a6\u03b4\u03c4(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393) {
        this.d = \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
    }
}

