/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c2\u03b4\u03c9\u03bb\u03bb\u03bd\u03b4\u03b4;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0
extends \u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 {
    private static int bq;
    private static int l;
    private static int bu;
    private static int bz;
    private static long af;
    private static int ao;
    private static int bp;
    private final String I;
    private static long aq;
    private static int bi;
    private static int bf;
    private static int m;
    private static int cb;
    private static int bn;
    private static int c;
    private static int bx;
    private static long o;
    private static int z;
    private static long az;
    private static int ch;
    private static int cc;
    private static int ae;
    private static long ak;
    private static long i;
    private static long aw;
    private static long h;
    private static long e;
    private static int ce;
    private static int bt;
    private static int be;
    private static int bk;
    private static String[] c;
    private static int w;
    private static long an;
    private static int bc;
    private static long ar;
    private static int ax;
    private static int t;
    private static long ah;
    private static long n;
    private static String[] d;
    private static int ai;
    private static int av;

    private static void b() {
        int n;
        e = -5849178998515416107L;
        long l = e ^ 0xAF71B1AA6559C656L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(20 + 49), (byte)(29 + 54), (byte)(42 + 5), (byte)(36 + 31), (byte)(36 + 30), 67, (byte)(46 + 1), (byte)(67 + 13), (byte)(45 + 30), (byte)(10 + 57), (byte)(65 + 18), (byte)(8 + 45), (byte)(22 + 58), (byte)(22 + 75), (byte)(70 + 30), 100, (byte)(73 + 32), (byte)(28 + 82), (byte)(95 + 8)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(31 + 52)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0528\u0534\u0518\u0521\u04ff\u0519\u0524\u0512\u0547\u051c\u0544\u054a\u052a\u0526\u053c\u0549\u050a\u054d\u0532\u0523\u0529\u0543\u051a\u051b", (byte)11, 70);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u050e\u0514\u0535\u0542\u052f\u0513\u0500\u0520\u04fa\u051c\u051e\u050f", (byte)11, 70);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0409\u044b\u0431\u0422\u0454\u040b\u0424\u044f\u044b\u0437\u0439\u041e", (byte)11, 67);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u00dd\u00e0\u00f0\u00cf\u00fd\u00cd\u00e7\u00d1\u00d5\u010e\u00f4\u00dd", (byte)11, 66);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0540\u0539\u0539\u0543\u0501\u0500\u0510\u0530\u0544\u0513\u0509\u050f", (byte)11, 70);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[5] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u051d\u0538\u0514\u050d\u052d\u0541\u0522\u0530\u051f\u051c\u052a\u050f", (byte)11, 69);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[6] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0535\u0532\u0516\u050d\u053e\u0530\u0525\u0533\u0539\u0518\u0541\u0545\u054b\u0517\u053b\u0529\u0539\u050b\u053d\u053e\u050b\u0545\u0513\u050e\u052f\u052b\u052e\u0551\u055a\u054a\u0557\u053d\u0556\u0534\u0556\u0541\u055b\u0544\u0565\u0555\u0567\u0521\u0558\u052f", (byte)11, 69);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0437\u0443\u0427\u0430\u040e\u0428\u0433\u0421\u0456\u042b\u0456\u044e\u042b\u041b\u043c\u044b\u0447\u043d\u0455\u0451\u0423\u043c\u0429\u042a", (byte)11, 68);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0100\u00c5\u00dd\u00fe\u0104\u0110\u00e3\u00c7\u00fe\u0113\u00d3\u00dd", (byte)11, 66);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u04f6\u050f\u0521\u0510\u0533\u051f\u0543\u0500\u0535\u051e\u0505\u050f", (byte)11, 70);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00fa\u00cc\u010a\u00fd\u00c8\u010c\u0111\u0108\u0117\u00d4\u00d3\u00dd", (byte)11, 66);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u010e\u00f9\u00ca\u00e7\u00db\u0108\u00df\u00cb\u010a\u00ea\u00e8\u010a\u00d4\u0107\u00f0\u00f2\u00fa\u010e\u00f5\u011e\u010f\u0121\u00e8\u00e9", (byte)11, 66);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[5] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0520\u0521\u0537\u0539\u0524\u053b\u050e\u051b\u0532\u0548\u0544\u050f", (byte)11, 69);
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0535\u0532\u0516\u050d\u053e\u0530\u0525\u0533\u0539\u0518\u0541\u0545\u054b\u0517\u053b\u0529\u0539\u050b\u053d\u053e\u050b\u0545\u0513\u050e\u052f\u052b\u052e\u0551\u055a\u054a\u0557\u053d\u051a\u0541\u051c\u0539\u0532\u0555\u0538\u0521\u0550\u0545\u054a\u056a\u052c\u052b\u053d\u0560\u0558\u054c\u0524\u056d\u0545\u054d\u053a\u053b", (byte)11, 70);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0109\u0110\u00c8\u00e3\u0111\u010d\u0101\u00e4\u0113\u00e5\u00f4\u00dd", (byte)11, 66);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0520\u04fa\u0510\u050f\u0541\u051d\u0503\u0507\u0508\u0543\u0507\u0508\u0514\u051d\u0506\u051b\u0544\u0519\u053a\u0523\u052b\u0543\u051a\u051b", (byte)11, 70);
                }
            }
        }
    }

    private String f(String string) {
        if ((string = string.trim()).length() >= be && string.charAt(bf) == bi) {
            string = string.substring(bk);
        }
        char c = string.charAt(bn);
        char c2 = string.charAt(string.length() - bp);
        if (string.length() >= bq && (c == bt && c2 == bu || c == bx && c2 == bz)) {
            string = string.substring(cb, string.length() - cc);
        }
        return string;
    }

    public \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, String string, boolean bl) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, bl);
        this.I = string;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u04e7\u0509\u050b\u04eb\u050f\u052e\u0526\u053c\u0528\u04f7\u0535\u052b\u0539\u0533\u04fc\u0521\u0543\u0542\u053a\u0540\u053a\u050f", (byte)3, 70), \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u00e8\u00f5\u00f4\u00b7\u00f7\u00f3\u00ee\u00f7\u0102\u00f1\u00be\u00fc\u0100\u00f9\u00fc\u0102\u00c4\u044e\u0454\u0450\u043f\u0450\u0464\u0445\u0461\u0454\u0453\u0468\u0441\u00dc", (byte)3, 65) + string + \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u03f8", (byte)3, 67) + methodType.toString(), exception);
        }
    }

    protected void h(String string, String string2) {
        this.a(string, string2, null, null);
    }

    public \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4) {
        this(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, (String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e80", (int)c, (long)(h ^ i)));
    }

    private static String a(int n, long l) {
        l ^= 0x2FL;
        l ^= 0xAF71B1AA6559C656L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(41 + 28), (byte)(9 + 74), (byte)(46 + 1), (byte)(45 + 22), (byte)(38 + 28), (byte)(50 + 17), (byte)(42 + 5), (byte)(51 + 29), (byte)(44 + 31), (byte)(23 + 44), 83, (byte)(30 + 23), (byte)(59 + 21), (byte)(63 + 34), (byte)(7 + 93), (byte)(28 + 72), (byte)(84 + 21), (byte)(20 + 90), (byte)(101 + 2)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(16 + 52), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u054b\u0558\u0557\u051a\u055a\u0556\u0551\u055a\u0565\u0554\u0521\u055f\u0563\u055c\u055f\u0565\u0527\u08b1\u08b7\u08b3\u08a2\u08b3\u08c7\u08a8\u08c4\u08b7\u08b6\u08cb\u08a4", (byte)44, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    static {
        c = (0 >>> 96 | 0 << -96) & 0xFFFFFFFF;
        h = Long.reverse(-6070276466911622283L);
        i = Long.reverse(-864691128455135232L);
        l = 0x4000000 >>> 218 | 0x4000000 << ~218 + 1;
        m = 32768 >>> 239 | 32768 << -239;
        n = Long.reverse(-6070276466911622283L);
        o = Long.reverse(-864691128455135232L);
        t = 0x400000 >>> 85 | 0x400000 << ~85 + 1;
        w = 0 >>> 200 | 0 << -200;
        z = Integer.reverse(Integer.MIN_VALUE);
        ae = 524288 >>> 50 | 524288 << ~50 + 1;
        af = Long.reverse(-6070276466911622283L);
        ah = Long.reverse(-864691128455135232L);
        ai = Integer.reverse(-1073741824);
        ak = Long.reverse(-6070276466911622283L);
        an = Long.reverse(-864691128455135232L);
        ao = Integer.reverse(0x20000000);
        aq = Long.reverse(-6070276466911622283L);
        ar = Long.reverse(-864691128455135232L);
        av = Integer.reverse(-1610612736);
        aw = Long.reverse(6900090459915406197L);
        ax = 0x600000 >>> 20 | 0x600000 << ~20 + 1;
        az = Long.reverse(6900090459915406197L);
        bc = 0 >>> 146 | 0 << -146;
        be = Integer.reverse(0x40000000);
        bf = (0 >>> 108 | 0 << ~108 + 1) & 0xFFFFFFFF;
        bi = (0x10000000 >>> 247 | 0x10000000 << ~247 + 1) & 0xFFFFFFFF;
        bk = Integer.reverse(Integer.MIN_VALUE);
        bn = (0 >>> 59 | 0 << ~59 + 1) & 0xFFFFFFFF;
        bp = (2 >>> 161 | 2 << ~161 + 1) & 0xFFFFFFFF;
        bq = Integer.reverse(-1073741824);
        bt = (0x27000000 >>> 152 | 0x27000000 << ~152 + 1) & 0xFFFFFFFF;
        bu = Integer.reverse(-469762048);
        bx = Integer.reverse(0x44000000);
        bz = Integer.reverse(0x44000000);
        cb = 0x20000000 >>> 61 | 0x20000000 << -61;
        cc = (0x40000000 >>> 222 | 0x40000000 << -222) & 0xFFFFFFFF;
        ce = Integer.reverse(-536870912);
        ch = 917504 >>> 145 | 917504 << -145;
        c = new String[ce];
        d = new String[ch];
        \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.b();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    protected void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2) {
        File file = new File(this.b(), this.I);
        List<String> list = \u03c9\u03c2\u03b4\u03c9\u03bb\u03bb\u03bd\u03b4\u03b4.a(file);
        this.j = list.size();
        for (String string : list) {
            String string2 = null;
            try {
                String[] stringArray = string.split((String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e80", (int)m, (long)(n ^ o)));
                if (stringArray.length < t) continue;
                this.h(stringArray[w], this.f(stringArray[z]));
            }
            catch (Exception exception) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e83", (int)ae, (long)(af ^ ah)) + this.a.getName() + (String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e86", (int)ai, (long)(ak ^ an)) + (String)(string2 == null ? \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e89", (int)ao, (long)(aq ^ ar)) : string2 + (String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e8c", (int)av, (long)aw)) + (String)\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0.c("\u3e8f", (int)ax, (long)az), exception, new Object[bc]);
            }
            finally {
                ++this.l;
            }
        }
        list.clear();
        this.c(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2);
    }

    public \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, String string) {
        this(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, string, l != 0);
    }
}

