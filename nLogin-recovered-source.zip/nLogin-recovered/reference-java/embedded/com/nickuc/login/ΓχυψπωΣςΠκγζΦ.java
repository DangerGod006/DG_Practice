/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Server
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c3\u03a0\u03bf\u03be\u0394\u03b8\u03b1\u03c6\u03b3\u03bf;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6 {
    private static long ay;
    private static int ax;
    private static long al;
    private static final boolean P;
    private static long au;
    private static int ba;
    private static int b;
    private static int u;
    private static int ae;
    private static final Method j;
    private static int ac;
    private static int aj;
    private static int o;
    private static int ah;
    private static int ad;
    private static final Field f;
    private static long n;
    private static int l;
    private static long c;
    private static \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 a;
    private static int ag;
    private static final Method i;
    private static int ap;
    private static int x;
    private static int z;
    private static int k;
    private static int w;
    private static int q;
    private static long bb;
    private static int e;
    private static int f;
    private static int ab;
    private static int a;
    private static long v;
    private static final Method k;
    private static int h;
    private static int aa;
    private static String[] b;
    private static long i;
    private static int j;
    private static int bc;
    private static int p;
    private static long r;
    private static long y;
    private static int an;
    private static int at;
    private static int bd;
    private static String[] a;
    private static long ak;
    private static long af;
    private static int az;
    private static int c;
    private static int aw;
    private static long g;
    private static long be;
    private static long ar;
    private static int ai;
    private static int aq;
    private static int as;
    private static int s;
    private static int m;
    private static long ao;
    private static int am;
    private static int av;
    private static int d;
    private static int t;

    public static void b(Runnable runnable) {
        a.b(d != 0).a(runnable);
    }

    public static void b(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        a.b(a != 0).a(consumer);
    }

    public static void a(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932) {
        a = \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u011f\u0141\u0143\u0123\u0147\u0166\u015e\u0174\u0160\u012f\u016d\u0163\u0171\u016b\u0134\u0159\u017b\u017a\u0172\u0178\u0172\u0147", (byte)60, 65), \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u055b\u0568\u0567\u052a\u056a\u0566\u0561\u056a\u0575\u0564\u0531\u056f\u0573\u056c\u056f\u0575\u0537\u089c\u08d1\u08d0\u08d4\u08cd\u08d7\u08b2\u08d2\u08b1\u08cc\u08c6\u08ca\u08bb\u0550", (byte)60, 70) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0532", (byte)60, 70) + methodType.toString(), exception);
        }
    }

    public static boolean U() {
        YamlConfiguration yamlConfiguration = \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.a();
        if (yamlConfiguration == null) {
            return s != 0;
        }
        return (yamlConfiguration.getBoolean((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)(t & u), (long)v)) || yamlConfiguration.getBoolean((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e83", (int)(w & x), (long)y)) ? z : aa) != 0;
    }

    public static CompletableFuture<Void> a(Player player, String string) {
        CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        if (!player.isOnline()) {
            completableFuture.complete(null);
        } else if (Bukkit.getServer().isPrimaryThread()) {
            player.kickPlayer(string);
            completableFuture.complete(null);
        } else {
            \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.a(() -> {
                player.kickPlayer(string);
                completableFuture.complete(null);
            });
        }
        return completableFuture;
    }

    @Nullable
    public static YamlConfiguration a() {
        if (k == null || j == null) {
            return null;
        }
        try {
            Object object = k.invoke((Object)Bukkit.getServer(), new Object[j]);
            return (YamlConfiguration)j.invoke(object, new Object[k]);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            if (reflectiveOperationException.getCause() instanceof UnsupportedOperationException) {
                return null;
            }
            throw new RuntimeException((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)(l & m), (long)n), reflectiveOperationException);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x6BL;
        l ^= 0xF9D202790191CB4EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(2 + 67), (byte)(43 + 40), 47, (byte)(29 + 38), (byte)(7 + 59), (byte)(9 + 58), (byte)(32 + 15), (byte)(69 + 11), (byte)(59 + 16), (byte)(19 + 48), (byte)(8 + 75), (byte)(10 + 43), (byte)(15 + 65), (byte)(76 + 21), (byte)(70 + 30), (byte)(7 + 93), (byte)(54 + 51), (byte)(93 + 17), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(38 + 30), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0542\u054f\u054e\u0511\u0551\u054d\u0548\u0551\u055c\u054b\u0518\u0556\u055a\u0553\u0556\u055c\u051e\u0883\u08b8\u08b7\u08bb\u08b4\u08be\u0899\u08b9\u0898\u08b3\u08ad\u08b1\u08a2", (byte)35, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static boolean T() {
        try {
            return (f != null && f.getBoolean(null) ? o : p) != 0;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)q, (long)r), reflectiveOperationException);
        }
    }

    public static void a(Runnable runnable) {
        a.b(b != 0).a(runnable);
    }

    public static boolean V() {
        return P;
    }

    static {
        AnnotatedElement annotatedElement;
        a = Integer.reverse(0);
        b = Integer.reverse(0);
        c = 131072 >>> 17 | 131072 << -17;
        d = 8 >>> 67 | 8 << -67;
        e = Integer.reverse(0);
        f = (0 >>> 108 | 0 << ~108 + 1) & 0xFFFFFFFF;
        g = Long.reverse(5980147380601356430L);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Long.reverse(5980147380601356430L);
        j = (0 >>> 146 | 0 << -146) & 0xFFFFFFFF;
        k = 0 >>> 81 | 0 << -81;
        l = 0x400000 >>> 21 | 0x400000 << -21;
        m = Integer.reverse(-1);
        n = Long.reverse(5980147380601356430L);
        o = 8192 >>> 237 | 8192 << ~237 + 1;
        p = Integer.reverse(0);
        q = Integer.reverse(-1073741824);
        r = Long.reverse(5980147380601356430L);
        s = Integer.reverse(0);
        t = Integer.reverse(0x20000000);
        u = Integer.reverse(-1);
        v = Long.reverse(5980147380601356430L);
        w = 10240 >>> 203 | 10240 << -203;
        x = -1 >>> 237 | -1 << ~237 + 1;
        y = Long.reverse(5980147380601356430L);
        z = Integer.reverse(Integer.MIN_VALUE);
        aa = Integer.reverse(0);
        ab = (0xE00000 >>> 84 | 0xE00000 << -84) & 0xFFFFFFFF;
        ac = (0x1C0000 >>> 113 | 0x1C0000 << -113) & 0xFFFFFFFF;
        ad = Integer.reverse(0x60000000);
        ae = -1 >>> 59 | -1 << -59;
        af = Long.reverse(5980147380601356430L);
        ag = Integer.reverse(0);
        ah = 2048 >>> 171 | 2048 << -171;
        ai = (0 >>> 255 | 0 << ~255 + 1) & 0xFFFFFFFF;
        aj = Integer.reverse(-536870912);
        ak = Long.reverse(-8863716991211798386L);
        al = Long.reverse(-3026418949592973312L);
        am = Integer.reverse(0);
        an = Integer.MIN_VALUE >>> 60 | Integer.MIN_VALUE << ~60 + 1;
        ao = Long.reverse(5980147380601356430L);
        ap = (1152 >>> 135 | 1152 << ~135 + 1) & 0xFFFFFFFF;
        aq = Integer.reverse(-1);
        ar = Long.reverse(5980147380601356430L);
        as = Integer.reverse(0x50000000);
        at = Integer.reverse(-1);
        au = Long.reverse(5980147380601356430L);
        av = Integer.reverse(0);
        aw = (0x58000000 >>> 123 | 0x58000000 << -123) & 0xFFFFFFFF;
        ax = Integer.reverse(-1);
        ay = Long.reverse(5980147380601356430L);
        az = 0 >>> 189 | 0 << -189;
        ba = Integer.reverse(0x30000000);
        bb = Long.reverse(5980147380601356430L);
        bc = Integer.reverse(-1342177280);
        bd = Integer.reverse(-1);
        be = Long.reverse(5980147380601356430L);
        a = new String[ab];
        b = new String[ac];
        \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b();
        P = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(Bukkit.class, (String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)(ad & ae), (long)af), new Class[ag]) != null ? ah : ai;
        Method method = null;
        try {
            Bukkit.getServer().getOnlinePlayers();
        }
        catch (Throwable throwable) {
            try {
                method = Server.class.getMethod((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e83", (int)aj, (long)(ak ^ al)), new Class[am]);
            }
            catch (Throwable throwable2) {
                throw new UnsupportedOperationException((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e86", (int)an, (long)ao), throwable2);
            }
        }
        i = method;
        Method method2 = null;
        Method method3 = null;
        try {
            annotatedElement = Class.forName((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e89", (int)(ap & aq), (long)ar));
            method3 = Server.class.getMethod((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e8c", (int)(as & at), (long)au), new Class[av]);
            method2 = annotatedElement.getMethod((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e8f", (int)(aw & ax), (long)ay), new Class[az]);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            // empty catch block
        }
        k = method3;
        j = method2;
        try {
            Class<?> clazz = Class.forName((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e92", (int)ba, (long)bb));
            annotatedElement = clazz.getField((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e95", (int)(bc & bd), (long)be));
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            annotatedElement = null;
        }
        f = annotatedElement;
    }

    public static Collection<? extends Player> d() {
        if (i == null) {
            return Bukkit.getServer().getOnlinePlayers();
        }
        try {
            return \u03c3\u03a0\u03bf\u03be\u0394\u03b8\u03b1\u03c6\u03b3\u03bf.a((Player[])i.invoke((Object)Bukkit.getServer(), new Object[e]));
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)f, (long)g), reflectiveOperationException);
        }
    }

    public static void c(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        a.b(c != 0).a(consumer);
    }

    public static UUID b(String string) {
        return UUID.nameUUIDFromBytes(((String)\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.c("\u3e80", (int)h, (long)i) + string).getBytes(StandardCharsets.UTF_8));
    }

    private static void b() {
        int n;
        c = 8142609985092960033L;
        long l = c ^ 0xF9D202790191CB4EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(2 + 67), (byte)(6 + 77), (byte)(32 + 15), (byte)(50 + 17), (byte)(26 + 40), 67, (byte)(18 + 29), (byte)(72 + 8), (byte)(30 + 45), (byte)(64 + 3), (byte)(7 + 76), (byte)(48 + 5), (byte)(6 + 74), (byte)(4 + 93), (byte)(4 + 96), (byte)(96 + 4), 105, (byte)(92 + 18), (byte)(74 + 29)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(54 + 29)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0156\u0156\u0156\u017c\u0160\u016c\u0158\u0159\u01a1\u01a5\u0175\u0185\u0199\u0197\u0187\u0168\u01a2\u0182\u016e\u018a\u01a8\u018f\u0169\u0170\u018e\u0180\u018a\u01b8\u016e\u01ac\u01b3\u01ab\u01b4\u01b6\u017e\u01bd\u01ab\u01c0\u0179\u01b4\u0193\u019f\u01ba\u0179\u0197\u01c3\u01a1\u01c6\u01c0\u01cd\u01b9\u018e\u01a6\u0199\u0196\u0197", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u04fd\u04e2\u0526\u04e4\u0523\u0528\u0514\u0525\u0517\u0504\u052e\u051c\u051c\u0520\u04e9\u050f\u0514\u0501\u04fe\u0507\u0501\u0501\u04fe\u04ff", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0153\u0193\u0173\u016b\u015c\u0193\u0175\u016f\u0162\u0197\u015d\u0183\u0171\u0199\u019d\u019d\u019e\u016d\u017c\u017b\u01b0\u018e\u017f\u01b4\u0191\u01b0\u0168\u0192\u0199\u0190\u017a\u0192\u0196\u0191\u01af\u019c\u01c0\u01ad\u0178\u0192\u01bd\u0184\u0181\u01c4\u0191\u01b7\u01be\u01cb\u0188\u01cb\u019c\u018e\u018e\u01cf\u0196\u0197", (byte)82, 65);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u053e\u057e\u055e\u0556\u0547\u057e\u0560\u055a\u054d\u0582\u0548\u0573\u0573\u054b\u0585\u056b\u0580\u0570\u0553\u0596\u0556\u059d\u0572\u0588\u0568\u05a0\u056f\u0576\u0578\u055a\u0557\u057b\u0573\u0591\u059f\u0572\u05a8\u0566\u0581\u058f\u0578\u0568\u0591\u0576", (byte)82, 70);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0189\u019a\u0179\u016a\u018b\u0172\u0175\u017a\u0164\u0162\u01a7\u0166\u0178\u0165\u0188\u01a4\u01a8\u01a1\u016d\u01a5\u01ad\u016c\u01af\u018d\u01b5\u0167\u0196\u01a9\u01ab\u0176\u0194\u0196\u0189\u0194\u01b6\u01a7\u018c\u018a\u019c\u019b\u019c\u01a1\u0191\u0194\u0196\u0185\u01a8\u01c5\u01a5\u018a\u01c5\u01b8\u018c\u01bf\u0196\u0197", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u051b\u0504\u0523\u04f0\u051f\u0525\u0514\u04eb\u0524\u051d\u052d\u0524\u051a\u0526\u050d\u051c\u04f3\u050b\u050d\u0538\u04f8\u0511\u052f\u0526\u0526\u0530\u050a\u053d\u051f\u0542\u0534\u051a\u0536\u0538\u053b\u0504\u0532\u0525\u0509\u0538\u051b\u054c\u0509\u0513", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[6] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u017b\u0192\u0173\u0198\u017f\u016b\u017c\u017f\u015a\u019b\u015e\u0175\u017a\u01a7\u018b\u01a1\u0186\u0186\u0178\u01a9\u017d\u018f\u01ac\u01ad\u01a8\u016d\u01b3\u0194\u01b5\u0174\u0192\u0184\u0195\u01b2\u01ae\u01b3\u01b3\u0196\u0179\u017c\u01a0\u017c\u019e\u018b", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[7] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0165\u016e\u019e\u0174\u019b\u0175\u0182\u0161\u019c\u01a0\u0163\u019f\u0176\u01a5\u017d\u01a0\u0194\u01a1\u0176\u0166\u0183\u0182\u019f\u01a3\u018d\u018b\u01b4\u01af\u0187\u01b0\u0199\u01a4", (byte)82, 65);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[8] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u04ed\u04f6\u0526\u04fc\u0523\u04fd\u050a\u04e9\u0524\u0528\u04eb\u0527\u04fe\u052d\u0505\u0528\u051c\u0529\u04fe\u04ee\u050b\u0507\u050f\u050d\u052e\u0526\u053a\u0513\u052d\u051e\u0537\u0524\u050f\u0546\u0518\u050f\u0518\u0535\u051e\u0519\u0524\u052a\u0505\u0513", (byte)82, 68);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[9] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u0155\u014f\u0198\u0170\u0158\u0181\u0173\u0171\u0173\u0163\u0183\u0186\u0180\u01a4\u017b\u01a3\u01ad\u019a\u0160\u0165\u0183\u0181\u0170\u0169\u0166\u0195\u0192\u01ab\u01ae\u01b3\u01b5\u01ac\u0192\u017a\u01ab\u0177\u01ab\u017f\u01b2\u0182\u01a1\u0184\u01b8\u018b", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[10] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04dc\u051e\u0522\u050f\u0517\u0516\u051e\u0519\u0519\u04fa\u051c\u04f3", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[11] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0503\u04f8\u04e2\u0502\u0524\u04f8\u04e4\u0501\u04fc\u04e9\u0504\u04eb\u04ea\u04f0\u04f0\u050c\u04f4\u0502\u0506\u0503\u0512\u0537\u04fe\u04ff", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[12] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u051a\u051f\u0503\u04e4\u051c\u04fd\u0508\u04e7\u052a\u04fb\u052f\u0530\u052e\u04ef\u04f1\u0530\u052c\u052c\u04f6\u0523\u0514\u0504\u052b\u0516\u050f\u0525\u051e\u0536\u053e\u051e\u050b\u0522\u0530\u0511\u04fc\u0519\u0531\u0507\u0544\u054b\u0522\u050b\u0526\u0513", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[13] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u04ee\u04ff\u0505\u04fa\u04f8\u04e5\u0528\u0509\u052b\u050d\u0528\u04f3", (byte)82, 68);
                    continue block7;
                }
                case 1: {
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u0156\u0156\u0156\u017c\u0160\u016c\u0158\u0159\u01a1\u01a5\u0175\u0185\u0199\u0197\u0187\u0168\u01a2\u0182\u016e\u018a\u01a8\u018f\u0169\u0170\u018e\u0180\u018a\u01b8\u016e\u01ac\u01b3\u01ab\u01b4\u01b6\u017e\u01bd\u01ab\u01c0\u0179\u01b4\u0193\u019f\u01b9\u01c5\u01a3\u01b1\u01a3\u01c8\u01cd\u01ad\u0199\u01ab\u01bc\u01cb\u01c3\u01aa\u01b0\u01d1\u01cb\u0189\u01cb\u01b9\u01d8\u01ab", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0560\u0545\u0589\u0547\u0586\u058b\u0577\u0588\u057a\u0567\u0590\u0587\u0568\u058c\u058d\u0595\u0567\u0554\u058b\u059b\u0598\u058a\u0579\u0559\u0595\u0556\u0561\u058c\u0593\u056c\u057e\u05a7", (byte)82, 70);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0153\u0193\u0173\u016b\u015c\u0193\u0175\u016f\u0162\u0197\u015d\u0183\u0171\u0199\u019d\u019d\u019e\u016d\u017c\u017b\u01b0\u018e\u017f\u01b4\u0191\u01b0\u0168\u0192\u0199\u0190\u017a\u0192\u0196\u0191\u01af\u019c\u01c0\u01ad\u0178\u0192\u01bd\u0184\u0184\u0197\u0184\u01bd\u01be\u019a\u01a8\u01ad\u01bf\u0186\u01d0\u01cf\u0196\u0197", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0153\u0193\u0173\u016b\u015c\u0193\u0175\u016f\u0162\u0197\u015d\u0188\u0188\u0160\u019a\u0180\u0195\u0185\u0168\u01ab\u016b\u01b2\u0187\u019d\u017d\u01b5\u0184\u018b\u018d\u016f\u016c\u0190\u01b6\u01bd\u0195\u017c\u01c1\u019a\u01b8\u01c4\u019c\u01a1\u01c5\u01be\u01a5\u01b4\u0192\u01a2\u018c\u01a1\u01c2\u018d\u01a0\u0199\u0196\u0197", (byte)82, 65);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[4] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0189\u019a\u0179\u016a\u018b\u0172\u0175\u017a\u0164\u0162\u01a7\u0166\u0178\u0165\u0188\u01a4\u01a8\u01a1\u016d\u01a5\u01ad\u016c\u01af\u018d\u01b5\u0167\u0196\u01a9\u01ab\u0176\u0194\u0196\u0189\u0194\u01b6\u01a7\u018c\u018a\u019c\u019b\u019c\u01a1\u018e\u0196\u01c7\u0184\u01a8\u01a4\u01c7\u0189\u01ba\u0189\u01c9\u01bf\u0196\u0197", (byte)82, 65);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[5] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u051b\u0504\u0523\u04f0\u051f\u0525\u0514\u04eb\u0524\u051d\u052d\u0524\u051a\u0526\u050d\u051c\u04f3\u050b\u050d\u0538\u04f8\u0511\u052f\u0526\u0526\u0530\u050a\u053d\u051f\u0542\u0534\u051a\u0541\u051b\u051f\u051b\u0524\u0508\u051d\u0509\u0529\u0517\u0505\u0513", (byte)82, 68);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[6] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u017b\u0192\u0173\u0198\u017f\u016b\u017c\u017f\u015a\u019b\u015e\u0175\u017a\u01a7\u018b\u01a1\u0186\u0186\u0178\u01a9\u017d\u018f\u01ac\u01ad\u01a8\u016d\u01b3\u0194\u01b5\u0174\u0192\u0184\u019d\u0177\u019b\u01a0\u0189\u0198\u019d\u018d\u01c5\u01a0\u019e\u018b", (byte)82, 65);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[7] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u04ed\u04f6\u0526\u04fc\u0523\u04fd\u050a\u04e9\u0524\u0528\u04eb\u0527\u04fe\u052d\u0505\u0528\u051c\u0529\u04fe\u04ee\u050b\u050d\u04f5\u0527\u052f\u0507\u0539\u0533\u0528\u04ff\u0516\u051c", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[8] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u0165\u016e\u019e\u0174\u019b\u0175\u0182\u0161\u019c\u01a0\u0163\u019f\u0176\u01a5\u017d\u01a0\u0194\u01a1\u0176\u0166\u0183\u017f\u0187\u0185\u01a6\u019e\u01b2\u018b\u01a5\u0196\u01af\u019c\u0176\u0178\u01ae\u019a\u01ac\u017f\u01af\u017d\u018f\u01c0\u01a7\u01b8\u019e\u019a\u0184\u018b\u01cc\u01a8\u01ac\u019d\u01c0\u01cf\u0196\u0197", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[9] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04dd\u04d7\u0520\u04f8\u04e0\u0509\u04fb\u04f9\u04fb\u04eb\u050b\u050e\u0508\u052c\u0503\u052b\u0535\u0522\u04e8\u04ed\u050b\u0509\u04f8\u04f1\u04ee\u051d\u051a\u0533\u0536\u053b\u053d\u0534\u053b\u050e\u0517\u0548\u053a\u0515\u054b\u050b\u053b\u0523\u050d\u0513", (byte)82, 67);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[10] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u050f\u04f4\u04f9\u0511\u051c\u0504\u0503\u04e6\u0506\u0520\u0504\u051d\u051d\u0520\u0521\u0506\u04ec\u0506\u04f0\u0531\u0503\u0527\u04fe\u04ff", (byte)82, 68);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[11] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u017b\u0170\u015a\u017a\u019c\u0170\u015c\u0179\u0174\u0161\u017a\u019d\u0180\u0196\u01a0\u0176\u0197\u01a2\u0182\u0177\u019c\u0190\u01a0\u019e\u01af\u0196\u0185\u0193\u0184\u01ab\u01a5\u0178", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[12] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u0192\u0197\u017b\u015c\u0194\u0175\u0180\u015f\u01a2\u0173\u01a7\u01a8\u01a6\u0167\u0169\u01a8\u01a4\u01a4\u016e\u019b\u018c\u017c\u01a3\u018e\u0187\u019d\u0196\u01ae\u01b6\u0196\u0183\u019a\u0178\u01b8\u019f\u0192\u017a\u01b6\u017f\u0195\u017c\u0185\u01bc\u018b", (byte)82, 66);
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[13] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u018f\u0189\u0159\u0177\u01a1\u019c\u0181\u01a0\u015c\u0183\u0178\u01a6\u019b\u0194\u01a9\u0182\u0176\u0198\u017b\u01a5\u01a3\u019f\u0176\u0177", (byte)82, 65);
                    continue block7;
                }
                case 2: {
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0152\u0165\u0188\u019b\u0174\u015a\u0162\u0180\u016e\u017b\u017c\u01a4\u0187\u0189\u0160\u01a6\u0177\u016a\u0181\u0169\u01a2\u0179\u0176\u0177", (byte)82, 65);
                    continue block7;
                }
                case 4: {
                    \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u055e\u0586\u055a\u057e\u0585\u054b\u0585\u0560\u054c\u0562\u0543\u054a\u0549\u0569\u054c\u055f\u0582\u0583\u056c\u0550\u0556\u0564\u0561\u0562", (byte)82, 70);
                }
            }
        }
    }
}

