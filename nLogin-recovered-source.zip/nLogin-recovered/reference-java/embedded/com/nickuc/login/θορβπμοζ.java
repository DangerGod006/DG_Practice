/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03c6\u03c4\u03bd\u03c1\u03bd\u03c5\u03c1\u03a3;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03c4\u03a9\u03a6\u03c0\u03c1\u03b7\u03a9\u0393;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6
extends \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 {
    private static int bq;
    private static long cf;
    private static String[] f;
    private static long bs;
    private static String[] e;
    private static int bz;
    private static long bx;
    private static int p;
    private static int ce;
    private static long cd;
    private static long s;
    private static long cn;
    private static long ca;
    private static long ad;
    private static int bu;
    private static int cp;
    private static long ap;
    private static long x;
    private static long bw;
    private static int br;
    private static long ck;
    private static long g;
    private static int ci;
    private static int co;
    private static int z;

    public \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6(nLoginBukkit nLoginBukkit2) {
        super(nLoginBukkit2);
    }

    private static void b() {
        int n;
        g = -5763985283632083236L;
        long l = g ^ 0x1E0AC4A3CBA31582L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(27 + 41), (byte)(65 + 4), (byte)(78 + 5), (byte)(22 + 25), (byte)(5 + 62), (byte)(37 + 29), (byte)(42 + 25), (byte)(37 + 10), (byte)(79 + 1), (byte)(29 + 46), (byte)(57 + 10), (byte)(20 + 63), (byte)(52 + 1), 80, (byte)(42 + 55), (byte)(82 + 18), (byte)(81 + 19), 105, (byte)(84 + 26), (byte)(18 + 85)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(16 + 52), (byte)(9 + 60), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u0539\u053a\u052a\u0509\u053c\u052f\u0540\u0519\u050d\u0518\u051c\u04f6\u0522\u053c\u0542\u0543\u0506\u0540\u0517\u0542\u051b\u0521\u0529\u0527\u0539\u0510\u0525\u0533\u0533\u0553\u050f\u0546\u050f\u0514\u0524\u0545\u0552\u0553\u053b\u0560\u0560\u051f\u0556\u0561\u0546\u0554\u0526\u0563\u0563\u0560\u0566\u0539\u054d\u0536\u0533\u0534", (byte)89, 68);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ab\u05b6\u059b\u05a9\u057b\u05b8\u05b8\u05b5\u05bb\u058e\u05a2\u058b\u0588\u0589", (byte)89, 69);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0539\u053a\u052a\u0509\u053c\u052f\u0540\u0519\u050d\u0518\u051c\u04f6\u0522\u053c\u0542\u0543\u0506\u0540\u0517\u0542\u051b\u0521\u0529\u0527\u0539\u0510\u0525\u0533\u0533\u0553\u050f\u0546\u050f\u0514\u0524\u0545\u0552\u0553\u053b\u0560\u0560\u051f\u0556\u0561\u0546\u0554\u0526\u0563\u0563\u0560\u0566\u0539\u054d\u0536\u0533\u0534", (byte)89, 67);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0539\u053a\u052a\u0509\u053c\u052f\u0540\u0519\u050d\u0518\u051c\u04f6\u0522\u053c\u0542\u0543\u0506\u0540\u0517\u0542\u051b\u0521\u0529\u0527\u0539\u0510\u0525\u0533\u0533\u0553\u050f\u0546\u050f\u0514\u0524\u0545\u0552\u0553\u053b\u0560\u0560\u051f\u0556\u0561\u0546\u0554\u0526\u0563\u0563\u0560\u0566\u0539\u054d\u0536\u0533\u0534", (byte)89, 67);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ab\u05b6\u059b\u05a9\u057b\u05b8\u05b8\u05b5\u05bb\u058e\u05a2\u058b\u0588\u0589", (byte)89, 69);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[5] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ab\u05b6\u059b\u05a9\u057b\u05b8\u05b8\u05b5\u05bb\u058e\u05a2\u058b\u0588\u0589", (byte)89, 69);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[6] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u01aa\u01ab\u019b\u017a\u01ad\u01a0\u01b1\u018a\u017e\u0189\u018d\u0167\u0193\u01ad\u01b3\u01b4\u0177\u01b1\u0188\u01b3\u018c\u0192\u019a\u0198\u01aa\u0181\u0196\u01a4\u01a4\u01c4\u0180\u01b7\u0180\u0185\u0195\u01b6\u01c3\u01c4\u01ac\u01d1\u01d1\u0190\u01c7\u01d2\u01b7\u01c5\u0197\u01d4\u01d4\u01d1\u01d7\u01aa\u01be\u01a7\u01a4\u01a5", (byte)89, 65);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ab\u0574\u05ac\u05ae\u0590\u0578\u05bd\u05a7\u0598\u05c1\u059d\u059b\u0588\u0589", (byte)89, 70);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0539\u053a\u052a\u0509\u053c\u052f\u0540\u0519\u050d\u0518\u051c\u04f6\u0522\u053c\u0542\u0543\u0506\u0540\u0517\u0542\u051b\u0521\u0529\u0527\u0539\u0510\u0525\u0533\u0533\u0553\u050f\u0546\u050f\u0514\u0524\u0545\u0552\u0553\u053b\u0560\u0560\u051f\u0558\u054f\u0531\u0552\u0560\u0562\u055f\u053b\u0542\u055b\u055f\u056c\u0533\u0534", (byte)89, 67);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u01aa\u01ab\u019b\u017a\u01ad\u01a0\u01b1\u018a\u017e\u0189\u018d\u0167\u0193\u01ad\u01b3\u01b4\u0177\u01b1\u0188\u01b3\u018c\u0192\u019a\u0198\u01aa\u0181\u0196\u01a4\u01a4\u01c4\u0180\u01b7\u0180\u0185\u0195\u01b6\u01c3\u01c4\u01ac\u01d1\u01d1\u0190\u01c7\u01c0\u01a3\u01bf\u01a9\u01d5\u0195\u01b7\u0193\u01cb\u01d3\u01dd\u01a4\u01a5", (byte)89, 66);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0539\u053a\u052a\u0509\u053c\u052f\u0540\u0519\u050d\u0518\u051c\u04f6\u0522\u053c\u0542\u0543\u0506\u0540\u0517\u0542\u051b\u0521\u0529\u0527\u0539\u0510\u0525\u0533\u0533\u0553\u050f\u0546\u050f\u0514\u0524\u0545\u0552\u0553\u053b\u0560\u0560\u051f\u0555\u0565\u055f\u0551\u053e\u0534\u0541\u055f\u0524\u0539\u0528\u055c\u0533\u0534", (byte)89, 68);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ab\u05b8\u058b\u0589\u056e\u058e\u057a\u0596\u0597\u05be\u057b\u05c1\u0588\u0589", (byte)89, 69);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01aa\u01ab\u019b\u017a\u01ad\u01a0\u01b1\u018a\u017e\u0189\u018d\u0167\u0193\u01ad\u01b3\u01b4\u0177\u01b1\u0188\u01b3\u018c\u0192\u019a\u0198\u01aa\u0181\u0196\u01a4\u01a4\u01c4\u0180\u01b7\u0180\u0185\u0195\u01b6\u01c3\u01c4\u01ac\u01d1\u01d1\u0190\u01c7\u01d1\u018c\u01b2\u0192\u01aa\u01af\u01d9\u01cd\u0195\u01ab\u01dd\u01a4\u01a5", (byte)89, 66);
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[6] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u058e\u058f\u057f\u055e\u0591\u0584\u0595\u056e\u0562\u056d\u0571\u054b\u0577\u0591\u0597\u0598\u055b\u0595\u056c\u0597\u0570\u0576\u057e\u057c\u058e\u0565\u057a\u0588\u0588\u05a8\u0564\u059b\u0564\u0569\u0579\u059a\u05a7\u05a8\u0590\u05b5\u05b5\u0574\u05ac\u058c\u0583\u05aa\u05bd\u05b6\u0576\u05ae\u05a0\u058e\u059b\u059b\u0588\u0589", (byte)89, 70);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0546\u0569\u054c\u0579\u0550\u0594\u058b\u0593\u0590\u058f\u0570\u055d", (byte)89, 69);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.f[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u0547\u0580\u057f\u058a\u055d\u0587\u0563\u0588\u0597\u0575\u056b\u0595\u058f\u0593\u058c\u056c\u0598\u056c\u057d\u0592\u055f\u057b\u0568\u0569", (byte)89, 70);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x51L;
        l ^= 0x1E0AC4A3CBA31582L;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(33 + 36), (byte)(38 + 45), (byte)(12 + 35), 67, (byte)(46 + 20), (byte)(58 + 9), (byte)(29 + 18), 80, (byte)(74 + 1), (byte)(29 + 38), (byte)(32 + 51), (byte)(5 + 48), (byte)(7 + 73), (byte)(45 + 52), (byte)(99 + 1), (byte)(88 + 12), (byte)(37 + 68), (byte)(49 + 61), (byte)(100 + 3)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(62 + 21)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0532\u053f\u053e\u0501\u0541\u053d\u0538\u0541\u054c\u053b\u0508\u0546\u054a\u0543\u0546\u054c\u050e\u0898\u08a0\u08a3\u0895\u08a4\u08a1\u08a5\u089d", (byte)94, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }

    @Override
    public void a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)bz, (long)(ca ^ cd)));
    }

    @Override
    public void a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, String string, boolean bl, boolean bl2) {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)(bq & br), (long)bs));
    }

    @Override
    public \u03c2\u03c4\u03a9\u03a6\u03c0\u03c1\u03b7\u03a9\u0393 a() {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)z, (long)(ad ^ ap)));
    }

    @Override
    public void a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, boolean bl, boolean bl2) {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)ci, (long)(ck ^ cn)));
    }

    @Override
    public \u0393\u03c6\u03c4\u03bd\u03c1\u03bd\u03c5\u03c1\u03a3 a() {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)p, (long)(s ^ x)));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u055f\u0581\u0583\u0563\u0587\u05a6\u059e\u05b4\u05a0\u056f\u05ad\u05a3\u05b1\u05ab\u0574\u0599\u05bb\u05ba\u05b2\u05b8\u05b2\u0587", (byte)123, 70), \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0589\u0596\u0595\u0558\u0598\u0594\u058f\u0598\u05a3\u0592\u055f\u059d\u05a1\u059a\u059d\u05a3\u0565\u08ef\u08f7\u08fa\u08ec\u08fb\u08f8\u08fc\u08f4\u0579", (byte)123, 68) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0560", (byte)123, 68) + methodType.toString(), exception);
        }
    }

    @Override
    public void b(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)ce, (long)cf));
    }

    @Override
    public void a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, String string, @Nullable String string2, boolean bl, boolean bl2) {
        throw new UnsupportedOperationException((String)\u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.c("\u3e80", (int)bu, (long)(bw ^ bx)));
    }

    static {
        p = Integer.reverse(0);
        s = Long.reverse(4284015499696422925L);
        x = Long.reverse(-8502796096475496448L);
        z = Integer.reverse(Integer.MIN_VALUE);
        ad = Long.reverse(4284015499696422925L);
        ap = Long.reverse(-8502796096475496448L);
        bq = Integer.reverse(0x40000000);
        br = Integer.reverse(-1);
        bs = Long.reverse(-5659932477537632243L);
        bu = (768 >>> 104 | 768 << -104) & 0xFFFFFFFF;
        bw = Long.reverse(4284015499696422925L);
        bx = Long.reverse(-8502796096475496448L);
        bz = Integer.reverse(0x20000000);
        ca = Long.reverse(4284015499696422925L);
        cd = Long.reverse(-8502796096475496448L);
        ce = Integer.reverse(-1610612736);
        cf = Long.reverse(-5659932477537632243L);
        ci = Integer.reverse(0x60000000);
        ck = Long.reverse(4284015499696422925L);
        cn = Long.reverse(-8502796096475496448L);
        co = Integer.reverse(-536870912);
        cp = 57344 >>> 173 | 57344 << -173;
        e = new String[co];
        f = new String[cp];
        \u03b8\u03bf\u03c1\u03b2\u03c0\u03bc\u03bf\u03b6.b();
    }
}

