/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8
extends \u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 {
    private static int ag;
    private static long x;
    private static String[] c;
    private static long aa;
    private static int ai;
    private static int m;
    private static long u;
    private static int l;
    private static long h;
    private static int ae;
    private static int w;
    private static int t;
    private static long e;
    private static long y;
    private static String[] d;
    private static int z;
    private static long v;
    private final String N;
    private static int c;

    protected abstract void a(File var1);

    static {
        c = (0 >>> 247 | 0 << -247) & 0xFFFFFFFF;
        h = Long.reverse(-7043089946565259651L);
        l = (0 >>> 2 | 0 << ~2 + 1) & 0xFFFFFFFF;
        m = (0 >>> 162 | 0 << ~162 + 1) & 0xFFFFFFFF;
        t = Integer.reverse(Integer.MIN_VALUE);
        u = Long.reverse(-5313707689654989187L);
        v = Long.reverse(0x2800000000000000L);
        w = Integer.reverse(0x40000000);
        x = Long.reverse(-5313707689654989187L);
        y = Long.reverse(0x2800000000000000L);
        z = Integer.reverse(-1073741824);
        aa = Long.reverse(-7043089946565259651L);
        ae = 0 >>> 212 | 0 << ~212 + 1;
        ag = Integer.reverse(0x20000000);
        ai = Integer.reverse(0x20000000);
        c = new String[ag];
        d = new String[ai];
        \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.b();
    }

    private static void b() {
        int n;
        e = -4723612220828188051L;
        long l = e ^ 0x35BAA3DB09E827DFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(18 + 51), (byte)(11 + 72), (byte)(4 + 43), (byte)(66 + 1), (byte)(59 + 7), (byte)(26 + 41), (byte)(34 + 13), (byte)(63 + 17), (byte)(50 + 25), (byte)(65 + 2), (byte)(76 + 7), (byte)(9 + 44), (byte)(53 + 27), 97, (byte)(51 + 49), (byte)(23 + 77), (byte)(97 + 8), (byte)(38 + 72), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(18 + 50), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0547\u0566\u0546\u0542\u0574\u055a\u0564\u0572\u056a\u056f\u054f\u0531\u0574\u0572\u0579\u056d\u0576\u0556\u0546\u057a\u057b\u0572\u0588\u0557\u0579\u055b\u054e\u0585\u0586\u0591\u0565\u057c\u055c\u0560\u058d\u0574\u058b\u0574\u058b\u0585\u0553\u0558\u0566\u0588\u0592\u0558\u05a1\u0562\u0584\u056d\u05a4\u056f\u05a0\u057f\u05a9\u05a2\u0587\u059d\u0568\u056f\u0591\u057a\u059e\u057f", (byte)63, 70);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0554\u0573\u055f\u0530\u0557\u056d\u0553\u0554\u0558\u0534\u0578\u0543", (byte)63, 70);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u04cb\u04c7\u04e4\u04da\u04ec\u04bd\u04bd\u04de\u04bf\u04e0\u04d5\u04ba", (byte)63, 67);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u012c\u0153\u0159\u0149\u0179\u0177\u0158\u0135\u0148\u0179\u0156\u016d\u0139\u0150\u016f\u015e\u017e\u0170\u0165\u0178\u017f\u018c\u0169\u018a\u0183\u0149\u0159\u014d\u0191\u0180\u0161\u0174\u0197\u018a\u0168\u0156\u0152\u019a\u017b\u0198\u0169\u016a\u0168\u0165", (byte)63, 65);
                    continue block7;
                }
                case 1: {
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04be\u04dd\u04bd\u04b9\u04eb\u04d1\u04db\u04e9\u04e1\u04e6\u04c6\u04a8\u04eb\u04e9\u04f0\u04e4\u04ed\u04cd\u04bd\u04f1\u04f2\u04e9\u04ff\u04ce\u04f0\u04d2\u04c5\u04fc\u04fd\u0508\u04dc\u04f3\u04d3\u04d7\u0504\u04eb\u0502\u04eb\u0502\u04fc\u04ca\u04cf\u04dd\u04ff\u0509\u04cf\u0518\u04d9\u04fb\u04e4\u051b\u04e6\u0517\u04f6\u04fb\u04d9\u04dc\u050c\u04de\u04dc\u04fb\u0515\u0505\u0518", (byte)63, 67);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u04ab\u04a4\u04eb\u04bc\u04b9\u04aa\u04ad\u04ae\u04d0\u04b3\u04eb\u04ba", (byte)63, 67);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u053d\u0543\u0555\u054d\u0563\u0534\u055b\u0533\u0568\u0568\u0567\u0550\u056f\u056e\u0561\u057b\u055e\u053f\u0577\u0543\u0586\u0561\u054e\u054f", (byte)63, 69);
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[3] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04a1\u04c8\u04ce\u04be\u04ee\u04ec\u04cd\u04aa\u04bd\u04ee\u04cb\u04e2\u04ae\u04c5\u04e4\u04d3\u04f3\u04e5\u04da\u04ed\u04f4\u0501\u04de\u04ff\u04f8\u04be\u04ce\u04c2\u0506\u04f5\u04d6\u04e9\u04d6\u04f7\u04e1\u04cb\u0506\u04fb\u04fb\u0507\u04e0\u04ca\u04d0\u04da", (byte)63, 68);
                    continue block7;
                }
                case 2: {
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04a3\u04c5\u04e0\u04eb\u04e1\u04ae\u04f0\u04d1\u04aa\u04b1\u04cd\u04f6\u04c0\u04c3\u04ec\u04ce\u04e9\u04d5\u04e5\u04cd\u04f6\u04d8\u04c5\u04c6", (byte)63, 67);
                    continue block7;
                }
                case 4: {
                    \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.d[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u015e\u012f\u0130\u0149\u0167\u0138\u016c\u0169\u015a\u0180\u015e\u014d\u0171\u0152\u013c\u0179\u014e\u015e\u0142\u0162\u017e\u014a\u015c\u014b\u018d\u0147\u016d\u0180\u018c\u0190\u018a\u014c", (byte)63, 65);
                }
            }
        }
    }

    public \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, String string, boolean bl) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, bl);
        this.N = string;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u052e\u0550\u0552\u0532\u0556\u0575\u056d\u0583\u056f\u053e\u057c\u0572\u0580\u057a\u0543\u0568\u058a\u0589\u0581\u0587\u0581\u0556", (byte)74, 69), \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u04f6\u0503\u0502\u04c5\u0505\u0501\u04fc\u0505\u0510\u04ff\u04cc\u050a\u050e\u0507\u050a\u0510\u04d2\u083f\u0859\u0863\u085b\u0868\u0844\u0860\u0873\u0863\u086b\u085f\u0870\u0858\u04eb", (byte)74, 68) + string + \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0540", (byte)74, 69) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x14L;
        l ^= 0x35BAA3DB09E827DFL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(59 + 9), (byte)(35 + 34), (byte)(19 + 64), (byte)(31 + 16), (byte)(49 + 18), (byte)(19 + 47), (byte)(14 + 53), (byte)(37 + 10), 80, (byte)(47 + 28), (byte)(31 + 36), 83, (byte)(48 + 5), (byte)(53 + 27), (byte)(45 + 52), (byte)(27 + 73), (byte)(50 + 50), (byte)(62 + 43), (byte)(10 + 100), (byte)(23 + 80)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(43 + 26), (byte)(65 + 18)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08c9\u08e3\u08ed\u08e5\u08f2\u08ce\u08ea\u08fd\u08ed\u08f5\u08e9\u08fa\u08e2", (byte)97, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    protected void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2) {
        File file = new File(this.b(), this.N);
        if (!file.isDirectory()) {
            return;
        }
        File[] fileArray = file.listFiles();
        if (fileArray == null) {
            if (\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 != null) {
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, (String)\u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.c("\u3e80", (int)c, (long)h), new Object[l]);
            }
            return;
        }
        this.j = fileArray.length;
        File[] fileArray2 = fileArray;
        int n = fileArray2.length;
        for (int i = m; i < n; ++i) {
            File file2 = fileArray2[i];
            try {
                this.a(file2);
                continue;
            }
            catch (Exception exception) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.c("\u3e83", (int)t, (long)(u ^ v)) + this.a.getName() + (String)\u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.c("\u3e86", (int)w, (long)(x ^ y)) + file2.getName() + (String)\u039b\u03b4\u03bd\u03b4\u03c0\u039b\u03b6\u03c8\u03b7\u03be\u03b1\u03c1\u03a8.c("\u3e89", (int)z, (long)aa), exception, new Object[ae]);
                continue;
            }
            finally {
                ++this.l;
            }
        }
        this.c(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2);
    }
}

