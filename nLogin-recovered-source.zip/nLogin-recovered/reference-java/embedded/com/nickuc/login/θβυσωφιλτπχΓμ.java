/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1;
import lombok.Generated;

public class \u03b8\u03b2\u03c5\u03c3\u03c9\u03c6\u03b9\u03bb\u03c4\u03c0\u03c7\u0393\u03bc<T> {
    private final T d;

    /* synthetic */ \u03b8\u03b2\u03c5\u03c3\u03c9\u03c6\u03b9\u03bb\u03c4\u03c0\u03c7\u0393\u03bc(Object object, \u03a6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1 \u03c6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1) {
        this(object);
    }

    public T d() {
        return this.d;
    }

    @Generated
    private \u03b8\u03b2\u03c5\u03c3\u03c9\u03c6\u03b9\u03bb\u03c4\u03c0\u03c7\u0393\u03bc(T t) {
        this.d = t;
    }
}

