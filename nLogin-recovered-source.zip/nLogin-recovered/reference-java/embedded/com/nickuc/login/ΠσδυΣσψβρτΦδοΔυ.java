/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b4\u03bc\u03c0\u03c8\u03be\u03a3\u03c4\u03b4\u03a0\u03a9\u03bf\u03c5\u03b4\u03be;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5 {
    private static long al;
    private static long ak;
    private static long f;
    private static int ao;
    private static int aj;
    private static int n;
    private static int l;
    private static String[] a;
    private static long af;
    private static long o;
    private static int ap;
    private static int y;
    public static final String Y;
    private static long t;
    private static int k;
    private static long ac;
    private static long q;
    private static int w;
    private static long ah;
    private static long g;
    private static String[] b;
    private static long j;
    private static int ar;
    private static long x;
    private static int ag;
    public static final int u;
    private static int z;
    private static long d;
    private static long aq;
    private static int ad;
    private static long b;
    private static int p;
    private static long ab;
    public static final int v;
    private static long r;
    private static int i;
    private static int a;
    private static int aa;
    private static long c;
    private static int s;
    private static long ai;
    private static int e;
    private static int h;
    private static int am;
    private static long ae;
    private final \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 a;
    private static int an;
    private static long m;

    private \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3) {
        this.a = \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3;
        \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e80", (int)aa, (long)(ab ^ ac)), new \u03b4\u03bc\u03c0\u03c8\u03be\u03a3\u03c4\u03b4\u03a0\u03a9\u03bf\u03c5\u03b4\u03be(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, null));
    }

    private static String a(int n, long l) {
        l ^= 0x62L;
        l ^= 0x8BD2B503B70E467BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(17 + 52), (byte)(79 + 4), (byte)(4 + 43), (byte)(15 + 52), (byte)(16 + 50), (byte)(30 + 37), (byte)(34 + 13), 80, (byte)(4 + 71), (byte)(51 + 16), (byte)(15 + 68), (byte)(51 + 2), (byte)(15 + 65), (byte)(26 + 71), (byte)(17 + 83), (byte)(30 + 70), (byte)(42 + 63), (byte)(65 + 45), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(49 + 20), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0556\u0563\u0562\u0525\u0565\u0561\u055c\u0565\u0570\u055f\u052c\u056a\u056e\u0567\u056a\u0570\u0532\u08a4\u08c8\u08ba\u08cc\u08ab\u08cc\u08d2\u08bd\u08cd\u08d1\u08b4\u08c3\u08cf\u08a5\u08d7", (byte)106, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    public static \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5 a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        Object object;
        List<String> list;
        \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a();
        if (\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.d(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e80", (int)a, (long)(b ^ d))) == false && \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.d(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e83", (int)e, (long)(f ^ g))) == false) {
            return null;
        }
        Object t = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.d(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e86", (int)(h & i), (long)j));
        if (t == null) {
            return null;
        }
        if (t instanceof String) {
            list = Collections.singletonList(t.toString());
        } else if (t instanceof List) {
            object = (List)t;
            list = object.stream().map(Object::toString).collect(Collectors.toList());
        } else {
            throw new IllegalArgumentException((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e89", (int)(k & l), (long)m) + t);
        }
        if (list.isEmpty()) {
            throw new IllegalArgumentException((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e8c", (int)n, (long)o));
        }
        object = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e8f", (int)p, (long)(q ^ r)));
        String string = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e92", (int)s, (long)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.t));
        Object t2 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.d(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e95", (int)w, (long)x));
        if (object != null && ((String)object).isEmpty()) {
            object = null;
        }
        if (string != null && string.isEmpty()) {
            string = null;
        }
        \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 = list.size() > y ? \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, list, (String)object, string, t2) : \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, list.get(z), (String)object, string, t2);
        return new \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u04f0\u0512\u0514\u04f4\u0518\u0537\u052f\u0545\u0531\u0500\u053e\u0534\u0542\u053c\u0505\u052a\u054c\u054b\u0543\u0549\u0543\u0518", (byte)12, 69), \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u043c\u0449\u0448\u040b\u044b\u0447\u0442\u044b\u0456\u0445\u0412\u0450\u0454\u044d\u0450\u0456\u0418\u078a\u07ae\u07a0\u07b2\u0791\u07b2\u07b8\u07a3\u07b3\u07b7\u079a\u07a9\u07b5\u078b\u07bd\u0433", (byte)12, 67) + string + \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0413", (byte)12, 67) + methodType.toString(), exception);
        }
    }

    public void c() {
        this.a.close();
    }

    private static void b() {
        int n;
        c = 3352992348137954994L;
        long l = c ^ 0x8BD2B503B70E467BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(18 + 51), (byte)(53 + 30), (byte)(13 + 34), (byte)(11 + 56), (byte)(56 + 10), (byte)(40 + 27), (byte)(34 + 13), (byte)(70 + 10), (byte)(44 + 31), (byte)(64 + 3), (byte)(16 + 67), (byte)(41 + 12), (byte)(23 + 57), (byte)(49 + 48), 100, 100, (byte)(69 + 36), (byte)(77 + 33), (byte)(83 + 20)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(50 + 18), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u059c\u0594\u057d\u059c\u055b\u0560\u0574\u057a\u059e\u057d\u0573\u05a2\u0560\u0561\u0587\u0577\u059a\u0597\u05a7\u058a\u0588\u05af\u0576\u0577", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u05af\u05a7\u0590\u05af\u056e\u0573\u0587\u058d\u05b1\u0590\u0588\u05b0\u0575\u0588\u057a\u058f\u05b5\u0576\u059f\u0598\u05c2\u05b2\u0589\u058a", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0569\u059b\u059d\u055d\u0588\u0581\u0594\u0572\u059d\u0582\u0565\u0564\u0570\u0569\u059e\u05a7\u0594\u058e\u0584\u059b\u057f\u059f\u0576\u0577", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u059b\u05a2\u057f\u05a8\u05b0\u058c\u056c\u0583\u05a0\u0571\u05a5\u0570\u0588\u05b0\u05bb\u05af\u0594\u0572\u05b6\u0574\u0597\u0593\u0591\u057d\u05bc\u059c\u05c5\u05be\u0583\u0583\u05ac\u05cd\u05ac\u05c4\u0591\u0590\u0589\u05a5\u05d4\u05c4\u05a4\u0593\u05d3\u059e", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[4] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u059c\u05a7\u0580\u0587\u058f\u057e\u0596\u058e\u059f\u0570\u058a\u05af\u05ad\u05a8\u05a5\u0596\u05bc\u05b0\u0596\u0579\u05b5\u057a\u0581\u05c1\u05a4\u05b9\u0592\u0599\u0581\u0589\u05a8\u05ba\u05c6\u05c1\u05a6\u05c7\u059d\u05a6\u059e\u05c8\u05cd\u05b2\u05c7\u059e", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[5] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u056e\u057b\u0586\u055b\u0597\u0575\u057e\u058c\u0564\u057e\u059d\u0595\u05a0\u057b\u0595\u0584\u0598\u0595\u0589\u05ae\u0586\u059f\u0576\u0577", (byte)122, 67);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[6] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u01bc\u01ed\u01a4\u01d9\u01cd\u01d9\u01cb\u01c1\u01ab\u01e7\u01c4\u01ae\u01d8\u01da\u01d7\u01c6\u01f6\u01b3\u01eb\u01c8\u01cb\u01ff\u01c6\u01c7", (byte)122, 65);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[7] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0590\u0580\u059b\u056d\u058b\u05a4\u058b\u05a9\u058a\u05ac\u05a8\u05b7\u05b7\u05bc\u0597\u05b8\u0593\u0593\u059b\u05ab\u0575\u05b2\u0589\u058a", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[8] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u05a4\u058c\u0591\u058f\u05af\u059f\u0595\u0590\u056e\u0583\u059a\u0584\u058c\u05b1\u058a\u05bf\u059b\u057e\u05af\u05b6\u059f\u05c2\u0589\u058a", (byte)122, 69);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[9] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u056d\u0566\u059a\u0587\u057e\u0586\u05a2\u0588\u058d\u0588\u05b7\u057e", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0569\u0585\u056d\u0577\u055a\u056f\u05a0\u056d\u0556\u0593\u05a4\u056b", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[11] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u01e1\u01c9\u01ce\u01cc\u01ec\u01dc\u01d2\u01cd\u01ab\u01c0\u01d7\u01c1\u01c9\u01ee\u01c7\u01fc\u01d8\u01bb\u01ec\u01f3\u01dc\u01ff\u01c6\u01c7", (byte)122, 65);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[12] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u01e1\u01c9\u01ce\u01cc\u01ec\u01dc\u01d2\u01cd\u01ab\u01c0\u01d7\u01c1\u01c9\u01ee\u01c7\u01fc\u01d8\u01bb\u01ec\u01f3\u01dc\u01ff\u01c6\u01c7", (byte)122, 65);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u059c\u0594\u057d\u059c\u055b\u0560\u0574\u057a\u059e\u057d\u0573\u059a\u059f\u059e\u0595\u059e\u05a8\u05ae\u0589\u05a1\u05aa\u0579\u0576\u0577", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u05af\u05a7\u0590\u05af\u056e\u0573\u0587\u058d\u05b1\u0590\u0587\u05b7\u0586\u0588\u05ac\u05b8\u0587\u05be\u0596\u05b8\u05b1\u0598\u05b0\u057f\u05a8\u05c4\u05a4\u05ab\u05bc\u05c2\u0584\u05c5", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u01b9\u01eb\u01ed\u01ad\u01d8\u01d1\u01e4\u01c2\u01ed\u01d2\u01b5\u01c0\u01cd\u01c5\u01ea\u01fa\u01f5\u01fc\u01f3\u01cb\u01fb\u01d4\u01f8\u01be\u01cc\u0203\u01e6\u01fa\u01c6\u01d7\u0204\u01bd", (byte)122, 66);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[3] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u059b\u05a2\u057f\u05a8\u05b0\u058c\u056c\u0583\u05a0\u0571\u05a5\u0570\u0588\u05b0\u05bb\u05af\u0594\u0572\u05b6\u0574\u0597\u0593\u0591\u057d\u05bc\u059c\u05c5\u05be\u0583\u0583\u05ac\u05cd\u059b\u05c6\u05b0\u059c\u059c\u058e\u05ab\u05a6\u05aa\u05d8\u05d5\u05b4\u05bc\u05bd\u05dd\u05dd\u05b4\u059a\u05d9\u059e\u05cc\u05bc\u05a9\u05aa", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[4] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u01d9\u01e4\u01bd\u01c4\u01cc\u01bb\u01d3\u01cb\u01dc\u01ad\u01c7\u01ec\u01ea\u01e5\u01e2\u01d3\u01f9\u01ed\u01d3\u01b6\u01f2\u01b7\u01be\u01fe\u01e1\u01f6\u01cf\u01d6\u01be\u01c6\u01e5\u01f7\u020d\u01d9\u01fd\u01e1\u01e1\u01f0\u01f0\u0208\u01dc\u020b\u0208\u0206\u01e0\u0202\u01ed\u01f9\u01f4\u01f7\u020d\u01d6\u01fa\u01e9\u01e6\u01e7", (byte)122, 65);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u056e\u057b\u0586\u055b\u0597\u0575\u057e\u058c\u0564\u057e\u059f\u0599\u0579\u05a8\u0594\u0596\u057c\u05a1\u059d\u059e\u05ac\u05b0\u0572\u05ae\u05b5\u059f\u0574\u0588\u05b8\u058e\u05a6\u0583", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[6] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u056c\u059d\u0554\u0589\u057d\u0589\u057b\u0571\u055b\u0597\u0575\u05a1\u057e\u059f\u057d\u059e\u057c\u0580\u05a9\u056a\u0562\u0580\u057d\u0582\u05b1\u057f\u05aa\u0589\u05a6\u0591\u0572\u0574", (byte)122, 68);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[7] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u01cd\u01bd\u01d8\u01aa\u01c8\u01e1\u01c8\u01e6\u01c7\u01e9\u01e6\u01df\u01d6\u01d1\u01c4\u01d3\u01cf\u01fb\u01fb\u01ee\u0200\u01ef\u01c6\u01c7", (byte)122, 65);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[8] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01e1\u01c9\u01ce\u01cc\u01ec\u01dc\u01d2\u01cd\u01ab\u01c0\u01d7\u01c2\u01e6\u01ce\u01f9\u01b2\u01d1\u01dc\u01dd\u01dc\u01ec\u01c9\u01c6\u01c7", (byte)122, 66);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[9] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u056b\u057f\u059b\u057b\u05b0\u05b2\u056e\u05a6\u0574\u0571\u05a7\u057e", (byte)122, 69);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[10] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u05ad\u0590\u05a9\u05b0\u058a\u05ab\u0580\u05a4\u05b0\u058b\u0589\u057e", (byte)122, 70);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[11] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u01e1\u01c9\u01ce\u01cc\u01ec\u01dc\u01d2\u01cd\u01ab\u01c0\u01de\u01ca\u01c1\u01eb\u01e7\u01d3\u01cf\u01dd\u01fa\u01f3\u01f2\u01d9\u01c6\u01c7", (byte)122, 65);
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[12] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0591\u0579\u057e\u057c\u059c\u058c\u0582\u057d\u055b\u0570\u058f\u0594\u0580\u0567\u05a5\u0586\u0576\u059d\u05a9\u05ae\u0584\u0589\u0576\u0577", (byte)122, 68);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0593\u057b\u056d\u058c\u055e\u0581\u0559\u056e\u0571\u0590\u05a0\u056b", (byte)122, 68);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u058e\u0598\u0577\u0571\u0598\u055b\u0593\u0584\u0582\u0561\u057b\u0599\u05a3\u0569\u056a\u0595\u058a\u0589\u05ab\u059f\u0581\u0579\u0576\u0577", (byte)122, 67);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(5582698449777463668L);
        d = Long.reverse(0x4600000000000000L);
        e = (262144 >>> 242 | 262144 << -242) & 0xFFFFFFFF;
        f = Long.reverse(5582698449777463668L);
        g = Long.reverse(0x4600000000000000L);
        h = Integer.reverse(0x40000000);
        i = -1 >>> 185 | -1 << -185;
        j = Long.reverse(826897243274219892L);
        k = 3072 >>> 170 | 3072 << ~170 + 1;
        l = (-1 >>> 164 | -1 << ~164 + 1) & 0xFFFFFFFF;
        m = Long.reverse(826897243274219892L);
        n = Integer.reverse(0x20000000);
        o = Long.reverse(826897243274219892L);
        p = Integer.reverse(-1610612736);
        q = Long.reverse(5582698449777463668L);
        r = Long.reverse(0x4600000000000000L);
        s = Integer.reverse(0x60000000);
        t = Long.reverse(826897243274219892L);
        w = (0x1C000000 >>> 26 | 0x1C000000 << ~26 + 1) & 0xFFFFFFFF;
        x = Long.reverse(826897243274219892L);
        y = Integer.reverse(Integer.MIN_VALUE);
        z = 0 >>> 138 | 0 << ~138 + 1;
        aa = (0x8000000 >>> 24 | 0x8000000 << ~24 + 1) & 0xFFFFFFFF;
        ab = Long.reverse(5582698449777463668L);
        ac = Long.reverse(0x4600000000000000L);
        ad = Integer.reverse(-1879048192);
        ae = Long.reverse(5582698449777463668L);
        af = Long.reverse(0x4600000000000000L);
        ag = 0xA00000 >>> 116 | 0xA00000 << ~116 + 1;
        ah = Long.reverse(5582698449777463668L);
        ai = Long.reverse(0x4600000000000000L);
        aj = (0x1600000 >>> 85 | 0x1600000 << ~85 + 1) & 0xFFFFFFFF;
        ak = Long.reverse(5582698449777463668L);
        al = Long.reverse(0x4600000000000000L);
        am = Integer.reverse(-1342177280);
        an = 3328 >>> 104 | 3328 << ~104 + 1;
        ao = 0 >>> 114 | 0 << -114;
        ap = 786432 >>> 176 | 786432 << ~176 + 1;
        aq = Long.reverse(826897243274219892L);
        ar = 0x4000000 >>> 122 | 0x4000000 << ~122 + 1;
        a = new String[am];
        b = new String[an];
        \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.b();
        u = ao;
        Y = \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e80", (int)ap, (long)aq);
        v = ar;
    }

    public void a(int n, Consumer<JSONObject> consumer) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e80", (int)ad, (long)(ae ^ af)), n);
        JSONObject jSONObject2 = new JSONObject();
        consumer.accept(jSONObject2);
        jSONObject.put((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e83", (int)ag, (long)(ah ^ ai)), (Object)jSONObject2);
        this.a.l((String)\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.c("\u3e86", (int)aj, (long)(ak ^ al)), jSONObject.toString());
    }
}

