/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b;
import com.nickuc.login.\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8 {
    private static int d;
    private static int c;
    private static int l;
    private static int k;
    private static int j;
    private static int g;
    private static int b;
    static final /* synthetic */ int[] k;
    static final /* synthetic */ int[] j;
    private static int a;
    static final /* synthetic */ int[] i;
    private static int h;
    private static int f;
    private static int i;
    private static int e;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        c = (98304 >>> 15 | 98304 << -15) & 0xFFFFFFFF;
        d = 0x100000 >>> 114 | 0x100000 << -114;
        e = (0x40000001 >>> 94 | 0x40000001 << -94) & 0xFFFFFFFF;
        f = (0x600000 >>> 212 | 0x600000 << ~212 + 1) & 0xFFFFFFFF;
        g = 262144 >>> 18 | 262144 << -18;
        h = (2048 >>> 138 | 2048 << ~138 + 1) & 0xFFFFFFFF;
        i = 262144 >>> 242 | 262144 << ~242 + 1;
        j = (16384 >>> 77 | 16384 << ~77 + 1) & 0xFFFFFFFF;
        k = Integer.reverse(-1073741824);
        l = 8192 >>> 43 | 8192 << ~43 + 1;
        k = new int[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.values().length];
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.f.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.c.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.d.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.k[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.e.ordinal()] = f;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        j = new int[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.values().length];
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.j[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.e.ordinal()] = g;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.j[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.d.ordinal()] = h;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        i = new int[\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.values().length];
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.i[\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.c.ordinal()] = i;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.i[\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.a.ordinal()] = j;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.i[\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.b.ordinal()] = k;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03b1\u0394\u0394\u03bb\u03c2\u03a9\u03a8.i[\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.d.ordinal()] = l;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

