/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Server
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;

public class \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6
extends \u03b8\u03bd\u03b8\u03a6\u03b6\u03c9\u03a9\u03c4\u03b6\u03b4\u03c8\u03a0 {
    private static int al;
    private static int ag;
    private static String[] f;
    private static long p;
    private static int aj;
    private static int d;
    private static long q;
    private static String[] e;
    private static int am;

    private static void b() {
        int n;
        p = -5391683615072557005L;
        long l = p ^ 0x4C9CE20CBDB00F16L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(30 + 39), (byte)(5 + 78), (byte)(34 + 13), (byte)(22 + 45), (byte)(4 + 62), 67, (byte)(18 + 29), (byte)(27 + 53), (byte)(6 + 69), 67, (byte)(7 + 76), (byte)(46 + 7), (byte)(70 + 10), (byte)(26 + 71), (byte)(36 + 64), (byte)(45 + 55), (byte)(63 + 42), (byte)(50 + 60), (byte)(89 + 14)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(14 + 69)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.f[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u056b\u058f\u05a3\u05b1\u0564\u05b0\u05ad\u0573\u05ad\u0583\u05ac\u0575\u05ba\u05b1\u0586\u057b\u057c\u059d\u05ba\u059b\u0597\u05c1\u0588\u0589", (byte)121, 70);
                    continue block7;
                }
                case 1: {
                    \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.f[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01a7\u01cb\u01df\u01ed\u01a0\u01ec\u01e9\u01af\u01e9\u01bf\u01e7\u01eb\u01de\u01f6\u01ef\u01c6\u01da\u01cb\u01e7\u01d5\u01cd\u01ef\u01cc\u01f3\u01f9\u01ff\u01db\u01cd\u01f5\u01b9\u01ba\u01d4", (byte)121, 66);
                    continue block7;
                }
                case 2: {
                    \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.f[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0562\u0586\u0577\u056d\u0598\u056f\u0569\u056b\u059d\u059c\u0562\u0568", (byte)121, 68);
                    continue block7;
                }
                case 4: {
                    \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.f[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0553\u0583\u0585\u0596\u0554\u0595\u0597\u059d\u057a\u0597\u059d\u0585\u0557\u056f\u055e\u0575\u05a8\u0584\u056b\u0583\u0583\u05a4\u0580\u0589\u05ac\u05b2\u059c\u0592\u05a6\u0576\u05b2\u05a4", (byte)121, 67);
                }
            }
        }
    }

    public \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.n, (String)\u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.c("\u3e80", (int)d, (long)q), (((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b()).a() == \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b ? ag : aj) != 0);
    }

    @Override
    protected void h(String string, String string2) {
        UUID uUID = \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c(string);
        OfflinePlayer offlinePlayer = ((Server)this.m.b().c()).getOfflinePlayer(uUID);
        this.a(offlinePlayer.getName(), string2, null, uUID);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u050e\u0530\u0532\u0512\u0536\u0555\u054d\u0563\u054f\u051e\u055c\u0552\u0560\u055a\u0523\u0548\u056a\u0569\u0561\u0567\u0561\u0536", (byte)42, 69), \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0549\u0556\u0555\u0518\u0558\u0554\u054f\u0558\u0563\u0552\u051f\u055d\u0561\u055a\u055d\u0563\u0525\u08ae\u08af\u08a2\u08c3\u08b3\u08bf\u08b2\u08a4\u0539", (byte)42, 69) + string + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0520", (byte)42, 70) + methodType.toString(), exception);
        }
    }

    static {
        d = Integer.reverse(0);
        q = Long.reverse(-8064132319505075027L);
        ag = (2 >>> 129 | 2 << ~129 + 1) & 0xFFFFFFFF;
        aj = Integer.reverse(0);
        al = 1024 >>> 170 | 1024 << -170;
        am = Integer.reverse(Integer.MIN_VALUE);
        e = new String[al];
        f = new String[am];
        \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.b();
    }

    private static String a(int n, long l) {
        l ^= 0x3AL;
        l ^= 0x4C9CE20CBDB00F16L;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(36 + 33), (byte)(77 + 6), (byte)(23 + 24), (byte)(47 + 20), (byte)(60 + 6), 67, (byte)(31 + 16), (byte)(42 + 38), (byte)(46 + 29), (byte)(16 + 51), (byte)(40 + 43), (byte)(2 + 51), (byte)(56 + 24), (byte)(58 + 39), (byte)(59 + 41), (byte)(3 + 97), (byte)(92 + 13), (byte)(105 + 5), (byte)(76 + 27)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(6 + 63), (byte)(74 + 9)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0534\u0541\u0540\u0503\u0543\u053f\u053a\u0543\u054e\u053d\u050a\u0548\u054c\u0545\u0548\u054e\u0510\u0899\u089a\u088d\u08ae\u089e\u08aa\u089d\u088f", (byte)21, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b7\u03b7\u03a9\u03c9\u03b8\u03c3\u03b5\u03a6.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }
}

