/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Player$Spigot
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9
implements \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0 {
    private static int j;
    private static int h;
    private static int f;
    private static long d;
    private static int l;
    private static int e;
    private static String[] a;
    private static int i;
    private static int m;
    private static int k;
    private static long c;
    private static String[] b;
    private static int a;
    private static long b;
    private static long g;

    private static String a(int n, long l) {
        l ^= 0x6CL;
        l ^= 0x8E78E09464EB96CEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(64 + 5), (byte)(37 + 46), (byte)(38 + 9), 67, 66, (byte)(27 + 40), (byte)(31 + 16), (byte)(5 + 75), (byte)(21 + 54), (byte)(32 + 35), (byte)(22 + 61), (byte)(3 + 50), (byte)(53 + 27), (byte)(51 + 46), (byte)(17 + 83), (byte)(42 + 58), (byte)(12 + 93), (byte)(76 + 34), (byte)(73 + 30)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(51 + 32)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u043f\u044c\u044b\u040e\u044e\u044a\u0445\u044e\u0459\u0448\u0415\u0453\u0457\u0450\u0453\u0459\u041b\u07a3\u078e\u0797\u07a8\u07ad\u07a6\u07af\u07ac\u07a8\u07b0\u079a\u07af\u07c2", (byte)13, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 136 | 0 << ~136 + 1) & 0xFFFFFFFF;
        b = Long.reverse(2562517847578131193L);
        d = Long.reverse(0x3600000000000000L);
        e = 0 >>> 97 | 0 << -97;
        f = 0x10000000 >>> 252 | 0x10000000 << ~252 + 1;
        g = Long.reverse(1553711531047140089L);
        h = Integer.reverse(0x40000000);
        i = Integer.reverse(0);
        j = (0x4000000 >>> 218 | 0x4000000 << -218) & 0xFFFFFFFF;
        k = Integer.reverse(0);
        l = Integer.reverse(0x40000000);
        m = Integer.reverse(0x40000000);
        a = new String[l];
        b = new String[m];
        \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b();
    }

    public \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9() {
        Objects.requireNonNull(Player.class.getMethod((String)\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.c("\u3e80", (int)a, (long)(b ^ d)), new Class[e]));
        Class[] classArray = new Class[h];
        classArray[\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.i] = ChatMessageType.class;
        classArray[\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.j] = Array.newInstance(BaseComponent.class, k).getClass();
        Objects.requireNonNull(Player.Spigot.class.getMethod((String)\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.c("\u3e83", (int)f, (long)g), classArray));
    }

    private static void b() {
        int n;
        c = -6963551509616791100L;
        long l = c ^ 0x8E78E09464EB96CEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(65 + 4), (byte)(24 + 59), (byte)(12 + 35), 67, (byte)(30 + 36), (byte)(36 + 31), (byte)(17 + 30), (byte)(70 + 10), 75, (byte)(47 + 20), (byte)(10 + 73), (byte)(48 + 5), (byte)(52 + 28), (byte)(90 + 7), (byte)(80 + 20), (byte)(64 + 36), (byte)(60 + 45), (byte)(74 + 36), (byte)(73 + 30)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(25 + 43), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u010c\u014b\u0147\u013c\u0152\u0153\u010c\u0124\u0134\u012e\u014a\u011d", (byte)43, 65);
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u049e\u046f\u04a1\u048e\u0487\u049f\u046d\u046d\u048c\u0493\u04ac\u0471\u0471\u0487\u0489\u04b5\u047f\u048c\u0492\u0491\u0490\u049c\u0489\u048a", (byte)43, 67);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u04ad\u04ae\u047b\u049d\u0485\u0488\u0492\u0494\u04a5\u04ab\u0493\u04b1\u04bb\u0498\u048b\u0492\u0475\u047c\u0498\u049c\u04a3\u04c2\u0489\u048a", (byte)43, 68);
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u054f\u0520\u0552\u053f\u0538\u0550\u051e\u051e\u053d\u0544\u055e\u0540\u053f\u0557\u0564\u0569\u0546\u0567\u055f\u054a\u0554\u0563\u053a\u053b", (byte)43, 69);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u052d\u0513\u055e\u0557\u052d\u0559\u0531\u0558\u0561\u0546\u0545\u0541\u056b\u054c\u052b\u055a\u0569\u055d\u0571\u0548\u0553\u0563\u053a\u053b", (byte)43, 69);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0122\u0147\u011f\u012e\u012b\u0133\u0144\u0153\u014b\u014f\u010f\u0121\u014c\u012f\u013d\u0131\u015d\u013a\u0120\u0136\u013d\u013a\u0151\u0162\u014f\u013b\u0166\u0154\u016a\u013f\u0167\u0127", (byte)43, 65);
                }
            }
        }
    }

    @Override
    public void send(Player player, String string) {
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((String)string));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u00c7\u00e9\u00eb\u00cb\u00ef\u010e\u0106\u011c\u0108\u00d7\u0115\u010b\u0119\u0113\u00dc\u0101\u0123\u0122\u011a\u0120\u011a\u00ef", (byte)16, 65), \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0102\u010f\u010e\u00d1\u0111\u010d\u0108\u0111\u011c\u010b\u00d8\u0116\u011a\u0113\u0116\u011c\u00de\u0466\u0451\u045a\u046b\u0470\u0469\u0472\u046f\u046b\u0473\u045d\u0472\u0485\u00f7", (byte)16, 65) + string + \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u00d9", (byte)16, 66) + methodType.toString(), exception);
        }
    }
}

