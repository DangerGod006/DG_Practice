/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.Channel
 *  javax.annotation.Nullable
 *  net.md_5.bungee.api.connection.PendingConnection
 *  net.md_5.bungee.connection.InitialHandler
 *  net.md_5.bungee.netty.ChannelWrapper
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.connection.PendingConnection;
import net.md_5.bungee.connection.InitialHandler;
import net.md_5.bungee.netty.ChannelWrapper;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2 {
    private static long g;
    private static int j;
    private static long d;
    private static String[] a;
    private static String[] b;
    private static long f;
    private static int h;
    private static int l;
    private static long b;
    private static int a;
    private static int i;
    private static int k;
    private static int e;
    private static final Field h;
    private static long c;
    private static final Field g;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0434\u0456\u0458\u0438\u045c\u047b\u0473\u0489\u0475\u0444\u0482\u0478\u0486\u0480\u0449\u046e\u0490\u048f\u0487\u048d\u0487\u045c", (byte)29, 68), \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u053c\u0549\u0548\u050b\u054b\u0547\u0542\u054b\u0556\u0545\u0512\u0550\u0554\u054d\u0550\u0556\u0518\u08a9\u08a0\u08ac\u0888\u0897\u08b8\u08ae\u08b5\u08a3\u08bb\u08bc\u08be\u08a8\u08b9\u0532", (byte)29, 70) + string + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00f3", (byte)29, 66) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(8777105115432364439L);
        d = Long.reverse(-5332261958806667264L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(8777105115432364439L);
        g = Long.reverse(-5332261958806667264L);
        h = Integer.reverse(0);
        i = 512 >>> 72 | 512 << -72;
        j = 8 >>> 130 | 8 << -130;
        k = (0 >>> 176 | 0 << ~176 + 1) & 0xFFFFFFFF;
        l = Integer.reverse(0);
        a = new String[i];
        b = new String[j];
        \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b();
        g = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(InitialHandler.class, ChannelWrapper.class, k);
        h = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(ChannelWrapper.class, Channel.class, l);
    }

    private static String a(int n, long l) {
        l ^= 0x6DL;
        l ^= 0xE32880E432DB7EC6L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(9 + 60), (byte)(8 + 75), 47, (byte)(46 + 21), (byte)(14 + 52), (byte)(50 + 17), (byte)(26 + 21), (byte)(32 + 48), (byte)(56 + 19), (byte)(24 + 43), (byte)(45 + 38), (byte)(5 + 48), (byte)(31 + 49), (byte)(37 + 60), (byte)(32 + 68), (byte)(80 + 20), (byte)(35 + 70), (byte)(13 + 97), (byte)(61 + 42)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(38 + 45)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0533\u0540\u053f\u0502\u0542\u053e\u0539\u0542\u054d\u053c\u0509\u0547\u054b\u0544\u0547\u054d\u050f\u08a0\u0897\u08a3\u087f\u088e\u08af\u08a5\u08ac\u089a\u08b2\u08b3\u08b5\u089f\u08b0", (byte)20, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    public static Channel a(Object object, PendingConnection pendingConnection) {
        try {
            InitialHandler initialHandler = (InitialHandler)pendingConnection;
            ChannelWrapper channelWrapper = (ChannelWrapper)g.get(initialHandler);
            return (Channel)h.get(channelWrapper);
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.c("\u3e80", (int)a, (long)(b ^ d)) + object.getClass().getCanonicalName() + (String)\u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.c("\u3e83", (int)e, (long)(f ^ g)), exception, new Object[h]);
            return null;
        }
    }

    private static void b() {
        int n;
        c = -1615603081698774114L;
        long l = c ^ 0xE32880E432DB7EC6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(36 + 32), (byte)(29 + 40), (byte)(32 + 51), (byte)(27 + 20), (byte)(14 + 53), (byte)(33 + 33), (byte)(4 + 63), (byte)(31 + 16), (byte)(75 + 5), 75, (byte)(40 + 27), (byte)(54 + 29), (byte)(17 + 36), (byte)(50 + 30), (byte)(38 + 59), (byte)(6 + 94), (byte)(83 + 17), (byte)(58 + 47), 110, (byte)(82 + 21)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(5 + 63), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u052a\u053a\u053e\u054e\u055a\u0570\u0545\u0530\u0564\u0552\u0567\u052e\u056f\u0567\u0536\u057c\u0537\u0552\u0570\u0555\u054a\u054f\u0580\u057c\u0575\u0542\u0581\u054f\u0572\u0580\u0549\u058b\u057c\u054a\u055c\u0569\u0561\u054e\u0548\u0582\u056c\u055f\u0566\u055b", (byte)106, 67);
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0561\u0557\u054f\u053e\u053f\u0547\u0546\u053c\u0531\u053f\u0546\u053b", (byte)106, 68);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u055d\u056d\u0571\u0581\u058d\u05a3\u0578\u0563\u0597\u0585\u059a\u0561\u05a2\u059a\u0569\u05af\u056a\u0585\u05a3\u0588\u057d\u0582\u05b3\u05af\u05a8\u0575\u05b4\u0582\u05a5\u05b3\u057c\u05be\u05ac\u0595\u0577\u0581\u05bf\u057d\u05b1\u0593\u05c4\u059b\u0581\u05c4\u05ab\u05c4\u05cb\u05c7\u05d0\u05cd\u05a1\u059f\u05b2\u05ac\u0599\u059a", (byte)106, 69);
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0548\u055c\u0525\u0542\u0566\u052e\u0548\u055d\u0547\u054b\u0533\u0542\u0576\u0573\u054c\u0553\u057c\u0553\u0573\u055d\u0570\u056f\u0546\u0547", (byte)106, 68);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u01bf\u019b\u01a0\u0197\u01ba\u01be\u0188\u019f\u019d\u0195\u01d0\u019b", (byte)106, 65);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03b5\u03c0\u039b\u03a9\u03c9\u03be\u03c4\u03b1\u03c8\u03c8\u03c9\u03b2\u03c2.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0595\u0592\u059b\u059b\u056e\u0572\u0573\u0592\u0593\u0598\u0583\u059d\u0581\u05ad\u057d\u056d\u057b\u056d\u057b\u056a\u056d\u05b2\u0579\u057a", (byte)106, 70);
                }
            }
        }
    }
}

