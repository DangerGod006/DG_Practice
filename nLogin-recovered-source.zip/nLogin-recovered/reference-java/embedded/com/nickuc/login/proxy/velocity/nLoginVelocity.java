/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.ServerConnectType
 *  com.nickuc.login.api.enums.event.EventEnum
 *  com.nickuc.login.api.event.internal.velocity.VelocityCancellableEvent
 *  com.nickuc.login.api.event.velocity.connection.ServerPreConnectEvent
 *  com.nickuc.login.loader.platform.VelocityLoader
 *  com.velocitypowered.api.proxy.ConnectionRequestBuilder$Status
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.ServerConnection
 *  com.velocitypowered.api.proxy.messages.ChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login.proxy.velocity;

import com.nickuc.login.api.enums.ServerConnectType;
import com.nickuc.login.api.enums.event.EventEnum;
import com.nickuc.login.api.event.internal.velocity.VelocityCancellableEvent;
import com.nickuc.login.api.event.velocity.connection.ServerPreConnectEvent;
import com.nickuc.login.loader.platform.VelocityLoader;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3;
import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.velocitypowered.api.proxy.ConnectionRequestBuilder;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class nLoginVelocity
extends \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9
implements \u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7,
\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3 {
    private static long t;
    private static int ad;
    private static int be;
    private final ChannelIdentifier d;
    private static int u;
    private static int al;
    private static long aq;
    private static int aa;
    private static long an;
    private static String[] c;
    private static long z;
    private static long v;
    private static int s;
    private static long q;
    private static long ap;
    private static int ax;
    private static int bg;
    private static int ai;
    private static long ae;
    private static long w;
    private static int ar;
    private static int j;
    private static long ak;
    private static int as;
    private static long aj;
    private static int bd;
    private static int bm;
    private static int ab;
    private static long l;
    private static int m;
    private static long ah;
    private static int bc;
    private static long ag;
    private static long am;
    private static int bk;
    private static long e;
    private static int av;
    private static int az;
    private static int bn;
    private static long y;
    private static int bf;
    private final ChannelIdentifier c = new LegacyChannelIdentifier((String)nLoginVelocity.c("\u3e98", (int)ai, (long)(aj ^ ak)));
    private static long at;
    private static long au;
    private static long ac;
    private static int bh;
    private static int ay;
    private \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd a;
    private static int ao;
    private static long n;
    private static int bb;
    private static String[] d;
    private static int bi;
    private static int af;
    private static long k;
    private static int x;
    private static int aw;
    private static int ba;
    private static long bl;
    private static int bj;

    @Override
    protected void i() {
        this.a().a().configureFilter(Collections.singleton(nLoginVelocity.c("\u3e80", (int)as, (long)(at ^ au))));
        super.i();
    }

    @Override
    protected void j() {
        this.a = new \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd(this.a(), this.b());
        super.j();
    }

    @Override
    public boolean callEvent(Object object) {
        this.a().getEventManager().fireAndForget(object);
        return (!(object instanceof VelocityCancellableEvent) || !((VelocityCancellableEvent)object).isCancelled() ? ay : az) != 0;
    }

    public nLoginVelocity(VelocityLoader velocityLoader) {
        super(velocityLoader, (String)nLoginVelocity.c("\u3e80", (int)j, (long)(k ^ l)), new \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3((String)nLoginVelocity.c("\u3e83", (int)m, (long)(n ^ q)), (String)nLoginVelocity.c("\u3e86", (int)s, (long)t), (String)nLoginVelocity.c("\u3e89", (int)u, (long)(v ^ w)), (String)nLoginVelocity.c("\u3e8c", (int)x, (long)(y ^ z)), (String)nLoginVelocity.c("\u3e8f", (int)(aa & ab), (long)ac), (String)nLoginVelocity.c("\u3e92", (int)ad, (long)ae), (String)nLoginVelocity.c("\u3e95", (int)af, (long)(ag ^ ah))));
        this.d = MinecraftChannelIdentifier.create((String)nLoginVelocity.c("\u3e9b", (int)al, (long)(am ^ an)), (String)nLoginVelocity.c("\u3e9e", (int)ao, (long)(ap ^ aq)));
        this.a(new \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6(new \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8(this), this, ar != 0));
    }

    @Override
    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R()) {
            return av != 0;
        }
        Player player = (Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
        Optional optional = player.getCurrentServer();
        return (optional.isPresent() && optional.map(serverConnection -> (!serverConnection.getServer().getPlayersConnected().isEmpty() ? bb : bc) != 0).get() != false ? aw : ax) != 0;
    }

    @Override
    public Class<?> getPlayerClass() {
        return Player.class;
    }

    @Override
    protected \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return \u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5.values();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(nLoginVelocity.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u052c\u054e\u0550\u0530\u0554\u0573\u056b\u0581\u056d\u053c\u057a\u0570\u057e\u0578\u0541\u0566\u0588\u0587\u057f\u0585\u057f\u0554", (byte)72, 70), nLoginVelocity.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0567\u0574\u0573\u0536\u0576\u0572\u056d\u0576\u0581\u0570\u053d\u057b\u057f\u0578\u057b\u0581\u0543\u0585\u0588\u0586\u0590\u0592\u0549\u0591\u0581\u0589\u058d\u0582\u0589\u0595\u059b\u0552\u0592\u0571\u0595\u058e\u0591\u0597\u0580\u0590\u0598\u059c\u0591\u0598\u05a4\u05aa\u056c", (byte)72, 70) + string + \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0149", (byte)72, 66) + methodType.toString(), exception);
        }
    }

    @Override
    public \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, String string, ServerConnectType serverConnectType, @Nullable \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9) {
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R()) {
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.c;
        }
        return this.a().getServer(string).map(registeredServer -> {
            Player player = (Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
            Object[] objectArray = new Object[bd];
            objectArray[nLoginVelocity.be] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
            objectArray[nLoginVelocity.bf] = serverConnectType;
            objectArray[nLoginVelocity.bg] = registeredServer;
            ServerPreConnectEvent serverPreConnectEvent = (ServerPreConnectEvent)this.a().a(EventEnum.SERVER_PRE_CONNECT, objectArray);
            if (!this.a().callEvent(serverPreConnectEvent)) {
                return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b;
            }
            registeredServer = serverPreConnectEvent.getServer();
            Optional optional = player.getCurrentServer();
            if (optional.isPresent() && registeredServer.getServerInfo().equals((Object)((ServerConnection)optional.get()).getServerInfo())) {
                if (\u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 != null) {
                    \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9.done(bh != 0);
                }
                return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a;
            }
            if (\u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 == null) {
                player.createConnectionRequest(registeredServer).connect().whenComplete((result, throwable) -> {
                    if (!result.isSuccessful() && result.getStatus() != ConnectionRequestBuilder.Status.ALREADY_CONNECTED) {
                        player.disconnect((Component)result.getReasonComponent().orElse(Component.text((String)((String)nLoginVelocity.c("\u3e80", (int)bk, (long)bl) + string))));
                    }
                });
            } else {
                player.createConnectionRequest(registeredServer).connectWithIndication().whenComplete((bl, throwable) -> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9.done((bl != null && throwable == null && bl != false ? bi : bj) != 0));
            }
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a;
        }).orElse(\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.c);
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b() {
        return this.a(ba != 0);
    }

    private static String a(int n, long l) {
        l ^= 0x34L;
        l ^= 0x7CBDA38CA8BC2EE4L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(68 + 1), (byte)(72 + 11), (byte)(36 + 11), (byte)(49 + 18), (byte)(49 + 17), (byte)(32 + 35), (byte)(27 + 20), (byte)(28 + 52), (byte)(60 + 15), (byte)(41 + 26), 83, (byte)(30 + 23), (byte)(55 + 25), (byte)(45 + 52), (byte)(86 + 14), (byte)(35 + 65), 105, (byte)(11 + 99), (byte)(46 + 57)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(39 + 30), (byte)(28 + 55)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u055b\u0568\u0567\u052a\u056a\u0566\u0561\u056a\u0575\u0564\u0531\u056f\u0573\u056c\u056f\u0575\u0537\u0579\u057c\u057a\u0584\u0586\u053d\u0585\u0575\u057d\u0581\u0576\u057d\u0589\u058f\u0546\u0586\u0565\u0589\u0582\u0585\u058b\u0574\u0584\u058c\u0590\u0585\u058c\u0598\u059e", (byte)60, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            nLoginVelocity.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    @Override
    @Generated
    public ChannelIdentifier b() {
        return this.d;
    }

    private static void b() {
        int n;
        e = -2658778895444079479L;
        long l = e ^ 0x7CBDA38CA8BC2EE4L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(31 + 37), 69, (byte)(51 + 32), (byte)(36 + 11), (byte)(47 + 20), (byte)(3 + 63), (byte)(32 + 35), (byte)(40 + 7), (byte)(59 + 21), (byte)(16 + 59), 67, (byte)(7 + 76), (byte)(42 + 11), (byte)(64 + 16), (byte)(20 + 77), (byte)(81 + 19), (byte)(76 + 24), (byte)(72 + 33), (byte)(39 + 71), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(29 + 40), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    nLoginVelocity.d[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0492\u049c\u0468\u0466\u048f\u0474\u049d\u0458\u0454\u047e\u0492\u0469", (byte)36, 68);
                    nLoginVelocity.d[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u044c\u0477\u046c\u0486\u046d\u045b\u0494\u048a\u0471\u0494\u0472\u045c\u0482\u0480\u0464\u047a\u04a3\u04ac\u0496\u046c\u0478\u047b\u0488\u0485\u04b0\u046c\u04b1\u04a6\u0484\u04aa\u0491\u049a", (byte)36, 67);
                    nLoginVelocity.d[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u011c\u0130\u0123\u0110\u011d\u010e\u0131\u013f\u00ff\u013d\u0105\u0103\u012a\u0127\u0149\u012c\u010f\u013c\u0151\u0149\u0124\u0133\u0156\u0156\u012a\u0150\u0158\u0116\u0129\u0126\u0152\u0131\u014a\u0139\u015d\u015b\u014d\u0117\u015e\u0164\u0128\u0147\u0126\u013d\u014a\u0155\u013a\u0162\u0160\u012f\u0148\u0170\u0175\u0161\u0166\u014f\u016d\u0133\u014b\u015c\u015d\u0152\u017b\u013d\u016a\u0177\u017b\u017f\u0142\u017e\u0180\u0159\u0168\u0157\u0178\u0157\u017e\u018d\u014e\u0186\u0158\u0150\u0190\u0190\u018b\u0171\u0163\u0194\u018e\u0170\u0159\u0170\u016a\u017d\u015e\u019d", (byte)36, 65);
                    nLoginVelocity.d[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u013a\u0118\u0131\u00ff\u013a\u0111\u0133\u0139\u0128\u0133\u0133\u0106\u0115\u0147\u011a\u0146\u0107\u0123\u011d\u014d\u0146\u0143\u0154\u0147\u012a\u0133\u0154\u0158\u013c\u014b\u0138\u0127\u0120\u0117\u0158\u0161\u0155\u013e\u0121\u0134\u015e\u0160\u016b\u0144\u013f\u016a\u0145\u0166\u016e\u014f\u0163\u0169\u014b\u0149\u0163\u0141\u0164\u0133\u0154\u016d\u016c\u0165\u0170\u0139\u0161\u0158\u014b\u0159\u016f\u0145\u0177\u015b\u0170\u0171\u0183\u0153\u014c\u015a\u0163\u0141\u0189\u0179\u0182\u016e\u0162\u0153\u0163\u016f\u014a\u0154\u0174\u0164\u018a\u014f\u0156\u0175", (byte)36, 66);
                    nLoginVelocity.d[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u012b\u010c\u0110\u0142\u0122\u0118\u0147\u0127\u0102\u0114\u0148\u0128\u010c\u0121\u0139\u010f\u0151\u0140\u0126\u010c\u012d\u0122\u014f\u0113\u0124\u014c\u014c\u0158\u013d\u0127\u011a\u012d\u0117\u011e\u013a\u0159\u015e\u011d\u015d\u013f\u0144\u015b\u015b\u014c\u015c\u0164\u016d\u012e\u0159\u015a\u013e\u012c\u0173\u0140\u0146\u0158\u0171\u0137\u016f\u0163\u0148\u0177\u0138\u0154\u0154\u0173\u013c\u0163\u0163\u0150\u0186\u0167\u013a\u0186\u0143\u017e\u018c\u0148\u0182\u0145\u018d\u0170\u0172\u0182\u0182\u015e\u0190\u018f\u0167\u017a\u0164\u014d\u0176\u0172\u0179\u018a", (byte)36, 66);
                    nLoginVelocity.d[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0546\u0551\u0523\u0528\u0554\u0553\u0550\u0556\u054c\u0560\u0563\u0524\u0542\u0538\u055f\u0560\u0568\u052a\u0548\u054a\u0566\u0524\u0541\u0539\u0548\u0560\u0546\u056b\u055f\u0574\u0568\u0566\u0553\u0544\u0532\u054c\u0557\u0551\u0549\u054d\u056b\u0560\u056c\u0541\u0560\u057a\u057f\u0589\u0546\u0581\u055a\u0574\u0544\u054e\u0562\u056f\u0581\u057a\u056e\u0572\u0596\u0589\u0598\u0574\u0594\u0575\u0583\u0596\u055b\u0578\u055e\u0556\u057c\u055e\u0561\u0598\u05a3\u059e\u0572\u0591\u0560\u0594\u057b\u0597\u0599\u057c\u059b\u0589\u05b1\u0593\u0583\u0585\u05b1\u0597\u0598\u0581", (byte)36, 70);
                    nLoginVelocity.d[6] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0514\u054b\u0559\u0553\u055d\u0547\u051c\u0530\u055f\u0563\u053b\u0557\u054e\u051d\u0555\u0555\u0546\u0535\u0546\u0523\u0563\u056e\u0565\u055a\u054d\u0548\u056d\u054d\u055d\u0577\u0557\u0549\u0566\u054d\u054a\u0569\u054d\u055d\u0574\u054c\u055d\u0581\u0564\u0561\u055f\u0557\u0552\u055f\u0545\u0568\u054b\u0543\u0557\u056d\u057f\u0582\u057a\u058d\u0565\u055f\u056c\u054c\u0565\u0560\u0575\u0569\u0570\u0558\u0574\u0575\u0559\u059b\u0574\u0560\u056e\u0585\u0596\u05a5\u055d\u059d\u059d\u059e\u057b\u05a7\u0598\u056e\u0585\u058d\u0581\u0584\u058e\u0570\u0595\u05ad\u058e\u058e", (byte)36, 70);
                    nLoginVelocity.d[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u011d\u0134\u010c\u0141\u012c\u00f7\u0142\u0127\u0124\u011f\u013b\u011b\u013d\u0135\u011e\u011b\u010d\u013d\u011a\u010a\u010d\u012a\u0156\u0157\u0151\u012c\u0153\u013c\u012a\u0126\u0134\u0138\u0119\u011c\u012b\u0143\u0141\u0152\u0146\u0133\u015d\u015e\u016b\u0138\u0129\u0167\u016d\u0164\u014f\u016a\u0162\u016f\u0134\u0167\u0152\u0157\u016e\u012b\u0150\u0150\u0150\u0137\u0130\u015a\u014b\u0162\u0161\u0174\u014c\u015e\u0159\u0186\u0152\u0146\u0174\u0159\u014c\u0186\u0168\u0184\u0165\u0172\u0160\u017b\u015f\u0189\u0148\u0150\u0156\u0196\u0191\u0171\u016b\u0197\u0171\u0151", (byte)36, 65);
                    nLoginVelocity.d[8] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0514\u0555\u0516\u0534\u0554\u0549\u0518\u0535\u054c\u0539\u0539\u051a\u0539\u0564\u0552\u0554\u0524\u053d\u0541\u0563\u0558\u056c\u0533\u0534", (byte)36, 70);
                    nLoginVelocity.d[9] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0110\u013c\u010e\u011f\u0117\u010f\u0124\u011b\u0117\u0101\u0144\u010f", (byte)36, 65);
                    nLoginVelocity.d[10] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0135\u0135\u0100\u0111\u0135\u0122\u0121\u0111\u0123\u00ff\u0140\u010f", (byte)36, 65);
                    nLoginVelocity.d[11] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0140\u0116\u0112\u0133\u0141\u0141\u011d\u0107\u0100\u0144\u0147\u0103\u0129\u012d\u0123\u010f\u013b\u012c\u013f\u012b\u0140\u011d\u011a\u011b", (byte)36, 66);
                    nLoginVelocity.d[12] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0497\u047c\u046d\u0499\u0456\u0495\u04a1\u0489\u049f\u049f\u047e\u0490\u0486\u04a4\u045f\u047b\u0497\u047c\u048a\u0497\u04a0\u046c\u04ab\u0486\u049d\u0483\u0495\u046f\u0476\u0493\u04ac\u0496\u04ae\u0494\u0498\u0491\u04bf\u0490\u049f\u04b6\u0482\u0495\u04a2\u049c\u04b6\u0480\u0493\u04bd\u0482\u0487\u04c0\u04cc\u04a9\u0497\u04a8\u04c9\u049e\u04a1\u0491\u04a5\u04ad\u0490\u0495\u04ba", (byte)36, 67);
                    continue block7;
                }
                case 1: {
                    nLoginVelocity.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0548\u0539\u0535\u0535\u0525\u0533\u0515\u051e\u054e\u054e\u0519\u0552\u0563\u0525\u0522\u051f\u055e\u0565\u0524\u052a\u0544\u0536\u0533\u0534", (byte)36, 70);
                    nLoginVelocity.d[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u050b\u0536\u052b\u0545\u052c\u051a\u0553\u0549\u0530\u0553\u0531\u051b\u0541\u053f\u0523\u0539\u0562\u056b\u0555\u052b\u0537\u0536\u0545\u0528\u0545\u0540\u055d\u0540\u0574\u0575\u0536\u0567", (byte)36, 70);
                    nLoginVelocity.d[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0476\u048a\u047d\u046a\u0477\u0468\u048b\u0499\u0459\u0497\u045f\u045d\u0484\u0481\u04a3\u0486\u0469\u0496\u04ab\u04a3\u047e\u048d\u04b0\u04b0\u0484\u04aa\u04b2\u0470\u0483\u0480\u04ac\u048b\u04a4\u0493\u04b7\u04b5\u04a7\u0471\u04b8\u04be\u0482\u04a1\u0480\u0497\u04a4\u04af\u0494\u04bc\u04ba\u0489\u04a2\u04ca\u04cf\u04bb\u04c0\u04a9\u04c7\u048d\u04a5\u04b6\u04b7\u04ac\u04d5\u0497\u04c4\u04d1\u04d5\u04d9\u049c\u04d8\u04da\u04b3\u04c2\u04b1\u04d2\u04b1\u04d8\u04e7\u04a8\u04e0\u04b2\u04aa\u04ea\u04ea\u04e5\u04d7\u04f0\u04df\u04ea\u04e8\u04c0\u04b5\u04f1\u04d2\u04b1\u04b1", (byte)36, 67);
                    nLoginVelocity.d[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u0494\u0472\u048b\u0459\u0494\u046b\u048d\u0493\u0482\u048d\u048d\u0460\u046f\u04a1\u0474\u04a0\u0461\u047d\u0477\u04a7\u04a0\u049d\u04ae\u04a1\u0484\u048d\u04ae\u04b2\u0496\u04a5\u0492\u0481\u047a\u0471\u04b2\u04bb\u04af\u0498\u047b\u048e\u04b8\u04ba\u04c5\u049e\u0499\u04c4\u049f\u04c0\u04c8\u04a9\u04bd\u04c3\u04a5\u04a3\u04bd\u049b\u04be\u048d\u04ae\u04c7\u04c6\u04bf\u04ca\u0493\u04bb\u04b2\u04a5\u04b3\u04c9\u049f\u04d1\u04b5\u04ca\u04cb\u04dd\u04ad\u04a6\u04b4\u04bd\u049b\u04e3\u04d3\u04dc\u04c8\u04bc\u04aa\u04c2\u04ea\u04e2\u04ab\u04bc\u04c7\u04f1\u04f6\u04b8\u04d9", (byte)36, 68);
                    nLoginVelocity.d[4] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0544\u0525\u0529\u055b\u053b\u0531\u0560\u0540\u051b\u052d\u0561\u0541\u0525\u053a\u0552\u0528\u056a\u0559\u053f\u0525\u0546\u053b\u0568\u052c\u053d\u0565\u0565\u0571\u0556\u0540\u0533\u0546\u0530\u0537\u0553\u0572\u0577\u0536\u0576\u0558\u055d\u0574\u0574\u0565\u0575\u057d\u0586\u0547\u0572\u0573\u0557\u0545\u058c\u0559\u055f\u0571\u058a\u0550\u0588\u057c\u0561\u0590\u0551\u056d\u056d\u058c\u0555\u057c\u057c\u0569\u059f\u0580\u0553\u059f\u055c\u0597\u05a5\u0561\u059b\u055e\u05a6\u0589\u058b\u059b\u059b\u0578\u058c\u05a7\u05a0\u058f\u05b0\u05b1\u058a\u05a0\u05b3\u0583", (byte)36, 69);
                    nLoginVelocity.d[5] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0546\u0551\u0523\u0528\u0554\u0553\u0550\u0556\u054c\u0560\u0563\u0524\u0542\u0538\u055f\u0560\u0568\u052a\u0548\u054a\u0566\u0524\u0541\u0539\u0548\u0560\u0546\u056b\u055f\u0574\u0568\u0566\u0553\u0544\u0532\u054c\u0557\u0551\u0549\u054d\u056b\u0560\u056c\u0541\u0560\u057a\u057f\u0589\u0546\u0581\u055a\u0574\u0544\u054e\u0562\u056f\u0581\u057a\u056e\u0572\u0596\u0589\u0598\u0574\u0594\u0575\u0583\u0596\u055b\u0578\u055e\u0556\u057c\u055e\u0561\u0598\u05a3\u059e\u0572\u0591\u0560\u0594\u057b\u0597\u0599\u0576\u0565\u057d\u05a7\u059d\u059d\u0587\u057f\u059f\u0587\u05b6", (byte)36, 70);
                    nLoginVelocity.d[6] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u00fb\u0132\u0140\u013a\u0144\u012e\u0103\u0117\u0146\u014a\u0122\u013e\u0135\u0104\u013c\u013c\u012d\u011c\u012d\u010a\u014a\u0155\u014c\u0141\u0134\u012f\u0154\u0134\u0144\u015e\u013e\u0130\u014d\u0134\u0131\u0150\u0134\u0144\u015b\u0133\u0144\u0168\u014b\u0148\u0146\u013e\u0139\u0146\u012c\u014f\u0132\u012a\u013e\u0154\u0166\u0169\u0161\u0174\u014c\u0146\u0153\u0133\u014c\u0147\u015c\u0150\u0157\u013f\u015b\u015c\u0140\u0182\u015b\u0147\u0155\u016c\u017d\u018c\u0144\u0184\u0184\u0185\u0162\u018e\u017f\u0153\u0171\u0156\u0169\u0154\u0169\u0164\u017a\u018a\u0193\u0151", (byte)36, 66);
                    nLoginVelocity.d[7] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0477\u048e\u0466\u049b\u0486\u0451\u049c\u0481\u047e\u0479\u0495\u0475\u0497\u048f\u0478\u0475\u0467\u0497\u0474\u0464\u0467\u0484\u04b0\u04b1\u04ab\u0486\u04ad\u0496\u0484\u0480\u048e\u0492\u0473\u0476\u0485\u049d\u049b\u04ac\u04a0\u048d\u04b7\u04b8\u04c5\u0492\u0483\u04c1\u04c7\u04be\u04a9\u04c4\u04bc\u04c9\u048e\u04c1\u04ac\u04b1\u04c8\u0485\u04aa\u04aa\u04aa\u0491\u048a\u04b4\u04a5\u04bc\u04bb\u04ce\u04a6\u04b8\u04b3\u04e0\u04ac\u04a0\u04ce\u04b3\u04a6\u04e0\u04c2\u04de\u04bf\u04cc\u04ba\u04d5\u04b9\u04e6\u04ef\u04ce\u04df\u04dd\u04cd\u04e8\u04d1\u04e1\u04e7\u04c8", (byte)36, 67);
                    nLoginVelocity.d[8] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0514\u0555\u0516\u0534\u0554\u0549\u0518\u0535\u054c\u0539\u053a\u0533\u0565\u054e\u0527\u0522\u055c\u0539\u053b\u054c\u0539\u055c\u0533\u0534", (byte)36, 69);
                    nLoginVelocity.d[9] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0492\u0475\u0458\u0459\u0497\u045c\u045e\u0458\u0497\u0471\u0463\u0490\u047d\u0484\u0468\u049e\u04a8\u049a\u0486\u04a0\u047f\u049d\u0474\u0475", (byte)36, 68);
                    nLoginVelocity.d[10] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u048c\u0470\u048e\u048c\u0493\u045a\u0498\u0453\u0454\u049c\u046c\u0469", (byte)36, 68);
                    nLoginVelocity.d[11] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0559\u052f\u052b\u054c\u055a\u055a\u0536\u0520\u0519\u055d\u0560\u0532\u0521\u055e\u0519\u051a\u0531\u0547\u0565\u0540\u0562\u056c\u0533\u0534", (byte)36, 69);
                    nLoginVelocity.d[12] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u013d\u0122\u0113\u013f\u00fc\u013b\u0147\u012f\u0145\u0145\u0124\u0136\u012c\u014a\u0105\u0121\u013d\u0122\u0130\u013d\u0146\u0112\u0151\u012c\u0143\u0129\u013b\u0115\u011c\u0139\u0152\u013c\u0154\u013a\u013e\u0137\u0165\u0136\u0145\u015c\u0128\u013b\u0148\u0142\u015c\u0126\u0139\u0163\u0128\u012d\u0166\u0172\u014f\u0143\u016f\u0156\u012a\u014f\u0168\u0150\u0134\u0156\u0136\u013e", (byte)36, 65);
                    continue block7;
                }
                case 2: {
                    nLoginVelocity.d[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0472\u0476\u0477\u0479\u045a\u048b\u048b\u046b\u047f\u0482\u0460\u04a2\u046e\u047e\u0498\u04a6\u045c\u0498\u048b\u047b\u049f\u04ad\u0474\u0475", (byte)36, 68);
                    continue block7;
                }
                case 4: {
                    nLoginVelocity.d[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0547\u0534\u0556\u0512\u053b\u054d\u054c\u0530\u0552\u0538\u053e\u055e\u0532\u0544\u055c\u0534\u0557\u0569\u0534\u0546\u0548\u056c\u0533\u0534", (byte)36, 70);
                }
            }
        }
    }

    @Override
    @Generated
    public \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd a() {
        return this.a;
    }

    @Override
    public boolean t(String string) {
        return this.a().getServer(string).isPresent();
    }

    @Generated
    public ChannelIdentifier a() {
        return this.c;
    }

    static {
        j = Integer.reverse(0);
        k = Long.reverse(-7984878778692642597L);
        l = Long.reverse(0x2C00000000000000L);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Long.reverse(-7984878778692642597L);
        q = Long.reverse(0x2C00000000000000L);
        s = Integer.reverse(0x40000000);
        t = Long.reverse(-4814344641023813413L);
        u = Integer.reverse(-1073741824);
        v = Long.reverse(-7984878778692642597L);
        w = Long.reverse(0x2C00000000000000L);
        x = 0x400000 >>> 148 | 0x400000 << -148;
        y = Long.reverse(-7984878778692642597L);
        z = Long.reverse(0x2C00000000000000L);
        aa = (0x500000 >>> 180 | 0x500000 << -180) & 0xFFFFFFFF;
        ab = Integer.reverse(-1);
        ac = Long.reverse(-4814344641023813413L);
        ad = (48 >>> 163 | 48 << -163) & 0xFFFFFFFF;
        ae = Long.reverse(-4814344641023813413L);
        af = Integer.reverse(-536870912);
        ag = Long.reverse(-7984878778692642597L);
        ah = Long.reverse(0x2C00000000000000L);
        ai = Integer.reverse(0x10000000);
        aj = Long.reverse(-7984878778692642597L);
        ak = Long.reverse(0x2C00000000000000L);
        al = 589824 >>> 16 | 589824 << ~16 + 1;
        am = Long.reverse(-7984878778692642597L);
        an = Long.reverse(0x2C00000000000000L);
        ao = (-2147483646 >>> 94 | -2147483646 << -94) & 0xFFFFFFFF;
        ap = Long.reverse(-7984878778692642597L);
        aq = Long.reverse(0x2C00000000000000L);
        ar = Integer.reverse(0);
        as = Integer.reverse(-805306368);
        at = Long.reverse(-7984878778692642597L);
        au = Long.reverse(0x2C00000000000000L);
        av = (0 >>> 67 | 0 << -67) & 0xFFFFFFFF;
        aw = (1 >>> 128 | 1 << -128) & 0xFFFFFFFF;
        ax = Integer.reverse(0);
        ay = Integer.reverse(Integer.MIN_VALUE);
        az = (0 >>> 63 | 0 << -63) & 0xFFFFFFFF;
        ba = Integer.reverse(Integer.MIN_VALUE);
        bb = (0x4000000 >>> 90 | 0x4000000 << -90) & 0xFFFFFFFF;
        bc = Integer.reverse(0);
        bd = 6144 >>> 203 | 6144 << ~203 + 1;
        be = Integer.reverse(0);
        bf = Integer.reverse(Integer.MIN_VALUE);
        bg = Integer.reverse(0x40000000);
        bh = Integer.reverse(Integer.MIN_VALUE);
        bi = Integer.reverse(Integer.MIN_VALUE);
        bj = 0 >>> 194 | 0 << ~194 + 1;
        bk = 192 >>> 36 | 192 << -36;
        bl = Long.reverse(-4814344641023813413L);
        bm = (104 >>> 163 | 104 << ~163 + 1) & 0xFFFFFFFF;
        bn = 6656 >>> 201 | 6656 << -201;
        c = new String[bm];
        d = new String[bn];
        nLoginVelocity.b();
    }

    @Override
    @Nullable
    public String a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
        Player player = (Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
        return player.getCurrentServer().map(serverConnection -> serverConnection.getServerInfo().getName()).orElse(null);
    }

    @Override
    public \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a() {
        return (\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)super.b();
    }
}

