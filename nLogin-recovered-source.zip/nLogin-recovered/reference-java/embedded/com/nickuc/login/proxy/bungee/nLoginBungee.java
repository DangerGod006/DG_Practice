/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.ServerConnectType
 *  com.nickuc.login.api.enums.event.EventEnum
 *  com.nickuc.login.api.event.bungee.connection.ServerPreConnectEvent
 *  com.nickuc.login.loader.platform.BungeeLoader
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  net.md_5.bungee.api.ServerConnectRequest
 *  net.md_5.bungee.api.ServerConnectRequest$Builder
 *  net.md_5.bungee.api.ServerConnectRequest$Result
 *  net.md_5.bungee.api.config.ServerInfo
 *  net.md_5.bungee.api.connection.ProxiedPlayer
 *  net.md_5.bungee.api.connection.Server
 *  net.md_5.bungee.api.event.ServerConnectEvent$Reason
 *  net.md_5.bungee.api.plugin.Cancellable
 *  net.md_5.bungee.api.plugin.Event
 */
package com.nickuc.login.proxy.bungee;

import com.nickuc.login.api.enums.ServerConnectType;
import com.nickuc.login.api.enums.event.EventEnum;
import com.nickuc.login.api.event.bungee.connection.ServerPreConnectEvent;
import com.nickuc.login.loader.platform.BungeeLoader;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b6\u03b2\u03ba\u03c8\u03b3\u03b1\u03c9\u03b7\u03ba\u03a0\u03a0;
import com.nickuc.login.\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.md_5.bungee.api.ServerConnectRequest;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.connection.Server;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.plugin.Cancellable;
import net.md_5.bungee.api.plugin.Event;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class nLoginBungee
extends \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393
implements \u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7,
\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3 {
    private static int bv;
    private static int aq;
    private static int bl;
    private static int cc;
    private static int bb;
    private static long cd;
    private static String[] c;
    private static int co;
    private static int bt;
    private \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd a;
    private static long n;
    private static int bx;
    private static long u;
    private static int cn;
    private static int bz;
    private static int j;
    private static int o;
    private static long t;
    private static int ci;
    private static long e;
    private static long h;
    private static int ah;
    private static long aj;
    private static long ce;
    private static long ab;
    private static String[] d;
    private static int bw;
    private static long k;
    private static int bu;
    private static long cg;
    private static long q;
    private static int ca;
    private static int aa;
    private static int al;
    private static int r;
    private static int p;
    private static int aw;
    private static int l;
    private static int as;
    private static int cm;
    private static int cl;
    private static int bo;
    private static long ch;
    private static long i;
    private static int ax;
    private static int g;
    private static int bp;
    private static int cb;
    private static int cf;
    private static long am;
    private static long au;
    private static int cj;
    private static int by;
    private static long ap;
    private static long ck;

    @Override
    @Generated
    public \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd a() {
        return this.a;
    }

    @Override
    public Class<?> getPlayerClass() {
        return ProxiedPlayer.class;
    }

    static {
        g = (0 >>> 171 | 0 << -171) & 0xFFFFFFFF;
        h = Long.reverse(-1340335484439930318L);
        i = Long.reverse(0x5000000000000000L);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(-4799099998260471246L);
        l = 524288 >>> 210 | 524288 << ~210 + 1;
        n = Long.reverse(-4799099998260471246L);
        o = Integer.reverse(-1073741824);
        p = Integer.reverse(-1);
        q = Long.reverse(-4799099998260471246L);
        r = (Integer.MIN_VALUE >>> 29 | Integer.MIN_VALUE << -29) & 0xFFFFFFFF;
        t = Long.reverse(-1340335484439930318L);
        u = Long.reverse(0x5000000000000000L);
        aa = 80 >>> 4 | 80 << ~4 + 1;
        ab = Long.reverse(-4799099998260471246L);
        ah = (48 >>> 3 | 48 << ~3 + 1) & 0xFFFFFFFF;
        aj = Long.reverse(-4799099998260471246L);
        al = (112 >>> 196 | 112 << -196) & 0xFFFFFFFF;
        am = Long.reverse(-1340335484439930318L);
        ap = Long.reverse(0x5000000000000000L);
        aq = Integer.reverse(0);
        as = Integer.reverse(0x10000000);
        au = Long.reverse(-4799099998260471246L);
        aw = Integer.reverse(-1073741824);
        ax = 0 >>> 15 | 0 << ~15 + 1;
        bb = Integer.reverse(Integer.MIN_VALUE);
        bl = (8192 >>> 108 | 8192 << ~108 + 1) & 0xFFFFFFFF;
        bo = Integer.reverse(Integer.MIN_VALUE);
        bp = Integer.reverse(Integer.MIN_VALUE);
        bt = Integer.reverse(0);
        bu = Integer.reverse(0);
        bv = 65536 >>> 240 | 65536 << -240;
        bw = Integer.reverse(0);
        bx = 0x400000 >>> 246 | 0x400000 << ~246 + 1;
        by = Integer.reverse(0);
        bz = 0x8000000 >>> 91 | 0x8000000 << -91;
        ca = 0x800000 >>> 119 | 0x800000 << ~119 + 1;
        cb = 0 >>> 210 | 0 << ~210 + 1;
        cc = Integer.reverse(-1879048192);
        cd = Long.reverse(-1340335484439930318L);
        ce = Long.reverse(0x5000000000000000L);
        cf = Integer.reverse(0x50000000);
        cg = Long.reverse(-1340335484439930318L);
        ch = Long.reverse(0x5000000000000000L);
        ci = (-1073741822 >>> 94 | -1073741822 << ~94 + 1) & 0xFFFFFFFF;
        cj = Integer.reverse(-1);
        ck = Long.reverse(-4799099998260471246L);
        cl = Integer.reverse(Integer.MIN_VALUE);
        cm = Integer.reverse(0);
        cn = Integer.reverse(0x30000000);
        co = (0x180000 >>> 81 | 0x180000 << ~81 + 1) & 0xFFFFFFFF;
        c = new String[cn];
        d = new String[co];
        nLoginBungee.b();
    }

    @Override
    public \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, String string, ServerConnectType serverConnectType, @Nullable \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9) {
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R()) {
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.c;
        }
        ServerInfo serverInfo = this.a().getServerInfo(string);
        if (serverInfo == null) {
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.c;
        }
        ProxiedPlayer proxiedPlayer = (ProxiedPlayer)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
        Object[] objectArray = new Object[aw];
        objectArray[nLoginBungee.ax] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
        objectArray[nLoginBungee.bb] = serverConnectType;
        objectArray[nLoginBungee.bl] = serverInfo;
        ServerPreConnectEvent serverPreConnectEvent = (ServerPreConnectEvent)this.a().a(EventEnum.SERVER_PRE_CONNECT, objectArray);
        if (!this.a().callEvent(serverPreConnectEvent)) {
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b;
        }
        serverInfo = serverPreConnectEvent.getServer();
        Server server = proxiedPlayer.getServer();
        if (server != null && serverInfo.equals((Object)server.getInfo())) {
            if (\u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 != null) {
                \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9.done(bo != 0);
            }
            return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a;
        }
        ServerConnectRequest.Builder builder = ServerConnectRequest.builder().target(serverInfo).reason(ServerConnectEvent.Reason.PLUGIN);
        if (\u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 == null) {
            builder.callback((result, throwable) -> {
                if (result != ServerConnectRequest.Result.SUCCESS && result != ServerConnectRequest.Result.ALREADY_CONNECTED) {
                    String string = proxiedPlayer.getGroups().contains(nLoginBungee.c("\u3e80", (int)cc, (long)(cd ^ ce))) ? throwable.getClass().getSimpleName() + (String)nLoginBungee.c("\u3e83", (int)cf, (long)(cg ^ ch)) + throwable.getMessage() : throwable.getClass().getName();
                    Object[] objectArray = new Object[cl];
                    objectArray[nLoginBungee.cm] = string;
                    \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(this.a().getTranslation((String)nLoginBungee.c("\u3e86", (int)(ci & cj), (long)ck), objectArray));
                }
            });
        } else {
            builder.callback((result, throwable) -> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9.done((result == ServerConnectRequest.Result.SUCCESS || result == ServerConnectRequest.Result.ALREADY_CONNECTED ? ca : cb) != 0));
        }
        proxiedPlayer.connect(builder.build());
        return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a;
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b() {
        return this.a(bz != 0);
    }

    @Override
    public boolean t(String string) {
        return (this.a().getServerInfo(string) != null ? bp : bt) != 0;
    }

    @Override
    @Nullable
    public String a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
        ProxiedPlayer proxiedPlayer = (ProxiedPlayer)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
        Server server = proxiedPlayer.getServer();
        return server == null ? null : server.getInfo().getName();
    }

    @Override
    protected \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return \u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5.values();
    }

    @Override
    protected void j() {
        this.a = new \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd(this.a(), nLoginBungee.c("\u3e80", (int)as, (long)au));
        super.j();
    }

    @Override
    public boolean callEvent(Object object) {
        this.a().getPluginManager().callEvent((Event)object);
        return (!(object instanceof Cancellable) || !((Cancellable)object).isCancelled() ? bx : by) != 0;
    }

    public nLoginBungee(BungeeLoader bungeeLoader) {
        super(bungeeLoader, (String)nLoginBungee.c("\u3e80", (int)g, (long)(h ^ i)), new \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3((String)nLoginBungee.c("\u3e83", (int)j, (long)k), (String)nLoginBungee.c("\u3e86", (int)l, (long)n), (String)nLoginBungee.c("\u3e89", (int)(o & p), (long)q), (String)nLoginBungee.c("\u3e8c", (int)r, (long)(t ^ u)), (String)nLoginBungee.c("\u3e8f", (int)aa, (long)ab), (String)nLoginBungee.c("\u3e92", (int)ah, (long)aj), (String)nLoginBungee.c("\u3e95", (int)al, (long)(am ^ ap))));
        this.a(new \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6(new \u03b6\u03b2\u03ba\u03c8\u03b3\u03b1\u03c9\u03b7\u03ba\u03a0\u03a0(this), this, aq != 0));
    }

    @Override
    public \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a() {
        return (\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)super.b();
    }

    private static void b() {
        int n;
        e = 5501947725913286327L;
        long l = e ^ 0x67DBD2251D830FE9L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(30 + 39), (byte)(11 + 72), (byte)(18 + 29), (byte)(53 + 14), (byte)(17 + 49), (byte)(26 + 41), (byte)(42 + 5), (byte)(54 + 26), (byte)(45 + 30), (byte)(8 + 59), (byte)(20 + 63), (byte)(27 + 26), (byte)(2 + 78), 97, (byte)(3 + 97), (byte)(65 + 35), (byte)(86 + 19), (byte)(105 + 5), (byte)(33 + 70)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(13 + 70)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    nLoginBungee.d[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0101\u0143\u0141\u0148\u0145\u0124\u014b\u010c\u011b\u011f\u0120\u0119", (byte)41, 65);
                    nLoginBungee.d[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0114\u011d\u0148\u010b\u0125\u0137\u013d\u012b\u0146\u014c\u012f\u0150\u0142\u0120\u0148\u0150\u0125\u0128\u0153\u0154\u0148\u0159\u0118\u0157\u012f\u011d\u015c\u0125\u0141\u0150\u0159\u0164", (byte)41, 65);
                    nLoginBungee.d[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0104\u013a\u0116\u0105\u0124\u011a\u012d\u0123\u014b\u010e\u010a\u010c\u0140\u0141\u014e\u0110\u013b\u015b\u015c\u0114\u0157\u0155\u012a\u0131\u0156\u0162\u0151\u011f\u0133\u0122\u0164\u0156\u0162\u0133\u015c\u0138\u014f\u0157\u016a\u016d\u013d\u013f\u0147\u0148\u012e\u016a\u014c\u0178\u0176\u016f\u0164\u017c\u0174\u0135\u0173\u0155\u0157\u0158\u0173\u0183\u013f\u0177\u0176\u0169\u0184\u0148\u013e\u013f\u015f\u0141\u0171\u0147\u015a\u018b\u0167\u0168\u0170\u0150\u0154\u0181\u017b\u0159\u0165\u0192\u0198\u0159\u0175\u0194\u017f\u0190\u015a\u0173\u01a5\u019a\u0189\u0197", (byte)41, 66);
                    nLoginBungee.d[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u0112\u0123\u012d\u011a\u0127\u012a\u0147\u0127\u014d\u014c\u012a\u0128\u0111\u0137\u014e\u014a\u014d\u0157\u013b\u0149\u012f\u0158\u015c\u012d\u012d\u015d\u0130\u0132\u0141\u0143\u0132\u0128\u0160\u0136\u0160\u013a\u0149\u0165\u015e\u016c\u012f\u013e\u0134\u012b\u0128\u0174\u0167\u0142\u016d\u0152\u014d\u0150\u017e\u014e\u0139\u014e\u0156\u016d\u013b\u017e\u0181\u0177\u0140\u017c\u0172\u0146\u018c\u015b\u016f\u0180\u0186\u0162\u0161\u014b\u0194\u0184\u014d\u018f\u0192\u0153\u0178\u0165\u019b\u018e\u019c\u0167\u0180\u018e\u017e\u0178\u017e\u0179\u0163\u01a8\u0196\u0189", (byte)41, 65);
                    nLoginBungee.d[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0116\u0123\u0106\u012a\u012e\u012c\u0119\u013b\u014e\u010e\u012a\u0107\u0155\u0133\u0144\u012b\u012b\u014b\u0147\u0127\u0115\u0136\u013e\u011e\u0118\u014f\u014f\u0140\u015f\u013a\u0169\u015c\u0165\u0157\u0128\u0146\u0145\u012d\u014f\u015e\u015d\u014b\u015c\u0167\u012c\u0174\u014b\u0136\u0132\u0165\u012e\u0168\u016c\u015a\u013a\u0178\u013f\u0174\u0140\u0166\u0150\u016f\u0174\u017a\u0165\u0159\u0158\u0168\u0176\u016b\u0180\u018f\u0148\u018c\u0187\u0193\u0173\u016f\u018e\u0161\u0196\u0176\u019a\u0171\u0173\u0195\u018b\u0182\u0177\u0162\u0156\u0197\u01a4\u0181\u0164\u0161", (byte)41, 65);
                    nLoginBungee.d[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0516\u053a\u0539\u052a\u054a\u055f\u0523\u0538\u0518\u0555\u0544\u0533\u0541\u0535\u052b\u053c\u0526\u0538\u0563\u052f\u0530\u0541\u0560\u0567\u056e\u056d\u0561\u056e\u0565\u0578\u0552\u054a\u0550\u057d\u0538\u057a\u054f\u054f\u053c\u0557\u0538\u055f\u0582\u0578\u0565\u0581\u054c\u053f\u058a\u054e\u0565\u057e\u056e\u054b\u0592\u0574\u0566\u056f\u0568\u0569\u0554\u056b\u0567\u055a\u0557\u056a\u0571\u0591\u0595\u055f\u058f\u0590\u0562\u055d\u0570\u0560\u05a9\u0593\u05a7\u059e\u0566\u0590\u057d\u059a\u059d\u05a0\u056f\u0581\u0580\u05ad\u05aa\u05a5\u0579\u05b6\u05aa\u05b1", (byte)41, 69);
                    nLoginBungee.d[6] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u051c\u055d\u0558\u0554\u0531\u052b\u0554\u0532\u0539\u0564\u0555\u0565\u0568\u0527\u052c\u053e\u054d\u0564\u056a\u0530\u052a\u0543\u055f\u0543\u056a\u0571\u0531\u0552\u0558\u0535\u054b\u056c\u0575\u0560\u0558\u0580\u0541\u0560\u0563\u0552\u055f\u053f\u0586\u0540\u057c\u0561\u058b\u0561\u054c\u0545\u056f\u057d\u0586\u057d\u0553\u056a\u0552\u0582\u0554\u058d\u0566\u056c\u0565\u0576\u0588\u0575\u058b\u056f\u0559\u056c\u05a3\u055f\u0574\u0578\u0587\u055f\u0561\u05a0\u057e\u058e\u059e\u0568\u0590\u0590\u059f\u05a4\u0587\u0580\u0588\u05a6\u05af\u0594\u05ba\u05bc\u059c\u057d", (byte)41, 69);
                    nLoginBungee.d[7] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u049c\u0475\u0498\u047e\u0479\u04a3\u049a\u04a0\u0469\u047d\u04ad\u04b2\u0467\u04ab\u0473\u04ad\u04ba\u04ba\u0499\u0485\u04b9\u049b\u0478\u0499\u047a\u04b4\u0491\u04c4\u0494\u048f\u04c6\u04bb\u04b9\u04a0\u04cb\u049a\u04ca\u0484\u0485\u04c7\u049b\u04cd\u04aa\u04ce\u04be\u0491\u04c8\u0492\u04c4\u04c9\u04a4\u04b5\u04de\u0497\u04b6\u04cf\u04db\u04b0\u04bf\u04d6\u04d1\u049d\u04d8\u04e9\u04b8\u04a5\u04a6\u04bd\u04b7\u04c1\u04cc\u04be\u04df\u04bb\u04eb\u04a6\u04c1\u04cb\u04b0\u04d3\u04fa\u04d6\u04cf\u04fd\u04de\u04d1\u04ba\u04f9\u04ee\u04b8\u04f7\u04e5\u04d9\u04f6\u04dc\u04fd", (byte)41, 67);
                    nLoginBungee.d[8] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0516\u0528\u0558\u0556\u0520\u0561\u0561\u051e\u0522\u0519\u0565\u055e\u0543\u0538\u055b\u054c\u055e\u056e\u0561\u053a\u0543\u0571\u0538\u0539", (byte)41, 69);
                    nLoginBungee.d[9] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u0122\u0117\u014b\u0125\u0108\u0127\u014c\u013c\u013e\u014b\u0128\u0119", (byte)41, 65);
                    nLoginBungee.d[10] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u049c\u047d\u047e\u0478\u0475\u0498\u04af\u0467\u04b1\u046a\u0487\u0478", (byte)41, 68);
                    nLoginBungee.d[11] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0121\u012b\u0102\u0138\u014d\u012c\u013b\u0111\u010d\u0110\u011c\u012c\u014c\u012e\u0151\u014d\u014d\u0127\u0116\u0134\u0134\u014d\u0124\u0125", (byte)41, 66);
                    continue block7;
                }
                case 1: {
                    nLoginBungee.d[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u011c\u0139\u0107\u0120\u0107\u013a\u014c\u0128\u012c\u014a\u0113\u0152\u0129\u0117\u0113\u0150\u0111\u0153\u014a\u015b\u0152\u0127\u0124\u0125", (byte)41, 66);
                    nLoginBungee.d[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0473\u047c\u04a7\u046a\u0484\u0496\u049c\u048a\u04a5\u04ab\u048e\u04af\u04a1\u047f\u04a7\u04af\u0484\u0487\u04b2\u04b3\u04a7\u04b1\u04a0\u04a1\u048d\u049e\u0490\u04b6\u04a0\u04c4\u0487\u04c2", (byte)41, 67);
                    nLoginBungee.d[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0104\u013a\u0116\u0105\u0124\u011a\u012d\u0123\u014b\u010e\u010a\u010c\u0140\u0141\u014e\u0110\u013b\u015b\u015c\u0114\u0157\u0155\u012a\u0131\u0156\u0162\u0151\u011f\u0133\u0122\u0164\u0156\u0162\u0133\u015c\u0138\u014f\u0157\u016a\u016d\u013d\u013f\u0147\u0148\u012e\u016a\u014c\u0178\u0176\u016f\u0164\u017c\u0174\u0135\u0173\u0155\u0157\u0158\u0173\u0183\u013f\u0177\u0176\u0169\u0184\u0148\u013e\u013f\u015f\u0141\u0171\u0147\u015a\u018b\u0167\u0168\u0170\u0150\u0154\u0181\u017b\u0159\u0165\u0192\u0198\u019d\u016b\u0182\u0197\u019e\u01a0\u01a2\u0180\u016f\u0186\u017d", (byte)41, 65);
                    nLoginBungee.d[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0471\u0482\u048c\u0479\u0486\u0489\u04a6\u0486\u04ac\u04ab\u0489\u0487\u0470\u0496\u04ad\u04a9\u04ac\u04b6\u049a\u04a8\u048e\u04b7\u04bb\u048c\u048c\u04bc\u048f\u0491\u04a0\u04a2\u0491\u0487\u04bf\u0495\u04bf\u0499\u04a8\u04c4\u04bd\u04cb\u048e\u049d\u0493\u048a\u0487\u04d3\u04c6\u04a1\u04cc\u04b1\u04ac\u04af\u04dd\u04ad\u0498\u04ad\u04b5\u04cc\u049a\u04dd\u04e0\u04d6\u049f\u04db\u04d1\u04a5\u04eb\u04ba\u04ce\u04df\u04e5\u04c1\u04c0\u04aa\u04f3\u04e3\u04ac\u04ee\u04f1\u04b2\u04d7\u04c4\u04fa\u04ed\u04fb\u04ca\u04b5\u04fd\u04e1\u0501\u04ef\u04d6\u04e6\u04d2\u04df\u04f0", (byte)41, 67);
                    nLoginBungee.d[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u0116\u0123\u0106\u012a\u012e\u012c\u0119\u013b\u014e\u010e\u012a\u0107\u0155\u0133\u0144\u012b\u012b\u014b\u0147\u0127\u0115\u0136\u013e\u011e\u0118\u014f\u014f\u0140\u015f\u013a\u0169\u015c\u0165\u0157\u0128\u0146\u0145\u012d\u014f\u015e\u015d\u014b\u015c\u0167\u012c\u0174\u014b\u0136\u0132\u0165\u012e\u0168\u016c\u015a\u013a\u0178\u013f\u0174\u0140\u0166\u0150\u016f\u0174\u017a\u0165\u0159\u0158\u0168\u0176\u016b\u0180\u018f\u0148\u018c\u0187\u0193\u0173\u016f\u018e\u0161\u0196\u0176\u019a\u0171\u0173\u0195\u0168\u018d\u0175\u017f\u017b\u019c\u01a3\u0165\u0161\u019a", (byte)41, 66);
                    nLoginBungee.d[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0102\u0126\u0125\u0116\u0136\u014b\u010f\u0124\u0104\u0141\u0130\u011f\u012d\u0121\u0117\u0128\u0112\u0124\u014f\u011b\u011c\u012d\u014c\u0153\u015a\u0159\u014d\u015a\u0151\u0164\u013e\u0136\u013c\u0169\u0124\u0166\u013b\u013b\u0128\u0143\u0124\u014b\u016e\u0164\u0151\u016d\u0138\u012b\u0176\u013a\u0151\u016a\u015a\u0137\u017e\u0160\u0152\u015b\u0154\u0155\u0140\u0157\u0153\u0146\u0143\u0156\u015d\u017d\u0181\u014b\u017b\u017c\u014e\u0149\u015c\u014c\u0195\u017f\u0193\u018a\u0152\u017c\u0169\u0186\u0189\u017b\u0197\u0175\u019e\u0184\u019d\u01a4\u0160\u0180\u0182\u0180", (byte)41, 66);
                    nLoginBungee.d[6] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u051c\u055d\u0558\u0554\u0531\u052b\u0554\u0532\u0539\u0564\u0555\u0565\u0568\u0527\u052c\u053e\u054d\u0564\u056a\u0530\u052a\u0543\u055f\u0543\u056a\u0571\u0531\u0552\u0558\u0535\u054b\u056c\u0575\u0560\u0558\u0580\u0541\u0560\u0563\u0552\u055f\u053f\u0586\u0540\u057c\u0561\u058b\u0561\u054c\u0545\u056f\u057d\u0586\u057d\u0553\u056a\u0552\u0582\u0554\u058d\u0566\u056c\u0565\u0576\u0588\u0575\u058b\u056f\u0559\u056c\u05a3\u055f\u0574\u0578\u0587\u055f\u0561\u05a0\u057e\u058e\u059e\u0568\u0590\u0590\u059f\u05a8\u0592\u056c\u0574\u058d\u0594\u05b3\u057a\u05b4\u0596\u059a", (byte)41, 70);
                    nLoginBungee.d[7] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0551\u052a\u054d\u0533\u052e\u0558\u054f\u0555\u051e\u0532\u0562\u0567\u051c\u0560\u0528\u0562\u056f\u056f\u054e\u053a\u056e\u0550\u052d\u054e\u052f\u0569\u0546\u0579\u0549\u0544\u057b\u0570\u056e\u0555\u0580\u054f\u057f\u0539\u053a\u057c\u0550\u0582\u055f\u0583\u0573\u0546\u057d\u0547\u0579\u057e\u0559\u056a\u0593\u054c\u056b\u0584\u0590\u0565\u0574\u058b\u0586\u0552\u058d\u059e\u056d\u055a\u055b\u0572\u056c\u0576\u0581\u0573\u0594\u0570\u05a0\u055b\u0576\u0580\u0565\u0588\u05af\u058b\u0584\u05b2\u0593\u057f\u0585\u05a0\u0582\u05a2\u058d\u0582\u05b5\u057a\u05bb\u0597", (byte)41, 69);
                    nLoginBungee.d[8] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0516\u0528\u0558\u0556\u0520\u0561\u0561\u051e\u0522\u0519\u0564\u0563\u0526\u055d\u055a\u055d\u0529\u0566\u0568\u054c\u0561\u054b\u0538\u0539", (byte)41, 69);
                    nLoginBungee.d[9] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0140\u00fd\u011a\u0117\u011e\u0137\u0118\u0150\u010f\u011b\u0149\u0155\u0130\u0154\u014c\u014a\u011a\u012a\u0149\u0157\u012c\u0137\u0124\u0125", (byte)41, 65);
                    nLoginBungee.d[10] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u013a\u013e\u0146\u0127\u0120\u0146\u012a\u013e\u010a\u012a\u014a\u0119", (byte)41, 65);
                    nLoginBungee.d[11] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0535\u053f\u0516\u054c\u0561\u0540\u054f\u0525\u0521\u0524\u0530\u0537\u055c\u0568\u0539\u0569\u056e\u053c\u0559\u055e\u0524\u052c\u0542\u052d\u0532\u056b\u056b\u0565\u0545\u056f\u055c\u055b", (byte)41, 70);
                    continue block7;
                }
                case 2: {
                    nLoginBungee.d[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0481\u0496\u0467\u0478\u04a6\u04a3\u04a5\u0480\u047b\u048e\u04a7\u04ae\u0485\u046e\u04a6\u04b0\u04b7\u04a2\u0499\u04ab\u04b1\u047b\u0492\u048c\u049d\u047b\u049e\u04b7\u04a6\u04a6\u0486\u049a", (byte)41, 67);
                    continue block7;
                }
                case 4: {
                    nLoginBungee.d[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0462\u0484\u04aa\u0476\u045f\u047b\u048f\u048d\u0467\u0491\u0481\u0481\u0491\u04aa\u04b4\u048f\u0475\u0493\u04b3\u048b\u0490\u04ac\u0483\u0484", (byte)41, 67);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(nLoginBungee.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0470\u0492\u0494\u0474\u0498\u04b7\u04af\u04c5\u04b1\u0480\u04be\u04b4\u04c2\u04bc\u0485\u04aa\u04cc\u04cb\u04c3\u04c9\u04c3\u0498", (byte)49, 68), nLoginBungee.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0550\u055d\u055c\u051f\u055f\u055b\u0556\u055f\u056a\u0559\u0526\u0564\u0568\u0561\u0564\u056a\u052c\u056e\u0571\u056f\u0579\u057b\u0532\u0566\u057a\u0574\u056e\u056d\u056e\u0539\u0579\u0558\u057c\u0575\u0578\u057e\u0553\u0587\u0581\u057b\u057a\u057b\u0551", (byte)49, 69) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0482", (byte)49, 68) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0xAL;
        l ^= 0x67DBD2251D830FE9L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(12 + 57), (byte)(63 + 20), 47, (byte)(18 + 49), (byte)(63 + 3), (byte)(27 + 40), 47, (byte)(38 + 42), (byte)(63 + 12), (byte)(64 + 3), (byte)(62 + 21), (byte)(31 + 22), (byte)(41 + 39), (byte)(56 + 41), (byte)(23 + 77), (byte)(98 + 2), (byte)(29 + 76), (byte)(19 + 91), (byte)(56 + 47)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(32 + 37), (byte)(57 + 26)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u016a\u0177\u0176\u0139\u0179\u0175\u0170\u0179\u0184\u0173\u0140\u017e\u0182\u017b\u017e\u0184\u0146\u0188\u018b\u0189\u0193\u0195\u014c\u0180\u0194\u018e\u0188\u0187\u0188\u0153\u0193\u0172\u0196\u018f\u0192\u0198\u016d\u01a1\u019b\u0195\u0194\u0195", (byte)68, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            nLoginBungee.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    @Override
    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R()) {
            return bu != 0;
        }
        ProxiedPlayer proxiedPlayer = (ProxiedPlayer)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
        return (proxiedPlayer.getServer() != null ? bv : bw) != 0;
    }
}

