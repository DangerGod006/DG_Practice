/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.SpawnType
 *  com.nickuc.login.api.nLoginAPI$nLoginInternal
 *  com.nickuc.login.api.types.Identity
 *  com.nickuc.login.api.types.Location
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.SpawnType;
import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.api.types.Identity;
import com.nickuc.login.api.types.Location;
import com.nickuc.login.\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c3\u03b7\u03b7\u03ba\u03c4\u03bb\u03c1\u03c7\u03c9\u03b2\u0393\u03b9\u03be;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.nickuc.login.\u03c9\u03c9\u03c9\u03a8\u03b1\u0393\u03b2\u03b4\u03bc\u03b7\u03a9\u0393\u03a0\u03c1;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7
extends \u03c3\u03b7\u03b7\u03ba\u03c4\u03bb\u03c1\u03c7\u03c9\u03b2\u0393\u03b9\u03be {
    private static int ab;
    private static long ac;
    private static long w;
    private static long e;
    private static String[] d;
    private static long h;
    private static long ag;
    private static int v;
    private static int f;
    private static long t;
    private static int j;
    private static int r;
    private final \u03c9\u03c9\u03c9\u03a8\u03b1\u0393\u03b2\u03b4\u03bc\u03b7\u03a9\u0393\u03a0\u03c1 a = new \u03c9\u03c9\u03c9\u03a8\u03b1\u0393\u03b2\u03b4\u03bc\u03b7\u03a9\u0393\u03a0\u03c1(this);
    private static long ad;
    private static int ae;
    private static int ai;
    private static int u;
    private static String[] c;
    private static int ah;

    @Nonnull
    public nLoginAPI.nLoginInternal internal() {
        return this.a;
    }

    static {
        f = Integer.reverse(0);
        h = Long.reverse(-3509382845787475326L);
        j = Integer.reverse(Integer.MIN_VALUE);
        r = Integer.reverse(-1);
        t = Long.reverse(-3509382845787475326L);
        u = 1 >>> 159 | 1 << -159;
        v = -1 >>> 84 | -1 << ~84 + 1;
        w = Long.reverse(-3509382845787475326L);
        ab = Integer.reverse(-1073741824);
        ac = Long.reverse(7155141071825859202L);
        ad = Long.reverse(-6052837899185946624L);
        ae = (0x800000 >>> 213 | 0x800000 << -213) & 0xFFFFFFFF;
        ag = Long.reverse(-3509382845787475326L);
        ah = (20480 >>> 204 | 20480 << -204) & 0xFFFFFFFF;
        ai = Integer.reverse(-1610612736);
        c = new String[ah];
        d = new String[ai];
        \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u045e\u0480\u0482\u0462\u0486\u04a5\u049d\u04b3\u049f\u046e\u04ac\u04a2\u04b0\u04aa\u0473\u0498\u04ba\u04b9\u04b1\u04b7\u04b1\u0486", (byte)43, 68), \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u054a\u0557\u0556\u0519\u0559\u0555\u0550\u0559\u0564\u0553\u0520\u055e\u0562\u055b\u055e\u0564\u0526\u08b6\u08bb\u08ad\u0896\u08c5\u08bd\u08b3\u089f\u08c9\u08b4\u08c2\u08ca\u053e", (byte)43, 69) + string + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0521", (byte)43, 70) + methodType.toString(), exception);
        }
    }

    public \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
    }

    private static String a(int n, long l) {
        l ^= 0x35L;
        l ^= 0xEFE7827E716B3123L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(36 + 32), 69, (byte)(52 + 31), (byte)(44 + 3), (byte)(61 + 6), (byte)(41 + 25), (byte)(41 + 26), (byte)(34 + 13), (byte)(65 + 15), (byte)(53 + 22), (byte)(36 + 31), (byte)(30 + 53), 53, (byte)(31 + 49), (byte)(73 + 24), (byte)(69 + 31), (byte)(77 + 23), (byte)(85 + 20), (byte)(101 + 9), (byte)(68 + 35)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(16 + 52), 69, (byte)(76 + 7)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0475\u0482\u0481\u0444\u0484\u0480\u047b\u0484\u048f\u047e\u044b\u0489\u048d\u0486\u0489\u048f\u0451\u07e1\u07e6\u07d8\u07c1\u07f0\u07e8\u07de\u07ca\u07f4\u07df\u07ed\u07f5", (byte)31, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    public Optional<Location> getSpawnLocation(@Nonnull SpawnType spawnType) {
        throw new UnsupportedOperationException((String)\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c("\u3e80", (int)f, (long)h));
    }

    public void requestLogin(@Nonnull Identity identity, @Nonnull Object object) {
        if (object == null) {
            throw new IllegalArgumentException((String)\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c("\u3e80", (int)(j & r), (long)t));
        }
        if (identity == null) {
            throw new IllegalArgumentException((String)\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c("\u3e83", (int)(u & v), (long)w));
        }
        if (!(identity instanceof \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0)) {
            throw new IllegalArgumentException((String)\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c("\u3e86", (int)ab, (long)(ac ^ ad)) + \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0.class.getCanonicalName() + (String)\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.c("\u3e89", (int)ae, (long)ag) + identity.getClass().getCanonicalName());
        }
        String string = this.b(identity);
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)((Object)this.a)).b().a(string);
        if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 != null) {
            ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).b().a().c(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6));
        }
    }

    private static void b() {
        int n;
        e = 4706050455637340870L;
        long l = e ^ 0xEFE7827E716B3123L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(31 + 38), (byte)(34 + 49), (byte)(46 + 1), (byte)(26 + 41), (byte)(14 + 52), (byte)(58 + 9), (byte)(21 + 26), (byte)(75 + 5), (byte)(30 + 45), (byte)(56 + 11), 83, (byte)(18 + 35), (byte)(65 + 15), (byte)(58 + 39), (byte)(2 + 98), (byte)(66 + 34), (byte)(69 + 36), (byte)(29 + 81), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(16 + 67)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0552\u0573\u0574\u057f\u0580\u0569\u055f\u055d\u056a\u055a\u057a\u057b\u0589\u056f\u0553\u0565\u0591\u058d\u0592\u056a\u0590\u0585\u0572\u0571\u0580\u0568\u058d\u0595\u0560\u0597\u0594\u0582", (byte)115, 68);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0545\u0581\u0585\u0574\u0577\u057c\u055b\u0580\u0569\u057b\u0566\u055c\u058a\u0568\u0585\u0586\u0569\u0556\u0581\u0589\u0571\u058f\u0557\u0578\u0595\u056b\u0553\u059d\u0581\u05a0\u05a4\u0574\u05a3\u0578\u059c\u059f\u057b\u057c\u056c\u0579\u057f\u0586\u059f\u0576", (byte)115, 68);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0565\u0540\u0573\u0568\u0561\u0575\u0583\u054b\u0548\u0560\u056e\u055a\u0550\u055f\u0572\u056f\u0563\u0574\u0552\u056d\u0589\u057c\u0587\u057d\u0571\u0590\u056e\u058c\u0559\u0598\u0580\u0570\u0582\u0571\u059c\u0581\u0579\u05ab\u056b\u0586\u05a6\u05a1\u05a3\u0576", (byte)115, 68);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[3] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u01bc\u0197\u01ca\u01bf\u01b8\u01cc\u01da\u01a2\u019f\u01b7\u01c4\u01a8\u01b4\u01b7\u01b8\u01e1\u01c1\u01ce\u01c1\u01c4\u01dc\u01dc\u01e3\u01e3\u01ee\u01ef\u01d6\u01cc\u01e7\u01c6\u01dd\u01cf\u01e7\u01ee\u01f4\u01d0\u01e3\u01c3\u01d1\u01d3\u01e3\u01e2\u01c7\u01cd", (byte)115, 66);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[4] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01ce\u01ac\u01bf\u01bd\u01d1\u01b4\u01bb\u01d1\u01d6\u01e6\u01df\u01c6\u01de\u01ea\u01ea\u01dc\u01c1\u01ab\u01a6\u01c2\u01e8\u01bb\u01b8\u01b9", (byte)115, 66);
                    continue block7;
                }
                case 1: {
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0552\u0573\u0574\u057f\u0580\u0569\u055f\u055d\u056a\u055a\u057a\u057b\u0589\u056f\u0553\u0565\u0591\u058d\u0592\u056a\u0590\u0584\u0577\u059f\u059a\u0590\u059b\u059a\u05a2\u0560\u055c\u0572\u05a0\u0570\u0576\u05a7\u0566\u058c\u057d\u0565\u0587\u0599\u0581\u0576", (byte)115, 68);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0545\u0581\u0585\u0574\u0577\u057c\u055b\u0580\u0569\u057b\u0566\u055c\u058a\u0568\u0585\u0586\u0569\u0556\u0581\u0589\u0571\u058f\u0557\u0578\u0595\u056b\u0553\u059d\u0581\u05a0\u05a4\u0574\u0596\u05a7\u0567\u05a2\u059c\u056a\u057e\u0567\u059a\u056d\u059f\u0576", (byte)115, 67);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[2] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0586\u0561\u0594\u0589\u0582\u0596\u05a4\u056c\u0569\u0581\u058f\u057b\u0571\u0580\u0593\u0590\u0584\u0595\u0573\u058e\u05aa\u059d\u05a8\u059e\u0592\u05b1\u058f\u05ad\u057a\u05b9\u05a1\u0591\u05a9\u05a3\u05be\u05cb\u05a6\u05a2\u05cc\u05a2\u059c\u05b1\u05d0\u0597", (byte)115, 69);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u01bc\u0197\u01ca\u01bf\u01b8\u01cc\u01da\u01a2\u019f\u01b7\u01c4\u01a8\u01b4\u01b7\u01b8\u01e1\u01c1\u01ce\u01c1\u01c4\u01dc\u01dc\u01e3\u01e3\u01ee\u01ef\u01d6\u01cc\u01e7\u01c6\u01dd\u01cf\u01d9\u01dd\u01dd\u01c1\u0202\u01d3\u0200\u01b7\u0200\u01fe\u0201\u0206\u0204\u01e3\u01d8\u01c4\u01ed\u0204\u020d\u01e3\u01ec\u01eb\u01d8\u01d9", (byte)115, 66);
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[4] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0598\u0576\u0589\u0587\u059b\u057e\u0585\u059b\u05a0\u05b0\u05a9\u059e\u05ac\u05a5\u05b5\u0582\u0590\u05a5\u056c\u0589\u05b7\u05bb\u0582\u0583", (byte)115, 69);
                    continue block7;
                }
                case 2: {
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u019e\u01ae\u01ba\u01aa\u01b6\u019d\u01b5\u01e5\u01dd\u0199\u01a6\u01bd\u01dd\u01bd\u01c3\u01b9\u01aa\u01ea\u01a7\u01d9\u01e8\u01f1\u01b8\u01b9", (byte)115, 65);
                    continue block7;
                }
                case 4: {
                    \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7.d[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0579\u053e\u058a\u0576\u0557\u055d\u0582\u0561\u0570\u0565\u057d\u0583\u054f\u054a\u058f\u0548\u0575\u0571\u058c\u058e\u0554\u059a\u0561\u0562", (byte)115, 68);
                }
            }
        }
    }
}

