/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03a8\u03bc\u03c1\u03b9\u03be\u03c7\u03bf\u03b3\u03bf\u03b7;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb
implements \u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9,
\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static int a = Integer.reverse(-1879048192);
    private static int p;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 ab;
    private static int c;
    private static int d;
    private static long o;
    private static String[] b;
    private static int f;
    private static int m;
    private static long l;
    private static long n;
    private static int i;
    private static int h;
    private static String[] a;
    private static long c;
    private static int g;
    private static int q;
    private static int j;
    private static int k;
    private static int b;
    private static int e;

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72) {
        switch (\u03a8\u03a8\u03bc\u03c1\u03b9\u03be\u03c7\u03bf\u03b3\u03bf\u03b7.C[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72.ordinal()]) {
            case 1: 
            case 2: {
                this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42).i((\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72 == \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b ? h : i) != 0);
                \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4.super.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72);
            }
        }
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.m, string -> {
            if (string.contains((CharSequence)\u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.c("\u3e80", (int)(j & k), (long)l))) {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.c((String)string, (String)\u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.c("\u3e83", (int)m, (long)(n ^ o)));
            } else {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.a((String)string);
            }
        }, new Object[d]);
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[e];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.f] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b;
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.g] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.ab;
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return (\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().n() == a && \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().q() ? b : c) != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x3EL;
        l ^= 0x14B177F8D89BDD45L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(50 + 19), (byte)(5 + 78), (byte)(11 + 36), (byte)(62 + 5), (byte)(10 + 56), (byte)(55 + 12), (byte)(3 + 44), (byte)(17 + 63), (byte)(39 + 36), 67, (byte)(13 + 70), (byte)(33 + 20), 80, (byte)(12 + 85), (byte)(68 + 32), (byte)(78 + 22), (byte)(78 + 27), (byte)(92 + 18), (byte)(87 + 16)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(27 + 42), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0588\u0595\u0594\u0557\u0597\u0593\u058e\u0597\u05a2\u0591\u055e\u059c\u05a0\u0599\u059c\u05a2\u0564\u08ee\u08e8\u08ee\u08fd\u08f5\u08cf\u08d0\u08f8", (byte)105, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.ab = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u051a\u053c\u053e\u051e\u0542\u0561\u0559\u056f\u055b\u052a\u0568\u055e\u056c\u0566\u052f\u0554\u0576\u0575\u056d\u0573\u056d\u0542", (byte)54, 70), \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0555\u0562\u0561\u0524\u0564\u0560\u055b\u0564\u056f\u055e\u052b\u0569\u056d\u0566\u0569\u056f\u0531\u08bb\u08b5\u08bb\u08ca\u08c2\u089c\u089d\u08c5\u0545", (byte)54, 70) + string + \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0125", (byte)54, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -5356749950265774151L;
        long l = c ^ 0x14B177F8D89BDD45L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(51 + 17), (byte)(58 + 11), (byte)(27 + 56), (byte)(22 + 25), (byte)(61 + 6), (byte)(22 + 44), (byte)(63 + 4), (byte)(19 + 28), (byte)(39 + 41), 75, (byte)(64 + 3), (byte)(60 + 23), (byte)(48 + 5), 80, (byte)(49 + 48), (byte)(9 + 91), (byte)(97 + 3), (byte)(59 + 46), (byte)(85 + 25), (byte)(98 + 5)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(61 + 8), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0502\u051f\u053f\u0543\u0537\u052a\u0549\u0543\u0539\u054f\u0508\u0544\u0523\u053b\u053b\u0506\u0545\u052f\u050f\u0515\u0546\u0532\u051f\u0520", (byte)93, 67);
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01a4\u01a2\u0174\u0171\u01a4\u0195\u0186\u01a6\u019b\u0190\u018d\u0187\u017b\u01a8\u01a9\u01ba\u0191\u0182\u01be\u01a2\u01ba\u0198\u01a1\u01a7\u01be\u018b\u0189\u018a\u01ca\u018f\u01a0\u018d\u01aa\u019b\u01c2\u0193\u01c1\u01cc\u01aa\u01c8\u0195\u01aa\u01b4\u01b1\u01dc\u01de\u01a9\u019b\u01ba\u01ae\u01e3\u01c4\u01ae\u01be\u01c2\u019f\u01eb\u01a5\u01da\u01e8\u01ca\u01af\u01af\u01cf\u01a8\u01c2\u01e1\u01f6\u01eb\u01d5\u01cb\u01c9\u01db\u01fb\u01d0\u01c1", (byte)93, 65);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u054f\u056c\u058c\u0590\u0584\u0577\u0596\u0590\u0586\u059c\u0553\u058a\u055d\u0573\u0597\u0560\u057d\u0598\u05a5\u0561\u0574\u057f\u056c\u056d", (byte)93, 70);
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0584\u0582\u0554\u0551\u0584\u0575\u0566\u0586\u057b\u0570\u056d\u0567\u055b\u0588\u0589\u059a\u0571\u0562\u059e\u0582\u059a\u0578\u0581\u0587\u059e\u056b\u0569\u056a\u05aa\u056f\u0580\u056d\u058a\u057b\u05a2\u0573\u05a1\u05ac\u058a\u05a8\u0575\u058a\u0594\u0591\u05bc\u05be\u0589\u057b\u059a\u058e\u05c3\u05a4\u058e\u059e\u05a2\u057f\u05cb\u0585\u05ba\u05c8\u05aa\u058f\u058f\u05af\u05aa\u0590\u05d4\u05b0\u05b4\u058d\u05b6\u05ae\u05a2\u05a9\u05c6\u05a1", (byte)93, 70);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u058f\u0589\u0586\u0586\u058a\u0566\u0587\u0568\u0595\u0568\u0579\u0554\u059f\u0574\u0577\u0582\u056f\u055c\u056c\u0598\u057d\u056f\u056c\u056d", (byte)93, 70);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01a7\u019c\u01b1\u0188\u0196\u01b3\u0197\u0197\u0176\u0174\u0188\u01bb\u01aa\u01bb\u01c0\u019e\u019a\u01ab\u01b6\u01c0\u017e\u019f\u018c\u018d", (byte)93, 66);
                }
            }
        }
    }

    static {
        b = 8 >>> 227 | 8 << ~227 + 1;
        c = 0 >>> 153 | 0 << ~153 + 1;
        d = 0 >>> 79 | 0 << ~79 + 1;
        e = Integer.reverse(0x40000000);
        f = (0 >>> 176 | 0 << ~176 + 1) & 0xFFFFFFFF;
        g = (16384 >>> 78 | 16384 << ~78 + 1) & 0xFFFFFFFF;
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Integer.reverse(0);
        j = 0 >>> 255 | 0 << ~255 + 1;
        k = -1 >>> 165 | -1 << ~165 + 1;
        l = Long.reverse(-2164951637783702099L);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Long.reverse(-7064868032362801747L);
        o = Long.reverse(0x7C00000000000000L);
        p = Integer.reverse(0x40000000);
        q = Integer.reverse(0x40000000);
        a = new String[p];
        b = new String[q];
        \u03b8\u03b1\u03b6\u03c4\u03bb\u0394\u0394\u03bb.b();
    }
}

