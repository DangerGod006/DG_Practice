/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc {
    public boolean f();

    public boolean e();

    public void g();

    @Nullable
    public \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7 a();

    public String d();

    public void b(String var1, @Nullable String var2);

    public \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 a();
}

