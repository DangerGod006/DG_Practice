/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Generated;

public class \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<T>
extends AbstractList<T> {
    public static final List<Integer> p;
    public static final List<?> n;
    private final List<T> q;
    public static final List<String> o;
    private static int a;

    @Override
    public T get(int n) {
        return this.q.get(n);
    }

    @Override
    public int size() {
        return this.q.size();
    }

    @SafeVarargs
    public static <T> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<T> a(T ... TArray) {
        List<T> list = Arrays.asList(TArray);
        return new \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<T>(list);
    }

    @Generated
    private \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0(List<T> list) {
        this.q = list;
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof List) {
            return object.equals(this.q);
        }
        return a != 0;
    }

    static {
        a = 0 >>> 231 | 0 << -231;
        n = new \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0(new ArrayList());
        o = new \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0(new ArrayList());
        p = new \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0(new ArrayList());
    }

    @Override
    public boolean contains(Object object) {
        return this.q.contains(object);
    }

    public static <T> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<T> a(List<T> list) {
        return new \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<T>(new ArrayList<T>(list));
    }
}

