/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8 {
    private static int o;
    private static int h;
    private static int a;
    private static long c;
    private static long m;
    private static int p;
    private static long g;
    private static String[] a;
    private static int l;
    private static long d;
    private final \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2 e;
    private static String[] b;
    private static int e;
    private static long n;
    private static long j;
    private static int c;
    private final long i;
    private static long k;
    private static long f;
    private static int b;
    private final String A;

    @Generated
    public String d() {
        return this.A;
    }

    @Generated
    public \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8(long l, String string, \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2 \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c22) {
        this.i = l;
        this.A = string;
        this.e = \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c22;
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        c = Integer.reverse(0);
        d = Long.reverse(3862777742378198190L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(5736275187364324526L);
        g = Long.reverse(0x7A00000000000000L);
        h = (0x800000 >>> 22 | 0x800000 << -22) & 0xFFFFFFFF;
        j = Long.reverse(5736275187364324526L);
        k = Long.reverse(0x7A00000000000000L);
        l = 0x30000000 >>> 188 | 0x30000000 << ~188 + 1;
        m = Long.reverse(5736275187364324526L);
        n = Long.reverse(0x7A00000000000000L);
        o = Integer.reverse(0x20000000);
        p = Integer.reverse(0x20000000);
        a = new String[o];
        b = new String[p];
        \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b();
    }

    @Generated
    public \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2 a() {
        return this.e;
    }

    private static void b() {
        int n;
        c = 8441783303566711282L;
        long l = c ^ 0xD382AFAD7545C92FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), 69, (byte)(61 + 22), (byte)(43 + 4), (byte)(28 + 39), (byte)(30 + 36), (byte)(55 + 12), (byte)(9 + 38), (byte)(27 + 53), 75, (byte)(20 + 47), (byte)(54 + 29), (byte)(51 + 2), (byte)(4 + 76), (byte)(11 + 86), (byte)(68 + 32), (byte)(99 + 1), (byte)(39 + 66), (byte)(17 + 93), (byte)(38 + 65)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(62 + 6), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u00f8\u00e7\u011a\u011c\u0100\u0112\u0129\u0111\u0115\u0116\u0123\u0123\u012d\u0130\u0129\u0120\u0129\u010c\u0130\u00fb\u0137\u013f\u0101\u013f\u0134\u0134\u010a\u0141\u0149\u011f\u011d\u013f", (byte)28, 65);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u044e\u0464\u0456\u0472\u043c\u0470\u045f\u0455\u0463\u0460\u0487\u044c\u0445\u0463\u047c\u0451\u0463\u048c\u048f\u0462\u0455\u046f\u045c\u045d", (byte)28, 68);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0440\u043c\u046d\u043c\u0462\u0482\u045e\u045f\u0488\u0444\u0443\u0451", (byte)28, 68);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[3] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u046d\u047d\u0443\u045a\u0459\u0466\u043f\u0489\u0465\u0462\u0468\u0451", (byte)28, 67);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u044a\u0439\u046c\u046e\u0452\u0464\u047b\u0463\u0467\u0468\u0475\u0475\u047f\u0482\u047b\u0472\u047b\u045e\u0482\u044d\u0489\u048b\u0461\u048a\u0462\u047a\u047b\u047a\u046a\u049a\u0490\u0489", (byte)28, 67);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u00fc\u0112\u0104\u0120\u00ea\u011e\u010d\u0103\u0111\u010e\u0137\u0131\u0134\u010a\u0134\u0113\u0137\u012d\u013a\u0113\u011e\u010d\u010a\u010b", (byte)28, 66);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0509\u0512\u0522\u053e\u054d\u0536\u051f\u052c\u0521\u052e\u0529\u0525\u0519\u0526\u0518\u0554\u0538\u0534\u0556\u0560\u0556\u052e\u052b\u052c", (byte)28, 69);
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u050e\u054d\u0528\u052e\u0541\u050d\u0530\u0529\u050b\u0549\u0516\u0520", (byte)28, 70);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0459\u0442\u0485\u0457\u0486\u0464\u0456\u0458\u0444\u0487\u045b\u0459\u048a\u047c\u0485\u044c\u048f\u048e\u0452\u0476\u048e\u0493\u0456\u0465\u0452\u0499\u048d\u0477\u047f\u0473\u045d\u0469", (byte)28, 68);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00ed\u012e\u0120\u0105\u012a\u0112\u0134\u00f4\u010a\u010a\u0103\u00fb\u0138\u00f9\u00f7\u0110\u0128\u0132\u012d\u0135\u013a\u0110\u0133\u011c\u0127\u0116\u0117\u0148\u010a\u011b\u0106\u012e", (byte)28, 66);
                }
            }
        }
    }

    public String getName() {
        return this.e != \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.c && \u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.d.ar() ? \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.g(this.A, (this.e == \u03c3\u039b\u03c9\u0394\u03c0\u03bc\u03b2\u03bf\u03c2.a ? a : b) != 0) : this.A;
    }

    @Generated
    public long d() {
        return this.i;
    }

    private static String a(int n, long l) {
        l ^= 0x5EL;
        l ^= 0xD382AFAD7545C92FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(40 + 28), (byte)(55 + 14), (byte)(17 + 66), 47, (byte)(40 + 27), (byte)(30 + 36), (byte)(47 + 20), (byte)(5 + 42), (byte)(67 + 13), (byte)(40 + 35), (byte)(28 + 39), (byte)(8 + 75), (byte)(24 + 29), (byte)(35 + 45), 97, (byte)(59 + 41), (byte)(88 + 12), (byte)(45 + 60), (byte)(40 + 70), (byte)(35 + 68)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(54 + 29)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04c3\u04d0\u04cf\u0492\u04d2\u04ce\u04c9\u04d2\u04dd\u04cc\u0499\u04d7\u04db\u04d4\u04d7\u04dd\u049f\u082d\u0835\u0826\u0837\u082a\u0834\u081d\u0830\u0838\u0842\u0843", (byte)57, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static /* synthetic */ long a(\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8 \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c82) {
        return \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c82.i;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u0171\u0193\u0195\u0175\u0199\u01b8\u01b0\u01c6\u01b2\u0181\u01bf\u01b5\u01c3\u01bd\u0186\u01ab\u01cd\u01cc\u01c4\u01ca\u01c4\u0199", (byte)101, 65), \u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u01ac\u01b9\u01b8\u017b\u01bb\u01b7\u01b2\u01bb\u01c6\u01b5\u0182\u01c0\u01c4\u01bd\u01c0\u01c6\u0188\u0516\u051e\u050f\u0520\u0513\u051d\u0506\u0519\u0521\u052b\u052c\u019f", (byte)101, 65) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u055b", (byte)101, 70) + methodType.toString(), exception);
        }
    }

    @Generated
    public String toString() {
        return (String)\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.c("\u3e80", (int)c, (long)d) + this.d() + (String)\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.c("\u3e83", (int)e, (long)(f ^ g)) + this.d() + (String)\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.c("\u3e86", (int)h, (long)(j ^ k)) + (Object)((Object)this.a()) + (String)\u03bc\u03c3\u03b3\u03c3\u03b5\u03be\u03a6\u03b8\u03bf\u03c8\u03c8.c("\u3e89", (int)l, (long)(m ^ n));
    }
}

