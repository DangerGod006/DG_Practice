/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;
import com.nickuc.login.\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6;
import com.nickuc.login.\u03c7\u03bf\u03b1\u03b3\u0393\u03a3\u0393\u03b8\u03c8\u03a0\u03c5\u03c7\u0393\u03b5\u03a8;
import java.nio.charset.StandardCharsets;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 {
    public static byte[] a(byte[] byArray, boolean bl) {
        byte[] byArray2;
        if (bl) {
            byte[] byArray3 = \u03c7\u03bf\u03b1\u03b3\u0393\u03a3\u0393\u03b8\u03c8\u03a0\u03c5\u03c7\u0393\u03b5\u03a8.b(byArray);
            byArray2 = new byte[1 + byArray3.length];
            byArray2[0] = 1;
            System.arraycopy(byArray3, 0, byArray2, 1, byArray3.length);
        } else {
            byArray2 = new byte[1 + byArray.length];
            byArray2[0] = 0;
            System.arraycopy(byArray, 0, byArray2, 1, byArray.length);
        }
        return byArray2;
    }

    default public boolean a(\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, Object object, byte[] byArray) {
        return this.a(null, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, object, byArray);
    }

    public static byte[] a(JSONObject jSONObject, boolean bl) {
        byte[] byArray = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b52 -> \u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b52.a(jSONObject.toString().getBytes(StandardCharsets.UTF_8)));
        return \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3.a(byArray, bl);
    }

    public void b(Object var1);

    public void a(Object var1, Object var2);

    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 var1, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 var2, Object var3, byte[] var4);

    public static byte[] a(byte[] byArray) {
        boolean bl = byArray[0] == 1;
        byte[] byArray2 = new byte[byArray.length - 1];
        System.arraycopy(byArray, 1, byArray2, 0, byArray2.length);
        if (bl) {
            byArray2 = \u03c7\u03bf\u03b1\u03b3\u0393\u03a3\u0393\u03b8\u03c8\u03a0\u03c5\u03c7\u0393\u03b5\u03a8.c(byArray2);
        }
        return byArray2;
    }

    public void c(Object var1);

    public static JSONObject a(byte[] byArray) {
        byte[] byArray2 = \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3.a(byArray);
        String string = new String(byArray2, StandardCharsets.UTF_8);
        return new JSONObject(string);
    }
}

