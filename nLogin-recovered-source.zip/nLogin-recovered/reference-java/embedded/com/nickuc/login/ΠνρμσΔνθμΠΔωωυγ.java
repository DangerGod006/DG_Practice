/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  org.geysermc.cumulus.form.CustomForm
 *  org.geysermc.cumulus.form.CustomForm$Builder
 *  org.geysermc.cumulus.response.CustomFormResponse
 *  org.geysermc.floodgate.api.player.FloodgatePlayer
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.geysermc.cumulus.form.CustomForm;
import org.geysermc.cumulus.response.CustomFormResponse;
import org.geysermc.floodgate.api.player.FloodgatePlayer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3 {
    private static long o;
    private static int i;
    private final \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2 a;
    private static int b;
    private static long a;
    private static long as;
    private static int bb;
    private static int bl;
    private static long ap;
    private static int x;
    private static long bo;
    private static int at;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 p;
    private static int ay;
    private static int bj;
    private static int ah;
    private static int bn;
    private static int e;
    private static int bc;
    private static int ba;
    private static long br;
    private static int bt;
    private static int ag;
    private static int v;
    private static String[] b;
    private static int c;
    private static int ao;
    private static int ab;
    private static int w;
    private static int bd;
    private static int bh;
    private static int be;
    private static int m;
    private static int k;
    private static long r;
    private static String[] a;
    private static int y;
    private static int bi;
    private static int l;
    private static int al;
    private static int av;
    private static int am;
    private static int ad;
    private static int aw;
    private static int q;
    private static long ar;
    private static int j;
    private static long s;
    private static int bs;
    private static int bm;
    private static int bk;
    private static int f;
    private static int af;
    private static int aq;
    private static int bp;
    private static int az;
    private static int d;
    private static int au;
    private static int bq;
    private static int g;
    private static int bf;
    private static int z;
    private static int n;
    private static int ac;
    private static long p;
    private static int bg;
    private static int h;
    private static int t;
    private static long c;
    private static int ae;
    private static int ai;
    private static int aj;
    private static int aa;
    private static int ak;
    private static int an;
    private static int ax;
    private static int u;

    private /* synthetic */ void a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, boolean bl, CustomFormResponse customFormResponse) {
        String string;
        String string2 = this.g((String)customFormResponse.next());
        if (string2 == null) {
            this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
            return;
        }
        if (bl) {
            string = this.g((String)customFormResponse.next());
            if (string == null) {
                this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
                return;
            }
        } else {
            string = string2;
        }
        String[] stringArray = new String[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.bl];
        stringArray[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.bm] = string2;
        stringArray[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.bn] = string;
        \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.j.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray);
        \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a().a(() -> {
            if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R() && this.p.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6).a() == \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.d) {
                this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
            }
        }, bo, TimeUnit.SECONDS);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u04e5\u0507\u0509\u04e9\u050d\u052c\u0524\u053a\u0526\u04f5\u0533\u0529\u0537\u0531\u04fa\u051f\u0541\u0540\u0538\u053e\u0538\u050d", (byte)88, 67), \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0192\u019f\u019e\u0161\u01a1\u019d\u0198\u01a1\u01ac\u019b\u0168\u01a6\u01aa\u01a3\u01a6\u01ac\u016e\u04e0\u04fe\u0503\u04ff\u0507\u04d9\u0503\u04ff\u0504\u04e9\u04de\u0514\u0515\u0512\u0501\u0189", (byte)88, 65) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0169", (byte)88, 65) + methodType.toString(), exception);
        }
    }

    @Nullable
    private String g(@Nullable String string) {
        if (string == null) {
            return null;
        }
        return !(string = string.trim()).isEmpty() ? string.replace((char)bj, (char)bk) : null;
    }

    private static void b() {
        int n;
        c = 7200986173644678517L;
        long l = c ^ 0x1C3EAD3AF0350EFEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(4 + 65), (byte)(39 + 44), (byte)(4 + 43), (byte)(50 + 17), (byte)(14 + 52), (byte)(34 + 33), (byte)(46 + 1), (byte)(3 + 77), (byte)(30 + 45), 67, 83, (byte)(18 + 35), (byte)(58 + 22), (byte)(53 + 44), (byte)(51 + 49), (byte)(62 + 38), (byte)(98 + 7), (byte)(44 + 66), (byte)(56 + 47)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(46 + 37)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u013f\u0132\u011d\u00ff\u0141\u011b\u0102\u0147\u011b\u010a\u0142\u0111", (byte)37, 66);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u013f\u0132\u011d\u00ff\u0141\u011b\u0102\u0147\u011b\u010a\u0142\u0111", (byte)37, 66);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0557\u054a\u0535\u0517\u0559\u0533\u051a\u055f\u0533\u0522\u055a\u0529", (byte)37, 70);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u013f\u0132\u011d\u00ff\u0141\u011b\u0102\u0147\u011b\u010a\u0142\u0111", (byte)37, 66);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u044f\u0456\u0487\u0473\u049f\u046e\u04a2\u0473\u0463\u045f\u046f\u046c", (byte)37, 67);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00fd\u012d\u0113\u0114\u0127\u0139\u0119\u011f\u0127\u013e\u013e\u0111", (byte)37, 66);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u047b\u0467\u0451\u045f\u048f\u0497\u0495\u0491\u0498\u047d\u046f\u046c", (byte)37, 68);
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[3] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u050c\u0533\u050e\u050f\u052d\u0555\u0538\u0532\u052a\u054b\u054e\u0529", (byte)37, 69);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u048f\u046f\u0474\u045e\u047d\u045b\u049a\u046e\u0460\u0473\u04a8\u0468\u0473\u049c\u0485\u04a0\u04a9\u049a\u04a6\u04a4\u0486\u04b0\u0477\u0478", (byte)37, 68);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0558\u0552\u051a\u0530\u053e\u0518\u0531\u053c\u0530\u054f\u052e\u0562\u0518\u051d\u0548\u0523\u0526\u0541\u0569\u0535\u0524\u0544\u0527\u052f\u055d\u054e\u0540\u0563\u055e\u0563\u0531\u052b", (byte)37, 70);
                }
            }
        }
    }

    @Generated
    public \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2 \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b22) {
        this.p = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
        this.a = \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b22;
    }

    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92) {
        FloodgatePlayer floodgatePlayer = this.a.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a());
        if (floodgatePlayer == null) {
            return b != 0;
        }
        CustomForm.Builder builder = (CustomForm.Builder)CustomForm.builder().title(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bA, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[c]));
        int n = d;
        int n2 = e;
        List<String> list = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bB, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[f]);
        for (String string : list) {
            String[] stringArray;
            String string2;
            ++n;
            if (string.length() > g && string.charAt(h) == i && string.charAt(string.length() - j) == k && (string2 = string.substring(l, string.length() - m)).contains((CharSequence)\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.c("\u3e80", (int)\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.n, (long)(o ^ p))) && (stringArray = string2.split((String)\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.c("\u3e83", (int)q, (long)(r ^ s)))).length == t) {
                builder.input(stringArray[u], stringArray[v]);
                n2 = n;
                continue;
            }
            builder.label(string);
        }
        if (n2 == w) {
            return x != 0;
        }
        builder.closedOrInvalidResultHandler(() -> this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92));
        builder.validResultHandler(customFormResponse -> {
            String string = this.g((String)customFormResponse.next());
            if (string == null) {
                this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
                return;
            }
            String[] stringArray = new String[bp];
            stringArray[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.bq] = string;
            \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.f.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray);
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a().a(() -> {
                if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R() && this.p.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6).a() == \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.d) {
                    this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
                }
            }, br, TimeUnit.SECONDS);
        });
        return floodgatePlayer.sendForm(builder.build());
    }

    private static String a(int n, long l) {
        l ^= 0x11L;
        l ^= 0x1C3EAD3AF0350EFEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(14 + 55), (byte)(77 + 6), (byte)(4 + 43), (byte)(64 + 3), (byte)(50 + 16), (byte)(22 + 45), (byte)(43 + 4), (byte)(12 + 68), 75, (byte)(50 + 17), (byte)(65 + 18), 53, (byte)(59 + 21), (byte)(52 + 45), (byte)(67 + 33), (byte)(50 + 50), (byte)(88 + 17), (byte)(31 + 79), (byte)(46 + 57)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(34 + 34), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u014e\u015b\u015a\u011d\u015d\u0159\u0154\u015d\u0168\u0157\u0124\u0162\u0166\u015f\u0162\u0168\u012a\u049c\u04ba\u04bf\u04bb\u04c3\u0495\u04bf\u04bb\u04c0\u04a5\u049a\u04d0\u04d1\u04ce\u04bd", (byte)54, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public boolean b(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92) {
        int n;
        FloodgatePlayer floodgatePlayer = this.a.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a());
        if (floodgatePlayer == null) {
            return y != 0;
        }
        CustomForm.Builder builder = (CustomForm.Builder)CustomForm.builder().title(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bC, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[z]));
        int n2 = aa;
        int[] nArray = new int[ab];
        nArray[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.ac] = ad;
        nArray[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.ae] = af;
        int[] nArray2 = nArray;
        List<String> list = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bD, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[ag]);
        for (String string : list) {
            String[] stringArray;
            String string2;
            ++n2;
            if (string.length() > ah && string.charAt(ai) == aj && string.charAt(string.length() - ak) == al && (string2 = string.substring(am, string.length() - an)).contains((CharSequence)\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.c("\u3e80", (int)ao, (long)ap)) && (stringArray = string2.split((String)\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.c("\u3e83", (int)aq, (long)(ar ^ as)))).length == at) {
                builder.input(stringArray[au], stringArray[av]);
                if (nArray2[aw] == ax) {
                    nArray2[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.ay] = n2;
                    continue;
                }
                nArray2[\u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.az] = n2;
                continue;
            }
            builder.label(string);
        }
        int n3 = n = nArray2[ba] != bb ? bc : bd;
        if (n == 0) {
            return be != 0;
        }
        int n4 = nArray2[bf] != bg ? bh : bi;
        builder.closedOrInvalidResultHandler(() -> this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92));
        builder.validResultHandler(arg_0 -> this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, n4 != 0, arg_0));
        return floodgatePlayer.sendForm(builder.build());
    }

    static {
        a = Long.reverse(-4611686018427387904L);
        b = 0 >>> 174 | 0 << ~174 + 1;
        c = Integer.reverse(0);
        d = Integer.reverse(-1);
        e = Integer.reverse(-1);
        f = 0 >>> 132 | 0 << ~132 + 1;
        g = Integer.reverse(-1610612736);
        h = 0 >>> 30 | 0 << ~30 + 1;
        i = (-2147483603 >>> 31 | -2147483603 << -31) & 0xFFFFFFFF;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = 0xBA0000 >>> 177 | 0xBA0000 << -177;
        l = Integer.reverse(Integer.MIN_VALUE);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = (0 >>> 86 | 0 << ~86 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-5862304613095376954L);
        p = Long.reverse(-8646911284551352320L);
        q = (65536 >>> 144 | 65536 << ~144 + 1) & 0xFFFFFFFF;
        r = Long.reverse(-5862304613095376954L);
        s = Long.reverse(-8646911284551352320L);
        t = (1024 >>> 9 | 1024 << ~9 + 1) & 0xFFFFFFFF;
        u = (0 >>> 193 | 0 << ~193 + 1) & 0xFFFFFFFF;
        v = Integer.reverse(Integer.MIN_VALUE);
        w = Integer.reverse(-1);
        x = (0 >>> 32 | 0 << -32) & 0xFFFFFFFF;
        y = Integer.reverse(0);
        z = Integer.reverse(0);
        aa = -1 >>> 52 | -1 << ~52 + 1;
        ab = 32 >>> 132 | 32 << -132;
        ac = (0 >>> 181 | 0 << -181) & 0xFFFFFFFF;
        ad = (-1 >>> 182 | -1 << ~182 + 1) & 0xFFFFFFFF;
        ae = 32768 >>> 111 | 32768 << -111;
        af = (-1 >>> 221 | -1 << -221) & 0xFFFFFFFF;
        ag = (0 >>> 118 | 0 << -118) & 0xFFFFFFFF;
        ah = Integer.reverse(-1610612736);
        ai = (0 >>> 2 | 0 << ~2 + 1) & 0xFFFFFFFF;
        aj = 46592 >>> 105 | 46592 << -105;
        ak = 0x8000000 >>> 123 | 0x8000000 << -123;
        al = Integer.reverse(-1174405120);
        am = Integer.reverse(Integer.MIN_VALUE);
        an = Integer.reverse(Integer.MIN_VALUE);
        ao = Integer.reverse(0x40000000);
        ap = Long.reverse(2784606671455975366L);
        aq = Integer.reverse(-1073741824);
        ar = Long.reverse(-5862304613095376954L);
        as = Long.reverse(-8646911284551352320L);
        at = Integer.reverse(0x40000000);
        au = (0 >>> 225 | 0 << ~225 + 1) & 0xFFFFFFFF;
        av = 32 >>> 37 | 32 << -37;
        aw = Integer.reverse(0);
        ax = Integer.reverse(-1);
        ay = Integer.reverse(0);
        az = Integer.reverse(Integer.MIN_VALUE);
        ba = (0 >>> 252 | 0 << -252) & 0xFFFFFFFF;
        bb = Integer.reverse(-1);
        bc = 8 >>> 67 | 8 << -67;
        bd = Integer.reverse(0);
        be = 0 >>> 209 | 0 << ~209 + 1;
        bf = 16384 >>> 78 | 16384 << -78;
        bg = Integer.reverse(-1);
        bh = Integer.reverse(Integer.MIN_VALUE);
        bi = 0 >>> 65 | 0 << ~65 + 1;
        bj = 0x200000 >>> 144 | 0x200000 << ~144 + 1;
        bk = Integer.reverse(-100663296);
        bl = (64 >>> 101 | 64 << ~101 + 1) & 0xFFFFFFFF;
        bm = 0 >>> 59 | 0 << ~59 + 1;
        bn = (Integer.MIN_VALUE >>> 159 | Integer.MIN_VALUE << ~159 + 1) & 0xFFFFFFFF;
        bo = Long.reverse(-6917529027641081856L);
        bp = (524288 >>> 147 | 524288 << -147) & 0xFFFFFFFF;
        bq = Integer.reverse(0);
        br = Long.reverse(-6917529027641081856L);
        bs = 16384 >>> 76 | 16384 << ~76 + 1;
        bt = Integer.reverse(0x20000000);
        a = new String[bs];
        b = new String[bt];
        \u03a0\u03bd\u03c1\u03bc\u03c3\u0394\u03bd\u03b8\u03bc\u03a0\u0394\u03c9\u03c9\u03c5\u03b3.b();
    }

    private void a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92) {
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.R()) {
            return;
        }
        \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a().a(() -> {
            if (this.p.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6).a() == \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.d) {
                if (\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.A()) {
                    this.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
                } else {
                    this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
                }
            }
        }, a, TimeUnit.SECONDS);
    }
}

