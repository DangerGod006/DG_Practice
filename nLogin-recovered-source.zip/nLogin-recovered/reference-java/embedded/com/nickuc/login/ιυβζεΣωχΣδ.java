/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03b9\u03c5\u03b2\u03b6\u03b5\u03a3\u03c9\u03c7\u03a3\u03b4 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] y;
    private static int b = Integer.reverse(0x40000000);

    static {
        y = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03b9\u03c5\u03b2\u03b6\u03b5\u03a3\u03c9\u03c7\u03a3\u03b4.y[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.k.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u03c5\u03b2\u03b6\u03b5\u03a3\u03c9\u03c7\u03a3\u03b4.y[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.l.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

