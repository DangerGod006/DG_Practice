/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.proxy.velocity.nLoginVelocity;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4;
import com.nickuc.login.\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c0\u03b1\u03be\u03b2\u03a9\u03b9\u03c3\u03b5\u03c9\u03ba\u03c6\u0394\u03bc;
import com.nickuc.login.\u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8
implements \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 {
    private static int e;
    private final nLoginVelocity b;
    private static String[] a;
    private static int h;
    private static long b;
    private final \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb b;
    private \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 a;
    private static long c;
    private static long d;
    private static int a;
    private static int g;
    private static String[] b;
    private \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 a;
    private static long f;

    @Override
    @Generated
    public \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 a() {
        return this.a;
    }

    @Generated
    public \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8(nLoginVelocity nLoginVelocity2, \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb2) {
        this.b = nLoginVelocity2;
        this.b = \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb2;
    }

    private static void b() {
        int n;
        c = -4900188889152423584L;
        long l = c ^ 0xB666B8E22CAB6417L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(32 + 37), (byte)(43 + 40), (byte)(36 + 11), (byte)(6 + 61), (byte)(29 + 37), (byte)(7 + 60), (byte)(25 + 22), (byte)(10 + 70), (byte)(4 + 71), (byte)(64 + 3), (byte)(32 + 51), (byte)(21 + 32), (byte)(79 + 1), (byte)(65 + 32), 100, (byte)(81 + 19), (byte)(6 + 99), (byte)(62 + 48), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(26 + 42), 69, (byte)(17 + 66)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u0127\u0121\u00eb\u0116\u011f\u00e6\u00eb\u0130\u012d\u012f\u0123\u0103\u00f6\u0116\u010e\u0113\u0116\u010f\u011d\u0130\u00fd\u012d\u0104\u0105", (byte)25, 65);
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u012b\u011c\u00e5\u0122\u011f\u0108\u00f8\u00f1\u00fe\u0134\u0108\u00f9", (byte)25, 65);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0127\u0121\u00eb\u0116\u011f\u00e6\u00eb\u0130\u012d\u012f\u0125\u0114\u0123\u00f1\u0119\u0130\u00f6\u0104\u010d\u0135\u0116\u012d\u0104\u0105", (byte)25, 66);
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u044a\u0435\u0450\u0448\u045c\u0458\u0459\u0448\u0476\u043a\u045f\u0453\u0463\u045b\u0466\u043e\u0481\u0444\u048b\u048d\u0485\u047c\u0453\u0454", (byte)25, 67);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u011d\u011f\u010b\u0100\u00fb\u012d\u0109\u011a\u0126\u00f2\u00f3\u00ff\u00ef\u0126\u0112\u0127\u013a\u011b\u012f\u0137\u0130\u0110\u0117\u011f\u012c\u013c\u0131\u012f\u013d\u0121\u0132\u0124", (byte)25, 65);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0106\u012b\u0119\u0117\u00e0\u0110\u0101\u00e7\u0100\u00fe\u012e\u0125\u0100\u010a\u0104\u0111\u00f0\u00f1\u0134\u00fb\u0132\u013d\u0104\u0105", (byte)25, 65);
                }
            }
        }
    }

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, boolean bl) {
        this.k();
    }

    @Override
    @Generated
    public \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 a() {
        return this.a;
    }

    static {
        a = 0 >>> 201 | 0 << ~201 + 1;
        b = Long.reverse(477104034009907165L);
        d = Long.reverse(0x4600000000000000L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(4656444488209727453L);
        g = Integer.reverse(0x40000000);
        h = 16384 >>> 77 | 16384 << -77;
        a = new String[g];
        b = new String[h];
        \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.b();
    }

    @Override
    public void l() {
        if (this.a != null) {
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394 \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942 = this.b.a();
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.c(\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.a);
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.c(\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b);
        }
        this.a = null;
    }

    private static String a(int n, long l) {
        l ^= 0x62L;
        l ^= 0xB666B8E22CAB6417L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(34 + 35), (byte)(77 + 6), (byte)(27 + 20), (byte)(8 + 59), (byte)(60 + 6), (byte)(57 + 10), (byte)(24 + 23), (byte)(41 + 39), (byte)(33 + 42), 67, (byte)(18 + 65), (byte)(49 + 4), (byte)(7 + 73), (byte)(5 + 92), (byte)(61 + 39), (byte)(55 + 45), (byte)(52 + 53), 110, (byte)(56 + 47)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(34 + 35), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u052f\u053c\u053b\u04fe\u053e\u053a\u0535\u053e\u0549\u0538\u0505\u0543\u0547\u0540\u0543\u0549\u050b\u0891\u088f\u0896\u08a2\u089c\u0893\u087e\u0877\u08a3\u08a2\u089f", (byte)93, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void k() {
        \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 = this.b.a();
        this.a = this.b.b().j((String)\u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.c("\u3e80", (int)a, (long)(b ^ d))) ? new \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) : (this.b.b().j((String)\u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.c("\u3e83", (int)e, (long)f)) ? new \u03c8\u0393\u03c0\u03b1\u03be\u03b2\u03a9\u03b9\u03c3\u03b5\u03c9\u03ba\u03c6\u0394\u03bc() : null);
        if (this.a == null) {
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394 \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942 = this.b.a();
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.a(\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.a, this.b);
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.a(\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b, this.b);
            this.a = new \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u04f9\u051b\u051d\u04fd\u0521\u0540\u0538\u054e\u053a\u0509\u0547\u053d\u054b\u0545\u050e\u0533\u0555\u0554\u054c\u0552\u054c\u0521", (byte)21, 70), \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0534\u0541\u0540\u0503\u0543\u053f\u053a\u0543\u054e\u053d\u050a\u0548\u054c\u0545\u0548\u054e\u0510\u0896\u0894\u089b\u08a7\u08a1\u0898\u0883\u087c\u08a8\u08a7\u08a4\u0527", (byte)21, 70) + string + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u050b", (byte)21, 69) + methodType.toString(), exception);
        }
    }
}

