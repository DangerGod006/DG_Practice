/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393
implements \u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9,
\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static long c;
    private static int l;
    private static int b;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 V;
    private static int k;
    private static int g;
    private static String[] b;
    private static int a;
    private static int c;
    private static long j;
    private static long e;
    private static int h;
    private static long i;
    private static String[] a;
    private static int m;
    private static long f;
    private static int d;

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(Integer.MIN_VALUE);
        c = (0 >>> 30 | 0 << ~30 + 1) & 0xFFFFFFFF;
        d = Integer.reverse(0);
        e = Long.reverse(5560851983676588313L);
        f = Long.reverse(0x7A00000000000000L);
        g = 0 >>> 126 | 0 << ~126 + 1;
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Long.reverse(5560851983676588313L);
        j = Long.reverse(0x7A00000000000000L);
        k = Integer.reverse(0);
        l = (32768 >>> 174 | 32768 << ~174 + 1) & 0xFFFFFFFF;
        m = Integer.reverse(0x40000000);
        a = new String[l];
        b = new String[m];
        \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b();
    }

    @Generated
    public \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.V = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.w, new Object[a]);
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[b];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.c] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.V;
    }

    private static String a(int n, long l) {
        l ^= 0x5EL;
        l ^= 0xA68EDD99826DEA9L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(61 + 7), (byte)(52 + 17), (byte)(48 + 35), (byte)(4 + 43), (byte)(31 + 36), (byte)(29 + 37), (byte)(48 + 19), (byte)(20 + 27), (byte)(35 + 45), 75, (byte)(29 + 38), (byte)(27 + 56), (byte)(45 + 8), (byte)(74 + 6), (byte)(31 + 66), 100, (byte)(40 + 60), (byte)(82 + 23), (byte)(93 + 17), (byte)(29 + 74)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(46 + 23), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u057d\u058a\u0589\u054c\u058c\u0588\u0583\u058c\u0597\u0586\u0553\u0591\u0595\u058e\u0591\u0597\u0559\u08ec\u08bf\u08c1\u08e8\u08f0\u08d0\u08e9\u08f6\u08ee\u08fb\u08e8\u08dc\u08ca", (byte)119, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u04f6\u0518\u051a\u04fa\u051e\u053d\u0535\u054b\u0537\u0506\u0544\u053a\u0548\u0542\u050b\u0530\u0552\u0551\u0549\u054f\u0549\u051e", (byte)18, 70), \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0106\u0113\u0112\u00d5\u0115\u0111\u010c\u0115\u0120\u010f\u00dc\u011a\u011e\u0117\u011a\u0120\u00e2\u0475\u0448\u044a\u0471\u0479\u0459\u0472\u047f\u0477\u0484\u0471\u0465\u0453\u00fb", (byte)18, 65) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u00dd", (byte)18, 65) + methodType.toString(), exception);
        }
    }

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72) {
        if (\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72 == \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b) {
            try {
                this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42).f(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
            }
            catch (Exception exception) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.c("\u3e80", (int)d, (long)(e ^ f)), exception, new Object[g]);
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, (String)\u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.c("\u3e83", (int)h, (long)(i ^ j)), new Object[k]);
            }
        }
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().q();
    }

    private static void b() {
        int n;
        c = -7456964854000634702L;
        long l = c ^ 0xA68EDD99826DEA9L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(20 + 49), (byte)(82 + 1), 47, 67, (byte)(25 + 41), (byte)(22 + 45), (byte)(44 + 3), (byte)(20 + 60), (byte)(28 + 47), (byte)(61 + 6), (byte)(16 + 67), (byte)(12 + 41), (byte)(45 + 35), (byte)(93 + 4), (byte)(62 + 38), (byte)(80 + 20), (byte)(28 + 77), (byte)(27 + 83), (byte)(39 + 64)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(45 + 24), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u054c\u054c\u0543\u0512\u053d\u054c\u051d\u0532\u0553\u0561\u0536\u052e\u055e\u051d\u0533\u0544\u051f\u0546\u055e\u055d\u0537\u0541\u055b\u0563\u053f\u056e\u055b\u056c\u0545\u0552\u0562\u0534\u0545\u0578\u0534\u054c\u054c\u055c\u054c\u054d\u0557\u056d\u0539\u0547", (byte)35, 69);
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u048c\u0492\u0462\u0496\u0487\u048c\u0459\u0476\u0471\u0469\u0496\u0476\u0484\u04a1\u048e\u0498\u04a0\u04a4\u0484\u0494\u047e\u04ad\u046d\u0487\u046c\u0484\u04a0\u0483\u048c\u0483\u04b1\u04ae\u0469\u04b5\u04a4\u0496\u04b6\u049d\u04b2\u04b5\u0498\u0497\u0481\u04ac\u04a4\u04c4\u04bf\u0491\u048f\u049e\u04a0\u04c1\u04b6\u04ca\u04b8\u04ce\u04b0\u0489\u04d2\u04bb\u04a6\u04ac\u04c6\u0490\u04a1\u04c3\u04c3\u04da\u04c6\u04cd\u0496\u04a7\u04d2\u049d\u04ae\u04d4\u04ab\u04a0\u04c0\u04b5\u04e0\u04bc\u04e1\u04a0\u04da\u04a5\u04c3\u04bb\u04c9\u04ad\u04cf\u04d1\u04ea\u04dc\u04cc\u04b0\u04c6\u04c4\u04e1\u04ed\u04b9\u04f3\u04ba\u04d1\u04ff\u04ee\u04b8\u04c6", (byte)35, 68);
                    continue block7;
                }
                case 1: {
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0132\u0132\u0129\u00f8\u0123\u0132\u0103\u0118\u0139\u0147\u011c\u0114\u0144\u0103\u0119\u012a\u0105\u012c\u0144\u0143\u011d\u0127\u0141\u0149\u0125\u0154\u0141\u0152\u012b\u0138\u0148\u011a\u015d\u0139\u013a\u011d\u0153\u011a\u0164\u0152\u0134\u015a\u0159\u013a\u012a\u015d\u0146\u014a\u013d\u015b\u0161\u012b\u0146\u0161\u0138\u0139", (byte)35, 66);
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u054d\u0553\u0523\u0557\u0548\u054d\u051a\u0537\u0532\u052a\u0557\u0537\u0545\u0562\u054f\u0559\u0561\u0565\u0545\u0555\u053f\u056e\u052e\u0548\u052d\u0545\u0561\u0544\u054d\u0544\u0572\u056f\u052a\u0576\u0565\u0557\u0577\u055e\u0573\u0576\u0559\u0558\u0542\u056d\u0565\u0585\u0580\u0552\u0550\u055f\u0561\u0582\u0577\u058b\u0579\u058f\u0571\u054a\u0593\u057c\u0567\u056d\u0587\u0551\u0562\u0584\u0584\u059b\u0587\u058e\u0557\u0568\u0593\u055e\u056f\u0595\u056c\u0561\u0581\u0576\u05a1\u057d\u05a2\u0561\u059b\u0566\u0584\u057c\u058a\u056e\u0590\u0592\u05ab\u059d\u058d\u0571\u0592\u05b7\u05b6\u05a7\u059c\u05b0\u0586\u0594\u058a\u05bf\u0593\u05ad\u059e\u058f\u05af\u057f\u0582\u05c6\u05c7\u0586\u05bc\u05cb\u0592\u0593", (byte)35, 70);
                    continue block7;
                }
                case 2: {
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0475\u046f\u0469\u0459\u0472\u047b\u048c\u0474\u049d\u0473\u04a0\u046e\u0472\u048c\u0485\u0478\u0490\u047a\u0489\u047d\u0467\u04aa\u0471\u0472", (byte)35, 67);
                    continue block7;
                }
                case 4: {
                    \u03c1\u0393\u0394\u03ba\u03c1\u03a0\u03b8\u03c4\u03bb\u03c7\u03b3\u03a6\u0393.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0489\u0488\u0457\u0479\u0456\u0496\u0474\u0466\u0470\u0491\u049d\u047a\u0482\u0462\u049e\u0460\u0485\u0486\u049b\u049d\u048b\u049a\u0471\u0472", (byte)35, 67);
                }
            }
        }
    }
}

