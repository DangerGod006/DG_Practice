/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba {
    private static long d;
    private static int q;
    private static int g;
    private static int k;
    private static int p;
    private static int f;
    private static int o;
    private static long s;
    private static long c;
    private static final char a;
    private static int r;
    private static int l;
    final Map<String, Object> d = (long)new LinkedHashMap();
    private static long b;
    private static int e;
    private static String[] b;
    private static int v;
    private static int a;
    private static int n;
    private final \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba a;
    private static int h;
    private static int m;
    private static int i;
    private static int u;
    private static int j;
    private static int t;
    private static String[] a;

    public List<Boolean> i(String string) {
        List<?> list = this.l(string);
        ArrayList<Boolean> arrayList = new ArrayList<Boolean>();
        for (Object obj : list) {
            if (!(obj instanceof Boolean)) continue;
            arrayList.add((Boolean)obj);
        }
        return arrayList;
    }

    public List<Double> h(String string) {
        List<?> list = this.l(string);
        ArrayList<Double> arrayList = new ArrayList<Double>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(((Number)obj).doubleValue());
        }
        return arrayList;
    }

    public List<String> k(String string) {
        List<?> list = this.l(string);
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Object obj : list) {
            if (!(obj instanceof String)) continue;
            arrayList.add((String)obj);
        }
        return arrayList;
    }

    public boolean l(String string) {
        return (this.a(string, (T)null) != null ? k : l) != 0;
    }

    public void a(String string, Object object) {
        Object object2;
        if (object instanceof Map) {
            object = new \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba((Map)object, this.a == null ? null : this.a.b(string));
        }
        if ((object2 = this.a(string)) == this) {
            if (object == null) {
                this.d.remove(string);
            } else {
                this.d.put(string, object);
            }
        } else {
            ((\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba)object2).a(this.j(string), object);
        }
    }

    public List<Short> d(String string) {
        List<?> list = this.l(string);
        ArrayList<Short> arrayList = new ArrayList<Short>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(((Number)obj).shortValue());
        }
        return arrayList;
    }

    public double a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).doubleValue() : 0.0);
    }

    public float a(String string, float f) {
        Float f2 = this.a(string, (T)Float.valueOf(f));
        return f2 instanceof Number ? ((Number)f2).floatValue() : f;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04c1\u04e3\u04e5\u04c5\u04e9\u0508\u0500\u0516\u0502\u04d1\u050f\u0505\u0513\u050d\u04d6\u04fb\u051d\u051c\u0514\u051a\u0514\u04e9", (byte)76, 68), \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u017a\u0187\u0186\u0149\u0189\u0185\u0180\u0189\u0194\u0183\u0150\u018e\u0192\u018b\u018e\u0194\u0156\u04e6\u04e6\u04d3\u04ec\u04c7\u04e0\u04e0\u04f7\u04e5\u04e7\u04e7\u04f5\u04d4\u04ef\u0170", (byte)76, 65) + string + \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0542", (byte)76, 70) + methodType.toString(), exception);
        }
    }

    public boolean m(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Boolean ? (Boolean)object : p);
    }

    public Object a(String string) {
        return this.a(string, (T)this.e(string));
    }

    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba(Map<?, ?> map, \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2) {
        this.a = \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2;
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            String string;
            String string2 = string = entry.getKey() == null ? \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.c("\u3e80", (int)a, (long)(b ^ d)) : entry.getKey().toString();
            if (entry.getValue() instanceof Map) {
                this.d.put(string, new \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba((Map)entry.getValue(), \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2 == null ? null : \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2.b(string)));
                continue;
            }
            this.d.put(string, entry.getValue());
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(8424703541181854603L);
        d = Long.reverse(0x1E00000000000000L);
        e = Integer.reverse(0x74000000);
        f = (-1 >>> 97 | -1 << ~97 + 1) & 0xFFFFFFFF;
        g = (0 >>> 22 | 0 << -22) & 0xFFFFFFFF;
        h = 47104 >>> 138 | 47104 << -138;
        i = Integer.reverse(-1);
        j = 0x40000000 >>> 222 | 0x40000000 << -222;
        k = Integer.reverse(Integer.MIN_VALUE);
        l = 0 >>> 88 | 0 << ~88 + 1;
        m = (0 >>> 205 | 0 << ~205 + 1) & 0xFFFFFFFF;
        n = 0 >>> 226 | 0 << -226;
        o = (0 >>> 60 | 0 << -60) & 0xFFFFFFFF;
        p = Integer.reverse(0);
        q = 0 >>> 146 | 0 << ~146 + 1;
        r = (0x40000000 >>> 94 | 0x40000000 << ~94 + 1) & 0xFFFFFFFF;
        s = Long.reverse(7704127600802575243L);
        t = (65536 >>> 239 | 65536 << ~239 + 1) & 0xFFFFFFFF;
        u = (2 >>> 160 | 2 << ~160 + 1) & 0xFFFFFFFF;
        v = 0x70000001 >>> 91 | 0x70000001 << -91;
        a = new String[t];
        b = new String[u];
        \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b();
        a = (char)v;
    }

    public <T> T a(String string, T t) {
        Object object = this.a(string);
        Object object2 = object == this ? this.d.get(string) : ((\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba)object).a(this.j(string), t);
        if (object2 == null && t instanceof \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba) {
            this.d.put(string, t);
        }
        return (T)(object2 != null ? object2 : t);
    }

    public List<Float> g(String string) {
        List<?> list = this.l(string);
        ArrayList<Float> arrayList = new ArrayList<Float>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(Float.valueOf(((Number)obj).floatValue()));
        }
        return arrayList;
    }

    public double a(String string, double d) {
        Double d2 = this.a(string, (T)d);
        return d2 instanceof Number ? ((Number)d2).doubleValue() : d;
    }

    public byte a(String string, byte by) {
        Byte by2 = this.a(string, (T)by);
        return by2 instanceof Number ? ((Number)by2).byteValue() : by;
    }

    private String j(String string) {
        int n = string.indexOf(h);
        return n == i ? string : string.substring(n + j);
    }

    private static void b() {
        int n;
        c = -3328872160462547154L;
        long l = c ^ 0xDD825FA53611B506L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(56 + 12), (byte)(41 + 28), (byte)(14 + 69), (byte)(39 + 8), (byte)(22 + 45), 66, (byte)(25 + 42), 47, (byte)(57 + 23), (byte)(30 + 45), (byte)(62 + 5), (byte)(3 + 80), (byte)(22 + 31), (byte)(79 + 1), (byte)(61 + 36), (byte)(16 + 84), (byte)(79 + 21), (byte)(47 + 58), (byte)(92 + 18), (byte)(100 + 3)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(46 + 23), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0545\u052f\u0508\u0522\u0551\u0511\u054f\u0551\u0522\u0515\u0528\u051d", (byte)25, 69);
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0544\u051c\u0542\u050b\u0510\u0523\u0522\u0550\u0522\u054d\u0538\u051d", (byte)25, 70);
                    continue block7;
                }
                case 1: {
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0102\u00e8\u00ec\u011a\u011f\u0127\u00fa\u011e\u0120\u012a\u0108\u0102\u0109\u0118\u00ef\u0132\u0118\u012d\u012e\u011d\u0128\u013d\u0104\u0105", (byte)25, 65);
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0117\u00fe\u0116\u00fa\u00e6\u0103\u012a\u012f\u0127\u0111\u0104\u00f9", (byte)25, 66);
                    continue block7;
                }
                case 2: {
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u011e\u0121\u0108\u012b\u012a\u011b\u00ed\u00ef\u0124\u00ef\u0123\u0108\u00fe\u0122\u0129\u0127\u0133\u0124\u0133\u0130\u011f\u0116\u0131\u011e\u010e\u012d\u011e\u012e\u011f\u013e\u0148\u011e", (byte)25, 66);
                    continue block7;
                }
                case 4: {
                    \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u046a\u0463\u042d\u046f\u0454\u044d\u0447\u0468\u0449\u045c\u045e\u0470\u046d\u0470\u045e\u0469\u0487\u046a\u0458\u0489\u0486\u0466\u0453\u0454", (byte)25, 67);
                }
            }
        }
    }

    public List<?> l(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof List ? (List)object : Collections.EMPTY_LIST);
    }

    public List<Integer> e(String string) {
        List<?> list = this.l(string);
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(((Number)obj).intValue());
        }
        return arrayList;
    }

    public char a(String string, char c) {
        Character c2 = this.a(string, (T)Character.valueOf(c));
        return c2 instanceof Character ? c2.charValue() : c;
    }

    public int a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).intValue() : o);
    }

    public short a(String string, short s) {
        Short s2 = this.a(string, (T)s);
        return s2 instanceof Number ? ((Number)s2).shortValue() : s;
    }

    public float a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).floatValue() : 0.0f);
    }

    public \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba(\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2) {
        this(new LinkedHashMap(), \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba2);
    }

    private static String a(int n, long l) {
        l ^= 0x78L;
        l ^= 0xDD825FA53611B506L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(50 + 19), (byte)(30 + 53), (byte)(40 + 7), (byte)(7 + 60), (byte)(11 + 55), (byte)(14 + 53), (byte)(6 + 41), (byte)(26 + 54), (byte)(23 + 52), (byte)(42 + 25), (byte)(36 + 47), (byte)(29 + 24), (byte)(26 + 54), (byte)(21 + 76), 100, (byte)(3 + 97), (byte)(85 + 20), (byte)(25 + 85), (byte)(88 + 15)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(65 + 4), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00f8\u0105\u0104\u00c7\u0107\u0103\u00fe\u0107\u0112\u0101\u00ce\u010c\u0110\u0109\u010c\u0112\u00d4\u0464\u0464\u0451\u046a\u0445\u045e\u045e\u0475\u0463\u0465\u0465\u0473\u0452\u046d", (byte)11, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public String g(String string, String string2) {
        String string3 = this.a(string, (T)string2);
        return string3 instanceof String ? string3 : string2;
    }

    public boolean a(String string, boolean bl) {
        Boolean bl2 = this.a(string, (T)bl);
        return bl2 instanceof Boolean ? bl2 : bl;
    }

    public \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba() {
        this(null);
    }

    public String k(String string) {
        Object object = this.e(string);
        return this.g(string, (String)(object instanceof String ? (String)object : \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba.c("\u3e80", (int)r, (long)s)));
    }

    public long a(String string, long l) {
        Long l2 = this.a(string, (T)l);
        return l2 instanceof Number ? ((Number)l2).longValue() : l;
    }

    public short a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).shortValue() : n);
    }

    public \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba b(String string) {
        Object object = this.e(string);
        return (\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba)this.a(string, (T)(object instanceof \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba ? object : new \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba(this.a == null ? null : this.a.b(string))));
    }

    public Collection<String> e() {
        return new LinkedHashSet<String>(this.d.keySet());
    }

    public long a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).longValue() : 0L);
    }

    public List<Byte> c(String string) {
        List<?> list = this.l(string);
        ArrayList<Byte> arrayList = new ArrayList<Byte>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(((Number)obj).byteValue());
        }
        return arrayList;
    }

    public int a(String string, int n) {
        Integer n2 = this.a(string, (T)n);
        return n2 instanceof Number ? ((Number)n2).intValue() : n;
    }

    public List<Long> f(String string) {
        List<?> list = this.l(string);
        ArrayList<Long> arrayList = new ArrayList<Long>();
        for (Object obj : list) {
            if (!(obj instanceof Number)) continue;
            arrayList.add(((Number)obj).longValue());
        }
        return arrayList;
    }

    public List<Character> j(String string) {
        List<?> list = this.l(string);
        ArrayList<Character> arrayList = new ArrayList<Character>();
        for (Object obj : list) {
            if (!(obj instanceof Character)) continue;
            arrayList.add((Character)obj);
        }
        return arrayList;
    }

    public List<?> a(String string, List<?> list) {
        List<?> list2 = this.a(string, (T)list);
        return list2 instanceof List ? list2 : list;
    }

    private \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba a(String string) {
        int n = string.indexOf(e);
        if (n == f) {
            return this;
        }
        String string2 = string.substring(g, n);
        Object object = this.d.get(string2);
        if (object == null) {
            object = new \u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba(this.a == null ? null : this.a.b(string2));
            this.d.put(string2, object);
        }
        return (\u03be\u03bd\u03a9\u03c1\u039b\u03b3\u03b2\u03c8\u03b5\u03b6\u03b5\u03c2\u03a0\u03ba)object;
    }

    public byte a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Number ? ((Number)object).byteValue() : m);
    }

    public Object e(String string) {
        return this.a == null ? null : this.a.a(string);
    }

    public char a(String string) {
        Object object = this.e(string);
        return this.a(string, object instanceof Character ? ((Character)object).charValue() : q);
    }
}

