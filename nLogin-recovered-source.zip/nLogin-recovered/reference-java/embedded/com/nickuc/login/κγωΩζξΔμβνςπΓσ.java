/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketListenerAbstract
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  com.nickuc.login.lib.packetevents.api.netty.channel.ChannelHelper
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketListenerAbstract;
import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.lib.packetevents.api.netty.channel.ChannelHelper;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3
extends PacketListenerAbstract {
    private static long p;
    private static long c;
    private static long x;
    private static int j;
    private static int ad;
    private static int ai;
    private static int ag;
    private static int s;
    private static long ah;
    private static int l;
    private static int g;
    private static int e;
    private static long k;
    private static int aj;
    private static long ac;
    final /* synthetic */ \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6 b;
    private static int h;
    private static int o;
    private static long v;
    private static long aa;
    private static long d;
    private static long y;
    private static long ae;
    private static String[] b;
    private static int w;
    private static long u;
    private static int a;
    private static int z;
    private static long f;
    private static int ak;
    private static int t;
    private static long n;
    private static int r;
    private static long i;
    private static int ab;
    private static int af;
    private static String[] a;
    private static long m;
    private static long q;
    private static int b;

    private static void b() {
        int n;
        c = 211314234593104249L;
        long l = c ^ 0x8ADCDA6AC7ADAC88L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(38 + 30), (byte)(17 + 52), (byte)(53 + 30), (byte)(34 + 13), (byte)(60 + 7), (byte)(53 + 13), (byte)(12 + 55), (byte)(20 + 27), (byte)(43 + 37), (byte)(42 + 33), 67, (byte)(3 + 80), (byte)(5 + 48), (byte)(11 + 69), (byte)(25 + 72), (byte)(22 + 78), (byte)(42 + 58), (byte)(25 + 80), (byte)(90 + 20), (byte)(81 + 22)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(65 + 3), 69, (byte)(59 + 24)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u042d\u043c\u0444\u042d\u042e\u0476\u044d\u0471\u0450\u045a\u044c\u0472\u044e\u0437\u0447\u0436\u047a\u0470\u045a\u0472\u0460\u044d\u044a\u044b", (byte)22, 67);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u011e\u00f8\u00f7\u0127\u0103\u0100\u00e8\u0115\u0128\u0109\u00e8\u012f\u010a\u0119\u012f\u0123\u011d\u011f\u0112\u0129\u0107\u0101\u00fe\u00ff", (byte)22, 66);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u011c\u010d\u0123\u00ff\u011e\u0120\u0124\u00f9\u00eb\u0118\u010a\u00f3", (byte)22, 66);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0525\u054b\u0524\u0519\u054d\u050a\u0546\u0546\u052d\u0554\u0552\u0530\u052b\u0522\u0546\u050c\u0523\u0513\u053d\u052c\u0559\u0532\u0541\u0563\u0537\u052e\u0545\u055a\u0563\u0545\u054a\u053c\u054a\u0545\u0537\u0565\u0564\u0562\u0530\u054c\u0573\u056c\u0550\u0564\u056f\u0542\u0530\u0554\u0534\u053a\u053d\u0567\u054f\u0558\u0545\u0546", (byte)22, 70);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u00fe\u00e4\u0110\u00e2\u011a\u00f8\u0107\u0120\u012c\u00f8\u012c\u00f3", (byte)22, 65);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[5] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0439\u0444\u0452\u0474\u0441\u046c\u043e\u0448\u044c\u042f\u0456\u043f", (byte)22, 67);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[6] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0508\u0517\u051f\u0508\u0509\u0551\u0528\u054c\u052b\u0535\u0527\u054d\u0529\u0512\u0522\u0511\u0555\u054b\u0535\u054d\u053b\u0528\u0525\u0526", (byte)22, 69);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[7] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u046a\u0444\u0443\u0473\u044f\u044c\u0434\u0461\u0474\u0455\u0434\u047b\u0456\u0465\u047b\u046f\u0469\u046b\u045e\u0475\u0453\u044d\u044a\u044b", (byte)22, 68);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[8] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0543\u0534\u054a\u0526\u0545\u0547\u054b\u0520\u0512\u053f\u0531\u051a", (byte)22, 69);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[9] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u044a\u0470\u0449\u043e\u0472\u042f\u046b\u046b\u0452\u0479\u0477\u0455\u0450\u0447\u046b\u0431\u0448\u0438\u0462\u0451\u047e\u0459\u044e\u0472\u0445\u0478\u0488\u043d\u046d\u046e\u0477\u0441\u044f\u0484\u045e\u047f\u0464\u0467\u0482\u0456\u0472\u0455\u0472\u047b\u0496\u0465\u0477\u048a\u0492\u0480\u046a\u047e\u0496\u047d\u046a\u046b", (byte)22, 68);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[10] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u044a\u0430\u045c\u042e\u0466\u0444\u0453\u046c\u0478\u0444\u0478\u043f", (byte)22, 68);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[11] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0514\u051f\u052d\u054f\u051c\u0547\u0519\u0523\u0527\u050a\u0531\u051a", (byte)22, 70);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u00e1\u00f0\u00f8\u00e1\u00e2\u012a\u0101\u0125\u0104\u010e\u0101\u00e5\u00e6\u00ed\u00eb\u0122\u0102\u010d\u00ff\u0118\u0106\u0137\u00fe\u00ff", (byte)22, 65);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0545\u051f\u051e\u054e\u052a\u0527\u050f\u053c\u054f\u0530\u050c\u0534\u052d\u0555\u050b\u0525\u0547\u0514\u052f\u054d\u0527\u0538\u0525\u0526", (byte)22, 69);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u046a\u045a\u043d\u044a\u0446\u0450\u044e\u0450\u0470\u044f\u044e\u043f", (byte)22, 67);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u044a\u0470\u0449\u043e\u0472\u042f\u046b\u046b\u0452\u0479\u0477\u0455\u0450\u0447\u046b\u0431\u0448\u0438\u0462\u0451\u047e\u0457\u0466\u0488\u045c\u0453\u046a\u047f\u0488\u046a\u046f\u0461\u046f\u046a\u045c\u048a\u0489\u0487\u0455\u0471\u0498\u0491\u0475\u048e\u0472\u048b\u0490\u049d\u047c\u0481\u045a\u047b\u049d\u0493\u046a\u046b", (byte)22, 68);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u054b\u0546\u0521\u0507\u051d\u0519\u054c\u054f\u0533\u0545\u050c\u051a", (byte)22, 69);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u044e\u046c\u0460\u044e\u043d\u0453\u046e\u0453\u0453\u046e\u0435\u043f", (byte)22, 68);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[6] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u00e1\u00f0\u00f8\u00e1\u00e2\u012a\u0101\u0125\u0104\u010e\u0100\u00e1\u0102\u00ee\u0103\u0130\u00f2\u0102\u0109\u0104\u0121\u0137\u00fe\u00ff", (byte)22, 66);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[7] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0545\u051f\u051e\u054e\u052a\u0527\u050f\u053c\u054f\u0530\u050e\u0532\u0547\u052d\u0552\u0548\u0512\u0538\u053e\u0557\u055d\u054e\u0525\u0526", (byte)22, 70);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u00df\u0122\u00dc\u0104\u00f9\u010a\u00e7\u0127\u00e4\u00e4\u00e9\u00f3", (byte)22, 66);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[9] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u00fe\u0124\u00fd\u00f2\u0126\u00e3\u011f\u011f\u0106\u012d\u012b\u0109\u0104\u00fb\u011f\u00e5\u00fc\u00ec\u0116\u0105\u0132\u010d\u0102\u0126\u00f9\u012c\u013c\u00f1\u0121\u0122\u012b\u00f5\u0103\u0138\u0112\u0133\u0118\u011b\u0136\u010a\u0126\u0109\u0129\u011b\u010e\u013b\u0125\u0125\u0142\u013e\u011f\u0149\u0142\u0131\u011e\u011f", (byte)22, 66);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[10] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0111\u0112\u00df\u0116\u00df\u0123\u00fa\u0123\u00fc\u012a\u0124\u00f3", (byte)22, 65);
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[11] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0101\u00ef\u0101\u00fd\u0128\u0104\u012a\u0123\u00f5\u0127\u0120\u00f3", (byte)22, 65);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u00f4\u00f2\u00fc\u0116\u011c\u0114\u0128\u0120\u00ea\u00e8\u010a\u00e1\u00f8\u00fb\u0108\u00ec\u0126\u0125\u0110\u0102\u00f0\u0101\u00fe\u00ff", (byte)22, 66);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0548\u054d\u051d\u0539\u050b\u053e\u051a\u051e\u0533\u051e\u0530\u052b\u051f\u0512\u0524\u0534\u0516\u0550\u0536\u055a\u0549\u055c\u054c\u052f\u0564\u054e\u053c\u0562\u055d\u0552\u0560\u0528", (byte)22, 69);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x5DL;
        l ^= 0x8ADCDA6AC7ADAC88L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(32 + 36), (byte)(63 + 6), (byte)(36 + 47), (byte)(21 + 26), (byte)(65 + 2), (byte)(54 + 12), (byte)(43 + 24), (byte)(44 + 3), (byte)(59 + 21), 75, (byte)(64 + 3), (byte)(9 + 74), (byte)(19 + 34), (byte)(43 + 37), (byte)(45 + 52), (byte)(60 + 40), (byte)(18 + 82), (byte)(18 + 87), (byte)(49 + 61), (byte)(43 + 60)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(31 + 38), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0424\u0431\u0430\u03f3\u0433\u042f\u042a\u0433\u043e\u042d\u03fa\u0438\u043c\u0435\u0438\u043e\u0400\u078c\u0786\u079d\u077e\u078c\u0795\u076c\u0795\u078c\u0798\u079e\u079d\u0771\u07a2", (byte)4, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public void onPacketSend(PacketSendEvent packetSendEvent) {
        if (packetSendEvent.isCancelled()) {
            return;
        }
        try {
            \u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b \u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b2 = (\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b)\u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6.b(this.b).get(packetSendEvent.getPacketType());
            if (\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b2 != null) {
                \u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b2.a(packetSendEvent);
            }
        }
        catch (Throwable throwable) {
            packetSendEvent.setCancelled(s != 0);
            ChannelHelper.close((Object)packetSendEvent.getChannel());
            User user = packetSendEvent.getUser();
            String string = (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e80", (int)t, (long)(u ^ v)) + packetSendEvent.getServerVersion() + (String)(user != null ? (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e83", (int)w, (long)(x ^ y)) + user.getClientVersion() : \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e86", (int)z, (long)aa));
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e89", (int)ab, (long)ac) + packetSendEvent.getPacketType() + (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e8c", (int)ad, (long)ae) + string + (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e8f", (int)(af & ag), (long)ah), throwable, new Object[ai]);
        }
    }

    public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
        if (packetReceiveEvent.isCancelled()) {
            return;
        }
        try {
            \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a62 = (\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6)\u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6.a(this.b).get(packetReceiveEvent.getPacketType());
            if (\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a62 != null) {
                \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a62.a(packetReceiveEvent);
            }
        }
        catch (Throwable throwable) {
            packetReceiveEvent.setCancelled(a != 0);
            ChannelHelper.close((Object)packetReceiveEvent.getChannel());
            User user = packetReceiveEvent.getUser();
            String string = (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e80", (int)b, (long)d) + packetReceiveEvent.getServerVersion() + (String)(user != null ? (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e83", (int)e, (long)f) + user.getClientVersion() : \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e86", (int)(g & h), (long)i));
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e89", (int)j, (long)k) + packetReceiveEvent.getPacketType() + (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e8c", (int)l, (long)(m ^ n)) + string + (String)\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.c("\u3e8f", (int)o, (long)(p ^ q)), throwable, new Object[r]);
        }
    }

    public \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3(\u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6 \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c62) {
        this.b = \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c62;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u04ee\u0510\u0512\u04f2\u0516\u0535\u052d\u0543\u052f\u04fe\u053c\u0532\u0540\u053a\u0503\u0528\u054a\u0549\u0541\u0547\u0541\u0516", (byte)10, 70), \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0436\u0443\u0442\u0405\u0445\u0441\u043c\u0445\u0450\u043f\u040c\u044a\u044e\u0447\u044a\u0450\u0412\u079e\u0798\u07af\u0790\u079e\u07a7\u077e\u07a7\u079e\u07aa\u07b0\u07af\u0783\u07b4\u042c", (byte)10, 67) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0500", (byte)10, 69) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        d = Long.reverse(2633452405936453440L);
        e = 1 >>> 192 | 1 << ~192 + 1;
        f = Long.reverse(2633452405936453440L);
        g = Integer.reverse(0x40000000);
        h = (-1 >>> 81 | -1 << ~81 + 1) & 0xFFFFFFFF;
        i = Long.reverse(2633452405936453440L);
        j = Integer.reverse(-1073741824);
        k = Long.reverse(2633452405936453440L);
        l = (4096 >>> 138 | 4096 << ~138 + 1) & 0xFFFFFFFF;
        m = Long.reverse(-7022265195145889984L);
        n = Long.reverse(-5044031582654955520L);
        o = 0x28000000 >>> 59 | 0x28000000 << ~59 + 1;
        p = Long.reverse(-7022265195145889984L);
        q = Long.reverse(-5044031582654955520L);
        r = Integer.reverse(0);
        s = Integer.reverse(Integer.MIN_VALUE);
        t = 0x180000 >>> 242 | 0x180000 << ~242 + 1;
        u = Long.reverse(-7022265195145889984L);
        v = Long.reverse(-5044031582654955520L);
        w = 458752 >>> 112 | 458752 << -112;
        x = Long.reverse(-7022265195145889984L);
        y = Long.reverse(-5044031582654955520L);
        z = Integer.reverse(0x10000000);
        aa = Long.reverse(2633452405936453440L);
        ab = Integer.reverse(-1879048192);
        ac = Long.reverse(2633452405936453440L);
        ad = 80 >>> 99 | 80 << -99;
        ae = Long.reverse(2633452405936453440L);
        af = Integer.reverse(-805306368);
        ag = Integer.reverse(-1);
        ah = Long.reverse(2633452405936453440L);
        ai = (0 >>> 154 | 0 << -154) & 0xFFFFFFFF;
        aj = Integer.reverse(0x30000000);
        ak = 192 >>> 228 | 192 << -228;
        a = new String[aj];
        b = new String[ak];
        \u03ba\u03b3\u03c9\u03a9\u03b6\u03be\u0394\u03bc\u03b2\u03bd\u03c2\u03c0\u0393\u03c3.b();
    }
}

