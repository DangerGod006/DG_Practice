/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.citizensnpcs.api.CitizensAPI
 *  org.bukkit.entity.Entity
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.citizensnpcs.api.CitizensAPI;
import org.bukkit.entity.Entity;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2 {
    private static String[] b;
    private static long c;
    private boolean G = a;
    private static long i;
    private static long e;
    private static int a;
    private static int c;
    private static String[] a;
    private static int b;
    private static int j;
    private static int f;
    private static int g;
    private static int h;
    private static int l;
    private static int k;
    private static int m;
    private static long d;

    private static void b() {
        int n;
        c = 2880721983740907624L;
        long l = c ^ 0x1F57C865369B7868L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(45 + 24), (byte)(11 + 72), (byte)(20 + 27), (byte)(59 + 8), (byte)(58 + 8), (byte)(44 + 23), (byte)(15 + 32), (byte)(67 + 13), (byte)(8 + 67), (byte)(7 + 60), (byte)(14 + 69), (byte)(30 + 23), (byte)(38 + 42), (byte)(86 + 11), (byte)(48 + 52), (byte)(63 + 37), 105, 110, (byte)(31 + 72)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(22 + 61)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0505\u0529\u0515\u053e\u04fc\u0540\u053a\u0536\u0525\u053c\u04fc\u053d\u0529\u0519\u051b\u0547\u053c\u051a\u0509\u054d\u054a\u0548\u0521\u0523\u0548\u0544\u0536\u052d\u0530\u0535\u0522\u052a\u054c\u052e\u0554\u0517\u052b\u0529\u051e\u0541\u0543\u0525\u0526\u0557\u0568\u053c\u0545\u053f\u0522\u0539\u0526\u055b\u0561\u053d\u0546\u0573\u0534\u0545\u054d\u0576\u0540\u056b\u0576\u054e\u0574\u057c\u0554\u0572\u054d\u0582\u057e\u0552\u053e\u0583\u056e\u055c\u055d\u057e\u0546\u0548\u057a\u0589\u056e\u0567\u0582\u057d\u0567\u0584\u0586\u056b\u0573\u0580\u0595\u056e\u0589\u0559\u0597\u0553\u055d\u0572\u0560\u056c\u056e\u058b\u0573\u05a3\u0576\u056b", (byte)7, 69);
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u00cf\u00f3\u00df\u0108\u00c6\u010a\u0104\u0100\u00ef\u0106\u00c6\u0107\u00f3\u00e3\u00e5\u0111\u0106\u00e4\u00d3\u0117\u0114\u0112\u00eb\u00ed\u0112\u010e\u0100\u00f7\u00fa\u00ff\u00ec\u00f4\u0116\u00f8\u011e\u00e1\u00f5\u00f3\u00e8\u010b\u010d\u00ef\u00f0\u0121\u0132\u0106\u010f\u0109\u00ec\u0103\u00f0\u0125\u012b\u0105\u012e\u0111\u0115\u010c\u011a\u00f8\u010f\u0118\u0119\u012e\u0114\u0101\u00fa\u013b\u0108\u012a\u0106\u014b\u010c\u013a\u011e\u011b\u010b\u010a\u0111\u0115\u0155\u0117\u0116\u0110\u0126\u0151\u015b\u015a\u015c\u012d\u0118\u0137\u011f\u011f\u015e\u0164\u0141\u0147\u011f\u0125\u016b\u0122\u0127\u0143\u0120\u0141\u0169\u0147\u0172\u013f\u0171\u014d\u014e\u0142\u0138\u0134\u0139\u0179\u0140\u0141", (byte)7, 65);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0505\u0529\u0515\u053e\u04fc\u0540\u053a\u0536\u0525\u053c\u04fc\u053d\u0529\u0519\u051b\u0547\u053c\u051a\u0509\u054d\u054a\u0548\u0521\u0523\u0548\u0544\u0536\u052d\u0530\u0535\u0522\u052a\u054c\u052e\u0554\u0517\u052b\u0529\u051e\u0541\u0543\u0525\u0526\u0557\u0568\u053c\u0545\u053f\u0522\u0539\u0526\u055b\u0561\u053d\u0546\u0573\u0534\u0545\u054d\u0576\u0540\u056b\u0576\u054e\u0574\u057c\u0554\u0572\u054d\u0582\u057e\u0552\u053e\u0583\u056e\u055c\u055d\u057e\u0546\u0548\u057a\u0589\u056e\u0567\u0582\u057d\u0567\u0584\u0586\u056b\u0573\u0580\u0595\u056e\u0589\u0559\u0584\u0592\u0557\u059a\u0573\u056a\u0596\u05a4\u058e\u056d\u055d\u056b", (byte)7, 69);
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u00cf\u00f3\u00df\u0108\u00c6\u010a\u0104\u0100\u00ef\u0106\u00c6\u0107\u00f3\u00e3\u00e5\u0111\u0106\u00e4\u00d3\u0117\u0114\u0112\u00eb\u00ed\u0112\u010e\u0100\u00f7\u00fa\u00ff\u00ec\u00f4\u0116\u00f8\u011e\u00e1\u00f5\u00f3\u00e8\u010b\u010d\u00ef\u00f0\u0121\u0132\u0106\u010f\u0109\u00ec\u0103\u00f0\u0125\u012b\u0105\u012e\u0111\u0115\u010c\u011a\u00f8\u010f\u0118\u0119\u012e\u0114\u0101\u00fa\u013b\u0108\u012a\u0106\u014b\u010c\u013a\u011e\u011b\u010b\u010a\u0111\u0115\u0155\u0117\u0116\u0110\u0126\u0151\u015b\u015a\u015c\u012d\u0118\u0137\u011f\u011f\u015e\u0164\u0141\u0147\u011f\u0125\u016b\u0122\u0127\u0143\u0120\u0141\u0169\u016e\u014c\u0148\u014d\u0144\u0176\u014e\u016c\u0169\u0158\u0153\u0140\u0141", (byte)7, 66);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00d1\u0104\u00d3\u00bf\u00fa\u00f7\u00d6\u010a\u00cc\u00eb\u00dc\u00dc\u0108\u00cf\u00cc\u00ef\u00e0\u00d5\u00ea\u00d6\u00e5\u0119\u00e0\u00e1", (byte)7, 66);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u00f0\u00fe\u00d9\u0104\u00fe\u00f9\u00e9\u00e1\u00ca\u00eb\u00d9\u00ea\u00fd\u00fd\u00ca\u0104\u00f6\u0105\u00d7\u00d4\u00f6\u0119\u00e0\u00e1", (byte)7, 65);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x79L;
        l ^= 0x1F57C865369B7868L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(20 + 48), (byte)(61 + 8), (byte)(79 + 4), (byte)(20 + 27), (byte)(58 + 9), (byte)(59 + 7), (byte)(9 + 58), (byte)(11 + 36), 80, (byte)(37 + 38), (byte)(64 + 3), (byte)(70 + 13), (byte)(52 + 1), (byte)(28 + 52), (byte)(90 + 7), (byte)(34 + 66), 100, (byte)(80 + 25), (byte)(98 + 12), (byte)(59 + 44)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(16 + 53), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u0128\u0135\u0134\u00f7\u0137\u0133\u012e\u0137\u0142\u0131\u00fe\u013c\u0140\u0139\u013c\u0142\u0104\u048a\u0491\u049d\u048b\u0480\u0484\u048d\u04a4\u0487\u0491", (byte)35, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = 256 >>> 232 | 256 << -232;
        b = 0 >>> 103 | 0 << -103;
        c = Integer.reverse(0);
        d = Long.reverse(1587678940041207780L);
        e = Long.reverse(-7061644215716937728L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(0);
        h = (32 >>> 37 | 32 << -37) & 0xFFFFFFFF;
        i = Long.reverse(-8644499413344559132L);
        j = 0 >>> 221 | 0 << ~221 + 1;
        k = 0 >>> 180 | 0 << -180;
        l = 2048 >>> 42 | 2048 << -42;
        m = (1024 >>> 41 | 1024 << -41) & 0xFFFFFFFF;
        a = new String[l];
        b = new String[m];
        \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.b();
    }

    public boolean b(Entity entity) {
        if (this.G) {
            try {
                return CitizensAPI.getNPCRegistry().isNPC(entity);
            }
            catch (Throwable throwable) {
                this.G = b;
                if (throwable.getCause() instanceof ClassNotFoundException) {
                    Object[] objectArray = new Object[f];
                    objectArray[\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.g] = throwable.getMessage();
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.c("\u3e80", (int)c, (long)(d ^ e)), objectArray);
                }
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.c("\u3e83", (int)h, (long)i), throwable, new Object[j]);
            }
        }
        return k != 0;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0163\u0185\u0187\u0167\u018b\u01aa\u01a2\u01b8\u01a4\u0173\u01b1\u01a7\u01b5\u01af\u0178\u019d\u01bf\u01be\u01b6\u01bc\u01b6\u018b", (byte)94, 65), \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u019e\u01ab\u01aa\u016d\u01ad\u01a9\u01a4\u01ad\u01b8\u01a7\u0174\u01b2\u01b6\u01af\u01b2\u01b8\u017a\u0500\u0507\u0513\u0501\u04f6\u04fa\u0503\u051a\u04fd\u0507\u0190", (byte)94, 66) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u0509", (byte)94, 68) + methodType.toString(), exception);
        }
    }
}

