/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.types.Identity
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.api.types.Identity;
import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b3;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<Identity> {
    private static int e;
    private static long ae;
    public static final \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0 a;
    private static long z;
    private static int a;
    private static int y;
    private static int ab;
    private static long j;
    private static long ac;
    private static long l;
    private static int aq;
    private static long r;
    private static int v;
    private static int af;
    private static int q;
    private static String[] b;
    private static int an;
    private static int k;
    private static long aj;
    private static long u;
    private static long o;
    private static long h;
    private static int ap;
    private static long ao;
    private static long m;
    private static long aa;
    private static long c;
    private static int n;
    private static long x;
    private static long g;
    private static int ai;
    private static long ah;
    private static long ag;
    private static int al;
    private static int i;
    private static String[] a;
    private static int ak;
    private static int t;
    private static long w;
    private static int b;
    private static int p;
    private static long d;
    private static int f;
    private static long am;
    private static long s;
    private static int ad;

    private static void b() {
        int n;
        c = -2457009663446453969L;
        long l = c ^ 0x4BD3119346A9E979L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(27 + 41), (byte)(49 + 20), (byte)(17 + 66), (byte)(45 + 2), (byte)(27 + 40), 66, (byte)(39 + 28), (byte)(35 + 12), 80, (byte)(7 + 68), (byte)(35 + 32), (byte)(17 + 66), (byte)(7 + 46), (byte)(4 + 76), (byte)(22 + 75), (byte)(12 + 88), (byte)(24 + 76), (byte)(37 + 68), (byte)(96 + 14), (byte)(28 + 75)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(68 + 15)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0105\u014d\u014b\u011e\u0108\u014d\u0127\u0122\u0154\u0128\u014a\u011d", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0558\u0555\u0535\u0541\u0531\u0521\u0556\u0539\u0561\u0543\u053e\u052f", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u047d\u04ac\u0485\u0490\u0470\u048c\u04a0\u0493\u04a0\u04a9\u04aa\u04ba\u04a5\u04b6\u04ad\u0486\u04b6\u04b0\u04c2\u049a\u04b5\u048c\u0489\u048a", (byte)43, 67);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0484\u047a\u049b\u04a4\u046c\u047c\u0475\u046e\u0498\u0471\u04a9\u04ba\u04b4\u04b2\u04b0\u04bb\u0493\u04b6\u04b3\u0497\u048c\u04b2\u0489\u048a", (byte)43, 67);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0105\u014d\u014b\u011e\u0108\u014d\u0127\u0122\u0154\u0128\u014a\u011d", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0106\u011f\u0138\u0119\u0120\u0140\u013d\u012f\u014b\u0134\u0158\u0142\u012d\u0116\u0114\u014e\u0114\u012f\u011c\u0159\u011c\u0161\u0128\u0129", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0535\u0521\u0531\u0556\u0564\u0538\u0521\u0541\u055c\u0560\u0534\u0523\u0539\u053d\u052b\u0561\u056d\u0543\u052b\u055e\u0551\u056d\u0563\u0563\u0551\u056a\u0573\u0536\u056f\u0550\u0546\u057f\u0540\u0574\u055d\u053e\u0541\u055f\u057c\u0572\u0559\u0566\u0546\u057a\u0582\u057e\u0562\u0561\u057c\u0560\u057e\u0586\u057e\u054f\u0586\u0554\u0591\u0575\u0554\u058b\u058b\u058c\u0559\u055b", (byte)43, 70);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[7] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0105\u014d\u014b\u011e\u0108\u014d\u0127\u0122\u0154\u0128\u014a\u011d", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[8] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u04a7\u04a4\u0484\u0490\u0480\u0470\u04a5\u0488\u04b0\u0492\u048d\u047e", (byte)43, 67);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[9] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u011c\u014b\u0124\u012f\u010f\u012b\u013f\u0132\u013f\u0148\u0149\u0159\u0144\u0155\u014c\u0125\u0155\u014f\u0161\u0139\u0154\u012b\u0128\u0129", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[10] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u047d\u04ac\u0485\u0490\u0470\u048c\u04a0\u0493\u04a0\u04a9\u04aa\u04ba\u04a5\u04b6\u04ad\u0486\u04b6\u04b0\u04c2\u049a\u04b5\u048c\u0489\u048a", (byte)43, 68);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[11] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u0535\u052b\u054c\u0555\u051d\u052d\u0526\u051f\u0549\u0522\u055a\u056b\u0565\u0563\u0561\u056c\u0544\u0567\u0564\u0548\u053d\u0563\u053a\u053b", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[12] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0484\u047a\u049b\u04a4\u046c\u047c\u0475\u046e\u0498\u0471\u04a9\u04ba\u04b4\u04b2\u04b0\u04bb\u0493\u04b6\u04b3\u0497\u048c\u04b2\u0489\u048a", (byte)43, 68);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[13] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0518\u0531\u054a\u052b\u0532\u0552\u054f\u0541\u055d\u0546\u056a\u0554\u053f\u0528\u0526\u0560\u0526\u0541\u052e\u056b\u052e\u0573\u053a\u053b", (byte)43, 70);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[14] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0535\u0521\u0531\u0556\u0564\u0538\u0521\u0541\u055c\u0560\u0532\u0544\u0569\u0548\u0547\u0558\u056c\u0568\u0566\u055f\u0566\u0552\u056b\u0544\u0555\u0554\u0559\u0537\u057d\u055a\u057d\u0568\u053f\u0577\u054a\u0557\u0559\u0572\u0538\u0565\u0551\u0577\u0560\u053d\u055a\u057a\u0547\u058e\u054d\u0586\u0552\u058b\u0571\u0583\u055a\u055b", (byte)43, 70);
                    continue block7;
                }
                case 1: {
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0517\u0556\u0541\u0560\u0537\u0566\u053c\u0568\u0569\u0546\u0529\u052f", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0119\u013e\u0151\u0143\u010b\u0109\u0106\u0147\u0134\u0149\u0130\u011d", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u047d\u04ac\u0485\u0490\u0470\u048c\u04a0\u0493\u04a0\u04a9\u04a7\u04ab\u046d\u047b\u04b6\u04bb\u04b8\u04be\u0481\u04b9\u04ac\u04c2\u0489\u048a", (byte)43, 67);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0123\u0119\u013a\u0143\u010b\u011b\u0114\u010d\u0137\u0110\u0147\u010b\u0125\u0130\u014f\u0125\u011b\u0135\u0118\u011b\u0143\u013b\u0128\u0129", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[4] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u052c\u054f\u0554\u0553\u052f\u0541\u051e\u0545\u0541\u055b\u0525\u052f", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0467\u0480\u0499\u047a\u0481\u04a1\u049e\u0490\u04ac\u0495\u04ba\u0475\u048b\u048e\u048a\u04bf\u04bf\u049e\u04ba\u04ba\u04ab\u048c\u0489\u048a", (byte)43, 68);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[6] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0123\u010f\u011f\u0144\u0152\u0126\u010f\u012f\u014a\u014e\u0122\u0111\u0127\u012b\u0119\u014f\u015b\u0131\u0119\u014c\u013f\u015b\u0151\u0151\u013f\u0158\u0161\u0124\u015d\u013e\u0134\u016d\u012e\u0162\u014b\u012c\u012f\u014d\u016a\u0160\u0147\u0154\u0134\u0168\u0170\u016c\u0150\u014f\u016a\u014e\u016c\u0174\u016c\u0184\u016f\u0144\u0178\u0182\u0147\u0149\u0172\u018a\u017c\u014c\u015d\u0145\u0181\u0168\u0150\u0160\u0192\u0173\u0195\u0192\u0186\u015d", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[7] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0118\u012a\u010e\u0131\u0143\u0148\u0130\u012e\u0120\u011f\u0152\u011d", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[8] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0532\u0535\u0531\u053a\u051a\u0536\u0555\u0553\u0543\u0561\u0568\u052f", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u011c\u014b\u0124\u012f\u010f\u012b\u013f\u0132\u013f\u0148\u0149\u0142\u0123\u0146\u0131\u0117\u014e\u014a\u015c\u0113\u012a\u0161\u0128\u0129", (byte)43, 66);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u011c\u014b\u0124\u012f\u010f\u012b\u013f\u0132\u013f\u0148\u0146\u013a\u0146\u0118\u0116\u0116\u015c\u0135\u012a\u0159\u0140\u0161\u0128\u0129", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[11] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0535\u052b\u054c\u0555\u051d\u052d\u0526\u051f\u0549\u0522\u0558\u0526\u054d\u0555\u0547\u055e\u0560\u054a\u0545\u056a\u056c\u0563\u053a\u053b", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[12] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0535\u052b\u054c\u0555\u051d\u052d\u0526\u051f\u0549\u0522\u055b\u0538\u0537\u053d\u053f\u053d\u0527\u054c\u0547\u056b\u0566\u0573\u053a\u053b", (byte)43, 69);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[13] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0106\u011f\u0138\u0119\u0120\u0140\u013d\u012f\u014b\u0134\u0156\u010f\u0119\u0123\u014c\u0149\u011a\u013f\u0119\u012f\u011b\u0151\u0128\u0129", (byte)43, 65);
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[14] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0123\u010f\u011f\u0144\u0152\u0126\u010f\u012f\u014a\u014e\u0120\u0132\u0157\u0136\u0135\u0146\u015a\u0156\u0154\u014d\u0154\u0140\u0159\u0132\u0143\u0142\u0147\u0125\u016b\u0148\u016b\u0156\u012d\u0165\u0138\u0145\u0147\u0160\u0126\u0153\u013f\u0165\u014f\u012b\u0143\u0138\u0176\u0152\u013b\u015c\u013e\u013f\u016b\u015b\u0148\u0149", (byte)43, 66);
                    continue block7;
                }
                case 2: {
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u048a\u047c\u04aa\u0480\u047e\u0480\u04b5\u0476\u0498\u0493\u046f\u0476\u0498\u04b9\u048f\u04b8\u04bc\u04c1\u04b9\u04aa\u048e\u048c\u0489\u048a", (byte)43, 68);
                    continue block7;
                }
                case 4: {
                    \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u047d\u04af\u04b2\u04ae\u04b1\u0484\u04aa\u0494\u0488\u04a7\u04a5\u04a7\u046d\u0473\u04bd\u04b2\u049c\u04b5\u04bf\u049c\u04be\u049c\u0489\u048a", (byte)43, 67);
                }
            }
        }
    }

    @Override
    public JSONObject a(@Nonnull Identity identity) {
        JSONObject jSONObject = new JSONObject();
        if (identity instanceof \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2) {
            UUID uUID;
            \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2 \u03c0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2 = (\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2)identity;
            jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e80", (int)(a & b), (long)d), e);
            jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e83", (int)f, (long)(g ^ h)), (Object)\u03c0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.getName());
            UUID uUID2 = \u03c0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.getMojangId();
            if (uUID2 != null) {
                jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e86", (int)i, (long)j), (Object)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b(uUID2));
            }
            if ((uUID = \u03c0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.getBedrockId()) != null) {
                jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e89", (int)k, (long)(l ^ m)), (Object)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b(uUID));
            }
        } else if (identity instanceof \u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b3) {
            \u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b3 \u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b32 = (\u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b3)identity;
            jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e8c", (int)n, (long)o), p);
            jSONObject.put((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e8f", (int)q, (long)(r ^ s)), (Object)\u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b32.getKnownName());
        } else {
            throw new IllegalArgumentException((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e92", (int)t, (long)u) + identity.getClass().getCanonicalName());
        }
        return jSONObject;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u052d\u054f\u0551\u0531\u0555\u0574\u056c\u0582\u056e\u053d\u057b\u0571\u057f\u0579\u0542\u0567\u0589\u0588\u0580\u0586\u0580\u0555", (byte)73, 69), \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0568\u0575\u0574\u0537\u0577\u0573\u056e\u0577\u0582\u0571\u053e\u057c\u0580\u0579\u057c\u0582\u0544\u08d0\u08b2\u08dc\u08cf\u08e0\u08ae\u08d5\u08de\u08e3\u08e7\u08e3\u08d4\u08e4\u08e3\u055e", (byte)73, 70) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u014b", (byte)73, 65) + methodType.toString(), exception);
        }
    }

    @Override
    public Class<?> a() {
        return Identity.class;
    }

    private static String a(int n, long l) {
        l ^= 0x2CL;
        l ^= 0x4BD3119346A9E979L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(68 + 1), (byte)(28 + 55), (byte)(35 + 12), (byte)(27 + 40), (byte)(2 + 64), (byte)(30 + 37), (byte)(15 + 32), (byte)(52 + 28), (byte)(20 + 55), (byte)(25 + 42), (byte)(82 + 1), (byte)(6 + 47), (byte)(14 + 66), 97, (byte)(51 + 49), (byte)(77 + 23), (byte)(71 + 34), (byte)(79 + 31), (byte)(68 + 35)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(56 + 12), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u017a\u0187\u0186\u0149\u0189\u0185\u0180\u0189\u0194\u0183\u0150\u018e\u0192\u018b\u018e\u0194\u0156\u04e2\u04c4\u04ee\u04e1\u04f2\u04c0\u04e7\u04f0\u04f5\u04f9\u04f5\u04e6\u04f6\u04f5", (byte)76, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 4 | 0 << -4) & 0xFFFFFFFF;
        b = -1 >>> 243 | -1 << ~243 + 1;
        d = Long.reverse(-4571636198445979717L);
        e = 0 >>> 155 | 0 << -155;
        f = 4 >>> 2 | 4 << ~2 + 1;
        g = Long.reverse(-824641308473727045L);
        h = Long.reverse(0x3400000000000000L);
        i = Integer.reverse(0x40000000);
        j = Long.reverse(-4571636198445979717L);
        k = Integer.reverse(-1073741824);
        l = Long.reverse(-824641308473727045L);
        m = Long.reverse(0x3400000000000000L);
        n = (8192 >>> 203 | 8192 << -203) & 0xFFFFFFFF;
        o = Long.reverse(-4571636198445979717L);
        p = (32768 >>> 111 | 32768 << ~111 + 1) & 0xFFFFFFFF;
        q = Integer.reverse(-1610612736);
        r = Long.reverse(-824641308473727045L);
        s = Long.reverse(0x3400000000000000L);
        t = 768 >>> 231 | 768 << ~231 + 1;
        u = Long.reverse(-4571636198445979717L);
        v = Integer.reverse(-536870912);
        w = Long.reverse(-824641308473727045L);
        x = Long.reverse(0x3400000000000000L);
        y = Integer.reverse(0x10000000);
        z = Long.reverse(-824641308473727045L);
        aa = Long.reverse(0x3400000000000000L);
        ab = Integer.reverse(-1879048192);
        ac = Long.reverse(-4571636198445979717L);
        ad = Integer.reverse(0x50000000);
        ae = Long.reverse(-4571636198445979717L);
        af = Integer.reverse(-805306368);
        ag = Long.reverse(-824641308473727045L);
        ah = Long.reverse(0x3400000000000000L);
        ai = (6 >>> 223 | 6 << ~223 + 1) & 0xFFFFFFFF;
        aj = Long.reverse(-4571636198445979717L);
        ak = Integer.reverse(-1342177280);
        al = Integer.reverse(-1);
        am = Long.reverse(-4571636198445979717L);
        an = Integer.reverse(0x70000000);
        ao = Long.reverse(-4571636198445979717L);
        ap = Integer.reverse(-268435456);
        aq = Integer.reverse(-268435456);
        a = new String[ap];
        b = new String[aq];
        \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.b();
        a = new \u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0();
    }

    @Override
    public Identity a(@Nonnull JSONObject jSONObject) {
        int n = jSONObject.getInt((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e80", (int)v, (long)(w ^ x)));
        switch (n) {
            case 0: {
                String string = jSONObject.getString((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e83", (int)y, (long)(z ^ aa)));
                UUID uUID = jSONObject.has((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e86", (int)ab, (long)ac)) ? \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c(jSONObject.getString((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e89", (int)ad, (long)ae))) : null;
                UUID uUID2 = jSONObject.has((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e8c", (int)af, (long)(ag ^ ah))) ? \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c(jSONObject.getString((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e8f", (int)ai, (long)aj))) : null;
                return new \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2(string, uUID, uUID2);
            }
            case 1: {
                String string = jSONObject.getString((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e92", (int)(ak & al), (long)am));
                return new \u03c6\u03bb\u03c6\u03c5\u0394\u03be\u03b8\u03b3(string);
            }
        }
        throw new IllegalArgumentException((String)\u03ba\u039b\u03c4\u03b6\u03c6\u0393\u03b9\u03c1\u03c5\u03c8\u03c3\u03b3\u03c2\u03c0.c("\u3e95", (int)an, (long)ao) + n);
    }
}

