/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7;
import com.nickuc.login.\u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 {
    public final \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7 a;
    public final \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0 a = new \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7(this);
    private final nLoginBukkit u;

    static /* synthetic */ nLoginBukkit a(\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942) {
        return \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942.u;
    }

    @Generated
    public \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394(nLoginBukkit nLoginBukkit2) {
        this.u = nLoginBukkit2;
    }
}

