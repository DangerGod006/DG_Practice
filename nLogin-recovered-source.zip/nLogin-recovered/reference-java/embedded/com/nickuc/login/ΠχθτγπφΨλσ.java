/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.protocol.DefinedPacket
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6;
import com.nickuc.login.\u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8;
import net.md_5.bungee.protocol.DefinedPacket;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class \u03a0\u03c7\u03b8\u03c4\u03b3\u03c0\u03c6\u03a8\u03bb\u03c3
implements \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 {
    final /* synthetic */ \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 a;
    private static int a = Integer.reverse(0);

    \u03a0\u03c7\u03b8\u03c4\u03b3\u03c0\u03c6\u03a8\u03bb\u03c3(\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6) {
        this.a = \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6;
    }

    @Override
    public void sendPacket(Object object, Object ... objectArray) {
        if (\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a(this.a).isConnected()) {
            \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a(this.a).unsafe().sendPacket((DefinedPacket)object);
            Object[] objectArray2 = objectArray;
            int n = objectArray2.length;
            for (int i = a; i < n; ++i) {
                Object object2 = objectArray2[i];
                \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a(this.a).unsafe().sendPacket((DefinedPacket)object2);
            }
        }
    }
}

