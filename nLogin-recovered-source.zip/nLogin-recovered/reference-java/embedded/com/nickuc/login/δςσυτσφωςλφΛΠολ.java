/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.event.Subscribe
 *  com.velocitypowered.api.event.connection.PluginMessageEvent
 *  com.velocitypowered.api.event.connection.PluginMessageEvent$ForwardResult
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.ServerConnection
 *  com.velocitypowered.api.proxy.messages.ChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.ChannelMessageSource
 *  com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login;

import com.nickuc.login.proxy.velocity.nLoginVelocity;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.ChannelMessageSource;
import com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb
implements \u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9 {
    private static long h;
    public static final ChannelIdentifier b;
    private static int j;
    private static int q;
    private static long l;
    private static String[] b;
    private static int r;
    private static int m;
    private static int f;
    private static int k;
    private static int c;
    private static long ad;
    private static long n;
    private static long aa;
    private static long c;
    private static long o;
    private static long s;
    private static int a;
    private static long i;
    private static long e;
    private static int g;
    private final nLoginVelocity d;
    private static long d;
    private static long b;
    private static int u;
    private static long w;
    private static int p;
    private static long ac;
    private static int ab;
    private static int t;
    private static String[] a;
    public static final ChannelIdentifier a;
    private static long x;
    private static int y;
    private static long z;
    private static int v;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00cb\u00ed\u00ef\u00cf\u00f3\u0112\u010a\u0120\u010c\u00db\u0119\u010f\u011d\u0117\u00e0\u0105\u0127\u0126\u011e\u0124\u011e\u00f3", (byte)18, 65), \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0106\u0113\u0112\u00d5\u0115\u0111\u010c\u0115\u0120\u010f\u00dc\u011a\u011e\u0117\u011a\u0120\u00e2\u0468\u0477\u0479\u047c\u047c\u047c\u0480\u0484\u047e\u0478\u0484\u045a\u0460\u0480\u047d\u00fd", (byte)18, 66) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0425", (byte)18, 67) + methodType.toString(), exception);
        }
    }

    @Subscribe
    public void a(PluginMessageEvent pluginMessageEvent) {
        block11: {
            if (!pluginMessageEvent.getResult().isAllowed()) {
                return;
            }
            ChannelMessageSource channelMessageSource = pluginMessageEvent.getSource();
            try {
                ChannelIdentifier channelIdentifier = pluginMessageEvent.getIdentifier();
                if (channelIdentifier.equals((Object)this.d.b()) || channelIdentifier.equals((Object)this.d.a())) {
                    pluginMessageEvent.setResult(PluginMessageEvent.ForwardResult.handled());
                    if (!(channelMessageSource instanceof ServerConnection)) {
                        if (channelMessageSource instanceof Player) {
                            Player player = (Player)channelMessageSource;
                            player.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e80", (int)a, (long)b)));
                            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(player.getUsername() + (String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e83", (int)c, (long)(d ^ e)), new Object[f]);
                        }
                        return;
                    }
                    \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.d.b().a(pluginMessageEvent.getTarget());
                    String string = ((ServerConnection)channelMessageSource).getServer().getServerInfo().getName();
                    byte[] byArray = pluginMessageEvent.getData();
                    this.d.a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string, byArray);
                } else if (channelIdentifier.equals((Object)b) || channelIdentifier.equals((Object)a)) {
                    \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b92 = this.d.a().b().a();
                    if (\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b92 == null) {
                        return;
                    }
                    if (!(channelMessageSource instanceof Player)) {
                        return;
                    }
                    if (\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b92.a().a(this.d.b().a(channelMessageSource), pluginMessageEvent.getData())) {
                        pluginMessageEvent.setResult(PluginMessageEvent.ForwardResult.handled());
                    }
                }
            }
            catch (Throwable throwable) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e86", (int)g, (long)(h ^ i)) + pluginMessageEvent.getClass().getSimpleName() + (String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e89", (int)(j & k), (long)l) + channelMessageSource + (String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e8c", (int)m, (long)(n ^ o)), throwable, new Object[p]);
                pluginMessageEvent.setResult(PluginMessageEvent.ForwardResult.handled());
                if (!(channelMessageSource instanceof Player)) break block11;
                ((Player)channelMessageSource).disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e8f", (int)(q & r), (long)s)));
            }
        }
    }

    private static void b() {
        int n;
        c = 949735208140129877L;
        long l = c ^ 0x61AE553666ABCBC3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), 69, (byte)(28 + 55), (byte)(41 + 6), (byte)(28 + 39), (byte)(11 + 55), (byte)(17 + 50), (byte)(37 + 10), (byte)(36 + 44), (byte)(25 + 50), (byte)(65 + 2), (byte)(13 + 70), (byte)(17 + 36), (byte)(65 + 15), 97, (byte)(49 + 51), (byte)(58 + 42), (byte)(17 + 88), (byte)(23 + 87), (byte)(6 + 97)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(41 + 27), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u01b5\u0171\u018b\u018b\u01b4\u01b1\u019e\u01af\u017a\u0193\u01ae\u01ba\u0190\u0183\u01b2\u01b7\u0190\u01a8\u01b7\u01a6\u01a3\u01c5\u01c9\u01c5\u0186\u018f\u01b1\u019e\u01c1\u0190\u01a4\u01ca\u01a9\u01ac\u01ce\u01b9\u018e\u01ab\u01ba\u01d7\u01b3\u0199\u01ad\u01ae\u01d4\u01c5\u01d9\u01a4\u01d6\u01c2\u01c5\u01bd\u01c8\u01e7\u01e4\u01c5\u01e7\u01de\u01cb\u01ac\u01d4\u01d5\u01c9\u01c8\u01ca\u01ca\u01f1\u01ec\u01fa\u01cd\u01ca\u01be\u01d3\u01f1\u01dd\u01d3\u01c1\u0202\u01f6\u01b9\u01f8\u01c4\u01c4\u01c7\u020c\u020b\u01d2\u01d3", (byte)96, 66);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u018f\u01b7\u0195\u01b4\u01bd\u0175\u0179\u0199\u0196\u01c1\u01b5\u018e\u01a2\u01c0\u01b5\u01a3\u01c3\u019c\u01a0\u0199\u01c3\u0199\u018e\u0189\u01d1\u018d\u01bc\u0190\u01c1\u01be\u01a7\u0196\u01d4\u0196\u0191\u01c6\u01bd\u01d8\u01b6\u0199\u01ad\u01b1\u019e\u01c2\u01ae\u01b2\u01d6\u01ba\u01ba\u01d7\u01bc\u01cc\u01c7\u01a3\u01c3\u01ae\u01ea\u01ba\u01ab\u01b3\u01b2\u01ef\u01d3\u01e4\u01f0\u01f1\u01c9\u01c6\u01c8\u01f9\u01fc\u01ec\u01bd\u01d0\u01d3\u01d0\u01dd\u0205\u0203\u01e3\u01e2\u01e8\u01c3\u01de\u01d6\u020b\u01d2\u01d3", (byte)96, 65);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0568\u0552\u0584\u054a\u0564\u0556\u057a\u058b\u058d\u0588\u0556\u059e\u058a\u056e\u0592\u057b\u0573\u055e\u05a0\u0561\u059c\u05a4\u0580\u056a\u0579\u056c\u056e\u057a\u056d\u05aa\u0584\u059f", (byte)96, 70);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0540\u0518\u0547\u0531\u054d\u0521\u054e\u052f\u050e\u0510\u050e\u0522\u052a\u054e\u055c\u054c\u052c\u051d\u0512\u0539\u0537\u053b\u0528\u0529", (byte)96, 68);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0194\u01a4\u0192\u019c\u01b5\u01b8\u0197\u019c\u0178\u01b4\u0192\u0187", (byte)96, 66);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[5] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0548\u050d\u0525\u0508\u0545\u0533\u0510\u0529\u0545\u0548\u0532\u050f\u053a\u0543\u054f\u051b\u0518\u054c\u0531\u0513\u052a\u055f\u0545\u0531\u053f\u0546\u0527\u0569\u0558\u0536\u055c\u054e\u056c\u0539\u0539\u0570\u053e\u056d\u053e\u0545\u056a\u056f\u0561\u0569\u054b\u0532\u0570\u056b\u0567\u0536\u0536\u0552\u0582\u0575\u0540\u057b\u055f\u0568\u0561\u055c\u057f\u0555\u0577\u0580\u058f\u0582\u0559\u0588\u055b\u0574\u054b\u0590\u0581\u0554\u0592\u0596\u0576\u056e\u0596\u0570\u058f\u0599\u0556\u0592\u056a\u0595\u058d\u0591\u0594\u0592\u0566\u059f\u058a\u059a\u0589\u0577", (byte)96, 67);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[6] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u050a\u050c\u0520\u0541\u053c\u0534\u052f\u0533\u0536\u0542\u0510\u0526\u0531\u050d\u0530\u0526\u0556\u0557\u0529\u0536\u055a\u0551\u0528\u0529", (byte)96, 67);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[7] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u050b\u052f\u051c\u0523\u054d\u0524\u0546\u054b\u0535\u0551\u0528\u051d", (byte)96, 67);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[8] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u01ad\u01b1\u01af\u01b3\u01bb\u019e\u01ae\u01bd\u0188\u018a\u01bc\u0187", (byte)96, 65);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u01b5\u0171\u018b\u018b\u01b4\u01b1\u019e\u01af\u017a\u0193\u01ae\u01ba\u0190\u0183\u01b2\u01b7\u0190\u01a8\u01b7\u01a6\u01a3\u01c5\u01c9\u01c5\u0186\u018f\u01b1\u019e\u01c1\u0190\u01a4\u01ca\u01a9\u01ac\u01ce\u01b9\u018e\u01ab\u01ba\u01d7\u01b3\u0199\u01ad\u01ae\u01d4\u01c5\u01d9\u01a4\u01d6\u01c2\u01c5\u01bd\u01c8\u01e7\u01e4\u01c5\u01e7\u01de\u01cb\u01ac\u01d4\u01d5\u01c9\u01c8\u01ca\u01ca\u01f1\u01ec\u01fa\u01cd\u01ca\u01be\u01d3\u01f1\u01da\u01e1\u01f6\u01e2\u01df\u01fc\u01f3\u01d3\u01d9\u01bd\u0200\u01d5\u01fa\u01e9\u01cc\u01fd\u01e5\u01ec\u01fc\u01eb\u01e4\u01cf", (byte)96, 65);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0525\u054d\u052b\u054a\u0553\u050b\u050f\u052f\u052c\u0557\u054b\u0524\u0538\u0556\u054b\u0539\u0559\u0532\u0536\u052f\u0559\u052f\u0524\u051f\u0567\u0523\u0552\u0526\u0557\u0554\u053d\u052c\u056a\u052c\u0527\u055c\u0553\u056e\u054c\u052f\u0543\u0547\u0534\u0558\u0544\u0548\u056c\u0550\u0550\u056d\u0552\u0562\u055d\u0539\u0559\u0544\u0580\u0550\u0541\u0549\u0548\u0585\u0569\u057a\u0586\u0587\u055f\u055c\u055e\u058f\u0592\u0582\u0553\u0566\u0568\u0569\u0579\u058d\u056b\u058d\u059d\u0579\u057f\u0575\u0558\u057b\u0568\u0569", (byte)96, 68);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u018b\u0175\u01a7\u016d\u0187\u0179\u019d\u01ae\u01b0\u01ab\u0179\u01c1\u01ad\u0191\u01b5\u019e\u0196\u0181\u01c3\u0184\u01bf\u01c7\u0199\u01a8\u018b\u01a0\u01a9\u01af\u01aa\u01a8\u01d2\u01c2\u01d0\u01cd\u01a2\u01b4\u019b\u01a7\u01a9\u01b6\u01b5\u01b9\u01cc\u01a7", (byte)96, 66);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0587\u055f\u058e\u0578\u0594\u0568\u0595\u0576\u0555\u0557\u055e\u0574\u056d\u057e\u0578\u0556\u0561\u055d\u0583\u0595\u057d\u0598\u056f\u0570", (byte)96, 70);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0187\u01ac\u0184\u01b0\u01b3\u01b0\u018e\u018f\u018b\u0178\u01a2\u0187", (byte)96, 65);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0548\u050d\u0525\u0508\u0545\u0533\u0510\u0529\u0545\u0548\u0532\u050f\u053a\u0543\u054f\u051b\u0518\u054c\u0531\u0513\u052a\u055f\u0545\u0531\u053f\u0546\u0527\u0569\u0558\u0536\u055c\u054e\u056c\u0539\u0539\u0570\u053e\u056d\u053e\u0545\u056a\u056f\u0561\u0569\u054b\u0532\u0570\u056b\u0567\u0536\u0536\u0552\u0582\u0575\u0540\u057b\u055f\u0568\u0561\u055c\u057f\u0555\u0577\u0580\u058f\u0582\u0559\u0588\u055b\u0574\u054b\u0590\u0581\u0554\u0592\u0596\u0576\u056e\u0596\u0570\u058f\u0599\u0556\u0592\u056a\u059c\u056f\u0597\u0583\u05a3\u057a\u0584\u0595\u0578\u05a4\u058e\u05a1\u057c\u0581\u059d\u058d\u058c\u05a7\u057d\u05ab\u059f\u0584\u057d", (byte)96, 67);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[6] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0551\u0553\u0567\u0588\u0583\u057b\u0576\u057a\u057d\u0589\u0558\u056c\u0576\u0572\u055b\u055f\u0577\u058e\u0574\u0596\u058a\u05a8\u056f\u0570", (byte)96, 70);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[7] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0550\u0550\u056e\u0556\u0587\u0566\u057a\u0558\u056d\u0591\u057e\u0571\u055a\u05a3\u0577\u056e\u057e\u058f\u0563\u0588\u0584\u0598\u056f\u0570", (byte)96, 69);
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[8] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u01b4\u01b3\u0177\u01bc\u01b6\u017a\u01bb\u019f\u01a0\u019d\u0198\u018e\u01c2\u01c0\u0191\u01b3\u01b6\u01a0\u017c\u01a0\u01c0\u01bb\u0192\u0193", (byte)96, 66);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0546\u052f\u053d\u0548\u052b\u0522\u0542\u052a\u053e\u0550\u0535\u054a\u0548\u052c\u0535\u0516\u0559\u051f\u0512\u053a\u0536\u0557\u0551\u051d\u0554\u0541\u0550\u054a\u052a\u0563\u056d\u0523", (byte)96, 68);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01a4\u01af\u01b5\u01ab\u017c\u0179\u0198\u0192\u01bf\u01bd\u01af\u0175\u01a4\u01af\u0178\u01b3\u01a0\u01b4\u0196\u018b\u01c9\u0195\u0192\u0193", (byte)96, 65);
                }
            }
        }
    }

    @Generated
    public \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb(nLoginVelocity nLoginVelocity2) {
        this.d = nLoginVelocity2;
    }

    private static String a(int n, long l) {
        l ^= 0x23L;
        l ^= 0x61AE553666ABCBC3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(54 + 15), (byte)(22 + 61), (byte)(39 + 8), 67, (byte)(6 + 60), (byte)(64 + 3), (byte)(31 + 16), (byte)(48 + 32), (byte)(27 + 48), (byte)(16 + 51), (byte)(66 + 17), (byte)(46 + 7), (byte)(53 + 27), (byte)(88 + 9), (byte)(70 + 30), (byte)(83 + 17), (byte)(19 + 86), 110, (byte)(39 + 64)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(52 + 16), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u046f\u047c\u047b\u043e\u047e\u047a\u0475\u047e\u0489\u0478\u0445\u0483\u0487\u0480\u0483\u0489\u044b\u07d1\u07e0\u07e2\u07e5\u07e5\u07e5\u07e9\u07ed\u07e7\u07e1\u07ed\u07c3\u07c9\u07e9\u07e6", (byte)29, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(7954478391263261872L);
        c = 524288 >>> 51 | 524288 << -51;
        d = Long.reverse(-6168810040170613584L);
        e = Long.reverse(-4323455642275676160L);
        f = Integer.reverse(0);
        g = Integer.reverse(0x40000000);
        h = Long.reverse(-6168810040170613584L);
        i = Long.reverse(-4323455642275676160L);
        j = (768 >>> 104 | 768 << ~104 + 1) & 0xFFFFFFFF;
        k = Integer.reverse(-1);
        l = Long.reverse(7954478391263261872L);
        m = 65536 >>> 206 | 65536 << ~206 + 1;
        n = Long.reverse(-6168810040170613584L);
        o = Long.reverse(-4323455642275676160L);
        p = 0 >>> 114 | 0 << -114;
        q = Integer.reverse(-1610612736);
        r = (-1 >>> 108 | -1 << ~108 + 1) & 0xFFFFFFFF;
        s = Long.reverse(7954478391263261872L);
        t = Integer.reverse(-1879048192);
        u = Integer.reverse(-1879048192);
        v = (3072 >>> 41 | 3072 << -41) & 0xFFFFFFFF;
        w = Long.reverse(-6168810040170613584L);
        x = Long.reverse(-4323455642275676160L);
        y = Integer.reverse(-536870912);
        z = Long.reverse(-6168810040170613584L);
        aa = Long.reverse(-4323455642275676160L);
        ab = (2048 >>> 104 | 2048 << -104) & 0xFFFFFFFF;
        ac = Long.reverse(-6168810040170613584L);
        ad = Long.reverse(-4323455642275676160L);
        a = new String[t];
        b = new String[u];
        \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.b();
        a = new LegacyChannelIdentifier((String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e80", (int)v, (long)(w ^ x)));
        b = MinecraftChannelIdentifier.create((String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e83", (int)y, (long)(z ^ aa)), (String)\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb.c("\u3e86", (int)ab, (long)(ac ^ ad)));
    }
}

