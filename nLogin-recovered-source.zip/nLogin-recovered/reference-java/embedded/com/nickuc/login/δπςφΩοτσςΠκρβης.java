/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2
implements \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static long k;
    private static int i;
    private static int o;
    private static String[] a;
    private static int b;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 M;
    private static int m;
    private static int r;
    private static int j;
    private static int g;
    private static String[] b;
    private Boolean c;
    private static int a;
    private static long n;
    private static int e;
    private static int l;
    private static int q;
    private static int c;
    private static int h;
    private static long c;
    private static int f;
    private static int d;
    private static int s;
    private static int p;

    private static String a(int n, long l) {
        l ^= 0x5CL;
        l ^= 0xC389CBE1961F0413L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(26 + 43), 83, (byte)(31 + 16), (byte)(45 + 22), (byte)(46 + 20), (byte)(27 + 40), (byte)(37 + 10), (byte)(61 + 19), (byte)(53 + 22), (byte)(54 + 13), (byte)(35 + 48), 53, (byte)(10 + 70), (byte)(55 + 42), (byte)(92 + 8), (byte)(4 + 96), (byte)(102 + 3), (byte)(76 + 34), (byte)(86 + 17)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(67 + 2), (byte)(32 + 51)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0427\u0434\u0433\u03f6\u0436\u0432\u042d\u0436\u0441\u0430\u03fd\u043b\u043f\u0438\u043b\u0441\u0403\u0789\u0796\u0799\u079e\u0782\u0799\u079f\u079f\u079f\u077e\u0799\u07a1\u0793\u0799\u07a5", (byte)5, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public Boolean a() {
        return this.c;
    }

    @Generated
    public \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.M = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(-1879048192);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (0 >>> 223 | 0 << ~223 + 1) & 0xFFFFFFFF;
        e = (0x170000 >>> 80 | 0x170000 << ~80 + 1) & 0xFFFFFFFF;
        f = Integer.reverse(-1073741824);
        g = Integer.reverse(0);
        h = 512 >>> 233 | 512 << ~233 + 1;
        i = (0 >>> 62 | 0 << -62) & 0xFFFFFFFF;
        j = Integer.reverse(-1);
        k = Long.reverse(1423232530128752438L);
        l = Integer.MIN_VALUE >>> 254 | Integer.MIN_VALUE << ~254 + 1;
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Long.reverse(1423232530128752438L);
        o = Integer.reverse(0);
        p = Integer.reverse(Integer.MIN_VALUE);
        q = Integer.reverse(0);
        r = Integer.MIN_VALUE >>> 30 | Integer.MIN_VALUE << ~30 + 1;
        s = Integer.reverse(0x40000000);
        a = new String[r];
        b = new String[s];
        \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b();
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.M;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0545\u0567\u0569\u0549\u056d\u058c\u0584\u059a\u0586\u0555\u0593\u0589\u0597\u0591\u055a\u057f\u05a1\u05a0\u0598\u059e\u0598\u056d", (byte)120, 68), \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08e2\u08ef\u08f2\u08f7\u08db\u08f2\u08f8\u08f8\u08f8\u08d7\u08f2\u08fa\u08ec\u08f2\u08fe\u0577", (byte)120, 68) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056e", (byte)120, 70) + methodType.toString(), exception);
        }
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        if (this.c != null) {
            return this.c;
        }
        int n = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().n();
        this.c = (n != a && n != b ? c : d) != 0;
        return this.c;
    }

    private static void b() {
        int n;
        c = 7850716364567872404L;
        long l = c ^ 0xC389CBE1961F0413L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), (byte)(48 + 21), (byte)(25 + 58), (byte)(18 + 29), (byte)(38 + 29), 66, (byte)(39 + 28), (byte)(11 + 36), (byte)(40 + 40), (byte)(61 + 14), (byte)(48 + 19), (byte)(34 + 49), (byte)(49 + 4), (byte)(32 + 48), (byte)(44 + 53), 100, (byte)(92 + 8), (byte)(45 + 60), (byte)(82 + 28), (byte)(64 + 39)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(22 + 47), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u01aa\u01ad\u01b2\u0194\u01c8\u01bc\u01ac\u019a\u01aa\u01bb\u01b2\u01cb\u019a\u01ac\u01a1\u01a1\u019f\u01d1\u01e2\u01b8\u01e8\u01a6\u01d5\u01ea\u01a6\u01dc\u01e0\u01ca\u01dd\u01c1\u01e0\u01d4\u01d4\u01d8\u01b6\u01c1\u01d5\u01fb\u01b7\u01d3\u01d6\u01d5\u01d5\u01ea\u01ce\u01bc\u01f2\u01c1\u01c5\u01c2\u01c4\u0203\u01d4\u0209\u01d0\u01d1", (byte)111, 65);
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0563\u05a6\u0582\u05a1\u0586\u057e\u05a4\u0566\u057e\u058d\u057a\u05a3\u057d\u05a0\u056c\u058b\u0594\u05ac\u05aa\u0571\u05a2\u05a7\u057e\u057f", (byte)111, 70);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u054f\u0552\u0557\u0539\u056d\u0561\u0551\u053f\u054f\u0560\u0557\u0570\u053f\u0551\u0546\u0546\u0544\u0576\u0587\u055d\u058d\u054b\u057a\u058f\u054b\u0581\u0585\u056f\u0582\u0566\u0585\u0579\u0579\u057d\u055b\u0566\u057a\u05a0\u055c\u0578\u057b\u057a\u057a\u05a0\u0590\u0583\u0586\u0592\u0573\u05a8\u059c\u0589\u0577\u0578\u0575\u0576", (byte)111, 67);
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0195\u01d8\u01b4\u01d3\u01b8\u01b0\u01d6\u0198\u01b0\u01bf\u01ac\u0193\u01e3\u01cb\u01b9\u01d3\u01a1\u01dd\u01e3\u01c9\u01b5\u01a7\u01d8\u01cc\u01c2\u01e3\u01c8\u01c1\u01ae\u01e5\u01e3\u01cb", (byte)111, 65);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0560\u0596\u0575\u0576\u0560\u059a\u0587\u05ac\u0598\u0595\u05ac\u0573", (byte)111, 69);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0594\u056f\u0583\u0586\u0571\u05a8\u059b\u05a8\u0594\u05a2\u0580\u056e\u0588\u056d\u056f\u058d\u0594\u0573\u05ab\u0570\u05b4\u05b7\u05ae\u05ad\u058a\u0598\u059d\u05bb\u0580\u05a2\u05b5\u0598", (byte)111, 69);
                }
            }
        }
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        Object[] objectArray = new Object[f];
        objectArray[\u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.g] = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.s();
        objectArray[\u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.h] = \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.c("\u3e80", (int)(i & j), (long)k);
        objectArray[\u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.l] = \u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.c("\u3e83", (int)m, (long)n);
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().n() != e ? \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.z : \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.A, objectArray);
        this.c = o != 0;
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[p];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03b4\u03c0\u03c2\u03c6\u03a9\u03bf\u03c4\u03c3\u03c2\u03a0\u03ba\u03c1\u03b2\u03b7\u03c2.q] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }
}

