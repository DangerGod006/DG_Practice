/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;

class \u03b8\u03be\u03b2\u0394\u03a0\u03a8\u0393\u03c5 {
    private static int a = 0x40000000 >>> 126 | 0x40000000 << ~126 + 1;
    static final /* synthetic */ int[] r;
    private static int b = 2 >>> 224 | 2 << -224;

    static {
        r = new int[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.values().length];
        try {
            \u03b8\u03be\u03b2\u0394\u03a0\u03a8\u0393\u03c5.r[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03be\u03b2\u0394\u03a0\u03a8\u0393\u03c5.r[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

