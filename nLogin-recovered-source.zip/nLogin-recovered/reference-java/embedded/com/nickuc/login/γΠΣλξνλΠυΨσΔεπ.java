/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;

class \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0 {
    static final /* synthetic */ int[] ad;
    private static int c;
    private static int b;
    private static int a;

    static {
        a = 4096 >>> 140 | 4096 << ~140 + 1;
        b = Integer.reverse(0x40000000);
        c = (24 >>> 35 | 24 << ~35 + 1) & 0xFFFFFFFF;
        ad = new int[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.values().length];
        try {
            \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0.ad[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0.ad[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b3\u03a0\u03a3\u03bb\u03be\u03bd\u03bb\u03a0\u03c5\u03a8\u03c3\u0394\u03b5\u03c0.ad[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.d.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

