/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf
extends \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private static int p;
    private static int l;
    private static int m;
    private static long i;
    private static int h;
    private static int c;
    private static int f;
    private static int u;
    private static String[] b;
    private static String[] a;
    private static int q;
    private static long o;
    private static long s;
    private static long r;
    private static long c;
    private static long j;
    private static int e;
    private static int t;
    private static int n;
    private static int k;
    private static int g;
    private static long d;

    @Override
    public void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        Object[] objectArray = new Object[k];
        objectArray[\u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.l] = \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.c("\u3e83", (int)(m & n), (long)o);
        objectArray[\u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.p] = \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.c("\u3e86", (int)q, (long)(r ^ s));
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, (String)\u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.c("\u3e80", (int)h, (long)(i ^ j)), objectArray);
    }

    static {
        c = Integer.reverse(0);
        d = Long.reverse(8251027879191701250L);
        e = (0 >>> 231 | 0 << -231) & 0xFFFFFFFF;
        f = 524288 >>> 19 | 524288 << ~19 + 1;
        g = Integer.reverse(0);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Long.reverse(-5007569423787038974L);
        j = Long.reverse(-4035225266123964416L);
        k = 0x400000 >>> 149 | 0x400000 << -149;
        l = Integer.reverse(0);
        m = Integer.reverse(0x40000000);
        n = (-1 >>> 172 | -1 << -172) & 0xFFFFFFFF;
        o = Long.reverse(8251027879191701250L);
        p = (0x10000000 >>> 188 | 0x10000000 << ~188 + 1) & 0xFFFFFFFF;
        q = 0x1800000 >>> 183 | 0x1800000 << ~183 + 1;
        r = Long.reverse(-5007569423787038974L);
        s = Long.reverse(-4035225266123964416L);
        t = Integer.reverse(0x20000000);
        u = 131072 >>> 79 | 131072 << ~79 + 1;
        a = new String[t];
        b = new String[u];
        \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b();
    }

    public \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, (String)\u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.c("\u3e80", (int)c, (long)d), null, e != 0, f != 0, new String[g]);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0517\u0539\u053b\u051b\u053f\u055e\u0556\u056c\u0558\u0527\u0565\u055b\u0569\u0563\u052c\u0551\u0573\u0572\u056a\u0570\u056a\u053f", (byte)51, 69), \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0552\u055f\u055e\u0521\u0561\u055d\u0558\u0561\u056c\u055b\u0528\u0566\u056a\u0563\u0566\u056c\u052e\u08bd\u089c\u08b6\u08c2\u08c1\u08c8\u08c4\u08c4\u08d1\u08c4\u08bb\u08c5\u08cb\u0547", (byte)51, 69) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0488", (byte)51, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x13L;
        l ^= 0x4297460978F0392BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(25 + 44), (byte)(35 + 48), (byte)(16 + 31), (byte)(13 + 54), (byte)(40 + 26), (byte)(38 + 29), (byte)(34 + 13), (byte)(13 + 67), (byte)(31 + 44), (byte)(58 + 9), (byte)(5 + 78), 53, (byte)(72 + 8), 97, (byte)(3 + 97), (byte)(47 + 53), (byte)(87 + 18), (byte)(18 + 92), (byte)(22 + 81)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(42 + 27), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0569\u0576\u0575\u0538\u0578\u0574\u056f\u0578\u0583\u0572\u053f\u057d\u0581\u057a\u057d\u0583\u0545\u08d4\u08b3\u08cd\u08d9\u08d8\u08df\u08db\u08db\u08e8\u08db\u08d2\u08dc\u08e2", (byte)74, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = 4676716460852216157L;
        long l = c ^ 0x4297460978F0392BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), 69, (byte)(42 + 41), (byte)(35 + 12), (byte)(65 + 2), (byte)(46 + 20), (byte)(17 + 50), (byte)(9 + 38), (byte)(44 + 36), (byte)(40 + 35), (byte)(64 + 3), (byte)(64 + 19), (byte)(28 + 25), (byte)(44 + 36), (byte)(91 + 6), (byte)(33 + 67), (byte)(43 + 57), 105, (byte)(67 + 43), (byte)(8 + 95)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(58 + 11), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0464\u0466\u045a\u046e\u0452\u0462\u0440\u043d\u0446\u046c\u042e\u043c", (byte)21, 68);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0462\u042c\u0463\u044d\u0442\u045c\u0446\u0433\u044d\u046b\u0477\u0474\u0470\u0459\u0451\u043c\u0475\u046b\u043a\u044c\u044d\u0471\u0475\u046d\u0479\u0477\u0476\u0476\u047f\u0478\u0477\u0449\u0486\u0448\u0462\u047f\u0471\u0493\u0493\u048e\u0464\u0487\u0475\u0486\u0455\u0485\u048a\u048a\u045a\u0468\u046d\u046f\u0458\u048b\u0474\u0463\u04a1\u0493\u045d\u047f\u047a\u0497\u0495\u0462", (byte)21, 68);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u050a\u0546\u0542\u04ff\u0546\u0548\u0549\u0529\u0509\u052c\u0535\u0521\u0556\u0544\u0525\u053a\u0514\u0553\u0534\u052f\u054b\u0527\u0524\u0525", (byte)21, 69);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0520\u053a\u0514\u0536\u053c\u053c\u0531\u053d\u054c\u053f\u051c\u052a\u0531\u052d\u052d\u0543\u054e\u0555\u0515\u0534\u055d\u0527\u0524\u0525", (byte)21, 70);
                    continue block7;
                }
                case 1: {
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0440\u043d\u0459\u046c\u044d\u043a\u046b\u0449\u0433\u0471\u0473\u046b\u0464\u0433\u0449\u0477\u046d\u0435\u046b\u0456\u0450\u0480\u0447\u0448", (byte)21, 68);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u053f\u0509\u0540\u052a\u051f\u0539\u0523\u0510\u052a\u0548\u0554\u0551\u054d\u0536\u052e\u0519\u0552\u0548\u0517\u0529\u052a\u054e\u0552\u054a\u0556\u0554\u0553\u0553\u055c\u0555\u0554\u0526\u0563\u0525\u053f\u055c\u054e\u0570\u0570\u056b\u0541\u0564\u0552\u0563\u0532\u0562\u0567\u0567\u0537\u0545\u054a\u054c\u0535\u055b\u054d\u056f\u055a\u0541\u0565\u057c\u0542\u0587\u0556\u0572", (byte)21, 70);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[2] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u00e2\u011e\u011a\u00d7\u011e\u0120\u0121\u0101\u00e1\u0104\u0115\u010b\u012a\u00f8\u00e8\u0120\u010e\u0107\u00eb\u0107\u0127\u00ff\u00fc\u00fd", (byte)21, 66);
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0520\u053a\u0514\u0536\u053c\u053c\u0531\u053d\u054c\u053f\u051d\u0541\u0515\u0531\u0550\u054c\u053a\u053b\u0556\u0550\u0550\u054d\u0524\u0525", (byte)21, 69);
                    continue block7;
                }
                case 2: {
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u00ec\u0103\u0114\u0121\u00fd\u00e6\u0129\u0120\u0126\u00f5\u0108\u00f1", (byte)21, 66);
                    continue block7;
                }
                case 4: {
                    \u03bd\u039b\u03b4\u03bf\u03bd\u03c3\u03be\u03bd\u03c9\u03bb\u03b1\u03ba\u03bf.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0122\u00e0\u00f4\u00d7\u00e6\u0121\u0103\u00f8\u0127\u0114\u00ff\u00f6\u0100\u0118\u0103\u011d\u010c\u00f0\u010c\u012b\u0134\u010f\u00fc\u00fd", (byte)21, 65);
                }
            }
        }
    }
}

