/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9
implements \u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9,
\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static long i;
    private static String[] a;
    private static int j;
    private static int a;
    private static int h;
    private static long k;
    private static int b;
    private static int f;
    private static int c;
    private static int d;
    private static String[] b;
    private static int e;
    private static long c;
    private static int m;
    private static int g;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 ac;
    private static int l;

    private static void b() {
        int n;
        c = 1192026045490543395L;
        long l = c ^ 0xDFDBA39F1948166CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), (byte)(50 + 19), (byte)(82 + 1), (byte)(12 + 35), (byte)(7 + 60), 66, 67, (byte)(46 + 1), (byte)(63 + 17), (byte)(43 + 32), (byte)(18 + 49), (byte)(60 + 23), (byte)(5 + 48), (byte)(9 + 71), (byte)(80 + 17), (byte)(97 + 3), (byte)(3 + 97), (byte)(37 + 68), (byte)(36 + 74), (byte)(41 + 62)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(2 + 81)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u016d\u012e\u0148\u0167\u0162\u016c\u012c\u0156\u0179\u017e\u016b\u017e\u014b\u017e\u013e\u0140\u0155\u014f\u016e\u0143\u0170\u0161\u014e\u014f", (byte)62, 65);
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u04e5\u04e9\u04df\u04e8\u04c0\u04c6\u04ea\u04af\u04cf\u04df\u04cf\u04b1\u04f5\u04ae\u04e8\u04f5\u04af\u04cb\u04cd\u04d4\u04b5\u04cc\u04d5\u04bd\u04dd\u04f3\u04e0\u04d7\u04f8\u04d9\u0500\u04f4\u04e9\u04bb\u04eb\u04e0\u04c5\u04c3\u04ce\u04de\u0510\u04d9\u04df\u04f2\u0507\u050f\u0507\u04d3\u0502\u0505\u04d5\u04e5\u04e9\u04d4\u04ef\u051b\u0509\u0522\u04d8\u04ff\u04dd\u04fc\u0503\u04dd\u0524\u04f1\u0516\u0515\u0515\u04fb\u04e7\u04e8\u0526\u04fa\u0528\u04f7", (byte)62, 67);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04e1\u04a2\u04bc\u04db\u04d6\u04e0\u04a0\u04ca\u04ed\u04f2\u04de\u04e4\u04d1\u04f1\u04f5\u04c3\u04b4\u04b2\u04d6\u04ce\u04d6\u04d5\u04c2\u04c3", (byte)62, 67);
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u04e5\u04e9\u04df\u04e8\u04c0\u04c6\u04ea\u04af\u04cf\u04df\u04cf\u04b1\u04f5\u04ae\u04e8\u04f5\u04af\u04cb\u04cd\u04d4\u04b5\u04cc\u04d5\u04bd\u04dd\u04f3\u04e0\u04d7\u04f8\u04d9\u0500\u04f4\u04e9\u04bb\u04eb\u04e0\u04c5\u04c3\u04ce\u04de\u0510\u04d9\u04df\u04f2\u0507\u050f\u0507\u04d3\u0502\u0505\u04d5\u04e5\u04e9\u04d4\u04ef\u051b\u0509\u0522\u04d8\u04ff\u04dd\u04fc\u0503\u04dd\u0528\u0513\u051a\u04fd\u051a\u04ff\u04fe\u050f\u050b\u04f0\u0506\u04f7", (byte)62, 67);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0545\u0570\u054a\u056c\u0551\u0553\u0531\u0539\u0555\u0533\u0549\u054f\u0537\u0540\u0582\u056f\u056c\u0559\u053c\u0565\u055c\u0560\u054d\u054e", (byte)62, 69);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u04b5\u04dc\u04ca\u04be\u04c5\u04d6\u04ce\u04a7\u04a2\u04b1\u04e4\u04af\u04c8\u04e1\u04ad\u04e0\u04d6\u04ef\u04ea\u04d0\u04ce\u04ed\u04cf\u04d6\u04b2\u04f5\u04cd\u04fb\u04f1\u04c4\u04db\u04da", (byte)62, 68);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0548\u056a\u056c\u054c\u0570\u058f\u0587\u059d\u0589\u0558\u0596\u058c\u059a\u0594\u055d\u0582\u05a4\u05a3\u059b\u05a1\u059b\u0570", (byte)100, 70), \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0544\u0551\u0550\u0513\u0553\u054f\u054a\u0553\u055e\u054d\u051a\u0558\u055c\u0555\u0558\u055e\u0520\u08b1\u08ab\u088f\u08b8\u08b4\u08a8\u08a1\u08b3\u08a3\u0535", (byte)100, 68) + string + \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u051b", (byte)100, 68) + methodType.toString(), exception);
        }
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.ac;
    }

    static {
        a = 18 >>> 225 | 18 << -225;
        b = 262144 >>> 178 | 262144 << ~178 + 1;
        c = (0 >>> 66 | 0 << -66) & 0xFFFFFFFF;
        d = 0 >>> 86 | 0 << -86;
        e = 4 >>> 130 | 4 << -130;
        f = (0 >>> 58 | 0 << -58) & 0xFFFFFFFF;
        g = Integer.reverse(0);
        h = (-1 >>> 56 | -1 << ~56 + 1) & 0xFFFFFFFF;
        i = Long.reverse(-6423155378309607160L);
        j = (0x1000000 >>> 216 | 0x1000000 << ~216 + 1) & 0xFFFFFFFF;
        k = Long.reverse(-6423155378309607160L);
        l = (0x1000000 >>> 151 | 0x1000000 << -151) & 0xFFFFFFFF;
        m = 524288 >>> 146 | 524288 << ~146 + 1;
        a = new String[l];
        b = new String[m];
        \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.b();
    }

    @Generated
    public \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.ac = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    private static String a(int n, long l) {
        l ^= 0x46L;
        l ^= 0xDFDBA39F1948166CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(52 + 17), (byte)(33 + 50), (byte)(22 + 25), (byte)(13 + 54), 66, 67, (byte)(11 + 36), (byte)(67 + 13), (byte)(36 + 39), (byte)(40 + 27), (byte)(50 + 33), (byte)(19 + 34), (byte)(69 + 11), (byte)(33 + 64), (byte)(98 + 2), (byte)(50 + 50), (byte)(82 + 23), (byte)(47 + 63), (byte)(97 + 6)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(52 + 17), (byte)(62 + 21)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u00fa\u0107\u0106\u00c9\u0109\u0105\u0100\u0109\u0114\u0103\u00d0\u010e\u0112\u010b\u010e\u0114\u00d6\u0467\u0461\u0445\u046e\u046a\u045e\u0457\u0469\u0459", (byte)12, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return (\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().n() == a && \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().q() && this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42).av() ? b : c) != 0;
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.n, string -> {
            if (string.contains((CharSequence)\u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.c("\u3e80", (int)(g & h), (long)i))) {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.c((String)string, (String)\u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.c("\u3e83", (int)j, (long)k));
            } else {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.a((String)string);
            }
        }, new Object[d]);
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[e];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03bf\u03b8\u039b\u03c3\u03be\u03b1\u03a9\u03ba\u03a9.f] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }
}

