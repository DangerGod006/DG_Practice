/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb
extends \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2 {
    private static long m;
    private static int w;
    private static long j;
    private static long y;
    private static int d;
    private static int ab;
    private static int x;
    private static String[] f;
    private static String[] e;
    private static int ae;
    private static long n;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u04bb\u04dd\u04df\u04bf\u04e3\u0502\u04fa\u0510\u04fc\u04cb\u0509\u04ff\u050d\u0507\u04d0\u04f5\u0517\u0516\u050e\u0514\u050e\u04e3", (byte)74, 68), \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0176\u0183\u0182\u0145\u0185\u0181\u017c\u0185\u0190\u017f\u014c\u018a\u018e\u0187\u018a\u0190\u0152\u04db\u04ce\u04e7\u04dc\u04f0\u04f2\u04c5\u04bf\u04e6\u04e6\u04e9\u0169", (byte)74, 65) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u014d", (byte)74, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        j = -2285734396477951092L;
        long l = j ^ 0x3FF62870A4E6D19EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(30 + 38), (byte)(32 + 37), (byte)(30 + 53), (byte)(20 + 27), (byte)(66 + 1), (byte)(65 + 1), 67, (byte)(37 + 10), (byte)(63 + 17), (byte)(58 + 17), (byte)(46 + 21), (byte)(11 + 72), (byte)(9 + 44), (byte)(54 + 26), (byte)(79 + 18), (byte)(70 + 30), (byte)(45 + 55), 105, (byte)(16 + 94), (byte)(39 + 64)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(4 + 65), (byte)(68 + 15)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04c2\u04df\u04be\u04cc\u04c3\u04b2\u04f3\u04b7\u04d0\u04da\u04ce\u04c3", (byte)66, 68);
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0536\u0551\u0565\u057b\u0574\u0556\u0538\u056f\u0575\u053d\u0559\u0546", (byte)66, 70);
                    continue block7;
                }
                case 1: {
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u04e4\u04e7\u04c7\u04e5\u04cc\u04ee\u04e6\u04f8\u04ed\u04d5\u04fa\u04f4\u04c0\u04e9\u04d5\u0501\u0505\u04da\u04dc\u04fc\u04be\u04e1\u04ce\u04cf", (byte)66, 67);
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0155\u013d\u0130\u0135\u0173\u0157\u0172\u013a\u016f\u015b\u0140\u0182\u0178\u0169\u017f\u0188\u018a\u0186\u0187\u016f\u017c\u017f\u0156\u0157", (byte)66, 66);
                    continue block7;
                }
                case 2: {
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0574\u0577\u0535\u0535\u0564\u0578\u0565\u056c\u055f\u056e\u0555\u055b\u057d\u057f\u056d\u057f\u055b\u057f\u0575\u0579\u0582\u058a\u0551\u0552", (byte)66, 70);
                    continue block7;
                }
                case 4: {
                    \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.f[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u012e\u0166\u014f\u016b\u015d\u0151\u0140\u0173\u015f\u0156\u0156\u014b", (byte)66, 66);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0x3FF62870A4E6D19EL;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(13 + 56), (byte)(21 + 62), (byte)(19 + 28), (byte)(58 + 9), (byte)(14 + 52), 67, (byte)(41 + 6), (byte)(5 + 75), (byte)(48 + 27), (byte)(57 + 10), (byte)(12 + 71), (byte)(42 + 11), (byte)(74 + 6), (byte)(25 + 72), (byte)(69 + 31), (byte)(3 + 97), 105, (byte)(84 + 26), (byte)(79 + 24)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(62 + 7), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u04e1\u04ee\u04ed\u04b0\u04f0\u04ec\u04e7\u04f0\u04fb\u04ea\u04b7\u04f5\u04f9\u04f2\u04f5\u04fb\u04bd\u0846\u0839\u0852\u0847\u085b\u085d\u0830\u082a\u0851\u0851\u0854", (byte)67, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }

    static {
        d = Integer.reverse(0);
        m = Long.reverse(3588332049407074823L);
        n = Long.reverse(-1873497444986126336L);
        w = Integer.reverse(Integer.MIN_VALUE);
        x = Integer.reverse(-1);
        y = Long.reverse(-2896851414006439417L);
        ab = 524288 >>> 18 | 524288 << ~18 + 1;
        ae = (2 >>> 160 | 2 << ~160 + 1) & 0xFFFFFFFF;
        e = new String[ab];
        f = new String[ae];
        \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.b();
    }

    public \u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb() {
        super((String)\u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.c("\u3e80", (int)d, (long)(m ^ n)), (String)\u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb.c("\u3e83", (int)(w & x), (long)y));
    }
}

