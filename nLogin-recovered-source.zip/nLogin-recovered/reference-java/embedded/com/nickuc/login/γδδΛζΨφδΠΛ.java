/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.types.Location
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.api.types.Location;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b
implements Location {
    private static long c;
    private static int b;
    private static long n;
    private final String j;
    private static String[] b;
    private static int j;
    private static long t;
    private static long d;
    private final float a;
    private static String[] a;
    private static int o;
    private static int e;
    private final double c;
    private static long i;
    private final float b;
    private static int m;
    private static int v;
    private static long l;
    private static long s;
    private final double b;
    private static int u;
    private static long q;
    private static int p;
    private static long h;
    private final double a;
    private static int a;
    private static int k;
    private static int r;
    private static long f;
    private static int g;

    private static void b() {
        int n;
        c = -28814734584330011L;
        long l = c ^ 0x1D8DF721D176D7C6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(14 + 55), (byte)(3 + 80), (byte)(36 + 11), (byte)(62 + 5), (byte)(56 + 10), (byte)(58 + 9), (byte)(30 + 17), (byte)(4 + 76), (byte)(68 + 7), (byte)(40 + 27), (byte)(16 + 67), (byte)(13 + 40), (byte)(27 + 53), (byte)(59 + 38), (byte)(48 + 52), 100, (byte)(70 + 35), (byte)(26 + 84), (byte)(69 + 34)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(43 + 26), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u00e4\u00dd\u00e2\u00ea\u0100\u00cf\u0112\u00e1\u0101\u00eb\u00f5\u00ed\u0109\u00fc\u00db\u011b\u0112\u00ed\u0121\u00f1\u00d4\u0112\u010d\u0103\u011b\u00e3\u0126\u00f1\u011b\u00f6\u00e3\u00fe", (byte)11, 65);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u053d\u0510\u0543\u0520\u0537\u052d\u0515\u0546\u0545\u0514\u0505\u050f", (byte)11, 70);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u042a\u0407\u042a\u044b\u041f\u0446\u0426\u0422\u0422\u0431\u0439\u041e", (byte)11, 67);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[3] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u00e0\u00da\u00f1\u00f1\u010d\u00d1\u00fd\u0107\u00d2\u00ee\u00d7\u00dd", (byte)11, 65);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u010d\u00fe\u00cc\u00e9\u0101\u00e2\u00e9\u00fd\u00d1\u00e8\u010a\u00dd", (byte)11, 66);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[5] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0109\u00d7\u0111\u00df\u00ee\u010f\u0106\u0106\u00e9\u00d2\u0116\u00d1\u00f1\u00f9\u00e6\u00fe\u00da\u010c\u00ed\u00d8\u00df\u0121\u00e8\u00e9", (byte)11, 65);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[6] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u010e\u00f7\u00fc\u0100\u00ea\u00df\u0104\u0109\u0102\u0109\u010e\u00dd", (byte)11, 65);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u00e4\u00dd\u00e2\u00ea\u0100\u00cf\u0112\u00e1\u0101\u00eb\u00f5\u00ed\u0109\u00fc\u00db\u011b\u0112\u00ed\u0121\u00f1\u00d4\u0112\u0117\u011b\u00e5\u0113\u0117\u00ff\u00e8\u00eb\u0101\u00ec\u0109\u00f8\u00e6\u0106\u00ea\u0101\u00eb\u0127\u00f3\u0117\u0136\u00fd", (byte)11, 65);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u052f\u052a\u0541\u053e\u051f\u0503\u0512\u053a\u0532\u0549\u0526\u050f", (byte)11, 69);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0409\u0438\u043b\u0445\u044c\u0454\u043d\u044d\u0430\u044b\u0452\u0414\u0449\u043c\u040f\u041e\u0427\u0457\u042c\u043f\u0437\u0452\u0429\u042a", (byte)11, 68);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u044f\u040a\u0427\u0444\u044a\u042e\u0454\u0423\u0446\u0416\u044b\u041e", (byte)11, 67);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u052d\u04fa\u04fa\u04ff\u04f6\u053b\u0510\u0514\u0500\u053b\u0515\u053d\u053d\u0524\u0544\u0529\u050a\u0546\u0508\u0541\u0522\u0553\u051a\u051b", (byte)11, 69);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0109\u00d7\u0111\u00df\u00ee\u010f\u0106\u0106\u00e9\u00d2\u0116\u0119\u00f3\u00db\u0107\u00e8\u00dd\u00f5\u00ed\u0117\u0111\u0121\u00e8\u00e9", (byte)11, 66);
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u00de\u00de\u0102\u00d1\u00cd\u0114\u010d\u00f1\u00e9\u00d7\u00e8\u00dd", (byte)11, 66);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u051e\u0539\u0532\u053c\u0532\u0536\u04fe\u0504\u0504\u04ff\u0509\u04fd\u0515\u0504\u0520\u0523\u0538\u0552\u054e\u0521\u0510\u0553\u051a\u051b", (byte)11, 70);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u00e0\u00e7\u010d\u010c\u0109\u00ee\u00df\u0102\u00cd\u00e2\u0114\u00ed\u00cc\u00e4\u0117\u0115\u00fb\u0100\u00fd\u010a\u0113\u00eb\u00e8\u00e9", (byte)11, 66);
                }
            }
        }
    }

    @Generated
    public float getPitch() {
        return this.b;
    }

    @Generated
    public double getY() {
        return this.b;
    }

    @Generated
    public String getWorldName() {
        return this.j;
    }

    @Generated
    public \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b(String string, double d, double d2, double d3, float f, float f2) {
        this.j = string;
        this.a = d;
        this.b = d2;
        this.c = d3;
        this.a = f;
        this.b = f2;
    }

    @Generated
    public String toString() {
        return (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e80", (int)(a & b), (long)d) + this.getWorldName() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e83", (int)e, (long)f) + this.getX() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e86", (int)g, (long)(h ^ i)) + this.getY() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e89", (int)(j & k), (long)l) + this.getZ() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e8c", (int)m, (long)n) + this.getYaw() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e8f", (int)(o & p), (long)q) + this.getPitch() + (String)\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.c("\u3e92", (int)r, (long)(s ^ t));
    }

    static {
        a = 0 >>> 36 | 0 << -36;
        b = Integer.reverse(-1);
        d = Long.reverse(6995131679547693567L);
        e = 0x100000 >>> 212 | 0x100000 << ~212 + 1;
        f = Long.reverse(6995131679547693567L);
        g = (0x100000 >>> 51 | 0x100000 << ~51 + 1) & 0xFFFFFFFF;
        h = Long.reverse(-6407580811506902529L);
        i = Long.reverse(-4179340454199820288L);
        j = Integer.reverse(-1073741824);
        k = (-1 >>> 164 | -1 << -164) & 0xFFFFFFFF;
        l = Long.reverse(6995131679547693567L);
        m = 65536 >>> 174 | 65536 << -174;
        n = Long.reverse(6995131679547693567L);
        o = Integer.reverse(-1610612736);
        p = Integer.reverse(-1);
        q = Long.reverse(6995131679547693567L);
        r = (49152 >>> 173 | 49152 << ~173 + 1) & 0xFFFFFFFF;
        s = Long.reverse(-6407580811506902529L);
        t = Long.reverse(-4179340454199820288L);
        u = 56 >>> 3 | 56 << ~3 + 1;
        v = (112 >>> 228 | 112 << ~228 + 1) & 0xFFFFFFFF;
        a = new String[u];
        b = new String[v];
        \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.b();
    }

    private static String a(int n, long l) {
        l ^= 0x63L;
        l ^= 0x1D8DF721D176D7C6L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(10 + 58), (byte)(56 + 13), (byte)(8 + 75), (byte)(8 + 39), (byte)(4 + 63), (byte)(58 + 8), (byte)(41 + 26), (byte)(44 + 3), (byte)(13 + 67), (byte)(39 + 36), (byte)(4 + 63), (byte)(41 + 42), 53, (byte)(24 + 56), (byte)(33 + 64), (byte)(83 + 17), (byte)(48 + 52), (byte)(25 + 80), (byte)(65 + 45), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(32 + 36), (byte)(36 + 33), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u059c\u05a9\u05a8\u056b\u05ab\u05a7\u05a2\u05ab\u05b6\u05a5\u0572\u05b0\u05b4\u05ad\u05b0\u05b6\u0578\u08fd\u08ff\u0900\u08e8\u0904\u08f7\u0916\u0905\u08f2\u08ee", (byte)125, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public float getYaw() {
        return this.a;
    }

    @Generated
    public double getZ() {
        return this.c;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u00d1\u00f3\u00f5\u00d5\u00f9\u0118\u0110\u0126\u0112\u00e1\u011f\u0115\u0123\u011d\u00e6\u010b\u012d\u012c\u0124\u012a\u0124\u00f9", (byte)21, 66), \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u010c\u0119\u0118\u00db\u011b\u0117\u0112\u011b\u0126\u0115\u00e2\u0120\u0124\u011d\u0120\u0126\u00e8\u046d\u046f\u0470\u0458\u0474\u0467\u0486\u0475\u0462\u045e\u00fe", (byte)21, 66) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u050b", (byte)21, 69) + methodType.toString(), exception);
        }
    }

    @Generated
    public double getX() {
        return this.a;
    }
}

