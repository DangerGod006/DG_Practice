/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;
import com.nickuc.login.\u03c4\u03b7\u03a9\u03bd\u03b2\u03a0\u03b1\u03b5\u03be\u03bb\u03ba\u03c4;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.io.Serializable;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Properties;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1
extends \u03c4\u03b7\u03a9\u03bd\u03b2\u03a0\u03b1\u03b5\u03be\u03bb\u03ba\u03c4 {
    private static int n;
    private static int i;
    private static int b;
    private static int k;
    @Nullable
    private final Object e;
    private static int s;
    private static int v;
    private static int ad;
    private static int ah;
    private static long d;
    private static int ag;
    private static int t;
    private static int e;
    private static int l;
    private static int z;
    private static int m;
    private static long aa;
    private final \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf a;
    private final Constructor<?> c;
    private static int c;
    private static int ae;
    private static int af;
    private final String aA;
    private static int aj;
    private static int a;
    private static int h;
    private static int j;
    private static int al;
    private static int an;
    private static long y;
    private static long r;
    private static int am;
    private static int q;
    private static int w;
    private static long u;
    private static int ai;
    private static long p;
    private static int ac;
    private static long x;
    private static int g;
    private final Properties c;
    private static long ab;
    private static int f;
    private static long o;
    private static String[] b;
    private static int ak;
    private static long c;
    private static String[] a;
    @Nullable
    private final String aB;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u04f3\u0515\u0517\u04f7\u051b\u053a\u0532\u0548\u0534\u0503\u0541\u0537\u0545\u053f\u0508\u052d\u054f\u054e\u0546\u054c\u0546\u051b", (byte)15, 70), \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0100\u010d\u010c\u00cf\u010f\u010b\u0106\u010f\u011a\u0109\u00d6\u0114\u0118\u0111\u0114\u011a\u00dc\u0464\u0472\u044b\u0478\u0479\u046f\u045d\u046e\u0479\u0471\u046b\u0478\u047a\u046f\u047d\u00f7", (byte)15, 65) + string + \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u00d7", (byte)15, 65) + methodType.toString(), exception);
        }
    }

    private \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2, File file, Properties properties, @Nullable String string, @Nullable Object object) {
        Serializable serializable;
        \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6Array = new \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[a];
        \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6Array[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b] = \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf.a(\u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2);
        \u0394\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7 \u03b4\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7 = \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42.a().a(\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6Array);
        try {
            Constructor<?> constructor;
            serializable = \u03b4\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7.loadClass((String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e80", (int)c, (long)d));
            if (\u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2 == \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf.b) {
                Class[] classArray = new Class[e];
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.f] = String.class;
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.g] = Properties.class;
                constructor = ((Class)serializable).getConstructor(classArray);
            } else {
                Class[] classArray = new Class[h];
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.i] = String.class;
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.j] = Properties.class;
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.k] = String.class;
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.l] = Object.class;
                classArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.m] = Boolean.TYPE;
                constructor = ((Class)serializable).getConstructor(classArray);
            }
            this.c = constructor;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException(reflectiveOperationException);
        }
        serializable = file.getParentFile();
        if (!((File)serializable).exists() && !((File)serializable).mkdirs()) {
            throw new RuntimeException((String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e83", (int)n, (long)(o ^ p)) + serializable + (String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e86", (int)q, (long)r));
        }
        String string2 = file.getAbsolutePath();
        if (string2.endsWith((String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e89", (int)(s & t), (long)u))) {
            string2 = string2.substring(v, string2.length() - ((String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e8c", (int)w, (long)(x ^ y))).length());
        }
        this.a = \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2;
        this.aA = (String)\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.c("\u3e8f", (int)z, (long)(aa ^ ab)) + string2;
        this.c = properties;
        this.aB = string;
        this.e = object;
    }

    public static \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1 a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2, File file, Properties properties) {
        return \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2, file, properties, null, null);
    }

    private static void b() {
        int n;
        c = 6216613205731730331L;
        long l = c ^ 0xF213663D2956594AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(44 + 25), (byte)(79 + 4), (byte)(5 + 42), (byte)(11 + 56), (byte)(38 + 28), 67, (byte)(9 + 38), (byte)(56 + 24), (byte)(11 + 64), (byte)(49 + 18), (byte)(12 + 71), (byte)(49 + 4), (byte)(71 + 9), (byte)(47 + 50), (byte)(36 + 64), (byte)(90 + 10), (byte)(33 + 72), (byte)(93 + 17), (byte)(95 + 8)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(56 + 12), (byte)(42 + 27), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0518\u04ef\u0511\u0516\u04f7\u0540\u050d\u04fc\u0518\u0511\u0534\u0548\u0529\u0533\u0519\u0537\u053b\u054e\u0516\u051e\u0518\u053b\u052f\u054d\u0527\u0554\u0543\u0514\u0524\u0551\u0551\u0559\u052c\u055a\u0536\u053f\u0537\u0532\u0557\u0534\u0545\u0544\u0542\u052b", (byte)90, 67);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u053a\u053a\u0533\u051b\u052a\u0540\u051a\u0512\u0539\u0517\u0535\u0534\u0511\u053a\u0514\u0514\u0537\u0540\u053a\u0501\u050d\u0543\u0527\u054e\u0531\u054c\u050d\u0549\u0525\u0523\u0536\u0534\u0555\u0530\u053d\u053c\u054f\u051c\u052c\u0537\u0535\u051e\u053e\u052b", (byte)90, 68);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u055d\u0571\u0590\u058f\u0552\u055d\u054c\u0585\u056a\u0569\u0561\u055e", (byte)90, 69);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[3] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u019b\u01a2\u0164\u016b\u019e\u01a9\u019c\u018b\u0184\u01b2\u018e\u017b", (byte)90, 66);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u052b\u0532\u04f4\u04fb\u052e\u0539\u052c\u051b\u0514\u0542\u051e\u050b", (byte)90, 67);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[5] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u01a2\u017c\u016c\u0179\u018a\u0168\u0182\u01b0\u01aa\u0190\u01a6\u0182\u0184\u0183\u0197\u01b5\u01a9\u01a5\u017d\u01ba\u01b5\u01bf\u0186\u0187", (byte)90, 65);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0518\u04ef\u0511\u0516\u04f7\u0540\u050d\u04fc\u0518\u0511\u0534\u0548\u0529\u0533\u0519\u0537\u053b\u054e\u0516\u051e\u0518\u053b\u052f\u054d\u0527\u0554\u0543\u0514\u0524\u0551\u0551\u0559\u052d\u052b\u0515\u0551\u0541\u0533\u0539\u0536\u054e\u0563\u0542\u052b", (byte)90, 68);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u01aa\u01aa\u01a3\u018b\u019a\u01b0\u018a\u0182\u01a9\u0187\u01a5\u01a4\u0181\u01aa\u0184\u0184\u01a7\u01b0\u01aa\u0171\u017d\u01b3\u0197\u01be\u01a1\u01bc\u017d\u01b9\u0195\u0193\u01a6\u01a4\u01ad\u018c\u01c2\u01cf\u01bc\u018f\u01af\u01a6\u01ca\u01a6\u0195\u019b", (byte)90, 65);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u017f\u0180\u0180\u01ad\u017a\u01ae\u01a6\u019b\u019e\u018c\u017e\u017b", (byte)90, 65);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u01a6\u019d\u018e\u0165\u0182\u0180\u016b\u017f\u019e\u0182\u0173\u0197\u01b4\u018a\u018e\u0178\u0194\u0194\u018f\u01a8\u01b8\u01bf\u0186\u0187", (byte)90, 65);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0504\u04f4\u053f\u0517\u050a\u0512\u0520\u0519\u04fb\u04f7\u04fd\u0518\u051f\u0535\u0523\u053a\u053b\u0547\u0509\u0547\u053d\u054f\u0516\u0517", (byte)90, 67);
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u01a2\u017c\u016c\u0179\u018a\u0168\u0182\u01b0\u01aa\u0190\u01a7\u017f\u01b7\u0181\u018a\u018b\u0177\u0196\u01b7\u017d\u019e\u0199\u0186\u0187", (byte)90, 66);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04f8\u0532\u0513\u04f5\u04fb\u0510\u051d\u04f9\u0500\u052e\u051c\u0531\u0522\u0546\u0548\u0502\u0507\u0542\u0543\u054e\u0529\u0545\u0524\u054d\u0526\u0544\u054c\u0524\u0529\u0555\u0559\u054e", (byte)90, 67);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0169\u0198\u019c\u01a8\u0191\u01aa\u018e\u01a4\u01a8\u0190\u01b6\u017f\u01ad\u0190\u01ac\u01b4\u0177\u01bb\u019f\u01b3\u01b8\u0199\u0186\u0187", (byte)90, 65);
                }
            }
        }
    }

    @Override
    public \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 a() {
        return \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.g;
    }

    private static String a(int n, long l) {
        l ^= 0x4AL;
        l ^= 0xF213663D2956594AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(26 + 43), (byte)(65 + 18), (byte)(35 + 12), (byte)(49 + 18), (byte)(50 + 16), (byte)(6 + 61), (byte)(31 + 16), 80, (byte)(50 + 25), 67, (byte)(80 + 3), (byte)(40 + 13), (byte)(62 + 18), (byte)(10 + 87), (byte)(65 + 35), (byte)(9 + 91), (byte)(88 + 17), (byte)(88 + 22), (byte)(46 + 57)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(9 + 60), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0520\u052d\u052c\u04ef\u052f\u052b\u0526\u052f\u053a\u0529\u04f6\u0534\u0538\u0531\u0534\u053a\u04fc\u0884\u0892\u086b\u0898\u0899\u088f\u087d\u088e\u0899\u0891\u088b\u0898\u089a\u088f\u089d", (byte)88, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    protected Connection c() {
        try {
            Object obj;
            if (this.a.compareTo(\u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf.c) >= 0) {
                Object[] objectArray = new Object[ac];
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.ad] = this.aA;
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.ae] = this.c;
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.af] = this.aB;
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.ag] = this.e;
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.ah] = ai != 0;
                obj = this.c.newInstance(objectArray);
            } else {
                Object[] objectArray = new Object[aj];
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.ak] = this.aA;
                objectArray[\u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.al] = this.c;
                obj = this.c.newInstance(objectArray);
            }
            Object obj2 = obj;
            return (Connection)obj2;
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            if (reflectiveOperationException.getCause() instanceof SQLException) {
                throw (SQLException)reflectiveOperationException.getCause();
            }
            throw new RuntimeException(reflectiveOperationException);
        }
    }

    static {
        a = (0x100000 >>> 244 | 0x100000 << ~244 + 1) & 0xFFFFFFFF;
        b = (0 >>> 129 | 0 << ~129 + 1) & 0xFFFFFFFF;
        c = (0 >>> 162 | 0 << ~162 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-8374965154980584854L);
        e = (4096 >>> 203 | 4096 << ~203 + 1) & 0xFFFFFFFF;
        f = Integer.reverse(0);
        g = Integer.reverse(Integer.MIN_VALUE);
        h = (2560 >>> 169 | 2560 << ~169 + 1) & 0xFFFFFFFF;
        i = 0 >>> 163 | 0 << -163;
        j = (0x2000000 >>> 25 | 0x2000000 << ~25 + 1) & 0xFFFFFFFF;
        k = 8192 >>> 108 | 8192 << -108;
        l = (6 >>> 33 | 6 << -33) & 0xFFFFFFFF;
        m = Integer.reverse(0x20000000);
        n = (524288 >>> 83 | 524288 << ~83 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-2754472820022205846L);
        p = Long.reverse(0x5200000000000000L);
        q = Integer.reverse(0x40000000);
        r = Long.reverse(-8374965154980584854L);
        s = (0x180000 >>> 51 | 0x180000 << -51) & 0xFFFFFFFF;
        t = Integer.reverse(-1);
        u = Long.reverse(-8374965154980584854L);
        v = Integer.reverse(0);
        w = Integer.reverse(0x20000000);
        x = Long.reverse(-2754472820022205846L);
        y = Long.reverse(0x5200000000000000L);
        z = Integer.reverse(-1610612736);
        aa = Long.reverse(-2754472820022205846L);
        ab = Long.reverse(0x5200000000000000L);
        ac = 80 >>> 196 | 80 << ~196 + 1;
        ad = Integer.reverse(0);
        ae = 2048 >>> 203 | 2048 << ~203 + 1;
        af = Integer.reverse(0x40000000);
        ag = 0x6000000 >>> 25 | 0x6000000 << ~25 + 1;
        ah = Integer.reverse(0x20000000);
        ai = 0 >>> 183 | 0 << -183;
        aj = 512 >>> 40 | 512 << -40;
        ak = Integer.reverse(0);
        al = Integer.reverse(Integer.MIN_VALUE);
        am = (786432 >>> 81 | 786432 << -81) & 0xFFFFFFFF;
        an = Integer.reverse(0x60000000);
        a = new String[am];
        b = new String[an];
        \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1.b();
    }

    public static \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1 a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2, File file, Properties properties, @Nullable String string, @Nullable Object object) {
        return new \u03b6\u03c3\u039b\u03c7\u03c7\u03bc\u03a9\u03b9\u03c3\u03ba\u03b3\u03bf\u03c0\u03b4\u03c1(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03c7\u03ba\u03b9\u039b\u03c6\u0393\u03ba\u03ba\u03c1\u03bb\u03b8\u03bb\u03c8\u03bf2, file, properties, string, object);
    }
}

