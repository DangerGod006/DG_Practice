/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.AccountType
 *  com.nickuc.login.api.types.AccountDataImpl
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.AccountType;
import com.nickuc.login.api.types.AccountDataImpl;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;

public class \u039b\u03a3\u03b2\u03b2\u03c5\u03c8\u0394\u03bc\u03ba\u03a3\u03b6\u03a3\u03c7\u03a6\u03c4 {
    public static AccountDataImpl from(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92) {
        return new AccountDataImpl(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a(), AccountType.convert((Enum)\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a()), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.i(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.getMojangId(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.getBedrockId(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.j(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.k(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.b(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.c(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a().l(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a().m(), \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a().a());
    }
}

