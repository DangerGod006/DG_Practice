/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b1\u03a6\u03b1\u03bf\u0393\u03b7\u03bd\u03c4\u03c3\u03b8\u03a9\u03b1\u03bb\u039b;
import com.nickuc.login.\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c3\u0393\u03c1\u03bc\u03c7\u03c1\u039b\u03b3\u03b4\u039b\u03a6\u03ba\u03c7\u03be;
import com.nickuc.login.\u03c4\u03b1\u03b8\u0394\u0393\u03b3\u03a9\u03a0;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u03a3\u03c4\u03b2\u03b4\u03c5\u039b\u03c9\u03c5\u03c6\u03c8\u03b1\u03b7\u03b8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6
implements \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static int y;
    private static int z;
    private static int v;
    private static int c;
    private static int b;
    private static long e;
    private static String[] a;
    private static int ac;
    private static int aa;
    private static int m;
    private static int ak;
    private static int ag;
    private static int r;
    private static int u;
    private static int g;
    private static long af;
    private static int w;
    private static long aj;
    private static int l;
    private static int ab;
    private static int n;
    private static long j;
    private static long ae;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 O;
    private static int ah;
    private static int o;
    private static int t;
    private static int i;
    private static String[] b;
    private static int a;
    private static int ai;
    private static long p;
    private static long d;
    private static int s;
    private static int x;
    private static int al;
    private static int f;
    private static int h;
    private static long c;
    private static long k;
    private static int ad;
    private static long q;

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array;
        Object object;
        \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c0 \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a();
        String string = \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02.M();
        String string2 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.s();
        boolean bl = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a().ac();
        if (!string2.equals(string)) {
            Object[] objectArray = new Object[l];
            objectArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.m] = string2;
            objectArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.n] = string;
            object = String.format((String)\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.c("\u3e80", (int)i, (long)(j ^ k)), objectArray);
        } else {
            object = \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.c("\u3e83", (int)o, (long)(p ^ q));
        }
        Object object2 = object;
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92 = \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02.b();
        if (\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92 == null) {
            \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92 = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.c;
        }
        String string3 = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a()).a(\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92 == \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b ? \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.a : \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.b, new Object[r]);
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b1\u03a6\u03b1\u03bf\u0393\u03b7\u03bd\u03c4\u03c3\u03b8\u03a9\u03b1\u03bb\u039b.q, new Object[s]);
        Object[] objectArray = new Object[t];
        objectArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.u] = object2;
        objectArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.v] = string3;
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, bl ? \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.y : \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.x, objectArray);
        if (bl) {
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[w];
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.x] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a;
            \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array = \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
        } else {
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[y];
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.z] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b;
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.aa] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c;
            \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array = \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
        }
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array;
    }

    static {
        a = 65536 >>> 80 | 65536 << ~80 + 1;
        b = Integer.reverse(0);
        c = (0 >>> 11 | 0 << ~11 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-6137281593557964876L);
        e = Long.reverse(-864691128455135232L);
        f = 0x800000 >>> 87 | 0x800000 << -87;
        g = 0x40000000 >>> 158 | 0x40000000 << ~158 + 1;
        h = Integer.reverse(0);
        i = 0x2000000 >>> 185 | 0x2000000 << -185;
        j = Long.reverse(-6137281593557964876L);
        k = Long.reverse(-864691128455135232L);
        l = Integer.reverse(0x40000000);
        m = (0 >>> 214 | 0 << ~214 + 1) & 0xFFFFFFFF;
        n = 16 >>> 4 | 16 << -4;
        o = (0x4000000 >>> 57 | 0x4000000 << -57) & 0xFFFFFFFF;
        p = Long.reverse(-6137281593557964876L);
        q = Long.reverse(-864691128455135232L);
        r = (0 >>> 235 | 0 << ~235 + 1) & 0xFFFFFFFF;
        s = (0 >>> 113 | 0 << ~113 + 1) & 0xFFFFFFFF;
        t = Integer.reverse(0x40000000);
        u = 0 >>> 187 | 0 << -187;
        v = 16 >>> 68 | 16 << ~68 + 1;
        w = (262144 >>> 50 | 262144 << ~50 + 1) & 0xFFFFFFFF;
        x = Integer.reverse(0);
        y = Integer.reverse(0x40000000);
        z = Integer.reverse(0);
        aa = Integer.reverse(Integer.MIN_VALUE);
        ab = 2 >>> 32 | 2 << ~32 + 1;
        ac = (0 >>> 210 | 0 << ~210 + 1) & 0xFFFFFFFF;
        ad = (192 >>> 134 | 192 << -134) & 0xFFFFFFFF;
        ae = Long.reverse(-6137281593557964876L);
        af = Long.reverse(-864691128455135232L);
        ag = Integer.reverse(Integer.MIN_VALUE);
        ah = (1 >>> 158 | 1 << ~158 + 1) & 0xFFFFFFFF;
        ai = (-1 >>> 6 | -1 << -6) & 0xFFFFFFFF;
        aj = Long.reverse(6833085333269063604L);
        ak = Integer.reverse(-1610612736);
        al = Integer.reverse(-1610612736);
        a = new String[ak];
        b = new String[al];
        \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b();
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        \u03c3\u0393\u03c1\u03bc\u03c7\u03c1\u039b\u03b3\u03b4\u039b\u03a6\u03ba\u03c7\u03be \u03c3\u0393\u03c1\u03bc\u03c7\u03c1\u039b\u03b3\u03b4\u039b\u03a6\u03ba\u03c7\u03be2 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a();
        \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c0 \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02 = \u03c3\u0393\u03c1\u03bc\u03c7\u03c1\u039b\u03b3\u03b4\u039b\u03a6\u03ba\u03c7\u03be2.a();
        String string = \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02.M();
        \u03c4\u03b1\u03b8\u0394\u0393\u03b3\u03a9\u03a0 \u03c4\u03b1\u03b8\u0394\u0393\u03b3\u03a9\u03a02 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a();
        if (string == null) {
            \u03c4\u03b1\u03b8\u0394\u0393\u03b3\u03a9\u03a02.e(a != 0);
            return b != 0;
        }
        return (!\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a().a((String)\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.c("\u3e80", (int)c, (long)(d ^ e)), f != 0) && (\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a().ac() || \u03b1\u0393\u03b1\u03c3\u03a3\u03be\u03b7\u039b\u03c0\u03c02.ad() && !\u03c4\u03b1\u03b8\u0394\u0393\u03b3\u03a9\u03a02.ah()) ? g : h) != 0;
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.O;
    }

    private static void b() {
        int n;
        c = 3307039133716695893L;
        long l = c ^ 0xDE8D62AEFAF8315DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(46 + 22), 69, (byte)(8 + 75), (byte)(22 + 25), (byte)(39 + 28), (byte)(2 + 64), (byte)(11 + 56), (byte)(31 + 16), (byte)(58 + 22), (byte)(5 + 70), (byte)(49 + 18), (byte)(72 + 11), (byte)(17 + 36), (byte)(12 + 68), (byte)(24 + 73), 100, (byte)(81 + 19), (byte)(93 + 12), (byte)(48 + 62), (byte)(38 + 65)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u017e\u0162\u013b\u0159\u0177\u014d\u0184\u0178\u0168\u0175\u0181\u0174\u016a\u017f\u0145\u016d\u0148\u015c\u018b\u0150\u0167\u0183\u015a\u015b", (byte)68, 65);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0169\u014c\u0173\u014f\u017f\u016d\u013e\u017e\u015e\u017d\u0148\u0162\u018b\u013f\u014b\u0177\u0149\u018f\u016a\u0174\u0162\u0192\u0184\u016c\u018c\u0188\u019a\u0157\u0194\u019d\u019e\u0176", (byte)68, 65);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u04b5\u04d5\u04f0\u04dd\u04b7\u04e7\u04cd\u04c0\u04e2\u04f5\u04d0\u04c9", (byte)68, 67);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[3] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0169\u0137\u0176\u014d\u0144\u0171\u0178\u0174\u015e\u0172\u0141\u014f", (byte)68, 65);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0558\u0568\u0545\u0536\u0552\u0557\u0553\u054c\u0560\u056e\u0542\u0548", (byte)68, 70);
                    continue block7;
                }
                case 1: {
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u017e\u0162\u013b\u0159\u0177\u014d\u0184\u0178\u0168\u0175\u0180\u0164\u0187\u016e\u018b\u015e\u0149\u017c\u014b\u0184\u0182\u0183\u015a\u015b", (byte)68, 65);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u04e3\u04c6\u04ed\u04c9\u04f9\u04e7\u04b8\u04f8\u04d8\u04f7\u04c2\u04dc\u0505\u04b9\u04c5\u04f1\u04c3\u0509\u04e4\u04ee\u04dc\u04ff\u04c9\u04ec\u04ef\u0509\u0508\u04e1\u0508\u04e4\u050f\u04f8\u04f2\u0517\u0509\u051b\u04d5\u04dd\u04eb\u051e\u04d9\u04fc\u04f8\u04e9", (byte)68, 67);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u04b2\u04ed\u04ed\u04f7\u04d2\u04fb\u04d2\u04e1\u04f5\u04bc\u04d0\u04c9", (byte)68, 68);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0538\u0567\u0563\u055a\u054e\u0577\u054f\u055e\u057b\u056a\u055e\u0553\u054d\u0584\u0567\u0558\u058a\u0564\u058a\u056b\u058e\u0556\u0553\u0554", (byte)68, 69);
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[4] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u016a\u0157\u0163\u0161\u013e\u015a\u0144\u0153\u0143\u0186\u0166\u0180\u0168\u0181\u0168\u015d\u0168\u017a\u0193\u0187\u017d\u0183\u015a\u015b", (byte)68, 66);
                    continue block7;
                }
                case 2: {
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0571\u0576\u0568\u0545\u0556\u0550\u053c\u0548\u0552\u057f\u0579\u055f\u0576\u0571\u0558\u0548\u056a\u0546\u057e\u0565\u0568\u0556\u0553\u0554", (byte)68, 70);
                    continue block7;
                }
                case 4: {
                    \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u014d\u0153\u0160\u0176\u014c\u0171\u0138\u017b\u0155\u0152\u0149\u0184\u0169\u0155\u015c\u0183\u0179\u017c\u014d\u015e\u0152\u015d\u015a\u015b", (byte)68, 66);
                }
            }
        }
    }

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72) {
        switch (\u03c8\u03a3\u03c4\u03b2\u03b4\u03c5\u039b\u03c9\u03c5\u03c6\u03c8\u03b1\u03b7\u03b8.u[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72.ordinal()]) {
            case 1: 
            case 2: {
                String[] stringArray = new String[ab];
                stringArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.ac] = \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.c("\u3e80", (int)ad, (long)(ae ^ af));
                stringArray[\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.ag] = \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.c("\u3e83", (int)(ah & ai), (long)aj);
                \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.b.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray);
            }
            case 3: {
                \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4.super.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72);
            }
        }
    }

    @Generated
    public \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.O = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0410\u0432\u0434\u0414\u0438\u0457\u044f\u0465\u0451\u0420\u045e\u0454\u0462\u045c\u0425\u044a\u046c\u046b\u0463\u0469\u0463\u0438", (byte)17, 67), \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0530\u053d\u053c\u04ff\u053f\u053b\u0536\u053f\u054a\u0539\u0506\u0544\u0548\u0541\u0544\u054a\u050c\u08a0\u08a4\u0883\u089c\u08a4\u0889\u08aa\u08ab\u0520", (byte)17, 70) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0507", (byte)17, 70) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x2FL;
        l ^= 0xDE8D62AEFAF8315DL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(53 + 16), (byte)(57 + 26), (byte)(33 + 14), (byte)(26 + 41), (byte)(24 + 42), (byte)(31 + 36), 47, (byte)(56 + 24), (byte)(68 + 7), (byte)(15 + 52), 83, (byte)(33 + 20), (byte)(48 + 32), (byte)(62 + 35), (byte)(72 + 28), (byte)(74 + 26), (byte)(31 + 74), (byte)(88 + 22), (byte)(4 + 99)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(50 + 33)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0556\u0563\u0562\u0525\u0565\u0561\u055c\u0565\u0570\u055f\u052c\u056a\u056e\u0567\u056a\u0570\u0532\u08c6\u08ca\u08a9\u08c2\u08ca\u08af\u08d0\u08d1", (byte)55, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c2\u03c5\u03a3\u03bb\u03c2\u03a6\u03c6\u03c6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

