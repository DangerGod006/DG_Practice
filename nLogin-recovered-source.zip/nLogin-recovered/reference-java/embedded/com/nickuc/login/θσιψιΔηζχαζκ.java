/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;

class \u03b8\u03c3\u03b9\u03c8\u03b9\u0394\u03b7\u03b6\u03c7\u03b1\u03b6\u03ba {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] p;
    private static int c;
    private static int b;

    static {
        b = Integer.reverse(0x40000000);
        c = 6 >>> 97 | 6 << ~97 + 1;
        p = new int[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.values().length];
        try {
            \u03b8\u03c3\u03b9\u03c8\u03b9\u0394\u03b7\u03b6\u03c7\u03b1\u03b6\u03ba.p[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.d.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c3\u03b9\u03c8\u03b9\u0394\u03b7\u03b6\u03c7\u03b1\u03b6\u03ba.p[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c3\u03b9\u03c8\u03b9\u0394\u03b7\u03b6\u03c7\u03b1\u03b6\u03ba.p[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

