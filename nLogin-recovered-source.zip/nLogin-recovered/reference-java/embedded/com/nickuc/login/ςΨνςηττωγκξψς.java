/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.manager.server.ServerVersion
 *  io.netty.channel.Channel
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.manager.server.ServerVersion;
import com.nickuc.login.\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394;
import com.nickuc.login.\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4;
import io.netty.channel.Channel;

public class \u03c2\u03a8\u03bd\u03c2\u03b7\u03c4\u03c4\u03c9\u03b3\u03ba\u03be\u03c8\u03c2
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private static int a = Integer.reverse(0);
    final /* synthetic */ \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 c;

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        if (\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a() != \u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.c) {
            return;
        }
        if (packetReceiveEvent.getServerVersion().isOlderThan(ServerVersion.V_1_21_6)) {
            return;
        }
        Channel channel = (Channel)packetReceiveEvent.getChannel();
        channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).set((Object)new \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4(null, (byte)a, null));
    }

    public \u03c2\u03a8\u03bd\u03c2\u03b7\u03c4\u03c4\u03c9\u03b3\u03ba\u03be\u03c8\u03c2(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82) {
        this.c = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82;
    }
}

