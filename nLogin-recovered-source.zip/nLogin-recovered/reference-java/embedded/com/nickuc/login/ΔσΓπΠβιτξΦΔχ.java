/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7
extends \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8 {
    private static int ab;
    private static long ah;
    private static String[] c;
    private static long m;
    private static int af;
    private static long w;
    private static long ag;
    private static int r;
    private static int x;
    private static long i;
    private static int ai;
    private static int ak;
    private static int an;
    private static int ao;
    private static int k;
    private static int v;
    private static int c;
    private static int ac;
    private static int z;
    private static int ae;
    private static long n;
    private static int ad;
    private static int aj;
    private static long j;
    private static long aa;
    private static String[] d;
    private static long t;
    private static long f;
    private static long s;
    private static int u;
    private static long am;
    private static int y;
    private static int al;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0508\u052a\u052c\u050c\u0530\u054f\u0547\u055d\u0549\u0518\u0556\u054c\u055a\u0554\u051d\u0542\u0564\u0563\u055b\u0561\u055b\u0530", (byte)36, 69), \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0543\u0550\u054f\u0512\u0552\u054e\u0549\u0552\u055d\u054c\u0519\u0557\u055b\u0554\u0557\u055d\u051f\u0885\u08b5\u0886\u08b4\u0895\u08a8\u08b0\u08bc\u08b7\u08a0\u088f\u08c3\u0537", (byte)36, 69) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0101", (byte)36, 65) + methodType.toString(), exception);
        }
    }

    @Override
    public String w(String string) {
        return (String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e80", (int)k, (long)(m ^ n)) + super.w(string);
    }

    private static void b() {
        int n;
        f = 7144940401801774714L;
        long l = f ^ 0x5D004E242C6B7432L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(47 + 22), (byte)(48 + 35), (byte)(24 + 23), (byte)(51 + 16), (byte)(22 + 44), 67, 47, (byte)(54 + 26), (byte)(15 + 60), (byte)(61 + 6), (byte)(62 + 21), (byte)(51 + 2), (byte)(53 + 27), (byte)(11 + 86), (byte)(65 + 35), (byte)(57 + 43), (byte)(84 + 21), (byte)(58 + 52), (byte)(35 + 68)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(3 + 65), 69, (byte)(17 + 66)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0479\u0478\u048d\u04b2\u04a5\u0485\u04b6\u04aa\u04ae\u04b5\u04ab\u047e", (byte)43, 67);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u0109\u011f\u0122\u013a\u0145\u0125\u0144\u0141\u0127\u0124\u0146\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u04a5\u0482\u0480\u0472\u048a\u047f\u047e\u0483\u048a\u04b8\u048d\u047e", (byte)43, 67);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[3] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0144\u0121\u011f\u0111\u0129\u011e\u011d\u0122\u0129\u0157\u012c\u011d", (byte)43, 65);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u010a\u014e\u014b\u011d\u0124\u0132\u0122\u0133\u0144\u0114\u014e\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0118\u0117\u012c\u0151\u0144\u0124\u0155\u0149\u014d\u0154\u014a\u011d", (byte)43, 65);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0528\u0542\u051e\u0557\u055b\u0538\u0518\u0560\u0527\u055e\u0541\u051d\u0568\u0524\u0526\u0542\u054e\u054e\u0542\u0565\u056d\u0567\u056b\u054d\u0555\u054f\u056e\u0567\u0551\u0557\u0539\u054e\u056f\u055d\u054d\u0575\u0578\u054f\u0580\u053f\u0555\u057b\u057b\u0558\u0588\u054d\u054e\u0561\u058d\u0579\u0591\u0582\u058f\u0593\u055a\u055b", (byte)43, 70);
                    continue block7;
                }
                case 1: {
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u0141\u0145\u013f\u0123\u0123\u0122\u0152\u0127\u012e\u011f\u0128\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u048e\u04a8\u0467\u046d\u047d\u04b0\u048c\u04ab\u04a6\u048d\u0495\u0487\u048f\u04b8\u0487\u049c\u0494\u04bc\u048e\u04b7\u04a2\u048c\u0489\u048a", (byte)43, 68);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u014e\u0138\u010f\u0130\u011f\u0129\u010f\u012b\u0124\u0114\u0146\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0119\u011a\u012e\u0124\u0141\u013e\u0149\u0147\u0125\u0138\u0120\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[4] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0145\u014d\u0122\u0128\u0121\u011e\u012a\u0135\u0153\u012b\u0142\u011d", (byte)43, 66);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u04a0\u047e\u04ad\u04ad\u049d\u04a1\u04aa\u047f\u04a8\u0496\u0481\u047e", (byte)43, 68);
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[6] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0528\u0542\u051e\u0557\u055b\u0538\u0518\u0560\u0527\u055e\u0541\u051d\u0568\u0524\u0526\u0542\u054e\u054e\u0542\u0565\u056d\u0567\u056b\u054d\u0555\u054f\u056e\u0567\u0551\u0557\u0539\u054e\u056f\u055d\u054d\u0575\u0578\u054f\u0580\u053f\u0555\u057b\u057a\u055a\u0577\u0564\u0560\u054c\u055f\u0550\u058d\u054d\u057e\u0592\u0550\u057f\u0598\u0581\u0576\u0595\u055a\u055b\u057c\u057c", (byte)43, 69);
                    continue block7;
                }
                case 2: {
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u04a7\u048a\u0491\u048b\u046b\u046b\u04a8\u049e\u0491\u0482\u04a3\u049a\u048c\u0489\u0479\u04bd\u0478\u04ab\u048f\u049b\u0498\u0491\u048f\u04b3\u049e\u04bb\u04c8\u04b8\u04a7\u04a3\u0496\u04a7", (byte)43, 68);
                    continue block7;
                }
                case 4: {
                    \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.d[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u051e\u054c\u051c\u0544\u055f\u0546\u0546\u0523\u0551\u0569\u0542\u053c\u0535\u0562\u056f\u0542\u054d\u0549\u0550\u053b\u0532\u0573\u053a\u053b", (byte)43, 69);
                }
            }
        }
    }

    public String C(String string) {
        return super.w(string);
    }

    private static String a(int n, long l) {
        l ^= 8L;
        l ^= 0x5D004E242C6B7432L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(2 + 67), (byte)(57 + 26), (byte)(41 + 6), (byte)(49 + 18), (byte)(17 + 49), (byte)(6 + 61), (byte)(2 + 45), (byte)(8 + 72), 75, (byte)(62 + 5), (byte)(11 + 72), (byte)(43 + 10), (byte)(23 + 57), (byte)(88 + 9), (byte)(80 + 20), (byte)(38 + 62), 105, (byte)(34 + 76), (byte)(65 + 38)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(29 + 54)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0116\u0123\u0122\u00e5\u0125\u0121\u011c\u0125\u0130\u011f\u00ec\u012a\u012e\u0127\u012a\u0130\u00f2\u0458\u0488\u0459\u0487\u0468\u047b\u0483\u048f\u048a\u0473\u0462\u0496", (byte)26, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    static {
        c = (0 >>> 99 | 0 << -99) & 0xFFFFFFFF;
        i = Long.reverse(6801241899290584262L);
        j = Long.reverse(0x1000000000000000L);
        k = (1 >>> 32 | 1 << -32) & 0xFFFFFFFF;
        m = Long.reverse(6801241899290584262L);
        n = Long.reverse(0x1000000000000000L);
        r = Integer.reverse(0x40000000);
        s = Long.reverse(6801241899290584262L);
        t = Long.reverse(0x1000000000000000L);
        u = (0x30000000 >>> 252 | 0x30000000 << -252) & 0xFFFFFFFF;
        v = Integer.reverse(-1);
        w = Long.reverse(5648320394683737286L);
        x = Integer.reverse(0);
        y = (65536 >>> 14 | 65536 << -14) & 0xFFFFFFFF;
        z = Integer.reverse(-1);
        aa = Long.reverse(5648320394683737286L);
        ab = (6 >>> 161 | 6 << -161) & 0xFFFFFFFF;
        ac = Integer.reverse(0x20000000);
        ad = 0 >>> 220 | 0 << -220;
        ae = 1024 >>> 202 | 1024 << ~202 + 1;
        af = Integer.reverse(-1610612736);
        ag = Long.reverse(6801241899290584262L);
        ah = Long.reverse(0x1000000000000000L);
        ai = Integer.reverse(0);
        aj = (32 >>> 132 | 32 << ~132 + 1) & 0xFFFFFFFF;
        ak = (0x180000 >>> 179 | 0x180000 << ~179 + 1) & 0xFFFFFFFF;
        al = Integer.reverse(0x60000000);
        am = Long.reverse(5648320394683737286L);
        an = (0x1C0000 >>> 50 | 0x1C0000 << -50) & 0xFFFFFFFF;
        ao = Integer.reverse(-536870912);
        c = new String[an];
        d = new String[ao];
        \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.b();
    }

    public \u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7() {
        super((String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e80", (int)c, (long)(i ^ j)));
    }

    @Override
    public boolean i(String string, String string2) {
        String[] stringArray;
        if (string2.contains((CharSequence)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e80", (int)r, (long)(s ^ t)))) {
            string2 = string2.split((String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e83", (int)(u & v), (long)w))[x];
        }
        if ((stringArray = string2.split((String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e86", (int)(y & z), (long)aa))).length != ab && stringArray.length != ac) {
            return ad != 0;
        }
        String string3 = stringArray[ae];
        if (!string3.equalsIgnoreCase((String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e89", (int)af, (long)(ag ^ ah)))) {
            return ai != 0;
        }
        String string4 = stringArray[aj];
        String string5 = super.w(string);
        switch (stringArray.length) {
            case 3: {
                return string4.equals(string5);
            }
            case 4: {
                String string6 = stringArray[ak];
                return string4.equals(super.w(string5 + string6));
            }
        }
        throw new IllegalArgumentException((String)\u0394\u03c3\u0393\u03c0\u03a0\u03b2\u03b9\u03c4\u03be\u03a6\u0394\u03c7.c("\u3e8c", (int)al, (long)am) + stringArray.length);
    }
}

