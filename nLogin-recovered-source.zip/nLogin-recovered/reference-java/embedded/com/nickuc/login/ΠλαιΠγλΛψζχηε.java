/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  com.nickuc.login.lib.packetevents.api.protocol.chat.ChatTypes
 *  com.nickuc.login.lib.packetevents.api.protocol.chat.message.ChatMessage
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientChatMessage
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerChatMessage
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.lib.packetevents.api.protocol.chat.ChatTypes;
import com.nickuc.login.lib.packetevents.api.protocol.chat.message.ChatMessage;
import com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientChatMessage;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerChatMessage;
import com.nickuc.login.\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6,
\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b {
    private static int r;
    private static int m;
    private static int h;
    private static int c;
    private static int i;
    private static int o;
    private static int t;
    private static int f;
    private static int g;
    private static int p;
    private static int d;
    private static int a;
    private static String[] b;
    private static int b;
    final /* synthetic */ \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 c;
    private static int u;
    private static int s;
    private static int e;
    private static int k;
    private static long c;
    private static int l;
    private static int q;
    private static String[] a;
    private static long j;
    private static int n;

    /* synthetic */ \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393, \u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7 \u03bb\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7) {
        this(\u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0549\u056b\u056d\u054d\u0571\u0590\u0588\u059e\u058a\u0559\u0597\u058d\u059b\u0595\u055e\u0583\u05a5\u05a4\u059c\u05a2\u059c\u0571", (byte)101, 70), \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0584\u0591\u0590\u0553\u0593\u058f\u058a\u0593\u059e\u058d\u055a\u0598\u059c\u0595\u0598\u059e\u0560\u08d2\u08ee\u08e5\u08ee\u08d6\u08ea\u08f3\u08d4\u0902\u08f1\u0903\u08f4\u08f3\u0579", (byte)101, 70) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0183", (byte)101, 65) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x4AL;
        l ^= 0x7F1D4DE925CA5510L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(39 + 29), (byte)(27 + 42), (byte)(68 + 15), (byte)(45 + 2), (byte)(9 + 58), (byte)(22 + 44), (byte)(63 + 4), (byte)(37 + 10), (byte)(67 + 13), (byte)(41 + 34), (byte)(44 + 23), 83, (byte)(29 + 24), (byte)(59 + 21), (byte)(4 + 93), (byte)(31 + 69), 100, (byte)(36 + 69), (byte)(68 + 42), (byte)(36 + 67)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(42 + 26), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u0574\u0581\u0580\u0543\u0583\u057f\u057a\u0583\u058e\u057d\u054a\u0588\u058c\u0585\u0588\u058e\u0550\u08c2\u08de\u08d5\u08de\u08c6\u08da\u08e3\u08c4\u08f2\u08e1\u08f3\u08e4\u08e3", (byte)85, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        Object object = packetReceiveEvent.getPlayer();
        if (object == null) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).b().a(object);
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 == null) {
            packetReceiveEvent.setCancelled(a != 0);
            return;
        }
        WrapperPlayClientChatMessage wrapperPlayClientChatMessage = new WrapperPlayClientChatMessage(packetReceiveEvent);
        String string = wrapperPlayClientChatMessage.getMessage();
        if ((string = string.trim()).isEmpty()) {
            return;
        }
        if (string.charAt(b) == c) {
            String string2 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string);
            if (string2 == null) {
                packetReceiveEvent.setCancelled(d != 0);
                return;
            }
            wrapperPlayClientChatMessage.setMessage(string2);
            packetReceiveEvent.markForReEncode(e != 0);
            if (string.length() < f) {
                return;
            }
            String[] stringArray = string.substring(g).split((String)\u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.c("\u3e80", (int)(h & i), (long)j));
            if (stringArray.length < k) {
                return;
            }
            \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).a().a(stringArray[l].toLowerCase(Locale.ENGLISH));
            if (\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92 != null) {
                String[] stringArray2 = new String[stringArray.length - m];
                if (stringArray2.length > 0) {
                    System.arraycopy(stringArray, n, stringArray2, o, stringArray2.length);
                }
                \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray[p], stringArray2);
            }
        } else if (\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string)) {
            packetReceiveEvent.setCancelled(q != 0);
        }
    }

    @Generated
    private \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393) {
        this.c = \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
    }

    static {
        a = 2048 >>> 139 | 2048 << ~139 + 1;
        b = Integer.reverse(0);
        c = Integer.reverse(-201326592);
        d = 16 >>> 100 | 16 << -100;
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (262144 >>> 81 | 262144 << ~81 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = (0 >>> 161 | 0 << -161) & 0xFFFFFFFF;
        i = (-1 >>> 110 | -1 << ~110 + 1) & 0xFFFFFFFF;
        j = Long.reverse(7902463148109724215L);
        k = 0x1000000 >>> 88 | 0x1000000 << -88;
        l = (0 >>> 203 | 0 << -203) & 0xFFFFFFFF;
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Integer.reverse(Integer.MIN_VALUE);
        o = Integer.reverse(0);
        p = 0 >>> 175 | 0 << ~175 + 1;
        q = Integer.reverse(Integer.MIN_VALUE);
        r = (491520 >>> 47 | 491520 << -47) & 0xFFFFFFFF;
        s = 262144 >>> 114 | 262144 << ~114 + 1;
        t = 512 >>> 201 | 512 << -201;
        u = 0x2000000 >>> 153 | 0x2000000 << ~153 + 1;
        a = new String[t];
        b = new String[u];
        \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.b();
    }

    private static void b() {
        int n;
        c = -1414256053695228420L;
        long l = c ^ 0x7F1D4DE925CA5510L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(10 + 58), (byte)(19 + 50), (byte)(76 + 7), 47, (byte)(63 + 4), (byte)(54 + 12), (byte)(57 + 10), (byte)(9 + 38), (byte)(21 + 59), (byte)(42 + 33), (byte)(14 + 53), (byte)(68 + 15), 53, (byte)(36 + 44), (byte)(95 + 2), (byte)(90 + 10), (byte)(65 + 35), (byte)(85 + 20), (byte)(48 + 62), (byte)(36 + 67)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(49 + 20), (byte)(18 + 65)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u055a\u0565\u054a\u0528\u0557\u0561\u054d\u0548\u052c\u0551\u0548\u0539", (byte)53, 70);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u011f\u0156\u0143\u0138\u0122\u0135\u0137\u0165\u0129\u014a\u0127\u0131", (byte)53, 65);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0539\u0560\u0545\u0565\u052c\u0539\u054c\u0547\u0546\u052c\u0550\u0539", (byte)53, 70);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03bb\u03b1\u03b9\u03a0\u03b3\u03bb\u039b\u03c8\u03b6\u03c7\u03b7\u03b5.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0118\u015e\u011b\u015f\u0140\u011f\u0128\u0133\u0166\u0127\u012b\u0131", (byte)53, 66);
                }
            }
        }
    }

    @Override
    public void a(PacketSendEvent packetSendEvent) {
        if (!\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.an.ar()) {
            return;
        }
        Object object = packetSendEvent.getPlayer();
        if (object == null) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).b().a(object);
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.c).a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 == null) {
            return;
        }
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a().b(\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.f)) {
            return;
        }
        WrapperPlayServerChatMessage wrapperPlayServerChatMessage = new WrapperPlayServerChatMessage(packetSendEvent);
        ChatMessage chatMessage = wrapperPlayServerChatMessage.getMessage();
        if (chatMessage.getType() == ChatTypes.GAME_INFO) {
            return;
        }
        Component component = chatMessage.getChatContent();
        List list = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.l, string -> new ArrayList());
        if (list.size() < r) {
            list.add(component);
        }
        packetSendEvent.setCancelled(s != 0);
    }
}

