/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.tasks.LoginMainQueueTask;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7
implements Runnable {
    private static long u;
    private final \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 c;
    private static long z;
    private static long ac;
    private static long c;
    private static int af;
    private static int aa;
    private static int f;
    private static long an;
    private static int n;
    private final \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 a;
    private static int a;
    private static long ab;
    private static int k;
    private static long ae;
    private static long j;
    private static long d;
    private static long r;
    private static long v;
    private static long h;
    private static int am;
    private static long o;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 j;
    private static int ao;
    private static int w;
    private static int ag;
    private static int q;
    private static int t;
    private static int ap;
    private static int al;
    private static String[] b;
    private static int c;
    private static int b;
    private static int ak;
    private static int aj;
    private static long m;
    private final String q;
    private static int i;
    private static int ah;
    private static long e;
    private static int ai;
    private final \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a;
    private static String[] a;
    private static int x;
    private final boolean y;
    private static int ad;
    private static long l;
    private static long s;
    private static long y;
    private static int g;
    private static long p;

    public \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = a;
        \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3[] \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array = \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.values();
        int n2 = \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array.length;
        for (int i = b; i < n2; ++i) {
            \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3 \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3 = \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array[i];
            if (\u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.aT()) continue;
            if (n == 0) {
                stringBuilder.append((String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e80", (int)c, (long)(d ^ e)));
            } else {
                n = f;
            }
            stringBuilder.append((String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e83", (int)g, (long)h)).append(\u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.cT).append((String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e86", (int)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.i, (long)j));
        }
        this.q = stringBuilder.toString();
        this.j = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
        this.c = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
        this.y = bl;
        this.a = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b();
        this.a = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b(k != 0).a(this, l, m, TimeUnit.MILLISECONDS);
    }

    private static String a(int n, long l) {
        l ^= 0x51L;
        l ^= 0xDA192DE6A9D59DF2L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(40 + 28), (byte)(23 + 46), 83, (byte)(18 + 29), (byte)(58 + 9), (byte)(41 + 25), (byte)(62 + 5), (byte)(43 + 4), (byte)(18 + 62), (byte)(12 + 63), (byte)(5 + 62), (byte)(7 + 76), 53, (byte)(15 + 65), (byte)(40 + 57), (byte)(49 + 51), (byte)(62 + 38), (byte)(95 + 10), (byte)(11 + 99), (byte)(55 + 48)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(46 + 37)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0108\u0115\u0114\u00d7\u0117\u0113\u010e\u0117\u0122\u0111\u00de\u011c\u0120\u0119\u011c\u0122\u00e4\u0478\u047d\u044b\u0470\u0462\u044e\u0470\u0458\u047e\u0470\u0478\u0469\u0479", (byte)19, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -1642595965744347619L;
        long l = c ^ 0xDA192DE6A9D59DF2L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(16 + 52), (byte)(17 + 52), (byte)(45 + 38), (byte)(10 + 37), (byte)(54 + 13), (byte)(48 + 18), (byte)(47 + 20), (byte)(17 + 30), (byte)(59 + 21), (byte)(49 + 26), 67, (byte)(13 + 70), (byte)(40 + 13), (byte)(11 + 69), (byte)(85 + 12), (byte)(69 + 31), (byte)(67 + 33), (byte)(82 + 23), (byte)(2 + 108), (byte)(34 + 69)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(9 + 60), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0436\u045d\u0446\u043d\u0461\u045a\u043e\u0451\u045b\u046b\u042b\u0439", (byte)20, 68);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0514\u053b\u0501\u0506\u050d\u0504\u050f\u053e\u051d\u051f\u054d\u0518", (byte)20, 70);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[2] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0506\u053f\u0537\u0520\u0525\u0547\u0524\u051f\u051d\u0532\u0551\u0518", (byte)20, 70);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[3] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0529\u0527\u0502\u0517\u0507\u0526\u0544\u0542\u050f\u0532\u0527\u0518", (byte)20, 69);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u00d7\u00f2\u010d\u00d5\u00df\u0122\u00df\u0113\u00e7\u0123\u00dc\u0123\u011f\u012b\u0103\u00e5\u0107\u00e7\u0120\u0112\u012f\u0116\u011e\u00ed\u00f4\u0128\u00f1\u012a\u013a\u0133\u00fb\u0113\u0118\u0113\u0143\u0130\u0117\u0102\u012e\u0126\u0117\u013b\u0109\u010f", (byte)20, 65);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0437\u0448\u042b\u045c\u0429\u046f\u0426\u0468\u0464\u044e\u045e\u0439", (byte)20, 67);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[6] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u045e\u0438\u0422\u0455\u043d\u044c\u0451\u0472\u0460\u044a\u0466\u0439", (byte)20, 67);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u00f0\u00f2\u00ec\u0122\u0105\u0126\u011a\u00f1\u00e7\u011f\u0124\u00ef", (byte)20, 65);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[8] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u00f7\u00db\u00ee\u011b\u00db\u00df\u00d8\u00f2\u00f8\u0103\u010a\u00ef", (byte)20, 66);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[9] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0424\u043e\u044c\u043b\u0425\u0462\u0449\u042a\u045f\u043f\u0472\u0439", (byte)20, 68);
                    continue block7;
                }
                case 1: {
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0446\u044a\u0427\u0428\u0425\u0447\u0428\u0428\u042c\u0443\u0450\u0439", (byte)20, 68);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u00f2\u0109\u00e0\u00df\u00e3\u0113\u0126\u0127\u00fb\u0103\u0124\u00ef", (byte)20, 65);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0460\u0446\u0448\u0465\u0456\u046a\u0447\u046f\u0428\u045c\u042b\u0439", (byte)20, 68);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00ef\u00f1\u010b\u00de\u011b\u00df\u011a\u0120\u0115\u0129\u00fe\u00ef", (byte)20, 66);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[4] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u00d7\u00f2\u010d\u00d5\u00df\u0122\u00df\u0113\u00e7\u0123\u00dc\u0123\u011f\u012b\u0103\u00e5\u0107\u00e7\u0120\u0112\u012f\u0116\u011e\u00ed\u00f4\u0128\u00f1\u012a\u013a\u0133\u00fb\u0113\u0116\u0133\u0120\u013a\u0113\u0116\u0114\u011a\u0148\u011d\u013f\u011f\u0102\u013b\u0117\u0101\u0122\u011e\u011a\u0126\u011e\u011d\u011a\u011b", (byte)20, 66);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0549\u0518\u0546\u0540\u053a\u053a\u054f\u0544\u0531\u054b\u0533\u0518", (byte)20, 70);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0440\u0457\u0444\u0426\u0428\u042f\u0441\u043a\u0460\u044b\u042c\u045e\u046c\u0474\u0469\u044a\u0464\u044b\u0466\u0472\u044d\u046d\u0444\u0445", (byte)20, 67);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[7] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u045a\u0449\u0461\u0455\u0427\u044c\u0439\u044b\u0447\u045e\u0450\u0454\u0453\u0476\u0461\u042b\u0478\u043b\u045a\u047d\u045c\u0447\u0444\u0445", (byte)20, 68);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[8] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u010d\u00f3\u00fa\u0124\u00f8\u0123\u0115\u00e6\u00f3\u0112\u00e9\u00ef", (byte)20, 66);
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[9] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u045a\u044a\u0444\u0464\u046f\u042d\u044a\u0440\u0451\u0463\u0450\u0439", (byte)20, 67);
                    continue block7;
                }
                case 2: {
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u00dd\u00e1\u00fc\u00f2\u00f8\u011d\u0127\u0122\u0105\u00df\u00fe\u00ef", (byte)20, 65);
                    continue block7;
                }
                case 4: {
                    \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0437\u0461\u043e\u042b\u044d\u0426\u046e\u044d\u043e\u0432\u044c\u0439", (byte)20, 67);
                }
            }
        }
    }

    static {
        a = (8192 >>> 45 | 8192 << ~45 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(0);
        c = Integer.reverse(0);
        d = Long.reverse(-5160691895763325801L);
        e = Long.reverse(-8502796096475496448L);
        f = Integer.reverse(0);
        g = 0x100000 >>> 84 | 0x100000 << ~84 + 1;
        h = Long.reverse(3630334576863882391L);
        i = Integer.reverse(0x40000000);
        j = Long.reverse(3630334576863882391L);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = Long.reverse(1711367858400788480L);
        m = Long.reverse(0x4C00000000000000L);
        n = (0x60000000 >>> 29 | 0x60000000 << ~29 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-5160691895763325801L);
        p = Long.reverse(-8502796096475496448L);
        q = Integer.reverse(0x20000000);
        r = Long.reverse(-5160691895763325801L);
        s = Long.reverse(-8502796096475496448L);
        t = (0x500000 >>> 116 | 0x500000 << -116) & 0xFFFFFFFF;
        u = Long.reverse(-5160691895763325801L);
        v = Long.reverse(-8502796096475496448L);
        w = (8 >>> 131 | 8 << ~131 + 1) & 0xFFFFFFFF;
        x = (3 >>> 127 | 3 << ~127 + 1) & 0xFFFFFFFF;
        y = Long.reverse(-5160691895763325801L);
        z = Long.reverse(-8502796096475496448L);
        aa = 0x38000000 >>> 27 | 0x38000000 << ~27 + 1;
        ab = Long.reverse(-5160691895763325801L);
        ac = Long.reverse(-8502796096475496448L);
        ad = Integer.reverse(0x10000000);
        ae = Long.reverse(3630334576863882391L);
        af = Integer.reverse(0);
        ag = Integer.reverse(0x14000000);
        ah = Integer.reverse(0x28000000);
        ai = 0 >>> 186 | 0 << -186;
        aj = 128 >>> 38 | 128 << -38;
        ak = 65536 >>> 207 | 65536 << -207;
        al = (0x1200000 >>> 213 | 0x1200000 << -213) & 0xFFFFFFFF;
        am = Integer.reverse(-1);
        an = Long.reverse(3630334576863882391L);
        ao = Integer.reverse(0x50000000);
        ap = 0x500000 >>> 243 | 0x500000 << -243;
        a = new String[ao];
        b = new String[ap];
        \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.b();
    }

    @Override
    public void run() {
        if (!this.j.N()) {
            this.a.Z();
            return;
        }
        if (!this.c.R() || !\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b().contains(this.c.getName())) {
            \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b().remove(this.c.getName());
            this.a.Z();
            return;
        }
        int n = LoginMainQueueTask.x();
        if (n > 0) {
            this.c.a((String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e80", (int)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.n, (long)(o ^ p)), (String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e83", (int)q, (long)(r ^ s)) + n + (String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e86", (int)t, (long)(u ^ v)) + (String)(n == w ? \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e89", (int)x, (long)(y ^ z)) : \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e8c", (int)aa, (long)(ab ^ ac))) + (String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e8f", (int)ad, (long)ae), af, ag, ah);
        }
        \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3[] \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array = \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.values();
        Object[] objectArray = new String[\u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array.length];
        for (int i = ai; i < \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array.length; ++i) {
            String string = this.y ? \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array[i].c(TimeUnit.MILLISECONDS, aj) : \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3Array[i].b(TimeUnit.MILLISECONDS, ak);
            objectArray[i] = string + (String)\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.c("\u3e92", (int)(al & am), (long)an);
        }
        this.c.o(String.format(this.q, objectArray));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u00d3\u00f5\u00f7\u00d7\u00fb\u011a\u0112\u0128\u0114\u00e3\u0121\u0117\u0125\u011f\u00e8\u010d\u012f\u012e\u0126\u012c\u0126\u00fb", (byte)22, 66), \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u010e\u011b\u011a\u00dd\u011d\u0119\u0114\u011d\u0128\u0117\u00e4\u0122\u0126\u011f\u0122\u0128\u00ea\u047e\u0483\u0451\u0476\u0468\u0454\u0476\u045e\u0484\u0476\u047e\u046f\u047f\u0103", (byte)22, 66) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0431", (byte)22, 67) + methodType.toString(), exception);
        }
    }
}

