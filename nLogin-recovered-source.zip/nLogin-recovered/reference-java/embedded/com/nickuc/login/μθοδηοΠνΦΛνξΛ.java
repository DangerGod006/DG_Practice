/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;

public interface \u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b {
    default public void a(PacketSendEvent packetSendEvent) {
    }
}

