/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03b8\u03bf\u03a3\u03ba\u03c1\u03b8\u03bf\u039b\u03bc\u0394\u03a8 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] G;
    private static int b = (0x8000000 >>> 218 | 0x8000000 << -218) & 0xFFFFFFFF;

    static {
        G = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03b8\u03bf\u03a3\u03ba\u03c1\u03b8\u03bf\u039b\u03bc\u0394\u03a8.G[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03bf\u03a3\u03ba\u03c1\u03b8\u03bf\u039b\u03bc\u0394\u03a8.G[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

