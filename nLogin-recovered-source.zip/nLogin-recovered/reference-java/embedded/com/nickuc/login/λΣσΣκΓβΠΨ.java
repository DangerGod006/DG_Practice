/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8 {
    private static final Pattern j;
    private static long l;
    private static int a;
    private static int k;
    private static long b;
    private static int i;
    private static int o;
    private static long e;
    private static long r;
    private static int n;
    private static long h;
    private static long j;
    private static long d;
    private static int q;
    private static int g;
    private static String[] b;
    private static long c;
    private static int c;
    private static String[] a;
    private static int p;
    private static long m;
    private static int f;

    public static UUID a(String string, UUID uUID) {
        return \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a().a(string, uUID);
    }

    public static String b(@Nullable UUID uUID) {
        return uUID != null ? uUID.toString().replace((CharSequence)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e80", (int)(f & g), (long)h), (CharSequence)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e83", (int)i, (long)j)) : null;
    }

    private static String a(int n, long l) {
        l ^= 0x77L;
        l ^= 0xC61CED9ABDF9B95FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(39 + 29), (byte)(58 + 11), 83, (byte)(44 + 3), (byte)(41 + 26), (byte)(41 + 25), (byte)(49 + 18), (byte)(31 + 16), (byte)(2 + 78), (byte)(41 + 34), (byte)(10 + 57), (byte)(14 + 69), (byte)(12 + 41), (byte)(23 + 57), (byte)(9 + 88), (byte)(3 + 97), 100, (byte)(21 + 84), (byte)(15 + 95), (byte)(52 + 51)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(17 + 51), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0110\u011d\u011c\u00df\u011f\u011b\u0116\u011f\u012a\u0119\u00e6\u0124\u0128\u0121\u0124\u012a\u00ec\u0479\u0462\u0483\u0464\u047c\u0456\u0476\u0465\u046e", (byte)23, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = 4030398502058651421L;
        long l = c ^ 0xC61CED9ABDF9B95FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(51 + 18), (byte)(26 + 57), (byte)(13 + 34), (byte)(54 + 13), (byte)(38 + 28), (byte)(14 + 53), (byte)(2 + 45), 80, (byte)(66 + 9), (byte)(61 + 6), (byte)(31 + 52), (byte)(42 + 11), 80, (byte)(73 + 24), (byte)(41 + 59), (byte)(65 + 35), (byte)(103 + 2), (byte)(91 + 19), (byte)(43 + 60)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(31 + 37), (byte)(20 + 49), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u04b9\u049c\u04b5\u04da\u04cc\u04d9\u04b8\u04e1\u04c1\u04bf\u04e4\u04ab", (byte)58, 68);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0167\u0146\u016f\u015c\u013e\u016a\u013e\u012a\u0165\u0165\u016a\u0140\u0177\u0143\u0176\u0152\u0179\u0146\u013b\u013a\u015d\u0159\u0146\u0147", (byte)58, 65);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u054c\u052f\u0548\u056d\u055f\u056c\u054b\u0574\u0554\u0552\u0577\u053e", (byte)58, 70);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0140\u014a\u016a\u014e\u0140\u0130\u0145\u0161\u0153\u016e\u0156\u013b", (byte)58, 65);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u056d\u056d\u054d\u0563\u052c\u0543\u0548\u0547\u0541\u0569\u055a\u0566\u0564\u056a\u0566\u055a\u0559\u0560\u054d\u0577\u0554\u0582\u0549\u054a", (byte)58, 70);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[5] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u04d6\u04a8\u04be\u04d4\u04b0\u04d5\u04a0\u04bf\u049c\u04bd\u04bd\u04c8\u04c0\u04d2\u04d4\u04e5\u04b5\u04c5\u04ba\u04ce\u04c4\u04eb\u04cf\u04c7\u04d1\u04b0\u04b4\u04d3\u04e2\u04c4\u04f2\u04ad\u04cd\u04e6\u04fc\u04dd\u04f6\u04e0\u04cc\u04f0\u04d5\u0500\u04d1\u04d5\u04fc\u04d7\u04c9\u04c2\u04f8\u04eb\u050c\u04c9\u04ed\u04e9\u04d6\u04d7", (byte)58, 67);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0492\u04ca\u04d8\u04de\u04d9\u04e0\u04ba\u04ab\u04c0\u04d1\u04c2\u04ab", (byte)58, 67);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04d7\u04b6\u04df\u04cc\u04ae\u04da\u04ae\u049a\u04d5\u04d5\u04db\u04a0\u04c3\u04be\u04ba\u04a9\u04a4\u04de\u04cf\u04e7\u04e8\u04cf\u04bb\u04c7\u04d3\u04f4\u04e7\u04ee\u04b2\u04f8\u04fa\u04ea", (byte)58, 68);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0550\u056d\u056b\u052b\u056d\u054c\u052b\u0540\u056c\u0530\u0545\u053e", (byte)58, 70);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u056b\u054b\u0523\u052a\u053b\u0553\u0543\u054d\u0529\u0563\u0541\u053e", (byte)58, 70);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[4] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u04da\u04da\u04ba\u04d0\u0499\u04b0\u04b5\u04b4\u04ae\u04d6\u04c6\u04d4\u04a2\u04da\u04c7\u04e9\u04e2\u04e9\u04ed\u04c1\u04bf\u04db\u04e6\u04c1\u04af\u04d6\u04f5\u04f4\u04c4\u04b0\u04ac\u04ce", (byte)58, 68);
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0569\u053b\u0551\u0567\u0543\u0568\u0533\u0552\u052f\u0550\u0550\u055b\u0553\u0565\u0567\u0578\u0548\u0558\u054d\u0561\u0557\u057e\u0562\u055a\u0564\u0543\u0547\u0566\u0575\u0557\u0585\u0540\u0560\u0579\u058f\u0570\u0589\u0573\u055f\u0583\u0568\u0593\u0561\u0579\u058e\u0586\u056d\u0576\u0591\u056f\u057b\u057e\u0573\u0575\u0598\u0580\u059c\u057b\u057e\u0595\u057a\u05a7\u056b\u057d", (byte)58, 69);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u055d\u053c\u054f\u0547\u0548\u0573\u0565\u0555\u0536\u052a\u056a\u054c\u0534\u0534\u0559\u057e\u053f\u0554\u056d\u0582\u0552\u055c\u0549\u054a", (byte)58, 70);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0142\u013d\u014a\u0141\u0139\u0159\u0145\u0148\u016b\u0134\u0143\u0135\u0169\u0146\u0145\u014e\u017c\u0139\u0177\u0154\u0132\u016f\u0146\u0147", (byte)58, 65);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(6266510764049922028L);
        c = (0x1000000 >>> 24 | 0x1000000 << ~24 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-5118589093942691860L);
        e = Long.reverse(-1297036692682702848L);
        f = Integer.reverse(0x40000000);
        g = (-1 >>> 119 | -1 << ~119 + 1) & 0xFFFFFFFF;
        h = Long.reverse(6266510764049922028L);
        i = (0x1800000 >>> 87 | 0x1800000 << -87) & 0xFFFFFFFF;
        j = Long.reverse(6266510764049922028L);
        k = Integer.reverse(0x20000000);
        l = Long.reverse(-5118589093942691860L);
        m = Long.reverse(-1297036692682702848L);
        n = Integer.reverse(0x60000000);
        o = (3 >>> 31 | 3 << -31) & 0xFFFFFFFF;
        p = 320 >>> 198 | 320 << -198;
        q = (-1 >>> 211 | -1 << ~211 + 1) & 0xFFFFFFFF;
        r = Long.reverse(6266510764049922028L);
        a = new String[n];
        b = new String[o];
        \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b();
        j = Pattern.compile((String)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e80", (int)(p & q), (long)r));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0458\u047a\u047c\u045c\u0480\u049f\u0497\u04ad\u0499\u0468\u04a6\u049c\u04aa\u04a4\u046d\u0492\u04b4\u04b3\u04ab\u04b1\u04ab\u0480", (byte)41, 67), \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0134\u0141\u0140\u0103\u0143\u013f\u013a\u0143\u014e\u013d\u010a\u0148\u014c\u0145\u0148\u014e\u0110\u049d\u0486\u04a7\u0488\u04a0\u047a\u049a\u0489\u0492\u0125", (byte)41, 65) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u051f", (byte)41, 69) + methodType.toString(), exception);
        }
    }

    public static UUID c(@Nullable String string) {
        if (string != null && !string.isEmpty()) {
            String string2 = string.contains((CharSequence)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e80", (int)a, (long)b)) ? string : j.matcher(string).replaceAll((String)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e83", (int)c, (long)(d ^ e)));
            return UUID.fromString(string2);
        }
        return null;
    }

    public static UUID d(String string) {
        return UUID.nameUUIDFromBytes(((String)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c("\u3e80", (int)k, (long)(l ^ m)) + string).getBytes(StandardCharsets.UTF_8));
    }
}

