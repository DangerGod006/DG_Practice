/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba {
    private static long ac;
    private static long c;
    private static long bh;
    private static int bb;
    private static int z;
    private static int n;
    private static int b;
    private static int ai;
    private static long bz;
    public static final String bv;
    private static int an;
    private static int q;
    private static int bq;
    private static int bo;
    private static int bd;
    private static int bt;
    private static int u;
    private static int t;
    private static int bk;
    private static long d;
    private static int ak;
    private static int j;
    private static long cl;
    private static int p;
    private static int bw;
    private static int bj;
    private static long ca;
    private static int bn;
    private static int cb;
    private static int bv;
    private static final Pattern d;
    private static int r;
    private static int ay;
    private static int ag;
    private static int aq;
    private static final Pattern f;
    private static int al;
    private static int a;
    private static int f;
    private static int e;
    private static int az;
    private static long bx;
    private static long ck;
    private static long ch;
    private static long ci;
    private static int i;
    private static int ad;
    private static String[] b;
    private static int bm;
    private static long h;
    private static int cj;
    private static int bl;
    private static int v;
    private static int bs;
    private static int m;
    private static long bi;
    private static int k;
    private static int as;
    private static int x;
    public static final char b;
    private static long cd;
    private static long g;
    private static int w;
    private static int af;
    private static int bu;
    private static int s;
    private static int aw;
    private static int br;
    private static long bp;
    private static int au;
    private static int cg;
    private static int bc;
    private static int be;
    private static int am;
    private static int ab;
    private static final Pattern g;
    private static long ba;
    public static final char d;
    private static int at;
    private static int aj;
    private static int bf;
    private static int ah;
    private static int y;
    private static int ap;
    public static final String bu;
    private static int l;
    private static String[] a;
    private static int o;
    private static final Pattern e;
    private static int bg;
    private static int ce;
    private static int cc;
    private static int ar;
    private static int ao;
    private static int ae;
    private static int by;
    private static int av;
    private static int aa;
    private static long ax;
    public static final char c;
    private static long cf;

    public static String t(String string) {
        if (string == null || string.isEmpty()) {
            return string;
        }
        char[] cArray = string.toCharArray();
        block5: for (int i = bc; i < cArray.length; ++i) {
            char c = cArray[i];
            switch (c) {
                case '&': 
                case '\u00a7': {
                    char c2;
                    if (cArray.length < i + bd || (c2 = cArray[i + be]) == bf) continue block5;
                    if (((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)bg, (long)(bh ^ bi))).indexOf(c2) > bj) {
                        ++i;
                        continue block5;
                    }
                    cArray[i + \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.bk] = Character.toUpperCase(c2);
                    break block5;
                }
                case '#': {
                    int n = i + bl;
                    if (cArray.length < n + bm) continue block5;
                    for (int j = i + bn; j < n; ++j) {
                        char c3 = cArray[j];
                        if (((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e83", (int)bo, (long)bp)).indexOf(c3) != bq) continue;
                        cArray[j] = Character.toUpperCase(cArray[j]);
                        break block5;
                    }
                    i += 6;
                    continue block5;
                }
                case ' ': {
                    continue block5;
                }
                default: {
                    cArray[i] = Character.toUpperCase(cArray[i]);
                    break block5;
                }
            }
        }
        return new String(cArray);
    }

    public static String m(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.o(\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.n(string));
    }

    public static String q(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.a(string, (char)m, (char)n, o != 0, p != 0);
    }

    private static void b() {
        int n;
        c = -1097982952399871023L;
        long l = c ^ 0x73AE1053A7CDDE8CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(29 + 39), (byte)(59 + 10), (byte)(46 + 37), (byte)(24 + 23), (byte)(5 + 62), (byte)(57 + 9), (byte)(65 + 2), (byte)(31 + 16), (byte)(74 + 6), 75, (byte)(13 + 54), 83, (byte)(17 + 36), (byte)(42 + 38), (byte)(69 + 28), (byte)(20 + 80), (byte)(5 + 95), (byte)(95 + 10), (byte)(98 + 12), (byte)(95 + 8)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(3 + 66), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u050f\u0537\u0534\u0545\u054b\u0513\u0554\u0545\u0534\u052c\u0537\u0524", (byte)32, 70);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0448\u0470\u046d\u047e\u0484\u044c\u048d\u047e\u046d\u0465\u0470\u045d", (byte)32, 68);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u012c\u0113\u0139\u0127\u0113\u00f9\u00fd\u00f6\u00ff\u011e\u0101\u0107", (byte)32, 65);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0531\u0533\u0544\u0559\u052d\u0518\u0549\u0529\u054b\u055d\u051a\u054b\u0557\u051a\u0537\u0538\u052d\u0542\u0547\u0534\u0546\u0562\u051d\u0561\u0538\u052d\u0568\u0565\u056f\u0570\u0567\u056f", (byte)32, 69);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u046a\u046c\u047d\u0492\u0466\u0451\u0482\u0462\u0484\u0496\u0453\u0484\u0490\u0453\u0470\u0471\u0466\u047b\u0480\u046d\u047f\u0494\u048c\u046f\u0466\u047b\u0466\u0492\u048b\u04a1\u049c\u049a\u046a\u049f\u049d\u04a1\u04a8\u04a5\u0493\u0482\u04a4\u04a5\u04ac\u046b\u0477\u0485\u0493\u04b8\u047b\u0494\u0498\u0481\u04bd\u04c1\u0488\u0489", (byte)32, 67);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[5] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0531\u0533\u0544\u0559\u052d\u0518\u0549\u0529\u054b\u055d\u051a\u054b\u0557\u051a\u0537\u0538\u052d\u0542\u0547\u0534\u0546\u055b\u0553\u0536\u052d\u0542\u052d\u0559\u0552\u0568\u0563\u0561\u0531\u0566\u0564\u0568\u056f\u056c\u055a\u0549\u056b\u056c\u0573\u0532\u053e\u054c\u055a\u057f\u0542\u055b\u055f\u0548\u0584\u0588\u054f\u0550", (byte)32, 69);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0114\u0116\u0127\u013c\u0110\u00fb\u012c\u010c\u012e\u0140\u00fd\u012e\u013a\u00fd\u011a\u011b\u0110\u0125\u012a\u0117\u0129\u0145\u0100\u0144\u011b\u0110\u014b\u0148\u0152\u0153\u014a\u0152", (byte)32, 66);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[7] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u0114\u0116\u0127\u013c\u0110\u00fb\u012c\u010c\u012e\u0140\u00fd\u012e\u013a\u00fd\u011a\u011b\u0110\u0125\u012a\u0117\u0129\u013e\u0136\u0119\u0110\u0125\u0110\u013c\u0135\u014b\u0146\u0144\u0114\u0149\u0147\u014b\u0152\u014f\u013d\u012c\u014e\u014f\u0156\u0115\u0121\u012f\u013d\u0162\u0125\u013e\u0142\u012b\u0167\u016b\u0132\u0133", (byte)32, 66);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[8] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u046a\u046c\u047d\u0492\u0466\u0451\u0482\u0462\u0484\u0496\u0453\u0484\u0490\u0453\u0470\u0471\u0466\u047b\u0480\u046d\u047f\u049b\u0456\u049a\u0471\u0466\u04a1\u049e\u04a8\u04a9\u04a0\u04a8", (byte)32, 67);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[9] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0482\u045e\u0459\u0491\u0492\u046a\u0492\u0471\u044c\u046e\u0450\u0497\u044c\u0452\u0492\u046c\u0468\u0458\u0496\u047b\u045c\u046c\u04a1\u045e\u04a2\u0484\u0467\u0488\u0472\u0486\u049c\u04aa\u04aa\u0469\u0470\u0484\u0480\u048a\u048f\u0481\u048a\u048c\u0498\u049a\u047a\u04a8\u04aa\u047a\u0478\u04be\u04b4\u0490\u049c\u048b\u0488\u0489", (byte)32, 67);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[10] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u012b\u010b\u010a\u0107\u0130\u00f9\u013e\u00f8\u0116\u00fa\u010b\u0140\u00fd\u0135\u0124\u0111\u00fa\u0113\u0133\u010a\u0140\u0125\u013c\u0121\u0125\u011e\u010a\u0113\u0131\u012a\u0129\u0109\u0113\u0141\u0133\u014a\u012a\u015c\u011d\u0158\u013d\u011e\u0150\u0127", (byte)32, 65);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[11] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u045d\u047d\u0446\u0489\u0484\u0470\u0461\u0482\u046a\u0464\u046c\u0478\u0463\u0486\u048a\u0487\u0491\u0468\u049a\u0498\u048a\u045a\u0473\u046d\u0496\u0472\u0490\u0478\u0483\u0481\u049f\u0483", (byte)32, 68);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[12] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u053f\u052b\u0533\u052e\u052c\u0536\u0550\u0545\u0532\u0516\u051d\u0552\u0562\u055e\u0521\u0562\u0543\u053a\u0568\u055d\u0523\u0542\u054b\u054b\u0528\u056e\u0559\u0540\u053e\u056b\u0571\u055d", (byte)32, 70);
                    continue block7;
                }
                case 1: {
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0529\u0554\u0543\u0526\u0555\u0524\u0558\u054c\u054f\u0552\u054d\u0524", (byte)32, 70);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[1] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0446\u044c\u0469\u0449\u044c\u0452\u0452\u0482\u0486\u0465\u0460\u045d", (byte)32, 68);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0523\u0550\u0547\u0525\u0518\u0537\u055c\u0525\u0555\u051b\u052b\u0555\u0529\u0535\u053c\u0557\u054e\u0545\u0545\u055e\u0533\u0568\u052f\u0530", (byte)32, 70);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[3] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0114\u0116\u0127\u013c\u0110\u00fb\u012c\u010c\u012e\u0140\u00fd\u012e\u013a\u00fd\u011a\u011b\u0110\u0125\u012a\u0117\u0129\u013b\u0116\u013c\u014f\u0139\u0104\u0153\u013c\u0142\u0113\u0146\u0126\u0134\u015a\u0152\u014a\u012e\u011d\u014e\u0135\u015c\u0158\u0127", (byte)32, 66);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0114\u0116\u0127\u013c\u0110\u00fb\u012c\u010c\u012e\u0140\u00fd\u012e\u013a\u00fd\u011a\u011b\u0110\u0125\u012a\u0117\u0129\u013e\u0136\u0119\u0110\u0125\u0110\u013c\u0135\u014b\u0146\u0144\u0114\u0149\u0147\u014b\u0152\u014f\u013d\u012c\u014e\u014f\u0155\u0161\u013a\u0161\u0162\u013a\u0135\u0144\u0169\u012b\u0140\u0145\u0132\u0133", (byte)32, 65);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[5] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u046a\u046c\u047d\u0492\u0466\u0451\u0482\u0462\u0484\u0496\u0453\u0484\u0490\u0453\u0470\u0471\u0466\u047b\u0480\u046d\u047f\u0494\u048c\u046f\u0466\u047b\u0466\u0492\u048b\u04a1\u049c\u049a\u046a\u049f\u049d\u04a1\u04a8\u04a5\u0493\u0482\u04a4\u04a5\u04ab\u0471\u04a3\u049b\u04ac\u0478\u04a8\u0489\u047c\u0478\u04a1\u049b\u0488\u0489", (byte)32, 67);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0114\u0116\u0127\u013c\u0110\u00fb\u012c\u010c\u012e\u0140\u00fd\u012e\u013a\u00fd\u011a\u011b\u0110\u0125\u012a\u0117\u0129\u0148\u011d\u0147\u010a\u011d\u013f\u0146\u014a\u0147\u012a\u0134\u0137\u0127\u0126\u0155\u0151\u012c\u0130\u011a\u015a\u012a\u015c\u0127", (byte)32, 66);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[7] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0531\u0533\u0544\u0559\u052d\u0518\u0549\u0529\u054b\u055d\u051a\u054b\u0557\u051a\u0537\u0538\u052d\u0542\u0547\u0534\u0546\u055b\u0553\u0536\u052d\u0542\u052d\u0559\u0552\u0568\u0563\u0561\u0531\u0566\u0564\u0568\u056f\u056c\u055a\u0549\u056b\u056c\u0574\u054d\u0557\u0540\u056f\u0552\u055f\u0557\u057e\u0582\u0562\u0578\u054f\u0550", (byte)32, 70);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u046a\u046c\u047d\u0492\u0466\u0451\u0482\u0462\u0484\u0496\u0453\u0484\u0490\u0453\u0470\u0471\u0466\u047b\u0480\u046d\u047f\u0494\u04a4\u045f\u0458\u0484\u0467\u0489\u049a\u0483\u047d\u0482\u0487\u049d\u0484\u0482\u0464\u048e\u04a3\u04b3\u0495\u047f\u0488\u047d", (byte)32, 68);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[9] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0549\u0525\u0520\u0558\u0559\u0531\u0559\u0538\u0513\u0535\u0517\u055e\u0513\u0519\u0559\u0533\u052f\u051f\u055d\u0542\u0523\u0533\u0568\u0525\u0569\u054b\u052e\u054f\u0539\u054d\u0563\u0571\u0571\u0530\u0537\u054b\u0547\u0551\u0556\u0548\u0551\u0553\u0560\u0575\u0550\u057d\u057b\u0564\u0556\u055d\u0567\u0548\u0573\u0552\u054f\u0550", (byte)32, 69);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[10] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0481\u0461\u0460\u045d\u0486\u044f\u0494\u044e\u046c\u0450\u0461\u0496\u0453\u048b\u047a\u0467\u0450\u0469\u0489\u0460\u0496\u047b\u0492\u0477\u047b\u0474\u0460\u0469\u0487\u0480\u047f\u045f\u048a\u04a6\u0491\u0480\u0486\u047d\u0491\u0481\u04aa\u0477\u0498\u0488\u046c\u0495\u0474\u0473\u0487\u049e\u049e\u048b\u04b4\u04c1\u0488\u0489", (byte)32, 68);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[11] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u045d\u047d\u0446\u0489\u0484\u0470\u0461\u0482\u046a\u0464\u046c\u0478\u0463\u0486\u048a\u0487\u0491\u0468\u049a\u0498\u048a\u0462\u048c\u049f\u0499\u04a7\u049c\u0463\u047e\u0494\u0468\u04a3\u048a\u04a0\u046f\u04a5\u048a\u0481\u04a9\u04af\u048b\u0497\u04a2\u047d", (byte)32, 67);
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[12] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0122\u010e\u0116\u0111\u010f\u0119\u0133\u0128\u0115\u00f9\u0100\u0135\u0145\u0141\u0104\u0145\u0126\u011d\u014b\u0140\u0106\u0136\u011f\u013d\u0143\u0130\u0148\u012f\u0144\u0131\u014e\u0146", (byte)32, 66);
                    continue block7;
                }
                case 2: {
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u0112\u0118\u0109\u012b\u00ee\u0111\u013b\u0111\u0134\u0111\u0112\u0107", (byte)32, 66);
                    continue block7;
                }
                case 4: {
                    \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u048a\u046c\u0467\u044a\u0491\u0470\u048a\u044c\u0468\u048d\u0474\u045d", (byte)32, 67);
                }
            }
        }
    }

    public static String d(String string, boolean bl) {
        return string != null && !string.isEmpty() ? (bl ? e : d).matcher(string).replaceAll((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)b, (long)d)) : string;
    }

    private static String a(String string, char c, char c2, boolean bl, boolean bl2) {
        if (string == null || string.isEmpty()) {
            return string;
        }
        char[] cArray = string.toCharArray();
        block0: for (int i = ao; i < cArray.length - ap; ++i) {
            if (cArray[i] != c) continue;
            char c3 = cArray[i + aq];
            if (bl2 && c3 == ar && cArray.length > i + as) {
                for (int j = i + at; j <= i + au; ++j) {
                    char c4 = cArray[j];
                    if (((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)(av & aw), (long)ax)).indexOf(c4) == ay) continue block0;
                }
                cArray[i] = c2;
                i += 7;
                continue;
            }
            if (!bl || ((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e83", (int)az, (long)ba)).indexOf(c3) <= bb) continue;
            cArray[i] = c2;
            cArray[++i] = Character.toLowerCase(cArray[i]);
        }
        return new String(cArray);
    }

    public static String n(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.d(string, a != 0);
    }

    private static String a(int n, long l) {
        l ^= 0x54L;
        l ^= 0x73AE1053A7CDDE8CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(22 + 46), (byte)(7 + 62), (byte)(8 + 75), 47, (byte)(43 + 24), (byte)(22 + 44), (byte)(16 + 51), (byte)(3 + 44), (byte)(15 + 65), (byte)(5 + 70), (byte)(54 + 13), (byte)(5 + 78), (byte)(34 + 19), (byte)(52 + 28), (byte)(91 + 6), (byte)(63 + 37), (byte)(9 + 91), (byte)(26 + 79), (byte)(62 + 48), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(36 + 33), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u052c\u0539\u0538\u04fb\u053b\u0537\u0532\u053b\u0546\u0535\u0502\u0540\u0544\u053d\u0540\u0546\u0508\u089c\u088d\u0895\u0897\u0892\u089f\u08a6\u0895\u0885\u089d", (byte)92, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = (0 >>> 2 | 0 << ~2 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-6789560037720931569L);
        e = 0 >>> 151 | 0 << -151;
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-8374827106555346161L);
        h = Long.reverse(0x2A00000000000000L);
        i = Integer.reverse(-452984832);
        j = Integer.reverse(0x64000000);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = Integer.reverse(Integer.MIN_VALUE);
        m = 0x13000000 >>> 23 | 0x13000000 << ~23 + 1;
        n = Integer.reverse(-452984832);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(Integer.MIN_VALUE);
        q = Integer.reverse(0x64000000);
        r = 2736128 >>> 206 | 2736128 << ~206 + 1;
        s = 16 >>> 196 | 16 << -196;
        t = Integer.reverse(0);
        u = 0x26000000 >>> 56 | 0x26000000 << -56;
        v = (-1677721598 >>> 154 | -1677721598 << ~154 + 1) & 0xFFFFFFFF;
        w = Integer.reverse(0);
        x = Integer.reverse(Integer.MIN_VALUE);
        y = (2 >>> 220 | 2 << ~220 + 1) & 0xFFFFFFFF;
        z = (8 >>> 35 | 8 << ~35 + 1) & 0xFFFFFFFF;
        aa = Integer.reverse(0x40000000);
        ab = Integer.reverse(-1);
        ac = Long.reverse(-6789560037720931569L);
        ad = (0 >>> 121 | 0 << -121) & 0xFFFFFFFF;
        ae = Integer.reverse(-452984832);
        af = Integer.reverse(Integer.MIN_VALUE);
        ag = Integer.reverse(-452984832);
        ah = Integer.reverse(0x40000000);
        ai = (0xA700000 >>> 244 | 0xA700000 << -244) & 0xFFFFFFFF;
        aj = (0x180000 >>> 211 | 0x180000 << ~211 + 1) & 0xFFFFFFFF;
        ak = 21889024 >>> 81 | 21889024 << -81;
        al = 0x4000000 >>> 24 | 0x4000000 << -24;
        am = 1400897536 >>> 119 | 1400897536 << ~119 + 1;
        an = Integer.reverse(-1610612736);
        ao = Integer.reverse(0);
        ap = (0x2000000 >>> 25 | 0x2000000 << ~25 + 1) & 0xFFFFFFFF;
        aq = 0x40000000 >>> 62 | 0x40000000 << ~62 + 1;
        ar = 0x2300000 >>> 84 | 0x2300000 << ~84 + 1;
        as = Integer.reverse(-536870912);
        at = (0x800000 >>> 54 | 0x800000 << -54) & 0xFFFFFFFF;
        au = (0x3800000 >>> 55 | 0x3800000 << ~55 + 1) & 0xFFFFFFFF;
        av = Integer.reverse(-1073741824);
        aw = Integer.reverse(-1);
        ax = Long.reverse(-6789560037720931569L);
        ay = -1 >>> 194 | -1 << -194;
        az = 2048 >>> 105 | 2048 << -105;
        ba = Long.reverse(-6789560037720931569L);
        bb = -1 >>> 173 | -1 << ~173 + 1;
        bc = Integer.reverse(0);
        bd = Integer.reverse(0x40000000);
        be = 0x800000 >>> 23 | 0x800000 << ~23 + 1;
        bf = 0x8C00000 >>> 214 | 0x8C00000 << -214;
        bg = Integer.reverse(-1610612736);
        bh = Long.reverse(-8374827106555346161L);
        bi = Long.reverse(0x2A00000000000000L);
        bj = (-1 >>> 57 | -1 << -57) & 0xFFFFFFFF;
        bk = (8192 >>> 109 | 8192 << -109) & 0xFFFFFFFF;
        bl = 448 >>> 6 | 448 << ~6 + 1;
        bm = Integer.reverse(Integer.MIN_VALUE);
        bn = Integer.reverse(Integer.MIN_VALUE);
        bo = (3 >>> 223 | 3 << -223) & 0xFFFFFFFF;
        bp = Long.reverse(-6789560037720931569L);
        bq = Integer.reverse(-1);
        br = 425984 >>> 111 | 425984 << -111;
        bs = -2147483642 >>> 63 | -2147483642 << ~63 + 1;
        bt = Integer.reverse(-452984832);
        bu = Integer.reverse(0x64000000);
        bv = Integer.reverse(-1006632960);
        bw = Integer.reverse(-536870912);
        bx = Long.reverse(-6789560037720931569L);
        by = 4 >>> 31 | 4 << -31;
        bz = Long.reverse(-8374827106555346161L);
        ca = Long.reverse(0x2A00000000000000L);
        cb = 0x900000 >>> 244 | 0x900000 << ~244 + 1;
        cc = (-1 >>> 83 | -1 << -83) & 0xFFFFFFFF;
        cd = Long.reverse(-6789560037720931569L);
        ce = (0xA00000 >>> 180 | 0xA00000 << ~180 + 1) & 0xFFFFFFFF;
        cf = Long.reverse(-6789560037720931569L);
        cg = (0x58000000 >>> 155 | 0x58000000 << ~155 + 1) & 0xFFFFFFFF;
        ch = Long.reverse(-8374827106555346161L);
        ci = Long.reverse(0x2A00000000000000L);
        cj = Integer.reverse(0x30000000);
        ck = Long.reverse(-8374827106555346161L);
        cl = Long.reverse(0x2A00000000000000L);
        a = new String[br];
        b = new String[bs];
        \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.b();
        d = (char)bt;
        c = (char)bu;
        b = (char)bv;
        bu = \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)bw, (long)bx);
        bv = \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e83", (int)by, (long)(bz ^ ca));
        d = Pattern.compile((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e86", (int)(cb & cc), (long)cd));
        e = Pattern.compile((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e89", (int)ce, (long)cf));
        f = Pattern.compile((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e8c", (int)cg, (long)(ch ^ ci)));
        g = Pattern.compile((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e8f", (int)cj, (long)(ck ^ cl)));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u04e5\u0507\u0509\u04e9\u050d\u052c\u0524\u053a\u0526\u04f5\u0533\u0529\u0537\u0531\u04fa\u051f\u0541\u0540\u0538\u053e\u0538\u050d", (byte)1, 69), \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0520\u052d\u052c\u04ef\u052f\u052b\u0526\u052f\u053a\u0529\u04f6\u0534\u0538\u0531\u0534\u053a\u04fc\u0890\u0881\u0889\u088b\u0886\u0893\u089a\u0889\u0879\u0891\u0512", (byte)1, 70) + string + \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u04f7", (byte)1, 70) + methodType.toString(), exception);
        }
    }

    public static String o(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.e(string, e != 0);
    }

    public static String s(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.a(string, (char)u, (char)v, w != 0, x != 0);
    }

    public static String f(String string, boolean bl) {
        if (string == null || string.isEmpty()) {
            return string;
        }
        Matcher matcher = (bl ? g : f).matcher(string);
        StringBuffer stringBuffer = new StringBuffer(string.length() + y);
        while (matcher.find()) {
            String string2 = matcher.group(z).toLowerCase(Locale.ROOT);
            matcher.appendReplacement(stringBuffer, (String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)(aa & ab), (long)ac) + string2.charAt(ad) + (char)ae + string2.charAt(af) + (char)ag + string2.charAt(ah) + (char)ai + string2.charAt(aj) + (char)ak + string2.charAt(al) + (char)am + string2.charAt(an));
        }
        return matcher.appendTail(stringBuffer).toString();
    }

    public static String e(String string, boolean bl) {
        return string != null && !string.isEmpty() ? (bl ? g : f).matcher(string).replaceAll((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.c("\u3e80", (int)f, (long)(g ^ h))) : string;
    }

    public static String c(String string, boolean bl) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.e(\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.d(string, bl), bl);
    }

    public static String p(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.a(string, (char)i, (char)j, k != 0, l != 0);
    }

    public static String r(String string) {
        return \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.a(string, (char)q, (char)r, s != 0, t != 0);
    }
}

