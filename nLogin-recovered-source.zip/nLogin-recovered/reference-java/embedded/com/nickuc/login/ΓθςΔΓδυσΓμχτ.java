/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

class \u0393\u03b8\u03c2\u0394\u0393\u03b4\u03c5\u03c3\u0393\u03bc\u03c7\u03c4 {
}

