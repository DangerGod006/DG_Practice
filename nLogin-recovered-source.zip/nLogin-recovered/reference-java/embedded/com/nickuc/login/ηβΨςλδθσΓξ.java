/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be
extends Enum<\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be> {
    public static final /* enum */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be a;
    public static final /* enum */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be b;
    public static final /* enum */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be c;
    public static final /* enum */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be d;
    private final boolean aA;
    private static final /* synthetic */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static long i;
    private static long j;
    private static int k;
    private static int l;
    private static int m;
    private static int n;
    private static long o;
    private static int p;
    private static int q;
    private static int r;
    private static long s;
    private static long t;
    private static int u;
    private static int v;
    private static int w;
    private static long x;
    private static int y;
    private static int z;

    private static /* synthetic */ \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[] a() {
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[] \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray = new \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[a];
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray[\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b] = a;
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray[\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.c] = b;
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray[\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.d] = c;
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray[\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.e] = d;
        return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03beArray;
    }

    static {
        a = Integer.reverse(0x20000000);
        b = Integer.reverse(0);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = 65536 >>> 79 | 65536 << -79;
        e = Integer.reverse(-1073741824);
        f = Integer.reverse(0x20000000);
        g = Integer.reverse(0x20000000);
        h = 0 >>> 195 | 0 << -195;
        i = Long.reverse(5526113298936297864L);
        j = Long.reverse(-4179340454199820288L);
        k = Integer.reverse(0);
        l = 0x20000000 >>> 157 | 0x20000000 << ~157 + 1;
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Integer.reverse(-1);
        o = Long.reverse(-8453059944421721720L);
        p = (2048 >>> 171 | 2048 << ~171 + 1) & 0xFFFFFFFF;
        q = Integer.reverse(0);
        r = 4096 >>> 43 | 4096 << -43;
        s = Long.reverse(5526113298936297864L);
        t = Long.reverse(-4179340454199820288L);
        u = Integer.reverse(0x40000000);
        v = (0 >>> 42 | 0 << ~42 + 1) & 0xFFFFFFFF;
        w = 0xC00000 >>> 214 | 0xC00000 << -214;
        x = Long.reverse(-8453059944421721720L);
        y = (192 >>> 198 | 192 << ~198 + 1) & 0xFFFFFFFF;
        z = (0 >>> 171 | 0 << ~171 + 1) & 0xFFFFFFFF;
        a = new String[f];
        b = new String[g];
        \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b();
        a = new \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be(l != 0);
        b = new \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be(q != 0);
        c = new \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be(v != 0);
        d = new \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be(z != 0);
        a = \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a();
    }

    public static \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be valueOf(String string) {
        return Enum.valueOf(\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.class, string);
    }

    static /* synthetic */ boolean a(\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be2) {
        return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be2.aA;
    }

    private static void b() {
        int n;
        c = 1269757612221336882L;
        long l = c ^ 0x853F704D16F80991L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(37 + 32), 83, (byte)(37 + 10), (byte)(20 + 47), (byte)(31 + 35), (byte)(63 + 4), (byte)(26 + 21), (byte)(24 + 56), (byte)(60 + 15), (byte)(29 + 38), (byte)(81 + 2), (byte)(21 + 32), (byte)(73 + 7), (byte)(15 + 82), (byte)(90 + 10), (byte)(87 + 13), 105, (byte)(47 + 63), (byte)(46 + 57)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(64 + 4), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0123\u010f\u012a\u00ef\u0106\u00f5\u0106\u0138\u0139\u012d\u0126\u0101", (byte)29, 65);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u052f\u0524\u053c\u0522\u0540\u0542\u052b\u0545\u0532\u0528\u055b\u0559\u052d\u052f\u0558\u0532\u0556\u0554\u0561\u053d\u0560\u0555\u052c\u052d", (byte)29, 70);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u052c\u052e\u050b\u052e\u0512\u0554\u0529\u0553\u0524\u0554\u0556\u0521", (byte)29, 69);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[3] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0549\u0554\u054b\u0547\u0552\u051f\u0530\u0541\u051a\u054e\u051b\u0521", (byte)29, 69);
                    continue block7;
                }
                case 1: {
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0107\u010d\u00fe\u00ef\u0122\u0123\u0135\u010b\u0103\u0124\u012a\u0101", (byte)29, 65);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0462\u0457\u046f\u0455\u0473\u0475\u045e\u0478\u0465\u045b\u048d\u0442\u0490\u0491\u0463\u0469\u048f\u0495\u0478\u0479\u0467\u0498\u045f\u0460", (byte)29, 68);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u052c\u050f\u0535\u0535\u0531\u0551\u0518\u0541\u0559\u0544\u0550\u0538\u055f\u0534\u053e\u0520\u0537\u052c\u054c\u0555\u0554\u053f\u052c\u052d", (byte)29, 70);
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[3] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0476\u0467\u0479\u047c\u0463\u045b\u045f\u047f\u0446\u048a\u0485\u0481\u0489\u0473\u0450\u046e\u047e\u0450\u046e\u0450\u0487\u0462\u045f\u0460", (byte)29, 67);
                    continue block7;
                }
                case 2: {
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u00fd\u0103\u00f0\u0107\u0136\u0125\u0107\u0108\u00f1\u0137\u0113\u010e\u0132\u0120\u0134\u012f\u0117\u0121\u00fe\u0120\u0134\u011f\u010c\u010d", (byte)29, 66);
                    continue block7;
                }
                case 4: {
                    \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u00ee\u0104\u0133\u0121\u012a\u0111\u0117\u00f3\u00f8\u011c\u012a\u0109\u011b\u012c\u013e\u00f8\u0101\u0114\u0112\u0142\u0105\u011f\u010c\u010d", (byte)29, 65);
                }
            }
        }
    }

    public static \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[] values() {
        return (\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be[])a.clone();
    }

    @Generated
    private \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be(boolean bl) {
        this.aA = bl;
    }

    private static String a(int n, long l) {
        l ^= 0x63L;
        l ^= 0x853F704D16F80991L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(5 + 64), (byte)(40 + 43), (byte)(40 + 7), (byte)(60 + 7), (byte)(13 + 53), (byte)(7 + 60), 47, (byte)(7 + 73), (byte)(4 + 71), (byte)(7 + 60), (byte)(33 + 50), (byte)(17 + 36), (byte)(34 + 46), (byte)(9 + 88), (byte)(58 + 42), (byte)(45 + 55), (byte)(83 + 22), (byte)(87 + 23), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(18 + 51), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u012c\u0139\u0138\u00fb\u013b\u0137\u0132\u013b\u0146\u0135\u0102\u0140\u0144\u013d\u0140\u0146\u0108\u0491\u048d\u0484\u049f\u0499\u0493\u0498\u04a4\u0475\u04a1", (byte)37, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u03e0\u0402\u0404\u03e4\u0408\u0427\u041f\u0435\u0421\u03f0\u042e\u0424\u0432\u042c\u03f5\u041a\u043c\u043b\u0433\u0439\u0433\u0408", (byte)1, 67), \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0520\u052d\u052c\u04ef\u052f\u052b\u0526\u052f\u053a\u0529\u04f6\u0534\u0538\u0531\u0534\u053a\u04fc\u0885\u0881\u0878\u0893\u088d\u0887\u088c\u0898\u0869\u0895\u0512", (byte)1, 70) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u03f2", (byte)1, 67) + methodType.toString(), exception);
        }
    }
}

