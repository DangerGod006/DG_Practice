/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4
extends Enum<\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4> {
    public static final /* enum */ \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4 b;
    public static final /* enum */ \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4 c;
    public static final /* enum */ \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4 d;
    private static final /* synthetic */ \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static long b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static long k;
    private static int l;
    private static int m;
    private static long n;
    private static long o;
    private static int p;
    private static int q;
    private static long r;
    private static long s;
    private static int t;

    private static /* synthetic */ \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[] a() {
        \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[] \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4Array = new \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[c];
        \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4Array[\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.d] = b;
        \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4Array[\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.e] = c;
        \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4Array[\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.f] = d;
        return \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4Array;
    }

    public static \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4 valueOf(String string) {
        return Enum.valueOf(\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.class, string);
    }

    private static String a(int n, long l) {
        l ^= 0x55L;
        l ^= 0x3C26ACBB39F49FCL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), 69, 83, (byte)(31 + 16), (byte)(27 + 40), (byte)(37 + 29), (byte)(42 + 25), (byte)(42 + 5), (byte)(30 + 50), (byte)(55 + 20), (byte)(28 + 39), (byte)(37 + 46), (byte)(12 + 41), (byte)(58 + 22), (byte)(96 + 1), (byte)(42 + 58), (byte)(5 + 95), (byte)(84 + 21), (byte)(9 + 101), (byte)(36 + 67)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(28 + 41), (byte)(57 + 26)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0182\u018f\u018e\u0151\u0191\u018d\u0188\u0191\u019c\u018b\u0158\u0196\u019a\u0193\u0196\u019c\u015e\u04ed\u04eb\u04ea\u04f0\u04e9\u04ea\u04ed\u04eb\u04ec", (byte)80, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public UUID a(String string, UUID uUID) {
        switch (this.ordinal()) {
            case 0: {
                return UUID.randomUUID();
            }
            case 1: {
                return uUID != null ? uUID : \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.d(string);
            }
            case 2: {
                return \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.d(string);
            }
        }
        throw new IllegalArgumentException((String)\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.c("\u3e80", (int)a, (long)b) + (Object)((Object)this));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u04fe\u0520\u0522\u0502\u0526\u0545\u053d\u0553\u053f\u050e\u054c\u0542\u0550\u054a\u0513\u0538\u055a\u0559\u0551\u0557\u0551\u0526", (byte)26, 70), \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0466\u0473\u0472\u0435\u0475\u0471\u046c\u0475\u0480\u046f\u043c\u047a\u047e\u0477\u047a\u0480\u0442\u07d1\u07cf\u07ce\u07d4\u07cd\u07ce\u07d1\u07cf\u07d0\u0457", (byte)26, 67) + string + \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0510", (byte)26, 70) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -5246294012713698384L;
        long l = c ^ 0x3C26ACBB39F49FCL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(68 + 1), (byte)(6 + 77), (byte)(32 + 15), (byte)(45 + 22), 66, (byte)(15 + 52), (byte)(22 + 25), (byte)(75 + 5), (byte)(39 + 36), (byte)(24 + 43), (byte)(17 + 66), (byte)(4 + 49), (byte)(23 + 57), (byte)(93 + 4), (byte)(94 + 6), (byte)(73 + 27), (byte)(8 + 97), 110, (byte)(50 + 53)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(3 + 65), (byte)(24 + 45), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0580\u0549\u057c\u0558\u055c\u0577\u055a\u0586\u0570\u057d\u057c\u0586\u0584\u056d\u0589\u0579\u0566\u055c\u0566\u054e\u0586\u0562\u0574\u0582\u0586\u0581\u0587\u0585\u0575\u055a\u0575\u0579\u0588\u0568\u0573\u057d\u058b\u056c\u056e\u059e\u0586\u0576\u0571\u056e", (byte)74, 69);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u055e\u0548\u056c\u0571\u0577\u0583\u0541\u0580\u055b\u055c\u057f\u054e", (byte)74, 70);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0536\u056f\u054b\u0538\u055d\u0564\u0580\u0555\u0564\u0580\u0551\u054e", (byte)74, 69);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[3] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u056d\u054d\u0538\u057e\u055b\u0558\u0563\u0538\u0583\u053f\u0559\u054e", (byte)74, 70);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u050d\u04d6\u0509\u04e5\u04e9\u0504\u04e7\u0513\u04fd\u050a\u0509\u0513\u0511\u04fa\u0516\u0506\u04f3\u04e9\u04f3\u04db\u0513\u04ef\u0501\u050f\u0513\u050e\u0514\u0512\u0502\u04e7\u0502\u0506\u0501\u051b\u04ea\u0524\u050f\u0528\u0529\u04f0\u04f0\u0532\u0512\u04fb", (byte)74, 68);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[1] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0531\u0538\u054c\u054d\u0571\u057a\u0577\u055c\u0570\u0571\u057c\u057d\u0563\u055b\u055a\u0586\u056c\u054b\u054e\u054d\u0583\u056c\u0559\u055a", (byte)74, 69);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0509\u04d8\u04f8\u04c7\u04e2\u04de\u04cf\u04cc\u04d4\u04eb\u0500\u04db", (byte)74, 68);
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u04e4\u050e\u050d\u0507\u04da\u04ce\u04e8\u04ec\u050d\u04e8\u04f6\u0511\u04d1\u04d4\u0514\u04e4\u0517\u04fd\u04f2\u04db\u04e8\u04e9\u04e6\u04e7", (byte)74, 67);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u04e9\u04f5\u04cc\u04d9\u04d0\u0512\u04d1\u04ee\u04eb\u0503\u0501\u04f6\u04d7\u0512\u04e9\u04d2\u051a\u0517\u04f4\u04ef\u04e8\u04fd\u04ee\u04ed\u0519\u0513\u0518\u0504\u0526\u0501\u0522\u04e2", (byte)74, 68);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u04c3\u04ff\u04ea\u04fc\u0508\u0507\u04cb\u04cf\u04c6\u0510\u04de\u04cf\u04f6\u0504\u04d4\u0509\u04f5\u04d8\u04f6\u04fd\u0521\u050f\u04e6\u04e7", (byte)74, 67);
                }
            }
        }
    }

    public static \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[] values() {
        return (\u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4[])a.clone();
    }

    static {
        a = 0 >>> 181 | 0 << -181;
        b = Long.reverse(-6350340335984014099L);
        c = 3072 >>> 106 | 3072 << -106;
        d = 0 >>> 207 | 0 << -207;
        e = Integer.reverse(Integer.MIN_VALUE);
        f = 2048 >>> 106 | 2048 << ~106 + 1;
        g = 4 >>> 192 | 4 << ~192 + 1;
        h = Integer.reverse(0x20000000);
        i = (131072 >>> 81 | 131072 << -81) & 0xFFFFFFFF;
        j = Integer.reverse(-1);
        k = Long.reverse(-6350340335984014099L);
        l = (0 >>> 48 | 0 << ~48 + 1) & 0xFFFFFFFF;
        m = (0x10000000 >>> 155 | 0x10000000 << ~155 + 1) & 0xFFFFFFFF;
        n = Long.reverse(999534255884635373L);
        o = Long.reverse(-6196953087261802496L);
        p = (0x8000000 >>> 155 | 0x8000000 << -155) & 0xFFFFFFFF;
        q = 12288 >>> 108 | 12288 << ~108 + 1;
        r = Long.reverse(999534255884635373L);
        s = Long.reverse(-6196953087261802496L);
        t = Integer.reverse(0x40000000);
        a = new String[g];
        b = new String[h];
        \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.b();
        b = new \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4();
        c = new \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4();
        d = new \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4();
        a = \u03bd\u03ba\u03b8\u03bd\u03b5\u03b5\u03b7\u03b4\u03b4.a();
    }
}

