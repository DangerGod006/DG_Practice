/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2;

class \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7 {
    private static int a = 0x100000 >>> 52 | 0x100000 << ~52 + 1;
    private static int d;
    private static int b;
    private static int c;
    static final /* synthetic */ int[] af;
    private static int e;

    static {
        b = Integer.reverse(0x40000000);
        c = 49152 >>> 206 | 49152 << ~206 + 1;
        d = 4 >>> 224 | 4 << ~224 + 1;
        e = Integer.reverse(-1610612736);
        af = new int[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.values().length];
        try {
            \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7.af[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.a.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7.af[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7.af[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.c.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7.af[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.d.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03b9\u03b5\u0393\u03c5\u03b8\u03a9\u03c3\u03a9\u03b5\u03bc\u03bf\u03c2\u03b7.af[\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.e.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

