/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0;
import com.nickuc.login.\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393;
import com.nickuc.login.\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 {
    default public <T> T g() {
        return this.b((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public boolean ar() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public List<Integer> j() {
        return this.d((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public List<String> b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, Object ... objectArray) {
        return new ArrayList<String>(this.a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, objectArray));
    }

    default public String a(Object ... objectArray) {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a(), objectArray);
    }

    public Object a();

    default public boolean a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (Boolean)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public List<Integer> d(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return new ArrayList<Integer>(this.c(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932));
    }

    default public List<?> h() {
        return this.b((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public List<String> a(Object ... objectArray) {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a(), objectArray);
    }

    default public List<?> g() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public <T> T b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        Object object = \u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.a(this, \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
        if (object == null && (object = this.a()) == null) {
            throw new IllegalArgumentException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0187\u01a9\u01ab\u01a7\u01bc\u01b4\u01bd\u016a\u01c1\u01ad\u01b9\u01c3\u01b4\u0170\u01b4\u01b3\u01c1\u01c2\u01c4\u01ca\u0177\u01ba\u01be\u017a\u01c9\u01d1\u01c9\u01ca\u0180", (byte)98, 66));
        }
        try {
            return (T)object;
        }
        catch (Throwable throwable) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0198\u01b2\u01a6\u01a8\u01b3\u01ad\u0169\u01be\u01ba\u016c\u01b0\u01af\u01c2\u01c4\u0171", (byte)98, 66) + this + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0163\u01b8\u01b4\u0166\u01b9\u01ad\u01ba\u01bf\u01b0\u01bf\u01c1\u01b3\u01b3\u0170\u01c5\u01cb\u01c3\u01b9\u0176", (byte)98, 65), throwable);
        }
    }

    default public double c() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    public \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 a();

    public \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 a();

    default public List<String> a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, Object ... objectArray) {
        List list = (List)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
        if (objectArray != null && objectArray.length > 0) {
            String[] stringArray = list.toArray(new String[0]);
            boolean bl = false;
            for (int i = 0; i < stringArray.length; ++i) {
                String string = stringArray[i];
                String string2 = \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(string, objectArray);
                if (!bl && !string.equals(string2)) {
                    bl = true;
                }
                stringArray[i] = string2;
            }
            if (bl) {
                return \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(stringArray);
            }
        }
        return list;
    }

    default public Object a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public List<?> b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return new ArrayList(this.a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932));
    }

    public int a();

    default public long a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (Long)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public List<Integer> i() {
        return this.c((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public Object a(\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b62, Object object) {
        return object;
    }

    default public int a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (Integer)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public double a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (Double)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public short a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (Short)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public List<String> b(Object ... objectArray) {
        return this.b((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a(), objectArray);
    }

    default public Object f() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public long g() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public List<?> a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (List)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public int r() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }

    default public List<Integer> c(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932) {
        return (List)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932);
    }

    default public String a(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932, Object ... objectArray) {
        return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a((String)this.b(\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u03932), objectArray);
    }

    default public short a() {
        return this.a((\u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393)this.a());
    }
}

