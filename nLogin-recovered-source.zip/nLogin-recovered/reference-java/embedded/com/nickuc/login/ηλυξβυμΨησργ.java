/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent
 *  org.bukkit.event.player.AsyncPlayerPreLoginEvent$Result
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.bukkit.\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import java.net.InetAddress;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

public class \u03b7\u03bb\u03c5\u03be\u03b2\u03c5\u03bc\u03a8\u03b7\u03c3\u03c1\u03b3
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private final nLoginBukkit k;

    @Generated
    public \u03b7\u03bb\u03c5\u03be\u03b2\u03c5\u03bc\u03a8\u03b7\u03c3\u03c1\u03b3(nLoginBukkit nLoginBukkit2) {
        this.k = nLoginBukkit2;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void b(AsyncPlayerPreLoginEvent asyncPlayerPreLoginEvent) {
        InetAddress inetAddress;
        if (asyncPlayerPreLoginEvent.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
            return;
        }
        InetAddress inetAddress2 = asyncPlayerPreLoginEvent.getAddress();
        try {
            inetAddress = asyncPlayerPreLoginEvent.getRawAddress();
        }
        catch (NoSuchMethodError noSuchMethodError) {
            inetAddress = null;
        }
        \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a(asyncPlayerPreLoginEvent.getName(), inetAddress2, inetAddress);
        if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 != null && \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a != null) {
            \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a.run();
        }
    }
}

