/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd;
import org.bukkit.entity.Player;

class \u03b6\u03c3\u03b5\u03c6\u03c0\u03b1\u03c0\u03c5\u03c2\u03a8\u03a0\u03a6\u03c9\u03bb
implements \u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd {
    \u03b6\u03c3\u03b5\u03c6\u03c0\u03b1\u03c0\u03c5\u03c2\u03a8\u03a0\u03a6\u03c9\u03bb() {
    }

    @Override
    public void a(Player player, String string, String string2, int n, int n2, int n3) {
    }

    @Override
    public void a(Player player) {
    }
}

