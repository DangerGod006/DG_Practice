/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9
extends Enum<\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9> {
    public static final /* enum */ \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 b;
    public static final /* enum */ \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 c;
    public static final /* enum */ \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 d;
    private final String bb;
    private static final /* synthetic */ \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static long i;
    private static int j;
    private static int k;
    private static long l;
    private static long m;
    private static int n;
    private static long o;
    private static int p;
    private static int q;
    private static long r;
    private static long s;
    private static int t;
    private static long u;
    private static int v;
    private static int w;
    private static long x;
    private static long y;

    @Nullable
    public static \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 a(int n) {
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.values();
        if (\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array.length > n) {
            return \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array[n];
        }
        return null;
    }

    @Generated
    private \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9(String string2) {
        this.bb = string2;
    }

    static {
        a = (0 >>> 154 | 0 << ~154 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(-1073741824);
        c = (0 >>> 104 | 0 << -104) & 0xFFFFFFFF;
        d = (0x4000000 >>> 122 | 0x4000000 << -122) & 0xFFFFFFFF;
        e = Integer.reverse(0x40000000);
        f = Integer.reverse(0x60000000);
        g = Integer.reverse(0x60000000);
        h = Integer.reverse(0);
        i = Long.reverse(4772496937393862577L);
        j = (0 >>> 185 | 0 << ~185 + 1) & 0xFFFFFFFF;
        k = 0x10000000 >>> 156 | 0x10000000 << -156;
        l = Long.reverse(-5171451039840192591L);
        m = Long.reverse(-432345564227567616L);
        n = 32 >>> 228 | 32 << -228;
        o = Long.reverse(4772496937393862577L);
        p = Integer.reverse(Integer.MIN_VALUE);
        q = 0x60000000 >>> 157 | 0x60000000 << -157;
        r = Long.reverse(-5171451039840192591L);
        s = Long.reverse(-432345564227567616L);
        t = (2 >>> 31 | 2 << ~31 + 1) & 0xFFFFFFFF;
        u = Long.reverse(4772496937393862577L);
        v = (32 >>> 100 | 32 << -100) & 0xFFFFFFFF;
        w = 0x2800000 >>> 23 | 0x2800000 << ~23 + 1;
        x = Long.reverse(-5171451039840192591L);
        y = Long.reverse(-432345564227567616L);
        a = new String[f];
        b = new String[g];
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b();
        b = new \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9((String)\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.c("\u3e83", (int)k, (long)(l ^ m)));
        c = new \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9((String)\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.c("\u3e89", (int)q, (long)(r ^ s)));
        d = new \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9((String)\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.c("\u3e8f", (int)w, (long)(x ^ y)));
        a = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.a();
    }

    private static String a(int n, long l) {
        l ^= 0x5FL;
        l ^= 0x2BDC0EBEF2B3E296L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(12 + 56), (byte)(40 + 29), (byte)(50 + 33), (byte)(44 + 3), (byte)(3 + 64), 66, (byte)(45 + 22), (byte)(37 + 10), (byte)(24 + 56), (byte)(69 + 6), (byte)(6 + 61), (byte)(80 + 3), (byte)(15 + 38), (byte)(23 + 57), (byte)(96 + 1), (byte)(86 + 14), (byte)(32 + 68), 105, (byte)(64 + 46), (byte)(65 + 38)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(48 + 35)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u04f0\u04fd\u04fc\u04bf\u04ff\u04fb\u04f6\u04ff\u050a\u04f9\u04c6\u0504\u0508\u0501\u0504\u050a\u04cc\u0851\u0851\u0857\u083c\u0858\u085e\u0863\u0859\u0841\u086e\u085a\u0872", (byte)72, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public String getName() {
        return this.bb;
    }

    private static void b() {
        int n;
        c = -8220194516740940771L;
        long l = c ^ 0x2BDC0EBEF2B3E296L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(21 + 47), (byte)(40 + 29), (byte)(11 + 72), (byte)(25 + 22), (byte)(46 + 21), (byte)(11 + 55), (byte)(50 + 17), (byte)(29 + 18), (byte)(12 + 68), 75, (byte)(66 + 1), 83, (byte)(28 + 25), (byte)(66 + 14), (byte)(38 + 59), (byte)(23 + 77), (byte)(53 + 47), (byte)(2 + 103), (byte)(77 + 33), (byte)(69 + 34)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(44 + 39)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0552\u057d\u056d\u055e\u055c\u057d\u0589\u054d\u056a\u0585\u0560\u0559", (byte)116, 67);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u058a\u0569\u0567\u0569\u05a7\u058d\u057a\u056c\u05a5\u05ae\u0593\u0578", (byte)116, 70);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u054a\u057b\u055f\u054a\u058d\u055f\u0548\u054b\u055b\u056a\u054f\u0559", (byte)116, 67);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u059a\u0594\u0574\u0597\u05a8\u0569\u0580\u0598\u05ae\u0588\u059d\u0578", (byte)116, 70);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0573\u0553\u0564\u0549\u058b\u057f\u058a\u0592\u0550\u0594\u0560\u0559", (byte)116, 68);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[5] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01d6\u019b\u01b4\u01db\u01cc\u01bc\u01c5\u01e7\u01d9\u01a1\u01b6\u01af", (byte)116, 66);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u057f\u056a\u0573\u0594\u05aa\u059a\u059e\u058a\u0590\u058c\u0571\u0580\u0584\u0571\u0575\u058c\u05b9\u0584\u0572\u0596\u0588\u05ac\u0583\u0584", (byte)116, 70);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u01ba\u01d9\u01b6\u01d6\u01ba\u01a2\u01c2\u01c7\u01c2\u01d5\u01b5\u01c0\u01ab\u01c6\u01c4\u01a9\u01ba\u01e1\u01eb\u01e3\u01ad\u01cd\u01ba\u01bb", (byte)116, 66);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[2] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u057d\u0587\u058a\u0579\u05a3\u0598\u05af\u0591\u0588\u05ab\u05a0\u0566\u058b\u05ae\u058c\u05a3\u0588\u05af\u058e\u0573\u057a\u05bc\u0583\u0584", (byte)116, 69);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0561\u0566\u0586\u055e\u0564\u0570\u0582\u0586\u055a\u0588\u0564\u0552\u056d\u0596\u056c\u0568\u0574\u0571\u056c\u058c\u0589\u058d\u0564\u0565", (byte)116, 68);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u05a7\u0576\u059c\u0576\u059e\u05a8\u057d\u056c\u059a\u058d\u05a9\u0578", (byte)116, 70);
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u019c\u0193\u01d4\u01cb\u01d7\u01e5\u01a6\u01e6\u01a8\u01a2\u01d4\u01af", (byte)116, 65);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u01c9\u01b7\u019b\u01b5\u01dc\u019e\u01d7\u01ba\u01bd\u01c2\u01e7\u01cc\u01aa\u01d9\u01ac\u01ad\u01b0\u01ba\u01aa\u01ec\u01eb\u01e3\u01ba\u01bb", (byte)116, 65);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u01cf\u01c2\u01af\u019d\u01b6\u01df\u01b1\u01c3\u01e6\u01c6\u01db\u01e7\u01e6\u01be\u01e7\u01f0\u01c4\u01ca\u01a4\u01e2\u01ad\u01c2\u01ee\u01e2\u01e2\u01b7\u01d7\u01eb\u01e4\u01f7\u01b8\u01ef", (byte)116, 66);
                }
            }
        }
    }

    private static /* synthetic */ \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] a() {
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array = new \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[b];
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array[\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.c] = b;
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array[\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.d] = c;
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array[\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.e] = d;
        return \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u055b\u057d\u057f\u055f\u0583\u05a2\u059a\u05b0\u059c\u056b\u05a9\u059f\u05ad\u05a7\u0570\u0595\u05b7\u05b6\u05ae\u05b4\u05ae\u0583", (byte)119, 70), \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0596\u05a3\u05a2\u0565\u05a5\u05a1\u059c\u05a5\u05b0\u059f\u056c\u05aa\u05ae\u05a7\u05aa\u05b0\u0572\u08f7\u08f7\u08fd\u08e2\u08fe\u0904\u0909\u08ff\u08e7\u0914\u0900\u0918\u058a", (byte)119, 70) + string + \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0554", (byte)119, 67) + methodType.toString(), exception);
        }
    }

    @Nullable
    public static \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 a(String string) {
        \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.values();
        int n = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array.length;
        for (int i = a; i < n; ++i) {
            \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92 = \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9Array[i];
            if (!\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92.bb.equalsIgnoreCase(string)) continue;
            return \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c92;
        }
        return null;
    }

    public static \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9 valueOf(String string) {
        return Enum.valueOf(\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9.class, string);
    }

    public static \u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[] values() {
        return (\u03b3\u03b2\u03b7\u039b\u03b6\u03bb\u03bf\u03b4\u039b\u03c7\u03b2\u03c9[])a.clone();
    }
}

