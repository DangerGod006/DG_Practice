/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import lombok.Generated;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class \u03c0\u03c6\u03c5\u03a8\u03b5\u03be\u03b2\u03bd\u039b\u03a0\u03c8
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private final \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 c;
    private final Server e;

    @EventHandler(priority=EventPriority.MONITOR)
    public void c(PlayerQuitEvent playerQuitEvent) {
        \u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3.b.remove(playerQuitEvent.getPlayer());
    }

    @Generated
    public \u03c0\u03c6\u03c5\u03a8\u03b5\u03be\u03b2\u03bd\u039b\u03a0\u03c8(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932, Server server) {
        this.c = \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932;
        this.e = server;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void c(PlayerJoinEvent playerJoinEvent) {
        Player player = playerJoinEvent.getPlayer();
        \u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3.b.put(player, \u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3.b(this.c, this.e, player));
    }
}

