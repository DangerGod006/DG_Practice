/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.event.CommandType
 *  com.nickuc.login.api.enums.event.EventEnum
 *  com.nickuc.login.api.event.internal.CancellableEvent
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.event.CommandType;
import com.nickuc.login.api.enums.event.EventEnum;
import com.nickuc.login.api.event.internal.CancellableEvent;
import com.nickuc.login.\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b9\u03b9\u03c6\u0394\u03b2\u03c7\u03c5;
import com.nickuc.login.\u03b5\u03b3\u03c9\u03c0\u03a8\u03c0\u03b5\u03bf\u03be\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c2\u03bb\u03b5\u03bd\u03c6\u03b5\u03a8\u039b\u03bd\u03b3\u03b5\u03a6\u03a6\u03bf;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1
extends \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6> {
    private static int ag;
    protected final \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 a;
    private static int n;
    private static int b;
    private static int h;
    private static int q;
    private static int ap;
    private static int ao;
    private static int u;
    private static int ae;
    private static int aq;
    private static int r;
    private static int ak;
    private static int j;
    private static int ad;
    private static int ah;
    private static int at;
    private static int as;
    private static int ab;
    private static int ar;
    private static long a;
    private static int t;

    @Override
    protected boolean a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray, boolean bl) {
        return (!bl || super.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray, ar != 0) ? as : at) != 0;
    }

    @Override
    protected final List<String> a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        return this.b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray);
    }

    protected List<String> b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        return null;
    }

    public \u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92) {
        super(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92.e());
        this.a = \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92;
    }

    protected abstract void a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba var1, String var2, String[] var3);

    static {
        a = Long.reverse(2562548187973812224L);
        b = Integer.reverse(0);
        h = Integer.reverse(0);
        j = 0 >>> 131 | 0 << ~131 + 1;
        n = Integer.reverse(Integer.MIN_VALUE);
        q = Integer.reverse(0x40000000);
        r = Integer.reverse(0x40000000);
        t = Integer.reverse(Integer.MIN_VALUE);
        u = (524288 >>> 51 | 524288 << ~51 + 1) & 0xFFFFFFFF;
        ab = Integer.reverse(0);
        ad = (0 >>> 120 | 0 << -120) & 0xFFFFFFFF;
        ae = (16 >>> 2 | 16 << ~2 + 1) & 0xFFFFFFFF;
        ag = Integer.reverse(0);
        ah = Integer.reverse(Integer.MIN_VALUE);
        ak = Integer.reverse(0x40000000);
        ao = (0x60000000 >>> 93 | 0x60000000 << -93) & 0xFFFFFFFF;
        ap = Integer.reverse(Integer.MIN_VALUE);
        aq = 0 >>> 133 | 0 << -133;
        ar = 2048 >>> 139 | 2048 << -139;
        as = Integer.reverse(Integer.MIN_VALUE);
        at = Integer.reverse(0);
    }

    @Override
    protected final void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        if (\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
            int n;
            \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0 \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c02;
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2;
            \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942 = ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).a();
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            Long l = (Long)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.k);
            if (l == null || System.currentTimeMillis() - l > a) {
                return;
            }
            String[] stringArray2 = (String[])\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.j);
            if (stringArray2 != null) {
                stringArray = stringArray2;
            }
            if ((\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c02 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a()).c(\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.c) || (\u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c02 == \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.c || \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c02 == \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.f) && !this.a.m()) {
                return;
            }
            if (!super.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray, b != 0)) {
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.y, new Object[h]);
                return;
            }
            CommandType commandType = null;
            int n2 = j;
            if (this instanceof \u03c2\u03bb\u03b5\u03bd\u03c6\u03b5\u03a8\u039b\u03bd\u03b3\u03b5\u03a6\u03a6\u03bf) {
                commandType = CommandType.LOGIN;
                n2 = \u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1.n;
            } else if (this instanceof \u03a9\u03b9\u03b9\u03c6\u0394\u03b2\u03c7\u03c5) {
                commandType = CommandType.REGISTER;
                n2 = q;
            } else if (this instanceof \u03b5\u03b3\u03c9\u03c0\u03a8\u03c0\u03b5\u03bf\u03be\u03a0\u03c5) {
                commandType = CommandType.CHANGE_PASSWORD;
                n2 = r;
            } else if (this instanceof \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6) {
                commandType = CommandType.UNREGISTER;
                n2 = t;
            }
            int n3 = n = \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c02 != \u03bf\u03c9\u03bb\u03b8\u03c2\u03b4\u03c5\u039b\u03b2\u03c3\u03a8\u03b4\u03b3\u03c0.f && !this.a.l() && !\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) ? u : ab;
            if (commandType != null) {
                String[] stringArray3 = stringArray.length <= n2 ? new String[ad] : Arrays.copyOfRange(stringArray, n2, stringArray.length);
                Object[] objectArray = new Object[ae];
                objectArray[\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1.ag] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
                objectArray[\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1.ah] = commandType;
                objectArray[\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1.ak] = string;
                objectArray[\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1.ao] = stringArray3;
                CancellableEvent cancellableEvent = (CancellableEvent)((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).a(EventEnum.PRE_COMMAND_EXECUTE, objectArray);
                cancellableEvent.setCancelled(n != 0);
                int n4 = n = !((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).callEvent(cancellableEvent) ? ap : aq;
            }
            if (n != 0) {
                return;
            }
        }
        this.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string.toLowerCase(Locale.ENGLISH), stringArray);
    }
}

