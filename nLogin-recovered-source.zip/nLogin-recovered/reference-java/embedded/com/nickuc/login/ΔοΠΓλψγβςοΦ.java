/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.guava.common.collect.Multimap
 *  net.md_5.bungee.api.ProxyServer
 *  net.md_5.bungee.api.plugin.Command
 *  net.md_5.bungee.api.plugin.Plugin
 *  net.md_5.bungee.api.plugin.PluginManager
 */
package com.nickuc.login;

import com.nickuc.login.lib.guava.common.collect.Multimap;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Handler;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.plugin.Command;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.plugin.PluginManager;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6 {
    private static long q;
    private static int o;
    private static long t;
    private static long ad;
    private static int l;
    private static int ac;
    private static int ak;
    private static String[] a;
    private static long w;
    private static int aj;
    private static long i;
    private static long ah;
    private static int p;
    private static long g;
    private static int y;
    private static long c;
    private static int ae;
    private static long n;
    private static long j;
    private static int r;
    private static String[] b;
    private static int x;
    private static int v;
    private static long m;
    private static int ai;
    private static int f;
    private static long d;
    private static long e;
    private static int ab;
    private static int u;
    private static int b;
    private static int a;
    private static long z;
    private static int s;
    private static int h;
    private static long ag;
    private static int k;
    private static int af;
    private static long aa;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u00ed\u010f\u0111\u00f1\u0115\u0134\u012c\u0142\u012e\u00fd\u013b\u0131\u013f\u0139\u0102\u0127\u0149\u0148\u0140\u0146\u0140\u0115", (byte)35, 66), \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0481\u048e\u048d\u0450\u0490\u048c\u0487\u0490\u049b\u048a\u0457\u0495\u0499\u0492\u0495\u049b\u045d\u07c3\u07ef\u07d1\u07c5\u07ee\u07fc\u07e8\u07e8\u07f9\u07f7\u07df\u0474", (byte)35, 67) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u00ff", (byte)35, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 1771948665714578483L;
        long l = c ^ 0x973FB6ABDBD4490CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(29 + 40), (byte)(74 + 9), (byte)(32 + 15), (byte)(47 + 20), (byte)(44 + 22), (byte)(26 + 41), 47, (byte)(22 + 58), (byte)(60 + 15), (byte)(4 + 63), (byte)(44 + 39), (byte)(40 + 13), 80, (byte)(32 + 65), (byte)(57 + 43), (byte)(95 + 5), (byte)(3 + 102), (byte)(72 + 38), (byte)(2 + 101)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(55 + 13), 69, (byte)(9 + 74)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u053a\u0535\u0538\u0500\u0547\u050a\u0540\u0507\u050c\u053d\u050f\u050d\u051d\u0548\u054e\u0556\u052a\u0523\u0551\u0536\u052a\u0535\u052e\u0553\u053a\u054f\u0529\u0514\u0530\u0530\u0540\u053a\u0544\u0532\u0567\u0521\u0526\u0549\u0527\u0559\u0566\u0558\u0530\u0536", (byte)18, 69);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e1\u00ef\u0119\u0120\u00f9\u0122\u010a\u0107\u011e\u00ed\u00ec\u00ec\u010a\u012c\u0134\u00f5\u0114\u0100\u0101\u010f\u00f9\u010f\u0139\u0108\u00f7\u0133\u010f\u00f8\u0139\u0136\u013a\u00fd\u0136\u0136\u0125\u0146\u010a\u011d\u011e\u013f\u0100\u0138\u0138\u0120\u0150\u0129\u0128\u012a\u0122\u0132\u014d\u0111\u0146\u0126", (byte)18, 66);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0538\u0519\u0506\u0544\u0502\u051d\u0546\u0505\u0548\u0545\u0548\u0551\u0544\u0513\u053e\u0547\u0511\u0522\u052f\u0533\u053c\u0524\u0521\u0522", (byte)18, 69);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e3\u0104\u011d\u0100\u0124\u0101\u0128\u0128\u011a\u0117\u0131\u00f0\u0108\u0109\u012d\u010c\u00f5\u010f\u012a\u0125\u00f4\u00f1\u011a\u00f3\u011f\u013a\u0116\u0119\u0134\u0117\u012f\u0139\u0134\u010b", (byte)18, 66);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u00fb\u00d3\u0118\u00fe\u00dd\u010d\u010f\u011d\u0125\u0121\u0118\u00eb", (byte)18, 66);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[5] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0541\u0500\u04ff\u052b\u0549\u0544\u053f\u053b\u053b\u052f\u0523\u0520\u0527\u054d\u0523\u052a\u0535\u054c\u054e\u051a\u052e\u0544\u053a\u052c\u0538\u0558\u0552\u054e\u054f\u0538\u0530\u0522", (byte)18, 69);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0510\u0541\u052a\u0506\u0546\u0538\u052a\u0507\u050a\u0540\u052c\u050c\u0531\u0528\u0534\u0511\u052e\u0556\u054b\u055a\u052e\u0528\u0527\u0548\u0549\u0535\u055c\u0532\u0550\u0534\u053e\u0565", (byte)18, 70);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[7] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0437\u043e\u0434\u041f\u043c\u045c\u0425\u0464\u0464\u0439\u042b\u044c\u0465\u0448\u046c\u0449\u0470\u0470\u0462\u045f\u0479\u047a\u046e\u0473\u0445\u047e\u0475\u045b\u0436\u0462\u0438\u0451\u044e\u0462\u045f\u047e\u047f\u047b\u0458\u0475\u0456\u048a\u0486\u046d\u0490\u046b\u046b\u044b\u046b\u044c\u0476\u046a\u0487\u048e\u0459\u0493\u0491\u0494\u0450\u046b\u048d\u049e\u048a\u0471\u0477\u0465\u045c\u04a8\u047f\u047e\u0489\u0499\u04a4\u0496\u0479\u0480\u0478\u04b2\u048d\u047b\u048b\u0470\u0476\u0486\u0483\u0491\u047e\u047f", (byte)18, 67);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[8] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e2\u00e7\u00f8\u0128\u00f8\u00f5\u00fc\u011a\u0128\u00fa\u010e\u00f1\u0127\u0134\u00f3\u010c\u010d\u00f4\u0131\u0116\u010d\u00f6\u012c\u00f9\u010b\u0136\u0108\u00f9\u0115\u0115\u011b\u0144\u0147\u0107\u0131\u0140\u0146\u0127\u0139\u0149\u0143\u0140\u0121\u0126\u010e\u0110\u013f\u0112\u0136\u012b\u014e\u0133\u013a\u014d", (byte)18, 66);
                    continue block7;
                }
                case 1: {
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u010f\u010a\u010d\u00d5\u011c\u00df\u0115\u00dc\u00e1\u0112\u00e4\u00e2\u00f2\u011d\u0123\u012b\u00ff\u00f8\u0126\u010b\u00ff\u010a\u0103\u0128\u010f\u0124\u00fe\u00e9\u0105\u0105\u0115\u010f\u00f5\u012d\u0112\u0130\u0113\u00fe\u010b\u0132\u0112\u0100\u011a\u010b", (byte)18, 65);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u051a\u0521\u0517\u0502\u051f\u053f\u0508\u0547\u0547\u051c\u050c\u051a\u0544\u054b\u0524\u054d\u0535\u0532\u0549\u0518\u0517\u0517\u0535\u0557\u055f\u0520\u053f\u052b\u052c\u053a\u0524\u053a\u0564\u0533\u0522\u055e\u053a\u0523\u0564\u0561\u0565\u0528\u0561\u0561\u0550\u0571\u0535\u0548\u0549\u056a\u052b\u0563\u0563\u054b\u0548\u0552\u053a\u0551\u053e\u0539\u0563\u0561\u055e\u0562", (byte)18, 69);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u010d\u00ee\u00db\u0119\u00d7\u00f2\u011b\u00da\u011d\u011a\u011e\u00e0\u00f1\u0113\u00e1\u0125\u00f4\u0124\u012f\u00fe\u0129\u012f\u00f6\u00f7", (byte)18, 65);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e3\u0104\u011d\u0100\u0124\u0101\u0128\u0128\u011a\u0117\u0131\u00f0\u0108\u0109\u012d\u010c\u00f5\u010f\u012a\u0125\u00f4\u00f1\u0113\u00fc\u0112\u00fc\u0141\u0114\u0133\u0115\u0102\u0126\u011e\u00f9\u0133\u0111\u00fc\u010b\u0139\u0128\u014e\u0107\u0131\u014f\u0116\u0117", (byte)18, 65);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[4] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0111\u00f0\u0115\u00d7\u010c\u00ff\u00dc\u0100\u0105\u0104\u0111\u0104\u00f1\u0106\u0118\u011e\u011f\u0128\u012a\u010e\u010e\u0109\u00f6\u00f7", (byte)18, 65);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[5] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u0116\u00d5\u00d4\u0100\u011e\u0119\u0114\u0110\u0110\u0104\u00f8\u00f5\u00fc\u0122\u00f8\u00ff\u010a\u0121\u0123\u00ef\u0103\u0119\u0131\u0104\u00ea\u0125\u00f2\u00f5\u010f\u0104\u0115\u010f", (byte)18, 66);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[6] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u042d\u045e\u0447\u0423\u0463\u0455\u0447\u0424\u0427\u045d\u0449\u0429\u044e\u0445\u0451\u042e\u044b\u0473\u0468\u0477\u044b\u0447\u044b\u046e\u0473\u0434\u045e\u0459\u0469\u0454\u045a\u0442", (byte)18, 68);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[7] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e3\u0104\u011d\u0100\u0124\u0101\u0128\u0128\u011a\u0117\u0131\u0132\u0126\u012b\u00fd\u0136\u012d\u0113\u00ee\u011a\u00f0\u0109\u0106\u011a\u0117\u0136\u0137\u0133\u0110\u012d\u010e\u0142\u013e\u0125\u0148\u0123\u0123\u0103\u0123\u0104\u012e\u0122\u013f\u0146\u0111\u014b\u0149\u014c\u0108\u0123\u0145\u0156\u0142\u0129\u012f\u011d\u0114\u0160\u0137\u0136\u0141\u0151\u015c\u014e\u012e\u0159\u0160\u0159\u0124\u0147\u0145\u014a\u015f\u0157\u0166\u0139\u0136\u0137", (byte)18, 65);
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u00ef\u00f6\u00ec\u00d7\u00f4\u0114\u00dd\u011c\u011c\u00f1\u00e2\u00e7\u00f8\u0128\u00f8\u00f5\u00fc\u011a\u0128\u00fa\u010e\u00f1\u0127\u0134\u00f3\u010c\u010d\u00f4\u0131\u0116\u010d\u00f6\u012c\u00f9\u010b\u0136\u0108\u00f9\u0115\u0115\u011b\u0144\u0147\u0107\u0131\u0140\u0146\u0127\u0139\u0149\u0143\u0140\u0121\u011e\u0104\u010e\u0122\u011f\u0108\u0138\u0144\u0135\u011a\u0152", (byte)18, 65);
                    continue block7;
                }
                case 2: {
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u041a\u0453\u0464\u043c\u0461\u0460\u0443\u045b\u0447\u045d\u042c\u0462\u0441\u0427\u0471\u0443\u0450\u0446\u042f\u0457\u0440\u0441\u043e\u043f", (byte)18, 68);
                    continue block7;
                }
                case 4: {
                    \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u043a\u041d\u0457\u0454\u0465\u0451\u0464\u0468\u0454\u044b\u046b\u0421\u0446\u045b\u0446\u0468\u0470\u0466\u0449\u0432\u0451\u0441\u043e\u043f", (byte)18, 67);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x13L;
        l ^= 0x973FB6ABDBD4490CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), (byte)(36 + 33), (byte)(20 + 63), (byte)(43 + 4), (byte)(32 + 35), (byte)(32 + 34), (byte)(55 + 12), (byte)(42 + 5), (byte)(4 + 76), (byte)(52 + 23), (byte)(31 + 36), 83, (byte)(25 + 28), (byte)(4 + 76), (byte)(14 + 83), (byte)(89 + 11), (byte)(5 + 95), (byte)(73 + 32), (byte)(89 + 21), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(35 + 34), (byte)(64 + 19)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0535\u0542\u0541\u0504\u0544\u0540\u053b\u0544\u054f\u053e\u050b\u0549\u054d\u0546\u0549\u054f\u0511\u0877\u08a3\u0885\u0879\u08a2\u08b0\u089c\u089c\u08ad\u08ab\u0893", (byte)22, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void a(Plugin plugin) {
        Map.Entry entry;
        Object object;
        PluginManager pluginManager = ProxyServer.getInstance().getPluginManager();
        ClassLoader classLoader = plugin.getClass().getClassLoader();
        try {
            plugin.onDisable();
            object = plugin.getLogger().getHandlers();
            int n = ((Handler[])object).length;
            for (int i = a; i < n; ++i) {
                entry = object[i];
                ((Handler)((Object)entry)).close();
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e80", (int)b, (long)(d ^ e)) + plugin.getDescription().getName(), throwable, new Object[f]);
        }
        pluginManager.unregisterListeners(plugin);
        pluginManager.unregisterCommands(plugin);
        ProxyServer.getInstance().getScheduler().cancel(plugin);
        plugin.getExecutorService().shutdownNow();
        for (Thread thread : Thread.getAllStackTraces().keySet()) {
            if (thread.getClass().getClassLoader() != classLoader) continue;
            try {
                thread.interrupt();
                thread.join(g);
                if (!thread.isAlive()) continue;
                thread.interrupt();
            }
            catch (Throwable throwable) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e83", (int)h, (long)(i ^ j)) + plugin.getDescription().getName(), throwable, new Object[k]);
            }
        }
        try {
            object = PluginManager.class.getDeclaredField((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e86", (int)l, (long)(m ^ n)));
            ((Field)object).setAccessible(o != 0);
            Map map = (Map)((Field)object).get(pluginManager);
            Iterator iterator = map.entrySet().iterator();
            while (iterator.hasNext()) {
                entry = iterator.next();
                if (((Command)entry.getValue()).getClass().getClassLoader() != classLoader) continue;
                iterator.remove();
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e89", (int)p, (long)q) + plugin.getDescription().getName(), throwable, new Object[r]);
        }
        try {
            object = PluginManager.class.getDeclaredField((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e8c", (int)s, (long)t));
            ((Field)object).setAccessible(u != 0);
            Map map = (Map)((Field)object).get(pluginManager);
            map.values().remove(plugin);
            Field field = PluginManager.class.getDeclaredField((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e8f", (int)v, (long)w));
            field.setAccessible(x != 0);
            entry = (Multimap)field.get(pluginManager);
            entry.removeAll(plugin);
            Field field2 = PluginManager.class.getDeclaredField((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e92", (int)y, (long)(z ^ aa)));
            field2.setAccessible(ab != 0);
            Multimap multimap = (Multimap)field2.get(pluginManager);
            multimap.removeAll((Object)plugin);
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e95", (int)ac, (long)ad) + plugin.getDescription().getName(), throwable, new Object[ae]);
        }
        if (classLoader instanceof URLClassLoader) {
            try {
                ((URLClassLoader)classLoader).close();
            }
            catch (Throwable throwable) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.c("\u3e98", (int)af, (long)(ag ^ ah)) + plugin.getDescription().getName(), throwable, new Object[ai]);
            }
        }
    }

    static {
        a = 0 >>> 165 | 0 << -165;
        b = (0 >>> 114 | 0 << ~114 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-3735555320955737832L);
        e = Long.reverse(-4035225266123964416L);
        f = (0 >>> 233 | 0 << ~233 + 1) & 0xFFFFFFFF;
        g = Long.reverse(0xBE0000000000000L);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Long.reverse(-3735555320955737832L);
        j = Long.reverse(-4035225266123964416L);
        k = (0 >>> 18 | 0 << -18) & 0xFFFFFFFF;
        l = 32 >>> 196 | 32 << ~196 + 1;
        m = Long.reverse(-3735555320955737832L);
        n = Long.reverse(-4035225266123964416L);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(-1073741824);
        q = Long.reverse(299669945168226584L);
        r = 0 >>> 225 | 0 << ~225 + 1;
        s = Integer.reverse(0x20000000);
        t = Long.reverse(299669945168226584L);
        u = Integer.reverse(Integer.MIN_VALUE);
        v = 0x14000000 >>> 186 | 0x14000000 << -186;
        w = Long.reverse(299669945168226584L);
        x = Integer.reverse(Integer.MIN_VALUE);
        y = Integer.reverse(0x60000000);
        z = Long.reverse(-3735555320955737832L);
        aa = Long.reverse(-4035225266123964416L);
        ab = Integer.reverse(Integer.MIN_VALUE);
        ac = Integer.reverse(-536870912);
        ad = Long.reverse(299669945168226584L);
        ae = Integer.reverse(0);
        af = 128 >>> 68 | 128 << -68;
        ag = Long.reverse(-3735555320955737832L);
        ah = Long.reverse(-4035225266123964416L);
        ai = Integer.reverse(0);
        aj = Integer.reverse(-1879048192);
        ak = Integer.reverse(-1879048192);
        a = new String[aj];
        b = new String[ak];
        \u0394\u03bf\u03a0\u0393\u03bb\u03c8\u03b3\u03b2\u03c2\u03bf\u03a6.b();
    }
}

