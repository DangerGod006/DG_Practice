/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.command.CommandSource
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.ProxyServer
 *  com.velocitypowered.api.proxy.messages.ChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.title.Title
 *  net.kyori.adventure.title.Title$Times
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03be\u03b6\u0393\u03b1\u03c2\u03bc\u03a3\u03bd\u03bd\u03bc;
import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Duration;
import java.util.Base64;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4
implements \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 {
    private final UUID f = UUID.randomUUID();
    private static long au;
    private static int bj;
    private static int e;
    private static long ao;
    private static int cf;
    private static long bq;
    private static long bx;
    private static int bz;
    private static int o;
    private static long l;
    static final Map<Player, \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4> j;
    private static int bk;
    private static int aw;
    private static int w;
    private final boolean aq;
    private static int bg;
    private static int bo;
    private static int al;
    private static int an;
    private static int ad;
    private static long n;
    private static int z;
    private static long d;
    private static int x;
    private static int u;
    private static long bu;
    private static int ap;
    private static int a;
    private static long ar;
    private static long ax;
    private static long by;
    private static int bv;
    private static int ae;
    private static long m;
    private static long p;
    private static long bf;
    private static long v;
    private static int g;
    private final ProxyServer c;
    private static int bc;
    private static int ak;
    private static int cg;
    private static int am;
    private static int bs;
    private final \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 b;
    private static long ba;
    private static int af;
    private static long bh;
    private static long ce;
    private static int cd;
    private static int bp;
    private static int t;
    private static int ac;
    private static int bt;
    private static int cb;
    private static int br;
    private static int ai;
    private static int be;
    private static int q;
    private static long y;
    private static int bm;
    private static int ah;
    private static int bl;
    private static long k;
    private static long bb;
    private static int aj;
    private static long bi;
    private static int ag;
    private static long aa;
    private static long bn;
    private static int r;
    private static int az;
    private static long av;
    private static long c;
    private static int as;
    private static int cc;
    private static long ay;
    private \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 a;
    private static int f;
    private static int bw;
    private static int at;
    private static long j;
    private static int s;
    private static String[] b;
    private static int aq;
    private static String[] a;
    private static int i;
    private static int ca;
    private final Player a;
    private static int b;
    private static long h;
    private static int bd;
    private static long ab;

    @Override
    public void o(String string) {
        this.a.sendActionBar((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string));
    }

    private static String a(int n, long l) {
        l ^= 0xBL;
        l ^= 0xDA30B746356BEF98L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), 69, (byte)(4 + 79), (byte)(20 + 27), (byte)(37 + 30), (byte)(28 + 38), (byte)(54 + 13), (byte)(40 + 7), (byte)(33 + 47), (byte)(44 + 31), (byte)(6 + 61), (byte)(18 + 65), (byte)(30 + 23), (byte)(63 + 17), (byte)(34 + 63), (byte)(76 + 24), (byte)(76 + 24), 105, (byte)(18 + 92), (byte)(98 + 5)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(41 + 28), (byte)(43 + 40)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0445\u0452\u0451\u0414\u0454\u0450\u044b\u0454\u045f\u044e\u041b\u0459\u045d\u0456\u0459\u045f\u0421\u07b1\u07b3\u07bb\u07be\u07a9\u078c\u07ad\u07b8\u07a1\u07bc\u07c2\u07b2", (byte)15, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(-1);
        d = Long.reverse(-962186193928740964L);
        e = (1 >>> 0 | 1 << ~0 + 1) & 0xFFFFFFFF;
        f = (2048 >>> 171 | 2048 << ~171 + 1) & 0xFFFFFFFF;
        g = (-1 >>> 233 | -1 << ~233 + 1) & 0xFFFFFFFF;
        h = Long.reverse(-962186193928740964L);
        i = (1024 >>> 169 | 1024 << -169) & 0xFFFFFFFF;
        j = Long.reverse(2496578319891799964L);
        k = Long.reverse(-3458764513820540928L);
        l = Long.reverse(0x4C00000000000000L);
        m = Long.reverse(0x4C00000000000000L);
        n = Long.reverse(0x4C00000000000000L);
        o = Integer.reverse(-1073741824);
        p = Long.reverse(-962186193928740964L);
        q = Integer.reverse(0x40000000);
        r = Integer.reverse(0);
        s = 256 >>> 232 | 256 << -232;
        t = Integer.reverse(0x20000000);
        u = Integer.reverse(-1);
        v = Long.reverse(-962186193928740964L);
        w = 40 >>> 3 | 40 << ~3 + 1;
        x = (-1 >>> 114 | -1 << ~114 + 1) & 0xFFFFFFFF;
        y = Long.reverse(-962186193928740964L);
        z = Integer.reverse(0x60000000);
        aa = Long.reverse(2496578319891799964L);
        ab = Long.reverse(-3458764513820540928L);
        ac = (4096 >>> 203 | 4096 << -203) & 0xFFFFFFFF;
        ad = (0 >>> 229 | 0 << -229) & 0xFFFFFFFF;
        ae = Integer.reverse(-201326592);
        af = (8 >>> 227 | 8 << ~227 + 1) & 0xFFFFFFFF;
        ag = (16384 >>> 174 | 16384 << -174) & 0xFFFFFFFF;
        ah = Integer.reverse(0);
        ai = 1024 >>> 106 | 1024 << -106;
        aj = 0 >>> 150 | 0 << ~150 + 1;
        ak = (0x800000 >>> 118 | 0x800000 << ~118 + 1) & 0xFFFFFFFF;
        al = Integer.reverse(0);
        am = Integer.reverse(Integer.MIN_VALUE);
        an = Integer.reverse(-536870912);
        ao = Long.reverse(-962186193928740964L);
        ap = (256 >>> 101 | 256 << ~101 + 1) & 0xFFFFFFFF;
        aq = Integer.reverse(-1);
        ar = Long.reverse(-962186193928740964L);
        as = (8000 >>> 134 | 8000 << ~134 + 1) & 0xFFFFFFFF;
        at = Integer.reverse(-1879048192);
        au = Long.reverse(2496578319891799964L);
        av = Long.reverse(-3458764513820540928L);
        aw = Integer.reverse(0x50000000);
        ax = Long.reverse(2496578319891799964L);
        ay = Long.reverse(-3458764513820540928L);
        az = Integer.reverse(-805306368);
        ba = Long.reverse(2496578319891799964L);
        bb = Long.reverse(-3458764513820540928L);
        bc = 0xC000000 >>> 90 | 0xC000000 << -90;
        bd = Integer.reverse(Integer.MIN_VALUE);
        be = (0x6000000 >>> 87 | 0x6000000 << ~87 + 1) & 0xFFFFFFFF;
        bf = Long.reverse(-962186193928740964L);
        bg = 0x1A000000 >>> 89 | 0x1A000000 << -89;
        bh = Long.reverse(2496578319891799964L);
        bi = Long.reverse(-3458764513820540928L);
        bj = (524288 >>> 50 | 524288 << ~50 + 1) & 0xFFFFFFFF;
        bk = Integer.reverse(0);
        bl = (0x40000000 >>> 94 | 0x40000000 << ~94 + 1) & 0xFFFFFFFF;
        bm = 0x1C00000 >>> 149 | 0x1C00000 << ~149 + 1;
        bn = Long.reverse(-962186193928740964L);
        bo = Integer.reverse(-1);
        bp = Integer.reverse(-268435456);
        bq = Long.reverse(-962186193928740964L);
        br = Integer.reverse(0);
        bs = Integer.reverse(0x8000000);
        bt = (-1 >>> 228 | -1 << -228) & 0xFFFFFFFF;
        bu = Long.reverse(-962186193928740964L);
        bv = 0x100000 >>> 116 | 0x100000 << ~116 + 1;
        bw = Integer.reverse(-2013265920);
        bx = Long.reverse(2496578319891799964L);
        by = Long.reverse(-3458764513820540928L);
        bz = Integer.reverse(0x40000000);
        ca = Integer.reverse(Integer.MIN_VALUE);
        cb = (0 >>> 54 | 0 << -54) & 0xFFFFFFFF;
        cc = Integer.reverse(0);
        cd = Integer.reverse(0x48000000);
        ce = Long.reverse(-962186193928740964L);
        cf = 0x260000 >>> 81 | 0x260000 << ~81 + 1;
        cg = Integer.reverse(-939524096);
        a = new String[cf];
        b = new String[cg];
        \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b();
        j = new ConcurrentHashMap<Player, \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4>();
    }

    @Override
    public Optional<String> a() {
        return Optional.of(this.a.getPlayerSettings().getLocale().toLanguageTag());
    }

    @Override
    public void n(String string) {
        throw new UnsupportedOperationException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)(a & b), (long)d));
    }

    public static \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4 a(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, ProxyServer proxyServer, Object object) {
        if (object instanceof String) {
            String string = ((String)object).toLowerCase(Locale.ENGLISH);
            return proxyServer.getPlayer(string).map(player -> \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.a(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, proxyServer, player)).orElse(null);
        }
        if (object instanceof Player) {
            return \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.a(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, proxyServer, (Player)object);
        }
        throw new IllegalArgumentException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)at, (long)(au ^ av)) + object + (String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e83", (int)aw, (long)(ax ^ ay)) + (String)(object != null ? object.getClass().getCanonicalName() : \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e86", (int)az, (long)(ba ^ bb))));
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 a() {
        return this.b.a(ag != 0);
    }

    @Override
    public UUID a() {
        return this.a.getUniqueId();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u04c4\u04e6\u04e8\u04c8\u04ec\u050b\u0503\u0519\u0505\u04d4\u0512\u0508\u0516\u0510\u04d9\u04fe\u0520\u051f\u0517\u051d\u0517\u04ec", (byte)77, 68), \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u056c\u0579\u0578\u053b\u057b\u0577\u0572\u057b\u0586\u0575\u0542\u0580\u0584\u057d\u0580\u0586\u0548\u08d8\u08da\u08e2\u08e5\u08d0\u08b3\u08d4\u08df\u08c8\u08e3\u08e9\u08d9\u0560", (byte)77, 70) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0543", (byte)77, 69) + methodType.toString(), exception);
        }
    }

    @Override
    @Nullable
    public InetSocketAddress a() {
        return this.a.getRemoteAddress();
    }

    public int hashCode() {
        Object[] objectArray = new Object[ak];
        objectArray[\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.al] = this.f;
        objectArray[\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.am] = this.a;
        return Objects.hash(objectArray);
    }

    @Override
    public void l(String string) {
        if (string.length() >= ac && string.charAt(ad) == ae) {
            string = string.substring(af);
        }
        this.c.getCommandManager().executeImmediatelyAsync((CommandSource)this.a, string);
    }

    @Override
    public String getName() {
        return this.a.getUsername();
    }

    @Override
    public \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 a() {
        if (this.a == null) {
            this.a = (object, objectArray) -> {
                throw new UnsupportedOperationException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)cd, (long)ce));
            };
        }
        return this.a;
    }

    @Override
    public CompletableFuture<Void> a(String string) {
        CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        this.a.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string));
        completableFuture.complete(null);
        return completableFuture;
    }

    @Override
    public String u() {
        return this.a.getUsername();
    }

    @Override
    public void a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, Object object, byte[] byArray) {
        ChannelIdentifier channelIdentifier;
        if (object instanceof String) {
            String string = (String)object;
            String[] stringArray = string.split((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)o, (long)p));
            channelIdentifier = stringArray.length == q ? MinecraftChannelIdentifier.create((String)stringArray[r], (String)stringArray[s]) : new LegacyChannelIdentifier(string);
        } else if (object instanceof ChannelIdentifier) {
            channelIdentifier = (ChannelIdentifier)object;
        } else {
            throw new IllegalArgumentException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e83", (int)(t & u), (long)v) + object + (String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e86", (int)(w & x), (long)y) + object.getClass().getCanonicalName());
        }
        switch (\u03b1\u03be\u03b6\u0393\u03b1\u03c2\u03bc\u03a3\u03bd\u03bd\u03bc.t[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72.ordinal()]) {
            case 1: {
                this.a.sendPluginMessage(channelIdentifier, byArray);
                break;
            }
            case 2: {
                this.a.getCurrentServer().ifPresent(serverConnection -> {
                    if (!serverConnection.getServer().getPlayersConnected().isEmpty()) {
                        serverConnection.sendPluginMessage(channelIdentifier, byArray);
                    }
                });
                break;
            }
            default: {
                throw new IllegalArgumentException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e89", (int)z, (long)(aa ^ ab)) + (Object)((Object)\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72));
            }
        }
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    @Override
    public boolean R() {
        return this.a.isActive();
    }

    @Override
    public void d(Object object) {
        if (object instanceof String) {
            this.a.sendMessage((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.b((String)object, e != 0));
        } else if (object instanceof Component) {
            this.a.sendMessage((Component)object);
        } else {
            throw new IllegalArgumentException((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)(f & g), (long)h) + object + (String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e83", (int)i, (long)(j ^ k)) + object.getClass().getCanonicalName());
        }
    }

    /*
     * Exception decompiling
     */
    static \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4 b(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 var0, ProxyServer var1_1, Player var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$TooOptimisticMatchException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.getString(SwitchStringRewriter.java:404)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.access$600(SwitchStringRewriter.java:53)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$SwitchStringMatchResultCollector.collectMatches(SwitchStringRewriter.java:368)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneN.match(KleeneN.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence.match(MatchSequence.java:26)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:23)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewriteComplex(SwitchStringRewriter.java:201)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewrite(SwitchStringRewriter.java:73)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:881)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public String toString() {
        return (String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)an, (long)ao) + this.a + (String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e83", (int)(ap & aq), (long)ar) + this.f + (char)as;
    }

    public boolean equals(Object object) {
        if (object == null || this.getClass() != object.getClass()) {
            return ah != 0;
        }
        \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4 \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42 = (\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4)object;
        return (Objects.equals(this.f, \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42.f) && Objects.equals(this.a, \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42.a) ? ai : aj) != 0;
    }

    @Override
    public void ad() {
        this.a.resetTitle();
    }

    @Generated
    private \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, Player player, ProxyServer proxyServer, boolean bl) {
        this.b = \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92;
        this.a = player;
        this.c = proxyServer;
        this.aq = bl;
    }

    @Override
    @Generated
    public boolean S() {
        return this.aq;
    }

    private static \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4 a(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, ProxyServer proxyServer, Player player) {
        \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4 \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42 = j.get(player);
        if (\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42 != null) {
            return \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b42;
        }
        if (\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.aj()) {
            StackTraceElement[] stackTraceElementArray = new Exception().getStackTrace();
            Object object = stackTraceElementArray.length > 0 ? stackTraceElementArray[Math.min(bc, stackTraceElementArray.length - bd)].toString() : \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e80", (int)be, (long)bf);
            Object[] objectArray = new Object[bj];
            objectArray[\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.bk] = player.getUsername();
            objectArray[\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.bl] = object;
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.c("\u3e83", (int)bg, (long)(bh ^ bi)), objectArray);
        }
        return \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, proxyServer, player);
    }

    @Override
    public int h() {
        return (int)this.a.getPing();
    }

    private static void b() {
        int n;
        c = 4177626197511218500L;
        long l = c ^ 0xDA30B746356BEF98L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(4 + 64), (byte)(60 + 9), (byte)(32 + 51), (byte)(37 + 10), 67, (byte)(54 + 12), (byte)(31 + 36), 47, (byte)(13 + 67), (byte)(73 + 2), (byte)(41 + 26), (byte)(25 + 58), (byte)(12 + 41), (byte)(73 + 7), (byte)(20 + 77), (byte)(33 + 67), (byte)(85 + 15), (byte)(87 + 18), (byte)(81 + 29), (byte)(17 + 86)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(22 + 46), (byte)(47 + 22), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u017b\u013d\u0185\u0144\u0175\u017f\u0184\u018b\u015d\u017a\u0168\u017b\u0181\u0167\u0173\u017f\u0167\u0185\u0171\u0150\u0190\u0161\u015e\u015f", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u014c\u0145\u0186\u017d\u0184\u0177\u0148\u0182\u018b\u0146\u0187\u014e\u0190\u0148\u0167\u0194\u018c\u0160\u015f\u0175\u0190\u018a\u0165\u016d\u016f\u016f\u0150\u016d\u0188\u019a\u0198\u0161\u01a0\u018d\u0198\u019b\u01a3\u01a7\u0184\u01a7\u0178\u0184\u0165\u0173", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u015f\u0185\u0154\u0183\u0185\u0189\u017a\u0146\u018d\u0144\u0145\u0153", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u014c\u013e\u017f\u0162\u015b\u0148\u0182\u017c\u015e\u017a\u018c\u0153", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u04dc\u04e2\u04f6\u04bd\u04f6\u04f2\u04ce\u04f9\u0509\u04db\u04d7\u04d6\u0505\u050d\u04ee\u04e3\u04fa\u04d0\u04c8\u04fe\u04ff\u04e5\u0502\u04ff\u04d4\u04cb\u04f5\u050d\u04eb\u051a\u04dd\u04eb\u050a\u0513\u050a\u050f\u051d\u04dd\u04f3\u04f9\u0523\u051f\u04e1\u04ef", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[5] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0556\u057c\u054b\u057a\u057c\u0580\u0571\u053d\u0584\u053b\u053c\u054a", (byte)70, 69);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[6] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u04c8\u04c1\u0502\u04f9\u0500\u04f3\u04c4\u04fe\u0507\u04c2\u0500\u04ca\u04db\u04e3\u04e4\u04e7\u050a\u04f0\u04e3\u050c\u0504\u04f6\u04ee\u04ed\u04d1\u04e9\u04ed\u051a\u0514\u0516\u04f3\u04eb", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[7] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u04ff\u04ee\u04fc\u04d9\u04de\u04ed\u0502\u04f4\u0509\u04c5\u04c7\u04fb\u04c4\u04cb\u0507\u04d9\u04ca\u0502\u04c4\u04cf\u0509\u04e7\u0512\u0503\u0518\u0515\u04f4\u04e9\u050b\u04e7\u04d0\u050c\u050a\u04d3\u04fa\u04f8\u04e0\u04f8\u04f6\u04e2\u0516\u051e\u051c\u04ef", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[8] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0165\u015d\u0177\u0155\u015a\u0143\u0177\u0188\u0148\u018e\u0176\u0177\u0178\u0164\u014c\u0169\u0162\u0166\u0177\u0174\u0185\u0161\u015e\u015f", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u014c\u0145\u0186\u017d\u0184\u0177\u0148\u0182\u018b\u0146\u0186\u0158\u015b\u018f\u0151\u0173\u014a\u0167\u0196\u0186\u0157\u018f\u018e\u0173\u0185\u019a\u0193\u015f\u0199\u0192\u018e\u0192\u016e\u017b\u0160\u019a\u0165\u0174\u019e\u019c\u0195\u019a\u01a0\u0173", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[10] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u04db\u0501\u04d0\u04ff\u0501\u0505\u04f6\u04c2\u0509\u04c0\u04c1\u04cf", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[11] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u013a\u013e\u0175\u013d\u0151\u0160\u0154\u0147\u014b\u015b\u015e\u0153", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[12] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u052d\u0565\u057e\u054f\u054e\u0560\u0559\u0573\u0575\u056c\u0551\u054a", (byte)70, 69);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[13] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04cd\u04d1\u04e0\u04ef\u04ce\u04f7\u0507\u04e1\u04e7\u04f4\u04d9\u04e1\u04e0\u04da\u04cc\u04de\u04fe\u04dc\u0508\u0500\u04e9\u050a\u04f4\u04f5\u04e0\u0502\u04d7\u04d1\u04f0\u04f2\u04f0\u051a\u0515\u04d3\u04f7\u0504\u0514\u051a\u04e5\u04f5\u04e5\u04e2\u0528\u0502\u0528\u0521\u04e9\u051d\u04e8\u04ef\u0509\u04e9\u04ee\u04fd\u051f\u0522\u0511\u0532\u0513\u050c\u053a\u051e\u052d\u0514\u0532\u0514\u0517\u0535\u0541\u0542\u0520\u0512\u053f\u0544\u0522\u0517\u051a\u050a\u0509\u052d\u0530\u0539\u0521\u051e\u052c\u0511\u050d\u0553\u0535\u0556\u0513\u0513\u0549\u051b\u0514\u0553", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[14] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0158\u0183\u0172\u015e\u0169\u0186\u017e\u016a\u0168\u0158\u014b\u0166\u0184\u014c\u0181\u0163\u017e\u0181\u0148\u016b\u0187\u0171\u015e\u015f", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[15] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u04de\u04ca\u04dc\u04f3\u04c0\u04de\u04ee\u04d0\u04f9\u04e0\u04c3\u04fa\u04d9\u0501\u04d7\u0506\u04fc\u04fc\u050e\u0508\u04eb\u0503\u04da\u04db", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[16] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u055a\u0553\u0570\u055c\u0553\u0539\u0539\u053a\u0558\u0542\u053b\u0565\u0584\u0585\u0563\u0565\u054b\u0544\u0547\u058b\u055f\u058e\u0555\u0556", (byte)70, 69);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[17] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0155\u0155\u0154\u016f\u0156\u0151\u0183\u0178\u014b\u0155\u014a\u014b\u0163\u0180\u017d\u0184\u0191\u0194\u018c\u0172\u0164\u0197\u015e\u015f", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[18] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0567\u0578\u054a\u054c\u0554\u0549\u054c\u0540\u053d\u056d\u0551\u055b\u0557\u0559\u0578\u0545\u0559\u056d\u0586\u056e\u0568\u058e\u0555\u0556", (byte)70, 70);
                    continue block7;
                }
                case 1: {
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u017b\u013d\u0185\u0144\u0175\u017f\u0184\u018b\u015d\u017a\u0166\u0190\u018a\u0184\u018d\u0163\u017f\u0184\u0187\u0174\u0193\u014b\u019b\u016c\u0157\u0198\u0166\u018d\u016f\u0159\u018c\u015c", (byte)70, 65);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u04c8\u04c1\u0502\u04f9\u0500\u04f3\u04c4\u04fe\u0507\u04c2\u0503\u04ca\u050c\u04c4\u04e3\u0510\u0508\u04dc\u04db\u04f1\u050c\u0506\u04e1\u04e9\u04eb\u04eb\u04cc\u04e9\u0504\u0516\u0514\u04dd\u04ec\u050c\u0516\u04f0\u0515\u0512\u0515\u04e7\u0503\u04ff\u04f6\u04ef", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[2] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04dd\u04fe\u04f6\u04df\u04cd\u0502\u04e3\u04be\u04e5\u04f8\u0504\u04cf", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[3] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0174\u0143\u0154\u015c\u0188\u013f\u0159\u017a\u017a\u0169\u015a\u0153", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[4] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04dc\u04e2\u04f6\u04bd\u04f6\u04f2\u04ce\u04f9\u0509\u04db\u04d7\u04d6\u0505\u050d\u04ee\u04e3\u04fa\u04d0\u04c8\u04fe\u04ff\u04e5\u0502\u04ff\u04d4\u04cb\u04f5\u050d\u04eb\u051a\u04dd\u04eb\u0516\u04f6\u04de\u050d\u0521\u0503\u0525\u0527\u04f8\u04e4\u051e\u0529\u04fd\u0506\u051e\u04ff\u04e9\u050f\u04f1\u04e5\u04fc\u0523\u04fa\u04fb", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u017a\u013f\u013d\u017e\u0171\u0140\u0142\u017a\u0162\u0163\u018c\u0153", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[6] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0543\u053c\u057d\u0574\u057b\u056e\u053f\u0579\u0582\u053d\u057b\u0545\u0556\u055e\u055f\u0562\u0585\u056b\u055e\u0587\u057f\u057b\u056a\u057b\u0591\u0573\u056f\u0590\u0560\u0582\u0581\u058c\u058a\u0584\u059d\u0598\u0569\u0573\u056c\u058e\u055b\u0578\u0564\u056a", (byte)70, 70);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[7] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u057a\u0569\u0577\u0554\u0559\u0568\u057d\u056f\u0584\u0540\u0542\u0576\u053f\u0546\u0582\u0554\u0545\u057d\u053f\u054a\u0584\u0562\u058d\u057e\u0593\u0590\u056f\u0564\u0586\u0562\u054b\u0587\u0559\u0594\u0568\u0569\u0587\u0599\u057a\u0581\u0583\u058d\u057e\u058e\u0567\u0568\u0569\u0565\u056b\u0578\u059c\u0564\u0598\u059e\u0575\u0576", (byte)70, 70);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[8] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u04e1\u04d9\u04f3\u04d1\u04d6\u04bf\u04f3\u0504\u04c4\u050a\u04f3\u04dd\u04d8\u04f7\u04f8\u04e3\u0503\u0503\u04fd\u04f1\u04ef\u0503\u04da\u04db", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[9] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u04c8\u04c1\u0502\u04f9\u0500\u04f3\u04c4\u04fe\u0507\u04c2\u0502\u04d4\u04d7\u050b\u04cd\u04ef\u04c6\u04e3\u0512\u0502\u04d3\u050b\u050a\u04ef\u0501\u0516\u050f\u04db\u0515\u050e\u050a\u050e\u04ec\u04f7\u0521\u04e0\u04f3\u0517\u04fc\u04df\u04e1\u0509\u051c\u04ef", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[10] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u0156\u0162\u0183\u0140\u015e\u0175\u0143\u0180\u018a\u0169\u0178\u0153", (byte)70, 66);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[11] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u04ba\u04b9\u04e2\u04e4\u04bb\u04fe\u0502\u04dc\u04f1\u04e4\u04e6\u04cf", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[12] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04ed\u04fb\u04ee\u04e0\u04e0\u04fa\u04f4\u04fd\u0507\u04f1\u04de\u04c5\u04c7\u04c6\u04f9\u04ff\u0511\u04df\u04c9\u04ec\u04f0\u0503\u04da\u04db", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[13] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u04cd\u04d1\u04e0\u04ef\u04ce\u04f7\u0507\u04e1\u04e7\u04f4\u04d9\u04e1\u04e0\u04da\u04cc\u04de\u04fe\u04dc\u0508\u0500\u04e9\u050a\u04f4\u04f5\u04e0\u0502\u04d7\u04d1\u04f0\u04f2\u04f0\u051a\u0515\u04d3\u04f7\u0504\u0514\u051a\u04e5\u04f5\u04e5\u04e2\u0528\u0502\u0528\u0521\u04e9\u051d\u04e8\u04ef\u0509\u04e9\u04ee\u04fd\u051f\u0522\u0511\u0532\u0513\u050c\u053a\u051e\u052d\u0514\u0532\u0514\u0517\u0535\u0541\u0542\u0520\u0512\u053f\u0544\u0522\u0517\u051a\u050a\u0509\u052d\u0530\u0539\u0521\u051e\u052c\u0556\u0511\u0515\u054a\u054a\u0539\u052d\u0516\u0545\u0526\u0516\u0549\u052b\u0536\u0553\u0564\u0543\u052e\u0541\u0526\u055d\u0521\u052f", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[14] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u04d4\u04ff\u04ee\u04da\u04e5\u0502\u04fa\u04e6\u04e4\u04d4\u04c5\u04f5\u04fd\u0503\u04cc\u0510\u04ee\u050b\u04ce\u04de\u04fe\u0509\u04f1\u0511\u0501\u04e1\u04fb\u04e9\u04d7\u04ee\u04f5\u051c", (byte)70, 68);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[15] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u04de\u04ca\u04dc\u04f3\u04c0\u04de\u04ee\u04d0\u04f9\u04e0\u04c3\u04de\u0507\u04ee\u04d6\u04ef\u04e5\u0508\u0501\u04ee\u04cc\u04f2\u0507\u04ef\u04d1\u0519\u04eb\u0519\u051b\u04f6\u0513\u050f", (byte)70, 67);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[16] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u055a\u0553\u0570\u055c\u0553\u0539\u0539\u053a\u0558\u0542\u0544\u0583\u0557\u0565\u053b\u0543\u0563\u0542\u0584\u058e\u058a\u057e\u0555\u0556", (byte)70, 70);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[17] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u054c\u054c\u054b\u0566\u054d\u0548\u057a\u056f\u0542\u054c\u0543\u056e\u0542\u057c\u0564\u0562\u058c\u0581\u0583\u0576\u0585\u0563\u0586\u056c\u055b\u057e\u054d\u0591\u057f\u058a\u0557\u0562", (byte)70, 70);
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[18] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0170\u0181\u0153\u0155\u015d\u0152\u0155\u0149\u0146\u0176\u015c\u015a\u0148\u014e\u0171\u0182\u0185\u0160\u0190\u0155\u0191\u0187\u015e\u015f", (byte)70, 65);
                    continue block7;
                }
                case 2: {
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0546\u0575\u0576\u054c\u057a\u057c\u0561\u0578\u0543\u0581\u053c\u054a", (byte)70, 70);
                    continue block7;
                }
                case 4: {
                    \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0136\u0162\u0159\u0183\u0166\u017a\u0146\u0145\u0160\u017b\u015a\u0168\u0186\u0149\u014c\u016b\u018f\u0153\u0169\u016e\u014a\u0171\u015e\u015f", (byte)70, 66);
                }
            }
        }
    }

    @Override
    public void a(String string, String string2, int n, int n2, int n3) {
        this.a.showTitle(Title.title((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string), (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string2), (Title.Times)Title.Times.times((Duration)Duration.ofMillis((long)n * l), (Duration)Duration.ofMillis((long)n2 * m), (Duration)Duration.ofMillis((long)n3 * \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.n))));
    }

    @Override
    public void p(String string) {
        this.a.spoofChatInput(string);
    }

    @Override
    public boolean i(String string) {
        return this.a.hasPermission(string);
    }
}

