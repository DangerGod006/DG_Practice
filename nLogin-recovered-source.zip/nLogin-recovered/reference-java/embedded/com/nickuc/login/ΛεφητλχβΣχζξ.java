/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u039b\u03b5\u03c6\u03b7\u03c4\u03bb\u03c7\u03b2\u03a3\u03c7\u03b6\u03be {
    private static int b;
    static final /* synthetic */ int[] H;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (4 >>> 65 | 4 << -65) & 0xFFFFFFFF;
        H = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u039b\u03b5\u03c6\u03b7\u03c4\u03bb\u03c7\u03b2\u03a3\u03c7\u03b6\u03be.H[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u039b\u03b5\u03c6\u03b7\u03c4\u03bb\u03c7\u03b2\u03a3\u03c7\u03b6\u03be.H[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

