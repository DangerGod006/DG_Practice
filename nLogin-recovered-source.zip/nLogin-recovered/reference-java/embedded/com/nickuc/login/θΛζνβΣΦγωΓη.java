/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7 {
    private static int i;
    private static String[] b;
    private static int l;
    private static int e;
    private static long c;
    private static int a;
    private static int b;
    private static long d;
    private static int g;
    private static int f;
    private static int h;
    private static int k;
    private static String[] a;
    private static int j;

    private static String a(int n, long l) {
        l ^= 0x59L;
        l ^= 0xC0B1A8A516D2A5B8L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(32 + 37), (byte)(24 + 59), (byte)(27 + 20), (byte)(12 + 55), 66, 67, (byte)(36 + 11), (byte)(34 + 46), (byte)(20 + 55), (byte)(35 + 32), (byte)(27 + 56), (byte)(28 + 25), (byte)(79 + 1), (byte)(8 + 89), (byte)(96 + 4), (byte)(8 + 92), (byte)(82 + 23), (byte)(62 + 48), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(24 + 44), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u055c\u0569\u0568\u052b\u056b\u0567\u0562\u056b\u0576\u0565\u0532\u0570\u0574\u056d\u0570\u0576\u0538\u08c2\u08a6\u08c2\u08ca\u08c0\u08b2\u08b6\u08c4\u08db\u08a6\u08cb", (byte)108, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public static \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2 a() {
        block10: {
            try {
                InputStream inputStream = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a((String)\u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.c("\u3e80", (int)(a & b), (long)d), e != 0);
                try {
                    \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2 \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22;
                    block11: {
                        if (inputStream == null) break block10;
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                        try {
                            \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22 = \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b2.a(bufferedReader.readLine());
                            if (Collections.singletonList(bufferedReader).get(f) == null) break block11;
                        }
                        catch (Throwable throwable) {
                            if (Collections.singletonList(bufferedReader).get(h) != null) {
                                bufferedReader.close();
                            }
                            throw throwable;
                        }
                        bufferedReader.close();
                    }
                    return \u03c4\u03b9\u03c0\u03c5\u03a6\u03b4\u03a9\u03bd\u03b22;
                }
                finally {
                    if (Collections.singletonList(inputStream).get(g) != null) {
                        inputStream.close();
                    }
                }
            }
            catch (IOException iOException) {
                throw new RuntimeException(iOException);
            }
        }
        return null;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0107\u0129\u012b\u010b\u012f\u014e\u0146\u015c\u0148\u0117\u0155\u014b\u0159\u0153\u011c\u0141\u0163\u0162\u015a\u0160\u015a\u012f", (byte)48, 65), \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u054f\u055c\u055b\u051e\u055e\u055a\u0555\u055e\u0569\u0558\u0525\u0563\u0567\u0560\u0563\u0569\u052b\u08b5\u0899\u08b5\u08bd\u08b3\u08a5\u08a9\u08b7\u08ce\u0899\u08be\u0542", (byte)48, 70) + string + \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0526", (byte)48, 70) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -6335034116628266575L;
        long l = c ^ 0xC0B1A8A516D2A5B8L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(30 + 38), (byte)(52 + 17), (byte)(79 + 4), 47, (byte)(9 + 58), (byte)(62 + 4), (byte)(48 + 19), (byte)(36 + 11), (byte)(44 + 36), (byte)(68 + 7), (byte)(30 + 37), (byte)(27 + 56), (byte)(45 + 8), (byte)(6 + 74), (byte)(38 + 59), (byte)(32 + 68), 100, (byte)(101 + 4), (byte)(82 + 28), (byte)(72 + 31)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(26 + 42), 69, (byte)(40 + 43)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u04a1\u04a1\u04a6\u04af\u04be\u04a1\u0491\u04b5\u04a2\u0495\u0491\u04c8\u04b5\u04d1\u04bb\u04ac\u0494\u04c9\u049d\u04c8\u04ad\u04b7\u04d7\u04d2\u04df\u04de\u04b4\u04e0\u04da\u04e7\u04ba\u04cc", (byte)53, 67);
                    continue block7;
                }
                case 1: {
                    \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u053e\u053e\u0543\u054c\u055b\u053e\u052e\u0552\u053f\u0532\u052e\u0565\u0552\u056e\u0558\u0549\u0531\u0566\u053a\u0565\u054a\u054d\u0539\u0579\u0556\u0551\u057e\u0552\u0557\u053d\u0568\u0571\u0557\u0544\u0588\u0560\u0561\u054a\u0560\u058d\u0562\u056c\u058a\u0559", (byte)53, 69);
                    continue block7;
                }
                case 2: {
                    \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0488\u04a8\u0497\u0498\u04bb\u0484\u04c4\u04b2\u04d3\u0494\u04b5\u04a5\u0496\u04d5\u04ac\u04da\u04b3\u04c7\u04ba\u04d9\u04ba\u04d3\u04d4\u04b5\u04d5\u04d2\u04a2\u04e2\u04d4\u04bb\u04be\u04a6", (byte)53, 68);
                    continue block7;
                }
                case 4: {
                    \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u015d\u011a\u014d\u012e\u0162\u0137\u0146\u0155\u0148\u015a\u013c\u0129\u0149\u013b\u0130\u0130\u0171\u0150\u0126\u0168\u0133\u014f\u013c\u013d", (byte)53, 65);
                }
            }
        }
    }

    static {
        a = 0 >>> 56 | 0 << -56;
        b = Integer.reverse(-1);
        d = Long.reverse(1693958674739800085L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(0);
        g = 0 >>> 10 | 0 << -10;
        h = Integer.reverse(0);
        i = Integer.reverse(0);
        j = 0 >>> 167 | 0 << -167;
        k = 128 >>> 167 | 128 << ~167 + 1;
        l = Integer.reverse(Integer.MIN_VALUE);
        a = new String[k];
        b = new String[l];
        \u03b8\u039b\u03b6\u03bd\u03b2\u03a3\u03a6\u03b3\u03c9\u0393\u03b7.b();
    }
}

