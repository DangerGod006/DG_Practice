/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b
extends Enum<\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b> {
    public static final /* enum */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b a;
    public static final /* enum */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b b;
    public static final /* enum */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b c;
    public static final /* enum */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b d;
    private static final /* synthetic */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static long i;
    private static long j;
    private static int k;
    private static int l;
    private static long m;
    private static long n;
    private static int o;
    private static int p;
    private static int q;
    private static long r;
    private static int s;
    private static int t;
    private static long u;
    private static long v;
    private static int w;

    private static void b() {
        int n;
        c = -5697605996346767519L;
        long l = c ^ 0xACD5C4F870033F5FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(6 + 62), (byte)(61 + 8), (byte)(71 + 12), 47, (byte)(15 + 52), (byte)(50 + 16), (byte)(49 + 18), (byte)(2 + 45), (byte)(31 + 49), (byte)(68 + 7), (byte)(48 + 19), (byte)(38 + 45), (byte)(48 + 5), (byte)(47 + 33), (byte)(94 + 3), (byte)(80 + 20), (byte)(85 + 15), 105, (byte)(103 + 7), (byte)(26 + 77)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(54 + 15), (byte)(64 + 19)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u056a\u054a\u0574\u0572\u056c\u0574\u053b\u053b\u0558\u0560\u0571\u0548", (byte)68, 69);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u04f6\u04e5\u04bc\u04b6\u04fe\u04f0\u04ed\u04f7\u04c1\u04d7\u04dd\u04d3\u04e4\u04f8\u04d9\u04c5\u04df\u0506\u050c\u04fa\u04d9\u04d7\u04d4\u04d5", (byte)68, 68);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[2] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u017b\u015d\u013a\u014d\u0153\u0162\u0153\u015f\u0189\u0175\u0149\u014f", (byte)68, 66);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[3] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0541\u056e\u055b\u0533\u0553\u057c\u054c\u0575\u053c\u057c\u057d\u0548", (byte)68, 69);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0539\u0578\u0533\u055c\u053c\u057b\u0559\u0569\u0579\u056e\u0573\u0574\u055e\u0561\u053d\u0571\u0574\u0562\u0577\u057a\u0561\u0556\u0553\u0554", (byte)68, 69);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u0575\u0564\u053b\u0535\u057d\u056f\u056c\u0576\u0540\u0556\u055c\u0579\u0551\u0575\u0556\u0576\u0571\u0566\u0577\u0568\u0555\u0566\u0553\u0554", (byte)68, 69);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0533\u0571\u056e\u055a\u054e\u0552\u053f\u0568\u0579\u0574\u0543\u0575\u056e\u0581\u055a\u0588\u057f\u0541\u0589\u0578\u0556\u0566\u0553\u0554", (byte)68, 70);
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[3] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u04b3\u04fc\u04cd\u04e6\u04b6\u04df\u04d0\u04fb\u04f7\u0502\u04e3\u0506\u04d3\u04f0\u0508\u04d5\u04fa\u04e0\u04fa\u04c7\u0504\u04fd\u04d4\u04d5", (byte)68, 67);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04b2\u04b8\u04f4\u04e5\u04e6\u04b6\u04b7\u04f8\u04bf\u04fd\u04d4\u0502\u04c0\u04f5\u0504\u0507\u04f2\u04f9\u04e7\u04e3\u050c\u0508\u04cf\u0511\u0503\u04f1\u04e7\u04cd\u050e\u04df\u04d3\u04f2", (byte)68, 68);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u0171\u014b\u013b\u0178\u0153\u0174\u014e\u015c\u0165\u017a\u0157\u0163\u0186\u014d\u0149\u0148\u0178\u017a\u0180\u018c\u017f\u016d\u015a\u015b", (byte)68, 66);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0x20000000);
        b = Integer.reverse(0);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (16 >>> 195 | 16 << -195) & 0xFFFFFFFF;
        e = Integer.reverse(-1073741824);
        f = (131072 >>> 143 | 131072 << ~143 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(0x20000000);
        h = (0 >>> 88 | 0 << ~88 + 1) & 0xFFFFFFFF;
        i = Long.reverse(-8727490467072018675L);
        j = Long.reverse(-6341068275337658368L);
        k = (0 >>> 185 | 0 << ~185 + 1) & 0xFFFFFFFF;
        l = 32768 >>> 111 | 32768 << ~111 + 1;
        m = Long.reverse(-8727490467072018675L);
        n = Long.reverse(-6341068275337658368L);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(0x40000000);
        q = Integer.reverse(-1);
        r = Long.reverse(3378185331299874573L);
        s = Integer.reverse(0x40000000);
        t = Integer.reverse(-1073741824);
        u = Long.reverse(-8727490467072018675L);
        v = Long.reverse(-6341068275337658368L);
        w = (0x300000 >>> 180 | 0x300000 << ~180 + 1) & 0xFFFFFFFF;
        a = new String[f];
        b = new String[g];
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b();
        a = new \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b();
        b = new \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b();
        c = new \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b();
        d = new \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b();
        a = \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.a();
    }

    public static \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[] values() {
        return (\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[])a.clone();
    }

    public static \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b valueOf(String string) {
        return Enum.valueOf(\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.class, string);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0516\u0538\u053a\u051a\u053e\u055d\u0555\u056b\u0557\u0526\u0564\u055a\u0568\u0562\u052b\u0550\u0572\u0571\u0569\u056f\u0569\u053e", (byte)50, 70), \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04ae\u04bb\u04ba\u047d\u04bd\u04b9\u04b4\u04bd\u04c8\u04b7\u0484\u04c2\u04c6\u04bf\u04c2\u04c8\u048a\u0814\u0817\u081f\u0813\u0812\u081b\u07f5\u081a\u081a\u0817\u081a\u0802\u04a2", (byte)50, 67) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u011d", (byte)50, 65) + methodType.toString(), exception);
        }
    }

    private static /* synthetic */ \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[] a() {
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[] \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray = new \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b[a];
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b] = a;
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.c] = b;
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.d] = c;
        \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.e] = d;
        return \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039bArray;
    }

    private static String a(int n, long l) {
        l ^= 0x15L;
        l ^= 0xACD5C4F870033F5FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(57 + 12), (byte)(20 + 63), (byte)(38 + 9), (byte)(19 + 48), 66, (byte)(56 + 11), (byte)(21 + 26), (byte)(29 + 51), (byte)(32 + 43), (byte)(19 + 48), (byte)(27 + 56), (byte)(8 + 45), (byte)(7 + 73), (byte)(77 + 20), (byte)(15 + 85), (byte)(76 + 24), (byte)(8 + 97), (byte)(96 + 14), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(43 + 25), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0511\u051e\u051d\u04e0\u0520\u051c\u0517\u0520\u052b\u051a\u04e7\u0525\u0529\u0522\u0525\u052b\u04ed\u0877\u087a\u0882\u0876\u0875\u087e\u0858\u087d\u087d\u087a\u087d\u0865", (byte)83, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

