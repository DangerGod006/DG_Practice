/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientPluginMessage
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientPluginMessage;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private static long b;
    private static int a;
    private static long d;
    private static int e;
    private static int g;
    private static int f;
    private static long c;
    private static String[] a;
    final /* synthetic */ \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 b;
    private static String[] b;

    private static void b() {
        int n;
        c = 6343347231702593885L;
        long l = c ^ 0x935C4F7641C65511L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(29 + 40), (byte)(59 + 24), (byte)(24 + 23), 67, (byte)(39 + 27), (byte)(26 + 41), (byte)(35 + 12), 80, (byte)(23 + 52), (byte)(28 + 39), (byte)(63 + 20), (byte)(9 + 44), (byte)(25 + 55), (byte)(25 + 72), (byte)(28 + 72), (byte)(73 + 27), (byte)(88 + 17), (byte)(8 + 102), (byte)(2 + 101)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(46 + 22), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u052b\u0508\u052e\u051f\u0545\u0523\u0513\u052a\u050f\u0516\u052c\u0551\u0527\u053c\u054f\u055d\u0518\u055d\u0563\u0530\u0554\u052d\u052a\u052b", (byte)27, 69);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u052b\u0508\u052e\u051f\u0545\u0523\u0513\u052a\u050f\u0516\u052a\u0516\u0555\u0532\u0517\u054e\u051e\u0541\u055a\u052e\u0551\u0563\u052a\u052b", (byte)27, 70);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0122\u00f9\u00fe\u011f\u0105\u011b\u010c\u0111\u00ed\u010e\u010a\u010e\u012e\u0134\u0115\u010d\u012c\u0112\u012f\u013e\u00f4\u0131\u0108\u0109", (byte)27, 66);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u0549\u053d\u050b\u052b\u0527\u052b\u0508\u0534\u0520\u0512\u0513\u0538\u053b\u0545\u0515\u0540\u0552\u0539\u0551\u051c\u0539\u051f\u0536\u055d\u055b\u0565\u0545\u0549\u0539\u053c\u0524\u055e", (byte)27, 69);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 5L;
        l ^= 0x935C4F7641C65511L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(11 + 58), (byte)(50 + 33), (byte)(33 + 14), (byte)(25 + 42), (byte)(41 + 25), (byte)(15 + 52), (byte)(25 + 22), (byte)(57 + 23), (byte)(42 + 33), 67, (byte)(25 + 58), (byte)(27 + 26), (byte)(35 + 45), (byte)(94 + 3), (byte)(14 + 86), (byte)(99 + 1), (byte)(38 + 67), 110, (byte)(52 + 51)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(80 + 3)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u052c\u0539\u0538\u04fb\u053b\u0537\u0532\u053b\u0546\u0535\u0502\u0540\u0544\u053d\u0540\u0546\u0508\u088d\u0893\u0892\u088e\u08a4\u0895\u089b\u0881\u0893\u0897\u08a4", (byte)13, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 146 | 0 << ~146 + 1) & 0xFFFFFFFF;
        b = Long.reverse(-5004368868347998182L);
        d = Long.reverse(-6917529027641081856L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0513\u0535\u0537\u0517\u053b\u055a\u0552\u0568\u0554\u0523\u0561\u0557\u0565\u055f\u0528\u054d\u056f\u056e\u0566\u056c\u0566\u053b", (byte)47, 70), \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u054e\u055b\u055a\u051d\u055d\u0559\u0554\u055d\u0568\u0557\u0524\u0562\u0566\u055f\u0562\u0568\u052a\u08af\u08b5\u08b4\u08b0\u08c6\u08b7\u08bd\u08a3\u08b5\u08b9\u08c6\u0541", (byte)47, 69) + string + \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u0525", (byte)47, 69) + methodType.toString(), exception);
        }
    }

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        WrapperPlayClientPluginMessage wrapperPlayClientPluginMessage = new WrapperPlayClientPluginMessage(packetReceiveEvent);
        String string = wrapperPlayClientPluginMessage.getChannelName();
        if (!string.equals(\u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0.c("\u3e80", (int)a, (long)(b ^ d)))) {
            return;
        }
        Player player = (Player)packetReceiveEvent.getPlayer();
        if (player == null) {
            return;
        }
        packetReceiveEvent.setCancelled(e != 0);
        \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394.a(this.b).a().a(\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394.a(this.b).b().a(player), wrapperPlayClientPluginMessage.getData());
    }

    public \u03b3\u03b8\u03b6\u03b1\u03c6\u03b6\u03bb\u03a0\u03b1\u03b4\u03c0(\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942) {
        this.b = \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942;
    }
}

