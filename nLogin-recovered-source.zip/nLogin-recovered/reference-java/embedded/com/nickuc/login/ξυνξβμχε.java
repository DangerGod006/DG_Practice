/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5<V extends \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?>>
implements \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 {
    private static int k;
    private static int e;
    private static String[] b;
    private static String[] a;
    private static int l;
    private static int j;
    private static int h;
    private static long b;
    private static int i;
    private static int a;
    private static long c;
    private static int f;
    private static long g;
    protected final V h;
    private static int c;
    private static long d;

    @Generated
    public \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5(V v) {
        this.h = (int)v;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u050c\u052e\u0530\u0510\u0534\u0553\u054b\u0561\u054d\u051c\u055a\u0550\u055e\u0558\u0521\u0546\u0568\u0567\u055f\u0565\u055f\u0534", (byte)101, 67), \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0547\u0554\u0553\u0516\u0556\u0552\u054d\u0556\u0561\u0550\u051d\u055b\u055f\u0558\u055b\u0561\u0523\u08b3\u08bb\u08b4\u08b6\u08ab\u08b6\u08c2\u08b1\u0537", (byte)101, 68) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u051e", (byte)101, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 5458403721679752587L;
        long l = c ^ 0xBBF0897B26D55751L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), (byte)(38 + 31), (byte)(59 + 24), (byte)(12 + 35), (byte)(17 + 50), 66, (byte)(28 + 39), (byte)(36 + 11), 80, (byte)(13 + 62), (byte)(6 + 61), (byte)(66 + 17), (byte)(10 + 43), (byte)(64 + 16), (byte)(7 + 90), (byte)(78 + 22), (byte)(55 + 45), (byte)(39 + 66), (byte)(9 + 101), (byte)(21 + 82)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(20 + 48), 69, (byte)(49 + 34)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u050a\u0527\u0516\u0524\u0520\u0522\u051d\u0522\u051f\u0506\u0545\u050d\u054e\u0556\u052e\u0542\u051b\u0531\u0528\u0526\u052f\u0555\u054c\u053a\u0550\u055d\u0565\u051e\u0567\u0536\u0548\u055a", (byte)95, 67);
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0553\u0570\u055f\u056d\u0569\u056b\u0566\u056b\u0568\u054f\u058e\u0556\u0597\u059f\u0577\u058b\u0564\u057a\u0571\u056f\u0578\u0597\u0564\u057b\u057b\u05ad\u0582\u0584\u056c\u058f\u0590\u05a4\u0574\u0596\u0586\u05a1\u0584\u05b0\u05ad\u0599\u05bc\u0596\u057d\u0583", (byte)95, 70);
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0571\u0580\u0568\u0582\u0570\u0589\u057b\u0563\u055b\u0569\u0587\u0576\u0597\u0576\u0559\u059c\u0583\u0593\u05a2\u05a1\u059c\u0565\u0584\u0586\u0568\u056a\u056b\u057a\u057e\u0589\u0588\u05aa\u0583\u056b\u05aa\u058a\u0596\u0593\u059b\u05aa\u0596\u0579\u05a8\u0583", (byte)95, 69);
                    continue block7;
                }
                case 1: {
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0175\u0192\u0181\u018f\u018b\u018d\u0188\u018d\u018a\u0171\u01b0\u0178\u01b9\u01c1\u0199\u01ad\u0186\u019c\u0193\u0191\u019a\u01c0\u0186\u01c2\u01c1\u01c1\u01a1\u01a5\u01a4\u019b\u01c0\u01c9\u01b4\u01b3\u01b0\u0196\u01af\u0193\u0195\u0194\u0199\u01b4\u019f\u01a5", (byte)95, 66);
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0175\u0192\u0181\u018f\u018b\u018d\u0188\u018d\u018a\u0171\u01b0\u0178\u01b9\u01c1\u0199\u01ad\u0186\u019c\u0193\u0191\u019a\u01b9\u0186\u019d\u019d\u01cf\u01a4\u01a6\u018e\u01b1\u01b2\u01c6\u01b0\u01b2\u01d9\u01a6\u01a6\u01b6\u01dc\u01aa\u01b1\u01d6\u0197\u01a5", (byte)95, 65);
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[2] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0528\u0537\u051f\u0539\u0527\u0540\u0532\u051a\u0512\u0520\u053e\u052d\u054e\u052d\u0510\u0553\u053a\u054a\u0559\u0558\u0553\u051c\u053b\u053d\u051f\u0521\u0522\u0531\u0535\u0540\u053f\u0561\u054c\u0555\u055e\u0558\u053e\u052f\u053a\u055e\u056d\u053d\u056b\u053a", (byte)95, 68);
                    continue block7;
                }
                case 2: {
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0520\u0536\u0540\u0541\u0545\u050e\u050b\u054b\u053d\u0547\u0540\u0516\u0535\u050e\u0554\u0554\u0519\u0553\u0545\u0554\u053b\u0549\u0540\u051e\u0530\u0538\u053f\u0531\u0533\u055b\u056a\u055d", (byte)95, 67);
                    continue block7;
                }
                case 4: {
                    \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0533\u0539\u0528\u053d\u0543\u052b\u0551\u050f\u0525\u051f\u0529\u0552\u0517\u050e\u0550\u0526\u0527\u052d\u0527\u0550\u0549\u054e\u0525\u0526", (byte)95, 67);
                }
            }
        }
    }

    @Override
    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, Object object, byte[] byArray) {
        if (object == null) {
            throw new IllegalArgumentException((String)\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.c("\u3e80", (int)a, (long)b));
        }
        if (object instanceof String && ((String)object).isEmpty()) {
            throw new IllegalArgumentException((String)\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.c("\u3e83", (int)c, (long)d));
        }
        if (byArray == null) {
            throw new IllegalArgumentException((String)\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.c("\u3e86", (int)(e & f), (long)g));
        }
        if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 != null) {
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a((\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?>)this.h, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, object, byArray);
            return h != 0;
        }
        for (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62 : this.h.b().c()) {
            if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62.R()) continue;
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62.a((\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?>)this.h, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, object, byArray);
            return i != 0;
        }
        return j != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x4CL;
        l ^= 0xBBF0897B26D55751L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), 69, (byte)(68 + 15), (byte)(41 + 6), (byte)(12 + 55), (byte)(61 + 5), (byte)(24 + 43), (byte)(14 + 33), (byte)(66 + 14), 75, (byte)(17 + 50), (byte)(72 + 11), (byte)(16 + 37), (byte)(72 + 8), (byte)(43 + 54), (byte)(25 + 75), (byte)(91 + 9), (byte)(61 + 44), (byte)(66 + 44), (byte)(78 + 25)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(41 + 28), (byte)(24 + 59)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0144\u0151\u0150\u0113\u0153\u014f\u014a\u0153\u015e\u014d\u011a\u0158\u015c\u0155\u0158\u015e\u0120\u04b0\u04b8\u04b1\u04b3\u04a8\u04b3\u04bf\u04ae", (byte)49, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-2039524887220714542L);
        c = 0x400000 >>> 182 | 0x400000 << -182;
        d = Long.reverse(-2039524887220714542L);
        e = (32768 >>> 110 | 32768 << ~110 + 1) & 0xFFFFFFFF;
        f = Integer.reverse(-1);
        g = Long.reverse(-2039524887220714542L);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = 32 >>> 101 | 32 << ~101 + 1;
        j = (0 >>> 148 | 0 << -148) & 0xFFFFFFFF;
        k = (0x1800000 >>> 183 | 0x1800000 << -183) & 0xFFFFFFFF;
        l = (3072 >>> 42 | 3072 << ~42 + 1) & 0xFFFFFFFF;
        a = new String[k];
        b = new String[l];
        \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5.b();
    }
}

