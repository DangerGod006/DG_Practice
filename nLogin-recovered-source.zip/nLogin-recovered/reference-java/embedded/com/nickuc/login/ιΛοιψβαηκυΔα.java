/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0;
import com.nickuc.login.\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b;

class \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1 {
    private static int d;
    private static int i;
    private static int h;
    private static int b;
    private static int a;
    private static int g;
    private static int f;
    static final /* synthetic */ int[] O;
    static final /* synthetic */ int[] N;
    private static int c;
    private static int j;
    static final /* synthetic */ int[] P;
    private static int e;

    static {
        a = 0x2000000 >>> 217 | 0x2000000 << ~217 + 1;
        b = (4 >>> 225 | 4 << ~225 + 1) & 0xFFFFFFFF;
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (0x1000000 >>> 55 | 0x1000000 << -55) & 0xFFFFFFFF;
        e = Integer.reverse(-1073741824);
        f = Integer.reverse(0x20000000);
        g = 524288 >>> 19 | 524288 << -19;
        h = Integer.reverse(0x40000000);
        i = Integer.reverse(-1073741824);
        j = Integer.reverse(0x20000000);
        P = new int[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.values().length];
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.P[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.d.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.P[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.e.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        O = new int[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.values().length];
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.O[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.a.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.O[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.O[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.c.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.O[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.d.ordinal()] = f;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        N = new int[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.values().length];
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.N[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b.ordinal()] = g;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.N[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.c.ordinal()] = h;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.N[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.d.ordinal()] = i;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u039b\u03bf\u03b9\u03c8\u03b2\u03b1\u03b7\u03ba\u03c5\u0394\u03b1.N[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.e.ordinal()] = j;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

