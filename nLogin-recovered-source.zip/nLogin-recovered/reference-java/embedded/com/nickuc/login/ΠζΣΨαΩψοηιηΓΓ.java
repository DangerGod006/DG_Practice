/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3;

public interface \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393
extends \u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3 {
    public void a(String var1, Throwable var2);

    public void r(String var1);

    public void s(String var1);

    public void b(String var1, Throwable var2);

    public void q(String var1);
}

