/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.java.JavaPlugin
 */
package com.nickuc.login;

import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import lombok.Generated;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2
implements \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 {
    private static int a = (0 >>> 62 | 0 << ~62 + 1) & 0xFFFFFFFF;
    private final \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 b;
    private final boolean N;
    @Nullable
    private final Player b = new \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2();
    private final BukkitLoader c;

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, runnable).a((JavaPlugin)this.c);
    }

    @Override
    public \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a() {
        return this.b;
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, TimeUnit timeUnit) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, consumer).a((JavaPlugin)this.c, l, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l, long l2, TimeUnit timeUnit) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, runnable).a((JavaPlugin)this.c, l, l2, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, long l2, TimeUnit timeUnit) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, consumer).a((JavaPlugin)this.c, l, l2, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, consumer).a((JavaPlugin)this.c);
    }

    @Generated
    private \u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2(BukkitLoader bukkitLoader, @Nullable Player player, boolean bl) {
        this.c = bukkitLoader;
        this.b = player;
        this.N = bl;
    }

    public \u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2(BukkitLoader bukkitLoader, boolean bl) {
        this(bukkitLoader, null, bl);
    }

    @Override
    public void Y() {
        \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7.a((JavaPlugin)this.c);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l, TimeUnit timeUnit) {
        return new \u03c7\u03c8\u03ba\u03be\u03b3\u03b9\u03b4\u03b8\u03a3\u03c8\u03b7(this.b, this.N, this.b, runnable).a((JavaPlugin)this.c, l, timeUnit);
    }

    public \u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2(BukkitLoader bukkitLoader, @Nullable Player player) {
        this(bukkitLoader, player, a != 0);
    }
}

