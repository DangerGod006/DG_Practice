/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03be\u03bb\u03a9\u03a0\u03bb\u03b6\u03c5\u03c5 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    private static int b = Integer.reverse(0x40000000);
    static final /* synthetic */ int[] v;

    static {
        v = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03be\u03bb\u03a9\u03a0\u03bb\u03b6\u03c5\u03c5.v[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.i.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03be\u03bb\u03a9\u03a0\u03bb\u03b6\u03c5\u03c5.v[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.j.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

