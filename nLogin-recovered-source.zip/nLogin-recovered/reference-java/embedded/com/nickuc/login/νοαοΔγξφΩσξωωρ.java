/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03bd\u03bf\u03b1\u03bf\u0394\u03b3\u03be\u03c6\u03a9\u03c3\u03be\u03c9\u03c9\u03c1 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] E;
    private static int b = Integer.reverse(0x40000000);

    static {
        E = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03bd\u03bf\u03b1\u03bf\u0394\u03b3\u03be\u03c6\u03a9\u03c3\u03be\u03c9\u03c9\u03c1.E[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bd\u03bf\u03b1\u03bf\u0394\u03b3\u03be\u03c6\u03a9\u03c3\u03be\u03c9\u03c9\u03c1.E[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

