/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.argon2.Argon2Factory
 *  com.nickuc.login.lib.argon2.Argon2Factory$Argon2Types
 */
package com.nickuc.login;

import com.nickuc.login.lib.argon2.Argon2Factory;
import com.nickuc.login.\u03a9\u03bb\u03c7\u03a6\u039b\u03be\u03b4\u03bc\u03b9\u03bc\u03a8\u03b2\u03c5\u03a0\u03c6;

public class \u03a3\u03b3\u039b\u03bb\u03a9\u03c4\u03c0\u03c5\u03a8\u03b5\u03b4
extends \u03a9\u03bb\u03c7\u03a6\u039b\u03be\u03b4\u03bc\u03b9\u03bc\u03a8\u03b2\u03c5\u03a0\u03c6 {
    public \u03a3\u03b3\u039b\u03bb\u03a9\u03c4\u03c0\u03c5\u03a8\u03b5\u03b4() {
        super(Argon2Factory.create((Argon2Factory.Argon2Types)Argon2Factory.Argon2Types.ARGON2i));
    }
}

