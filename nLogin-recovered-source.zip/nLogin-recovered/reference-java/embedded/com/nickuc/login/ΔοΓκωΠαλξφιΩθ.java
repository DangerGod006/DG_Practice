/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.nLoginAPI
 */
package com.nickuc.login;

import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.\u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u03c7\u03a3\u03c5\u03c3\u03c6\u03bb\u03b5\u03bb\u03a3\u03bc\u03b5\u03c8\u03be;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8 {
    public boolean a();

    public \u03c7\u03a3\u03c5\u03c3\u03c6\u03bb\u03b5\u03bb\u03a3\u03bc\u03b5\u03c8\u03be a();

    public void b();

    public nLoginAPI a();

    public \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 a();

    public void c();

    public \u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0 a();
}

