/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class \u03b3\u03c5\u03b8\u03b6\u03c2\u03c0\u0394\u03a0\u03a8
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int a = (0x10000000 >>> 188 | 0x10000000 << -188) & 0xFFFFFFFF;
    private final nLoginBukkit f;

    @EventHandler(priority=EventPriority.HIGH)
    public void a(AsyncPlayerChatEvent asyncPlayerChatEvent) {
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.f.b().a(asyncPlayerChatEvent.getPlayer());
        if (this.f.a().b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, asyncPlayerChatEvent.getMessage())) {
            asyncPlayerChatEvent.setCancelled(a != 0);
        }
    }

    @Generated
    public \u03b3\u03c5\u03b8\u03b6\u03c2\u03c0\u0394\u03a0\u03a8(nLoginBukkit nLoginBukkit2) {
        this.f = nLoginBukkit2;
    }
}

