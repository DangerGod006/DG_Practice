/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03b6\u03b9\u03be\u03b6\u03c1\u03b4\u03bd\u03b4\u03c8 {
    private static int b;
    private static int a;
    static final /* synthetic */ int[] w;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        w = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03b6\u03b9\u03be\u03b6\u03c1\u03b4\u03bd\u03b4\u03c8.w[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.o.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b6\u03b9\u03be\u03b6\u03c1\u03b4\u03bd\u03b4\u03c8.w[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.p.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

