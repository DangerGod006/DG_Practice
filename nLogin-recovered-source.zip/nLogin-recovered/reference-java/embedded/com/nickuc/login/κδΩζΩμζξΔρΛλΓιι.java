/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b1\u03c5\u03a9\u03be\u03c4\u03ba\u039b;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03be\u03a0\u03c4\u03a3\u03c4\u03b3\u03b1\u03c8\u03b7\u03c1\u03c8\u0393\u03a0\u03c4\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.sql.ResultSet;
import java.util.Base64;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9
extends \u03be\u03a0\u03c4\u03a3\u03c4\u03b3\u03b1\u03c8\u03b7\u03c1\u03c8\u0393\u03a0\u03c4\u03be {
    private static int cz;
    private static int ce;
    private static int bq;
    private static int aj;
    private static int dm;
    private static int ct;
    private static int bt;
    private static long ba;
    private static int bz;
    private static long p;
    private static int cm;
    private static long db;
    private static long de;
    private static int bp;
    private static long cl;
    private static int be;
    private static int df;
    private static int cn;
    private static int f;
    private static long dj;
    private static String[] f;
    private static int cb;
    private static int ax;
    private static long cv;
    private static int di;
    private static String[] e;
    private static int dh;
    private static long bv;
    private static long cd;
    private static long dg;
    private static int dl;
    private static long br;
    private static long bj;
    private static int cu;
    private static int ck;
    private static int da;
    private static int ch;
    private static long as;
    private static long bh;
    private static int bx;
    private static long cy;
    private static int ag;
    private static long bb;
    private static long o;
    private static long cr;
    private static long bw;
    private static long co;

    @Override
    protected void c(\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22) {
        File file = new File(this.b(), (String)\u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.c("\u3e80", (int)ax, (long)(ba ^ bb)));
        this.d = \u03a9\u03b1\u03c5\u03a9\u03be\u03c4\u03ba\u039b.a(this.m, file, new Properties());
    }

    public \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.B, (String)\u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.c("\u3e80", (int)f, (long)p), (String)\u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.c("\u3e83", (int)(ag & aj), (long)as));
    }

    static {
        f = Integer.reverse(0);
        p = Long.reverse(7055144638940908633L);
        ag = 2048 >>> 43 | 2048 << ~43 + 1;
        aj = -1 >>> 151 | -1 << -151;
        as = Long.reverse(7055144638940908633L);
        ax = Integer.reverse(0x40000000);
        ba = Long.reverse(6622799074713341017L);
        bb = Long.reverse(0x3A00000000000000L);
        be = Integer.reverse(-1073741824);
        bh = Long.reverse(6622799074713341017L);
        bj = Long.reverse(0x3A00000000000000L);
        bp = (0x400000 >>> 212 | 0x400000 << ~212 + 1) & 0xFFFFFFFF;
        bq = Integer.reverse(-1);
        br = Long.reverse(7055144638940908633L);
        bt = Integer.reverse(-1610612736);
        bv = Long.reverse(6622799074713341017L);
        bw = Long.reverse(0x3A00000000000000L);
        bx = (-1 >>> 81 | -1 << ~81 + 1) & 0xFFFFFFFF;
        bz = (3072 >>> 73 | 3072 << ~73 + 1) & 0xFFFFFFFF;
        cb = Integer.reverse(-1);
        cd = Long.reverse(7055144638940908633L);
        ce = 0 >>> 80 | 0 << -80;
        ch = Integer.reverse(-536870912);
        ck = Integer.reverse(-1);
        cl = Long.reverse(7055144638940908633L);
        cm = (0x400000 >>> 22 | 0x400000 << ~22 + 1) & 0xFFFFFFFF;
        cn = (2048 >>> 8 | 2048 << ~8 + 1) & 0xFFFFFFFF;
        co = Long.reverse(6622799074713341017L);
        cr = Long.reverse(0x3A00000000000000L);
        ct = 0x800000 >>> 182 | 0x800000 << -182;
        cu = 73728 >>> 173 | 73728 << ~173 + 1;
        cv = Long.reverse(6622799074713341017L);
        cy = Long.reverse(0x3A00000000000000L);
        cz = Integer.reverse(-1073741824);
        da = (5120 >>> 233 | 5120 << -233) & 0xFFFFFFFF;
        db = Long.reverse(6622799074713341017L);
        de = Long.reverse(0x3A00000000000000L);
        df = Integer.reverse(-805306368);
        dg = Long.reverse(7055144638940908633L);
        dh = (0xC00000 >>> 148 | 0xC00000 << ~148 + 1) & 0xFFFFFFFF;
        di = Integer.reverse(-1);
        dj = Long.reverse(7055144638940908633L);
        dl = Integer.reverse(-1342177280);
        dm = 0x1A000000 >>> 217 | 0x1A000000 << ~217 + 1;
        e = new String[dl];
        f = new String[dm];
        \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.b();
    }

    private static void b() {
        int n;
        o = -7336142950783051814L;
        long l = o ^ 0xCB6BCB12D082DAB6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(51 + 18), (byte)(22 + 61), (byte)(22 + 25), (byte)(36 + 31), (byte)(23 + 43), (byte)(26 + 41), (byte)(20 + 27), (byte)(65 + 15), (byte)(52 + 23), (byte)(40 + 27), (byte)(39 + 44), 53, (byte)(54 + 26), (byte)(28 + 69), (byte)(61 + 39), (byte)(96 + 4), (byte)(25 + 80), (byte)(63 + 47), (byte)(21 + 82)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(7 + 62), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0178\u014c\u0180\u0151\u0175\u017c\u0141\u015c\u013c\u0176\u0179\u0145\u014d\u0145\u017f\u0169\u0164\u017c\u0189\u0160\u0163\u0185\u015c\u015d", (byte)69, 65);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04cc\u04c8\u04d2\u04f2\u04f4\u0502\u04fa\u04e0\u0503\u04f8\u04c1\u04c3\u04fd\u0505\u04d7\u0501\u04c6\u0502\u04cd\u04ca\u04e7\u0500\u04d7\u04d8", (byte)69, 68);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u056d\u0539\u0557\u053a\u0549\u053f\u0549\u053c\u055d\u0579\u057a\u0549", (byte)69, 70);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0178\u0140\u0170\u017a\u0177\u0180\u017c\u0162\u0162\u0176\u018a\u0151", (byte)69, 65);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[4] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u04d7\u04be\u04d3\u04ca\u04c1\u04da\u04be\u04c4\u04b7\u04d3\u04e2\u04d7\u0500\u0507\u0505\u0500\u04f5\u050c\u0504\u04ec\u04e4\u04ea\u04d7\u04d8", (byte)69, 67);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[5] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u017c\u016c\u013d\u0171\u017d\u0165\u0150\u0174\u0166\u0169\u0160\u0151", (byte)69, 65);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[6] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0558\u056b\u0573\u0535\u0567\u055c\u057d\u0557\u056c\u0573\u053f\u0549", (byte)69, 69);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04ba\u04d8\u04de\u04bf\u0502\u04ee\u04cb\u04d2\u04e1\u04dc\u04fd\u04cc", (byte)69, 67);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u053a\u0551\u057d\u0566\u053a\u0567\u054e\u055e\u0570\u0575\u0560\u0549", (byte)69, 70);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u057a\u056e\u0537\u0552\u056b\u0558\u0569\u056a\u0556\u0580\u056e\u0549", (byte)69, 70);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[10] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0564\u0575\u055a\u052f\u054b\u0536\u0558\u0570\u055a\u056e\u0582\u0549", (byte)69, 70);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[11] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u04e7\u04f8\u04dd\u04b2\u04ce\u04b9\u04db\u04f3\u04dd\u04f1\u0505\u04cc", (byte)69, 68);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[12] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0158\u0150\u014f\u0158\u017b\u0184\u0170\u0154\u017c\u0161\u0160\u0151", (byte)69, 65);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0178\u014c\u0180\u0151\u0175\u017c\u0141\u015c\u013c\u0176\u0177\u0143\u017c\u0161\u0183\u0150\u014e\u017c\u014f\u018a\u018f\u016f\u015c\u015d", (byte)69, 66);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u04cc\u04c8\u04d2\u04f2\u04f4\u0502\u04fa\u04e0\u0503\u04f8\u04c1\u0501\u04c6\u04fc\u04fc\u04db\u04e5\u04d6\u04fc\u04e5\u04e3\u04ea\u04d7\u04d8", (byte)69, 68);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0141\u0177\u0161\u0171\u0180\u013e\u013f\u0149\u0160\u014b\u0142\u0149\u0167\u016f\u015e\u0191\u016d\u018d\u0154\u0170\u0197\u0195\u015c\u015d", (byte)69, 65);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u04b7\u04fb\u04df\u04e9\u04dc\u04fd\u04dc\u0505\u04f2\u04e7\u04df\u04cc", (byte)69, 68);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u04d7\u04be\u04d3\u04ca\u04c1\u04da\u04be\u04c4\u04b7\u04d3\u04e1\u0509\u04ff\u04e6\u04d3\u04e8\u04ed\u0509\u04c6\u04ea\u04e8\u0510\u04d7\u04d8", (byte)69, 67);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u055a\u0573\u0532\u057b\u056a\u0535\u0537\u054b\u0571\u0556\u0576\u0570\u0571\u0560\u0567\u0542\u0586\u0580\u057b\u0560\u0567\u057d\u0554\u0555", (byte)69, 69);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u056e\u0559\u054a\u0568\u0536\u057e\u057d\u0557\u054c\u057c\u0564\u0549", (byte)69, 69);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0538\u056c\u0538\u0538\u0576\u057e\u055a\u0580\u0555\u056b\u056f\u0541\u0581\u0576\u0583\u053b\u0554\u057a\u058d\u0580\u054b\u058d\u0554\u0555", (byte)69, 69);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[8] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0178\u013a\u0152\u0160\u0165\u0162\u0184\u0167\u017f\u0165\u0174\u017f\u0156\u014a\u017f\u016a\u0161\u0193\u016f\u0163\u0188\u016f\u015c\u015d", (byte)69, 65);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u0162\u0172\u0180\u0176\u0154\u015f\u013e\u017d\u0186\u017e\u017c\u015d\u0184\u016d\u015b\u018a\u015d\u016a\u014d\u0188\u0170\u015f\u015c\u015d", (byte)69, 66);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[10] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u016b\u0183\u0140\u0173\u0164\u0164\u015e\u016a\u0159\u0181\u0143\u0151", (byte)69, 66);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[11] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u04d0\u04f5\u04cf\u04bb\u04df\u04fd\u04be\u04df\u04c3\u04ee\u04df\u04cc", (byte)69, 68);
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[12] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0569\u055a\u0577\u054d\u0566\u055e\u057e\u0537\u0550\u0578\u0564\u0549", (byte)69, 69);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0171\u016e\u0159\u0171\u013d\u0179\u0184\u0181\u0148\u017c\u0164\u0151", (byte)69, 66);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.f[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u04b9\u04f2\u04eb\u04cf\u04cd\u04cb\u04cd\u04dd\u04f6\u04de\u04c5\u04f8\u04c4\u04fa\u04da\u04ec\u050c\u04e5\u04c9\u04ea\u04d0\u0510\u04d7\u04d8", (byte)69, 68);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00df\u0101\u0103\u00e3\u0107\u0126\u011e\u0134\u0120\u00ef\u012d\u0123\u0131\u012b\u00f4\u0119\u013b\u013a\u0132\u0138\u0132\u0107", (byte)28, 66), \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u053b\u0548\u0547\u050a\u054a\u0546\u0541\u054a\u0555\u0544\u0511\u054f\u0553\u054c\u054f\u0555\u0517\u08a3\u089e\u0894\u08a2\u0896\u08aa\u08a5\u08ae\u0885\u08b3\u088e\u08af\u0888\u08af\u08b0\u0532", (byte)28, 69) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u00f1", (byte)28, 65) + methodType.toString(), exception);
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    protected void b(ResultSet var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$TooOptimisticMatchException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.getString(SwitchStringRewriter.java:404)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.access$600(SwitchStringRewriter.java:53)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$SwitchStringMatchResultCollector.collectMatches(SwitchStringRewriter.java:368)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneN.match(KleeneN.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence.match(MatchSequence.java:26)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:23)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewriteComplex(SwitchStringRewriter.java:201)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewrite(SwitchStringRewriter.java:73)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:881)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static String a(int n, long l) {
        l ^= 0x5CL;
        l ^= 0xCB6BCB12D082DAB6L;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(36 + 32), (byte)(54 + 15), (byte)(33 + 50), (byte)(38 + 9), (byte)(28 + 39), (byte)(18 + 48), 67, (byte)(7 + 40), (byte)(72 + 8), 75, (byte)(65 + 2), (byte)(82 + 1), (byte)(30 + 23), (byte)(61 + 19), (byte)(78 + 19), (byte)(43 + 57), (byte)(53 + 47), (byte)(92 + 13), (byte)(15 + 95), (byte)(17 + 86)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(75 + 8)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u015c\u0169\u0168\u012b\u016b\u0167\u0162\u016b\u0176\u0165\u0132\u0170\u0174\u016d\u0170\u0176\u0138\u04c4\u04bf\u04b5\u04c3\u04b7\u04cb\u04c6\u04cf\u04a6\u04d4\u04af\u04d0\u04a9\u04d0\u04d1", (byte)61, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03b4\u03a9\u03b6\u03a9\u03bc\u03b6\u03be\u0394\u03c1\u039b\u03bb\u0393\u03b9\u03b9.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }
}

