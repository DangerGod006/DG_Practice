/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8
extends Enum<\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8> {
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 a;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 b;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 c;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 d;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 e;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 f;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 g;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 h;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 i;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 j;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 k;
    public static final /* enum */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 l;
    private final \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2 a;
    private static final /* synthetic */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static long d;
    private static long e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static int k;
    private static int l;
    private static int m;
    private static int n;
    private static int o;
    private static int p;
    private static int q;
    private static int r;
    private static int s;
    private static int t;
    private static int u;
    private static int v;
    private static long w;
    private static long x;
    private static int y;
    private static int z;
    private static long aa;
    private static long ab;
    private static int ac;
    private static int ad;
    private static long ae;
    private static int af;
    private static int ag;
    private static long ah;
    private static long ai;
    private static int aj;
    private static int ak;
    private static long al;
    private static long am;
    private static int an;
    private static int ao;
    private static long ap;
    private static int aq;
    private static int ar;
    private static long as;
    private static long at;
    private static int au;
    private static int av;
    private static long aw;
    private static long ax;
    private static int ay;
    private static int az;
    private static int ba;
    private static long bb;
    private static int bc;
    private static int bd;
    private static int be;
    private static long bf;
    private static int bg;
    private static int bh;
    private static int bi;
    private static long bj;
    private static int bk;
    private static int bl;
    private static long bm;
    private static int bn;

    @Generated
    private \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2 \u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2) {
        this.a = \u03c3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
    }

    public static \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[] values() {
        return (\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[])a.clone();
    }

    public static String a(String string, \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 ... \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array) {
        if (string == null) {
            throw new IllegalArgumentException((String)\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.c("\u3e80", (int)b, (long)(d ^ e)));
        }
        Object[] objectArray = new String[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array.length];
        for (int i = f; i < objectArray.length; ++i) {
            objectArray[i] = \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[i].getName();
        }
        return String.format(string, objectArray);
    }

    private static void b() {
        int n;
        c = -5897729883472160052L;
        long l = c ^ 0x18910A2185B29245L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(46 + 23), (byte)(69 + 14), (byte)(5 + 42), 67, (byte)(48 + 18), (byte)(63 + 4), (byte)(16 + 31), (byte)(10 + 70), (byte)(5 + 70), (byte)(30 + 37), (byte)(45 + 38), (byte)(52 + 1), (byte)(47 + 33), (byte)(92 + 5), (byte)(83 + 17), (byte)(13 + 87), (byte)(25 + 80), (byte)(69 + 41), (byte)(40 + 63)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(67 + 2), (byte)(45 + 38)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u056f\u053e\u0560\u0578\u0557\u056e\u0581\u0583\u0588\u0566\u0552\u0579\u0586\u058a\u0581\u0582\u056c\u0586\u058e\u0550\u054a\u058f\u056a\u0573\u0573\u0562\u0598\u055a\u0597\u0558\u0568\u05a0", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u056b\u0549\u056b\u0554\u056e\u055d\u0543\u0579\u0558\u057b\u0580\u054f", (byte)75, 70);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u04ef\u04d0\u04e5\u0502\u050d\u04e5\u04de\u050b\u04f6\u04e1\u04d3\u04d4\u04f4\u04f7\u04e8\u04f8\u04f4\u04dd\u0513\u04f0\u04f6\u0512\u04e9\u04ea", (byte)75, 68);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[3] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0550\u0582\u0539\u0564\u0540\u0554\u0552\u0559\u0558\u0565\u0586\u0575\u056c\u0549\u058a\u057f\u0566\u0590\u0586\u057f\u058d\u055d\u055a\u055b", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04fd\u0508\u04eb\u0506\u04db\u050b\u04fd\u04ea\u0504\u050b\u0514\u0508\u04f5\u0509\u0512\u051b\u04f5\u04f2\u04ef\u04e0\u04ff\u04ec\u04e9\u04ea", (byte)75, 67);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[5] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0166\u014c\u0181\u0181\u014b\u014a\u014f\u017f\u016d\u0189\u0185\u0192\u0164\u0168\u0166\u0193\u017a\u0170\u0198\u0169\u01a2\u017b\u0168\u0169", (byte)75, 65);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[6] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0184\u016c\u0179\u014c\u0151\u0174\u017e\u0173\u0175\u016c\u0178\u0156\u0177\u0171\u0157\u018b\u015e\u015d\u0168\u0182\u018c\u016b\u0168\u0169", (byte)75, 65);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[7] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u015e\u0166\u0168\u0147\u016e\u014f\u017d\u0196\u014f\u0160\u0182\u015d", (byte)75, 65);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[8] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u015e\u0186\u016f\u0192\u016b\u0172\u017d\u0150\u018c\u016b\u0180\u0168\u014c\u0190\u019a\u0186\u0186\u019c\u017e\u0178\u017a\u0191\u0168\u0169", (byte)75, 66);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[9] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0506\u04f1\u04d0\u0510\u0512\u0503\u050e\u04ed\u0510\u0517\u0518\u04ee\u0517\u04d6\u0511\u050a\u04f0\u0511\u04ed\u0522\u0518\u0512\u04e9\u04ea", (byte)75, 67);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[10] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0500\u04ea\u04fe\u04da\u04f2\u04d4\u0514\u04de\u0502\u0512\u04d8\u04de", (byte)75, 68);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[11] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u054e\u055e\u0541\u056d\u0550\u0584\u0562\u057d\u0550\u0586\u0574\u054f", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[12] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0510\u04ea\u050a\u04f2\u04e2\u04c6\u050f\u04fe\u04f0\u0509\u0508\u04f0\u04d4\u04f4\u0510\u04f8\u04f8\u04f2\u0519\u04f6\u0513\u04fc\u04e9\u04ea", (byte)75, 67);
                    continue block7;
                }
                case 1: {
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u017d\u014c\u016e\u0186\u0165\u017c\u018f\u0191\u0196\u0174\u0160\u0187\u0194\u0198\u018f\u0190\u017a\u0194\u019c\u015e\u0158\u019e\u0178\u0197\u01a5\u015f\u01a3\u0163\u01a6\u017b\u0174\u0168", (byte)75, 66);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u04ea\u04e4\u0505\u04ec\u04cb\u04e6\u0504\u04cc\u0515\u04f5\u0513\u04de", (byte)75, 68);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u016e\u014f\u0164\u0181\u018c\u0164\u015d\u018a\u0175\u0160\u0152\u0189\u0197\u0172\u0190\u019b\u018d\u0188\u019a\u0193\u0173\u017b\u0168\u0169", (byte)75, 65);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[3] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0550\u0582\u0539\u0564\u0540\u0554\u0552\u0559\u0558\u0565\u0587\u058b\u0555\u0584\u0546\u0581\u058e\u0580\u0566\u0583\u0554\u0583\u055a\u055b", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u056e\u0579\u055c\u0577\u054c\u057c\u056e\u055b\u0575\u057c\u0587\u0555\u056c\u055b\u0578\u0545\u055b\u0590\u058a\u0582\u056a\u0593\u055a\u055b", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[5] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0166\u014c\u0181\u0181\u014b\u014a\u014f\u017f\u016d\u0189\u0183\u0172\u0164\u018c\u0195\u0187\u0186\u018e\u015e\u0199\u016e\u016b\u0168\u0169", (byte)75, 66);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0576\u055e\u056b\u053e\u0543\u0566\u0570\u0565\u0567\u055e\u056b\u0586\u055c\u0580\u0579\u0589\u0561\u054c\u057e\u055b\u0561\u0583\u055a\u055b", (byte)75, 70);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[7] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04cd\u04e9\u04f1\u04e1\u04d0\u04d4\u0508\u04eb\u0506\u0510\u04f3\u04e5\u04d8\u04f8\u0513\u04f6\u0518\u04f5\u0515\u0521\u050b\u04ec\u04e9\u04ea", (byte)75, 67);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[8] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u04df\u0507\u04f0\u0513\u04ec\u04f3\u04fe\u04d1\u050d\u04ec\u0502\u051a\u04d4\u04d7\u04f1\u04ea\u04dc\u050d\u050e\u0519\u04ec\u04fc\u04e9\u04ea", (byte)75, 67);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[9] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0506\u04f1\u04d0\u0510\u0512\u0503\u050e\u04ed\u0510\u0517\u051a\u04f0\u04f9\u04e8\u04e6\u0514\u04ea\u04d6\u04fd\u04ec\u0518\u04f3\u051f\u04f7\u04fa\u04e4\u04e8\u04e2\u0504\u04e6\u04df\u0529", (byte)75, 68);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[10] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u0187\u0177\u014f\u0165\u0193\u018f\u0150\u016b\u0162\u0161\u0160\u0198\u018e\u0175\u0192\u0153\u0169\u0175\u0179\u0194\u015f\u01a1\u0168\u0169", (byte)75, 66);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[11] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0571\u0533\u057a\u0582\u0570\u0566\u0552\u0553\u0565\u0545\u057b\u058a\u0557\u0560\u054e\u0579\u0585\u0589\u055e\u056a\u0574\u055d\u055a\u055b", (byte)75, 69);
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[12] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0581\u055b\u057b\u0563\u0553\u0537\u0580\u056f\u0561\u057a\u057b\u0545\u0576\u057c\u0581\u057e\u0584\u057e\u0570\u058e\u0573\u055d\u055a\u055b", (byte)75, 70);
                    continue block7;
                }
                case 2: {
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0573\u0573\u0550\u0576\u0583\u0572\u0585\u0542\u055f\u0572\u0568\u0543\u058a\u0588\u0547\u056d\u054a\u0562\u0568\u054a\u056d\u055d\u055a\u055b", (byte)75, 70);
                    continue block7;
                }
                case 4: {
                    \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0568\u0538\u056a\u0574\u055a\u057c\u055c\u0565\u057c\u0553\u0584\u0581\u055b\u055e\u0562\u0589\u0584\u0590\u056e\u058c\u0588\u055d\u055a\u055b", (byte)75, 69);
                }
            }
        }
    }

    private static /* synthetic */ \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[] a() {
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[] \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[g];
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.h] = a;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.i] = b;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.j] = c;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.k] = d;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.l] = e;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.m] = f;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.n] = g;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.o] = h;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.p] = i;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.q] = j;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.r] = k;
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array[\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.s] = l;
        return \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8Array;
    }

    static {
        a = Integer.reverse(0);
        b = 0 >>> 15 | 0 << ~15 + 1;
        d = Long.reverse(3700259344398476405L);
        e = Long.reverse(0x5A00000000000000L);
        f = 0 >>> 254 | 0 << ~254 + 1;
        g = Integer.reverse(0x30000000);
        h = (0 >>> 189 | 0 << -189) & 0xFFFFFFFF;
        i = Integer.reverse(Integer.MIN_VALUE);
        j = Integer.reverse(0x40000000);
        k = (393216 >>> 209 | 393216 << -209) & 0xFFFFFFFF;
        l = (Integer.MIN_VALUE >>> 253 | Integer.MIN_VALUE << -253) & 0xFFFFFFFF;
        m = Integer.reverse(-1610612736);
        n = Integer.reverse(0x60000000);
        o = Integer.reverse(-536870912);
        p = Integer.reverse(0x10000000);
        q = 0x480000 >>> 83 | 0x480000 << -83;
        r = (327680 >>> 47 | 327680 << -47) & 0xFFFFFFFF;
        s = (360448 >>> 143 | 360448 << -143) & 0xFFFFFFFF;
        t = Integer.reverse(-1342177280);
        u = 0x34000000 >>> 250 | 0x34000000 << -250;
        v = 16 >>> 68 | 16 << -68;
        w = Long.reverse(3700259344398476405L);
        x = Long.reverse(0x5A00000000000000L);
        y = 0 >>> 117 | 0 << -117;
        z = Integer.reverse(0x40000000);
        aa = Long.reverse(3700259344398476405L);
        ab = Long.reverse(0x5A00000000000000L);
        ac = Integer.reverse(Integer.MIN_VALUE);
        ad = Integer.reverse(-1073741824);
        ae = Long.reverse(7591369422446584949L);
        af = Integer.reverse(0x40000000);
        ag = Integer.reverse(0x20000000);
        ah = Long.reverse(3700259344398476405L);
        ai = Long.reverse(0x5A00000000000000L);
        aj = Integer.reverse(-1073741824);
        ak = 2560 >>> 201 | 2560 << ~201 + 1;
        al = Long.reverse(3700259344398476405L);
        am = Long.reverse(0x5A00000000000000L);
        an = (4 >>> 192 | 4 << ~192 + 1) & 0xFFFFFFFF;
        ao = Integer.reverse(0x60000000);
        ap = Long.reverse(7591369422446584949L);
        aq = 0x40000001 >>> 62 | 0x40000001 << -62;
        ar = Integer.reverse(-536870912);
        as = Long.reverse(3700259344398476405L);
        at = Long.reverse(0x5A00000000000000L);
        au = (98304 >>> 78 | 98304 << -78) & 0xFFFFFFFF;
        av = (0x200000 >>> 114 | 0x200000 << ~114 + 1) & 0xFFFFFFFF;
        aw = Long.reverse(3700259344398476405L);
        ax = Long.reverse(0x5A00000000000000L);
        ay = Integer.reverse(-536870912);
        az = Integer.reverse(-1879048192);
        ba = Integer.reverse(-1);
        bb = Long.reverse(7591369422446584949L);
        bc = Integer.reverse(0x10000000);
        bd = 320 >>> 165 | 320 << -165;
        be = Integer.reverse(-1);
        bf = Long.reverse(7591369422446584949L);
        bg = Integer.reverse(-1879048192);
        bh = Integer.reverse(-805306368);
        bi = Integer.reverse(-1);
        bj = Long.reverse(7591369422446584949L);
        bk = (40960 >>> 12 | 40960 << -12) & 0xFFFFFFFF;
        bl = (6144 >>> 201 | 6144 << ~201 + 1) & 0xFFFFFFFF;
        bm = Long.reverse(7591369422446584949L);
        bn = Integer.reverse(-805306368);
        a = new String[t];
        b = new String[u];
        \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.b();
        a = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.f);
        b = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.g);
        c = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.h);
        d = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.i);
        e = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.j);
        f = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.k);
        g = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.l);
        h = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.m);
        i = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.n);
        j = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.o);
        k = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.p);
        l = new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.q);
        a = \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.a();
    }

    public static \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8 valueOf(String string) {
        return Enum.valueOf(\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.class, string);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0510\u0532\u0534\u0514\u0538\u0557\u054f\u0565\u0551\u0520\u055e\u0554\u0562\u055c\u0525\u054a\u056c\u056b\u0563\u0569\u0563\u0538", (byte)44, 70), \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u013a\u0147\u0146\u0109\u0149\u0145\u0140\u0149\u0154\u0143\u0110\u014e\u0152\u014b\u014e\u0154\u0116\u04a6\u04a7\u04a9\u04a2\u04a7\u04ab\u04ab\u0497\u012a", (byte)44, 66) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0473", (byte)44, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x5AL;
        l ^= 0x18910A2185B29245L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(39 + 29), (byte)(66 + 3), (byte)(12 + 71), (byte)(27 + 20), 67, (byte)(16 + 50), (byte)(6 + 61), (byte)(2 + 45), (byte)(58 + 22), (byte)(29 + 46), (byte)(22 + 45), (byte)(73 + 10), (byte)(29 + 24), 80, (byte)(34 + 63), (byte)(83 + 17), (byte)(30 + 70), (byte)(5 + 100), (byte)(87 + 23), (byte)(59 + 44)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(51 + 18), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u01aa\u01b7\u01b6\u0179\u01b9\u01b5\u01b0\u01b9\u01c4\u01b3\u0180\u01be\u01c2\u01bb\u01be\u01c4\u0186\u0516\u0517\u0519\u0512\u0517\u051b\u051b\u0507", (byte)100, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public String getName() {
        return this.a.a(new Object[a]);
    }
}

