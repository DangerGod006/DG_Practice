/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;
import java.sql.Connection;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03b8\u03b1\u03a3\u03b1\u03b6\u03b6\u03b6
implements \u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 {
    private final int r;
    private static int b;
    private static int a;
    private final \u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 c;
    private final AtomicInteger a;
    private final Connection a = new AtomicInteger();

    @Override
    public void a(Connection connection) {
        if (this.a.get() > 0) {
            connection.commit();
        }
    }

    @Override
    public Connection a() {
        if (this.a.getAndIncrement() >= this.r) {
            this.a.set(b);
            this.a.commit();
        }
        return this.a;
    }

    @Override
    public \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 a() {
        return this.c.a();
    }

    public \u0393\u03b8\u03b1\u03a3\u03b1\u03b6\u03b6\u03b6(\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, int n) {
        this.c = \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
        this.r = n;
        this.a = \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2.a();
        this.a.setAutoCommit(a != 0);
    }

    @Override
    public void c() {
        if (this.a.get() > 0) {
            this.a.commit();
        }
        this.a.close();
    }

    @Generated
    public int c() {
        return this.r;
    }

    static {
        a = (0 >>> 113 | 0 << ~113 + 1) & 0xFFFFFFFF;
        b = (0x10000000 >>> 252 | 0x10000000 << -252) & 0xFFFFFFFF;
    }
}

