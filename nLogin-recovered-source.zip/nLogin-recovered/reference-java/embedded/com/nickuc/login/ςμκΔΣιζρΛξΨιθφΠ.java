/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u03b7\u03b9\u03c7\u03c7\u03a9\u03c9\u03be\u03b3\u03c8\u03b9\u03b4\u03b6\u03b1;
import org.bukkit.entity.Player;

public interface \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0 {
    default public void a(Player player) {
        this.send(player, "");
    }

    public void send(Player var1, String var2);

    public static \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0 a() {
        return \u03b7\u03b9\u03c7\u03c7\u03a9\u03c9\u03be\u03b3\u03c8\u03b9\u03b4\u03b6\u03b1.a();
    }
}

