/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.snakeyaml.DumperOptions
 *  com.nickuc.login.lib.snakeyaml.LoaderOptions
 *  com.nickuc.login.lib.snakeyaml.Yaml
 *  com.nickuc.login.lib.snakeyaml.constructor.BaseConstructor
 *  com.nickuc.login.lib.snakeyaml.constructor.Constructor
 *  com.nickuc.login.lib.snakeyaml.nodes.MappingNode
 *  com.nickuc.login.lib.snakeyaml.nodes.Node
 *  com.nickuc.login.lib.snakeyaml.nodes.NodeTuple
 *  com.nickuc.login.lib.snakeyaml.nodes.ScalarNode
 *  com.nickuc.login.lib.snakeyaml.representer.Representer
 */
package com.nickuc.login;

import com.nickuc.login.lib.snakeyaml.DumperOptions;
import com.nickuc.login.lib.snakeyaml.LoaderOptions;
import com.nickuc.login.lib.snakeyaml.Yaml;
import com.nickuc.login.lib.snakeyaml.constructor.BaseConstructor;
import com.nickuc.login.lib.snakeyaml.constructor.Constructor;
import com.nickuc.login.lib.snakeyaml.nodes.MappingNode;
import com.nickuc.login.lib.snakeyaml.nodes.Node;
import com.nickuc.login.lib.snakeyaml.nodes.NodeTuple;
import com.nickuc.login.lib.snakeyaml.nodes.ScalarNode;
import com.nickuc.login.lib.snakeyaml.representer.Representer;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.function.BiFunction;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba {
    private static int b;
    private static int k;
    private static int a;
    private static String[] b;
    private static long d;
    private static int q;
    private static int j;
    private static long n;
    private static int e;
    private static int g;
    private static long c;
    private static int p;
    private static long i;
    private static long f;
    private static long l;
    private static String[] a;
    private static int c;
    private static long o;
    private static int m;
    private static int h;

    private static String a(int n, long l) {
        l ^= 0x38L;
        l ^= 0xD970E5802C9DD639L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(61 + 8), (byte)(33 + 50), (byte)(18 + 29), (byte)(10 + 57), (byte)(28 + 38), (byte)(22 + 45), (byte)(32 + 15), (byte)(68 + 12), 75, (byte)(64 + 3), (byte)(77 + 6), (byte)(28 + 25), (byte)(27 + 53), (byte)(78 + 19), (byte)(58 + 42), (byte)(64 + 36), 105, (byte)(14 + 96), (byte)(15 + 88)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(49 + 34)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0475\u0482\u0481\u0444\u0484\u0480\u047b\u0484\u048f\u047e\u044b\u0489\u048d\u0486\u0489\u048f\u0451\u07be\u07ed\u07b8\u07ea\u07e7\u07e0\u07dd\u07e4\u07e8\u07e6\u07e5\u07f6\u07e1\u07f0\u07eb", (byte)31, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u048b\u04ad\u04af\u048f\u04b3\u04d2\u04ca\u04e0\u04cc\u049b\u04d9\u04cf\u04dd\u04d7\u04a0\u04c5\u04e7\u04e6\u04de\u04e4\u04de\u04b3", (byte)58, 67), \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0559\u0566\u0565\u0528\u0568\u0564\u055f\u0568\u0573\u0562\u052f\u056d\u0571\u056a\u056d\u0573\u0535\u08a2\u08d1\u089c\u08ce\u08cb\u08c4\u08c1\u08c8\u08cc\u08ca\u08c9\u08da\u08c5\u08d4\u08cf\u0550", (byte)58, 69) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u049d", (byte)58, 67) + methodType.toString(), exception);
        }
    }

    public static MappingNode a(Yaml yaml, File file) {
        Node node;
        try (FileReader fileReader = new FileReader(file);){
            node = yaml.compose((Reader)fileReader);
        }
        if (!(node instanceof MappingNode)) {
            throw new IllegalStateException((String)\u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.c("\u3e80", (int)m, (long)(n ^ o)) + node.getClass().getCanonicalName());
        }
        return (MappingNode)node;
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(0);
        c = (-1 >>> 164 | -1 << -164) & 0xFFFFFFFF;
        d = Long.reverse(808794730305359064L);
        e = 0x2000000 >>> 249 | 0x2000000 << ~249 + 1;
        f = Long.reverse(808794730305359064L);
        g = 8192 >>> 12 | 8192 << -12;
        h = Integer.reverse(-1);
        i = Long.reverse(808794730305359064L);
        j = Integer.reverse(-1073741824);
        k = -1 >>> 175 | -1 << ~175 + 1;
        l = Long.reverse(808794730305359064L);
        m = 65536 >>> 78 | 65536 << ~78 + 1;
        n = Long.reverse(1673485858760494296L);
        o = Long.reverse(0x1C00000000000000L);
        p = Integer.reverse(-1610612736);
        q = Integer.reverse(-1610612736);
        a = new String[p];
        b = new String[q];
        \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b();
    }

    public static Yaml a(boolean bl) {
        LoaderOptions loaderOptions = new LoaderOptions();
        loaderOptions.setProcessComments(bl);
        DumperOptions dumperOptions = new DumperOptions();
        dumperOptions.setProcessComments(bl);
        return new Yaml((BaseConstructor)new Constructor(loaderOptions), new Representer(dumperOptions), dumperOptions, loaderOptions);
    }

    private static void b() {
        int n;
        c = 1959329882317429992L;
        long l = c ^ 0xD970E5802C9DD639L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(19 + 49), (byte)(18 + 51), (byte)(41 + 42), (byte)(15 + 32), (byte)(43 + 24), (byte)(55 + 11), (byte)(33 + 34), (byte)(3 + 44), (byte)(16 + 64), (byte)(46 + 29), 67, (byte)(81 + 2), (byte)(3 + 50), (byte)(61 + 19), (byte)(22 + 75), (byte)(21 + 79), 100, (byte)(58 + 47), (byte)(90 + 20), (byte)(90 + 13)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(8 + 75)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u057a\u0584\u0557\u0550\u054d\u0567\u0590\u0591\u0574\u0565\u054d\u0591\u058c\u0565\u0591\u0569\u0597\u0574\u055a\u057b\u056f\u0573\u0570\u0576\u05a3\u0590\u0573\u0572\u0579\u059c\u0583\u059a\u0582\u056b\u05a6\u059c\u0588\u056d\u057d\u058f\u05a3\u05b0\u0593\u057c", (byte)117, 67);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u055b\u0546\u0564\u0566\u056f\u0584\u0580\u0575\u056f\u0572\u0577\u055c", (byte)117, 68);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0561\u057c\u054b\u0568\u057e\u0585\u0590\u0550\u054e\u056a\u0581\u055c", (byte)117, 67);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[3] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u01b5\u0199\u01d0\u01b2\u01b3\u01a5\u01c5\u01c7\u01dd\u01d6\u01e2\u01b1", (byte)117, 66);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[4] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u01cf\u01d9\u01ac\u01a5\u01a2\u01bc\u01e5\u01e6\u01c9\u01ba\u01ac\u01c7\u01bf\u01ec\u01c2\u01e3\u01bd\u01ea\u01c7\u01e4\u01c6\u01df\u01f4\u01e7\u01ed\u01f0\u01b4\u01f9\u01ca\u01cd\u01e8\u01fd\u01ed\u01e2\u01c0\u01d3\u01db\u01f2\u01dc\u01d7\u01df\u01dd\u01e4\u01d1", (byte)117, 65);
                    continue block7;
                }
                case 1: {
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u057a\u0584\u0557\u0550\u054d\u0567\u0590\u0591\u0574\u0565\u054d\u0591\u058c\u0565\u0591\u0569\u0597\u0574\u055a\u057b\u056f\u0573\u0570\u0576\u05a3\u0590\u0573\u0572\u0579\u059c\u0583\u059a\u059e\u05af\u05a1\u05a2\u059f\u057e\u059b\u0589\u0593\u05a7\u0587\u057c", (byte)117, 68);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u01b3\u01d3\u01b4\u01ad\u01b3\u01a0\u01b2\u01be\u01cb\u01dd\u01ea\u01b1", (byte)117, 66);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u0565\u056e\u058a\u0582\u058f\u058a\u0562\u056c\u0561\u0568\u056f\u055c", (byte)117, 68);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u019b\u01bd\u01bb\u01da\u01b8\u01e1\u01b4\u01da\u01a1\u01c0\u01a7\u01b1", (byte)117, 65);
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0597\u05a1\u0574\u056d\u056a\u0584\u05ad\u05ae\u0591\u0582\u0574\u058f\u0587\u05b4\u058a\u05ab\u0585\u05b2\u058f\u05ac\u058e\u05a7\u05bc\u05af\u05b5\u05b8\u057c\u05c1\u0592\u0595\u05b0\u05c5\u0594\u0595\u05bb\u05ac\u0586\u0586\u05ad\u05c1\u05b1\u05a2\u059c\u0599", (byte)117, 69);
                    continue block7;
                }
                case 2: {
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0584\u059a\u059d\u05ae\u057d\u059e\u0569\u057a\u05b3\u05af\u057c\u0579", (byte)117, 69);
                    continue block7;
                }
                case 4: {
                    \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0561\u0561\u05ab\u0577\u05ad\u0590\u0566\u058f\u056b\u05ac\u05b2\u0579", (byte)117, 70);
                }
            }
        }
    }

    public static void a(MappingNode mappingNode, String string, BiFunction<String, Node, Node> biFunction) {
        List list = mappingNode.getValue();
        for (int i = a; i < list.size(); ++i) {
            NodeTuple nodeTuple = (NodeTuple)list.get(i);
            Node node = nodeTuple.getKeyNode();
            if (!(node instanceof ScalarNode)) {
                throw new IllegalStateException((String)\u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.c("\u3e80", (int)(b & c), (long)d) + node.getClass().getCanonicalName() + (String)\u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.c("\u3e83", (int)e, (long)f) + node);
            }
            ScalarNode scalarNode = (ScalarNode)node;
            String string2 = string + (String)(string.isEmpty() ? \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.c("\u3e86", (int)(g & h), (long)\u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.i) : \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.c("\u3e89", (int)(j & k), (long)l)) + scalarNode.getValue();
            Node node2 = nodeTuple.getValueNode();
            if (node2 instanceof MappingNode) {
                \u039b\u03c9\u0393\u03c4\u03c0\u03b8\u03b4\u03ba\u03bd\u03ba\u03b8\u03c8\u03b2\u03c0\u03ba.a((MappingNode)node2, string2, biFunction);
                continue;
            }
            Node node3 = biFunction.apply(string2, node2);
            if (node3 == null) continue;
            list.set(i, new NodeTuple(node, node3));
        }
    }
}

