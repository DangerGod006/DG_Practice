/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;

class \u03bc\u03c1\u03c6\u03c2\u03b9\u03bd\u03c0\u0394\u03b9 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] ag;
    private static int b = 131072 >>> 176 | 131072 << ~176 + 1;

    static {
        ag = new int[\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.values().length];
        try {
            \u03bc\u03c1\u03c6\u03c2\u03b9\u03bd\u03c0\u0394\u03b9.ag[\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.h.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bc\u03c1\u03c6\u03c2\u03b9\u03bd\u03c0\u0394\u03b9.ag[\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.i.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

