/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.geysermc.floodgate.api.player.FloodgatePlayer
 */
package com.nickuc.login;

import lombok.Generated;
import org.geysermc.floodgate.api.player.FloodgatePlayer;

public class \u03bd\u03bc\u03b7\u03b1\u03a3\u03b5\u03c6\u03b7 {
    public final FloodgatePlayer a;

    @Generated
    public \u03bd\u03bc\u03b7\u03b1\u03a3\u03b5\u03c6\u03b7(FloodgatePlayer floodgatePlayer) {
        this.a = floodgatePlayer;
    }
}

