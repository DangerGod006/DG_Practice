/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import javax.annotation.Nullable;

public interface \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 {
    default public void g(String string, String string2) {
        this.a(string, null, null, string2, null);
    }

    default public void f(String string, String string2) {
        this.a(string, null, string2, null, null);
    }

    default public void d(String string, String string2) {
        this.a(string, string2, null, null, null);
    }

    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a();

    default public void b(String string, String string2, String string3) {
        this.a(string, string2, string3, null, null);
    }

    public void a(int var1, \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] var2);

    default public void a(String string, String string2, String string3) {
        if (!string3.isEmpty() && string3.charAt(0) != '/') {
            string3 = '/' + string3;
        }
        this.a(string, string2, string3, null, null);
    }

    public static \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return new \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b());
    }

    public void a(String var1, @Nullable String var2, @Nullable String var3, @Nullable String var4, @Nullable String var5);

    default public void c(String string, String string2, String string3) {
        this.a(string, string2, null, string3, null);
    }

    default public void a(String string) {
        this.a(string, null, null, null, null);
    }

    default public void d(String string, String string2, String string3) {
        this.a(string, string2, null, null, string3);
    }

    public void c(String var1, String var2);

    default public void e(String string, String string2) {
        this.a(string, null, string2);
    }
}

