/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;

class \u03b9\u03b4\u03c1\u03c1\u03c6\u03c7\u03b6\u03c6\u03bc {
    private static int c;
    private static int a;
    static final /* synthetic */ int[] m;
    private static int b;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (0x40000000 >>> 253 | 0x40000000 << ~253 + 1) & 0xFFFFFFFF;
        c = Integer.reverse(-1073741824);
        m = new int[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.values().length];
        try {
            \u03b9\u03b4\u03c1\u03c1\u03c6\u03c7\u03b6\u03c6\u03bc.m[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.c.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u03b4\u03c1\u03c1\u03c6\u03c7\u03b6\u03c6\u03bc.m[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.d.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b9\u03b4\u03c1\u03c1\u03c6\u03c7\u03b6\u03c6\u03bc.m[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.f.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

