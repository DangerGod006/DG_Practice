/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2
extends \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0 {
    private static long d;
    private static long l;
    private static int m;
    private static long g;
    private static String[] a;
    private final String h;
    private static int a;
    private static int c;
    private static int n;
    private static String[] b;
    private static int h;
    public static final int b;
    private static int k;
    private static int j;
    private static long i;
    private static int f;
    private static long c;
    @Nullable
    private final UUID b;
    private static int e;
    private static int o;
    @Nullable
    private final UUID a;

    private static String a(int n, long l) {
        l ^= 0x21L;
        l ^= 0x75148998F009159DL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(12 + 56), (byte)(33 + 36), (byte)(38 + 45), (byte)(14 + 33), (byte)(21 + 46), (byte)(19 + 47), (byte)(51 + 16), (byte)(28 + 19), (byte)(24 + 56), (byte)(51 + 24), (byte)(66 + 1), (byte)(81 + 2), 53, (byte)(36 + 44), (byte)(91 + 6), (byte)(34 + 66), (byte)(48 + 52), (byte)(2 + 103), (byte)(71 + 39), (byte)(96 + 7)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(12 + 56), (byte)(42 + 27), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u015e\u016b\u016a\u012d\u016d\u0169\u0164\u016d\u0178\u0167\u0134\u0172\u0176\u016f\u0172\u0178\u013a\u04ac\u04c6\u04c1\u04cb\u04cc\u04a4\u04ba\u04ce\u04d6", (byte)62, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    @Generated
    public UUID getBedrockId() {
        return this.b;
    }

    @Generated
    public String getName() {
        return this.h;
    }

    @Generated
    public String toString() {
        return (String)\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.c("\u3e80", (int)(a & c), (long)d) + this.getName() + (String)\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.c("\u3e83", (int)(e & f), (long)g) + this.getMojangId() + (String)\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.c("\u3e86", (int)h, (long)i) + this.getBedrockId() + (String)\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.c("\u3e89", (int)(j & k), (long)l);
    }

    private static void b() {
        int n;
        c = -6698379297099949269L;
        long l = c ^ 0x75148998F009159DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(17 + 51), (byte)(61 + 8), (byte)(36 + 47), (byte)(11 + 36), (byte)(14 + 53), 66, (byte)(36 + 31), (byte)(32 + 15), (byte)(45 + 35), (byte)(59 + 16), (byte)(2 + 65), (byte)(53 + 30), (byte)(42 + 11), (byte)(28 + 52), (byte)(75 + 22), 100, (byte)(30 + 70), (byte)(11 + 94), (byte)(103 + 7), (byte)(32 + 71)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(59 + 9), 69, (byte)(24 + 59)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0522\u04ff\u04fd\u0515\u053e\u0516\u0505\u054a\u0524\u04fd\u0506\u053c\u0540\u053d\u0529\u053b\u0530\u050e\u0547\u054e\u054a\u050f\u0511\u0511\u0546\u0533\u0554\u0550\u0519\u0517\u055f\u0536\u0551\u0538\u0556\u0552\u0524\u053b\u0536\u0568\u0563\u056b\u053f\u0558\u0524\u0539\u054a\u0572\u0542\u0553\u0570\u056c\u0565\u0575\u053c\u053d", (byte)13, 70);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u00e7\u0114\u00f2\u00cd\u00f2\u00f6\u00ce\u00d0\u00e3\u00e4\u0104\u00f2\u00f9\u00d5\u00f6\u00f0\u00fa\u00f7\u00ed\u0112\u00e4\u0115\u00ec\u00ed", (byte)13, 66);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u041f\u0424\u0456\u0449\u042a\u043b\u0454\u044d\u043b\u045d\u0449\u0418\u0435\u0436\u041a\u043f\u041e\u0424\u0431\u0424\u0454\u0442\u042f\u0430", (byte)13, 67);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[3] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0421\u041e\u041f\u0435\u0438\u0446\u041b\u042f\u0446\u0429\u0433\u0424", (byte)13, 68);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u00f2\u00cf\u00cd\u00e5\u010e\u00e6\u00d5\u011a\u00f4\u00cd\u00d6\u010c\u0110\u010d\u00f9\u010b\u0100\u00de\u0117\u011e\u011a\u00df\u00e1\u00e1\u0116\u0103\u0124\u0120\u00e9\u00e7\u012f\u0106\u0121\u0108\u0126\u0122\u00f4\u010b\u0106\u0138\u0133\u013b\u010f\u011c\u0117\u0113\u013d\u0137\u0116\u0114\u0118\u00ff\u0130\u011f\u010c\u010d", (byte)13, 66);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0517\u0544\u0522\u04fd\u0522\u0526\u04fe\u0500\u0513\u0514\u052c\u0546\u054f\u0525\u0543\u050e\u0526\u054c\u0555\u0555\u0510\u051f\u051c\u051d", (byte)13, 70);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u050c\u0511\u0543\u0536\u0517\u0528\u0541\u053a\u0528\u054a\u0538\u050a\u0519\u0523\u053a\u054a\u051c\u0525\u0527\u0520\u0527\u052d\u0545\u054e\u053a\u055c\u0529\u0554\u0537\u052f\u0556\u054a", (byte)13, 69);
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u00c4\u00c9\u00e3\u00d5\u0116\u00e9\u00e2\u00ed\u00ec\u0107\u00ec\u00e1", (byte)13, 65);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u0432\u044e\u0437\u0455\u0438\u0427\u044b\u0419\u043d\u0429\u041a\u0424", (byte)13, 67);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0413\u044d\u0438\u0428\u0456\u0410\u042b\u0437\u0438\u0447\u043b\u0448\u045e\u0457\u041f\u0423\u0460\u0418\u0445\u0466\u0460\u0436\u0455\u0466\u045a\u044b\u0425\u044c\u0450\u046c\u043c\u043f", (byte)13, 68);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0);
        c = -1 >>> 123 | -1 << -123;
        d = Long.reverse(5826357793129058501L);
        e = 0x200000 >>> 117 | 0x200000 << -117;
        f = Integer.reverse(-1);
        g = Long.reverse(5826357793129058501L);
        h = 4 >>> 1 | 4 << ~1 + 1;
        i = Long.reverse(5826357793129058501L);
        j = Integer.reverse(-1073741824);
        k = (-1 >>> 137 | -1 << -137) & 0xFFFFFFFF;
        l = Long.reverse(5826357793129058501L);
        m = 0x20000000 >>> 219 | 0x20000000 << ~219 + 1;
        n = Integer.reverse(0x20000000);
        o = (0 >>> 75 | 0 << -75) & 0xFFFFFFFF;
        a = new String[m];
        b = new String[n];
        \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.b();
        b = o;
    }

    @Nullable
    @Generated
    public UUID getMojangId() {
        return this.a;
    }

    @Generated
    public \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2(String string, @Nullable UUID uUID, @Nullable UUID uUID2) {
        this.h = string;
        this.a = uUID;
        this.b = uUID2;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0464\u0486\u0488\u0468\u048c\u04ab\u04a3\u04b9\u04a5\u0474\u04b2\u04a8\u04b6\u04b0\u0479\u049e\u04c0\u04bf\u04b7\u04bd\u04b7\u048c", (byte)45, 67), \u03a0\u03b9\u03b3\u03bc\u03bc\u0393\u03a8\u03bb\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u013c\u0149\u0148\u010b\u014b\u0147\u0142\u014b\u0156\u0145\u0112\u0150\u0154\u014d\u0150\u0156\u0118\u048a\u04a4\u049f\u04a9\u04aa\u0482\u0498\u04ac\u04b4\u012d", (byte)45, 65) + string + \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0476", (byte)45, 67) + methodType.toString(), exception);
        }
    }
}

