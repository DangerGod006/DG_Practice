/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.block.SignChangeEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03c3\u03b1\u03c2\u03c8\u03a0\u03c6\u03a0\u03b1\u03c6\u03c4
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int a = (32768 >>> 47 | 32768 << -47) & 0xFFFFFFFF;
    private static int c;
    private final \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 a;
    private static int b;

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void a(BlockBreakEvent blockBreakEvent) {
        if (this.a.b(blockBreakEvent.getPlayer())) {
            blockBreakEvent.setCancelled(b != 0);
        }
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void a(BlockPlaceEvent blockPlaceEvent) {
        if (this.a.b(blockPlaceEvent.getPlayer())) {
            blockPlaceEvent.setCancelled(a != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=true)
    public void a(SignChangeEvent signChangeEvent) {
        if (this.a.b(signChangeEvent.getPlayer())) {
            signChangeEvent.setCancelled(c != 0);
        }
    }

    static {
        b = Integer.reverse(Integer.MIN_VALUE);
        c = 131072 >>> 113 | 131072 << -113;
    }

    @Generated
    public \u03b2\u03c3\u03b1\u03c2\u03c8\u03a0\u03c6\u03a0\u03b1\u03c6\u03c4(\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52) {
        this.a = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52;
    }
}

