/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1 {
    public void W();

    public void X();
}

