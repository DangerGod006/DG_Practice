/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5;

class \u0393\u03b9\u03c4\u03c7\u03b6\u03b4\u0393\u03a0 {
    private static int a = 8 >>> 35 | 8 << ~35 + 1;
    private static int b = Integer.reverse(0x40000000);
    static final /* synthetic */ int[] Q;

    static {
        Q = new int[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.values().length];
        try {
            \u0393\u03b9\u03c4\u03c7\u03b6\u03b4\u0393\u03a0.Q[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.d.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u0393\u03b9\u03c4\u03c7\u03b6\u03b4\u0393\u03a0.Q[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.e.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

