/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03c6\u03bc\u03c5\u03b6\u03ba\u03b6\u03be\u03b2\u039b\u03b3\u039b\u03b6\u03a9\u03a0;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b7\u03c4\u03c2\u039b\u03b6\u03be\u03bc\u03a3\u03bc\u03a8\u03be;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9
implements \u03b7\u03c4\u03c2\u039b\u03b6\u03be\u03bc\u03a3\u03bc\u03a8\u03be {
    private static int b;
    private static long n;
    private static int ar;
    private final Set<String> c;
    private static int av;
    private static int bm;
    private static int ao;
    private static int be;
    private final EnumMap<\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9, \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1> a;
    private final Set<String> b;
    private static int bn;
    private static int k;
    private static long ai;
    private static long s;
    private static int v;
    private static int q;
    private static long x;
    private static int f;
    private static int bb;
    private static int aq;
    private static long p;
    private static int ac;
    private static long i;
    private static int bc;
    private static long c;
    private static int t;
    private static int ba;
    private final Map<String, \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9> a = new ConcurrentHashMap();
    private static int af;
    private static long am;
    private static int h;
    private static int ax;
    private static long aa;
    private static int bf;
    private static int a;
    private static long g;
    private static int aj;
    private static long u;
    private static long ae;
    private static int bk;
    private static int bj;
    private static int o;
    private static int an;
    private static int bd;
    private static int e;
    private static long bh;
    private static String[] b;
    private static int y;
    private static int ab;
    private static int az;
    private static long ad;
    private static int ay;
    private static int bl;
    private static int z;
    private static int w;
    private static long al;
    private static long at;
    private static long m;
    private static int l;
    private static long au;
    private static long j;
    private static int bi;
    private static int ag;
    private static String[] a;
    private static long aw;
    private static int bg;
    private static int r;
    private static int ak;
    private static int ap;
    private static int as;
    private static long ah;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 i;
    private static long d;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u04eb\u050d\u050f\u04ef\u0513\u0532\u052a\u0540\u052c\u04fb\u0539\u052f\u053d\u0537\u0500\u0525\u0547\u0546\u053e\u0544\u053e\u0513", (byte)7, 70), \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0526\u0533\u0532\u04f5\u0535\u0531\u052c\u0535\u0540\u052f\u04fc\u053a\u053e\u0537\u053a\u0540\u0502\u088c\u088e\u0895\u089b\u089f\u0899\u089d\u0881\u0885\u0517", (byte)7, 70) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u04fd", (byte)7, 70) + methodType.toString(), exception);
        }
    }

    public Set<String> a() {
        return this.b;
    }

    private static String a(int n, long l) {
        l ^= 0x19L;
        l ^= 0x6DB986B1769A3D06L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(58 + 11), (byte)(66 + 17), (byte)(38 + 9), (byte)(8 + 59), (byte)(48 + 18), (byte)(3 + 64), (byte)(45 + 2), (byte)(28 + 52), (byte)(54 + 21), (byte)(29 + 38), (byte)(25 + 58), (byte)(26 + 27), (byte)(64 + 16), 97, 100, (byte)(36 + 64), (byte)(50 + 55), (byte)(45 + 65), (byte)(33 + 70)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(16 + 52), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u018e\u019b\u019a\u015d\u019d\u0199\u0194\u019d\u01a8\u0197\u0164\u01a2\u01a6\u019f\u01a2\u01a8\u016a\u04f4\u04f6\u04fd\u0503\u0507\u0501\u0505\u04e9\u04ed", (byte)86, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public void r() {
        this.q();
        \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9[] \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9Array = \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.values();
        int n = \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9Array.length;
        for (int i = be; i < n; ++i) {
            \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92 = \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9Array[i];
            this.a(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void q() {
        this.b.clear();
        this.c.clear();
        EnumMap<\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9, \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1> enumMap = this.a;
        synchronized (enumMap) {
            this.a.forEach((\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92, \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c12) -> \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c12.X());
        }
    }

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, boolean bl) {
        if (((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b()).a() != \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b) {
            this.r();
        }
    }

    private /* synthetic */ void a(boolean bl, String string, \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92, String string2) {
        if (bl) {
            this.c.add((char)bk + string2);
            this.c.add(string + string2);
        }
        this.b.add((char)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.bl + string2);
        this.a.put((\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9)((Object)string2), (\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1)((Object)\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92));
    }

    static {
        a = Integer.reverse(0);
        b = (-1 >>> 167 | -1 << ~167 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-7645699065457567120L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-7645699065457567120L);
        h = Integer.reverse(0x40000000);
        i = Long.reverse(1001212219093785200L);
        j = Long.reverse(-7493989779944505344L);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = 786432 >>> 178 | 786432 << ~178 + 1;
        m = Long.reverse(1001212219093785200L);
        n = Long.reverse(-7493989779944505344L);
        o = Integer.reverse(0x20000000);
        p = Long.reverse(-7645699065457567120L);
        q = (0x1400000 >>> 22 | 0x1400000 << ~22 + 1) & 0xFFFFFFFF;
        r = Integer.reverse(-1);
        s = Long.reverse(-7645699065457567120L);
        t = Integer.reverse(0x60000000);
        u = Long.reverse(-7645699065457567120L);
        v = Integer.reverse(-1);
        w = Integer.reverse(-536870912);
        x = Long.reverse(-7645699065457567120L);
        y = Integer.reverse(0);
        z = (32768 >>> 108 | 32768 << ~108 + 1) & 0xFFFFFFFF;
        aa = Long.reverse(-7645699065457567120L);
        ab = (16384 >>> 206 | 16384 << -206) & 0xFFFFFFFF;
        ac = Integer.reverse(-1879048192);
        ad = Long.reverse(1001212219093785200L);
        ae = Long.reverse(-7493989779944505344L);
        af = Integer.reverse(0x40000000);
        ag = Integer.reverse(0x50000000);
        ah = Long.reverse(1001212219093785200L);
        ai = Long.reverse(-7493989779944505344L);
        aj = (-1073741824 >>> 94 | -1073741824 << ~94 + 1) & 0xFFFFFFFF;
        ak = (180224 >>> 14 | 180224 << ~14 + 1) & 0xFFFFFFFF;
        al = Long.reverse(1001212219093785200L);
        am = Long.reverse(-7493989779944505344L);
        an = Integer.reverse(0x20000000);
        ao = (0 >>> 240 | 0 << ~240 + 1) & 0xFFFFFFFF;
        ap = Integer.reverse(0);
        aq = (0 >>> 90 | 0 << ~90 + 1) & 0xFFFFFFFF;
        ar = Integer.reverse(0);
        as = (24576 >>> 139 | 24576 << ~139 + 1) & 0xFFFFFFFF;
        at = Long.reverse(1001212219093785200L);
        au = Long.reverse(-7493989779944505344L);
        av = Integer.reverse(-1342177280);
        aw = Long.reverse(-7645699065457567120L);
        ax = (4 >>> 2 | 4 << ~2 + 1) & 0xFFFFFFFF;
        ay = Integer.reverse(Integer.MIN_VALUE);
        az = Integer.reverse(0);
        ba = -1140850688 >>> 90 | -1140850688 << -90;
        bb = Integer.reverse(0x5C000000);
        bc = (0 >>> 67 | 0 << -67) & 0xFFFFFFFF;
        bd = 0 >>> 247 | 0 << -247;
        be = Integer.reverse(0);
        bf = (57344 >>> 12 | 57344 << -12) & 0xFFFFFFFF;
        bg = -1 >>> 250 | -1 << -250;
        bh = Long.reverse(-7645699065457567120L);
        bi = 128 >>> 231 | 128 << -231;
        bj = Integer.reverse(0);
        bk = Integer.reverse(-201326592);
        bl = 1504 >>> 69 | 1504 << ~69 + 1;
        bm = (30 >>> 193 | 30 << -193) & 0xFFFFFFFF;
        bn = Integer.reverse(-268435456);
        a = new String[bm];
        b = new String[bn];
        \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void a(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 var1_1) {
        block24: {
            block23: {
                var2_2 = this.i.a();
                var3_3 = var1_1.e();
                var4_4 = var1_1.a();
                var5_5 = var1_1.l();
                var6_6 = (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e80", (int)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.a & \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b), (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.d) + var3_3;
                var7_7 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.e;
                var9_8 = null;
                if (var1_1 == \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.b) break block23;
                var7_7 = var2_2.a(var6_6 + (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e83", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.f, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.g), var2_2.a(var6_6 + (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e86", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.h, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.i ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.j)), \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.k));
                var8_9 = var2_2.k(var6_6 + (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e89", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.l, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.m ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.n)));
                var9_8 = var2_2.b(var6_6 + (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e8c", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.o, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.p));
                var10_10 = var2_2.a(var6_6 + (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e8f", (int)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.q & \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.r), (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.s), (String)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e92", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.t, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.u));
                if (var7_7 == 0) break block24;
                var11_11 = var3_3;
                var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.v;
                switch (var11_11.hashCode()) {
                    case 1671380268: {
                        if (!var11_11.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e95", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.w, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.x))) break;
                        var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.y;
                        break;
                    }
                    case 96619420: {
                        if (!var11_11.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e98", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.z, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.aa))) break;
                        var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ab;
                        break;
                    }
                    case -1548612125: {
                        if (!var11_11.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e9b", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ac, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ad ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ae)))) break;
                        var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.af;
                        break;
                    }
                    case -318452137: {
                        if (!var11_11.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e9e", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ag, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ah ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ai)))) break;
                        var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.aj;
                        break;
                    }
                    case 1082600804: {
                        if (!var11_11.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3ea1", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ak, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.al ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.am)))) break;
                        var12_12 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.an;
                        break;
                    }
                }
                switch (var12_12) {
                    case 0: {
                        if (!\u03b2\u03c6\u03bc\u03c5\u03b6\u03ba\u03b6\u03be\u03b2\u039b\u03b3\u039b\u03b6\u03a9\u03a0.a.ar()) {
                            var7_7 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ao;
                            ** break;
                        }
                        break block24;
                    }
                    case 1: {
                        if (!\u03b2\u03c6\u03bc\u03c5\u03b6\u03ba\u03b6\u03be\u03b2\u039b\u03b3\u039b\u03b6\u03a9\u03a0.k.ar()) {
                            var7_7 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ap;
                            ** break;
                        }
                        break block24;
                    }
                    case 2: 
                    case 3: {
                        if (\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.d.ar()) {
                            var7_7 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.aq;
                        }
                    }
                    case 4: {
                        if (!\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.n.ar()) {
                            var7_7 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ar;
                            ** break;
                        }
                        break block24;
                    }
                }
lbl57:
                // 4 sources

                break block24;
            }
            var8_9 = Collections.singletonList(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3ea4", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.as, (long)(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.at ^ \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.au)));
            var10_10 = \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3ea7", (int)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.av, (long)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.aw);
        }
        if (var7_7 == 0) return;
        if (var8_9.isEmpty()) {
            var8_9 = Collections.singletonList(var3_3);
        } else if (var8_9.size() > \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ax) {
            var4_4.a(new ArrayList<Object>(var8_9).subList(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ay, var8_9.size()));
        }
        if (var9_8 != null) {
            var4_4.u(var9_8);
        }
        var4_4.b((String)var10_10);
        var4_4.a((String)var8_9.get(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.az));
        var11_11 = (char)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.ba + this.i.q().toLowerCase(Locale.ENGLISH) + (char)\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.bb;
        this.b.add(var11_11);
        var8_9.stream().map((Function<String, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, a(java.lang.String ), (Ljava/lang/String;)Ljava/lang/String;)()).forEach((Consumer<String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, a(boolean java.lang.String com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 java.lang.String ), (Ljava/lang/String;)V)((\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9)this, (boolean)var5_5, (String)var11_11, (\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9)var1_1));
        var12_13 = this.a;
        synchronized (var12_13) {
            this.a.put(var1_1, var4_4.a(this.i));
            return;
        }
    }

    private static void b() {
        int n;
        c = 1034064188871321520L;
        long l = c ^ 0x6DB986B1769A3D06L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(15 + 54), (byte)(31 + 52), (byte)(29 + 18), (byte)(45 + 22), (byte)(54 + 12), (byte)(50 + 17), (byte)(45 + 2), (byte)(15 + 65), 75, (byte)(65 + 2), (byte)(56 + 27), (byte)(31 + 22), (byte)(47 + 33), (byte)(32 + 65), (byte)(71 + 29), 100, (byte)(37 + 68), (byte)(81 + 29), (byte)(41 + 62)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(6 + 62), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0548\u0509\u0505\u053a\u051e\u054a\u053a\u0510\u0503\u050e\u053f\u0553\u0556\u0508\u052d\u0537\u0549\u054e\u053b\u055d\u054b\u054c\u0523\u0524", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0528\u0504\u0540\u0536\u0525\u0522\u0522\u052c\u051d\u0520\u0545\u0518", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u010c\u011b\u0102\u00d9\u010d\u011b\u00f0\u00dd\u0120\u0112\u00f7\u0113\u011a\u0108\u0102\u00f8\u0119\u012d\u011d\u00ff\u0135\u0133\u00fa\u00fb", (byte)20, 66);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[3] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0509\u0548\u0517\u053d\u054e\u0523\u0508\u050d\u0522\u0547\u053e\u0525\u0544\u0531\u050e\u0545\u0542\u0524\u0549\u0552\u0553\u0526\u0523\u0524", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u00db\u00ee\u00e1\u0110\u00f0\u00ee\u00f8\u00f6\u00e1\u0127\u00e6\u010b\u00e3\u0117\u00f9\u0130\u00ea\u012a\u0128\u0112\u0112\u010d\u00fa\u00fb", (byte)20, 65);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u044b\u0437\u0441\u044b\u0467\u0426\u045b\u0461\u046e\u0432\u0460\u0474\u045e\u0435\u0449\u0430\u0451\u045a\u0465\u046e\u045c\u046d\u0444\u0445", (byte)20, 68);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[6] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u051b\u053c\u0524\u051b\u04ff\u050b\u0546\u052e\u050b\u0529\u0549\u0528\u052f\u0512\u0525\u0543\u0550\u0543\u0550\u0558\u052e\u0557\u054a\u0540\u054f\u055c\u0539\u053d\u0522\u052f\u0553\u0564\u055b\u0544\u0562\u054d\u054a\u054a\u0542\u052e\u0568\u052e\u053c\u054b\u0575\u0552\u0535\u0562\u0550\u0565\u0569\u0544\u0538\u0546\u0543\u0544", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[7] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0522\u053f\u053c\u0520\u0516\u0521\u054b\u050f\u052e\u053d\u0527\u0518", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[8] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0508\u0504\u050b\u050c\u0544\u0521\u051e\u0521\u053f\u0542\u051b\u0518", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[9] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u0437\u0467\u0447\u0464\u045a\u0449\u0468\u0445\u0449\u042a\u0444\u0439", (byte)20, 68);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[10] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u0517\u051f\u054b\u0547\u054c\u054e\u053b\u053d\u051e\u051c\u0527\u0518", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[11] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0424\u0437\u0461\u043f\u0459\u0467\u0422\u042c\u045c\u0460\u0448\u0439", (byte)20, 67);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[12] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0549\u0533\u051b\u0536\u0547\u0507\u054a\u053b\u053d\u054c\u054d\u0518", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[13] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u04fb\u053c\u0541\u0538\u0548\u051a\u0526\u0519\u0527\u051d\u0548\u053e\u050e\u0554\u0511\u0549\u052e\u0554\u0514\u0556\u055d\u0534\u0555\u051c\u0518\u0560\u0536\u0536\u0562\u0550\u0554\u0551", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[14] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0425\u0426\u0461\u0462\u0447\u043d\u0422\u044b\u0445\u0468\u045e\u0439", (byte)20, 68);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0469\u042a\u0426\u045b\u043f\u046b\u045b\u0431\u0424\u042f\u045f\u046f\u0451\u0435\u0431\u0470\u046f\u0456\u0457\u046d\u047a\u046d\u0444\u0445", (byte)20, 67);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0521\u0535\u0529\u054d\u0539\u0544\u0525\u0538\u053f\u054a\u0527\u0510\u054b\u0529\u0509\u0520\u0526\u0559\u0543\u0533\u0527\u0526\u0523\u0524", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0456\u0465\u044c\u0423\u0457\u0465\u043a\u0427\u046a\u045c\u0441\u0443\u046b\u045f\u0463\u0441\u0431\u046e\u0471\u0436\u0446\u0447\u0444\u0445", (byte)20, 67);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0509\u0548\u0517\u053d\u054e\u0523\u0508\u050d\u0522\u0547\u0540\u0527\u050b\u054f\u0543\u0513\u0545\u0526\u0550\u055d\u0532\u054c\u0523\u0524", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u00db\u00ee\u00e1\u0110\u00f0\u00ee\u00f8\u00f6\u00e1\u0127\u00e7\u0122\u010d\u0107\u012b\u0126\u010b\u011c\u0103\u011b\u012a\u00fd\u00fa\u00fb", (byte)20, 66);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u044b\u0437\u0441\u044b\u0467\u0426\u045b\u0461\u046e\u0432\u0460\u0432\u0448\u0471\u0458\u0456\u046a\u0478\u0447\u0475\u0477\u0447\u0444\u0445", (byte)20, 68);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[6] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u051b\u053c\u0524\u051b\u04ff\u050b\u0546\u052e\u050b\u0529\u0549\u0528\u052f\u0512\u0525\u0543\u0550\u0543\u0550\u0558\u052e\u0557\u054a\u0540\u054f\u055c\u0539\u053d\u0522\u052f\u0553\u0564\u055b\u0544\u0562\u054d\u054a\u054a\u0542\u052e\u0568\u052e\u053c\u055f\u0531\u056b\u0561\u0570\u0550\u0546\u056b\u0556\u055c\u0555\u0539\u0580\u0571\u055c\u057f\u057f\u0558\u0552\u057e\u0557", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[7] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0518\u053d\u0522\u053c\u0520\u052c\u052d\u052e\u0531\u0548\u0511\u052f\u0544\u051f\u0556\u0533\u0514\u050c\u0556\u054d\u0516\u054c\u0523\u0524", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[8] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0508\u051c\u051b\u0543\u053c\u050a\u0543\u0545\u0546\u0548\u0523\u0518", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[9] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u00f5\u0110\u00ec\u010e\u0103\u0110\u00f6\u00f5\u0113\u010a\u00f6\u00e9\u0108\u011a\u00ea\u0101\u011d\u012e\u0102\u0101\u0115\u0133\u00fa\u00fb", (byte)20, 65);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[10] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0531\u0543\u053c\u0547\u0508\u0519\u050c\u0550\u0522\u0541\u0510\u053c\u0528\u051f\u054e\u054e\u0514\u054d\u0545\u052e\u0559\u054c\u0523\u0524", (byte)20, 69);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[11] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0109\u0122\u0122\u0123\u0124\u00e1\u0122\u0103\u0107\u00fc\u00f2\u00f3\u0121\u00e7\u010c\u011b\u0120\u0126\u0122\u00ea\u0134\u010d\u00fa\u00fb", (byte)20, 65);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[12] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0547\u0506\u0545\u053e\u0536\u051a\u053b\u050c\u050b\u0552\u0525\u050b\u0556\u052f\u0550\u0558\u0548\u053a\u0512\u0533\u0518\u0536\u0523\u0524", (byte)20, 70);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[13] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u041c\u045d\u0462\u0459\u0469\u043b\u0447\u043a\u0448\u043e\u0469\u045f\u042f\u0475\u0432\u046a\u044f\u0475\u0435\u0477\u047e\u044f\u0456\u043d\u047d\u045b\u044f\u0462\u0473\u045c\u045f\u0471\u0465\u0466\u046d\u0448\u045a\u0479\u0459\u047f\u047e\u046f\u0453\u0459", (byte)20, 67);
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[14] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u054a\u0549\u054a\u0522\u053f\u050a\u053d\u0529\u0520\u0540\u051b\u0518", (byte)20, 70);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0503\u051c\u0514\u0543\u0542\u054a\u050b\u051e\u0525\u052d\u0545\u0518", (byte)20, 69);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u011c\u010f\u010c\u00dd\u010e\u0112\u00f7\u00f2\u0108\u00e3\u010a\u00ef", (byte)20, 66);
                }
            }
        }
    }

    @Nullable
    public \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 a(String string) {
        return (\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9)((Object)this.a.get(string));
    }

    @Generated
    public \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.b = (int)ConcurrentHashMap.newKeySet();
        this.c = ConcurrentHashMap.newKeySet();
        this.i = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    public boolean b(String string) {
        if (this.c.stream().anyMatch(string::equals)) {
            return bc != 0;
        }
        List<String> list = \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.as.a(new Object[bd]);
        return list.stream().noneMatch(string2 -> (!string2.isEmpty() && (string2.equals(\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9.c("\u3e80", (int)(bf & bg), (long)bh)) || string.equals(string2)) ? bi : bj) != 0);
    }

    private static /* synthetic */ String a(String string) {
        return string.toLowerCase(Locale.ENGLISH);
    }
}

