/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.proxy.bungee.nLoginBungee;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4;
import com.nickuc.login.\u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c0\u03b1\u03be\u03b2\u03a9\u03b9\u03c3\u03b5\u03c9\u03ba\u03c6\u0394\u03bc;
import com.nickuc.login.\u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2;
import com.nickuc.login.\u03c9\u039b\u03bf\u03c7\u03b3\u03c6\u03bb\u03c0\u03b5\u03c5\u03c2\u03bf\u03c2;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3
implements \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 {
    private static int h;
    private static String[] a;
    private static String[] b;
    private static int b;
    private static int n;
    private static long i;
    private static long d;
    private \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 a;
    private static long g;
    private final \u03c9\u039b\u03bf\u03c7\u03b3\u03c6\u03bb\u03c0\u03b5\u03c5\u03c2\u03bf\u03c2 b;
    private \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 a;
    private static long c;
    private final nLoginBungee b;
    private static long l;
    private static long j;
    private static long f;
    private static int e;
    private static int k;
    private static int a;
    private static int m;

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, boolean bl) {
        this.k();
    }

    @Generated
    public \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3(nLoginBungee nLoginBungee2, \u03c9\u039b\u03bf\u03c7\u03b3\u03c6\u03bb\u03c0\u03b5\u03c5\u03c2\u03bf\u03c2 \u03c9\u039b\u03bf\u03c7\u03b3\u03c6\u03bb\u03c0\u03b5\u03c5\u03c2\u03bf\u03c22) {
        this.b = nLoginBungee2;
        this.b = \u03c9\u039b\u03bf\u03c7\u03b3\u03c6\u03bb\u03c0\u03b5\u03c5\u03c2\u03bf\u03c22;
    }

    @Override
    @Generated
    public \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 a() {
        return this.a;
    }

    private static String a(int n, long l) {
        l ^= 0x11L;
        l ^= 0x398FA3DF1E87F652L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(19 + 50), 83, (byte)(8 + 39), (byte)(41 + 26), (byte)(50 + 16), (byte)(60 + 7), (byte)(33 + 14), (byte)(22 + 58), (byte)(3 + 72), (byte)(24 + 43), (byte)(35 + 48), 53, (byte)(49 + 31), (byte)(45 + 52), (byte)(3 + 97), (byte)(84 + 16), (byte)(2 + 103), (byte)(63 + 47), (byte)(26 + 77)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(63 + 5), 69, (byte)(78 + 5)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0164\u0171\u0170\u0133\u0173\u016f\u016a\u0173\u017e\u016d\u013a\u0178\u017c\u0175\u0178\u017e\u0140\u04c6\u04bc\u04db\u04de\u04ce\u04d3\u04cb\u04cb\u04d9\u04df\u04da\u04d0", (byte)65, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    @Generated
    public \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 a() {
        return this.a;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0547\u0569\u056b\u054b\u056f\u058e\u0586\u059c\u0588\u0557\u0595\u058b\u0599\u0593\u055c\u0581\u05a3\u05a2\u059a\u05a0\u059a\u056f", (byte)99, 70), \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01a8\u01b5\u01b4\u0177\u01b7\u01b3\u01ae\u01b7\u01c2\u01b1\u017e\u01bc\u01c0\u01b9\u01bc\u01c2\u0184\u050a\u0500\u051f\u0522\u0512\u0517\u050f\u050f\u051d\u0523\u051e\u0514\u019c", (byte)99, 66) + string + \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0559", (byte)99, 69) + methodType.toString(), exception);
        }
    }

    static {
        a = 0 >>> 227 | 0 << -227;
        b = Integer.reverse(-1);
        d = Long.reverse(-2502445854718776679L);
        e = (0x4000000 >>> 154 | 0x4000000 << ~154 + 1) & 0xFFFFFFFF;
        f = Long.reverse(6144465429832575641L);
        g = Long.reverse(-8646911284551352320L);
        h = (8192 >>> 108 | 8192 << ~108 + 1) & 0xFFFFFFFF;
        i = Long.reverse(6144465429832575641L);
        j = Long.reverse(-8646911284551352320L);
        k = Integer.reverse(-1073741824);
        l = Long.reverse(-2502445854718776679L);
        m = (16 >>> 66 | 16 << ~66 + 1) & 0xFFFFFFFF;
        n = Integer.reverse(0x20000000);
        a = new String[m];
        b = new String[n];
        \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b();
    }

    @Override
    public void k() {
        \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 = this.b.a();
        this.a = this.b.b().j((String)\u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.c("\u3e80", (int)(a & b), (long)d)) ? new \u03c9\u0393\u039b\u03a8\u03a0\u03c9\u03a6\u03c0\u03a8\u03c7\u03c6\u03b2(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) : (this.b.b().j((String)\u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.c("\u3e83", (int)e, (long)(f ^ g))) ? new \u03c8\u0393\u03c0\u03b1\u03be\u03b2\u03a9\u03b9\u03c3\u03b5\u03c9\u03ba\u03c6\u0394\u03bc() : null);
        if (this.a == null) {
            \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba2 = this.b.a();
            \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba2.a(\u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.c("\u3e86", (int)h, (long)(i ^ j)), this.b);
            this.a = new \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        }
    }

    private static void b() {
        int n;
        c = -7397888104228347222L;
        long l = c ^ 0x398FA3DF1E87F652L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(24 + 45), (byte)(11 + 72), (byte)(43 + 4), (byte)(9 + 58), 66, (byte)(27 + 40), (byte)(32 + 15), (byte)(66 + 14), (byte)(35 + 40), (byte)(56 + 11), (byte)(45 + 38), (byte)(47 + 6), (byte)(53 + 27), (byte)(67 + 30), (byte)(43 + 57), (byte)(47 + 53), (byte)(42 + 63), (byte)(10 + 100), (byte)(76 + 27)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(63 + 20)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0426\u0443\u0426\u0466\u0456\u0466\u044b\u0427\u043c\u044a\u0460\u046c\u0430\u0446\u0434\u0452\u045f\u0476\u0458\u044a\u0469\u047a\u0441\u0442", (byte)19, 68);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0514\u0514\u0535\u053c\u051b\u0517\u053f\u0505\u051c\u0529\u0545\u0544\u0524\u0546\u0510\u0546\u054c\u0522\u0530\u0547\u0514\u0530\u053b\u051c\u052e\u0532\u055c\u055d\u0564\u0533\u0544\u0554", (byte)19, 70);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u0464\u0430\u0461\u043a\u0439\u0466\u0441\u0426\u0448\u046c\u043d\u044e\u042b\u0453\u0440\u0443\u044a\u046f\u0435\u0473\u0474\u0454\u0441\u0442", (byte)19, 68);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0545\u0511\u0542\u051b\u051a\u0547\u0522\u0507\u0529\u054d\u051e\u052f\u050c\u0534\u0521\u0524\u052b\u0550\u0516\u0554\u0555\u0535\u0522\u0523", (byte)19, 70);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u00dd\u00fa\u00dd\u011d\u010d\u011d\u0102\u00de\u00f3\u0101\u0119\u0101\u00f2\u010c\u011a\u0104\u0102\u00ed\u00ff\u0105\u0102\u010b\u00f8\u00f9", (byte)19, 65);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0433\u0433\u0454\u045b\u043a\u0436\u045e\u0424\u043b\u0448\u0464\u0463\u0443\u0465\u042f\u0465\u046b\u0441\u044f\u0466\u0433\u0451\u046d\u047e\u0437\u043b\u0471\u045c\u0459\u0480\u0476\u0482", (byte)19, 68);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u011b\u00e7\u0118\u00f1\u00f0\u011d\u00f8\u00dd\u00ff\u0123\u00f6\u011d\u00ea\u011a\u0125\u0107\u0127\u00fd\u00e9\u0104\u00ed\u010b\u00f8\u00f9", (byte)19, 66);
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[3] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0464\u0430\u0461\u043a\u0439\u0466\u0441\u0426\u0448\u046c\u043d\u0440\u046b\u044d\u0433\u0454\u0430\u0454\u0461\u0437\u0437\u046a\u0441\u0442", (byte)19, 68);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0445\u0469\u0465\u0424\u0466\u043b\u0423\u0428\u046f\u043c\u044d\u0436", (byte)19, 67);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u042f\u045f\u0444\u0455\u0453\u0441\u044a\u0459\u0457\u0458\u0431\u0445\u0474\u042c\u0473\u044c\u044a\u0466\u042b\u0446\u0449\u047c\u045e\u047e\u047a\u0475\u043f\u046b\u043f\u043a\u046e\u0480", (byte)19, 68);
                }
            }
        }
    }

    @Override
    public void l() {
        if (this.a != null) {
            \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba2 = this.b.a();
            \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba2.c(\u03b4\u03a9\u03c7\u03c9\u03b8\u03bc\u03b3\u03b2\u03bf\u03c4\u03be\u03b3.c("\u3e80", (int)k, (long)l));
        }
        this.a = null;
    }
}

