/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6 {
    private static long g;
    private static int j;
    private static int i;
    private static int a;
    private static String[] a;
    private static String[] b;
    private static int b;
    private static long c;
    private static int d;
    public static final boolean j;
    private static int e;
    private static int f;
    private static int c;
    private static int h;

    public static boolean a(Player player) {
        return (j && player.isGliding() ? a : b) != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x2AL;
        l ^= 0x33339B267494E946L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(35 + 34), (byte)(6 + 77), (byte)(15 + 32), (byte)(19 + 48), (byte)(53 + 13), (byte)(11 + 56), (byte)(16 + 31), (byte)(47 + 33), (byte)(41 + 34), (byte)(20 + 47), (byte)(56 + 27), (byte)(4 + 49), (byte)(16 + 64), (byte)(5 + 92), (byte)(84 + 16), (byte)(58 + 42), (byte)(72 + 33), 110, (byte)(21 + 82)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(47 + 22), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0188\u0195\u0194\u0157\u0197\u0193\u018e\u0197\u01a2\u0191\u015e\u019c\u01a0\u0199\u019c\u01a2\u0164\u04eb\u04fd\u04f4\u0502\u0503\u04fe\u04f3\u04f7\u04fa\u04d3\u0507\u04fd\u04fd\u0509", (byte)83, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0413\u0435\u0437\u0417\u043b\u045a\u0452\u0468\u0454\u0423\u0461\u0457\u0465\u045f\u0428\u044d\u046f\u046e\u0466\u046c\u0466\u043b", (byte)18, 67), \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0531\u053e\u053d\u0500\u0540\u053c\u0537\u0540\u054b\u053a\u0507\u0545\u0549\u0542\u0545\u054b\u050d\u0894\u08a6\u089d\u08ab\u08ac\u08a7\u089c\u08a0\u08a3\u087c\u08b0\u08a6\u08a6\u08b2\u0527", (byte)18, 70) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0425", (byte)18, 67) + methodType.toString(), exception);
        }
    }

    public static void a(Player player, boolean bl) {
        if (j) {
            player.setGliding(bl);
        }
    }

    private static void b() {
        int n;
        c = -6965152775870707117L;
        long l = c ^ 0x33339B267494E946L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(66 + 3), (byte)(82 + 1), 47, (byte)(12 + 55), (byte)(54 + 12), (byte)(50 + 17), (byte)(39 + 8), (byte)(25 + 55), (byte)(51 + 24), (byte)(41 + 26), (byte)(40 + 43), (byte)(17 + 36), (byte)(63 + 17), (byte)(69 + 28), 100, (byte)(65 + 35), (byte)(24 + 81), (byte)(21 + 89), (byte)(71 + 32)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(12 + 56), (byte)(36 + 33), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0517\u050e\u04e7\u04f1\u04da\u04fb\u04f6\u04fc\u04f6\u0510\u04f8\u0501\u051d\u04f1\u04f4\u04e2\u0518\u04fc\u04e7\u0522\u04fe\u0508\u04f5\u04f6", (byte)79, 68);
                    continue block7;
                }
                case 1: {
                    \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u0192\u0189\u0162\u016c\u0155\u0176\u0171\u0177\u0171\u018b\u0172\u018f\u0190\u017d\u016c\u0171\u019a\u019a\u01a1\u0177\u01aa\u0183\u0170\u0171", (byte)79, 65);
                    continue block7;
                }
                case 2: {
                    \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u0189\u014f\u0160\u0165\u0190\u0175\u0197\u018d\u018f\u019f\u018c\u016e\u0159\u0191\u0163\u0164\u017c\u017b\u019a\u0182\u019b\u01a9\u0170\u0171", (byte)79, 66);
                    continue block7;
                }
                case 4: {
                    \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u04f8\u04e8\u04f7\u04fb\u0515\u04f2\u04e1\u051f\u04f8\u04df\u04d7\u04f5\u04ef\u04f1\u04e7\u04fe\u050a\u0520\u0521\u0519\u0522\u04f8\u04f5\u04f6", (byte)79, 67);
                }
            }
        }
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 0 >>> 135 | 0 << ~135 + 1;
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (0x10000000 >>> 92 | 0x10000000 << ~92 + 1) & 0xFFFFFFFF;
        e = 0 >>> 238 | 0 << -238;
        f = -1 >>> 207 | -1 << ~207 + 1;
        g = Long.reverse(-7038730598773200135L);
        h = Integer.reverse(0);
        i = Integer.reverse(Integer.MIN_VALUE);
        j = 0 >>> 104 | 0 << ~104 + 1;
        a = new String[c];
        b = new String[d];
        \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.b();
        j = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(Player.class, (String)\u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.c("\u3e80", (int)(e & f), (long)g), new Class[h]) != null ? i : j;
    }
}

