/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1;
import com.nickuc.login.\u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c9;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8
extends \u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1 {
    private static int bi;
    private static long co;
    private static String[] c;
    private static int ct;
    private static int a;
    private static int bf;
    private static int bh;
    private static int bq;
    private static long ce;
    private static int cf;
    private static int cg;
    private static int ci;
    private static long ax;
    private static int cs;
    private static long cc;
    private static long cn;
    private static long bj;
    private static long cb;
    private static int bu;
    private static int cv;
    private static int bp;
    private static long bm;
    private static int bg;
    private static int bz;
    private static int av;
    private static long cr;
    private static long az;
    private static int ch;
    private static int au;
    private static int ba;
    private static long be;
    private static int bx;
    private static int cl;
    private static int cu;
    private static int bo;
    private static int ca;
    private static int cq;
    private static long bn;
    private static int br;
    private static int ck;
    private static long bb;
    private static String[] d;
    private static int cj;
    private static int bt;
    private static int by;
    private static int cp;
    private static int bw;
    private static long bs;
    private static int bd;
    private static int bv;
    private static long aw;
    private static int bk;
    private static int cm;
    private static int ay;
    private static long bc;
    private static int bl;
    private static int cd;
    private static long e;

    private static String a(int n, long l) {
        l ^= 4L;
        l ^= 0x3002EC9F42155DBFL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), 69, (byte)(52 + 31), (byte)(27 + 20), (byte)(48 + 19), (byte)(34 + 32), (byte)(42 + 25), (byte)(30 + 17), (byte)(53 + 27), (byte)(26 + 49), (byte)(4 + 63), 83, (byte)(15 + 38), (byte)(23 + 57), (byte)(53 + 44), (byte)(50 + 50), (byte)(43 + 57), (byte)(87 + 18), (byte)(16 + 94), (byte)(68 + 35)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(29 + 39), 69, (byte)(29 + 54)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0593\u05a0\u059f\u0562\u05a2\u059e\u0599\u05a2\u05ad\u059c\u0569\u05a7\u05ab\u05a4\u05a7\u05ad\u056f\u0902\u08dd\u08f9\u08ec\u0903\u090f\u08fe\u0905\u08ef\u08f2", (byte)116, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    public \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92) {
        super(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92);
    }

    static {
        a = (131072 >>> 81 | 131072 << -81) & 0xFFFFFFFF;
        au = Integer.reverse(0);
        av = (0 >>> 191 | 0 << ~191 + 1) & 0xFFFFFFFF;
        aw = Long.reverse(2997539361080099741L);
        ax = Long.reverse(0x2000000000000000L);
        ay = Integer.reverse(Integer.MIN_VALUE);
        az = Long.reverse(691696351866405789L);
        ba = 65536 >>> 239 | 65536 << -239;
        bb = Long.reverse(2997539361080099741L);
        bc = Long.reverse(0x2000000000000000L);
        bd = Integer.reverse(-1073741824);
        be = Long.reverse(691696351866405789L);
        bf = Integer.reverse(0x20000000);
        bg = Integer.reverse(0);
        bh = 8192 >>> 107 | 8192 << -107;
        bi = Integer.reverse(-1);
        bj = Long.reverse(691696351866405789L);
        bk = 256 >>> 200 | 256 << -200;
        bl = 1280 >>> 168 | 1280 << -168;
        bm = Long.reverse(2997539361080099741L);
        bn = Long.reverse(0x2000000000000000L);
        bo = Integer.reverse(0x40000000);
        bp = 49152 >>> 238 | 49152 << ~238 + 1;
        bq = Integer.reverse(0x60000000);
        br = (-1 >>> 145 | -1 << -145) & 0xFFFFFFFF;
        bs = Long.reverse(691696351866405789L);
        bt = (256 >>> 167 | 256 << -167) & 0xFFFFFFFF;
        bu = (0 >>> 160 | 0 << ~160 + 1) & 0xFFFFFFFF;
        bv = Integer.reverse(Integer.MIN_VALUE);
        bw = Integer.reverse(0);
        bx = Integer.reverse(Integer.MIN_VALUE);
        by = 0 >>> 89 | 0 << -89;
        bz = (0 >>> 13 | 0 << ~13 + 1) & 0xFFFFFFFF;
        ca = Integer.reverse(-536870912);
        cb = Long.reverse(2997539361080099741L);
        cc = Long.reverse(0x2000000000000000L);
        cd = 0x100000 >>> 17 | 0x100000 << ~17 + 1;
        ce = Long.reverse(691696351866405789L);
        cf = Integer.reverse(0);
        cg = (0 >>> 250 | 0 << -250) & 0xFFFFFFFF;
        ch = 0 >>> 1 | 0 << -1;
        ci = (0 >>> 202 | 0 << -202) & 0xFFFFFFFF;
        cj = Integer.reverse(0);
        ck = Integer.reverse(0x20000000);
        cl = 0 >>> 24 | 0 << ~24 + 1;
        cm = 294912 >>> 111 | 294912 << ~111 + 1;
        cn = Long.reverse(2997539361080099741L);
        co = Long.reverse(0x2000000000000000L);
        cp = (32 >>> 229 | 32 << ~229 + 1) & 0xFFFFFFFF;
        cq = Integer.reverse(0x50000000);
        cr = Long.reverse(691696351866405789L);
        cs = Integer.reverse(0x40000000);
        ct = 0x180000 >>> 211 | 0x180000 << -211;
        cu = Integer.reverse(-805306368);
        cv = Integer.reverse(-805306368);
        c = new String[cu];
        d = new String[cv];
        \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0109\u012b\u012d\u010d\u0131\u0150\u0148\u015e\u014a\u0119\u0157\u014d\u015b\u0155\u011e\u0143\u0165\u0164\u015c\u0162\u015c\u0131", (byte)49, 66), \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u04ab\u04b8\u04b7\u047a\u04ba\u04b6\u04b1\u04ba\u04c5\u04b4\u0481\u04bf\u04c3\u04bc\u04bf\u04c5\u0487\u081a\u07f5\u0811\u0804\u081b\u0827\u0816\u081d\u0807\u080a\u049d", (byte)49, 67) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u011b", (byte)49, 66) + methodType.toString(), exception);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    protected void a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        if (!\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.n.ar()) {
            return;
        }
        if (\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.d.ar()) {
            return;
        }
        if (!(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            Object[] objectArray = new Object[a];
            objectArray[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.au] = (String)\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e80", (int)av, (long)(aw ^ ax)) + \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.h.a().aa() + (String)(stringArray.length > 0 ? \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e83", (int)ay, (long)az) : \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e86", (int)ba, (long)(bb ^ bc))) + String.join((CharSequence)\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e89", (int)bd, (long)be), stringArray);
            \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.x, objectArray);
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2;
        \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942 = ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a();
        if (!\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2 \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22 = (\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.n);
            if (\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22 != null && \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22.a() == \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.b) {
                String[] stringArray2 = new String[bf];
                stringArray2[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bg] = \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e8c", (int)(bh & bi), (long)bj);
                stringArray2[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bk] = \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e8f", (int)bl, (long)(bm ^ bn));
                stringArray2[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bo] = Integer.toString(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.b.v());
                stringArray2[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bp] = Integer.toString(\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.v());
                \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.b.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray2);
            }
            return;
        }
        if (stringArray.length == 0) {
            Object[] objectArray = new Object[bt];
            objectArray[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bu] = string;
            objectArray[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.bv] = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.D, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[bw]);
            String string2 = String.format((String)\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e92", (int)(bq & br), (long)bs), objectArray);
            Object[] objectArray2 = new Object[bx];
            objectArray2[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.by] = string2;
            \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.x, objectArray2);
            return;
        }
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b43 = \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b43.a();
        Object object = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.c;
        synchronized (object) {
            if (!\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.h()) {
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.t, new Object[bz]);
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                return;
            }
            UUID uUID = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.getMojangId();
            if (uUID != null) {
                if (uUID.equals(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.a())) {
                    \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b43.a().a((String)(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b43.j() ? \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e95", (int)ca, (long)(cb ^ cc)) : \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e98", (int)cd, (long)ce)));
                    \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                    return;
                }
                if (\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.t()) {
                    String string3;
                    \u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c9 \u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c92 = ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a();
                    if (!\u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c92.a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, string3 = stringArray[cf])) {
                        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.P, new Object[cg]);
                        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                        return;
                    }
                    \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.b(null);
                    if (!((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a().a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, new \u03be\u03be\u03bf\u03b7\u03bb\u03be\u03bd\u03a8[ch])) {
                        \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.b(uUID);
                        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.w, new Object[ci]);
                        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                        return;
                    }
                    \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.r, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[cj]));
                    return;
                }
            }
        }
        String[] stringArray3 = new String[ck];
        stringArray3[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.cl] = \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e9b", (int)cm, (long)(cn ^ co));
        stringArray3[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.cp] = \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.c("\u3e9e", (int)cq, (long)cr);
        stringArray3[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.cs] = Integer.toString(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.b.v());
        stringArray3[\u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.ct] = Integer.toString(\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.v());
        \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9.b.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b43, stringArray3);
    }

    private static void b() {
        int n;
        e = -5061352690422474348L;
        long l = e ^ 0x3002EC9F42155DBFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), (byte)(62 + 7), (byte)(11 + 72), (byte)(7 + 40), (byte)(51 + 16), (byte)(30 + 36), (byte)(24 + 43), (byte)(42 + 5), 80, (byte)(26 + 49), (byte)(14 + 53), (byte)(66 + 17), (byte)(36 + 17), (byte)(16 + 64), (byte)(5 + 92), 100, (byte)(26 + 74), (byte)(50 + 55), (byte)(53 + 57), (byte)(29 + 74)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), 69, (byte)(77 + 6)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u05ac\u058f\u05a4\u0590\u05a8\u058b\u058e\u057c\u0575\u05b3\u0576\u057c", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u05aa\u0584\u058b\u0580\u0588\u0568\u0573\u056f\u056d\u0591\u05ad\u057c", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u01e3\u01a9\u019c\u01cb\u01ea\u01e8\u01c9\u01dd\u01be\u01c8\u01ba\u01b7", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u01e5\u01bf\u01c6\u01bb\u01c3\u01a3\u01ae\u01aa\u01a8\u01cc\u01e8\u01b7", (byte)120, 65);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01d7\u01bb\u01d6\u01d5\u01aa\u01c2\u01c6\u01a7\u01c8\u01e9\u01be\u01b7", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[5] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u058e\u0571\u0561\u0592\u0567\u059c\u0585\u055c\u0557\u057f\u056d\u058e\u05a2\u0563\u059e\u059c\u0563\u057b\u0574\u05a7\u0569\u05a9\u0570\u0571", (byte)120, 68);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[6] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u058c\u057a\u0565\u05b1\u0584\u0568\u05a7\u0590\u059f\u05a3\u0580\u0598\u058b\u058a\u05b7\u0599\u058b\u05b5\u05a9\u0599\u059c\u058a\u0587\u0588", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u01ba\u01b9\u01d5\u01c6\u01aa\u01b9\u01d6\u01ad\u01a7\u01e2\u01f3\u01e6\u01de\u01c4\u01b2\u01d8\u01d9\u01f8\u01b2\u01cd\u01ee\u01c8\u01be\u01ee\u01ea\u01fb\u01c0\u01ec\u01e2\u01e6\u0203\u01cf\u01f6\u01fc\u01c7\u01fd\u01d5\u01f9\u01c4\u01ed\u01df\u01c8\u01ec\u0214\u01e0\u01f5\u01ea\u01d2\u0208\u01d9\u01ea\u0216\u0219\u0205\u01ea\u020f\u01f5\u020c\u0220\u021d\u01f1\u01fd\u0205\u0201", (byte)120, 65);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0591\u0583\u0584\u0576\u0587\u054d\u0579\u059c\u057b\u055e\u059d\u0553\u0576\u055f\u055a\u0582\u0598\u0588\u0576\u0577\u0565\u057f\u059c\u056a\u0565\u0582\u059f\u056a\u056c\u0589\u05ad\u0582\u05ac\u058a\u0599\u0570\u05a5\u0594\u0596\u0592\u0577\u05c0\u0592\u057a\u0597\u058f\u05b2\u05a6\u05b6\u059c\u057e\u0596\u059f\u05a3\u05a8\u0598\u05a9\u058f\u05ab\u058d\u05c9\u05ce\u05aa\u05b1", (byte)120, 67);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[9] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u059c\u0580\u059b\u059a\u056f\u0587\u058b\u056c\u058d\u05ae\u0583\u057c", (byte)120, 70);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[10] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u05a5\u0588\u0578\u05a9\u057e\u05b3\u059c\u0573\u056e\u0596\u0584\u05a5\u05b9\u057a\u05b5\u05b3\u057a\u0592\u058b\u05be\u0580\u05c0\u0587\u0588", (byte)120, 70);
                    continue block7;
                }
                case 1: {
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u01a8\u01a2\u01b3\u019d\u01e7\u01c5\u01b6\u01c4\u01b8\u01e8\u01be\u01b7", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0564\u056a\u0588\u0580\u05a5\u0588\u05a5\u0585\u0593\u05b4\u058b\u057c", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0578\u0597\u057c\u05ac\u0582\u058c\u059b\u05a1\u0581\u05b5\u0587\u057c", (byte)120, 70);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01c4\u01e8\u01b4\u01a3\u01a8\u01e5\u01a5\u01aa\u01a7\u01c1\u01b1\u01b7", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[4] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u01e9\u01ba\u01c6\u01bb\u01a4\u01a6\u01ec\u01e8\u01d1\u01af\u01bc\u01f2\u01ea\u01d0\u01e0\u01f4\u01ae\u01ee\u01ea\u01cd\u01f7\u01fb\u01c2\u01c3", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[5] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01e0\u01c3\u01b3\u01e4\u01b9\u01ee\u01d7\u01ae\u01a9\u01d1\u01c0\u01de\u01be\u01c8\u01ee\u01e5\u01aa\u01ce\u01d7\u01dc\u01b2\u01eb\u01c2\u01c3", (byte)120, 66);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[6] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u058c\u057a\u0565\u05b1\u0584\u0568\u05a7\u0590\u059f\u05a3\u0581\u0570\u0594\u0594\u05ab\u05bb\u0595\u057d\u05b6\u05ac\u058a\u058a\u0587\u0588", (byte)120, 70);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u057f\u057e\u059a\u058b\u056f\u057e\u059b\u0572\u056c\u05a7\u05b8\u05ab\u05a3\u0589\u0577\u059d\u059e\u05bd\u0577\u0592\u05b3\u058d\u0583\u05b3\u05af\u05c0\u0585\u05b1\u05a7\u05ab\u05c8\u0594\u05bb\u05c1\u058c\u05c2\u059a\u05be\u0589\u05b2\u05a4\u058d\u05b1\u05d9\u05a5\u05ba\u05af\u0597\u05cd\u059e\u05af\u05db\u05de\u05be\u05a0\u05de\u05ce\u05d4\u05c3\u05a3\u05c6\u05e5\u05c8\u05ed", (byte)120, 70);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[8] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u05a8\u059a\u059b\u058d\u059e\u0564\u0590\u05b3\u0592\u0575\u05b4\u056a\u058d\u0576\u0571\u0599\u05af\u059f\u058d\u058e\u057c\u0596\u05b3\u0581\u057c\u0599\u05b6\u0581\u0583\u05a0\u05c4\u0599\u05c3\u05a1\u05b0\u0587\u05bc\u05ab\u05ad\u05a9\u058e\u05d7\u05a9\u0591\u05ae\u05a6\u05c9\u05bd\u05cd\u05b3\u0595\u05ad\u05b6\u05cd\u05c2\u05db\u05e0\u05e0\u05b2\u05db\u05c7\u05a1\u05c7\u05cd", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[9] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0583\u058a\u056e\u05a2\u0584\u0580\u05a5\u05af\u05a0\u05b6\u0587\u057c", (byte)120, 69);
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[10] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u058e\u0571\u0561\u0592\u0567\u059c\u0585\u055c\u0557\u057f\u056f\u057f\u058d\u056b\u0590\u05a6\u05a4\u0590\u0573\u0588\u059f\u0573\u0570\u0571", (byte)120, 68);
                    continue block7;
                }
                case 2: {
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u05ac\u05a6\u0566\u05ab\u05af\u058f\u05b0\u056e\u05ae\u05b7\u0587\u0589\u0589\u05ba\u05b7\u05b5\u05bb\u058a\u05ae\u05b4\u05a1\u0592\u0583\u05c3\u059c\u059d\u0590\u05c8\u05c2\u05a4\u05bd\u05b5", (byte)120, 70);
                    continue block7;
                }
                case 4: {
                    \u03c1\u039b\u03b6\u03a8\u03be\u03c9\u03b7\u03bd\u03a6\u03a8.d[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0585\u056d\u0591\u0550\u058f\u0568\u0585\u0592\u055a\u055e\u0593\u059f\u055f\u059f\u0598\u0596\u057f\u0565\u059b\u0569\u057c\u059c\u05a1\u0568\u0580\u0584\u057c\u059e\u05b2\u0584\u0574\u0585", (byte)120, 68);
                }
            }
        }
    }
}

