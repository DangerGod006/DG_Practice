/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a3\u03bc\u03c2\u03a0\u0394\u03c5\u03c3\u03b8;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394
extends \u03a3\u03bc\u03c2\u03a0\u0394\u03c5\u03c3\u03b8 {
    private static int aj;
    private final String L;
    private final String M;
    private static String[] f;
    private static long r;
    private static int d;
    private static long p;
    private static int ag;
    private static String[] e;
    private static long q;

    static {
        d = (0 >>> 165 | 0 << -165) & 0xFFFFFFFF;
        q = Long.reverse(-1696560954048379689L);
        r = Long.reverse(-1152921504606846976L);
        ag = Integer.reverse(Integer.MIN_VALUE);
        aj = Integer.reverse(Integer.MIN_VALUE);
        e = new String[ag];
        f = new String[aj];
        \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.b();
    }

    private static void b() {
        int n;
        p = -1504092012132356585L;
        long l = p ^ 0xEED291FF6FFD23EAL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(31 + 37), (byte)(31 + 38), (byte)(44 + 39), 47, (byte)(32 + 35), (byte)(30 + 36), 67, (byte)(18 + 29), (byte)(78 + 2), (byte)(47 + 28), (byte)(32 + 35), (byte)(40 + 43), (byte)(17 + 36), (byte)(41 + 39), (byte)(65 + 32), (byte)(34 + 66), (byte)(75 + 25), (byte)(53 + 52), (byte)(97 + 13), (byte)(86 + 17)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(51 + 32)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.f[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056b\u0580\u0558\u0548\u057e\u0571\u0584\u0583\u0568\u0562\u0587\u055a", (byte)86, 70);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.f[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0175\u0175\u017c\u0170\u01a3\u017a\u0176\u0169\u017a\u01a9\u0176\u0173", (byte)86, 65);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.f[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u056c\u0585\u0549\u0546\u057e\u0558\u0565\u056e\u0560\u0564\u0552\u0572\u0588\u058b\u0561\u056b\u0571\u0584\u0574\u0574\u0598\u055d\u0591\u059b\u0595\u056f\u0570\u0571\u0571\u0561\u0580\u055c", (byte)86, 70);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.f[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u055f\u0545\u0579\u058d\u058f\u057a\u057c\u0544\u056e\u058c\u0576\u056d\u0549\u0566\u0553\u0596\u058b\u0597\u0570\u0558\u0555\u058e\u0565\u0566", (byte)86, 70);
                }
            }
        }
    }

    @Override
    protected void a(\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, String string, String string2) {
        String string3 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(string2 + this.L);
        String string4 = null;
        if (this.M != null) {
            string4 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(string2 + this.M);
            if (((String)\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.c("\u3e80", (int)d, (long)(q ^ r))).equals(string4)) {
                string4 = null;
            }
        }
        this.a(string, string3, string4, null);
        ++this.l;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u04f5\u0517\u0519\u04f9\u051d\u053c\u0534\u054a\u0536\u0505\u0543\u0539\u0547\u0541\u050a\u052f\u0551\u0550\u0548\u054e\u0548\u051d", (byte)17, 69), \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0530\u053d\u053c\u04ff\u053f\u053b\u0536\u053f\u054a\u0539\u0506\u0544\u0548\u0541\u0544\u054a\u050c\u087e\u0897\u089a\u08a0\u089f\u089b\u087f\u08a0\u0897\u08ae\u08aa\u087d\u0524", (byte)17, 70) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0507", (byte)17, 69) + methodType.toString(), exception);
        }
    }

    public \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, String string, String string2, String string3, String string4) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4, string, string2);
        this.L = string3;
        this.M = string4;
    }

    private static String a(int n, long l) {
        l ^= 0xFL;
        l ^= 0xEED291FF6FFD23EAL;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(43 + 25), (byte)(40 + 29), (byte)(26 + 57), (byte)(9 + 38), (byte)(2 + 65), (byte)(65 + 1), (byte)(56 + 11), (byte)(22 + 25), (byte)(58 + 22), (byte)(48 + 27), (byte)(21 + 46), (byte)(5 + 78), (byte)(26 + 27), (byte)(6 + 74), (byte)(3 + 94), (byte)(36 + 64), (byte)(67 + 33), 105, 110, (byte)(78 + 25)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(30 + 39), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0559\u0566\u0565\u0528\u0568\u0564\u055f\u0568\u0573\u0562\u052f\u056d\u0571\u056a\u056d\u0573\u0535\u08a7\u08c0\u08c3\u08c9\u08c8\u08c4\u08a8\u08c9\u08c0\u08d7\u08d3\u08a6", (byte)107, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }
}

