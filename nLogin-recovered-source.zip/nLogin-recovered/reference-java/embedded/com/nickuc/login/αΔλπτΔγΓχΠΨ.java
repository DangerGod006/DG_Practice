/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public final class \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8 {
    public static String F(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String A(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String E(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String B(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String C(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String D(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }
}

