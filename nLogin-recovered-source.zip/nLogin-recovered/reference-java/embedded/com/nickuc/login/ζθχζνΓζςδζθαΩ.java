/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.event.PostOrder
 *  com.velocitypowered.api.event.Subscribe
 *  com.velocitypowered.api.event.connection.DisconnectEvent
 *  com.velocitypowered.api.event.connection.LoginEvent
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.ProxyServer
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4;
import com.nickuc.login.\u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import lombok.Generated;

public class \u03b6\u03b8\u03c7\u03b6\u03bd\u0393\u03b6\u03c2\u03b4\u03b6\u03b8\u03b1\u03a9
implements \u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9 {
    private final ProxyServer d;
    private final \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 c;

    @Generated
    public \u03b6\u03b8\u03c7\u03b6\u03bd\u0393\u03b6\u03c2\u03b4\u03b6\u03b8\u03b1\u03a9(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, ProxyServer proxyServer) {
        this.c = \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92;
        this.d = proxyServer;
    }

    @Subscribe(order=PostOrder.FIRST)
    public void a(LoginEvent loginEvent) {
        Player player = loginEvent.getPlayer();
        \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.j.put(player, \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.b(this.c, this.d, player));
    }

    @Subscribe(order=PostOrder.LAST)
    public void a(DisconnectEvent disconnectEvent) {
        \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.j.remove(disconnectEvent.getPlayer());
    }
}

