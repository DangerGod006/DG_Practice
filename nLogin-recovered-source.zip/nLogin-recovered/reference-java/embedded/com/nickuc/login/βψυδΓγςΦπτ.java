/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4
implements Cloneable {
    private static int b;
    private String bF;
    private static int f;
    private static long c;
    private static long e;
    static \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 b;
    private String bG;
    private static int c;
    private int af;
    private static String[] a;
    private static long g;
    private static int h;
    private TimeUnit a;
    private static long d;
    private static String[] b;
    private static int a;

    static {
        a = (Integer.MIN_VALUE >>> 30 | Integer.MIN_VALUE << ~30 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(0x40000000);
        c = Integer.reverse(0);
        d = Long.reverse(4197143914721788081L);
        e = Long.reverse(-2161727821137838080L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-2864500300995149647L);
        h = (786432 >>> 210 | 786432 << -210) & 0xFFFFFFFF;
        a = new String[a];
        b = new String[b];
        \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b();
        b = new \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4((String)\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.c("\u3e80", (int)c, (long)(d ^ e)), (String)\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.c("\u3e83", (int)f, (long)g), TimeUnit.MILLISECONDS, h);
    }

    @Generated
    public \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 a(int n) {
        this.af = n;
        return this;
    }

    static /* synthetic */ int a(\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42) {
        return \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42.af;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0428\u044a\u044c\u042c\u0450\u046f\u0467\u047d\u0469\u0438\u0476\u046c\u047a\u0474\u043d\u0462\u0484\u0483\u047b\u0481\u047b\u0450", (byte)25, 67), \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u0114\u0121\u0120\u00e3\u0123\u011f\u011a\u0123\u012e\u011d\u00ea\u0128\u012c\u0125\u0128\u012e\u00f0\u0474\u048b\u0489\u0479\u0459\u047a\u048a\u046f\u048a\u048f\u0106", (byte)25, 66) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u043a", (byte)25, 68) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 a(TimeUnit timeUnit) {
        this.a = timeUnit;
        return this;
    }

    static /* synthetic */ TimeUnit a(\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42) {
        return \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42.a;
    }

    @Generated
    public \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 b(String string) {
        this.bG = string;
        return this;
    }

    private static void b() {
        int n;
        c = -8285791856407413668L;
        long l = c ^ 0xC201FD035D7E0254L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(9 + 60), (byte)(70 + 13), (byte)(36 + 11), (byte)(64 + 3), (byte)(18 + 48), (byte)(38 + 29), (byte)(2 + 45), (byte)(26 + 54), (byte)(49 + 26), (byte)(35 + 32), (byte)(36 + 47), (byte)(14 + 39), (byte)(70 + 10), (byte)(46 + 51), (byte)(53 + 47), (byte)(43 + 57), 105, (byte)(56 + 54), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(36 + 33), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0440\u0417\u0417\u041f\u0400\u0427\u0417\u044e\u040c\u0430\u0423\u0408\u0412\u043b\u041c\u0410\u043e\u0424\u0422\u044b\u044d\u042d\u0446\u0456\u045d\u0429\u0435\u041c\u0460\u0450\u0456\u043f\u043d\u0456\u0449\u0462\u0460\u0438\u044a\u043c\u046c\u0428\u0468\u045a\u045b\u045f\u042b\u044e\u0446\u0448\u0442\u0452\u0434\u0469\u045a\u0471\u045f\u0472\u045e\u0481\u047f\u0471\u046c\u045f\u0454\u0481\u0477\u0489\u0480\u048b\u0477\u0486\u0467\u045b\u048a\u0455", (byte)8, 68);
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u00c7\u00fa\u00df\u00de\u0103\u00ec\u00ed\u00dd\u00d8\u00fb\u00e9\u0103\u0114\u00e4\u010d\u00ee\u00f3\u0110\u00f0\u00d7\u00f0\u00f5\u00e2\u00e3", (byte)8, 66);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0102\u00d9\u00d9\u00e1\u00c2\u00e9\u00d9\u0110\u00ce\u00f2\u00e5\u00ca\u00d4\u00fd\u00de\u00d2\u0100\u00e6\u00e4\u010d\u010f\u00ef\u0108\u0118\u011f\u00eb\u00f7\u00de\u0122\u0112\u0118\u0101\u00ff\u0118\u010b\u0124\u0122\u00fa\u010c\u00fe\u012e\u00ea\u012a\u011c\u011d\u0121\u00ed\u0110\u0108\u010a\u0104\u0114\u00f6\u012b\u011c\u0133\u0121\u0134\u0120\u0143\u0141\u0133\u012e\u0121\u0124\u013c\u0143\u0136\u011b\u010d\u0116\u012f\u0121\u011b\u014c\u0117", (byte)8, 65);
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u00c7\u00fa\u00df\u00de\u0103\u00ec\u00ed\u00dd\u00d8\u00fb\u00e8\u00d2\u0104\u010a\u00e4\u00d0\u00d3\u010c\u0119\u00f0\u00ea\u00d5\u010d\u0116\u0100\u0109\u0119\u0123\u00f7\u00f3\u00d8\u00e6", (byte)8, 65);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0103\u00f3\u00c6\u00f6\u0104\u00e4\u00d8\u00ee\u00c6\u00ec\u00cd\u00f4\u00e2\u0106\u010c\u00d5\u00d6\u00ef\u00f6\u0105\u00dc\u00e5\u00e2\u00e3", (byte)8, 65);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0440\u0433\u0438\u0408\u0403\u0449\u041a\u0442\u041e\u041d\u0402\u040c\u0420\u0450\u0426\u0414\u0444\u0457\u042c\u0424\u0445\u0433\u0420\u0421", (byte)8, 68);
                }
            }
        }
    }

    static /* synthetic */ String a(\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42) {
        return \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42.bF;
    }

    @Generated
    public \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 a(String string) {
        this.bF = string;
        return this;
    }

    private static String a(int n, long l) {
        l ^= 0x47L;
        l ^= 0xC201FD035D7E0254L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(43 + 25), (byte)(63 + 6), (byte)(42 + 41), (byte)(20 + 27), 67, (byte)(39 + 27), (byte)(38 + 29), (byte)(33 + 14), (byte)(38 + 42), (byte)(18 + 57), (byte)(15 + 52), (byte)(9 + 74), (byte)(45 + 8), (byte)(71 + 9), (byte)(50 + 47), (byte)(93 + 7), (byte)(45 + 55), (byte)(70 + 35), 110, (byte)(70 + 33)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(13 + 56), (byte)(65 + 18)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u017c\u0189\u0188\u014b\u018b\u0187\u0182\u018b\u0196\u0185\u0152\u0190\u0194\u018d\u0190\u0196\u0158\u04dc\u04f3\u04f1\u04e1\u04c1\u04e2\u04f2\u04d7\u04f2\u04f7", (byte)77, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 a() {
        try {
            return (\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4)b.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new RuntimeException(cloneNotSupportedException);
        }
    }

    static /* synthetic */ String b(\u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4 \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42) {
        return \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c42.bG;
    }

    @Generated
    public \u03b2\u03c8\u03c5\u03b4\u0393\u03b3\u03c2\u03a6\u03c0\u03c4(String string, String string2, TimeUnit timeUnit, int n) {
        this.bF = string;
        this.bG = string2;
        this.a = timeUnit;
        this.af = n;
    }
}

