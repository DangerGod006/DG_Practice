/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u03b2\u03a3\u03a3\u0393\u03bd\u03b8\u03a9\u03bb\u03bd\u03bd\u03a9\u03b3\u03c5\u03b4\u03c2 {
}

