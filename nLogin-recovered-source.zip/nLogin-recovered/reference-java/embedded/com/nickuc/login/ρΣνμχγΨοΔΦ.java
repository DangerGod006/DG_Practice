/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7;
import com.nickuc.login.\u0394\u03c5\u03a0\u03c9\u03b8\u03b1\u03c8\u03b4\u03a3\u03a3\u03b1\u03b4\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.io.File;
import java.util.List;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6 {
    public String getVersion();

    default public String c(boolean bl) {
        String string = this.b() + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u050a", (byte)33, 69) + this.getVersion() + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0446\u0483\u047b\u048d", (byte)33, 67);
        if (bl) {
            string = string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u00ef\u0136\u0130\u0134", (byte)33, 66);
        }
        return string;
    }

    public boolean c();

    @Nullable
    public String c();

    public boolean b();

    public List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> a();

    default public File a(\u0394\u03c5\u03a0\u03c9\u03b8\u03b1\u03c8\u03b4\u03a3\u03a3\u03b1\u03b4\u03c8\u03c9 \u03b4\u03c5\u03a0\u03c9\u03b8\u03b1\u03c8\u03b4\u03a3\u03a3\u03b1\u03b4\u03c8\u03c9, boolean bl) {
        return new File(\u03b4\u03c5\u03a0\u03c9\u03b8\u03b1\u03c8\u03b4\u03a3\u03a3\u03b1\u03b4\u03c8\u03c9.g, this.c(bl));
    }

    default public String A() {
        return this.b() + \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0474\u04cb", (byte)53, 67) + this.getVersion();
    }

    public String b();

    public String a();
}

