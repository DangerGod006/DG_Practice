/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

class \u03bc\u03c8\u03b4\u03c5\u03c0\u03ba\u03c1\u03c1\u0393\u03ba\u03ba\u0393\u0393\u03a8 {
}

