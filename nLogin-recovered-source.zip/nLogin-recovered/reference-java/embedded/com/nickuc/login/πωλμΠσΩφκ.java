/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03b9\u03bc\u03c1\u03b9\u03b3\u03b4\u03b2\u03c8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba
implements \u03bb\u03b9\u03bc\u03c1\u03b9\u03b3\u03b4\u03b2\u03c8 {
    private static int e;
    private static long ag;
    private static int ad;
    private static int i;
    private static int ab;
    private static int az;
    private static int u;
    private static int q;
    private static int bc;
    private static int ai;
    private static int m;
    private static int bi;
    private static int bl;
    private static int t;
    private static long s;
    private static int as;
    private static int aq;
    private static int aa;
    private static long r;
    private static int ar;
    private static int bb;
    private static long af;
    private static int g;
    private static int bg;
    private static int aw;
    private static int l;
    private static int au;
    private static int h;
    private static int o;
    private static long n;
    private static long d;
    private static int aj;
    private static long p;
    private static final char[] c;
    private static int bm;
    private static int bd;
    public static final String cq;
    private static int ay;
    private static int bf;
    private static int bk;
    private static int v;
    private static int ao;
    private static int ap;
    private static String[] b;
    private static int bn;
    private static int ba;
    private static int y;
    private static int an;
    private static int f;
    private static int ak;
    private static int av;
    private static int a;
    private static long b;
    private static int ah;
    private static int ae;
    private static long c;
    private static int ax;
    private static int am;
    private static long j;
    private static int bj;
    private static long k;
    private static String[] a;
    private static int z;
    private static int bh;
    private static int x;
    private static int ac;
    private static int be;
    private static int al;
    private static int w;
    private static int at;

    @Override
    public boolean i(String string, String string2) {
        String[] stringArray = string2.split((String)\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e80", (int)a, (long)(b ^ d)));
        if (stringArray.length != e) {
            return f != 0;
        }
        String string3 = stringArray[g];
        String string4 = stringArray[h];
        String string5 = (String)\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e83", (int)i, (long)(j ^ k)) + string + (String)\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e86", (int)(l & m), (long)n) + string3 + (String)\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e89", (int)o, (long)p) + string;
        return string4.equals(this.B(string5));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0177\u0199\u019b\u017b\u019f\u01be\u01b6\u01cc\u01b8\u0187\u01c5\u01bb\u01c9\u01c3\u018c\u01b1\u01d3\u01d2\u01ca\u01d0\u01ca\u019f", (byte)104, 65), \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01b2\u01bf\u01be\u0181\u01c1\u01bd\u01b8\u01c1\u01cc\u01bb\u0188\u01c6\u01ca\u01c3\u01c6\u01cc\u018e\u0520\u052a\u051d\u051f\u0504\u0528\u050f\u052d\u0522\u01a3", (byte)104, 65) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0527", (byte)104, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0xBBF27EFF73F671B3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(59 + 9), (byte)(38 + 31), (byte)(59 + 24), (byte)(27 + 20), (byte)(46 + 21), 66, (byte)(66 + 1), (byte)(6 + 41), (byte)(72 + 8), (byte)(70 + 5), (byte)(22 + 45), (byte)(80 + 3), (byte)(5 + 48), (byte)(13 + 67), (byte)(82 + 15), (byte)(93 + 7), (byte)(28 + 72), (byte)(40 + 65), (byte)(22 + 88), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(41 + 27), 69, (byte)(53 + 30)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0565\u0572\u0571\u0534\u0574\u0570\u056b\u0574\u057f\u056e\u053b\u0579\u057d\u0576\u0579\u057f\u0541\u08d3\u08dd\u08d0\u08d2\u08b7\u08db\u08c2\u08e0\u08d5", (byte)111, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-389079848556584706L);
        d = Long.reverse(-1873497444986126336L);
        e = Integer.reverse(0x20000000);
        f = 0 >>> 255 | 0 << -255;
        g = (Integer.MIN_VALUE >>> 62 | Integer.MIN_VALUE << -62) & 0xFFFFFFFF;
        h = (0xC000000 >>> 218 | 0xC000000 << -218) & 0xFFFFFFFF;
        i = (0x40000000 >>> 62 | 0x40000000 << -62) & 0xFFFFFFFF;
        j = Long.reverse(-389079848556584706L);
        k = Long.reverse(-1873497444986126336L);
        l = (131072 >>> 176 | 131072 << ~176 + 1) & 0xFFFFFFFF;
        m = -1 >>> 26 | -1 << -26;
        n = Long.reverse(2060878348732965118L);
        o = Integer.reverse(-1073741824);
        p = Long.reverse(2060878348732965118L);
        q = Integer.reverse(0x20000000);
        r = Long.reverse(-389079848556584706L);
        s = Long.reverse(-1873497444986126336L);
        t = 0 >>> 117 | 0 << ~117 + 1;
        u = Integer.reverse(0x40000000);
        v = 0 >>> 144 | 0 << -144;
        w = (2 >>> 224 | 2 << -224) & 0xFFFFFFFF;
        x = Integer.reverse(0x20000000);
        y = Integer.reverse(-268435456);
        z = (0x40000000 >>> 221 | 0x40000000 << -221) & 0xFFFFFFFF;
        aa = (0x10000000 >>> 188 | 0x10000000 << -188) & 0xFFFFFFFF;
        ab = 1920 >>> 103 | 1920 << ~103 + 1;
        ac = (0x18000000 >>> 154 | 0x18000000 << ~154 + 1) & 0xFFFFFFFF;
        ad = (0x600000 >>> 20 | 0x600000 << ~20 + 1) & 0xFFFFFFFF;
        ae = Integer.reverse(-1610612736);
        af = Long.reverse(-389079848556584706L);
        ag = Long.reverse(-1873497444986126336L);
        ah = (2 >>> 221 | 2 << -221) & 0xFFFFFFFF;
        ai = 0 >>> 160 | 0 << ~160 + 1;
        aj = 0x300000 >>> 176 | 0x300000 << ~176 + 1;
        ak = Integer.reverse(Integer.MIN_VALUE);
        al = (392 >>> 195 | 392 << -195) & 0xFFFFFFFF;
        am = Integer.reverse(0x40000000);
        an = Integer.reverse(0x4C000000);
        ao = (-1073741824 >>> 30 | -1073741824 << ~30 + 1) & 0xFFFFFFFF;
        ap = (-1073741812 >>> 62 | -1073741812 << ~62 + 1) & 0xFFFFFFFF;
        aq = (64 >>> 196 | 64 << -196) & 0xFFFFFFFF;
        ar = Integer.reverse(0x2C000000);
        as = Integer.reverse(-1610612736);
        at = Integer.reverse(-1409286144);
        au = (786432 >>> 81 | 786432 << ~81 + 1) & 0xFFFFFFFF;
        av = Integer.reverse(0x6C000000);
        aw = 458752 >>> 48 | 458752 << -48;
        ax = 14080 >>> 200 | 14080 << ~200 + 1;
        ay = Integer.reverse(0x10000000);
        az = Integer.reverse(0x1C000000);
        ba = 4608 >>> 233 | 4608 << -233;
        bb = Integer.reverse(-1677721600);
        bc = (20 >>> 193 | 20 << -193) & 0xFFFFFFFF;
        bd = (-1040187392 >>> 217 | -1040187392 << ~217 + 1) & 0xFFFFFFFF;
        be = Integer.reverse(-805306368);
        bf = Integer.reverse(0x46000000);
        bg = Integer.reverse(0x30000000);
        bh = Integer.reverse(-973078528);
        bi = Integer.reverse(-1342177280);
        bj = 819200 >>> 109 | 819200 << -109;
        bk = Integer.reverse(0x70000000);
        bl = Integer.reverse(-1509949440);
        bm = 30 >>> 97 | 30 << -97;
        bn = Integer.reverse(0x66000000);
        a = new String[ac];
        b = new String[ad];
        \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b();
        cq = \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e80", (int)ae, (long)(af ^ ag));
        char[] cArray = new char[ah];
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.ai] = aj;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.ak] = al;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.am] = an;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.ao] = ap;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.aq] = ar;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.as] = at;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.au] = av;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.aw] = ax;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.ay] = az;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.ba] = bb;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.bc] = bd;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.be] = bf;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.bg] = bh;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.bi] = bj;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.bk] = bl;
        cArray[\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.bm] = bn;
        c = cArray;
    }

    private static void b() {
        int n;
        c = 9152899621019556191L;
        long l = c ^ 0xBBF27EFF73F671B3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(4 + 64), (byte)(34 + 35), (byte)(20 + 63), (byte)(38 + 9), (byte)(37 + 30), 66, (byte)(56 + 11), (byte)(42 + 5), (byte)(56 + 24), (byte)(40 + 35), (byte)(50 + 17), (byte)(25 + 58), (byte)(23 + 30), (byte)(16 + 64), (byte)(34 + 63), (byte)(59 + 41), (byte)(98 + 2), 105, (byte)(69 + 41), (byte)(37 + 66)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(60 + 9), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01bd\u01d5\u01c7\u01c6\u01e4\u01ca\u01ac\u01c5\u01b2\u01e9\u01b3\u01b9", (byte)121, 65);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0564\u058c\u0598\u05a1\u05a2\u056d\u0590\u0590\u0575\u05a2\u0581\u0596\u05b0\u0591\u05b3\u05b5\u0575\u0577\u05b3\u0581\u05b8\u058b\u0588\u0589", (byte)121, 69);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u059b\u05a2\u057d\u056d\u059c\u0586\u05b3\u05b1\u058a\u05b3\u05af\u05a3\u0582\u0572\u058c\u05a8\u05b0\u057c\u0591\u057f\u058d\u05b1\u0588\u0589", (byte)121, 69);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[3] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u01e1\u01eb\u01b6\u01cb\u01c1\u01ab\u01f0\u01d1\u01a4\u01cc\u01c6\u01e8\u01f4\u01f0\u01e5\u01d5\u01d4\u01b4\u01e8\u01eb\u01cd\u01ed\u01c4\u01c5", (byte)121, 66);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u01b4\u01d6\u01ea\u01e1\u01b8\u01e5\u01f1\u01d1\u01ca\u01f3\u01b3\u01b9", (byte)121, 66);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0587\u05ac\u059a\u05a8\u058e\u0569\u05ac\u0572\u0590\u05aa\u0584\u05ad\u058f\u05ae\u0572\u0590\u0591\u0597\u058a\u05bb\u05b5\u05b1\u0588\u0589", (byte)121, 70);
                    continue block7;
                }
                case 1: {
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u01c2\u01bd\u01eb\u01df\u01ac\u01cd\u01be\u01d9\u01be\u01ed\u01c8\u01b9", (byte)121, 65);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0564\u058c\u0598\u05a1\u05a2\u056d\u0590\u0590\u0575\u05a2\u0583\u0577\u0590\u0571\u0592\u0596\u0598\u05ba\u057d\u058f\u059f\u05bd\u0597\u0584\u05c4\u05a7\u05b0\u05b2\u05a9\u0584\u05aa\u058a", (byte)121, 70);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u059b\u05a2\u057d\u056d\u059c\u0586\u05b3\u05b1\u058a\u05b3\u05af\u05b3\u05b8\u05ac\u059b\u059e\u0570\u059b\u0592\u05aa\u05b9\u05c1\u0588\u0589", (byte)121, 70);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u05a5\u05af\u057a\u058f\u0585\u056f\u05b4\u0595\u0568\u0590\u0589\u0577\u0576\u05ad\u05b1\u05b7\u05ab\u0571\u059b\u0597\u05af\u05c2\u0581\u0593\u059d\u057e\u05a6\u05a0\u05a1\u059d\u05ba\u059e", (byte)121, 70);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u059b\u0579\u0567\u05ae\u05ad\u059f\u058c\u056c\u0582\u0573\u0593\u05ae\u057a\u0577\u05b6\u059d\u05aa\u05b4\u059d\u05b3\u05c3\u059b\u0588\u0589", (byte)121, 70);
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0587\u05ac\u059a\u05a8\u058e\u0569\u05ac\u0572\u0590\u05aa\u0587\u0581\u0597\u0589\u0588\u058e\u05a8\u0577\u05bd\u058c\u05b9\u05c1\u0588\u0589", (byte)121, 70);
                    continue block7;
                }
                case 2: {
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01a4\u01a7\u01c5\u01ac\u01ba\u01dd\u01ca\u01ae\u01dd\u01e4\u01c3\u01c1\u01d1\u01d2\u01ce\u01ee\u01c8\u01f7\u01ec\u01dc\u01f8\u01fd\u01c4\u01c5", (byte)121, 66);
                    continue block7;
                }
                case 4: {
                    \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u01e1\u01a2\u01e8\u01e5\u01c1\u01bb\u01c7\u01ec\u01e3\u01e8\u01ed\u01b3\u01c9\u01ea\u01d9\u01cf\u01fb\u01f8\u01c7\u01e5\u01d2\u01f5\u01bb\u01d7\u01da\u01ed\u01bd\u01da\u01f8\u01e1\u01f7\u0200", (byte)121, 66);
                }
            }
        }
    }

    private String B(String string) {
        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance((String)\u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.c("\u3e80", (int)q, (long)(r ^ s)));
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new RuntimeException(noSuchAlgorithmException);
        }
        messageDigest.update(string.getBytes(StandardCharsets.UTF_8), t, string.length());
        return \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.e(messageDigest.digest());
    }

    private static String e(byte ... byArray) {
        char[] cArray = new char[byArray.length * u];
        for (int i = v; i < byArray.length; ++i) {
            cArray[i * \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.w] = c[byArray[i] >> x & y];
            cArray[i * \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.z + \u03c0\u03c9\u03bb\u03bc\u03a0\u03c3\u03a9\u03c6\u03ba.aa] = c[byArray[i] & ab];
        }
        return new String(cArray);
    }
}

