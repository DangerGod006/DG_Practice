/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.CommonDialogData
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.Dialog
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.DialogAction
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.MultiActionDialog
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.action.Action
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.action.DynamicCustomAction
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.body.DialogBody
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.body.PlainMessage
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.body.PlainMessageDialogBody
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.button.ActionButton
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.button.CommonButtonData
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.input.Input
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.input.InputControl
 *  com.nickuc.login.lib.packetevents.api.protocol.dialog.input.TextInputControl
 *  com.nickuc.login.lib.packetevents.api.protocol.player.ClientVersion
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  com.nickuc.login.lib.packetevents.api.resources.ResourceLocation
 *  com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper
 *  com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerClearDialog
 *  com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerShowDialog
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerClearDialog
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerShowDialog
 *  io.netty.channel.Channel
 *  io.netty.util.AttributeKey
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.CommonDialogData;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.Dialog;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.DialogAction;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.MultiActionDialog;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.action.Action;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.action.DynamicCustomAction;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.body.DialogBody;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.body.PlainMessage;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.body.PlainMessageDialogBody;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.button.ActionButton;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.button.CommonButtonData;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.input.Input;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.input.InputControl;
import com.nickuc.login.lib.packetevents.api.protocol.dialog.input.TextInputControl;
import com.nickuc.login.lib.packetevents.api.protocol.player.ClientVersion;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.lib.packetevents.api.resources.ResourceLocation;
import com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper;
import com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerClearDialog;
import com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerShowDialog;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerClearDialog;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerShowDialog;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4;
import com.nickuc.login.\u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9;
import com.nickuc.login.\u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b2\u03bf\u03bb\u03bc\u03c2\u03a6\u03b6\u0393\u03c8\u03b3\u03c4\u03b8\u0394\u039b;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc;
import com.nickuc.login.\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03a8\u03bd\u03c2\u03b7\u03c4\u03c4\u03c9\u03b3\u03ba\u03be\u03c8\u03c2;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03be\u03bd\u03c8\u03b7\u03c0\u03b9\u03b2;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1;
import com.nickuc.login.\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import io.netty.channel.Channel;
import io.netty.util.AttributeKey;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 {
    private static int o;
    private static int ff;
    private static int dk;
    private static long dy;
    private static int ad;
    private static int cj;
    private static int cs;
    private static int g;
    private static long av;
    private static long ay;
    private static long ap;
    private static int fs;
    private static long bj;
    private static int fj;
    private static int eu;
    private static int bl;
    public final \u03c2\u03be\u03bd\u03c8\u03b7\u03c0\u03b9\u03b2 a;
    private static int ds;
    private static int di;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 v;
    private static long ag;
    private static int ei;
    private static int ct;
    private static int ck;
    private static int s;
    private static long cn;
    private static int fi;
    private static int cm;
    private static int en;
    private static int du;
    private static int bw;
    private static long cy;
    public final \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4 a;
    private static int bv;
    private static int cx;
    private static long fe;
    private static int bs;
    private static long ew;
    private static int b;
    private static int cu;
    private static long dl;
    private static int ax;
    private static int ae;
    private static int dd;
    private static int al;
    private static int z;
    private static int am;
    private static int x;
    private static int fw;
    private static int ev;
    private static long ez;
    private static int ba;
    private static int k;
    private static long ab;
    private static long ex;
    private static long c;
    private static int fr;
    private static int eo;
    private static int em;
    private static int ca;
    private static int bk;
    private static int bn;
    private static int fv;
    private static long df;
    private static int f;
    private static String[] b;
    private static int el;
    private static int h;
    private static int cd;
    private static long y;
    private static int cc;
    private static int dc;
    private static long ep;
    private static long cp;
    private static int er;
    private static int dj;
    private static int aw;
    private static long ed;
    private static int dz;
    private static int at;
    private static int da;
    private static int w;
    private static long bc;
    private static int fp;
    private static int ea;
    private static int af;
    private static int fn;
    private static int q;
    private static int ai;
    private static int eh;
    private static int co;
    private static long cfr_renamed_1;
    private static long cv;
    private static long aj;
    private static int fu;
    private static int es;
    private static int ar;
    private static int cr;
    private static int cg;
    private static int fc;
    private static int as;
    private static int au;
    private static int bt;
    private static long cq;
    private static int ah;
    private static int fb;
    private static int j;
    private static int dq;
    private static int cl;
    private static int e;
    private static int bx;
    private static int az;
    private static long ak;
    private static int ey;
    private static int dg;
    private static int fd;
    private static long n;
    private static int bg;
    private static int eg;
    private static int be;
    private static int t;
    private static int dx;
    private static int r;
    private static long by;
    private static int dr;
    private static long aq;
    private static int bd;
    private static long cf;
    private static String[] a;
    private static int dn;
    private static long dm;
    private static int dp;
    public final \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5 a;
    private static long bp;
    private static int dt;
    private static long bf;
    private static int ef;
    private static int i;
    private static int br;
    private static int eb;
    private static long dh;
    private static long p;
    private static int ao;
    private static int fh;
    private static int bq;
    private static long fo;
    private static int l;
    private static long bi;
    private static long de;
    private static long fl;
    private static long m;
    private static long bm;
    private static int a;
    private static int cz;
    private static long bb;
    private static long bz;
    private static int ec;
    private static long fa;
    private static int ch;
    private static int db;
    private static int aa;
    private static int bo;
    private static int ci;
    private static int bh;
    private static long an;
    private static int dv;
    private static int ce;
    private static int v;
    private static int cb;
    private static int d;
    private static int ft;
    private static int dw;
    private static long ee;
    private static long u;
    private static long cw;
    private static int c;
    private static int et;
    private static int fk;
    private static int fm;
    private static int eq;
    private static long fg;
    public final \u03c2\u03a8\u03bd\u03c2\u03b7\u03c4\u03c4\u03c9\u03b3\u03ba\u03be\u03c8\u03c2 a = new \u03c2\u03be\u03bd\u03c8\u03b7\u03c0\u03b9\u03b2(this);
    private static int bu;
    private static long ac;
    private static int fq;
    private static long ej;
    private static int ek;

    @Generated
    public \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.v = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    static /* synthetic */ \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82) {
        return \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82.v;
    }

    static /* synthetic */ void a(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82, User user) {
        \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82.a(user);
    }

    private static String a(int n, long l) {
        l ^= 0x73L;
        l ^= 0xEEB4DEB27965114EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(40 + 29), (byte)(49 + 34), (byte)(32 + 15), (byte)(15 + 52), (byte)(62 + 4), (byte)(21 + 46), (byte)(36 + 11), (byte)(22 + 58), (byte)(61 + 14), 67, (byte)(29 + 54), (byte)(39 + 14), 80, (byte)(96 + 1), (byte)(8 + 92), (byte)(11 + 89), (byte)(65 + 40), (byte)(77 + 33), (byte)(6 + 97)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(35 + 33), 69, (byte)(3 + 80)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0198\u01a5\u01a4\u0167\u01a7\u01a3\u019e\u01a7\u01b2\u01a1\u016e\u01ac\u01b0\u01a9\u01ac\u01b2\u0174\u04f7\u0502\u0504\u04ec\u04f3\u050f\u0514\u0513\u0501\u0505\u0507\u0509\u0510\u051b", (byte)91, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    private \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc a(User user, Channel channel) {
        switch (\u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.L[((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)this.v.b()).a().ordinal()]) {
            case 1: {
                \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = (\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0)channel.attr((AttributeKey)\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a).get();
                if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null) {
                    String string = (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e80", (int)l, (long)(m ^ n)) + user.getName() + (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e83", (int)o, (long)p);
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string, new Object[q]);
                    this.a(user);
                    String[] stringArray = new String[r];
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.s] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e86", (int)t, (long)u);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.v] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e89", (int)(w & x), (long)y);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.z] = (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8c", (int)aa, (long)(ab ^ ac)) + string;
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.ad] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8f", (int)(ae & af), (long)ag);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.ah] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e92", (int)ai, (long)(aj ^ ak));
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.a(user, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray)));
                    return null;
                }
                return \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
            }
            case 2: 
            case 3: {
                \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1 \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 = (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1)channel.attr((AttributeKey)\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1.f).get();
                if (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 == null) {
                    String string = (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e95", (int)(al & am), (long)an) + user.getName() + (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e98", (int)ao, (long)(ap ^ aq));
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string, new Object[ar]);
                    this.a(user);
                    String[] stringArray = new String[as];
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.at] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e9b", (int)au, (long)av);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.aw] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e9e", (int)ax, (long)ay);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.az] = (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3ea1", (int)ba, (long)(bb ^ bc)) + string;
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.bd] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3ea4", (int)be, (long)bf);
                    stringArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.bg] = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3ea7", (int)bh, (long)(bi ^ bj));
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.a(user, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray)));
                    return null;
                }
                return \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12;
            }
        }
        throw new IllegalStateException((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3eaa", (int)(bk & bl), (long)bm) + (Object)((Object)((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)this.v.b()).a()) + (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3ead", (int)(bn & bo), (long)bp));
    }

    private static void b() {
        int n;
        c = 5566241513336963699L;
        long l = c ^ 0xEEB4DEB27965114EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(4 + 65), (byte)(34 + 49), (byte)(16 + 31), (byte)(7 + 60), (byte)(44 + 22), (byte)(10 + 57), (byte)(24 + 23), (byte)(37 + 43), (byte)(25 + 50), (byte)(7 + 60), (byte)(23 + 60), 53, (byte)(71 + 9), (byte)(6 + 91), 100, (byte)(46 + 54), (byte)(18 + 87), (byte)(76 + 34), (byte)(7 + 96)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(21 + 47), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0103\u00d1\u0111\u0115\u0113\u0104\u00f0\u010c\u0104\u00fa\u00e8\u010b\u0113\u00f5\u0116\u0118\u00f3\u00ee\u00e5\u0112\u0111\u00e0\u00ff\u0120\u0106\u0117\u00eb\u0104\u010b\u0110\u0120\u00fe\u0128\u00f1\u0114\u0109\u0132\u010d\u0125\u012a\u0139\u0116\u010f\u0113\u0116\u0115\u011a\u00f5\u00fb\u012f\u0144\u0138\u0126\u0140\u0104\u0127\u012c\u0116\u012c\u0130\u011e\u014a\u0108\u0127", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u00d4\u010b\u00d5\u0113\u010a\u00e1\u00ef\u00e9\u00f5\u00e6\u0110\u00f4\u00ee\u00f0\u00f8\u00ec\u00fe\u0111\u0102\u0110\u0105\u0116\u0124\u0104\u011c\u0119\u012c\u010d\u0126\u012a\u011c\u00f1\u0103\u012c\u00f4\u0120\u010b\u0128\u013a\u00fa\u012a\u0105\u00f6\u0112\u0119\u0133\u011b\u0140\u0138\u0103\u0122\u0132\u0147\u0147\u010e\u010f", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u040f\u044f\u044b\u0448\u044a\u0432\u0450\u041e\u0456\u044c\u0452\u045e\u0461\u0464\u0439\u0435\u0467\u0452\u0426\u0469\u0440\u0435\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u051b\u0536\u050f\u051c\u0522\u0525\u0522\u0539\u053b\u053e\u0525\u0512", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u00d3\u0114\u00ff\u00d4\u0104\u0119\u00f6\u00f6\u00d6\u00ee\u00f6\u00e3", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[5] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0430\u044b\u0424\u0431\u0437\u043a\u0437\u044e\u0450\u0453\u043a\u0427", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[6] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0415\u0458\u0445\u044a\u044c\u0455\u044d\u0411\u042f\u042a\u0433\u043b\u0442\u0453\u045e\u043b\u0467\u0424\u0458\u0441\u0457\u0446\u0460\u0457\u0446\u0465\u044f\u0468\u0471\u044c\u0466\u0447\u0478\u0432\u044c\u047a\u0433\u043b\u0450\u0452\u043a\u0454\u046f\u0471\u043b\u045a\u0471\u0457\u0447\u0440\u0481\u0482\u048c\u047b\u0452\u0453", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0532\u0500\u0540\u0544\u0542\u0533\u051f\u053b\u0533\u0529\u0517\u053a\u0542\u0524\u0545\u0547\u0522\u051d\u0514\u0541\u0540\u050f\u052e\u054f\u0535\u0546\u051a\u0533\u053a\u053f\u054f\u052d\u0557\u0520\u0543\u0538\u0561\u053c\u0554\u0559\u0568\u0545\u053e\u0542\u0545\u0544\u0549\u0524\u052a\u055e\u0573\u0567\u0555\u056f\u0533\u0556\u055b\u0545\u055b\u055f\u054d\u0579\u0537\u0556", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[8] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u00d4\u010b\u00d5\u0113\u010a\u00e1\u00ef\u00e9\u00f5\u00e6\u0110\u00f4\u00ee\u00f0\u00f8\u00ec\u00fe\u0111\u0102\u0110\u0105\u0116\u0124\u0104\u011c\u0119\u012c\u010d\u0126\u012a\u011c\u00f1\u0103\u012c\u00f4\u0120\u010b\u0128\u013a\u00fa\u012a\u0105\u00f6\u0112\u0119\u0133\u011b\u0140\u0138\u0103\u0122\u0132\u0147\u0147\u010e\u010f", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[9] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u04fa\u053a\u0536\u0533\u0535\u051d\u053b\u0509\u0541\u0537\u053d\u0549\u054c\u054f\u0524\u0520\u0552\u053d\u0511\u0554\u052b\u0520\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[10] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u051b\u0536\u050f\u051c\u0522\u0525\u0522\u0539\u053b\u053e\u0525\u0512", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[11] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00d3\u0114\u00ff\u00d4\u0104\u0119\u00f6\u00f6\u00d6\u00ee\u00f6\u00e3", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[12] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u051b\u0536\u050f\u051c\u0522\u0525\u0522\u0539\u053b\u053e\u0525\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[13] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0415\u0458\u0445\u044a\u044c\u0455\u044d\u0411\u042f\u042a\u0433\u043b\u0442\u0453\u045e\u043b\u0467\u0424\u0458\u0441\u0457\u0446\u0460\u0457\u0446\u0465\u044f\u0468\u0471\u044c\u0466\u0447\u0478\u0432\u044c\u047a\u0433\u043b\u0450\u0452\u043a\u0454\u046f\u0471\u043b\u045a\u0471\u0457\u0447\u0440\u0481\u0482\u048c\u047b\u0452\u0453", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[14] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0500\u0518\u04fe\u051f\u0503\u0500\u0547\u0509\u052b\u0539\u053a\u0523\u054e\u053a\u0543\u054b\u0524\u0524\u0531\u0551\u0538\u0556\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[15] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0530\u051f\u04fb\u051e\u0533\u0533\u0548\u0504\u0525\u0534\u0519\u0540\u0547\u0508\u0544\u0521\u0527\u0532\u0553\u054f\u051f\u0544\u0512\u0544\u0547\u0554\u0536\u0536\u0528\u054a\u053b\u053c", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[16] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u00fc\u00d0\u00e3\u00f2\u00d7\u00e5\u00f8\u00e3\u00ec\u00f3\u00ea\u00f6\u00ea\u010e\u00fc\u00f2\u00e0\u0112\u0125\u0114\u00f3\u0127\u00ee\u00ef", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[17] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0430\u044b\u0424\u0431\u0437\u043a\u0437\u044e\u0450\u0453\u043a\u0427", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[18] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u00dd\u0116\u00e4\u0107\u0107\u00ef\u00ee\u00f0\u00f7\u011c\u00f2\u00e3", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[19] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0530\u051b\u0537\u0530\u0526\u0512\u0516\u053b\u0520\u0538\u0538\u050d\u0521\u0530\u0541\u054b\u0520\u050d\u052b\u0541\u0558\u0546\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[20] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u00dd\u0116\u00e4\u0107\u0107\u00ef\u00ee\u00f0\u00f7\u011c\u00f2\u00e3", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[21] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0417\u0439\u045b\u0447\u0458\u043e\u0446\u0431\u045e\u041f\u0433\u0455\u0445\u045a\u0433\u0465\u0449\u045d\u045c\u0455\u0454\u0435\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[22] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00dd\u0116\u00e4\u0107\u0107\u00ef\u00ee\u00f0\u00f7\u011c\u00f2\u00e3", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[23] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0502\u0524\u0546\u0532\u0543\u0529\u0531\u051c\u0549\u050a\u051e\u0540\u0530\u0545\u051e\u0550\u0534\u0548\u0547\u0540\u053f\u0520\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[24] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0421\u045a\u0428\u044b\u044b\u0433\u0432\u0434\u043b\u0460\u0436\u0427", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[25] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u051e\u0533\u051d\u0543\u0540\u0518\u0506\u053b\u054a\u052c\u050b\u053a\u052f\u0549\u053d\u0508\u052b\u053f\u054e\u0520\u0520\u0556\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[26] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0440\u0414\u0427\u0436\u041b\u0429\u043c\u0427\u0430\u0437\u0431\u0420\u041e\u0452\u045d\u045a\u0439\u045b\u0448\u0460\u046c\u0435\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[27] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u051b\u0536\u050f\u051c\u0522\u0525\u0522\u0539\u053b\u053e\u0525\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[28] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u052b\u04ff\u0512\u0521\u0506\u0514\u0527\u0512\u051b\u0522\u051b\u054c\u051d\u052d\u053d\u0552\u052f\u0513\u0534\u0527\u0542\u0546\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[29] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u051b\u0536\u050f\u051c\u0522\u0525\u0522\u0539\u053b\u053e\u0525\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[30] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u050c\u0545\u0513\u0536\u0536\u051e\u051d\u051f\u0526\u054b\u0521\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[31] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0447\u0419\u0435\u0457\u0416\u0448\u0454\u0417\u0454\u0439\u0419\u0432\u041c\u043a\u043e\u0426\u043a\u0420\u046b\u0422\u042a\u046d\u0449\u0444\u045f\u042c\u0445\u042d\u0452\u044a\u0466\u046e", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[32] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u050c\u0545\u0513\u0536\u0536\u051e\u051d\u051f\u0526\u054b\u0521\u0512", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[33] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0532\u0504\u0520\u0542\u0501\u0533\u053f\u0502\u053f\u0524\u0504\u051a\u050c\u0543\u0526\u0525\u0534\u0541\u054f\u0515\u054c\u0530\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[34] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u00ee\u0115\u0117\u0102\u010f\u0104\u00e7\u00d6\u00fa\u0112\u0106\u00f5\u00f9\u0122\u0123\u011f\u010c\u0115\u0127\u0104\u00f7\u010a\u00e2\u00f4\u010a\u0100\u00fc\u00e9\u00fb\u0101\u0104\u0109\u0102\u0112\u0136\u0106\u00f1\u010f\u0115\u00f2\u012c\u010c\u011e\u0103", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[35] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u051d\u0544\u0546\u0531\u053e\u0533\u0516\u0505\u0529\u0541\u0535\u0524\u0528\u0551\u0552\u054e\u053b\u0544\u0556\u0533\u0526\u0539\u0511\u0523\u0539\u052f\u052b\u0518\u052a\u0530\u0533\u0538\u0531\u0541\u0565\u0535\u0520\u053e\u0544\u0521\u055b\u053b\u054d\u0532", (byte)14, 70);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0447\u0415\u0455\u0459\u0457\u0448\u0434\u0450\u0448\u043e\u042c\u044f\u0457\u0439\u045a\u045c\u0437\u0432\u0429\u0456\u0455\u0424\u0443\u0464\u044a\u045b\u042f\u0448\u044f\u0454\u0464\u0442\u046c\u0435\u0458\u044d\u0476\u0451\u0469\u046e\u047d\u045a\u0453\u0457\u045a\u0459\u045e\u0439\u043f\u0473\u0488\u047c\u046a\u0481\u044a\u0477\u046d\u045b\u048f\u0494\u046f\u0481\u0472\u0495", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u00d4\u010b\u00d5\u0113\u010a\u00e1\u00ef\u00e9\u00f5\u00e6\u0110\u00f4\u00ee\u00f0\u00f8\u00ec\u00fe\u0111\u0102\u0110\u0105\u0116\u0124\u0104\u011c\u0119\u012c\u010d\u0126\u012a\u011c\u00f1\u0103\u012c\u00f4\u0120\u010b\u0128\u013a\u00fa\u012a\u0105\u00f7\u00f5\u0131\u012c\u012d\u0111\u00fe\u0120\u00fd\u0134\u0131\u0147\u010e\u010f", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[2] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u040f\u044f\u044b\u0448\u044a\u0432\u0450\u041e\u0456\u044c\u0452\u044d\u0459\u045e\u043e\u0434\u043e\u0467\u043b\u0426\u046d\u045b\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[3] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0112\u00d0\u00e9\u010a\u00ed\u010f\u00f0\u0103\u00d7\u011c\u00dd\u00e3", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[4] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00ca\u00ec\u00d4\u00d5\u0104\u00e8\u00f0\u00f0\u00d8\u00fd\u010c\u00e3", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[5] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0536\u0511\u0540\u0510\u0503\u0510\u051b\u0529\u0521\u0529\u0543\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[6] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u00d1\u0114\u0101\u0106\u0108\u0111\u0109\u00cd\u00eb\u00e6\u00ef\u00f7\u00fe\u010f\u011a\u00f7\u0123\u00e0\u0114\u00fd\u0113\u0102\u011c\u0113\u0102\u0121\u010b\u0124\u012d\u0108\u0122\u0103\u0134\u00ee\u0108\u0136\u00ef\u00f7\u010c\u010e\u00f6\u0110\u012b\u0116\u010b\u0113\u0135\u013c\u0102\u0142\u0143\u013f\u0105\u0121\u010e\u010f", (byte)14, 65);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0532\u0500\u0540\u0544\u0542\u0533\u051f\u053b\u0533\u0529\u0517\u053a\u0542\u0524\u0545\u0547\u0522\u051d\u0514\u0541\u0540\u050f\u052e\u054f\u0535\u0546\u051a\u0533\u053a\u053f\u054f\u052d\u0557\u0520\u0543\u0538\u0561\u053c\u0554\u0559\u0568\u0545\u053e\u0542\u0545\u0544\u0549\u0524\u052a\u055e\u0573\u0567\u0555\u0567\u0558\u0567\u056d\u0565\u055e\u0549\u057a\u0580\u053c\u0559", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[8] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0418\u044f\u0419\u0457\u044e\u0425\u0433\u042d\u0439\u042a\u0454\u0438\u0432\u0434\u043c\u0430\u0442\u0455\u0446\u0454\u0449\u045a\u0468\u0448\u0460\u045d\u0470\u0451\u046a\u046e\u0460\u0435\u0447\u0470\u0438\u0464\u044f\u046c\u047e\u043e\u046e\u0449\u0439\u0463\u0453\u044f\u0457\u0478\u0478\u0474\u0473\u0485\u0477\u047b\u0452\u0453", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[9] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u04fa\u053a\u0536\u0533\u0535\u051d\u053b\u0509\u0541\u0537\u053d\u0504\u0517\u0538\u051d\u054f\u0541\u054c\u052a\u0510\u052c\u0556\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[10] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u042b\u0438\u044b\u0437\u0439\u0457\u0455\u043b\u045d\u0457\u043e\u0427", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[11] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u0438\u0456\u0430\u0426\u0438\u0446\u041c\u045d\u0431\u0441\u043e\u0427", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[12] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u042b\u0414\u0451\u0456\u0451\u0453\u041e\u0415\u0435\u0420\u045c\u0427", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[13] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0415\u0458\u0445\u044a\u044c\u0455\u044d\u0411\u042f\u042a\u0433\u043b\u0442\u0453\u045e\u043b\u0467\u0424\u0458\u0441\u0457\u0446\u0460\u0457\u0446\u0465\u044f\u0468\u0471\u044c\u0466\u0447\u0478\u0432\u044c\u047a\u0433\u043b\u0450\u0452\u043a\u0454\u046c\u045b\u043c\u0460\u047d\u047e\u045e\u0477\u0466\u046b\u0467\u048b\u0452\u0453", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[14] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u00d1\u00e9\u00cf\u00f0\u00d4\u00d1\u0118\u00da\u00fc\u010a\u0109\u010e\u010b\u00f2\u0122\u00df\u00e3\u00df\u011b\u011a\u00f3\u0101\u00ee\u00ef", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[15] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0445\u0434\u0410\u0433\u0448\u0448\u045d\u0419\u043a\u0449\u042e\u0455\u045c\u041d\u0459\u0436\u043c\u0447\u0468\u0464\u0434\u044d\u0458\u0425\u043d\u044c\u043e\u044f\u0473\u044d\u044e\u042f", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[16] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0440\u0414\u0427\u0436\u041b\u0429\u043c\u0427\u0430\u0437\u042f\u0440\u045d\u0464\u0451\u0451\u045a\u0420\u0435\u0425\u045d\u0445\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[17] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u051f\u0545\u0541\u0514\u0520\u0542\u0521\u0509\u0523\u054b\u0508\u0512", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[18] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u051b\u0536\u0545\u04f8\u0541\u0508\u053a\u0537\u0546\u0537\u054b\u053d\u0524\u053d\u052c\u0521\u053f\u050c\u0553\u052b\u052d\u0546\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[19] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0530\u051b\u0537\u0530\u0526\u0512\u0516\u053b\u0520\u0538\u0537\u053a\u051e\u0529\u054c\u050e\u051d\u054d\u0513\u0527\u0549\u0530\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[20] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0456\u044a\u0431\u044b\u0446\u0434\u0458\u044e\u0454\u041a\u0421\u0442\u041e\u045d\u0461\u0433\u045b\u0428\u0447\u0448\u0423\u046b\u0432\u0433", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[21] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0417\u0439\u045b\u0447\u0458\u043e\u0446\u0431\u045e\u041f\u0433\u0459\u045a\u0458\u041c\u0444\u0459\u0461\u0469\u0440\u043c\u0445\u0432\u0433", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[22] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0110\u0113\u0102\u00ee\u00e2\u0116\u0107\u011c\u011a\u00d5\u00ea\u00f3\u0100\u00dc\u0122\u00f1\u00f4\u00e2\u011d\u00fb\u0109\u0101\u00ee\u00ef", (byte)14, 66);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[23] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0502\u0524\u0546\u0532\u0543\u0529\u0531\u051c\u0549\u050a\u051f\u0500\u050a\u0520\u052c\u0521\u0523\u052c\u0551\u052e\u052d\u0524\u0541\u055b\u053c\u0539\u054d\u054a\u0540\u0555\u053a\u055c", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[24] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0458\u042e\u042f\u0434\u0445\u0415\u0448\u0431\u041a\u042c\u0463\u0430\u0444\u0453\u0446\u041d\u0436\u043d\u0432\u0441\u0425\u0435\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[25] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u051e\u0533\u051d\u0543\u0540\u0518\u0506\u053b\u054a\u052c\u050a\u053f\u0541\u0544\u0519\u053c\u053c\u0534\u0532\u0543\u0541\u0546\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[26] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0440\u0414\u0427\u0436\u041b\u0429\u043c\u0427\u0430\u0437\u042e\u045e\u041a\u0456\u0436\u0443\u041e\u045a\u0449\u046b\u0442\u046b\u0432\u0433", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[27] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0510\u04fb\u051f\u0542\u0547\u0519\u0516\u0503\u0501\u0542\u054b\u0512", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[28] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u052b\u04ff\u0512\u0521\u0506\u0514\u0527\u0512\u051b\u0522\u051a\u0522\u051f\u0538\u0551\u051f\u050a\u054d\u050b\u054e\u050d\u0520\u051d\u051e", (byte)14, 69);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[29] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u042f\u042b\u042a\u0451\u0437\u0418\u0450\u0437\u041a\u0435\u041d\u0427", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[30] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0510\u0515\u051c\u0511\u0531\u0532\u0533\u052b\u0528\u0537\u0508\u053f\u052e\u052b\u052c\u0528\u050a\u053e\u052f\u0534\u0517\u0530\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[31] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0447\u0419\u0435\u0457\u0416\u0448\u0454\u0417\u0454\u0439\u0419\u0432\u041c\u043a\u043e\u0426\u043a\u0420\u046b\u0422\u042a\u0429\u0441\u044a\u0470\u043f\u0430\u046b\u0463\u0465\u0440\u046c", (byte)14, 68);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[32] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u053f\u0514\u0504\u0538\u053e\u0524\u051e\u0521\u0544\u0545\u054b\u052d\u0524\u0529\u050a\u0530\u051d\u052e\u0527\u0544\u0536\u0530\u051d\u051e", (byte)14, 70);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[33] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0447\u0419\u0435\u0457\u0416\u0448\u0454\u0417\u0454\u0439\u0419\u0436\u043f\u043a\u0447\u0459\u0453\u0466\u0440\u0458\u0464\u0439\u042e\u043e\u042b\u0463\u0440\u0430\u0444\u0470\u0471\u0429", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[34] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0432\u0459\u045b\u0446\u0453\u0448\u042b\u041a\u043e\u0456\u044a\u0439\u043d\u0466\u0467\u0463\u0450\u0459\u046b\u0448\u043b\u044e\u0426\u0438\u044e\u0444\u0440\u042d\u043f\u0445\u0448\u044d\u0474\u0459\u0457\u045b\u0445\u045c\u045e\u0439\u0473\u0433\u0474\u0447", (byte)14, 67);
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[35] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u00ee\u0115\u0117\u0102\u010f\u0104\u00e7\u00d6\u00fa\u0112\u0106\u00f5\u00f9\u0122\u0123\u011f\u010c\u0115\u0127\u0104\u00f7\u010a\u00e2\u00f4\u010a\u0100\u00fc\u00e9\u00fb\u0101\u0104\u0109\u0120\u010f\u0113\u00f2\u012d\u00f8\u00fa\u0111\u0133\u012d\u011a\u0103", (byte)14, 66);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0435\u0417\u0434\u0414\u044e\u041c\u042d\u042c\u0419\u0438\u0419\u0427", (byte)14, 67);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0420\u0435\u0434\u0434\u042d\u0426\u0457\u0416\u0416\u0454\u042f\u0464\u0456\u0437\u043b\u0421\u0437\u0432\u0443\u0429\u043f\u0445\u0432\u0433", (byte)14, 68);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0);
        b = (0 >>> 152 | 0 << ~152 + 1) & 0xFFFFFFFF;
        c = (0 >>> 84 | 0 << -84) & 0xFFFFFFFF;
        d = Integer.reverse(0);
        e = 0 >>> 79 | 0 << -79;
        f = Integer.reverse(0);
        g = Integer.reverse(0);
        h = (4096 >>> 204 | 4096 << ~204 + 1) & 0xFFFFFFFF;
        i = 0 >>> 226 | 0 << ~226 + 1;
        j = Integer.reverse(0);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = (0 >>> 65 | 0 << ~65 + 1) & 0xFFFFFFFF;
        m = Long.reverse(-3584339658097361742L);
        n = Long.reverse(-3602879701896396800L);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Long.reverse(18540043799035058L);
        q = 0 >>> 225 | 0 << ~225 + 1;
        r = Integer.reverse(-1610612736);
        s = 0 >>> 56 | 0 << -56;
        t = (8 >>> 66 | 8 << ~66 + 1) & 0xFFFFFFFF;
        u = Long.reverse(18540043799035058L);
        v = Integer.reverse(Integer.MIN_VALUE);
        w = 0x30000000 >>> 92 | 0x30000000 << -92;
        x = (-1 >>> 19 | -1 << -19) & 0xFFFFFFFF;
        y = Long.reverse(18540043799035058L);
        z = Integer.reverse(0x40000000);
        aa = Integer.reverse(0x20000000);
        ab = Long.reverse(-3584339658097361742L);
        ac = Long.reverse(-3602879701896396800L);
        ad = Integer.reverse(-1073741824);
        ae = Integer.reverse(-1610612736);
        af = -1 >>> 247 | -1 << ~247 + 1;
        ag = Long.reverse(18540043799035058L);
        ah = Integer.reverse(0x20000000);
        ai = Integer.reverse(0x60000000);
        aj = Long.reverse(-3584339658097361742L);
        ak = Long.reverse(-3602879701896396800L);
        al = 7168 >>> 234 | 7168 << -234;
        am = (-1 >>> 132 | -1 << ~132 + 1) & 0xFFFFFFFF;
        an = Long.reverse(18540043799035058L);
        ao = 8192 >>> 202 | 8192 << -202;
        ap = Long.reverse(-3584339658097361742L);
        aq = Long.reverse(-3602879701896396800L);
        ar = (0 >>> 152 | 0 << -152) & 0xFFFFFFFF;
        as = (5120 >>> 234 | 5120 << -234) & 0xFFFFFFFF;
        at = Integer.reverse(0);
        au = (0x120000 >>> 81 | 0x120000 << -81) & 0xFFFFFFFF;
        av = Long.reverse(18540043799035058L);
        aw = Integer.reverse(Integer.MIN_VALUE);
        ax = 0x40000001 >>> 221 | 0x40000001 << ~221 + 1;
        ay = Long.reverse(18540043799035058L);
        az = Integer.reverse(0x40000000);
        ba = Integer.reverse(-805306368);
        bb = Long.reverse(-3584339658097361742L);
        bc = Long.reverse(-3602879701896396800L);
        bd = 3 >>> 128 | 3 << ~128 + 1;
        be = 0x1800000 >>> 85 | 0x1800000 << -85;
        bf = Long.reverse(18540043799035058L);
        bg = Integer.reverse(0x20000000);
        bh = Integer.reverse(-1342177280);
        bi = Long.reverse(-3584339658097361742L);
        bj = Long.reverse(-3602879701896396800L);
        bk = (917504 >>> 208 | 917504 << -208) & 0xFFFFFFFF;
        bl = -1 >>> 177 | -1 << ~177 + 1;
        bm = Long.reverse(18540043799035058L);
        bn = 0x7800000 >>> 55 | 0x7800000 << ~55 + 1;
        bo = -1 >>> 18 | -1 << -18;
        bp = Long.reverse(18540043799035058L);
        bq = (0 >>> 90 | 0 << ~90 + 1) & 0xFFFFFFFF;
        br = Integer.reverse(Integer.MIN_VALUE);
        bs = 0 >>> 197 | 0 << ~197 + 1;
        bt = 0 >>> 205 | 0 << -205;
        bu = Integer.reverse(880803840);
        bv = 32768 >>> 239 | 32768 << -239;
        bw = Integer.reverse(0);
        bx = Integer.reverse(0x8000000);
        by = Long.reverse(-3584339658097361742L);
        bz = Long.reverse(-3602879701896396800L);
        ca = (19660800 >>> 112 | 19660800 << ~112 + 1) & 0xFFFFFFFF;
        cb = (0 >>> 133 | 0 << ~133 + 1) & 0xFFFFFFFF;
        cc = Integer.reverse(Integer.MIN_VALUE);
        cd = Integer.reverse(-2013265920);
        ce = (-1 >>> 101 | -1 << ~101 + 1) & 0xFFFFFFFF;
        cf = Long.reverse(18540043799035058L);
        cg = Integer.reverse(0x2000000);
        ch = Integer.reverse(0x40000000);
        ci = Integer.reverse(0);
        cj = Integer.reverse(0);
        ck = 614400 >>> 172 | 614400 << ~172 + 1;
        cl = Integer.reverse(0x48000000);
        cm = (-1 >>> 68 | -1 << ~68 + 1) & 0xFFFFFFFF;
        cn = Long.reverse(18540043799035058L);
        co = Integer.reverse(-939524096);
        cp = Long.reverse(-3584339658097361742L);
        cq = Long.reverse(-3602879701896396800L);
        cr = Integer.reverse(Integer.MIN_VALUE);
        cs = (0 >>> 211 | 0 << ~211 + 1) & 0xFFFFFFFF;
        ct = (0x4B0000 >>> 143 | 0x4B0000 << ~143 + 1) & 0xFFFFFFFF;
        cu = Integer.reverse(0x28000000);
        cv = Long.reverse(-3584339658097361742L);
        cw = Long.reverse(-3602879701896396800L);
        cx = Integer.reverse(-1476395008);
        cy = Long.reverse(18540043799035058L);
        cz = (0x20000000 >>> 189 | 0x20000000 << -189) & 0xFFFFFFFF;
        da = Integer.reverse(0);
        db = (0 >>> 45 | 0 << -45) & 0xFFFFFFFF;
        dc = Integer.reverse(0x13000000);
        dd = (22 >>> 224 | 22 << -224) & 0xFFFFFFFF;
        de = Long.reverse(-3584339658097361742L);
        df = Long.reverse(-3602879701896396800L);
        dg = Integer.reverse(-402653184);
        dh = Long.reverse(18540043799035058L);
        di = Integer.reverse(0);
        dj = 1200 >>> 67 | 1200 << ~67 + 1;
        dk = 786432 >>> 143 | 786432 << ~143 + 1;
        dl = Long.reverse(-3584339658097361742L);
        dm = Long.reverse(-3602879701896396800L);
        dn = (0x19000000 >>> 152 | 0x19000000 << ~152 + 1) & 0xFFFFFFFF;
        cfr_renamed_1 = Long.reverse(18540043799035058L);
        dp = Integer.reverse(0);
        dq = Integer.reverse(Integer.MIN_VALUE);
        dr = Integer.reverse(0);
        ds = Integer.reverse(0);
        dt = Integer.reverse(880803840);
        du = Integer.reverse(0x40000000);
        dv = 0 >>> 117 | 0 << -117;
        dw = (0x34000000 >>> 57 | 0x34000000 << ~57 + 1) & 0xFFFFFFFF;
        dx = Integer.reverse(-1);
        dy = Long.reverse(18540043799035058L);
        dz = (38400 >>> 71 | 38400 << -71) & 0xFFFFFFFF;
        ea = Integer.reverse(0);
        eb = Integer.MIN_VALUE >>> 127 | Integer.MIN_VALUE << -127;
        ec = 864 >>> 229 | 864 << ~229 + 1;
        ed = Long.reverse(-3584339658097361742L);
        ee = Long.reverse(-3602879701896396800L);
        ef = (0x100000 >>> 14 | 0x100000 << -14) & 0xFFFFFFFF;
        eg = Integer.reverse(Integer.MIN_VALUE);
        eh = Integer.reverse(0x38000000);
        ei = (-1 >>> 221 | -1 << ~221 + 1) & 0xFFFFFFFF;
        ej = Long.reverse(18540043799035058L);
        ek = 150 >>> 191 | 150 << -191;
        el = 0 >>> 40 | 0 << ~40 + 1;
        em = Integer.MIN_VALUE >>> 127 | Integer.MIN_VALUE << -127;
        en = 116 >>> 226 | 116 << -226;
        eo = Integer.reverse(-1);
        ep = Long.reverse(18540043799035058L);
        eq = Integer.reverse(0x2000000);
        er = (262144 >>> 50 | 262144 << ~50 + 1) & 0xFFFFFFFF;
        es = 0 >>> 217 | 0 << ~217 + 1;
        et = Integer.reverse(0);
        eu = Integer.reverse(0x13000000);
        ev = Integer.reverse(0x78000000);
        ew = Long.reverse(-3584339658097361742L);
        ex = Long.reverse(-3602879701896396800L);
        ey = Integer.reverse(-134217728);
        ez = Long.reverse(-3584339658097361742L);
        fa = Long.reverse(-3602879701896396800L);
        fb = 0 >>> 85 | 0 << ~85 + 1;
        fc = Integer.reverse(0x69000000);
        fd = Integer.reverse(0x4000000);
        fe = Long.reverse(18540043799035058L);
        ff = Integer.reverse(-2080374784);
        fg = Long.reverse(18540043799035058L);
        fh = (0x1000000 >>> 248 | 0x1000000 << ~248 + 1) & 0xFFFFFFFF;
        fi = 0 >>> 60 | 0 << ~60 + 1;
        fj = Integer.reverse(0x40000000);
        fk = Integer.reverse(0x44000000);
        fl = Long.reverse(18540043799035058L);
        fm = Integer.reverse(Integer.MIN_VALUE);
        fn = Integer.reverse(-1006632960);
        fo = Long.reverse(18540043799035058L);
        fp = Integer.reverse(0);
        fq = Integer.reverse(0);
        fr = Integer.reverse(0);
        fs = 0 >>> 232 | 0 << ~232 + 1;
        ft = Integer.reverse(0);
        fu = Integer.reverse(0);
        fv = Integer.reverse(0x24000000);
        fw = Integer.reverse(0x24000000);
        a = new String[fv];
        b = new String[fw];
        \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.b();
    }

    static /* synthetic */ \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc a(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82, User user, Channel channel) {
        return \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82.a(user, channel);
    }

    public void a(User user, String string, boolean bl, @Nullable \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2) {
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<ActionButton> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02;
        TextComponent textComponent = \u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bE, string, null, new Object[bq]));
        DialogBody[] dialogBodyArray = new DialogBody[br];
        dialogBodyArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.bs] = new PlainMessageDialogBody(new PlainMessage((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bF, string, null, new Object[bt])), bu));
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<DialogBody> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c03 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(dialogBodyArray);
        Input[] inputArray = new Input[bv];
        inputArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.bw] = new Input((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e80", (int)bx, (long)(by ^ bz)), (InputControl)new TextInputControl(ca, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bG, string, null, new Object[cb])), cc != 0, (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e83", (int)(cd & ce), (long)cf), cg, null));
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<Input> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c04 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(inputArray);
        if (bl) {
            ActionButton[] actionButtonArray = new ActionButton[ch];
            actionButtonArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.ci] = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bI, string, null, new Object[cj])), null, ck), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e86", (int)(cl & cm), (long)cn), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e89", (int)co, (long)(cp ^ cq))), null));
            actionButtonArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.cr] = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bH, string, null, new Object[cs])), null, ct), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8c", (int)cu, (long)(cv ^ cw)), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8f", (int)cx, (long)cy)), null));
            \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(actionButtonArray);
        } else {
            ActionButton[] actionButtonArray = new ActionButton[cz];
            actionButtonArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.da] = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bH, string, null, new Object[db])), null, dc), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e92", (int)dd, (long)(de ^ df)), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e95", (int)dg, (long)dh)), null));
            \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(actionButtonArray);
        }
        ActionButton actionButton = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bJ, string, null, new Object[di])), null, dj), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e98", (int)dk, (long)(dl ^ dm)), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e9b", (int)dn, (long)cfr_renamed_1)), null));
        this.a(user, textComponent, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c03, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c04, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02, actionButton, \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u03e3\u0405\u0407\u03e7\u040b\u042a\u0422\u0438\u0424\u03f3\u0431\u0427\u0435\u042f\u03f8\u041d\u043f\u043e\u0436\u043c\u0436\u040b", (byte)2, 67), \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u00e6\u00f3\u00f2\u00b5\u00f5\u00f1\u00ec\u00f5\u0100\u00ef\u00bc\u00fa\u00fe\u00f7\u00fa\u0100\u00c2\u0445\u0450\u0452\u043a\u0441\u045d\u0462\u0461\u044f\u0453\u0455\u0457\u045e\u0469\u00dc", (byte)2, 66) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u04f8", (byte)2, 69) + methodType.toString(), exception);
        }
    }

    public void a(User user, String string, @Nullable \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2) {
        TextComponent textComponent = \u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bK, string, null, new Object[dp]));
        DialogBody[] dialogBodyArray = new DialogBody[dq];
        dialogBodyArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.dr] = new PlainMessageDialogBody(new PlainMessage((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bL, string, null, new Object[ds])), dt));
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<DialogBody> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(dialogBodyArray);
        Input[] inputArray = new Input[du];
        inputArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.dv] = new Input((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e80", (int)(dw & dx), (long)dy), (InputControl)new TextInputControl(dz, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bM, string, null, new Object[ea])), eb != 0, (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e83", (int)ec, (long)(ed ^ ee)), ef, null));
        inputArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.eg] = new Input((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e86", (int)(eh & ei), (long)ej), (InputControl)new TextInputControl(ek, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bN, string, null, new Object[el])), em != 0, (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e89", (int)(en & eo), (long)ep), eq, null));
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<Input> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c03 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(inputArray);
        ActionButton[] actionButtonArray = new ActionButton[er];
        actionButtonArray[\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.es] = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bO, string, null, new Object[et])), null, eu), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8c", (int)ev, (long)(ew ^ ex)), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e8f", (int)ey, (long)(ez ^ fa))), null));
        \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0<ActionButton> \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c04 = \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c0.a(actionButtonArray);
        ActionButton actionButton = new ActionButton(new CommonButtonData((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.bP, string, null, new Object[fb])), null, fc), (Action)new DynamicCustomAction(new ResourceLocation((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e92", (int)fd, (long)fe), (String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e95", (int)ff, (long)fg)), null));
        this.a(user, textComponent, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c02, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c03, \u03b7\u03b6\u03b7\u03c3\u03a0\u03a0\u03c9\u0393\u03c1\u03b3\u03c04, actionButton, \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2);
    }

    private void a(User user) {
        switch (\u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.M[user.getEncoderState().ordinal()]) {
            case 1: {
                user.sendPacketSilently((PacketWrapper)new WrapperConfigServerClearDialog());
                break;
            }
            case 2: {
                user.sendPacketSilently((PacketWrapper)new WrapperPlayServerClearDialog());
                break;
            }
            default: {
                throw new IllegalArgumentException((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e80", (int)fn, (long)fo) + user.getEncoderState());
            }
        }
    }

    private void a(User user, TextComponent textComponent, List<DialogBody> list, List<Input> list2, List<ActionButton> list3, ActionButton actionButton, @Nullable \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2) {
        CommonDialogData commonDialogData = new CommonDialogData((Component)textComponent, null, fh != 0, fi != 0, DialogAction.CLOSE, list, list2);
        MultiActionDialog multiActionDialog = new MultiActionDialog(commonDialogData, list3, actionButton, fj);
        switch (\u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.M[user.getEncoderState().ordinal()]) {
            case 1: {
                user.sendPacketSilently((PacketWrapper)new WrapperConfigServerShowDialog((Dialog)multiActionDialog));
                break;
            }
            case 2: {
                user.sendPacketSilently((PacketWrapper)new WrapperPlayServerShowDialog((Dialog)multiActionDialog));
                break;
            }
            default: {
                throw new IllegalArgumentException((String)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.c("\u3e80", (int)fk, (long)fl) + user.getEncoderState());
            }
        }
        Channel channel = (Channel)user.getChannel();
        channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).set((Object)new \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4(\u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2, (byte)fm, null));
    }

    public boolean a(User user, \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2) {
        if (\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a() != \u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.c) {
            return a != 0;
        }
        if (this.v.a().p()) {
            return b != 0;
        }
        if (user.getClientVersion().isOlderThan(ClientVersion.V_1_21_6)) {
            return c != 0;
        }
        if (this.v.b().a(user).isOlderThan(ClientVersion.V_1_21_6)) {
            return d != 0;
        }
        Channel channel = (Channel)user.getChannel();
        \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2 = this.a(user, channel);
        if (\u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2 == null) {
            return e != 0;
        }
        \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2.a();
        boolean bl = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.A();
        if (!bl) {
            int n;
            if (\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.n.ar() && \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.t()) {
                return f != 0;
            }
            if (this.v.a().a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, user.getAddress().getAddress().getHostAddress()) == \u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc.d) {
                return g != 0;
            }
            \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42 = this.v.b().a();
            int n2 = n = \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2.e() || \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42 != null && \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42.a(user.getUUID()) ? h : i;
            if (\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.k.ar() && n != 0) {
                return j != 0;
            }
        }
        if (bl) {
            this.a(user, \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2.d(), \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2);
        } else {
            this.a(user, \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc2.d(), \u03b2\u03bf\u03bb\u03bc\u03c2\u03a6\u03b6\u0393\u03c8\u03b3\u03c4\u03b8\u0394\u039b.a(this.v, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92), \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2);
        }
        channel.eventLoop().schedule(() -> {
            \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4 \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42;
            block8: {
                block7: {
                    block6: {
                        try {
                            if (channel.isActive()) break block6;
                            \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2.resume(fp != 0);
                            return;
                        }
                        catch (Throwable throwable) {
                            \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2.resume(fu != 0);
                            throw throwable;
                        }
                    }
                    if (channel.hasAttr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c)) break block7;
                    \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2.resume(fq != 0);
                    return;
                }
                \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 = (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4)channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).get();
                if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 != null) break block8;
                \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2.resume(fr != 0);
                return;
            }
            if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42.a != null) {
                this.a(user);
                \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.i(user, \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(bl ? \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.ad : \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.ac, new Object[fs]));
            }
            \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2.resume(ft != 0);
        }, (long)\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.E.r(), TimeUnit.SECONDS);
        return k != 0;
    }
}

