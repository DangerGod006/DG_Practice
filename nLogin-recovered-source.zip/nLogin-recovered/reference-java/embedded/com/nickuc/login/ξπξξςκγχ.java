/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  lombok.Generated
 *  org.bukkit.plugin.java.JavaPlugin
 */
package com.nickuc.login;

import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import lombok.Generated;
import org.bukkit.plugin.java.JavaPlugin;

public class \u03be\u03c0\u03be\u03be\u03c2\u03ba\u03b3\u03c7
implements \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 {
    private final BukkitLoader b;
    private final \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a = new \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2();
    private final boolean K;

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l, long l2, TimeUnit timeUnit) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, runnable).a((JavaPlugin)this.b, l, l2, timeUnit);
    }

    @Generated
    public \u03be\u03c0\u03be\u03be\u03c2\u03ba\u03b3\u03c7(BukkitLoader bukkitLoader, boolean bl) {
        this.b = bukkitLoader;
        this.K = bl;
    }

    @Override
    public void Y() {
        \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.a((JavaPlugin)this.b);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, consumer).a((JavaPlugin)this.b);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l, TimeUnit timeUnit) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, runnable).a((JavaPlugin)this.b, l, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, long l2, TimeUnit timeUnit) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, consumer).a((JavaPlugin)this.b, l, l2, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, TimeUnit timeUnit) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, consumer).a((JavaPlugin)this.b, l, timeUnit);
    }

    @Override
    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable) {
        return new \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(this.K, this.a, runnable).a((JavaPlugin)this.b);
    }

    @Override
    public \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a() {
        return this.a;
    }
}

