/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class \u03a0\u03a8\u0393\u03b7\u03b5\u03a3\u03a8\u03a0\u03b6\u03c4\u03b2\u0394\u03ba\u03a3\u03a3 {
    private static int a = 32 >>> 165 | 32 << ~165 + 1;

    public static List<String> a(List<String> list, String[] stringArray) {
        if (stringArray.length == 0) {
            return list;
        }
        String string = stringArray[stringArray.length - a].toLowerCase(Locale.ENGLISH);
        if (string.isEmpty()) {
            return list;
        }
        return list.stream().filter(string2 -> string2.toLowerCase(Locale.ENGLISH).startsWith(string)).collect(Collectors.toList());
    }
}

