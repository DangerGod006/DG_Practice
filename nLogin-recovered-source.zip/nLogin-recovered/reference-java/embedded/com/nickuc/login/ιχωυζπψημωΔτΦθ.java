/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c4;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8 {
    private static int a = (0 >>> 238 | 0 << -238) & 0xFFFFFFFF;
    private static int c;
    private static long c;
    private static int b;
    private static long f;
    private static int j;
    private static long i;
    private static final Random a;
    private static long h;
    private static int k;
    private static int l;
    private static int e;
    private static String[] a;
    private static int g;
    private static String[] b;
    private static long d;
    private static final SecureRandom b;

    public static int a(int n) {
        return n == 0 ? a : a.nextInt(n);
    }

    public static int a(int n, int n2) {
        int n3;
        if (n == n2) {
            throw new IllegalArgumentException((String)\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.c("\u3e80", (int)(b & c), (long)d));
        }
        if (n < 0) {
            throw new IllegalArgumentException((String)\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.c("\u3e83", (int)e, (long)f));
        }
        if (n2 <= 0) {
            throw new IllegalArgumentException((String)\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.c("\u3e86", (int)g, (long)(h ^ i)));
        }
        if (n > n2) {
            n3 = n2;
            n2 = n;
            n = n3;
        }
        n3 = n2 - n;
        int n4 = \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a(n3);
        return n + n4;
    }

    public static Random a() {
        return a;
    }

    public static String a(\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c4 \u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c42, int n) {
        return \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a(\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c4.a(\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c42), n);
    }

    public static String a(char[] cArray, int n) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = j; i < n; ++i) {
            stringBuilder.append(cArray[b.nextInt(cArray.length)]);
        }
        return stringBuilder.toString();
    }

    static {
        b = 0 >>> 53 | 0 << ~53 + 1;
        c = Integer.reverse(-1);
        d = Long.reverse(-1973580661764733775L);
        e = 0x800000 >>> 23 | 0x800000 << ~23 + 1;
        f = Long.reverse(-1973580661764733775L);
        g = 4 >>> 1 | 4 << ~1 + 1;
        h = Long.reverse(8258597691621033137L);
        i = Long.reverse(-7638104968020361216L);
        j = (0 >>> 112 | 0 << -112) & 0xFFFFFFFF;
        k = Integer.reverse(-1073741824);
        l = 24576 >>> 141 | 24576 << ~141 + 1;
        a = new String[k];
        b = new String[l];
        \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b();
        a = new Random();
        b = new SecureRandom();
    }

    public static String a(String string, int n) {
        return \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a(string.toCharArray(), n);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0137\u0159\u015b\u013b\u015f\u017e\u0176\u018c\u0178\u0147\u0185\u017b\u0189\u0183\u014c\u0171\u0193\u0192\u018a\u0190\u018a\u015f", (byte)72, 65), \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0567\u0574\u0573\u0536\u0576\u0572\u056d\u0576\u0581\u0570\u053d\u057b\u057f\u0578\u057b\u0581\u0543\u08ce\u08dd\u08e0\u08dd\u08cf\u08da\u08e3\u08d3\u08d9\u08e7\u08b3\u08e4\u08c7\u08da\u055d", (byte)72, 69) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0149", (byte)72, 66) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x69L;
        l ^= 0x3A027656B64DFD62L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(55 + 14), (byte)(31 + 52), (byte)(18 + 29), (byte)(56 + 11), (byte)(55 + 11), (byte)(26 + 41), 47, (byte)(74 + 6), (byte)(56 + 19), (byte)(7 + 60), (byte)(67 + 16), 53, (byte)(60 + 20), (byte)(34 + 63), (byte)(91 + 9), (byte)(94 + 6), (byte)(23 + 82), (byte)(88 + 22), (byte)(30 + 73)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(7 + 62), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u04ea\u04f7\u04f6\u04b9\u04f9\u04f5\u04f0\u04f9\u0504\u04f3\u04c0\u04fe\u0502\u04fb\u04fe\u0504\u04c6\u0851\u0860\u0863\u0860\u0852\u085d\u0866\u0856\u085c\u086a\u0836\u0867\u084a\u085d", (byte)70, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -8276639834220119730L;
        long l = c ^ 0x3A027656B64DFD62L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(19 + 50), (byte)(41 + 42), (byte)(6 + 41), (byte)(22 + 45), (byte)(16 + 50), (byte)(65 + 2), (byte)(2 + 45), (byte)(37 + 43), (byte)(18 + 57), (byte)(53 + 14), 83, 53, (byte)(10 + 70), (byte)(74 + 23), (byte)(74 + 26), (byte)(10 + 90), (byte)(94 + 11), (byte)(63 + 47), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(4 + 65), (byte)(20 + 63)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0130\u0152\u0155\u0153\u0132\u0123\u0124\u0169\u015e\u0164\u014d\u016d\u012c\u012f\u0166\u0171\u0163\u0149\u0141\u0148\u0162\u0145\u014d\u0144\u016d\u0173\u014b\u017d\u015a\u017b\u014f\u014e\u015f\u0161\u0175\u015a\u0180\u0179\u0141\u0159\u017f\u0187\u0149\u0153", (byte)54, 66);
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u04cf\u0490\u04a8\u04bf\u04c5\u0490\u04c3\u04c4\u04d7\u04b1\u0492\u04d4\u04ae\u049c\u0499\u04a7\u04b6\u04b3\u049e\u04d4\u04de\u049d\u04d2\u04ba\u04b5\u04b2\u04c5\u04de\u04ac\u04c6\u04ac\u04e7\u04cc\u04c6\u04ce\u04f0\u04cd\u04e6\u04ec\u04b2\u04ef\u04d0\u04c2\u04bf", (byte)54, 67);
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0123\u0137\u0147\u0143\u0133\u0127\u0140\u0121\u0144\u0145\u014a\u0169\u016f\u0149\u015a\u013c\u014d\u0132\u012f\u0160\u016f\u014e\u0132\u016d\u014e\u0165\u0174\u0156\u0139\u014b\u0160\u017b\u013a\u0157\u0171\u0182\u017d\u0151\u0187\u0156\u0175\u0183\u0149\u0153", (byte)54, 65);
                    continue block7;
                }
                case 1: {
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0130\u0152\u0155\u0153\u0132\u0123\u0124\u0169\u015e\u0164\u014d\u016d\u012c\u012f\u0166\u0171\u0163\u0149\u0141\u0148\u0162\u0145\u014d\u0144\u016d\u0173\u014b\u017d\u015a\u017b\u014f\u014e\u017e\u017f\u013f\u017d\u0177\u015b\u0161\u0166\u014a\u017e\u015a\u017c\u0162\u017f\u016f\u0167\u015f\u0167\u0148\u0169\u0173\u0171\u015e\u015f", (byte)54, 66);
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u056a\u052b\u0543\u055a\u0560\u052b\u055e\u055f\u0572\u054c\u052d\u056f\u0549\u0537\u0534\u0542\u0551\u054e\u0539\u056f\u0579\u0538\u056d\u0555\u0550\u054d\u0560\u0579\u0547\u0561\u0547\u0582\u057c\u0560\u0559\u0549\u058c\u0591\u0587\u054d\u058d\u055e\u0567\u0581\u0587\u058c\u058e\u058b\u0567\u0567\u057b\u0590\u0576\u059e\u0565\u0566", (byte)54, 70);
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0123\u0137\u0147\u0143\u0133\u0127\u0140\u0121\u0144\u0145\u014a\u0169\u016f\u0149\u015a\u013c\u014d\u0132\u012f\u0160\u016f\u014e\u0132\u016d\u014e\u0165\u0174\u0156\u0139\u014b\u0160\u017b\u0144\u015b\u0152\u013f\u0153\u0160\u0178\u0161\u0169\u016e\u0145\u0153", (byte)54, 66);
                    continue block7;
                }
                case 2: {
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0529\u0564\u051f\u0563\u052b\u0559\u054a\u052d\u0549\u0572\u0565\u0575\u0551\u052e\u0545\u0574\u0565\u055b\u0568\u0550\u0573\u0558\u0545\u0546", (byte)54, 69);
                    continue block7;
                }
                case 4: {
                    \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04ab\u0487\u04a5\u04c3\u049d\u04be\u04c8\u04a5\u048a\u04a2\u04ba\u049f", (byte)54, 67);
                }
            }
        }
    }
}

