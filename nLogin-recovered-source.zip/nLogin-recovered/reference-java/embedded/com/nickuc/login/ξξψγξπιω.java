/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitTask
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9
implements \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be {
    private static long i;
    private final Runnable b;
    private static int a;
    private static int e;
    private static int f;
    private static int q;
    private static long n;
    private static long o;
    private static long c;
    private static int b;
    private static long m;
    private static long l;
    private final boolean L;
    private static String[] a;
    private static long h;
    private static int j;
    private final String an;
    private static int r;
    private static long d;
    private static long g;
    private BukkitTask a;
    private static String[] b;
    private static int c;
    private static long k;
    private boolean M;
    private static int p;

    @Override
    public String t() {
        return this.an;
    }

    public \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9 a(JavaPlugin javaPlugin, long l, long l2, TimeUnit timeUnit) {
        if (javaPlugin.isEnabled()) {
            if (this.a != null) {
                throw new IllegalStateException((String)\u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.c("\u3e80", (int)j, (long)k));
            }
            this.a = this.L ? javaPlugin.getServer().getScheduler().runTaskTimerAsynchronously((Plugin)javaPlugin, this.b, timeUnit.toMillis(l) / \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.l, timeUnit.toMillis(l2) / m) : javaPlugin.getServer().getScheduler().runTaskTimer((Plugin)javaPlugin, this.b, timeUnit.toMillis(l) / n, timeUnit.toMillis(l2) / o);
        }
        return this;
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    public \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9 a(JavaPlugin javaPlugin, long l, TimeUnit timeUnit) {
        if (javaPlugin.isEnabled()) {
            if (this.a != null) {
                throw new IllegalStateException((String)\u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.c("\u3e80", (int)(e & f), (long)g));
            }
            this.a = this.L ? javaPlugin.getServer().getScheduler().runTaskLaterAsynchronously((Plugin)javaPlugin, this.b, timeUnit.toMillis(l) / h) : javaPlugin.getServer().getScheduler().runTaskLater((Plugin)javaPlugin, this.b, timeUnit.toMillis(l) / i);
        }
        return this;
    }

    static {
        a = Integer.reverse(0x40000000);
        b = Integer.reverse(0x40000000);
        c = (0 >>> 106 | 0 << ~106 + 1) & 0xFFFFFFFF;
        d = Long.reverse(2877153550704712099L);
        e = (16384 >>> 14 | 16384 << ~14 + 1) & 0xFFFFFFFF;
        f = Integer.reverse(-1);
        g = Long.reverse(2877153550704712099L);
        h = Long.reverse(0x4C00000000000000L);
        i = Long.reverse(0x4C00000000000000L);
        j = Integer.reverse(0x40000000);
        k = Long.reverse(2877153550704712099L);
        l = Long.reverse(0x4C00000000000000L);
        m = Long.reverse(0x4C00000000000000L);
        n = Long.reverse(0x4C00000000000000L);
        o = Long.reverse(0x4C00000000000000L);
        p = Integer.reverse(Integer.MIN_VALUE);
        q = 48 >>> 100 | 48 << -100;
        r = (786432 >>> 146 | 786432 << ~146 + 1) & 0xFFFFFFFF;
        a = new String[q];
        b = new String[r];
        \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b();
    }

    public \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9 a(JavaPlugin javaPlugin) {
        if (javaPlugin.isEnabled()) {
            if (this.a != null) {
                throw new IllegalStateException((String)\u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.c("\u3e80", (int)c, (long)d));
            }
            this.a = this.L ? javaPlugin.getServer().getScheduler().runTaskAsynchronously((Plugin)javaPlugin, this.b) : javaPlugin.getServer().getScheduler().runTask((Plugin)javaPlugin, this.b);
        }
        return this;
    }

    private static void b() {
        int n;
        c = -4208543102529587245L;
        long l = c ^ 0xE77A6ACDA0D067A3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(26 + 43), (byte)(11 + 72), (byte)(17 + 30), (byte)(29 + 38), (byte)(38 + 28), (byte)(36 + 31), 47, (byte)(37 + 43), (byte)(30 + 45), (byte)(6 + 61), (byte)(11 + 72), (byte)(21 + 32), 80, (byte)(17 + 80), (byte)(41 + 59), (byte)(7 + 93), (byte)(95 + 10), (byte)(69 + 41), (byte)(93 + 10)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(36 + 32), 69, (byte)(28 + 55)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0529\u04fa\u0536\u052e\u0517\u0534\u052f\u04f9\u0516\u0545\u0522\u0514\u0527\u0533\u0542\u0507\u051a\u0502\u0517\u052d\u053a\u0529\u050d\u054a\u0549\u051f\u0507\u054b\u0526\u0543\u0545\u054f", (byte)6, 69);
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u00f2\u00c3\u00ff\u00f7\u00e0\u00fd\u00f8\u00c2\u00df\u010e\u00eb\u00dd\u00f0\u00fc\u010b\u00d0\u00e3\u00cb\u00e0\u00f6\u0103\u00f2\u00d6\u0113\u0112\u00e8\u00d0\u0114\u00ef\u010c\u010e\u0118", (byte)6, 65);
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0529\u04fa\u0536\u052e\u0517\u0534\u052f\u04f9\u0516\u0545\u0522\u0514\u0527\u0533\u0542\u0507\u051a\u0502\u0517\u052d\u053a\u0529\u050d\u054a\u0549\u051f\u0507\u054b\u0526\u0543\u0545\u054f", (byte)6, 70);
                    continue block7;
                }
                case 1: {
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u00f2\u00c3\u00ff\u00f7\u00e0\u00fd\u00f8\u00c2\u00df\u010e\u00eb\u00dd\u00f0\u00fc\u010b\u00d0\u00e3\u00cb\u00e0\u00f6\u0103\u00f4\u00e8\u010d\u00d2\u00fd\u0109\u010b\u00d2\u0122\u0103\u00ef", (byte)6, 66);
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u042e\u03ff\u043b\u0433\u041c\u0439\u0434\u03fe\u041b\u044a\u0427\u0419\u042c\u0438\u0447\u040c\u041f\u0407\u041c\u0432\u043f\u0435\u0442\u0424\u0441\u0413\u0424\u0431\u0416\u044e\u043e\u045f", (byte)6, 67);
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u042e\u03ff\u043b\u0433\u041c\u0439\u0434\u03fe\u041b\u044a\u0427\u0419\u042c\u0438\u0447\u040c\u041f\u0407\u041c\u0432\u043f\u0431\u044c\u0417\u0450\u0452\u0427\u0415\u0419\u0425\u0451\u0436", (byte)6, 67);
                    continue block7;
                }
                case 2: {
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0528\u0506\u0529\u051e\u0512\u0537\u0518\u052e\u0531\u0502\u0524\u0542\u0505\u0533\u053b\u0521\u052c\u0504\u051f\u0523\u0517\u053b\u054c\u052f\u050f\u0506\u0556\u052c\u0532\u0537\u0528\u0545", (byte)6, 70);
                    continue block7;
                }
                case 4: {
                    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u041a\u042e\u0431\u0439\u040d\u043a\u03ff\u0401\u0439\u041d\u041a\u0401\u0423\u0439\u044b\u0405\u0420\u042b\u043c\u0445\u0444\u041d\u041a\u041b", (byte)6, 68);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u03e9\u040b\u040d\u03ed\u0411\u0430\u0428\u043e\u042a\u03f9\u0437\u042d\u043b\u0435\u03fe\u0423\u0445\u0444\u043c\u0442\u043c\u0411", (byte)4, 68), \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0424\u0431\u0430\u03f3\u0433\u042f\u042a\u0433\u043e\u042d\u03fa\u0438\u043c\u0435\u0438\u043e\u0400\u0790\u0791\u079c\u0788\u0794\u0797\u0791\u07a2\u0414", (byte)4, 68) + string + \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u00c1", (byte)4, 65) + methodType.toString(), exception);
        }
    }

    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(boolean bl, \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22, Runnable runnable) {
        this.an = new Exception().getStackTrace()[a].toString();
        this.L = bl;
        this.b = () -> {
            try {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.b(this);
                runnable.run();
            }
            finally {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.c(this);
            }
        };
    }

    static void a(JavaPlugin javaPlugin) {
        javaPlugin.getServer().getScheduler().cancelTasks((Plugin)javaPlugin);
    }

    private static String a(int n, long l) {
        l ^= 0x37L;
        l ^= 0xE77A6ACDA0D067A3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), 69, (byte)(79 + 4), (byte)(30 + 17), (byte)(54 + 13), (byte)(61 + 5), (byte)(44 + 23), (byte)(8 + 39), (byte)(11 + 69), (byte)(29 + 46), (byte)(21 + 46), (byte)(75 + 8), (byte)(42 + 11), (byte)(65 + 15), (byte)(32 + 65), (byte)(76 + 24), (byte)(14 + 86), (byte)(98 + 7), 110, (byte)(23 + 80)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(45 + 23), 69, (byte)(18 + 65)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u046f\u047c\u047b\u043e\u047e\u047a\u0475\u047e\u0489\u0478\u0445\u0483\u0487\u0480\u0483\u0489\u044b\u07db\u07dc\u07e7\u07d3\u07df\u07e2\u07dc\u07ed", (byte)29, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public boolean P() {
        return this.M;
    }

    \u03be\u03be\u03c8\u03b3\u03be\u03c0\u03b9\u03c9(boolean bl, \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22, Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        this.an = new Exception().getStackTrace()[b].toString();
        this.L = bl;
        this.b = () -> {
            try {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.b(this);
                consumer.accept(this);
            }
            finally {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.c(this);
            }
        };
    }

    @Override
    public void Z() {
        if (this.a != null) {
            this.a.cancel();
        }
        this.M = p;
    }
}

