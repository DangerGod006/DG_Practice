/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4
extends \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private static final Set<String> d;
    private static int i;
    private static int c;
    private static int q;
    private static int f;
    private static int l;
    private static int k;
    private static String[] b;
    private static long e;
    private static long h;
    private static int n;
    private static long o;
    private static int p;
    private static int d;
    private static String[] a;
    private static int z;
    private static long y;
    private static int aa;
    private static long c;
    private static long t;
    private static long u;
    private static int r;
    private static int v;
    private static long g;
    private static int j;
    private static int x;
    private static int s;
    private static int m;
    private static int w;

    private static String a(int n, long l) {
        l ^= 6L;
        l ^= 0xEDDD55F1BD766B18L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(62 + 7), (byte)(14 + 69), 47, (byte)(33 + 34), (byte)(27 + 39), (byte)(13 + 54), (byte)(41 + 6), (byte)(48 + 32), (byte)(31 + 44), (byte)(33 + 34), (byte)(14 + 69), (byte)(13 + 40), 80, (byte)(19 + 78), (byte)(13 + 87), (byte)(17 + 83), (byte)(3 + 102), (byte)(21 + 89), (byte)(84 + 19)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(4 + 64), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u011c\u0129\u0128\u00eb\u012b\u0127\u0122\u012b\u0136\u0125\u00f2\u0130\u0134\u012d\u0130\u0136\u00f8\u0480\u048c\u0493\u0485\u048c\u0484\u0478\u0499\u048c\u0487", (byte)29, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        if (!(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.z, new Object[l]);
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2;
        if (d.remove(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName())) {
            \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, (String)\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.c("\u3e80", (int)(m & n), (long)o), new Object[p]);
            return;
        }
        d.add(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName());
        new \u03c2\u03c6\u0393\u03b7\u03a8\u0393\u03b4\u039b\u03c0\u03b1\u03b8\u03a8\u03b7((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, (stringArray.length > q && stringArray[r].equalsIgnoreCase((String)\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.c("\u3e83", (int)s, (long)(t ^ u))) ? v : w) != 0);
        \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.o((String)\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.c("\u3e86", (int)x, (long)y));
    }

    public \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, (String)\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.c("\u3e80", (int)(c & d), (long)e), (String)\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.c("\u3e83", (int)f, (long)(g ^ h)), i != 0, j != 0, new String[k]);
    }

    private static void b() {
        int n;
        c = -1885345553393656576L;
        long l = c ^ 0xEDDD55F1BD766B18L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), 69, (byte)(7 + 76), (byte)(4 + 43), 67, (byte)(38 + 28), (byte)(59 + 8), (byte)(13 + 34), (byte)(54 + 26), (byte)(58 + 17), (byte)(5 + 62), (byte)(17 + 66), (byte)(43 + 10), (byte)(46 + 34), (byte)(63 + 34), (byte)(22 + 78), (byte)(92 + 8), (byte)(36 + 69), (byte)(59 + 51), (byte)(98 + 5)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(5 + 63), (byte)(28 + 41), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0568\u0564\u0587\u056e\u0553\u058f\u058f\u0568\u0583\u058b\u0570\u0561", (byte)93, 69);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0183\u01b4\u01a0\u017f\u01a7\u01a9\u0187\u0196\u018a\u01b8\u01a8\u018d\u01bb\u01a0\u017c\u019b\u01ba\u01b5\u01c1\u019c\u0190\u018f\u018c\u018d", (byte)93, 66);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u055e\u0593\u057e\u058e\u0590\u056f\u0574\u0582\u0592\u0573\u0570\u0573\u0575\u056b\u0581\u0572\u0583\u0563\u0585\u058e\u0575\u059b\u0576\u0582\u0588\u057d\u0566\u05a5\u059d\u0598\u056b\u0571\u056b\u05b3\u0590\u05a6\u05b1\u05a2\u0597\u05a4\u0578\u0592\u05aa\u0581", (byte)93, 69);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u052f\u051e\u0515\u0523\u0515\u0526\u0508\u050b\u0546\u0529\u052f\u0514", (byte)93, 68);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u053c\u0518\u0541\u0533\u0518\u0515\u0517\u0547\u0523\u0541\u052d\u050f\u0547\u0540\u053e\u0554\u0522\u0535\u0554\u0535\u053a\u052d\u054d\u052e\u0539\u055c\u051f\u0556\u051a\u052c\u051e\u052f\u0545\u0543\u051f\u055b\u0535\u0566\u052b\u055d\u0541\u0548\u0537\u0534", (byte)93, 68);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u057a\u0565\u0562\u054f\u0595\u058a\u0563\u0595\u0599\u0568\u058d\u0590\u0550\u0551\u0579\u057d\u0582\u05a2\u059d\u057d\u0592\u057f\u056c\u056d", (byte)93, 69);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0563\u0594\u0580\u055f\u0587\u0589\u0567\u0576\u056a\u0598\u0589\u0579\u056e\u056e\u057a\u0577\u0570\u0562\u0579\u055d\u0574\u057f\u056c\u056d", (byte)93, 70);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[2] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0511\u0546\u0531\u0541\u0543\u0522\u0527\u0535\u0545\u0526\u0523\u0526\u0528\u051e\u0534\u0525\u0536\u0516\u0538\u0541\u0528\u054e\u0529\u0535\u053b\u0530\u0519\u0558\u0550\u054b\u051e\u0524\u0541\u053b\u0553\u0553\u0523\u055c\u0527\u0526\u0542\u052e\u052b\u0539\u056d\u056a\u0560\u053d\u054b\u0573\u0570\u0575\u054f\u0552\u053f\u0540", (byte)93, 68);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u018e\u018c\u016a\u0172\u0176\u01a6\u0178\u01b3\u0185\u0187\u0198\u017c\u0188\u01af\u01bf\u0193\u01b6\u017b\u019d\u01bd\u01b9\u019f\u018c\u018d", (byte)93, 65);
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0589\u0565\u058e\u0580\u0565\u0562\u0564\u0594\u0570\u058e\u057a\u055c\u0594\u058d\u058b\u05a1\u056f\u0582\u05a1\u0582\u0587\u057a\u059a\u057b\u0586\u05a9\u056c\u05a3\u0567\u0579\u056b\u057c\u05b3\u0572\u058d\u056f\u0588\u05b8\u058f\u0589\u0572\u0589\u05a5\u057a\u059c\u059b\u0589\u058e\u05bf\u057a\u0597\u05a2\u05a4\u05b5\u058c\u058d", (byte)93, 69);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u053d\u053c\u0515\u04ff\u0535\u051d\u0547\u053c\u0503\u0536\u052f\u050f\u050f\u050e\u0529\u0520\u0555\u0543\u0555\u0559\u0548\u0558\u051f\u0520", (byte)93, 68);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u0572\u058c\u0564\u0569\u0575\u058e\u058a\u0565\u0590\u0575\u058a\u0561", (byte)93, 69);
                }
            }
        }
    }

    static {
        c = Integer.reverse(0);
        d = Integer.reverse(-1);
        e = Long.reverse(6970403247627938727L);
        f = (0x4000000 >>> 250 | 0x4000000 << -250) & 0xFFFFFFFF;
        g = Long.reverse(52874219986856871L);
        h = Long.reverse(0x6000000000000000L);
        i = (0 >>> 151 | 0 << ~151 + 1) & 0xFFFFFFFF;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = 0 >>> 64 | 0 << -64;
        l = 0 >>> 217 | 0 << ~217 + 1;
        m = 4096 >>> 107 | 4096 << ~107 + 1;
        n = (-1 >>> 55 | -1 << -55) & 0xFFFFFFFF;
        o = Long.reverse(6970403247627938727L);
        p = Integer.reverse(0);
        q = Integer.reverse(Integer.MIN_VALUE);
        r = (0x20000000 >>> 157 | 0x20000000 << ~157 + 1) & 0xFFFFFFFF;
        s = 0x300000 >>> 180 | 0x300000 << -180;
        t = Long.reverse(52874219986856871L);
        u = Long.reverse(0x6000000000000000L);
        v = Integer.reverse(Integer.MIN_VALUE);
        w = (0 >>> 49 | 0 << ~49 + 1) & 0xFFFFFFFF;
        x = Integer.reverse(0x20000000);
        y = Long.reverse(6970403247627938727L);
        z = Integer.reverse(-1610612736);
        aa = Integer.reverse(-1610612736);
        a = new String[z];
        b = new String[aa];
        \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.b();
        d = new HashSet<String>();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0503\u0525\u0527\u0507\u052b\u054a\u0542\u0558\u0544\u0513\u0551\u0547\u0555\u054f\u0518\u053d\u055f\u055e\u0556\u055c\u0556\u052b", (byte)98, 67), \u03b6\u03c1\u03c7\u03b8\u03be\u03b5\u03a8\u03c8\u03ba\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0581\u058e\u058d\u0550\u0590\u058c\u0587\u0590\u059b\u058a\u0557\u0595\u0599\u0592\u0595\u059b\u055d\u08e5\u08f1\u08f8\u08ea\u08f1\u08e9\u08dd\u08fe\u08f1\u08ec\u0573", (byte)98, 69) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u017d", (byte)98, 65) + methodType.toString(), exception);
        }
    }

    static /* synthetic */ Set b() {
        return d;
    }
}

