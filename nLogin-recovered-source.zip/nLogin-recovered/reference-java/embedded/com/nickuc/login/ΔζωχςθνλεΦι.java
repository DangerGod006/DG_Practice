/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6;

public interface \u0394\u03b6\u03c9\u03c7\u03c2\u03b8\u03bd\u03bb\u03b5\u03a6\u03b9
extends \u03bb\u03c1\u03b6\u03b7\u0393\u03b6\u03c2\u03c6\u03b6 {
}

