/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.nLoginAPI
 *  lombok.Generated
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package com.nickuc.login;

import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.tasks.LoginMainQueueTask;
import com.nickuc.login.\u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03b5\u0394\u03c7\u03c7\u03a8\u03c0\u03be\u03be;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b3\u03a6\u03c2\u03b8\u03b4\u03c8\u03b5\u03b3\u03c9\u03a9\u03c7\u03c9\u03ba\u03c4\u03be;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b9\u03a0\u03b4\u03c6\u03bc\u03b7\u03c9\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c6\u03a3\u03bd\u03ba\u03b2\u03ba\u03ba\u03b5\u0393\u03c2;
import com.nickuc.login.\u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u0394;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc
implements \u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8 {
    private static long g;
    private static int x;
    private static int o;
    private static long s;
    private static int h;
    private static int c;
    private static int i;
    private static int v;
    private static String[] a;
    private static long m;
    private static long n;
    private static int t;
    private static long j;
    private static int a;
    private static int k;
    private static long u;
    private static int l;
    private static int b;
    private static int e;
    private final nLoginBukkit b;
    private static int f;
    private static String[] b;
    private static long c;
    private static long p;
    private static int r;
    private static int w;
    private static long q;
    private static int y;
    private static long d;

    private void d() {
        PluginManager pluginManager = this.b.a().getPluginManager();
        Plugin plugin = pluginManager.getPlugin((String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e80", (int)l, (long)(m ^ n)));
        if (plugin != null) {
            pluginManager.disablePlugin(plugin);
            File file = new File(this.b.c().getParentFile(), (String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e83", (int)o, (long)(p ^ q)));
            if (file.exists() && !file.delete()) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e86", (int)r, (long)s) + file.getPath() + (String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e89", (int)t, (long)u), new Object[v]);
            }
        }
    }

    @Override
    public nLoginAPI a() {
        return new \u03c7\u03c7\u03bd\u03c1\u03c8\u0394\u03c2\u0393\u03a6\u03c6\u039b\u0394(this.b.a());
    }

    @Override
    public boolean a() {
        return \u03c2\u03b9\u03a0\u03b4\u03c6\u03bc\u03b7\u03c9\u03b7.e(this.b.a());
    }

    @Override
    public \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 a() {
        return new \u03c6\u03a3\u03bd\u03ba\u03b2\u03ba\u03ba\u03b5\u0393\u03c2(this.b);
    }

    private static Object f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u052f\u0551\u0553\u0533\u0557\u0576\u056e\u0584\u0570\u053f\u057d\u0573\u0581\u057b\u0544\u0569\u058b\u058a\u0582\u0588\u0582\u0557", (byte)75, 69), \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u056a\u0577\u0576\u0539\u0579\u0575\u0570\u0579\u0584\u0573\u0540\u057e\u0582\u057b\u057e\u0584\u0546\u08ca\u08cf\u08cf\u08dc\u08d3\u08c0\u08dd\u08da\u08e3\u08d2\u08de\u055d", (byte)75, 69) + string + \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u014f", (byte)75, 66) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(0);
        c = Integer.reverse(-1);
        d = Long.reverse(8062913391167826205L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (-1 >>> 140 | -1 << ~140 + 1) & 0xFFFFFFFF;
        g = Long.reverse(8062913391167826205L);
        h = Integer.MIN_VALUE >>> 158 | Integer.MIN_VALUE << -158;
        i = Integer.reverse(-1);
        j = Long.reverse(8062913391167826205L);
        k = (0 >>> 136 | 0 << -136) & 0xFFFFFFFF;
        l = Integer.reverse(-1073741824);
        m = Long.reverse(-4763338347583346403L);
        n = Long.reverse(-3314649325744685056L);
        o = 2048 >>> 137 | 2048 << -137;
        p = Long.reverse(-4763338347583346403L);
        q = Long.reverse(-3314649325744685056L);
        r = (5120 >>> 202 | 5120 << -202) & 0xFFFFFFFF;
        s = Long.reverse(8062913391167826205L);
        t = (24576 >>> 12 | 24576 << ~12 + 1) & 0xFFFFFFFF;
        u = Long.reverse(8062913391167826205L);
        v = Integer.reverse(0);
        w = 0 >>> 127 | 0 << ~127 + 1;
        x = 28 >>> 66 | 28 << ~66 + 1;
        y = (7168 >>> 74 | 7168 << ~74 + 1) & 0xFFFFFFFF;
        a = new String[x];
        b = new String[y];
        \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.e();
    }

    @Generated
    public \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc(nLoginBukkit nLoginBukkit2) {
        this.b = nLoginBukkit2;
    }

    private static String a(int n, long l) {
        l ^= 0x4BL;
        l ^= 0xCDEC9E8C24994E56L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(9 + 60), (byte)(51 + 32), (byte)(15 + 32), (byte)(38 + 29), 66, (byte)(11 + 56), (byte)(36 + 11), (byte)(49 + 31), (byte)(44 + 31), (byte)(11 + 56), (byte)(62 + 21), 53, (byte)(35 + 45), (byte)(70 + 27), (byte)(61 + 39), (byte)(26 + 74), (byte)(17 + 88), (byte)(20 + 90), (byte)(48 + 55)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(69 + 14)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0182\u018f\u018e\u0151\u0191\u018d\u0188\u0191\u019c\u018b\u0158\u0196\u019a\u0193\u0196\u019c\u015e\u04e2\u04e7\u04e7\u04f4\u04eb\u04d8\u04f5\u04f2\u04fb\u04ea\u04f6", (byte)80, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public \u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0 a() {
        return new \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.b.b(), this.b, k != 0);
    }

    @Override
    public \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 a() {
        return new \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393(this.b);
    }

    @Override
    public void c() {
    }

    @Override
    public void b() {
        \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 = this.b.a();
        this.b.b().c().forEach(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 -> \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.p, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[w])));
        \u03b3\u03a6\u03c2\u03b8\u03b4\u03c8\u03b5\u03b3\u03c9\u03a9\u03c7\u03c9\u03ba\u03c4\u03be.a(this.b, a != 0);
        \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a9 \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a();
        \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92.r();
        \u03a6\u03b5\u0394\u03c7\u03c7\u03a8\u03c0\u03be\u03be.a(((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)this.b.b()).a(), \u03b8\u03b9\u03bf\u03c4\u03c7\u03c0\u03c3\u03a6\u03a92);
        LoginMainQueueTask.p(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        this.b.b().c().forEach(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 -> \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b().a().c((\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().b((\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)));
        \u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4.b(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.a.b(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        \u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b \u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b2 = this.b.a().a();
        \u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b2.a((String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e80", (int)(b & c), (long)d), \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a());
        \u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b2.a((String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e83", (int)(e & f), (long)g), \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.aC());
        \u03b5\u03a9\u03c4\u03b3\u0394\u03c4\u03a8\u03ba\u03b7\u03b3\u03c0\u03a3\u03be\u03b8\u039b2.a((String)\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.f("\u3e86", (int)(h & i), (long)j), \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.b().name().toLowerCase(Locale.ENGLISH));
        this.d();
    }

    private static void e() {
        int n;
        c = -5145869546831435843L;
        long l = c ^ 0xCDEC9E8C24994E56L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(14 + 54), (byte)(24 + 45), 83, (byte)(33 + 14), (byte)(58 + 9), (byte)(8 + 58), 67, (byte)(23 + 24), (byte)(31 + 49), (byte)(58 + 17), (byte)(57 + 10), (byte)(59 + 24), (byte)(3 + 50), (byte)(31 + 49), (byte)(60 + 37), (byte)(97 + 3), (byte)(89 + 11), (byte)(20 + 85), (byte)(90 + 20), (byte)(38 + 65)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(41 + 27), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u00c2\u00fb\u00ca\u00fc\u00ff\u00fc\u00e7\u00da\u00c7\u00ed\u00ea\u010a\u00ed\u00c7\u00cc\u0117\u0106\u0101\u0109\u00e4\u00f9\u00f5\u00e2\u00e3", (byte)8, 65);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0431\u0436\u0425\u0402\u041b\u0424\u043b\u0407\u0444\u0425\u0450\u0428\u041e\u0422\u0412\u043f\u0431\u042b\u0438\u0423\u0452\u0433\u0420\u0421", (byte)8, 68);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u00c4\u00d2\u00f2\u00dc\u0105\u00ed\u00d9\u00de\u00fe\u00c8\u00ec\u0109\u010b\u00e3\u0108\u0103\u0106\u00d6\u00fb\u00e8\u00ef\u00f5\u00e2\u00e3", (byte)8, 66);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0402\u0422\u0426\u0440\u0439\u0421\u044b\u0420\u0449\u0419\u0428\u0411\u044c\u040d\u0430\u0432\u0444\u0414\u0447\u0459\u0451\u0459\u0420\u0421", (byte)8, 68);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u053d\u04f6\u050a\u050e\u052d\u0530\u0544\u0535\u050f\u051c\u053e\u0526\u0505\u04fc\u052c\u0522\u0546\u0537\u053c\u0521\u0542\u052a\u0517\u0518", (byte)8, 70);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0506\u053c\u0528\u051d\u053f\u0512\u0502\u0542\u0514\u053f\u0520\u051a\u0520\u051a\u0549\u0546\u051b\u0544\u0505\u052d\u0543\u051d\u050a\u052f\u0547\u050f\u0553\u0547\u0514\u054d\u0558\u0539", (byte)8, 70);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0401\u0401\u0404\u0446\u040a\u0436\u0426\u044a\u0441\u0418\u0420\u0415", (byte)8, 67);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u00c2\u00fb\u00ca\u00fc\u00ff\u00fc\u00e7\u00da\u00c7\u00ed\u00ec\u0114\u00ca\u00e6\u00d6\u00e5\u00ea\u00cf\u00f4\u010a\u00db\u00d5\u00eb\u0116\u011d\u0122\u00fc\u00f1\u00ee\u0113\u0110\u0120", (byte)8, 66);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0528\u052d\u051c\u04f9\u0512\u051b\u0532\u04fe\u053b\u051c\u0547\u0522\u051b\u054a\u051e\u0544\u0523\u0508\u054d\u052a\u050a\u051a\u0517\u0518", (byte)8, 70);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[2] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0402\u0410\u0430\u041a\u0443\u042b\u0417\u041c\u043c\u0406\u042a\u0430\u041e\u041e\u042d\u044c\u0440\u0433\u042a\u0435\u044d\u042d\u042e\u0434\u0433\u0455\u0430\u045d\u0437\u044e\u0457\u0433", (byte)8, 68);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[3] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u00c4\u00e4\u00e8\u0102\u00fb\u00e3\u010d\u00e2\u010b\u00db\u00ec\u00fe\u00e7\u00ec\u0100\u00ea\u00f1\u00e5\u010e\u00eb\u0106\u0110\u0117\u00db\u011e\u00f8\u0113\u00ec\u00ef\u0124\u0110\u00e6", (byte)8, 66);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0446\u03ff\u0413\u0417\u0436\u0439\u044d\u043e\u0418\u0425\u0446\u043a\u0412\u0429\u040c\u0448\u0448\u0417\u0451\u0430\u0442\u0459\u0420\u0421", (byte)8, 68);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[5] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u00d1\u0107\u00f3\u00e8\u010a\u00dd\u00cd\u010d\u00df\u010a\u00eb\u00e5\u00eb\u00e5\u0114\u0111\u00e6\u010f\u00d0\u00f8\u010e\u00ed\u010b\u011f\u00fa\u00f5\u00eb\u00ed\u00ff\u00fd\u0103\u0105", (byte)8, 65);
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[6] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u00e2\u010a\u00f8\u00d5\u00d9\u00fa\u00ee\u010c\u00e5\u00ed\u00e0\u00fb\u0114\u00f1\u00f1\u00e7\u00eb\u00d4\u0116\u00fa\u00f6\u00f5\u00e2\u00e3", (byte)8, 65);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0417\u041b\u0433\u0447\u042a\u0447\u044c\u0447\u041e\u0418\u0418\u0408\u0452\u042c\u0454\u0427\u0416\u042c\u0433\u0443\u044f\u0459\u0420\u0421", (byte)8, 67);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u04f9\u0512\u0509\u0531\u0516\u050b\u0512\u053f\u0504\u0530\u0528\u04fe\u0525\u051b\u050b\u050a\u04ff\u0516\u054d\u0543\u054b\u0550\u0517\u0518", (byte)8, 69);
                }
            }
        }
    }
}

