/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5
extends \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394 {
    private static long s;
    private static long ac;
    private static int ax;
    private static int f;
    private static String[] g;
    private static long ba;
    private static String[] h;
    private static int al;
    private static int bc;
    private static long aq;
    private static int be;
    private static long ad;
    private static long az;
    private static long ar;

    public \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.E, (String)\u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.c("\u3e80", (int)f, (long)(ac ^ ad)), (String)\u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.c("\u3e83", (int)al, (long)(aq ^ ar)), (String)\u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.c("\u3e86", (int)ax, (long)(az ^ ba)), null);
    }

    private static String a(int n, long l) {
        l ^= 0x11L;
        l ^= 0x4AF4BBA4C402A631L;
        if (g[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(15 + 54), (byte)(35 + 48), (byte)(40 + 7), (byte)(52 + 15), (byte)(48 + 18), (byte)(38 + 29), 47, (byte)(69 + 11), (byte)(30 + 45), (byte)(28 + 39), (byte)(33 + 50), (byte)(27 + 26), (byte)(61 + 19), (byte)(8 + 89), (byte)(84 + 16), 100, (byte)(47 + 58), (byte)(18 + 92), (byte)(94 + 9)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(60 + 8), (byte)(11 + 58), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0562\u056f\u056e\u0531\u0571\u056d\u0568\u0571\u057c\u056b\u0538\u0576\u057a\u0573\u0576\u057c\u053e\u08b0\u08b4\u08b5\u08c6\u08ce\u08be\u08d1\u08cc", (byte)67, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.g[n] = new String(cipher.doFinal(Base64.getDecoder().decode(h[n])), StandardCharsets.UTF_8);
        }
        return g[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u019b\u01bd\u01bf\u019f\u01c3\u01e2\u01da\u01f0\u01dc\u01ab\u01e9\u01df\u01ed\u01e7\u01b0\u01d5\u01f7\u01f6\u01ee\u01f4\u01ee\u01c3", (byte)122, 66), \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0599\u05a6\u05a5\u0568\u05a8\u05a4\u059f\u05a8\u05b3\u05a2\u056f\u05ad\u05b1\u05aa\u05ad\u05b3\u0575\u08e7\u08eb\u08ec\u08fd\u0905\u08f5\u0908\u0903\u0589", (byte)122, 69) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u055d", (byte)122, 68) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        s = -8898670883139535403L;
        long l = s ^ 0x4AF4BBA4C402A631L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(42 + 27), (byte)(48 + 35), (byte)(21 + 26), (byte)(64 + 3), (byte)(16 + 50), (byte)(38 + 29), (byte)(36 + 11), (byte)(74 + 6), (byte)(46 + 29), (byte)(2 + 65), (byte)(29 + 54), (byte)(29 + 24), 80, (byte)(31 + 66), (byte)(39 + 61), (byte)(84 + 16), (byte)(20 + 85), (byte)(108 + 2), (byte)(45 + 58)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(42 + 26), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0520\u0547\u0528\u0550\u052d\u054e\u054f\u052b\u050d\u0535\u0535\u0552\u0510\u0523\u0546\u0518\u053a\u052a\u0549\u051c\u0522\u0561\u0528\u0529", (byte)25, 70);
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u053a\u0539\u0522\u0541\u054f\u0548\u050f\u0522\u0555\u0551\u0524\u051d", (byte)25, 69);
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0540\u0518\u054a\u0521\u051b\u0551\u0528\u0512\u054b\u0543\u0523\u0544\u0528\u0525\u0524\u051c\u0549\u054a\u0550\u055a\u0522\u053b\u0528\u0529", (byte)25, 69);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00fc\u0123\u0104\u012c\u0109\u012a\u012b\u0107\u00e9\u0111\u0112\u00ef\u00f2\u00f3\u010d\u00f4\u012c\u013b\u0130\u010c\u013c\u013d\u0104\u0105", (byte)25, 66);
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0500\u053a\u0548\u052c\u054a\u0534\u0512\u0507\u0541\u052f\u0545\u0525\u0534\u052b\u052e\u051c\u053c\u0556\u0552\u054b\u052b\u0561\u0528\u0529", (byte)25, 70);
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u046b\u0443\u0475\u044c\u0446\u047c\u0453\u043d\u0476\u046e\u044b\u0483\u0443\u0465\u0442\u045f\u0471\u0445\u043d\u0445\u0448\u0466\u0453\u0454", (byte)25, 68);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u0446\u045b\u0438\u044f\u046a\u045c\u047d\u043a\u0477\u0473\u045f\u0448", (byte)25, 68);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.h[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0109\u0128\u010a\u011b\u00eb\u00fc\u010b\u00fd\u011f\u0103\u012e\u00f9", (byte)25, 66);
                }
            }
        }
    }

    static {
        f = 0 >>> 222 | 0 << -222;
        ac = Long.reverse(-6071737707895619295L);
        ad = Long.reverse(-8646911284551352320L);
        al = Integer.reverse(Integer.MIN_VALUE);
        aq = Long.reverse(-6071737707895619295L);
        ar = Long.reverse(-8646911284551352320L);
        ax = (16384 >>> 141 | 16384 << -141) & 0xFFFFFFFF;
        az = Long.reverse(-6071737707895619295L);
        ba = Long.reverse(-8646911284551352320L);
        bc = (0x1800000 >>> 87 | 0x1800000 << -87) & 0xFFFFFFFF;
        be = Integer.reverse(-1073741824);
        g = new String[bc];
        h = new String[be];
        \u03a0\u03a3\u03a3\u03b3\u03ba\u03a9\u03bb\u03b5.b();
    }
}

