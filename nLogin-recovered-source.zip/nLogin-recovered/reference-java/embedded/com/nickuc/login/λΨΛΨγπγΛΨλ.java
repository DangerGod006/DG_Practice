/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb
implements \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static int i;
    private static int l;
    private static int k;
    private static long p;
    private static int c;
    private static String[] a;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 L;
    private static int e;
    private static int f;
    private static int n;
    private static long o;
    private static final int ag;
    private static long c;
    private static String[] b;
    private static int d;
    private static int s;
    private static int a;
    private static int j;
    private static int h;
    private static int m;
    private static int g;
    private static int r;
    private static int q;
    private static int b;

    @Generated
    public \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.L = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return (!\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().p() && \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().n() != a && \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a().nextInt(b) <= c ? d : e) != 0;
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.B, string -> {
            String string2 = string.trim();
            if (string2.length() > i && string2.charAt(j) == k && string2.charAt(string.length() - l) == m) {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.c((String)string, (String)\u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.c("\u3e80", (int)n, (long)(o ^ p)));
            } else {
                \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.a((String)string);
            }
        }, new Object[f]);
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[g];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.h] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }

    private static String a(int n, long l) {
        l ^= 0x34L;
        l ^= 0x10C0849ED1DFD879L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(56 + 13), (byte)(77 + 6), (byte)(3 + 44), (byte)(11 + 56), (byte)(29 + 37), (byte)(54 + 13), (byte)(22 + 25), (byte)(54 + 26), (byte)(48 + 27), 67, (byte)(2 + 81), (byte)(13 + 40), (byte)(9 + 71), (byte)(19 + 78), (byte)(43 + 57), (byte)(16 + 84), (byte)(3 + 102), 110, (byte)(23 + 80)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(29 + 39), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u01be\u01cb\u01ca\u018d\u01cd\u01c9\u01c4\u01cd\u01d8\u01c7\u0194\u01d2\u01d6\u01cf\u01d2\u01d8\u019a\u0527\u0515\u0509\u0517\u0523\u0531\u0525\u050e\u051c\u0530", (byte)110, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u054b\u056d\u056f\u054f\u0573\u0592\u058a\u05a0\u058c\u055b\u0599\u058f\u059d\u0597\u0560\u0585\u05a7\u05a6\u059e\u05a4\u059e\u0573", (byte)103, 69), \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u054d\u055a\u0559\u051c\u055c\u0558\u0553\u055c\u0567\u0556\u0523\u0561\u0565\u055e\u0561\u0567\u0529\u08b6\u08a4\u0898\u08a6\u08b2\u08c0\u08b4\u089d\u08ab\u08bf\u053f", (byte)103, 68) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0187", (byte)103, 66) + methodType.toString(), exception);
        }
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.L;
    }

    static {
        a = 9 >>> 64 | 9 << -64;
        b = Integer.reverse(0x26000000);
        c = Integer.reverse(0x40000000);
        d = Integer.reverse(Integer.MIN_VALUE);
        e = Integer.reverse(0);
        f = Integer.reverse(0);
        g = Integer.reverse(Integer.MIN_VALUE);
        h = 0 >>> 126 | 0 << -126;
        i = Integer.reverse(0x40000000);
        j = 0 >>> 179 | 0 << -179;
        k = 182 >>> 65 | 182 << ~65 + 1;
        l = Integer.reverse(Integer.MIN_VALUE);
        m = 5952 >>> 134 | 5952 << -134;
        n = Integer.reverse(0);
        o = Long.reverse(-505247532877664998L);
        p = Long.reverse(0x2C00000000000000L);
        q = Integer.reverse(Integer.MIN_VALUE);
        r = (0x8000000 >>> 155 | 0x8000000 << ~155 + 1) & 0xFFFFFFFF;
        s = Integer.reverse(0x40000000);
        a = new String[q];
        b = new String[r];
        \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.b();
        ag = s;
    }

    private static void b() {
        int n;
        c = 6392003073379712799L;
        long l = c ^ 0x10C0849ED1DFD879L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(46 + 22), (byte)(56 + 13), (byte)(41 + 42), (byte)(40 + 7), (byte)(5 + 62), (byte)(64 + 2), (byte)(44 + 23), (byte)(15 + 32), (byte)(73 + 7), (byte)(38 + 37), 67, (byte)(59 + 24), (byte)(18 + 35), (byte)(23 + 57), (byte)(83 + 14), (byte)(13 + 87), (byte)(45 + 55), 105, (byte)(80 + 30), (byte)(74 + 29)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(15 + 68)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0424\u0425\u03f1\u03fa\u0434\u042b\u0416\u03f8\u0432\u03ff\u042c\u0420\u0416\u03fd\u0417\u0443\u0423\u0407\u041b\u0429\u043a\u0408\u042d\u0421\u040d\u0420\u043e\u0440\u0428\u042c\u0430\u0452\u0414\u0415\u0444\u0430\u0417\u041a\u040f\u0414\u042a\u0431\u0456\u041f\u043a\u041b\u045e\u0433\u043c\u0426\u0455\u043f\u0425\u0434\u0431\u0432", (byte)3, 67);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0424\u0425\u03f1\u03fa\u0434\u042b\u0416\u03f8\u0432\u03ff\u042c\u0420\u0416\u03fd\u0417\u0443\u0423\u0407\u041b\u0429\u043a\u0408\u042d\u0421\u040d\u0420\u043e\u0440\u0428\u042c\u0430\u0452\u0414\u0415\u0444\u0430\u0417\u041a\u040f\u0414\u042a\u0431\u0456\u0421\u0420\u0420\u0435\u0458\u0446\u0442\u0445\u0432\u0429\u0460\u0460\u0462\u0450\u0462\u045b\u0464\u0444\u0463\u043e\u0475", (byte)3, 68);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u04f5\u0506\u04ec\u052a\u0508\u053b\u050b\u04f6\u0512\u0500\u052f\u053a\u051d\u053b\u0546\u052f\u0529\u0524\u0522\u0549\u0524\u0525\u0512\u0513", (byte)3, 70);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03a8\u039b\u03a8\u03b3\u03c0\u03b3\u039b\u03a8\u03bb.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u03f4\u0437\u03f6\u0405\u040a\u040a\u041a\u0439\u0434\u0419\u0417\u042d\u0415\u0416\u0446\u0438\u0446\u0447\u0421\u043f\u042b\u043a\u0411\u0412", (byte)3, 67);
                }
            }
        }
    }
}

