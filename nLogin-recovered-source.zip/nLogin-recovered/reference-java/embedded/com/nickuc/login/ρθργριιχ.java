/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03c1\u03b8\u03c1\u03b3\u03c1\u03b9\u03b9\u03c7 {
    private static int b;
    private static int a;
    static final /* synthetic */ int[] D;

    static {
        a = 8 >>> 195 | 8 << ~195 + 1;
        b = Integer.reverse(0x40000000);
        D = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03c1\u03b8\u03c1\u03b3\u03c1\u03b9\u03b9\u03c7.D[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03b8\u03c1\u03b3\u03c1\u03b9\u03b9\u03c7.D[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

