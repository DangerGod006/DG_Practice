/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0;

class \u03c1\u03c2\u03a8\u03a3\u03c6\u03c3\u0394\u03a9\u03c7\u03b5\u03b7\u03b3 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] d;
    private static int b = 0x4000000 >>> 121 | 0x4000000 << ~121 + 1;

    static {
        d = new int[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.values().length];
        try {
            \u03c1\u03c2\u03a8\u03a3\u03c6\u03c3\u0394\u03a9\u03c7\u03b5\u03b7\u03b3.d[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.e.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03c2\u03a8\u03a3\u03c6\u03c3\u0394\u03a9\u03c7\u03b5\u03b7\u03b3.d[\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0.f.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

