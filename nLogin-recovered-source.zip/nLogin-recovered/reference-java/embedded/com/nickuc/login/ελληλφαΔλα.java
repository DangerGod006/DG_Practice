/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.text.DecimalFormat;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1 {
    private static long an;
    private static long z;
    private static long s;
    private static long c;
    private static int al;
    private static int t;
    private static int n;
    private static int af;
    private static int v;
    private static int r;
    private static int i;
    private static long ak;
    private static long k;
    private static final String bQ;
    private static long j;
    private static double ap;
    private static int o;
    private static long ag;
    private static int a;
    private static long u;
    private static int p;
    private static final String[] e;
    private static final String bR;
    private static double h;
    private static long aj;
    private static int ad;
    private static int w;
    private static int ae;
    private static int aq;
    private static int ai;
    private static int f;
    private static long b;
    private static String[] b;
    private static int g;
    private static long m;
    private static int am;
    private static int aa;
    private static int y;
    private static int e;
    private static long d;
    private static int x;
    private static final double g;
    private static double ar;
    private static final DecimalFormat a;
    private static int ab;
    private static String[] a;
    private static int ah;
    private static int l;
    private static final double[] a;
    private static long ao;
    private static long ac;
    private static long q;

    @Nullable
    public static Short a(String string) {
        return \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(string, null);
    }

    private static String a(int n, long l) {
        l ^= 0xEL;
        l ^= 0xAC263F87398C976DL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(36 + 32), (byte)(52 + 17), 83, (byte)(20 + 27), (byte)(4 + 63), (byte)(18 + 48), (byte)(3 + 64), (byte)(37 + 10), (byte)(36 + 44), (byte)(7 + 68), (byte)(7 + 60), (byte)(8 + 75), (byte)(9 + 44), (byte)(17 + 63), 97, (byte)(97 + 3), (byte)(37 + 63), (byte)(28 + 77), (byte)(33 + 77), (byte)(61 + 42)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(41 + 28), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0528\u0535\u0534\u04f7\u0537\u0533\u052e\u0537\u0542\u0531\u04fe\u053c\u0540\u0539\u053c\u0542\u0504\u088b\u0892\u0893\u0890\u0895\u08a1\u088d\u0871\u0899\u0890", (byte)9, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(4490262658710781805L);
        d = Long.reverse(0x7000000000000000L);
        e = Integer.reverse(-1);
        f = (1024 >>> 170 | 1024 << ~170 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(0);
        h = Double.longBitsToDouble(Long.reverse(39426L));
        i = 8 >>> 227 | 8 << ~227 + 1;
        j = Long.reverse(4490262658710781805L);
        k = Long.reverse(0x7000000000000000L);
        l = (32 >>> 196 | 32 << -196) & 0xFFFFFFFF;
        m = Long.reverse(5643184163317628781L);
        n = Integer.reverse(-805306368);
        o = 0xB00000 >>> 212 | 0xB00000 << -212;
        p = (0x18000000 >>> 123 | 0x18000000 << ~123 + 1) & 0xFFFFFFFF;
        q = Long.reverse(5643184163317628781L);
        r = 0x1000000 >>> 150 | 0x1000000 << -150;
        s = Long.reverse(5643184163317628781L);
        t = (0x2800000 >>> 151 | 0x2800000 << -151) & 0xFFFFFFFF;
        u = Long.reverse(5643184163317628781L);
        v = Integer.reverse(-1610612736);
        w = Integer.reverse(0);
        x = (1536 >>> 232 | 1536 << -232) & 0xFFFFFFFF;
        y = Integer.reverse(-1);
        z = Long.reverse(5643184163317628781L);
        aa = (0x20000000 >>> 61 | 0x20000000 << -61) & 0xFFFFFFFF;
        ab = Integer.reverse(-536870912);
        ac = Long.reverse(5643184163317628781L);
        ad = Integer.reverse(0x40000000);
        ae = (2048 >>> 72 | 2048 << -72) & 0xFFFFFFFF;
        af = -1 >>> 161 | -1 << -161;
        ag = Long.reverse(5643184163317628781L);
        ah = (768 >>> 136 | 768 << ~136 + 1) & 0xFFFFFFFF;
        ai = Integer.reverse(-1879048192);
        aj = Long.reverse(4490262658710781805L);
        ak = Long.reverse(0x7000000000000000L);
        al = 65536 >>> 110 | 65536 << -110;
        am = Integer.reverse(0x50000000);
        an = Long.reverse(4490262658710781805L);
        ao = Long.reverse(0x7000000000000000L);
        ap = Double.longBitsToDouble(Long.reverse(2306L));
        aq = Integer.reverse(0);
        ar = Double.longBitsToDouble(Long.reverse(2306L));
        a = new String[n];
        b = new String[o];
        \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b();
        bQ = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e80", (int)p, (long)q);
        bR = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e83", (int)r, (long)s);
        a = new DecimalFormat((String)\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e86", (int)t, (long)u));
        String[] stringArray = new String[v];
        stringArray[\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.w] = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e89", (int)(x & y), (long)z);
        stringArray[\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.aa] = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e8c", (int)ab, (long)ac);
        stringArray[\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.ad] = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e8f", (int)(ae & af), (long)ag);
        stringArray[\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.ah] = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e92", (int)ai, (long)(aj ^ ak));
        stringArray[\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.al] = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e95", (int)am, (long)(an ^ ao));
        e = stringArray;
        g = Math.log10(ap);
        a = new double[e.length];
        for (int i = aq; i < a.length; ++i) {
            \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a[i] = Math.pow(ar, i);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0523\u0545\u0547\u0527\u054b\u056a\u0562\u0578\u0564\u0533\u0571\u0567\u0575\u056f\u0538\u055d\u057f\u057e\u0576\u057c\u0576\u054b", (byte)63, 69), \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04d5\u04e2\u04e1\u04a4\u04e4\u04e0\u04db\u04e4\u04ef\u04de\u04ab\u04e9\u04ed\u04e6\u04e9\u04ef\u04b1\u0838\u083f\u0840\u083d\u0842\u084e\u083a\u081e\u0846\u083d\u04c7", (byte)63, 67) + string + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0535", (byte)63, 70) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -5261307172373329284L;
        long l = c ^ 0xAC263F87398C976DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(63 + 5), (byte)(7 + 62), (byte)(78 + 5), (byte)(9 + 38), (byte)(28 + 39), (byte)(60 + 6), (byte)(33 + 34), (byte)(45 + 2), 80, (byte)(45 + 30), (byte)(31 + 36), (byte)(10 + 73), (byte)(39 + 14), (byte)(55 + 25), (byte)(19 + 78), (byte)(47 + 53), 100, (byte)(58 + 47), (byte)(61 + 49), (byte)(77 + 26)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(48 + 20), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0510\u0506\u04f4\u04ea\u0501\u04d6\u0518\u04e9\u04e5\u050b\u0507\u0516\u04f0\u0519\u04f1\u0510\u04e3\u04de\u04f0\u04f2\u04e7\u04f2\u04ef\u04f0", (byte)77, 68);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u018f\u0182\u017f\u014c\u0184\u0162\u0196\u0166\u0171\u0191\u0178\u0161", (byte)77, 65);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u04cc\u0507\u04e7\u0508\u04f3\u0513\u051b\u04ee\u0519\u04f2\u04eb\u04e4", (byte)77, 68);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[3] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0510\u0506\u04f4\u04ea\u0501\u04d6\u0518\u04e9\u04e5\u050b\u0507\u0516\u04f0\u0519\u04f1\u0510\u04e3\u04de\u04f0\u04f2\u04e7\u04f2\u04ef\u04f0", (byte)77, 68);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u057f\u0572\u056f\u053c\u0574\u0552\u0586\u0556\u0561\u0581\u0568\u0551", (byte)77, 70);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[5] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u018d\u018a\u0154\u0161\u018a\u0192\u0173\u0157\u0157\u016b\u0192\u0161", (byte)77, 65);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[6] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0160\u0187\u0195\u018e\u018a\u0191\u0162\u016f\u0165\u0193\u0153\u0161", (byte)77, 66);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[7] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0561\u057f\u0565\u055b\u0558\u0572\u0555\u0572\u055f\u055d\u054b\u0551", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[8] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0562\u053b\u053b\u0553\u0572\u0567\u057c\u057a\u0564\u0555\u0558\u0551", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[9] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u057d\u057b\u055f\u0556\u057b\u0571\u057f\u053b\u0563\u0581\u057a\u0551", (byte)77, 70);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[10] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u017c\u018a\u0182\u018e\u016d\u0187\u0176\u0174\u0183\u018d\u0186\u0161", (byte)77, 65);
                    continue block7;
                }
                case 1: {
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u057d\u0573\u0561\u0557\u056e\u0543\u0585\u0556\u0552\u0578\u056c\u058b\u0557\u0545\u0560\u056d\u056b\u055c\u0554\u0547\u058e\u0585\u055c\u055d", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u04cc\u04ec\u050d\u04e2\u04f6\u04ed\u0517\u04f5\u0514\u0511\u04fb\u04e4", (byte)77, 68);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[2] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u056a\u054c\u055c\u0550\u0543\u057e\u0541\u0569\u056a\u0573\u054b\u0551", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u018d\u0183\u0171\u0167\u017e\u0153\u0195\u0166\u0162\u0188\u017c\u017b\u018f\u0191\u0179\u017f\u017c\u016e\u019a\u01a3\u019d\u016f\u016c\u016d", (byte)77, 65);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u056e\u0578\u0575\u0545\u0550\u0565\u0542\u0575\u055b\u0544\u058a\u0551", (byte)77, 70);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[5] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u057c\u055d\u0542\u0563\u0581\u057d\u0541\u057f\u0587\u0580\u0584\u0564\u0540\u055f\u054d\u0591\u056d\u058d\u0587\u056b\u0551\u0585\u055c\u055d", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u018d\u017d\u0150\u0172\u0152\u0180\u018d\u0194\u0198\u0173\u019a\u0161", (byte)77, 65);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[7] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u015a\u017f\u0154\u0195\u0183\u0165\u0187\u0166\u0175\u0165\u0164\u0161", (byte)77, 66);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[8] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u04e4\u0513\u04e7\u0518\u04eb\u04e7\u04f4\u0514\u050f\u04e8\u04de\u04e4", (byte)77, 67);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[9] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0554\u057f\u0578\u0576\u0575\u053d\u0547\u0582\u0579\u0578\u057a\u0551", (byte)77, 69);
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[10] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0540\u057c\u0570\u053c\u054f\u0578\u057c\u0573\u0555\u058b\u0558\u0551", (byte)77, 70);
                    continue block7;
                }
                case 2: {
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04dd\u0502\u04d4\u0518\u04ed\u04f2\u04d7\u04d7\u050e\u0507\u04e7\u04e4", (byte)77, 68);
                    continue block7;
                }
                case 4: {
                    \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u018a\u0174\u0175\u0150\u0153\u0156\u0168\u0171\u0183\u0179\u018e\u0161", (byte)77, 66);
                }
            }
        }
    }

    public static Integer a(String string, Integer n) {
        if (string == null) {
            return n;
        }
        try {
            return Integer.valueOf(string);
        }
        catch (NumberFormatException numberFormatException) {
            return n;
        }
    }

    public static double a(long l, long l2) {
        return (double)l * h / (double)l2;
    }

    public static Double a(String string, Double d) {
        if (string == null) {
            return d;
        }
        try {
            return Double.valueOf(string);
        }
        catch (NumberFormatException numberFormatException) {
            return d;
        }
    }

    @Nullable
    public static Integer a(String string) {
        return \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(string, null);
    }

    @Nullable
    public static Long a(String string) {
        return \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(string, null);
    }

    @Nullable
    public static Double a(String string) {
        return \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(string, null);
    }

    public static Long a(String string, Long l) {
        if (string == null) {
            return l;
        }
        try {
            return Long.valueOf(string);
        }
        catch (NumberFormatException numberFormatException) {
            return l;
        }
    }

    public static boolean a(char c) {
        return (((String)\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e80", (int)a, (long)(b ^ d))).indexOf(c) > e ? f : g) != 0;
    }

    public static String c(long l) {
        if (l <= 0L) {
            return \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e80", (int)i, (long)(j ^ k));
        }
        int n = (int)(Math.log10(l) / g);
        double d = (double)l / a[n];
        return a.format(d) + (String)\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.c("\u3e83", (int)\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.l, (long)m) + e[n];
    }

    public static Short a(String string, Short s) {
        if (string == null) {
            return s;
        }
        try {
            return Short.valueOf(string);
        }
        catch (NumberFormatException numberFormatException) {
            return s;
        }
    }
}

