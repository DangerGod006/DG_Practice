/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.MemClassLoader
 *  javax.annotation.CheckReturnValue
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.loader.MemClassLoader;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Collections;
import java.util.function.Consumer;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6 {
    private static int v;
    private static int f;
    private static int l;
    private static long r;
    private static int j;
    private static int a;
    private static int i;
    private static int e;
    private static int u;
    private static int t;
    private static int k;
    private static long q;
    private static int b;
    private static int d;
    private static int g;
    private static int h;
    private static String[] b;
    private static int p;
    private static int c;
    private static String[] a;
    private static int n;
    private static int m;
    private static final int ac;
    private static int o;
    private static int w;
    private static int s;
    private static long c;

    @CheckReturnValue
    public static ByteArrayInputStream a(byte[] byArray) {
        return new ByteArrayInputStream(Base64.getDecoder().decode(byArray));
    }

    @CheckReturnValue
    @Nullable
    public static InputStream a(String string, boolean bl) {
        InputStream inputStream;
        ClassLoader classLoader = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.class.getClassLoader();
        if (!(classLoader instanceof MemClassLoader)) {
            throw new IllegalArgumentException((String)\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.c("\u3e80", (int)p, (long)(q ^ r)) + classLoader.getClass().getCanonicalName());
        }
        MemClassLoader memClassLoader = (MemClassLoader)classLoader;
        InputStream inputStream2 = inputStream = bl ? memClassLoader.getParentLoader().getResourceAsStream(string) : memClassLoader.getInJarResourceAsStream(string);
        if (inputStream == null) {
            inputStream = bl ? memClassLoader.getParentLoader().getResourceAsStream((char)s + string) : memClassLoader.getInJarResourceAsStream((char)t + string);
        }
        return inputStream;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @CheckReturnValue
    public static byte[] b(InputStream inputStream, int n) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(inputStream, byteArrayOutputStream, n);
            byte[] byArray = byteArrayOutputStream.toByteArray();
            return byArray;
        }
        finally {
            if (Collections.singletonList(byteArrayOutputStream).get(b) != null) {
                byteArrayOutputStream.close();
            }
        }
    }

    public static void a(InputStream inputStream, OutputStream outputStream, int n) {
        int n2;
        byte[] byArray = new byte[n];
        while ((n2 = inputStream.read(byArray, e, n)) != f) {
            outputStream.write(byArray, g, n2);
        }
        outputStream.flush();
    }

    @CheckReturnValue
    @Nullable
    public static InputStream a(String string) {
        return \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(string, o != 0);
    }

    public static String a(InputStream inputStream, MessageDigest messageDigest) {
        int n;
        byte[] byArray = new byte[h];
        while ((n = inputStream.read(byArray)) > 0) {
            messageDigest.update(byArray, i, n);
        }
        byte[] byArray2 = messageDigest.digest();
        StringBuilder stringBuilder = new StringBuilder();
        byte[] byArray3 = byArray2;
        int n2 = byArray3.length;
        for (int i = j; i < n2; ++i) {
            byte by = byArray3[i];
            stringBuilder.append(Integer.toString((by & k) + l, m).substring(\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.n));
        }
        return stringBuilder.toString();
    }

    public static byte[] a(Consumer<\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5> consumer) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        \u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5 \u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b52 = new \u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5(new DataOutputStream(byteArrayOutputStream));
        consumer.accept(\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b52);
        return byteArrayOutputStream.toByteArray();
    }

    private static String a(int n, long l) {
        l ^= 0x4DL;
        l ^= 0x19567A59F06C5C5CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(11 + 58), (byte)(9 + 74), (byte)(3 + 44), 67, (byte)(31 + 35), (byte)(65 + 2), (byte)(12 + 35), (byte)(40 + 40), (byte)(20 + 55), (byte)(15 + 52), 83, (byte)(40 + 13), (byte)(17 + 63), (byte)(16 + 81), (byte)(41 + 59), (byte)(86 + 14), (byte)(30 + 75), (byte)(6 + 104), (byte)(76 + 27)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(27 + 41), 69, (byte)(61 + 22)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u04e1\u04ee\u04ed\u04b0\u04f0\u04ec\u04e7\u04f0\u04fb\u04ea\u04b7\u04f5\u04f9\u04f2\u04f5\u04fb\u04bd\u084f\u0845\u084c\u0852\u0859\u0846\u085a\u085e\u084c\u085b\u084a\u0863\u085a\u0842", (byte)67, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = 64 >>> 154 | 64 << -154;
        b = Integer.reverse(0);
        c = 0 >>> 49 | 0 << ~49 + 1;
        d = Integer.reverse(524288);
        e = Integer.reverse(0);
        f = Integer.reverse(-1);
        g = (0 >>> 21 | 0 << -21) & 0xFFFFFFFF;
        h = Integer.reverse(262144);
        i = Integer.reverse(0);
        j = Integer.reverse(0);
        k = 261120 >>> 234 | 261120 << ~234 + 1;
        l = 0x800000 >>> 175 | 0x800000 << -175;
        m = Integer.reverse(0x8000000);
        n = 0x20000000 >>> 93 | 0x20000000 << ~93 + 1;
        o = (0 >>> 77 | 0 << -77) & 0xFFFFFFFF;
        p = Integer.reverse(0);
        q = Long.reverse(-7159247899349391199L);
        r = Long.reverse(-5620492334958379008L);
        s = (0xBC0000 >>> 242 | 0xBC0000 << -242) & 0xFFFFFFFF;
        t = Integer.reverse(-201326592);
        u = 0x40000000 >>> 62 | 0x40000000 << ~62 + 1;
        v = Integer.reverse(Integer.MIN_VALUE);
        w = 1 >>> 212 | 1 << -212;
        a = new String[u];
        b = new String[v];
        \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b();
        ac = w;
    }

    private static void b() {
        int n;
        c = -8856739738816830151L;
        long l = c ^ 0x19567A59F06C5C5CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(41 + 27), (byte)(56 + 13), (byte)(43 + 40), (byte)(17 + 30), (byte)(27 + 40), (byte)(23 + 43), (byte)(15 + 52), (byte)(36 + 11), (byte)(31 + 49), (byte)(72 + 3), (byte)(60 + 7), (byte)(19 + 64), (byte)(22 + 31), (byte)(56 + 24), (byte)(51 + 46), 100, (byte)(71 + 29), (byte)(71 + 34), 110, (byte)(52 + 51)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(12 + 56), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0464\u0486\u0446\u045f\u0485\u0462\u048b\u0465\u0463\u0464\u048a\u0453\u044f\u046f\u0491\u0474\u0488\u0489\u047d\u0456\u0491\u046c\u047a\u0470\u045d\u0493\u045c\u04a5\u0471\u0485\u0463\u0472", (byte)31, 68);
                    continue block7;
                }
                case 1: {
                    \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u052d\u054f\u050f\u0528\u054e\u052b\u0554\u052e\u052c\u052d\u0553\u051c\u0518\u0538\u055a\u053d\u0551\u0552\u0546\u051f\u055a\u0539\u0543\u055b\u053c\u0565\u055e\u054d\u0562\u0547\u0551\u054b\u0533\u0542\u0548\u0542\u0561\u0561\u054c\u0564\u055a\u0535\u054a\u0543", (byte)31, 70);
                    continue block7;
                }
                case 2: {
                    \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u052f\u0536\u0554\u054e\u052f\u0548\u0542\u0513\u0526\u0551\u054e\u0528\u054b\u0536\u0558\u0555\u0545\u0554\u0540\u0559\u0533\u0527\u0552\u055d\u0567\u0542\u0536\u056b\u054c\u054a\u054b\u0543", (byte)31, 69);
                    continue block7;
                }
                case 4: {
                    \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0512\u0532\u0528\u0516\u054a\u0516\u0512\u0549\u0513\u0557\u054c\u0523", (byte)31, 69);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0413\u0435\u0437\u0417\u043b\u045a\u0452\u0468\u0454\u0423\u0461\u0457\u0465\u045f\u0428\u044d\u046f\u046e\u0466\u046c\u0466\u043b", (byte)18, 68), \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0531\u053e\u053d\u0500\u0540\u053c\u0537\u0540\u054b\u053a\u0507\u0545\u0549\u0542\u0545\u054b\u050d\u089f\u0895\u089c\u08a2\u08a9\u0896\u08aa\u08ae\u089c\u08ab\u089a\u08b3\u08aa\u0892\u0527", (byte)18, 70) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0425", (byte)18, 68) + methodType.toString(), exception);
        }
    }

    @CheckReturnValue
    public static byte[] a(InputStream inputStream) {
        return \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.b(inputStream, a);
    }

    @CheckReturnValue
    public static ByteArrayInputStream a(String string, Charset charset) {
        return \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(string.getBytes(charset));
    }

    @CheckReturnValue
    public static ByteArrayInputStream a(String string) {
        return \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(string, StandardCharsets.UTF_8);
    }

    public static void a(InputStream inputStream, OutputStream outputStream) {
        \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(inputStream, outputStream, d);
    }
}

