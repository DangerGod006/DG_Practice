/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import javax.annotation.Nullable;
import lombok.Generated;

public class \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7 {
    @Nullable
    private final String bZ;
    private final String bY;

    @Generated
    public String au() {
        return this.bY;
    }

    @Generated
    public \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7(String string, @Nullable String string2) {
        this.bY = string;
        this.bZ = string2;
    }

    @Nullable
    @Generated
    public String av() {
        return this.bZ;
    }
}

