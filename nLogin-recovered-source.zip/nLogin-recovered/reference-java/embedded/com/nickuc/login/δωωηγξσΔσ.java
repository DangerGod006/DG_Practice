/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3
extends \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private static int z;
    private static long r;
    private static long q;
    private static long d;
    private static int t;
    private static int ac;
    private static long h;
    private static int f;
    private static int ad;
    private static int l;
    private static long ab;
    private static long w;
    private static int s;
    private static int aa;
    private static long n;
    private static int m;
    private static int x;
    private static String[] b;
    private static int ai;
    private static int k;
    private static int ah;
    private static int i;
    private static long o;
    private static int ae;
    private static long g;
    private static int p;
    private static int c;
    private static int u;
    private static int j;
    private static long c;
    private static long y;
    private static int af;
    private static int ag;
    private static long e;
    private static String[] a;
    private static int v;

    @Override
    public void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, (String)(\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.p != l ? \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e80", (int)m, (long)(n ^ o)) : \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e83", (int)p, (long)(q ^ r))), new Object[s]);
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.e(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.getName() + (String)(\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.p != t ? \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e86", (int)(u & v), (long)w) : \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e89", (int)x, (long)y)) + (String)\u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e8c", (int)(z & aa), (long)ab), new Object[ac]);
        int n = ad;
        if (stringArray.length > ae) {
            n = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(stringArray[af], (Integer)n);
        }
        \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.a((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a, n > 0 ? n : ag);
    }

    public \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, (String)\u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e80", (int)c, (long)(d ^ e)), (String)\u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.c("\u3e83", (int)f, (long)(g ^ h)), i != 0, j != 0, new String[k]);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u00b7\u00d9\u00db\u00bb\u00df\u00fe\u00f6\u010c\u00f8\u00c7\u0105\u00fb\u0109\u0103\u00cc\u00f1\u0113\u0112\u010a\u0110\u010a\u00df", (byte)8, 66), \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0527\u0534\u0533\u04f6\u0536\u0532\u052d\u0536\u0541\u0530\u04fd\u053b\u053f\u0538\u053b\u0541\u0503\u0889\u089f\u08a0\u088f\u088c\u0898\u089e\u0870\u08a0\u0518", (byte)8, 70) + string + \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u00c9", (byte)8, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -2991879847883957714L;
        long l = c ^ 0xF6E98D38049ACCA3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(7 + 62), (byte)(49 + 34), (byte)(45 + 2), (byte)(31 + 36), (byte)(59 + 7), (byte)(50 + 17), 47, (byte)(6 + 74), (byte)(13 + 62), 67, (byte)(62 + 21), (byte)(14 + 39), (byte)(13 + 67), (byte)(36 + 61), (byte)(94 + 6), (byte)(46 + 54), (byte)(83 + 22), (byte)(34 + 76), (byte)(72 + 31)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(7 + 61), 69, (byte)(36 + 47)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u052c\u0530\u052f\u051c\u0536\u051e\u052a\u0545\u0533\u054e\u0533\u0520", (byte)28, 69);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u011a\u0129\u0100\u012c\u012a\u010c\u0102\u0131\u0128\u0132\u0131\u013a\u0134\u012f\u010c\u00f7\u013f\u0119\u010c\u011a\u011a\u010d\u010a\u010b", (byte)28, 65);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u050d\u050e\u0531\u054b\u0535\u051e\u0558\u0558\u0545\u0525\u0559\u0527\u0558\u0517\u054c\u053e\u055b\u052f\u0541\u0564\u0553\u0555\u0525\u0533\u0541\u0564\u0535\u0568\u052b\u053f\u0558\u0571", (byte)28, 69);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u047d\u0476\u0452\u0486\u0472\u0456\u0483\u045a\u047e\u047b\u048a\u0481\u0477\u0490\u0450\u0483\u0473\u046e\u046b\u0483\u0493\u0449\u0465\u048b\u0466\u0499\u0474\u0457\u047a\u0488\u0491\u046f\u0493\u0476\u0494\u0486\u0486\u0475\u04a7\u047c\u047a\u04a9\u046b\u0471", (byte)28, 68);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u0109\u011e\u0126\u00ee\u0100\u0116\u0115\u012b\u0106\u0123\u0103\u0132\u012a\u0127\u00fe\u0128\u00f8\u00ff\u012b\u013c\u0134\u011d\u010a\u010b", (byte)28, 65);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[5] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u00ee\u0122\u00f0\u0109\u0127\u00ef\u0128\u0108\u0112\u0133\u00ec\u0118\u00fa\u013e\u00f5\u013c\u0112\u012b\u010a\u0120\u013d\u011d\u010a\u010b", (byte)28, 65);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u011a\u011d\u0127\u0134\u011e\u012e\u0133\u0125\u0131\u010a\u010d\u00f8\u012d\u010a\u0106\u012d\u0117\u0100\u0136\u00fe\u00fe\u0104\u00f8\u0125\u0130\u0117\u011a\u011e\u0147\u00ff\u0147\u0150", (byte)28, 65);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0453\u0475\u0452\u0440\u0478\u0456\u0469\u0451\u0454\u0479\u0447\u0446\u0444\u047c\u0485\u0492\u0491\u0473\u0493\u0468\u048a\u0495\u045c\u045d", (byte)28, 67);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u046c\u047b\u0452\u047e\u047c\u045e\u0454\u0483\u047a\u0484\u0484\u0465\u045d\u0462\u0442\u046b\u044f\u0464\u0490\u046e\u0454\u046f\u045c\u045d", (byte)28, 67);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u043e\u043f\u0462\u047c\u0466\u044f\u0489\u0489\u0476\u0456\u048a\u0458\u0489\u0448\u047d\u046f\u048c\u0460\u0472\u0495\u0484\u048d\u048d\u0498\u0469\u0454\u0466\u0489\u049f\u0456\u049d\u0493", (byte)28, 68);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[3] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u012b\u0124\u0100\u0134\u0120\u0104\u0131\u0108\u012c\u0129\u0138\u012f\u0125\u013e\u00fe\u0131\u0121\u011c\u0119\u0131\u0141\u00f7\u0113\u0139\u0114\u0147\u0122\u0105\u0128\u0136\u013f\u011d\u011e\u0107\u012a\u0109\u013c\u0111\u0150\u0156\u010a\u014e\u012e\u011f", (byte)28, 66);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u045b\u0470\u0478\u0440\u0452\u0468\u0467\u047d\u0458\u0475\u0455\u0488\u0457\u047b\u046e\u047c\u0486\u047e\u0473\u046b\u0485\u046f\u045c\u045d", (byte)28, 67);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u050f\u0543\u0511\u052a\u0548\u0510\u0549\u0529\u0533\u0554\u051a\u054b\u0545\u0536\u053e\u0551\u0542\u051e\u051c\u0531\u0534\u0554\u052b\u052c", (byte)28, 70);
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[6] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u053b\u053e\u0548\u0555\u053f\u054f\u0554\u0546\u0552\u052b\u052e\u0519\u054e\u052b\u0527\u054e\u0538\u0521\u0557\u051f\u051f\u0523\u0531\u0532\u0539\u0567\u056a\u052b\u0547\u056c\u0528\u053f", (byte)28, 69);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u010a\u00e7\u0100\u0131\u0114\u0134\u0115\u0120\u0139\u00f0\u0138\u00ff", (byte)28, 65);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0540\u052b\u054e\u0528\u0532\u0527\u0510\u0536\u0551\u0557\u0524\u0527\u055d\u0559\u052c\u052c\u055f\u054b\u051d\u0561\u0541\u053e\u052b\u052c", (byte)28, 70);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x2AL;
        l ^= 0xF6E98D38049ACCA3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), (byte)(54 + 15), (byte)(51 + 32), (byte)(35 + 12), (byte)(47 + 20), (byte)(58 + 8), (byte)(39 + 28), 47, (byte)(10 + 70), (byte)(50 + 25), (byte)(35 + 32), (byte)(24 + 59), (byte)(17 + 36), (byte)(47 + 33), (byte)(34 + 63), (byte)(60 + 40), (byte)(68 + 32), (byte)(13 + 92), (byte)(15 + 95), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(35 + 33), 69, (byte)(17 + 66)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0571\u057e\u057d\u0540\u0580\u057c\u0577\u0580\u058b\u057a\u0547\u0585\u0589\u0582\u0585\u058b\u054d\u08d3\u08e9\u08ea\u08d9\u08d6\u08e2\u08e8\u08ba\u08ea", (byte)82, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        c = Integer.reverse(0);
        d = Long.reverse(8383551940955299435L);
        e = Long.reverse(0x5400000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(8383551940955299435L);
        h = Long.reverse(0x5400000000000000L);
        i = 0 >>> 145 | 0 << ~145 + 1;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = (0 >>> 86 | 0 << ~86 + 1) & 0xFFFFFFFF;
        l = Integer.reverse(-1);
        m = Integer.reverse(0x40000000);
        n = Long.reverse(8383551940955299435L);
        o = Long.reverse(0x5400000000000000L);
        p = Integer.reverse(-1073741824);
        q = Long.reverse(8383551940955299435L);
        r = Long.reverse(0x5400000000000000L);
        s = (0 >>> 231 | 0 << -231) & 0xFFFFFFFF;
        t = (-1 >>> 59 | -1 << -59) & 0xFFFFFFFF;
        u = Integer.reverse(0x20000000);
        v = -1 >>> 120 | -1 << -120;
        w = Long.reverse(2330714041769352811L);
        x = (5120 >>> 138 | 5120 << -138) & 0xFFFFFFFF;
        y = Long.reverse(2330714041769352811L);
        z = Integer.reverse(0x60000000);
        aa = -1 >>> 56 | -1 << ~56 + 1;
        ab = Long.reverse(2330714041769352811L);
        ac = 0 >>> 224 | 0 << ~224 + 1;
        ad = (7680 >>> 167 | 7680 << ~167 + 1) & 0xFFFFFFFF;
        ae = Integer.reverse(Integer.MIN_VALUE);
        af = Integer.reverse(Integer.MIN_VALUE);
        ag = Integer.reverse(0x3C000000);
        ah = Integer.reverse(-536870912);
        ai = (-536870912 >>> 253 | -536870912 << ~253 + 1) & 0xFFFFFFFF;
        a = new String[ah];
        b = new String[ai];
        \u03b4\u03c9\u03c9\u03b7\u03b3\u03be\u03c3\u0394\u03c3.b();
    }
}

