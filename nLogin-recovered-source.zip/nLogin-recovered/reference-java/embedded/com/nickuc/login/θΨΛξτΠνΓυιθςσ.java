/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3 {
    private static long i;
    private final \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4 a;
    private static long b;
    private static long g;
    private static int q;
    private static int e;
    private static int k;
    private static long d;
    private static long c;
    private static int h;
    private static String[] b;
    private final String bp;
    private static int f;
    private static String[] a;
    private static int r;
    private static int a;
    private static int o;
    private final String bq;
    private static long j;
    private final boolean aj;
    private static long p;
    private final String br;
    private static long l;
    private static int m;
    private static long n;

    @Generated
    public \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3(String string, String string2, String string3, \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4 \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b42, boolean bl) {
        this.bp = string;
        this.bq = string2;
        this.br = string3;
        this.a = \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b42;
        this.aj = bl;
    }

    @Generated
    public \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4 a() {
        return this.a;
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(2528483508529752244L);
        d = Long.reverse(0xA00000000000000L);
        e = (0x8000000 >>> 59 | 0x8000000 << ~59 + 1) & 0xFFFFFFFF;
        f = -1 >>> 229 | -1 << ~229 + 1;
        g = Long.reverse(2960829072757319860L);
        h = Integer.reverse(0x40000000);
        i = Long.reverse(2528483508529752244L);
        j = Long.reverse(0xA00000000000000L);
        k = 98304 >>> 15 | 98304 << -15;
        l = Long.reverse(2960829072757319860L);
        m = (262144 >>> 48 | 262144 << ~48 + 1) & 0xFFFFFFFF;
        n = Long.reverse(2960829072757319860L);
        o = (163840 >>> 79 | 163840 << -79) & 0xFFFFFFFF;
        p = Long.reverse(2960829072757319860L);
        q = (0x300000 >>> 179 | 0x300000 << -179) & 0xFFFFFFFF;
        r = 49152 >>> 173 | 49152 << -173;
        a = new String[q];
        b = new String[r];
        \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b();
    }

    private static void b() {
        int n;
        c = 3248953795264080068L;
        long l = c ^ 0x12343032EBA119CEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(6 + 62), (byte)(8 + 61), (byte)(32 + 51), (byte)(13 + 34), (byte)(23 + 44), (byte)(35 + 31), (byte)(43 + 24), 47, (byte)(29 + 51), (byte)(71 + 4), (byte)(49 + 18), (byte)(59 + 24), 53, (byte)(9 + 71), (byte)(43 + 54), (byte)(84 + 16), (byte)(11 + 89), (byte)(98 + 7), (byte)(47 + 63), (byte)(20 + 83)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(15 + 54), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u056a\u054d\u0580\u0587\u0572\u058d\u058a\u056c\u0570\u0597\u0570\u0595\u057b\u056f\u0598\u0570\u0597\u055a\u059b\u057d\u05a2\u0595\u0591\u05aa\u0575\u0567\u05ab\u0585\u057c\u0589\u057b\u05b2", (byte)94, 69);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0521\u0534\u0537\u051e\u0517\u052b\u054f\u050f\u0510\u0543\u0542\u0541\u0510\u053e\u050e\u0511\u0541\u0548\u0557\u055c\u0527\u054b\u0522\u0523", (byte)94, 67);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0171\u018a\u0180\u01aa\u016e\u01b5\u01a4\u0179\u018d\u01be\u019c\u01af\u0191\u01b9\u01ba\u01b2\u017c\u017d\u01c2\u01c0\u01a6\u01c7\u018e\u018f", (byte)94, 65);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u018d\u0180\u0190\u01b8\u018b\u01b4\u0170\u019c\u01b0\u01b4\u0192\u0183", (byte)94, 66);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u018c\u018a\u0186\u0181\u01a1\u019a\u01ad\u0194\u01a6\u0185\u01a9\u0190\u01b0\u018c\u0197\u01a4\u0195\u0197\u01b0\u01b8\u01a8\u01a1\u018e\u018f", (byte)94, 65);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[5] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u01a7\u01b6\u019e\u0185\u0198\u01a3\u01aa\u018d\u01b6\u01b6\u018e\u0183", (byte)94, 65);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u051f\u0502\u0535\u053c\u0527\u0542\u053f\u0521\u0525\u054c\u0525\u054a\u0530\u0524\u054d\u0525\u054c\u050f\u0550\u0532\u0557\u0547\u052c\u0560\u051b\u052d\u051d\u0515\u055d\u0532\u055f\u0535\u055b\u0534\u055d\u053b\u055d\u0543\u056c\u055c\u056c\u0541\u0529\u0537", (byte)94, 68);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u056c\u057f\u0582\u0569\u0562\u0576\u059a\u055a\u055b\u058e\u058c\u055d\u0598\u058e\u058c\u058e\u0562\u0595\u0583\u0593\u0563\u0580\u056d\u056e", (byte)94, 70);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0550\u0569\u055f\u0589\u054d\u0594\u0583\u0558\u056c\u059d\u057c\u058f\u0575\u0556\u055a\u059a\u05a3\u0562\u0593\u0598\u059e\u057b\u057c\u058a\u05ab\u0598\u0588\u0597\u05a4\u056c\u0567\u0571", (byte)94, 70);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[3] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u054a\u0553\u0581\u0589\u056b\u054e\u056b\u0574\u0573\u0593\u0556\u0587\u0578\u058e\u0580\u0574\u057c\u056d\u05a5\u0564\u0599\u0580\u056d\u056e", (byte)94, 70);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u056b\u0569\u0565\u0560\u0580\u0579\u058c\u0573\u0585\u0564\u058a\u059d\u055a\u058b\u0577\u0562\u0592\u058e\u055e\u059c\u05a3\u05a6\u056d\u056e", (byte)94, 70);
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[5] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u056e\u0572\u0572\u0565\u0584\u058e\u0597\u0575\u0566\u056d\u056d\u0562", (byte)94, 70);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0552\u0550\u058c\u0581\u0565\u0568\u058e\u0566\u0574\u0577\u058f\u0559\u0551\u0595\u0561\u057d\u058d\u05a2\u0595\u05a0\u059f\u057a\u059c\u057c\u059b\u0589\u059c\u059d\u0589\u056a\u05a1\u058c", (byte)94, 70);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0564\u058a\u0553\u0582\u054f\u0551\u058d\u0551\u058b\u055b\u0598\u0573\u0572\u059e\u0573\u055c\u0560\u0579\u055e\u05a5\u0581\u0580\u056d\u056e", (byte)94, 69);
                }
            }
        }
    }

    @Generated
    public String Y() {
        return this.br;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u014b\u016d\u016f\u014f\u0173\u0192\u018a\u01a0\u018c\u015b\u0199\u018f\u019d\u0197\u0160\u0185\u01a7\u01a6\u019e\u01a4\u019e\u0173", (byte)82, 65), \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0571\u057e\u057d\u0540\u0580\u057c\u0577\u0580\u058b\u057a\u0547\u0585\u0589\u0582\u0585\u058b\u054d\u08d7\u08c8\u08bc\u08e0\u08e7\u08c4\u08e2\u08b9\u08ec\u08e1\u08e1\u08ec\u08ee\u0566", (byte)82, 70) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u015d", (byte)82, 65) + methodType.toString(), exception);
        }
    }

    @Generated
    public boolean ao() {
        return this.aj;
    }

    @Generated
    public String s() {
        return this.bq;
    }

    @Generated
    public String toString() {
        return (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e80", (int)a, (long)(b ^ d)) + this.q() + (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e83", (int)(e & f), (long)g) + this.s() + (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e86", (int)h, (long)(i ^ j)) + this.Y() + (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e89", (int)k, (long)l) + (Object)((Object)this.a()) + (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e8c", (int)m, (long)n) + this.ao() + (String)\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.c("\u3e8f", (int)o, (long)p);
    }

    private static String a(int n, long l) {
        l ^= 0x50L;
        l ^= 0x12343032EBA119CEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(10 + 58), (byte)(49 + 20), (byte)(66 + 17), (byte)(16 + 31), (byte)(52 + 15), 66, (byte)(32 + 35), (byte)(39 + 8), (byte)(19 + 61), (byte)(64 + 11), 67, (byte)(82 + 1), (byte)(29 + 24), (byte)(49 + 31), (byte)(44 + 53), (byte)(81 + 19), (byte)(44 + 56), (byte)(101 + 4), (byte)(75 + 35), (byte)(99 + 4)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(19 + 49), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u00f4\u0101\u0100\u00c3\u0103\u00ff\u00fa\u0103\u010e\u00fd\u00ca\u0108\u010c\u0105\u0108\u010e\u00d0\u045a\u044b\u043f\u0463\u046a\u0447\u0465\u043c\u046f\u0464\u0464\u046f\u0471", (byte)9, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public String q() {
        return this.bp;
    }
}

