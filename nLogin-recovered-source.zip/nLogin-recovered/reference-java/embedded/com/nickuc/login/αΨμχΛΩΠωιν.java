/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.SpawnType
 *  com.nickuc.login.api.nLoginAPI$nLoginInternal
 *  com.nickuc.login.api.types.Identity
 *  com.nickuc.login.api.types.Location
 *  javax.annotation.Nonnull
 *  net.md_5.bungee.api.plugin.Plugin
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.SpawnType;
import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.api.types.Identity;
import com.nickuc.login.api.types.Location;
import com.nickuc.login.\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4;
import com.nickuc.login.\u03a3\u03c5\u0393\u03b9\u03c8\u03a0\u03c4\u03c6\u03bf;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c3\u03b7\u03b7\u03ba\u03c4\u03bb\u03c1\u03c7\u03c9\u03b2\u0393\u03b9\u03be;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.plugin.Plugin;

public class \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd
extends \u03c3\u03b7\u03b7\u03ba\u03c4\u03bb\u03c1\u03c7\u03c9\u03b2\u0393\u03b9\u03be {
    private static String[] d;
    private final \u03a3\u03c5\u0393\u03b9\u03c8\u03a0\u03c4\u03c6\u03bf a = new \u03a3\u03c5\u0393\u03b9\u03c8\u03a0\u03c4\u03c6\u03bf(this);
    private static int br;
    private static int bp;
    private static long w;
    private static long bj;
    private static int aq;
    private static long ac;
    private static int f;
    private static long i;
    private static int af;
    private static long bi;
    private static long e;
    private static int ab;
    private static int ae;
    private static int bg;
    private static long k;
    private static int r;
    private static long ag;
    private static long au;
    private static long aj;
    private static long as;
    private static long ak;
    private static long h;
    private static long t;
    private static int ah;
    private static long l;
    private static int j;
    private static String[] c;

    public void requestLogin(Identity identity, Object object) {
        if (object == null) {
            throw new IllegalArgumentException((String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e80", (int)j, (long)(k ^ l)));
        }
        if (!(object instanceof Plugin)) {
            throw new IllegalArgumentException((String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e83", (int)r, (long)(t ^ w)) + object + (String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e86", (int)ab, (long)ac) + Plugin.class + (String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e89", (int)(ae & af), (long)ag));
        }
        if (identity == null) {
            throw new IllegalArgumentException((String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e8c", (int)ah, (long)(aj ^ ak)));
        }
        if (!(identity instanceof \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0)) {
            throw new IllegalArgumentException((String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e8f", (int)aq, (long)(as ^ au)) + \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0.class.getCanonicalName() + (String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e92", (int)bg, (long)(bi ^ bj)) + identity.getClass().getCanonicalName());
        }
        String string = this.b(identity);
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)((Object)this.a)).b().a(string);
        if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 != null) {
            ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).b().a().c(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)((Object)this.a)).a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6));
        }
    }

    private static String a(int n, long l) {
        l ^= 0x10L;
        l ^= 0xB3C63675A264B6A3L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(36 + 32), (byte)(55 + 14), (byte)(2 + 81), (byte)(31 + 16), (byte)(57 + 10), 66, (byte)(29 + 38), (byte)(31 + 16), (byte)(31 + 49), (byte)(19 + 56), (byte)(61 + 6), (byte)(32 + 51), (byte)(2 + 51), (byte)(42 + 38), (byte)(29 + 68), (byte)(57 + 43), (byte)(35 + 65), (byte)(88 + 17), (byte)(5 + 105), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(39 + 29), (byte)(57 + 12), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u057a\u0587\u0586\u0549\u0589\u0585\u0580\u0589\u0594\u0583\u0550\u058e\u0592\u058b\u058e\u0594\u0556\u08d9\u08d1\u08e6\u08f2\u08c7\u08d6\u08ce\u08f8\u08e9\u08ee", (byte)91, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    public Optional<Location> getSpawnLocation(@Nonnull SpawnType spawnType) {
        throw new UnsupportedOperationException((String)\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.c("\u3e80", (int)f, (long)(h ^ i)));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u043d\u045f\u0461\u0441\u0465\u0484\u047c\u0492\u047e\u044d\u048b\u0481\u048f\u0489\u0452\u0477\u0499\u0498\u0490\u0496\u0490\u0465", (byte)32, 68), \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u053f\u054c\u054b\u050e\u054e\u054a\u0545\u054e\u0559\u0548\u0515\u0553\u0557\u0550\u0553\u0559\u051b\u089e\u0896\u08ab\u08b7\u088c\u089b\u0893\u08bd\u08ae\u08b3\u0531", (byte)32, 70) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00f9", (byte)32, 66) + methodType.toString(), exception);
        }
    }

    static {
        f = (0 >>> 88 | 0 << ~88 + 1) & 0xFFFFFFFF;
        h = Long.reverse(6412067348004770653L);
        i = Long.reverse(0x800000000000000L);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(6412067348004770653L);
        l = Long.reverse(0x800000000000000L);
        r = Integer.reverse(0x40000000);
        t = Long.reverse(6412067348004770653L);
        w = Long.reverse(0x800000000000000L);
        ab = 98304 >>> 47 | 98304 << -47;
        ac = Long.reverse(5835606595701347165L);
        ae = 8 >>> 97 | 8 << -97;
        af = -1 >>> 4 | -1 << -4;
        ag = Long.reverse(5835606595701347165L);
        ah = 20 >>> 130 | 20 << ~130 + 1;
        aj = Long.reverse(6412067348004770653L);
        ak = Long.reverse(0x800000000000000L);
        aq = (-2147483647 >>> 94 | -2147483647 << -94) & 0xFFFFFFFF;
        as = Long.reverse(6412067348004770653L);
        au = Long.reverse(0x800000000000000L);
        bg = Integer.reverse(-536870912);
        bi = Long.reverse(6412067348004770653L);
        bj = Long.reverse(0x800000000000000L);
        bp = Integer.reverse(0x10000000);
        br = Integer.reverse(0x10000000);
        c = new String[bp];
        d = new String[br];
        \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.b();
    }

    public \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
    }

    @Nonnull
    public nLoginAPI.nLoginInternal internal() {
        return this.a;
    }

    private static void b() {
        int n;
        e = -4987404999148683494L;
        long l = e ^ 0xB3C63675A264B6A3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(60 + 8), (byte)(19 + 50), (byte)(4 + 79), (byte)(13 + 34), (byte)(44 + 23), (byte)(28 + 38), 67, (byte)(2 + 45), (byte)(19 + 61), (byte)(60 + 15), (byte)(10 + 57), (byte)(80 + 3), (byte)(29 + 24), (byte)(67 + 13), (byte)(32 + 65), (byte)(44 + 56), (byte)(23 + 77), 105, (byte)(11 + 99), (byte)(62 + 41)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(13 + 55), 69, (byte)(81 + 2)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0540\u0541\u055b\u057c\u0574\u0582\u056d\u057c\u0584\u0578\u0543\u0588\u057d\u054b\u0593\u054d\u056b\u0587\u0562\u058d\u056b\u0573\u0597\u0569\u057d\u0570\u0596\u0591\u055e\u0556\u055b\u0599", (byte)115, 67);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0542\u0581\u0589\u0563\u0548\u0582\u055e\u055c\u057f\u0559\u058f\u055d\u057c\u0580\u0547\u0576\u054e\u0583\u0599\u0550\u0555\u0568\u0590\u0592\u0595\u0560\u059e\u056e\u05a0\u0584\u0595\u0561\u0571\u059c\u0597\u059f\u057d\u0581\u0577\u05ae\u059e\u059d\u0581\u0576", (byte)115, 67);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0199\u01d8\u01e0\u01ba\u019f\u01d9\u01b5\u01b3\u01d6\u01b0\u01e7\u01d9\u01b7\u01a7\u01ec\u01d5\u01c6\u01e6\u01ad\u01e3\u01e6\u01e3\u01c3\u01f3\u01cd\u01e9\u01b4\u01cd\u01d6\u01e3\u01b5\u01e5", (byte)115, 66);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0583\u0540\u057e\u0556\u0547\u058a\u057a\u057b\u054e\u0588\u0560\u055a\u057d\u058a\u0568\u0574\u054f\u0554\u056c\u058b\u056c\u0599\u059d\u057a\u058d\u058e\u057a\u057a\u0562\u0564\u0599\u0592\u0565\u05a6\u0573\u0578\u057b\u0568\u0585\u059b\u0578\u0598\u0579\u0576", (byte)115, 68);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u01d4\u01b8\u01b1\u01d7\u01d5\u01ab\u01b1\u01a2\u01d3\u01ba\u01a7\u01ad", (byte)115, 66);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0577\u0571\u05a2\u0582\u056c\u05ae\u057d\u058a\u059b\u05ad\u059e\u056c\u056d\u0586\u056c\u0574\u0596\u05b6\u05a8\u0590\u0590\u05b0\u0577\u0587\u0594\u057a\u059b\u059a\u05a3\u05af\u05a6\u059e\u0588\u05c8\u0599\u05b6\u05c1\u05b6\u05b9\u05b9\u05ab\u05a6\u05bc\u0597", (byte)115, 69);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[6] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0577\u0571\u05a2\u0582\u056c\u05ae\u057d\u058a\u059b\u05ad\u059c\u058c\u059d\u0574\u0587\u0597\u05b0\u0571\u0570\u0589\u0572\u058c\u05b9\u05b7\u058d\u05c0\u05b0\u05ac\u05af\u05bd\u0593\u05a8\u05b5\u05be\u05c2\u05ba\u05cd\u059b\u0589\u059f\u05bc\u05c1\u05c8\u0597", (byte)115, 70);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0585\u0594\u0566\u059f\u058b\u05ad\u0568\u0587\u056a\u057d\u05ac\u056e\u0566\u05a8\u05ab\u0571\u0584\u0596\u05b6\u0579\u0575\u0585\u0582\u0583", (byte)115, 69);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0540\u0541\u055b\u057c\u0574\u0582\u056d\u057c\u0584\u0578\u0543\u0588\u057d\u054b\u0593\u054d\u056b\u0587\u0562\u058d\u056b\u0568\u056b\u0589\u0587\u057b\u0592\u057f\u0593\u0560\u0570\u05a3\u0584\u0573\u0587\u05aa\u0577\u0563\u057a\u0588\u05a7\u059b\u0581\u0576", (byte)115, 67);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0199\u01d8\u01e0\u01ba\u019f\u01d9\u01b5\u01b3\u01d6\u01b0\u01e6\u01b4\u01d3\u01d7\u019e\u01cd\u01a5\u01da\u01f0\u01a7\u01ac\u01bf\u01e7\u01e9\u01ec\u01b7\u01f5\u01c5\u01f7\u01db\u01ec\u01b8\u01fb\u01f9\u01f0\u01d1\u01d4\u01fd\u01fe\u01e2\u01c6\u01bf\u0206\u01cd", (byte)115, 66);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0563\u05a2\u05aa\u0584\u0569\u05a3\u057f\u057d\u05a0\u057a\u05b1\u05a3\u0581\u0571\u05b6\u059f\u0590\u05b0\u0577\u05ad\u05b0\u05ac\u0589\u057e\u058b\u05a0\u059b\u057c\u0583\u05af\u05bf\u0586\u05b0\u0592\u05a4\u05c2\u05a8\u05bb\u0585\u05c0\u05a9\u05bc\u05d0\u0597", (byte)115, 69);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u05a4\u0561\u059f\u0577\u0568\u05ab\u059b\u059c\u056f\u05a9\u0581\u057b\u059e\u05ab\u0589\u0595\u0570\u0575\u058d\u05ac\u058d\u05ba\u05be\u059b\u05ae\u05af\u059b\u059b\u0583\u0585\u05ba\u05b3\u0583\u0592\u0580\u05a9\u05c7\u05c4\u05b6\u05a3\u0599\u05d1\u05c0\u0597", (byte)115, 69);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[4] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u055b\u053a\u0577\u054a\u055b\u057b\u0568\u0546\u0548\u0561\u0569\u0556", (byte)115, 67);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[5] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0577\u0571\u05a2\u0582\u056c\u05ae\u057d\u058a\u059b\u05ad\u059e\u056c\u056d\u0586\u056c\u0574\u0596\u05b6\u05a8\u0590\u0590\u05b0\u0577\u0587\u0594\u057a\u059b\u059a\u05a3\u05af\u05a6\u059e\u0586\u0583\u05a0\u0585\u05cb\u0597\u05ba\u05cd\u05c0\u05a1\u05c8\u0597", (byte)115, 69);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u01ad\u01a7\u01d8\u01b8\u01a2\u01e4\u01b3\u01c0\u01d1\u01e3\u01d2\u01c2\u01d3\u01aa\u01bd\u01cd\u01e6\u01a7\u01a6\u01bf\u01a8\u01c2\u01ef\u01ed\u01c3\u01f6\u01e6\u01e2\u01e5\u01f3\u01c9\u01de\u01ee\u01b1\u01b9\u01d7\u01d3\u01fe\u01d8\u0206\u0203\u01c4\u01d0\u01f4\u01c8\u01f7\u01ed\u01db\u01f6\u01f9\u0205\u01e6\u01e3\u0201\u01d8\u01d9", (byte)115, 66);
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[7] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0585\u0594\u0566\u059f\u058b\u05ad\u0568\u0587\u056a\u057d\u05ad\u0589\u058f\u058d\u0588\u05ad\u058d\u0571\u0596\u05a9\u059d\u05bb\u0582\u0583", (byte)115, 70);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u05a7\u0582\u057b\u0567\u0582\u0587\u05a1\u056e\u0587\u05ac\u059e\u05a7\u056b\u059f\u0584\u058c\u0584\u058a\u05b9\u0576\u0596\u0599\u0576\u0593\u0596\u05a2\u05ba\u05bd\u058e\u05a6\u057f\u05a7", (byte)115, 70);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03a8\u03bc\u03c7\u039b\u03a9\u03a0\u03c9\u03b9\u03bd.d[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0585\u0566\u0576\u05a9\u0586\u05a5\u058c\u059c\u0588\u058c\u059c\u0571\u059c\u0589\u05a0\u05a5\u058b\u0597\u0594\u05b9\u056e\u05b8\u05b8\u05a8\u05b9\u058b\u05b2\u059a\u05c2\u05c4\u057e\u0597", (byte)115, 69);
                }
            }
        }
    }
}

