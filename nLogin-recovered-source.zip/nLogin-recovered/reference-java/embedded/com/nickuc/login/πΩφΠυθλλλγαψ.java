/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;

class \u03c0\u03a9\u03c6\u03a0\u03c5\u03b8\u03bb\u03bb\u03bb\u03b3\u03b1\u03c8 {
    private static int b;
    static final /* synthetic */ int[] h;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 512 >>> 200 | 512 << -200;
        h = new int[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.values().length];
        try {
            \u03c0\u03a9\u03c6\u03a0\u03c5\u03b8\u03bb\u03bb\u03bb\u03b3\u03b1\u03c8.h[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.c.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c0\u03a9\u03c6\u03a0\u03c5\u03b8\u03bb\u03bb\u03bb\u03b3\u03b1\u03c8.h[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.d.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

