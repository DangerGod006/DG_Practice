/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.caffeine.cache.Cache
 *  com.nickuc.login.lib.caffeine.cache.Caffeine
 */
package com.nickuc.login;

import com.nickuc.login.lib.caffeine.cache.Cache;
import com.nickuc.login.lib.caffeine.cache.Caffeine;
import com.nickuc.login.\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be {
    private static long h;
    private static long d;
    private static int l;
    private static String[] a;
    private static long j;
    private static int f;
    private static long e;
    private static int a;
    private static long c;
    private static int g;
    private static String[] b;
    private static final Cache<String, \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9> j;
    private static long n;
    private static long o;
    private static int i;
    private static int b;
    private static int m;
    private static final Cache<String, \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5> i;
    private static long k;

    static {
        a = (0 >>> 15 | 0 << ~15 + 1) & 0xFFFFFFFF;
        b = 0 >>> 118 | 0 << -118;
        d = Long.reverse(-1574197329411762470L);
        e = Long.reverse(0x3C00000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = (-1 >>> 173 | -1 << -173) & 0xFFFFFFFF;
        h = Long.reverse(-3015349210170321190L);
        i = 524288 >>> 50 | 524288 << -50;
        j = Long.reverse(-1574197329411762470L);
        k = Long.reverse(0x3C00000000000000L);
        l = Integer.reverse(-1073741824);
        m = Integer.reverse(-1073741824);
        n = Long.reverse(-1152921504606846976L);
        o = Long.reverse(-5476377146882523136L);
        a = new String[l];
        b = new String[m];
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b();
        i = (int)Caffeine.newBuilder().expireAfterWrite(n, TimeUnit.SECONDS).build();
        j = (long)Caffeine.newBuilder().expireAfterWrite(o, TimeUnit.SECONDS).build();
    }

    public static \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9 a(String string, InetAddress inetAddress) {
        String string2 = string + inetAddress.getHostAddress();
        \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9 \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92 = (\u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9)((Object)j.getIfPresent((Object)string2));
        return \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92 != null ? \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92 : \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9.a;
    }

    private static void b() {
        int n;
        c = 6586743640856126551L;
        long l = c ^ 0xC74882D7F9436329L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(40 + 28), (byte)(21 + 48), (byte)(29 + 54), (byte)(41 + 6), (byte)(49 + 18), 66, 67, (byte)(16 + 31), (byte)(71 + 9), (byte)(29 + 46), (byte)(23 + 44), (byte)(29 + 54), (byte)(48 + 5), (byte)(65 + 15), (byte)(47 + 50), (byte)(53 + 47), (byte)(3 + 97), (byte)(8 + 97), (byte)(96 + 14), (byte)(19 + 84)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(43 + 25), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0541\u0555\u0574\u0544\u057d\u0571\u0554\u0576\u0557\u0551\u0578\u0547", (byte)67, 69);
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0544\u055a\u0544\u0543\u0565\u0557\u0556\u057e\u0555\u0578\u0570\u0547", (byte)67, 70);
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[2] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0537\u0530\u0573\u0577\u054a\u0546\u0552\u056a\u0558\u0541\u0552\u0547", (byte)67, 69);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u04b0\u04cd\u04c7\u04e3\u04e3\u04d1\u04b4\u04c6\u04bd\u04bb\u04bc\u04d6\u04ed\u04bb\u0502\u04d9\u04f7\u04d8\u04e6\u04c0\u04db\u04e4\u04d1\u04d2", (byte)67, 67);
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u056b\u0559\u0562\u054d\u0565\u0578\u056f\u0555\u057a\u0540\u0552\u0547", (byte)67, 70);
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0173\u0157\u0139\u0138\u014e\u014d\u0141\u0176\u017b\u0147\u0175\u015f\u0146\u017d\u014b\u015f\u017f\u018c\u015a\u014e\u0181\u0181\u0158\u0159", (byte)67, 65);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u056e\u054a\u0569\u054c\u0538\u0577\u0554\u0572\u0532\u0571\u055e\u0547", (byte)67, 70);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u04d5\u04d5\u04f5\u04ec\u04e8\u04c9\u04d5\u04de\u04dc\u04e9\u04d4\u04b9\u04e0\u04f2\u04ce\u04fa\u0504\u04e9\u0502\u04f6\u04f3\u04d4\u04d1\u04d2", (byte)67, 68);
                }
            }
        }
    }

    private static void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, String string, String string2, Enum<?> enum_) {
        \u03a0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5 \u03c0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a();
        if (\u03c0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5 != null) {
            \u03c0\u03c3\u03b4\u03c5\u03a3\u03c3\u03c8\u03b2\u03c1\u03c4\u03a6\u03b4\u03bf\u0394\u03c5.a(a, jSONObject -> {
                jSONObject.put((String)\u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.c("\u3e80", (int)b, (long)(d ^ e)), (Object)string);
                jSONObject.put((String)\u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.c("\u3e83", (int)(f & g), (long)h), (Object)string2);
                jSONObject.put((String)\u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.c("\u3e86", (int)i, (long)(j ^ k)), (Object)enum_.name());
            });
        }
    }

    public static void a(String string, String string2, \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9 \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92) {
        String string3 = string + string2;
        if (\u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92 != \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9.a) {
            j.put((Object)string3, (Object)\u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92);
        } else {
            j.invalidate((Object)string3);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x3CL;
        l ^= 0xC74882D7F9436329L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(7 + 62), (byte)(71 + 12), (byte)(11 + 36), (byte)(11 + 56), (byte)(14 + 52), (byte)(5 + 62), (byte)(21 + 26), (byte)(64 + 16), (byte)(63 + 12), (byte)(7 + 60), (byte)(42 + 41), (byte)(35 + 18), (byte)(50 + 30), (byte)(2 + 95), (byte)(59 + 41), 100, (byte)(93 + 12), (byte)(92 + 18), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(26 + 43), (byte)(28 + 55)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0134\u0141\u0140\u0103\u0143\u013f\u013a\u0143\u014e\u013d\u010a\u0148\u014c\u0145\u0148\u014e\u0110\u049f\u049d\u04a7\u048e\u04a3\u04a4\u04a7\u04b1\u04a8", (byte)41, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, String string, InetAddress inetAddress, \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5) {
        String string2 = inetAddress.getHostAddress();
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, string, string2, \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5);
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(string, string2, \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5);
    }

    public static void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, String string, InetAddress inetAddress, \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c9 \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92) {
        String string2 = inetAddress.getHostAddress();
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, string, string2, \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92);
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(string, string2, \u03c4\u03c3\u03a6\u03b6\u03c7\u03b2\u03bc\u03b8\u03bd\u03b1\u03b6\u03bc\u03b8\u03c92);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0545\u0567\u0569\u0549\u056d\u058c\u0584\u059a\u0586\u0555\u0593\u0589\u0597\u0591\u055a\u057f\u05a1\u05a0\u0598\u059e\u0598\u056d", (byte)97, 70), \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01a4\u01b1\u01b0\u0173\u01b3\u01af\u01aa\u01b3\u01be\u01ad\u017a\u01b8\u01bc\u01b5\u01b8\u01be\u0180\u050f\u050d\u0517\u04fe\u0513\u0514\u0517\u0521\u0518\u0195", (byte)97, 66) + string + \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u017b", (byte)97, 65) + methodType.toString(), exception);
        }
    }

    public static void a(String string, String string2, \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5) {
        String string3 = string + string2;
        if (\u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 != \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a) {
            i.put((Object)string3, (Object)\u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5);
        } else {
            i.invalidate((Object)string3);
        }
    }

    public static \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 a(String string, InetAddress inetAddress) {
        String string2 = string + inetAddress.getHostAddress();
        \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 = (\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5)((Object)i.getIfPresent((Object)string2));
        return \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 != null ? \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 : \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a;
    }
}

