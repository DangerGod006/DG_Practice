/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.platform.VelocityLoader
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.loader.platform.VelocityLoader;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import lombok.Generated;

public class \u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9
implements \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 {
    private final \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 d = new \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2();
    private final VelocityLoader b;

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, long l2, TimeUnit timeUnit) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, consumer).a(this.b, l, l2, timeUnit);
    }

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Runnable runnable, long l, long l2, TimeUnit timeUnit) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, runnable).a(this.b, l, l2, timeUnit);
    }

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, consumer).a(this.b);
    }

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, TimeUnit timeUnit) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, consumer).a(this.b, l, timeUnit);
    }

    @Override
    public void Y() {
        this.f().forEach(\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be::Z);
    }

    @Override
    public \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a() {
        return this.d;
    }

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Runnable runnable, long l, TimeUnit timeUnit) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, runnable).a(this.b, l, timeUnit);
    }

    @Generated
    public \u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9(VelocityLoader velocityLoader) {
        this.b = velocityLoader;
    }

    @Override
    public \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be a(Runnable runnable) {
        return new \u03c6\u03bb\u03c6\u03bf\u03c1\u03bd\u03b5\u03c1\u03b4\u03b4\u03c9\u03b5\u03b9\u03be(this.d, runnable).a(this.b);
    }
}

