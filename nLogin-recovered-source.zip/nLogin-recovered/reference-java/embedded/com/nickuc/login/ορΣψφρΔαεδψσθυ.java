/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5 {
    private static int z;
    private static int ay;
    private static int w;
    private static int g;
    private static int i;
    private static long af;
    private static int o;
    private static String[] b;
    private static long f;
    private static int e;
    private static int r;
    private static int q;
    private static int ae;
    private static int y;
    private static int ad;
    private static int ar;
    private static long ag;
    private static int al;
    private static long ba;
    private static int aq;
    private static long x;
    public static final String cH;
    private static long as;
    private static int u;
    private static long av;
    public static final boolean aF;
    private static long s;
    private static long aw;
    private static long ap;
    private static long aj;
    public static final boolean aG;
    public static boolean aE;
    private static int v;
    private static int n;
    private static int ai;
    private static int a;
    private static String[] a;
    private static int ac;
    private static long p;
    private static int b;
    private static long ak;
    public static final String cI;
    private static int ax;
    private static long d;
    private static int ah;
    private static int l;
    private static long ab;
    private static long at;
    private static int aa;
    private static int au;
    private static int h;
    private static int am;
    private static int j;
    private static long c;
    private static int m;
    private static long t;
    private static int an;
    private static long ao;
    private static int az;
    private static int k;

    private static String a(int n, long l) {
        l ^= 0x5EL;
        l ^= 0xB127676842AC48FEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(42 + 26), (byte)(13 + 56), (byte)(37 + 46), (byte)(11 + 36), (byte)(4 + 63), (byte)(21 + 45), (byte)(60 + 7), (byte)(14 + 33), (byte)(76 + 4), (byte)(2 + 73), (byte)(46 + 21), (byte)(80 + 3), (byte)(43 + 10), (byte)(58 + 22), (byte)(14 + 83), (byte)(77 + 23), (byte)(20 + 80), 105, (byte)(15 + 95), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(58 + 11), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u00f2\u00ff\u00fe\u00c1\u0101\u00fd\u00f8\u0101\u010c\u00fb\u00c8\u0106\u010a\u0103\u0106\u010c\u00ce\u045f\u0462\u0445\u046b\u046a\u0466\u043a\u0458\u045d\u045d\u0472\u046e\u0464\u0472", (byte)8, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u03ef\u0411\u0413\u03f3\u0417\u0436\u042e\u0444\u0430\u03ff\u043d\u0433\u0441\u043b\u0404\u0429\u044b\u044a\u0442\u0448\u0442\u0417", (byte)6, 67), \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u0525\u0532\u0531\u04f4\u0534\u0530\u052b\u0534\u053f\u052e\u04fb\u0539\u053d\u0536\u0539\u053f\u0501\u0892\u0895\u0878\u089e\u089d\u0899\u086d\u088b\u0890\u0890\u08a5\u08a1\u0897\u08a5\u051b", (byte)6, 69) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u04fc", (byte)6, 69) + methodType.toString(), exception);
        }
    }

    static {
        a = 0 >>> 245 | 0 << ~245 + 1;
        b = Integer.reverse(-1);
        d = Long.reverse(-6363513138596340089L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(-6363513138596340089L);
        g = 16384 >>> 174 | 16384 << ~174 + 1;
        h = Integer.reverse(0);
        i = 0 >>> 134 | 0 << ~134 + 1;
        j = 0x18000000 >>> 89 | 0x18000000 << ~89 + 1;
        k = 0xC00000 >>> 244 | 0xC00000 << ~244 + 1;
        l = (65536 >>> 175 | 65536 << ~175 + 1) & 0xFFFFFFFF;
        m = 0 >>> 64 | 0 << -64;
        n = Integer.reverse(0x40000000);
        o = (-1 >>> 212 | -1 << ~212 + 1) & 0xFFFFFFFF;
        p = Long.reverse(-6363513138596340089L);
        q = (512 >>> 41 | 512 << ~41 + 1) & 0xFFFFFFFF;
        r = Integer.reverse(-1073741824);
        s = Long.reverse(-2472403060548231545L);
        t = Long.reverse(0x7A00000000000000L);
        u = Integer.reverse(0x40000000);
        v = 0 >>> 96 | 0 << -96;
        w = Integer.reverse(0x20000000);
        x = Long.reverse(-6363513138596340089L);
        y = (0x200000 >>> 117 | 0x200000 << -117) & 0xFFFFFFFF;
        z = (0x40000001 >>> 222 | 0x40000001 << ~222 + 1) & 0xFFFFFFFF;
        aa = Integer.reverse(-1);
        ab = Long.reverse(-6363513138596340089L);
        ac = (128 >>> 38 | 128 << ~38 + 1) & 0xFFFFFFFF;
        ad = Integer.reverse(0);
        ae = 6144 >>> 234 | 6144 << ~234 + 1;
        af = Long.reverse(-2472403060548231545L);
        ag = Long.reverse(0x7A00000000000000L);
        ah = Integer.reverse(Integer.MIN_VALUE);
        ai = Integer.reverse(-536870912);
        aj = Long.reverse(-2472403060548231545L);
        ak = Long.reverse(0x7A00000000000000L);
        al = 0x10000000 >>> 91 | 0x10000000 << ~91 + 1;
        am = Integer.reverse(0);
        an = Integer.reverse(0x10000000);
        ao = Long.reverse(-2472403060548231545L);
        ap = Long.reverse(0x7A00000000000000L);
        aq = 0x20000000 >>> 189 | 0x20000000 << -189;
        ar = Integer.reverse(-1879048192);
        as = Long.reverse(-2472403060548231545L);
        at = Long.reverse(0x7A00000000000000L);
        au = Integer.reverse(0x50000000);
        av = Long.reverse(-2472403060548231545L);
        aw = Long.reverse(0x7A00000000000000L);
        ax = (131072 >>> 49 | 131072 << -49) & 0xFFFFFFFF;
        ay = (0 >>> 69 | 0 << -69) & 0xFFFFFFFF;
        az = Integer.reverse(-805306368);
        ba = Long.reverse(-6363513138596340089L);
        a = new String[j];
        b = new String[k];
        \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b();
        String[] stringArray = new String[l];
        stringArray[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.m] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e80", (int)(n & o), (long)p);
        stringArray[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.q] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e83", (int)r, (long)(s ^ t));
        aE = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a(stringArray);
        String[] stringArray2 = new String[u];
        stringArray2[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.v] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e86", (int)w, (long)x);
        stringArray2[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.y] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e89", (int)(z & aa), (long)ab);
        aF = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a(stringArray2);
        String[] stringArray3 = new String[ac];
        stringArray3[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.ad] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e8c", (int)ae, (long)(af ^ ag));
        stringArray3[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.ah] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e8f", (int)ai, (long)(aj ^ ak));
        aG = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a(stringArray3);
        String[] stringArray4 = new String[al];
        stringArray4[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.am] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e92", (int)an, (long)(ao ^ ap));
        stringArray4[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.aq] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e95", (int)ar, (long)(as ^ at));
        cH = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a(null, stringArray4);
        String[] stringArray5 = new String[ax];
        stringArray5[\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.ay] = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e9b", (int)az, (long)ba);
        cI = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a((String)\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e98", (int)au, (long)(av ^ aw)), stringArray5);
    }

    private static boolean a(String ... stringArray) {
        String string = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.a(null, stringArray);
        return (((String)\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e80", (int)(a & b), (long)d)).equals(string) || ((String)\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.c("\u3e83", (int)e, (long)f)).equalsIgnoreCase(string) ? g : h) != 0;
    }

    private static void b() {
        int n;
        c = -2199737593954693701L;
        long l = c ^ 0xB127676842AC48FEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(32 + 36), (byte)(17 + 52), (byte)(33 + 50), (byte)(44 + 3), 67, (byte)(52 + 14), (byte)(64 + 3), (byte)(4 + 43), (byte)(45 + 35), (byte)(17 + 58), (byte)(24 + 43), (byte)(78 + 5), 53, (byte)(73 + 7), (byte)(63 + 34), (byte)(26 + 74), (byte)(99 + 1), (byte)(89 + 16), (byte)(66 + 44), (byte)(38 + 65)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(39 + 29), (byte)(29 + 40), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0555\u0563\u0594\u0585\u059c\u0579\u058b\u0589\u058e\u0559\u057f\u0568", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u05a5\u0582\u05ad\u05ae\u05b3\u05ae\u0587\u0586\u05b5\u05a9\u0584\u057d", (byte)121, 69);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u059a\u057b\u058f\u0583\u058c\u05a3\u056e\u057f\u05a5\u0569\u05b7\u05a7\u05a2\u059a\u0576\u05bd\u05b2\u05bd\u05ab\u057a\u058e\u0599\u05bd\u059c\u0578\u05b6\u0581\u05a8\u05a5\u05a5\u05ac\u058d\u05a7\u05a0\u058d\u05c7\u05a1\u0593\u058d\u05aa\u05a1\u05b4\u058f\u059d", (byte)121, 70);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0552\u0566\u0597\u058c\u0559\u0589\u058e\u056d\u0576\u05a3\u0592\u0556\u0583\u0576\u0591\u0599\u0581\u058b\u0568\u0583\u0578\u05a1\u057c\u0589\u0587\u0590\u0571\u0592\u05af\u056c\u058f\u058a\u05a9\u0597\u059b\u0586\u05bd\u05ac\u05be\u05ad\u05c0\u05a2\u059b\u0588", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[4] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0567\u057f\u056d\u057d\u05a0\u056b\u056b\u05ae\u0576\u0582\u05b6\u05b7\u05b0\u0584\u0586\u058e\u057e\u0578\u057f\u05ae\u059a\u058d\u059e\u05ae\u0583\u05c5\u0580\u059a\u0596\u0599\u0585\u05a2\u058d\u05a6\u05ab\u05bf\u05d0\u05c4\u05a2\u05af\u05ae\u05c5\u05c2\u059d", (byte)121, 69);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0566\u05a3\u05a4\u0587\u0570\u058e\u059f\u056f\u05a8\u05b0\u0577\u0595\u0573\u0576\u05ad\u05a9\u0588\u05aa\u05ae\u05b2\u0580\u0591\u05b2\u0582\u057e\u05c6\u0580\u05c6\u05aa\u05a0\u0587\u05a1\u05c6\u0598\u0599\u058b\u05a2\u05cc\u0593\u05be\u05ca\u05c7\u05a4\u059d", (byte)121, 69);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0565\u058b\u0569\u05a1\u059a\u0590\u058e\u058b\u05a2\u05a2\u0599\u058a\u0584\u0589\u0579\u0577\u0597\u0576\u057b\u0597\u05bb\u05c4\u057e\u05bd\u05bf\u05a2\u05b0\u059e\u05c1\u05c2\u0596\u059c\u058a\u05ad\u05c4\u05a8\u05a4\u058e\u05a8\u05c9\u05cc\u058e\u05d2\u059d", (byte)121, 69);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[7] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u056c\u05ab\u059a\u056c\u05a5\u059c\u0595\u0590\u058e\u0572\u05b4\u05b5\u0592\u05aa\u057c\u056f\u057c\u0599\u05bb\u0593\u059b\u058d\u05a0\u0596\u05bb\u05b0\u05a8\u0580\u05c4\u05b9\u05a9\u05c2", (byte)121, 70);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[8] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0591\u0578\u0599\u057a\u059d\u057e\u055d\u0560\u05a2\u0577\u0577\u0572\u0584\u055c\u0595\u0577\u05a7\u0589\u0584\u0586\u055f\u058c\u0578\u0566\u05a4\u057d\u0588\u05b0\u05ae\u05b4\u05a0\u05b7", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[9] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u057c\u05ac\u0584\u05a9\u05b2\u0583\u05ac\u0592\u05ae\u058b\u05b4\u05a3\u0587\u05bb\u05ac\u05b0\u05bd\u0595\u0576\u05b8\u0598\u05b1\u0588\u0589", (byte)121, 70);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[10] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0584\u0595\u058d\u0571\u0591\u059d\u0567\u058d\u0560\u055a\u059d\u0576\u0590\u0565\u05a1\u0591\u0582\u059c\u0598\u0599\u0588\u05a2\u0580\u0562\u058f\u05a3\u059d\u057c\u05b4\u05a7\u05b3\u0577\u05ba\u0573\u0579\u05a4\u057a\u05b3\u0588\u0599\u0577\u0590\u05c3\u05a5\u05a3\u059b\u05b6\u0582\u0594\u059e\u057d\u05cd\u05c6\u0596\u0593\u0594", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[11] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0569\u0567\u055a\u054e\u0557\u0590\u056d\u058f\u0569\u056a\u0583\u0577\u0576\u0581\u0573\u0579\u055b\u05a5\u0589\u05ab\u058b\u059a\u05ac\u059e\u057e\u05ab\u059c\u0592\u0585\u056e\u058a\u05b1\u05a7\u05b8\u05a5\u05a8\u0590\u05bd\u058e\u05a8\u0592\u057f\u05ad\u0588", (byte)121, 67);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u01e4\u01b3\u01d8\u01db\u01d9\u01bb\u01c7\u01bf\u01df\u01ef\u01ea\u01b9", (byte)121, 65);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0595\u0596\u059b\u0554\u0553\u0576\u0580\u0570\u057f\u0595\u058b\u055b\u0592\u0576\u0594\u0593\u05a2\u057d\u0566\u05ac\u05a2\u059c\u0573\u0574", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0585\u0566\u057a\u056e\u0577\u058e\u0559\u056a\u0590\u0554\u05a2\u0592\u058d\u0585\u0561\u05a8\u059d\u05a8\u0596\u0565\u0579\u0584\u05a8\u0587\u0563\u05a1\u056c\u0593\u0590\u0590\u0597\u0578\u0598\u0576\u05a5\u0596\u0593\u0594\u058a\u057e\u05a2\u0596\u057a\u0588", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[3] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0552\u0566\u0597\u058c\u0559\u0589\u058e\u056d\u0576\u05a3\u0592\u0556\u0583\u0576\u0591\u0599\u0581\u058b\u0568\u0583\u0578\u05a1\u057c\u0589\u0587\u0590\u0571\u0592\u05af\u056c\u058f\u058a\u05b8\u05a7\u05aa\u05ac\u0595\u058e\u057e\u05b7\u05be\u05ab\u05ae\u059f\u05b6\u05be\u05bc\u05a4\u057b\u05c1\u059b\u0587\u05aa\u05a6\u0593\u0594", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[4] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0552\u056a\u0558\u0568\u058b\u0556\u0556\u0599\u0561\u056d\u05a1\u05a2\u059b\u056f\u0571\u0579\u0569\u0563\u056a\u0599\u0585\u0578\u0589\u0599\u056e\u05b0\u056b\u0585\u0581\u0584\u0570\u058d\u05ab\u0579\u0575\u05bd\u05b8\u05a9\u05ac\u057e\u059f\u058b\u057e\u0588", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0566\u05a3\u05a4\u0587\u0570\u058e\u059f\u056f\u05a8\u05b0\u0577\u0595\u0573\u0576\u05ad\u05a9\u0588\u05aa\u05ae\u05b2\u0580\u0591\u05b2\u0582\u057e\u05c6\u0580\u05c6\u05aa\u05a0\u0587\u05a1\u05c9\u05cd\u05af\u05a1\u0584\u05c3\u059c\u05a7\u05a7\u059f\u05c2\u059d", (byte)121, 69);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0550\u0576\u0554\u058c\u0585\u057b\u0579\u0576\u058d\u058d\u0584\u0575\u056f\u0574\u0564\u0562\u0582\u0561\u0566\u0582\u05a6\u05af\u0569\u05a8\u05aa\u058d\u059b\u0589\u05ac\u05ad\u0581\u0587\u0599\u0598\u05b8\u0596\u058f\u0587\u0588\u0597\u059b\u05b0\u0597\u0588", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u01a8\u01e7\u01d6\u01a8\u01e1\u01d8\u01d1\u01cc\u01ca\u01ae\u01f0\u01f1\u01ce\u01e6\u01b8\u01ab\u01b8\u01d5\u01f7\u01cf\u01d7\u01d6\u01ee\u01f7\u01bc\u0202\u01c1\u01f3\u0205\u01e6\u01ff\u0202\u0201\u01dc\u020a\u01d9\u01ed\u01e8\u01e7\u01ee\u01e9\u01e6\u01e8\u01d9", (byte)121, 66);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u01e2\u01c9\u01ea\u01cb\u01ee\u01cf\u01ae\u01b1\u01f3\u01c8\u01c8\u01c3\u01d5\u01ad\u01e6\u01c8\u01f8\u01da\u01d5\u01d7\u01b0\u01da\u01dd\u01f2\u01d2\u01dd\u01e2\u01c5\u0200\u01f5\u01f9\u0200", (byte)121, 66);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[9] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0567\u0597\u056f\u0594\u059d\u056e\u0597\u057d\u0599\u0576\u059d\u0593\u0598\u055d\u0577\u0567\u0595\u05a5\u0576\u057f\u05a4\u0599\u0567\u0567\u05a7\u0582\u05a5\u0580\u056e\u05a3\u0591\u0588", (byte)121, 68);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[10] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0584\u0595\u058d\u0571\u0591\u059d\u0567\u058d\u0560\u055a\u059d\u0576\u0590\u0565\u05a1\u0591\u0582\u059c\u0598\u0599\u0588\u05a2\u0580\u0562\u058f\u05a3\u059d\u057c\u05b4\u05a7\u05b3\u0577\u05ba\u0573\u0579\u05a4\u057a\u05b3\u0588\u0599\u0577\u0590\u05c4\u058c\u05b6\u05ba\u05b4\u05bf\u05a6\u05c5\u059f\u0599\u05aa\u0596\u0593\u0594", (byte)121, 67);
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[11] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u057e\u057c\u056f\u0563\u056c\u05a5\u0582\u05a4\u057e\u057f\u0598\u058c\u058b\u0596\u0588\u058e\u0570\u05ba\u059e\u05c0\u05a0\u05af\u05c1\u05b3\u0593\u05c0\u05b1\u05a7\u059a\u0583\u059f\u05c6\u05c8\u05bc\u05ab\u05ca\u059a\u059e\u058e\u05b1\u05d1\u0591\u05a8\u059d", (byte)121, 69);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u019c\u01db\u01c4\u01e1\u01ca\u01d7\u01a9\u01c1\u01da\u01eb\u01e6\u01ee\u01d1\u01ca\u01f3\u01c3\u01da\u01f9\u01dd\u01b4\u01ca\u01fd\u01c4\u01c5", (byte)121, 65);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0581\u0592\u0570\u058f\u0574\u0590\u056e\u0572\u0572\u05a3\u0596\u0581\u05a2\u0566\u05a1\u059c\u05a8\u0572\u059e\u057b\u0576\u0576\u0573\u0574", (byte)121, 68);
                }
            }
        }
    }

    private static String a(String string, String ... stringArray) {
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        for (int i = \u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.i; i < n; ++i) {
            String string2 = stringArray2[i];
            String string3 = System.getProperty(string2);
            if (string3 == null) continue;
            return string3;
        }
        return string;
    }
}

