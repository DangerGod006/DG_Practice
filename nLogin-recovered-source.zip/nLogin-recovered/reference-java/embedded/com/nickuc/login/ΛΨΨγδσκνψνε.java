/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5
extends Enum<\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5> {
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 a;
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 b;
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 c;
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 d;
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 e;
    public static final /* enum */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 f;
    private static final /* synthetic */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static long k;
    private static long l;
    private static int m;
    private static int n;
    private static long o;
    private static int p;
    private static int q;
    private static long r;
    private static long s;
    private static int t;
    private static int u;
    private static int v;
    private static long w;
    private static int x;
    private static int y;
    private static int z;
    private static long aa;
    private static int ab;
    private static int ac;
    private static long ad;
    private static long ae;
    private static int af;

    private static /* synthetic */ \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[] a() {
        \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[] \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[a];
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b] = a;
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.c] = b;
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.d] = c;
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.e] = d;
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.f] = e;
        \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array[\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.g] = f;
        return \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5Array;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0511\u0533\u0535\u0515\u0539\u0558\u0550\u0566\u0552\u0521\u055f\u0555\u0563\u055d\u0526\u054b\u056d\u056c\u0564\u056a\u0564\u0539", (byte)45, 70), \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u013c\u0149\u0148\u010b\u014b\u0147\u0142\u014b\u0156\u0145\u0112\u0150\u0154\u014d\u0150\u0156\u0118\u0485\u0493\u0494\u04a0\u04a2\u04b2\u04aa\u04ae\u04ba\u04b0\u04a9\u012f", (byte)45, 66) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0476", (byte)45, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 8077157188477979915L;
        long l = c ^ 0xD134174F9DC2AB51L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(26 + 43), (byte)(74 + 9), (byte)(3 + 44), (byte)(60 + 7), (byte)(31 + 35), (byte)(24 + 43), (byte)(22 + 25), (byte)(12 + 68), (byte)(8 + 67), (byte)(35 + 32), (byte)(28 + 55), 53, (byte)(21 + 59), (byte)(69 + 28), (byte)(53 + 47), (byte)(71 + 29), (byte)(28 + 77), (byte)(16 + 94), (byte)(78 + 25)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(27 + 41), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u054b\u0527\u051c\u0546\u0544\u0516\u0552\u0545\u0548\u0559\u0512\u0520", (byte)28, 69);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0439\u043b\u045c\u044d\u0458\u0471\u0463\u0466\u0477\u0489\u0443\u047f\u0462\u0441\u0471\u0491\u046c\u0461\u0472\u0495\u0468\u0495\u045c\u045d", (byte)28, 67);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[2] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u012b\u00f0\u010a\u0121\u0114\u0112\u0127\u00ed\u0102\u012f\u0137\u0106\u0115\u0129\u012a\u00fd\u0121\u00f7\u0136\u013a\u0119\u0133\u010a\u010b", (byte)28, 65);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0128\u00f1\u0112\u00fe\u0104\u00ec\u012d\u0108\u012b\u00f4\u0133\u0123\u00f5\u0129\u0107\u0120\u010a\u00fe\u0130\u0122\u0112\u0133\u010a\u010b", (byte)28, 66);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0439\u0474\u043c\u046f\u043e\u047e\u043f\u0483\u0447\u0480\u0476\u0451", (byte)28, 67);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u00f0\u0106\u0103\u012e\u0132\u00f4\u00ef\u0136\u010c\u0128\u0106\u00ff", (byte)28, 65);
                    continue block7;
                }
                case 1: {
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u051a\u0553\u0542\u0510\u0528\u0547\u054a\u0559\u0544\u0532\u0546\u053b\u0530\u051b\u0519\u053b\u051d\u0521\u051d\u0534\u0555\u0554\u052b\u052c", (byte)28, 69);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00e7\u00e9\u010a\u00fb\u0106\u011f\u0111\u0114\u0125\u0137\u00f1\u0114\u0129\u0114\u0134\u0135\u0128\u00fd\u0102\u0121\u0110\u011d\u010a\u010b", (byte)28, 66);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u012b\u00f0\u010a\u0121\u0114\u0112\u0127\u00ed\u0102\u012f\u0136\u013a\u00fa\u0117\u0137\u012f\u00f8\u013b\u011d\u00f9\u00fa\u0133\u010a\u010b", (byte)28, 66);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u047a\u0443\u0464\u0450\u0456\u043e\u047f\u045a\u047d\u0446\u0482\u045d\u044a\u044d\u045f\u0450\u047f\u048f\u0492\u0481\u0452\u0495\u045c\u045d", (byte)28, 67);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[4] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u00fe\u0120\u00eb\u011f\u012f\u011f\u0108\u00ff\u0112\u00f4\u010e\u00ff", (byte)28, 66);
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[5] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u0123\u012c\u0113\u0133\u012f\u0110\u010d\u0125\u0123\u0133\u012b\u012b\u00ee\u013a\u00fb\u011a\u00fb\u00f9\u0112\u0130\u010e\u011d\u010a\u010b", (byte)28, 66);
                    continue block7;
                }
                case 2: {
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0101\u00fa\u011d\u0105\u011d\u00fe\u0122\u012b\u00ef\u0114\u0111\u00f9\u0111\u00f6\u0117\u0111\u013a\u0134\u00fd\u0102\u00fc\u00fb\u0125\u011f\u0106\u0145\u0128\u011a\u0143\u0146\u010b\u013f", (byte)28, 65);
                    continue block7;
                }
                case 4: {
                    \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u047b\u047e\u047c\u0441\u0440\u0477\u0480\u0476\u0472\u0469\u0486\u0483\u0480\u046d\u045c\u044f\u0463\u0487\u0488\u045d\u0495\u045f\u045c\u045d", (byte)28, 67);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0x60000000);
        b = 0 >>> 202 | 0 << -202;
        c = 4 >>> 34 | 4 << -34;
        d = Integer.reverse(0x40000000);
        e = Integer.reverse(-1073741824);
        f = Integer.reverse(0x20000000);
        g = Integer.reverse(-1610612736);
        h = 49152 >>> 109 | 49152 << ~109 + 1;
        i = Integer.reverse(0x60000000);
        j = (0 >>> 209 | 0 << -209) & 0xFFFFFFFF;
        k = Long.reverse(-3409052943842023410L);
        l = Long.reverse(0x4400000000000000L);
        m = Integer.reverse(0);
        n = (0x800000 >>> 119 | 0x800000 << -119) & 0xFFFFFFFF;
        o = Long.reverse(-7732508586117699570L);
        p = (8 >>> 3 | 8 << ~3 + 1) & 0xFFFFFFFF;
        q = (4 >>> 193 | 4 << ~193 + 1) & 0xFFFFFFFF;
        r = Long.reverse(-3409052943842023410L);
        s = Long.reverse(0x4400000000000000L);
        t = (1 >>> 223 | 1 << -223) & 0xFFFFFFFF;
        u = Integer.reverse(-1073741824);
        v = Integer.reverse(-1);
        w = Long.reverse(-7732508586117699570L);
        x = 0x3000000 >>> 24 | 0x3000000 << -24;
        y = (0x20000000 >>> 187 | 0x20000000 << ~187 + 1) & 0xFFFFFFFF;
        z = (-1 >>> 49 | -1 << -49) & 0xFFFFFFFF;
        aa = Long.reverse(-7732508586117699570L);
        ab = Integer.reverse(0x20000000);
        ac = 0x1400000 >>> 214 | 0x1400000 << ~214 + 1;
        ad = Long.reverse(-3409052943842023410L);
        ae = Long.reverse(0x4400000000000000L);
        af = 0x280000 >>> 83 | 0x280000 << ~83 + 1;
        a = new String[h];
        b = new String[i];
        \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b();
        a = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        b = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        c = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        d = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        e = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        f = new \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5();
        a = \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a();
    }

    public static \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[] values() {
        return (\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5[])a.clone();
    }

    private static String a(int n, long l) {
        l ^= 0x22L;
        l ^= 0xD134174F9DC2AB51L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(42 + 27), (byte)(30 + 53), (byte)(4 + 43), (byte)(32 + 35), (byte)(7 + 59), (byte)(7 + 60), (byte)(30 + 17), (byte)(26 + 54), (byte)(64 + 11), (byte)(62 + 5), 83, 53, (byte)(59 + 21), (byte)(47 + 50), (byte)(35 + 65), (byte)(71 + 29), (byte)(5 + 100), (byte)(58 + 52), (byte)(46 + 57)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(54 + 29)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u04a2\u04af\u04ae\u0471\u04b1\u04ad\u04a8\u04b1\u04bc\u04ab\u0478\u04b6\u04ba\u04b3\u04b6\u04bc\u047e\u07eb\u07f9\u07fa\u0806\u0808\u0818\u0810\u0814\u0820\u0816\u080f", (byte)46, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 valueOf(String string) {
        return Enum.valueOf(\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.class, string);
    }
}

