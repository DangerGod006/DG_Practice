/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.wrapper.configuration.client.WrapperConfigClientPluginMessage
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.wrapper.configuration.client.WrapperConfigClientPluginMessage;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private static String[] a;
    private static int a;
    final /* synthetic */ \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 a;
    private static long b;
    private static long d;
    private static int e;
    private static int f;
    private static long c;
    private static String[] b;
    private static int g;

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        WrapperConfigClientPluginMessage wrapperConfigClientPluginMessage = new WrapperConfigClientPluginMessage(packetReceiveEvent);
        String string = wrapperConfigClientPluginMessage.getChannelName();
        if (!string.equals(\u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.c("\u3e80", (int)a, (long)(b ^ d)))) {
            return;
        }
        Player player = (Player)packetReceiveEvent.getPlayer();
        if (player == null) {
            return;
        }
        packetReceiveEvent.setCancelled(e != 0);
        \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394.a(this.a).a().a(\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394.a(this.a).b().a(player), wrapperConfigClientPluginMessage.getData());
    }

    private static void b() {
        int n;
        c = 5786157169008203577L;
        long l = c ^ 0x32D1A23DDEB62556L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(52 + 17), (byte)(68 + 15), 47, (byte)(20 + 47), (byte)(44 + 22), (byte)(2 + 65), (byte)(6 + 41), (byte)(15 + 65), (byte)(44 + 31), (byte)(29 + 38), (byte)(77 + 6), (byte)(50 + 3), (byte)(76 + 4), (byte)(47 + 50), (byte)(83 + 17), (byte)(14 + 86), (byte)(72 + 33), (byte)(101 + 9), (byte)(88 + 15)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(49 + 19), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0536\u0532\u0541\u056a\u0521\u051d\u054a\u055b\u0548\u0566\u056c\u0540\u0573\u053f\u055d\u0551\u0545\u056d\u0569\u0538\u0579\u0553\u0540\u0541", (byte)104, 68);
                    continue block7;
                }
                case 1: {
                    \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u0198\u0194\u01a3\u01cc\u0183\u017f\u01ac\u01bd\u01aa\u01c8\u01cd\u01d1\u0191\u0192\u01ad\u0194\u0191\u01aa\u01b1\u01aa\u01a7\u01a5\u01a2\u01a3", (byte)104, 66);
                    continue block7;
                }
                case 2: {
                    \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u01b3\u01bf\u019f\u01a2\u01a4\u01c2\u01cc\u01c4\u01a3\u01a2\u019c\u01c1\u0193\u01b2\u01b5\u01d4\u0190\u01af\u01aa\u01af\u01d6\u01de\u019e\u01bc\u01d7\u01d1\u019d\u01cb\u01c4\u01e5\u0198\u01d5", (byte)104, 65);
                    continue block7;
                }
                case 4: {
                    \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u057c\u0587\u0574\u055e\u058b\u0560\u057b\u055a\u05a6\u057e\u0581\u0563\u0595\u059a\u05a0\u05aa\u0599\u05a6\u0582\u05ac\u05a4\u057a\u0577\u0578", (byte)104, 69);
                }
            }
        }
    }

    public \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7(\u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u0394 \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942) {
        this.a = \u03bf\u03bf\u03c5\u03c4\u03c7\u039b\u03ba\u03a3\u03b7\u0393\u03c8\u03bf\u03942;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u04f5\u0517\u0519\u04f9\u051d\u053c\u0534\u054a\u0536\u0505\u0543\u0539\u0547\u0541\u050a\u052f\u0551\u0550\u0548\u054e\u0548\u051d", (byte)17, 69), \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0530\u053d\u053c\u04ff\u053f\u053b\u0536\u053f\u054a\u0539\u0506\u0544\u0548\u0541\u0544\u054a\u050c\u0881\u0872\u089d\u089a\u0895\u089e\u088d\u0885\u089b\u087b\u0891\u0884\u08ab\u08a2\u0526", (byte)17, 69) + string + \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0507", (byte)17, 70) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x3DL;
        l ^= 0x32D1A23DDEB62556L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), (byte)(60 + 9), (byte)(53 + 30), (byte)(30 + 17), (byte)(20 + 47), (byte)(48 + 18), (byte)(4 + 63), 47, (byte)(42 + 38), (byte)(32 + 43), (byte)(46 + 21), (byte)(31 + 52), (byte)(29 + 24), (byte)(25 + 55), (byte)(52 + 45), (byte)(33 + 67), (byte)(82 + 18), (byte)(19 + 86), 110, (byte)(39 + 64)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(46 + 22), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u01ac\u01b9\u01b8\u017b\u01bb\u01b7\u01b2\u01bb\u01c6\u01b5\u0182\u01c0\u01c4\u01bd\u01c0\u01c6\u0188\u04fd\u04ee\u0519\u0516\u0511\u051a\u0509\u0501\u0517\u04f7\u050d\u0500\u0527\u051e", (byte)101, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-7139882647480618486L);
        d = Long.reverse(-4899916394579099648L);
        e = 0x100000 >>> 52 | 0x100000 << ~52 + 1;
        f = (32768 >>> 111 | 32768 << ~111 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03a3\u0393\u03bd\u03b9\u03b3\u03bb\u03a9\u03a0\u03b5\u0394\u03a9\u039b\u03c1\u03b7.b();
    }
}

