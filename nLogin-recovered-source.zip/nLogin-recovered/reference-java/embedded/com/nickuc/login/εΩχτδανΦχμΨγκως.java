/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c4;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
abstract class \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2
extends \u03c0\u03bd\u03c0\u03c6\u03b4\u03bb\u039b\u03c0\u03bd\u03c8 {
    private static int ac;
    private static int y;
    private static long ah;
    private static int aa;
    private static int t;
    private static int ad;
    private static int u;
    private static int v;
    private static int ag;
    private static int z;
    private static int ay;
    private static int ar;
    private static long w;
    private static long au;
    private static long ao;
    private static long av;
    private static String[] c;
    private static int k;
    private static long ab;
    private static int l;
    private static long ae;
    private static long as;
    private final String cu;
    private static int aw;
    private static int aj;
    private static long i;
    private static String[] d;
    private static int ai;
    private static long f;
    private static int ap;
    private static long af;
    private static int am;
    private static int ak;
    private static long ax;
    private static int r;
    private static int aq;
    private static int az;
    private static int c;
    private static long x;
    private static int at;
    private static long an;
    private static int s;
    private static long al;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u010b\u012d\u012f\u010f\u0133\u0152\u014a\u0160\u014c\u011b\u0159\u014f\u015d\u0157\u0120\u0145\u0167\u0166\u015e\u0164\u015e\u0133", (byte)50, 66), \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0551\u055e\u055d\u0520\u0560\u055c\u0557\u0560\u056b\u055a\u0527\u0565\u0569\u0562\u0565\u056b\u052d\u08b4\u08a9\u08c8\u08c6\u08b7\u08b5\u08c2\u08ac\u08ce\u08c4\u08b1\u08bd\u08c5\u08d5\u08cf\u0548", (byte)50, 70) + string + \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0485", (byte)50, 67) + methodType.toString(), exception);
        }
    }

    public String D(String string) {
        String string2 = \u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a(\u03b2\u03bb\u03c5\u03c2\u0393\u03c5\u03c6\u03b3\u03b6\u03c0\u03a9\u03a3\u03a0\u03a8\u03c4.c, ap);
        return this.j(string, string2);
    }

    private static String a(int n, long l) {
        l ^= 0x38L;
        l ^= 0x701CA9DFF217922EL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(8 + 61), (byte)(31 + 52), (byte)(37 + 10), (byte)(46 + 21), (byte)(60 + 6), (byte)(11 + 56), (byte)(11 + 36), 80, (byte)(18 + 57), (byte)(5 + 62), (byte)(50 + 33), (byte)(8 + 45), (byte)(54 + 26), (byte)(83 + 14), (byte)(43 + 57), (byte)(6 + 94), (byte)(23 + 82), 110, (byte)(87 + 16)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(78 + 5)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0144\u0151\u0150\u0113\u0153\u014f\u014a\u0153\u015e\u014d\u011a\u0158\u015c\u0155\u0158\u015e\u0120\u04a7\u049c\u04bb\u04b9\u04aa\u04a8\u04b5\u049f\u04c1\u04b7\u04a4\u04b0\u04b8\u04c8\u04c2", (byte)49, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    public String j(String string, String string2) {
        return (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e80", (int)(aq & ar), (long)as) + this.cu + (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e83", (int)at, (long)(au ^ av)) + this.E(this.E(string) + string2) + (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e86", (int)aw, (long)ax) + string2;
    }

    private static void b() {
        int n;
        f = -23555528395456640L;
        long l = f ^ 0x701CA9DFF217922EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(19 + 49), (byte)(13 + 56), 83, (byte)(23 + 24), (byte)(59 + 8), (byte)(48 + 18), (byte)(18 + 49), 47, (byte)(73 + 7), (byte)(12 + 63), (byte)(46 + 21), (byte)(32 + 51), (byte)(47 + 6), (byte)(6 + 74), (byte)(62 + 35), (byte)(66 + 34), (byte)(76 + 24), (byte)(71 + 34), (byte)(42 + 68), (byte)(37 + 66)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(18 + 65)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0549\u0543\u054f\u0550\u0563\u0564\u055e\u0565\u0561\u0554\u0556\u053f", (byte)59, 70);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u0146\u013f\u0162\u0150\u0170\u0133\u014a\u0142\u012e\u014e\u0176\u013d", (byte)59, 66);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0548\u0541\u0564\u0552\u0572\u0535\u054c\u0544\u0530\u0550\u0578\u053f", (byte)59, 69);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[3] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04d6\u04bf\u04b2\u04cf\u04df\u04c1\u04c1\u04a6\u04c4\u04e9\u04e7\u04ae", (byte)59, 68);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[4] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0165\u014e\u0141\u015e\u016e\u0150\u0150\u0135\u0153\u0178\u0176\u013d", (byte)59, 65);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u054e\u052d\u056b\u052c\u056c\u0549\u0566\u052d\u0578\u0553\u0532\u0538\u0552\u0548\u0575\u0574\u0550\u0578\u053d\u056e\u0579\u053d\u0583\u0586\u0587\u0554\u0572\u055f\u057b\u055f\u0581\u055b\u058d\u054b\u056c\u057d\u0569\u058f\u058a\u0564\u0571\u0591\u0550\u0563\u0565\u0558\u0597\u055a\u056e\u055c\u0582\u0584\u055c\u056d\u056a\u056b", (byte)59, 70);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[6] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u049f\u04bf\u04b5\u04d9\u04de\u04b6\u04af\u04b2\u04d6\u04b1\u04df\u04ae", (byte)59, 68);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[7] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0165\u014e\u0141\u015e\u016e\u0150\u0150\u0135\u0153\u0178\u0176\u013d", (byte)59, 66);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[8] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u0165\u014e\u0141\u015e\u016e\u0150\u0150\u0135\u0153\u0178\u0176\u013d", (byte)59, 65);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[9] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0567\u0550\u0543\u0560\u0570\u0552\u0552\u0537\u0555\u057a\u0578\u053f", (byte)59, 69);
                    continue block7;
                }
                case 1: {
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04b2\u04d7\u04e0\u04d7\u04b0\u04b4\u04bf\u04e3\u04bb\u049e\u04c9\u04ae", (byte)59, 68);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0125\u0158\u0169\u0129\u012a\u014b\u012c\u0132\u016b\u0148\u016a\u013d", (byte)59, 66);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0141\u014a\u013f\u015f\u012b\u0163\u0166\u0130\u0153\u014e\u014c\u013d", (byte)59, 66);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u04b6\u04d7\u04bf\u04a0\u0495\u04ba\u04b1\u0498\u04c4\u04d2\u04df\u04ae", (byte)59, 67);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[4] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0159\u0137\u013a\u0160\u0144\u012b\u013c\u0166\u0132\u016a\u012f\u013d", (byte)59, 65);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04bd\u049c\u04da\u049b\u04db\u04b8\u04d5\u049c\u04e7\u04c2\u04a1\u04a7\u04c1\u04b7\u04e4\u04e3\u04bf\u04e7\u04ac\u04dd\u04e8\u04ac\u04f2\u04f5\u04f6\u04c3\u04e1\u04ce\u04ea\u04ce\u04f0\u04ca\u04fc\u04ba\u04db\u04ec\u04d8\u04fe\u04f9\u04d3\u04e0\u0500\u04bf\u04f4\u0507\u04fe\u04e2\u04fc\u050f\u04da\u0502\u050b\u0508\u0502\u04d9\u04da", (byte)59, 68);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u052f\u056f\u055e\u055c\u0562\u052f\u053f\u0546\u0542\u055a\u0570\u053f", (byte)59, 70);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u04c0\u04af\u04bb\u04bf\u04cf\u04de\u04b9\u04a5\u04a6\u04b2\u04b5\u04ae", (byte)59, 67);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[8] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0148\u013c\u0168\u012b\u012c\u0164\u013c\u0152\u0153\u0148\u0137\u013d", (byte)59, 65);
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[9] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u0147\u0161\u016b\u0149\u016b\u012b\u0153\u014b\u0152\u0178\u014c\u013d", (byte)59, 65);
                    continue block7;
                }
                case 2: {
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u04a8\u04d0\u04ab\u04b0\u04cc\u04a3\u04e2\u04a1\u04b1\u04d9\u04c6\u04e5\u04a4\u04ba\u04df\u04cb\u04d8\u04c6\u04c1\u04f1\u04db\u04f2\u04b9\u04ba", (byte)59, 67);
                    continue block7;
                }
                case 4: {
                    \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u054b\u0565\u054f\u0574\u0546\u0552\u0557\u0568\u054b\u054c\u0571\u056f\u0548\u056e\u0558\u0552\u0557\u053d\u0580\u057e\u053e\u0556\u0557\u0566\u0566\u0566\u0544\u0589\u0564\u0578\u0559\u058d", (byte)59, 70);
                }
            }
        }
    }

    @Override
    public String w(String string) {
        return this.D(string);
    }

    protected \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2(String string, String string2) {
        super(string);
        this.cu = string2;
    }

    static {
        c = (0 >>> 87 | 0 << ~87 + 1) & 0xFFFFFFFF;
        i = Long.reverse(2161655893220537855L);
        k = Integer.reverse(-1073741824);
        l = 4 >>> 128 | 4 << -128;
        r = Integer.reverse(0);
        s = (0x20000000 >>> 221 | 0x20000000 << -221) & 0xFFFFFFFF;
        t = Integer.reverse(0);
        u = (256 >>> 7 | 256 << -7) & 0xFFFFFFFF;
        v = 0x100000 >>> 148 | 0x100000 << -148;
        w = Long.reverse(144043260158555647L);
        x = Long.reverse(0x1C00000000000000L);
        y = 0x800000 >>> 150 | 0x800000 << -150;
        z = 0x8000000 >>> 27 | 0x8000000 << ~27 + 1;
        aa = (0x4000000 >>> 25 | 0x4000000 << ~25 + 1) & 0xFFFFFFFF;
        ab = Long.reverse(2161655893220537855L);
        ac = Integer.reverse(0);
        ad = Integer.reverse(-1073741824);
        ae = Long.reverse(144043260158555647L);
        af = Long.reverse(0x1C00000000000000L);
        ag = Integer.reverse(0x20000000);
        ah = Long.reverse(2161655893220537855L);
        ai = Integer.reverse(-1073741824);
        aj = (5 >>> 224 | 5 << -224) & 0xFFFFFFFF;
        ak = (-1 >>> 80 | -1 << -80) & 0xFFFFFFFF;
        al = Long.reverse(2161655893220537855L);
        am = Integer.reverse(0x60000000);
        an = Long.reverse(144043260158555647L);
        ao = Long.reverse(0x1C00000000000000L);
        ap = Integer.reverse(0x18000000);
        aq = (114688 >>> 142 | 114688 << ~142 + 1) & 0xFFFFFFFF;
        ar = Integer.reverse(-1);
        as = Long.reverse(2161655893220537855L);
        at = (2 >>> 254 | 2 << ~254 + 1) & 0xFFFFFFFF;
        au = Long.reverse(144043260158555647L);
        av = Long.reverse(0x1C00000000000000L);
        aw = 1152 >>> 231 | 1152 << ~231 + 1;
        ax = Long.reverse(2161655893220537855L);
        ay = (10240 >>> 106 | 10240 << -106) & 0xFFFFFFFF;
        az = 40 >>> 130 | 40 << -130;
        c = new String[ay];
        d = new String[az];
        \u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.b();
    }

    public String E(String string) {
        return super.w(string);
    }

    @Override
    public boolean i(String string, String string2) {
        String[] stringArray = string2.split((String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e80", (int)c, (long)i));
        if (stringArray.length != k && stringArray.length != l) {
            return r != 0;
        }
        String string3 = stringArray[s];
        if (!string3.equalsIgnoreCase(this.cu)) {
            return t != 0;
        }
        String string4 = this.E(string);
        String string5 = stringArray[u];
        switch (stringArray.length) {
            case 3: {
                String[] stringArray2 = string2.split((String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e83", (int)v, (long)(w ^ x)));
                if (stringArray2.length == y) {
                    String string6 = stringArray2[z];
                    return string5.equals(this.E(string4 + string6) + (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e86", (int)aa, (long)ab) + string6);
                }
                if (stringArray2.length > 0) {
                    return stringArray2[ac].equals((String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e89", (int)ad, (long)(ae ^ af)) + string3 + (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e8c", (int)ag, (long)ah) + string4);
                }
                return string5.equals(string4);
            }
            case 4: {
                String string7 = stringArray[ai];
                return string5.equals(this.E(string4 + string7));
            }
        }
        throw new IllegalArgumentException((String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e8f", (int)(aj & ak), (long)al) + this.cm + (String)\u03b5\u03a9\u03c7\u03c4\u03b4\u03b1\u03bd\u03a6\u03c7\u03bc\u03a8\u03b3\u03ba\u03c9\u03c2.c("\u3e92", (int)am, (long)(an ^ ao)) + stringArray.length);
    }
}

