/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03a6\u03c7\u03a3\u03a8\u03c1\u03bb\u03b6\u03a3;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb
extends \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private static int g;
    private static String[] b;
    private static int i;
    private static int j;
    private static String[] a;
    private static long c;
    private static int e;
    private static int c;
    private static int h;
    private static int k;
    private static long f;
    private static long d;

    private static void b() {
        int n;
        c = 361297495054130406L;
        long l = c ^ 0x3E548124B9A75845L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(51 + 18), (byte)(5 + 78), (byte)(4 + 43), (byte)(29 + 38), (byte)(14 + 52), (byte)(57 + 10), (byte)(41 + 6), (byte)(45 + 35), (byte)(65 + 10), (byte)(34 + 33), (byte)(42 + 41), 53, (byte)(17 + 63), (byte)(44 + 53), (byte)(12 + 88), (byte)(96 + 4), (byte)(96 + 9), (byte)(105 + 5), (byte)(11 + 92)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(39 + 29), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0141\u0116\u0146\u0142\u0148\u010a\u0131\u0132\u0132\u0105\u014e\u0119", (byte)41, 65);
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0551\u052b\u0518\u051f\u055f\u055a\u0557\u0551\u0564\u0522\u0540\u053e\u055f\u0536\u0535\u0537\u0568\u0528\u056b\u0528\u054e\u0561\u0538\u0539", (byte)41, 70);
                    continue block7;
                }
                case 1: {
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0109\u0148\u012c\u0138\u011c\u0147\u013b\u013e\u014b\u014a\u0121\u0113\u014d\u0141\u0124\u0126\u013b\u014b\u0145\u0135\u0149\u014d\u0124\u0125", (byte)41, 66);
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u013d\u0117\u0104\u010b\u014b\u0146\u0143\u013d\u0150\u010e\u012f\u0146\u0128\u014a\u0139\u0133\u012a\u0153\u012e\u0118\u0110\u0137\u0124\u0125", (byte)41, 66);
                    continue block7;
                }
                case 2: {
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0487\u0489\u049a\u048d\u0488\u0468\u04a2\u047b\u047f\u04a9\u04ad\u0478", (byte)41, 67);
                    continue block7;
                }
                case 4: {
                    \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0555\u0518\u052b\u052f\u053e\u0555\u0555\u054e\u0564\u0526\u0556\u052d", (byte)41, 70);
                }
            }
        }
    }

    static {
        c = Integer.reverse(0);
        d = Long.reverse(3546882992375447712L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(3546882992375447712L);
        g = (0 >>> 248 | 0 << ~248 + 1) & 0xFFFFFFFF;
        h = Integer.reverse(0);
        i = 0 >>> 11 | 0 << ~11 + 1;
        j = 0x400000 >>> 149 | 0x400000 << -149;
        k = 65536 >>> 111 | 65536 << ~111 + 1;
        a = new String[j];
        b = new String[k];
        \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.b();
    }

    @Override
    public void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        \u03a0\u03a6\u03c7\u03a3\u03a8\u03c1\u03bb\u03b6\u03a3.a((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a, \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, this.j());
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u03e0\u0402\u0404\u03e4\u0408\u0427\u041f\u0435\u0421\u03f0\u042e\u0424\u0432\u042c\u03f5\u041a\u043c\u043b\u0433\u0439\u0433\u0408", (byte)1, 68), \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u00e4\u00f1\u00f0\u00b3\u00f3\u00ef\u00ea\u00f3\u00fe\u00ed\u00ba\u00f8\u00fc\u00f5\u00f8\u00fe\u00c0\u044b\u043c\u0427\u0438\u0436\u0453\u044a\u0454\u00d4", (byte)1, 66) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u03f2", (byte)1, 67) + methodType.toString(), exception);
        }
    }

    public \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, (String)\u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.c("\u3e80", (int)c, (long)d), (String)\u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.c("\u3e83", (int)e, (long)f), g != 0, h != 0, new String[i]);
    }

    private static String a(int n, long l) {
        l ^= 0x6AL;
        l ^= 0x3E548124B9A75845L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(67 + 2), (byte)(62 + 21), (byte)(14 + 33), (byte)(49 + 18), (byte)(17 + 49), (byte)(66 + 1), (byte)(3 + 44), (byte)(45 + 35), (byte)(36 + 39), 67, (byte)(62 + 21), (byte)(43 + 10), (byte)(46 + 34), (byte)(15 + 82), (byte)(30 + 70), (byte)(19 + 81), 105, (byte)(46 + 64), (byte)(73 + 30)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(52 + 17), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u017a\u0187\u0186\u0149\u0189\u0185\u0180\u0189\u0194\u0183\u0150\u018e\u0192\u018b\u018e\u0194\u0156\u04e1\u04d2\u04bd\u04ce\u04cc\u04e9\u04e0\u04ea", (byte)76, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b9\u03a9\u0393\u03a3\u03a0\u03bc\u03b2\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

