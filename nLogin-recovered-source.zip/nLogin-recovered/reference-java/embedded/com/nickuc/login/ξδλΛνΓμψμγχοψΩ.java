/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.AccountType
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.AccountType;
import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<AccountType> {
    private static long b;
    private static int e;
    private static int h;
    private static int i;
    private static long f;
    private static long g;
    private static int a;
    private static String[] b;
    private static long d;
    public static final \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9 a;
    private static long c;
    private static String[] a;

    @Override
    public JSONObject a(@Nonnull AccountType accountType) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put((String)\u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.c("\u3e80", (int)a, (long)(b ^ d)), (Object)accountType);
        return jSONObject;
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-8882993929522185742L);
        d = Long.reverse(0x2200000000000000L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(-8882993929522185742L);
        g = Long.reverse(0x2200000000000000L);
        h = Integer.reverse(0x40000000);
        i = (4 >>> 1 | 4 << ~1 + 1) & 0xFFFFFFFF;
        a = new String[h];
        b = new String[i];
        \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b();
        a = new \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9();
    }

    private static void b() {
        int n;
        c = 5737312196940176673L;
        long l = c ^ 0xDA539A27E5F603EEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(58 + 10), (byte)(2 + 67), (byte)(12 + 71), (byte)(42 + 5), (byte)(51 + 16), (byte)(2 + 64), (byte)(19 + 48), 47, (byte)(59 + 21), (byte)(60 + 15), (byte)(50 + 17), (byte)(22 + 61), (byte)(46 + 7), (byte)(27 + 53), (byte)(83 + 14), (byte)(83 + 17), (byte)(10 + 90), (byte)(73 + 32), (byte)(109 + 1), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(5 + 63), 69, (byte)(52 + 31)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u0188\u017d\u014c\u0161\u0166\u015d\u018e\u018b\u0195\u0149\u016c\u015d", (byte)75, 66);
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u0509\u04fe\u04cd\u04e2\u04e7\u04de\u050f\u050c\u0516\u04ca\u04ed\u04de", (byte)75, 68);
                    continue block7;
                }
                case 1: {
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u0148\u014b\u0171\u0191\u0185\u0173\u0181\u014c\u014c\u0167\u0188\u0183\u0169\u0158\u014e\u018b\u0176\u0193\u0157\u0192\u016b\u0191\u0168\u0169", (byte)75, 66);
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u04fb\u04c7\u04ff\u04f0\u04ce\u04dc\u0509\u04cc\u04f7\u0503\u0507\u04fb\u04d8\u04db\u050b\u050a\u04d7\u04de\u04eb\u04f9\u0504\u0522\u04e9\u04ea", (byte)75, 68);
                    continue block7;
                }
                case 2: {
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0177\u0179\u0168\u017e\u017d\u017f\u015e\u0190\u0188\u0164\u0191\u0184\u0152\u0170\u0155\u019d\u016a\u017b\u017f\u019d\u017f\u016b\u0168\u0169", (byte)75, 65);
                    continue block7;
                }
                case 4: {
                    \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0574\u057e\u053d\u0535\u055a\u0555\u0580\u0578\u0585\u0588\u055d\u0569\u0555\u0575\u0578\u0588\u0549\u0588\u0582\u0590\u0570\u056d\u0567\u056d\u054a\u0563\u0556\u058f\u0557\u0594\u059b\u0570", (byte)75, 70);
                }
            }
        }
    }

    @Override
    public AccountType a(@Nonnull JSONObject jSONObject) {
        return (AccountType)jSONObject.getEnum(AccountType.class, (String)\u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.c("\u3e80", (int)e, (long)(f ^ g)));
    }

    private static String a(int n, long l) {
        l ^= 0x44L;
        l ^= 0xDA539A27E5F603EEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(7 + 62), (byte)(39 + 44), (byte)(41 + 6), (byte)(42 + 25), (byte)(50 + 16), (byte)(16 + 51), (byte)(2 + 45), (byte)(54 + 26), (byte)(16 + 59), (byte)(4 + 63), 83, (byte)(29 + 24), 80, (byte)(20 + 77), (byte)(95 + 5), (byte)(82 + 18), (byte)(17 + 88), (byte)(87 + 23), (byte)(52 + 51)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(39 + 30), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u04e4\u04f1\u04f0\u04b3\u04f3\u04ef\u04ea\u04f3\u04fe\u04ed\u04ba\u04f8\u04fc\u04f5\u04f8\u04fe\u04c0\u0850\u0847\u084f\u0830\u0853\u082a\u0854\u0861\u0856\u084e\u0863\u085c\u0866\u0848", (byte)68, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public Class<?> a() {
        return AccountType.class;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0527\u0549\u054b\u052b\u054f\u056e\u0566\u057c\u0568\u0537\u0575\u056b\u0579\u0573\u053c\u0561\u0583\u0582\u057a\u0580\u057a\u054f", (byte)67, 70), \u03be\u03b4\u03bb\u039b\u03bd\u0393\u03bc\u03c8\u03bc\u03b3\u03c7\u03bf\u03c8\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u04e1\u04ee\u04ed\u04b0\u04f0\u04ec\u04e7\u04f0\u04fb\u04ea\u04b7\u04f5\u04f9\u04f2\u04f5\u04fb\u04bd\u084d\u0844\u084c\u082d\u0850\u0827\u0851\u085e\u0853\u084b\u0860\u0859\u0863\u0845\u04d7", (byte)67, 67) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0539", (byte)67, 70) + methodType.toString(), exception);
        }
    }
}

