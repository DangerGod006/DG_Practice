/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  github.scarsz.discordsrv.DiscordSRV
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import github.scarsz.discordsrv.DiscordSRV;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9 {
    private static int b;
    private static int e;
    private static int f;
    private static long d;
    private static long c;
    private static int a;
    private static String[] a;
    private static String[] b;
    private static int g;

    private static String a(int n, long l) {
        l ^= 0x78L;
        l ^= 0xDB7B1AA93C1E6795L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(58 + 10), (byte)(52 + 17), (byte)(25 + 58), (byte)(32 + 15), (byte)(10 + 57), 66, (byte)(7 + 60), (byte)(33 + 14), (byte)(60 + 20), 75, (byte)(12 + 55), (byte)(80 + 3), (byte)(40 + 13), (byte)(58 + 22), (byte)(82 + 15), (byte)(58 + 42), (byte)(83 + 17), (byte)(73 + 32), (byte)(7 + 103), (byte)(77 + 26)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(66 + 2), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0514\u0521\u0520\u04e3\u0523\u051f\u051a\u0523\u052e\u051d\u04ea\u0528\u052c\u0525\u0528\u052e\u04f0\u0883\u0874\u0875\u086d\u0884\u088d\u087e\u0883\u0888\u088b\u0894\u088c\u0877", (byte)84, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    public String a(UUID uUID) {
        try {
            return DiscordSRV.getPlugin().getAccountLinkManager().getDiscordId(uUID);
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.c("\u3e80", (int)(a & b), (long)d), throwable, new Object[e]);
            return null;
        }
    }

    static {
        a = Integer.reverse(0);
        b = (-1 >>> 49 | -1 << -49) & 0xFFFFFFFF;
        d = Long.reverse(-8180841672966045951L);
        e = Integer.reverse(0);
        f = (8 >>> 3 | 8 << -3) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0151\u0173\u0175\u0155\u0179\u0198\u0190\u01a6\u0192\u0161\u019f\u0195\u01a3\u019d\u0166\u018b\u01ad\u01ac\u01a4\u01aa\u01a4\u0179", (byte)85, 65), \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u018c\u0199\u0198\u015b\u019b\u0197\u0192\u019b\u01a6\u0195\u0162\u01a0\u01a4\u019d\u01a0\u01a6\u0168\u04fb\u04ec\u04ed\u04e5\u04fc\u0505\u04f6\u04fb\u0500\u0503\u050c\u0504\u04ef\u0181", (byte)85, 65) + string + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u04ee", (byte)85, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -9151696085357171191L;
        long l = c ^ 0xDB7B1AA93C1E6795L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(9 + 60), (byte)(21 + 62), (byte)(12 + 35), (byte)(66 + 1), (byte)(9 + 57), (byte)(55 + 12), (byte)(4 + 43), (byte)(19 + 61), (byte)(14 + 61), (byte)(19 + 48), (byte)(50 + 33), 53, (byte)(32 + 48), (byte)(87 + 10), (byte)(96 + 4), (byte)(90 + 10), 105, (byte)(34 + 76), (byte)(71 + 32)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(35 + 34), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0558\u0541\u0567\u058b\u0566\u0579\u0557\u058f\u0545\u054f\u0561\u054f\u0553\u0586\u056a\u0586\u0593\u056a\u0592\u0597\u0595\u0570\u055a\u055b\u0595\u058c\u0589\u0582\u0563\u056c\u059a\u0592\u05a4\u0579\u0596\u0560\u057a\u059f\u05ae\u0579\u059c\u059b\u0568\u0593\u0584\u05a8\u0574\u0573\u05a1\u05aa\u05a9\u0599\u05a4\u058e\u0577\u05b9\u05bf\u05a1\u05ba\u0593\u057a\u057c\u05a3\u05b9\u0592\u0592\u05c4\u0583\u0599\u05cc\u05bc\u05a4\u05cf\u0599\u0588\u0596", (byte)82, 69);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04f5\u04de\u0504\u0528\u0503\u0516\u04f4\u052c\u04e2\u04ec\u04fe\u04ec\u04f0\u0523\u0507\u0523\u0530\u0507\u052f\u0534\u0532\u050d\u04f7\u04f8\u0532\u0529\u0526\u051f\u0500\u0509\u0537\u052f\u0541\u0516\u0533\u04fd\u0517\u053c\u054b\u0516\u0539\u0538\u0505\u0530\u0521\u0545\u0511\u0510\u053e\u0547\u0546\u0536\u0541\u052b\u0514\u0556\u055c\u053e\u0557\u0530\u0517\u0519\u0540\u0556\u0551\u053f\u0522\u0530\u0555\u054a\u0565\u054c\u055e\u055d\u055c\u0533", (byte)82, 68);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u051c\u04f1\u050f\u0501\u0524\u04f9\u0509\u051b\u0509\u0527\u050c\u0529\u0506\u0503\u04ed\u04ef\u052a\u04e7\u0505\u0503\u04ea\u0527\u04fe\u04ff", (byte)82, 68);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03b1\u03b1\u03a8\u03be\u03c6\u03b6\u03ba\u03be\u03c0\u03c8\u03bf\u03a9.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0541\u0573\u0573\u0574\u055e\u0583\u056d\u0576\u0549\u058f\u0563\u055d\u057e\u055e\u054e\u0583\u056e\u0589\u058f\u059a\u0554\u0573\u058d\u0590\u0567\u0556\u0591\u05a1\u0581\u0570\u0562\u0597", (byte)82, 70);
                }
            }
        }
    }
}

