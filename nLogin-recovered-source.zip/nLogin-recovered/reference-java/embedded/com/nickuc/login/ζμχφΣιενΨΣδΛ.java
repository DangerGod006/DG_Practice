/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.messaging.PluginMessageListener
 *  org.jetbrains.annotations.NotNull
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b
implements PluginMessageListener {
    private static int h;
    private static String[] b;
    private static int a;
    private static long g;
    private final nLoginBukkit q;
    private static int f;
    private final \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 a;
    private static int e;
    private static long c;
    private static String[] a;
    private static long b;
    private static int j;
    private static long d;
    private static int i;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u049a\u04bc\u04be\u049e\u04c2\u04e1\u04d9\u04ef\u04db\u04aa\u04e8\u04de\u04ec\u04e6\u04af\u04d4\u04f6\u04f5\u04ed\u04f3\u04ed\u04c2", (byte)63, 68), \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u04d5\u04e2\u04e1\u04a4\u04e4\u04e0\u04db\u04e4\u04ef\u04de\u04ab\u04e9\u04ed\u04e6\u04e9\u04ef\u04b1\u0839\u0840\u084c\u084c\u082a\u0841\u083e\u0847\u0833\u082f\u0841\u0829\u04c9", (byte)63, 67) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0535", (byte)63, 70) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b(nLoginBukkit nLoginBukkit2, \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b9 \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b92) {
        this.q = nLoginBukkit2;
        this.a = \u03bd\u03a6\u03b2\u03ba\u03b9\u03c8\u03c9\u03b6\u03c2\u03b5\u03bf\u03b5\u03b92;
    }

    private static void b() {
        int n;
        c = 3285406851601245588L;
        long l = c ^ 0x37390C66700FB92CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(23 + 46), (byte)(74 + 9), (byte)(4 + 43), (byte)(51 + 16), (byte)(17 + 49), 67, (byte)(16 + 31), 80, (byte)(42 + 33), (byte)(24 + 43), (byte)(73 + 10), (byte)(37 + 16), (byte)(27 + 53), (byte)(79 + 18), (byte)(67 + 33), (byte)(24 + 76), (byte)(26 + 79), (byte)(5 + 105), (byte)(20 + 83)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(26 + 43), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u044f\u046c\u0468\u047f\u0494\u045a\u048c\u0484\u0462\u0460\u04a6\u0477\u045f\u04aa\u04a0\u0476\u049c\u04a6\u046d\u049a\u049c\u04a0\u0477\u0478", (byte)37, 67);
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0559\u054a\u0550\u0525\u0557\u0535\u0537\u0557\u0553\u054c\u051b\u0546\u055e\u0555\u0548\u055f\u0540\u0528\u054d\u0527\u0556\u0544\u0545\u054a\u0529\u054d\u0551\u0544\u056b\u0567\u054d\u0547\u0571\u054f\u0538\u0576\u054e\u056b\u0571\u0551\u0570\u057b\u055d\u057a\u055c\u0555\u053a\u0565\u0568\u0575\u0587\u058a\u058e\u056a\u0549\u0580\u055b\u0569\u056b\u055e\u0555\u056f\u0561\u0553", (byte)37, 69);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u044f\u046c\u0468\u047f\u0494\u045a\u048c\u0484\u0462\u0460\u04a6\u047b\u04a0\u0476\u0496\u046c\u0480\u048f\u0484\u047b\u0483\u04a0\u0477\u0478", (byte)37, 68);
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u049c\u048d\u0493\u0468\u049a\u0478\u047a\u049a\u0496\u048f\u045e\u0489\u04a1\u0498\u048b\u04a2\u0483\u046b\u0490\u046a\u0499\u0487\u0488\u048d\u046c\u0490\u0494\u0487\u04ae\u04aa\u0490\u048a\u04b4\u0492\u047b\u04b9\u0491\u04ae\u04b4\u0494\u04b3\u04be\u04a0\u04bd\u049f\u0498\u047d\u04a8\u04ab\u04b8\u04ca\u04cd\u04d1\u04aa\u04aa\u04cd\u04a2\u0494\u04ca\u048e\u04c5\u04c4\u0494\u0497\u04a5\u04b3\u04b9\u04e0\u04e2\u04ce\u04af\u04e1\u04b2\u04b7\u04d9\u04ac", (byte)37, 68);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u054a\u0532\u054a\u0559\u054c\u0558\u0512\u053b\u052e\u054e\u055f\u0556\u0553\u053c\u0548\u0552\u053e\u053a\u054d\u0568\u0567\u0568\u0568\u0541\u052e\u0531\u0542\u0527\u052f\u054a\u0553\u0570", (byte)37, 70);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0551\u052e\u052a\u0514\u0551\u053b\u053a\u0531\u0535\u0550\u0539\u0565\u0537\u053d\u053d\u053b\u0522\u0529\u0562\u055b\u055a\u052e\u0538\u0564\u0544\u055e\u0546\u0575\u0569\u0535\u056d\u0549", (byte)37, 70);
                }
            }
        }
    }

    public void onPluginMessageReceived(@NotNull String string, Player player, byte[] byArray) {
        if (!string.equals(\u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.c("\u3e80", (int)a, (long)(b ^ d)))) {
            return;
        }
        try {
            this.a.a().a(this.q.b().a(player), byArray);
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.a((String)\u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.c("\u3e83", (int)(e & f), (long)g) + player.getName(), exception, new Object[h]);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x6AL;
        l ^= 0x37390C66700FB92CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(38 + 30), (byte)(22 + 47), (byte)(4 + 79), (byte)(36 + 11), (byte)(63 + 4), (byte)(24 + 42), (byte)(42 + 25), (byte)(15 + 32), (byte)(42 + 38), (byte)(7 + 68), (byte)(23 + 44), (byte)(8 + 75), (byte)(6 + 47), (byte)(2 + 78), (byte)(76 + 21), (byte)(44 + 56), (byte)(15 + 85), (byte)(89 + 16), 110, 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(45 + 24), (byte)(23 + 60)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0472\u047f\u047e\u0441\u0481\u047d\u0478\u0481\u048c\u047b\u0448\u0486\u048a\u0483\u0486\u048c\u044e\u07d6\u07dd\u07e9\u07e9\u07c7\u07de\u07db\u07e4\u07d0\u07cc\u07de\u07c6", (byte)30, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(3001027068448741812L);
        d = Long.reverse(0x5600000000000000L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (-1 >>> 126 | -1 << -126) & 0xFFFFFFFF;
        g = Long.reverse(9197980155710544308L);
        h = Integer.reverse(0);
        i = (0x8000000 >>> 154 | 0x8000000 << -154) & 0xFFFFFFFF;
        j = Integer.reverse(0x40000000);
        a = new String[i];
        b = new String[j];
        \u03b6\u03bc\u03c7\u03c6\u03a3\u03b9\u03b5\u03bd\u03a8\u03a3\u03b4\u039b.b();
    }
}

